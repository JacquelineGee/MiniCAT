var r = require("~/r");
r("u8yC", Object.assign({}, require("~/v.js").modules, require("~/c.js").modules, {
  u8yC: function(o, t, e) {
    e.r(t);
    var s = e("Fcif"),
      i = e("VmHG"),
      r = e("YeA1"),
      u = e("Shdd"),
      a = function(o) {
        return o >= 1e4 ? (o / 1e4).toFixed(1) + "万" : o
      },
      c = {
        getters: {
          goodsStockOpt() {
            var o, {
                goodsBaseInfo: t,
                goodsPriceInfo: e,
                multistore: s,
                shopConfig: i = {},
                distribution: {
                  postage: r
                }
              } = this,
              {
                isOutlink: u,
                isHotel: c
              } = t,
              {
                soldNum: n,
                stockNum: d,
                hideStock: g
              } = e,
              {
                showBuyRecord: l,
                goodsDetailSales: h
              } = i,
              f = s.id || 0,
              m = function(o) {
                var {
                  goodsBaseInfo: t,
                  goodsPriceInfo: e,
                  storeId: s
                } = o, {
                  isHotel: i
                } = t, {
                  stockNum: r,
                  hideStock: u
                } = e;
                return r > 0 && !u && !i && !(s > 0 && 0 === r)
              }({
                goodsBaseInfo: t,
                goodsPriceInfo: e,
                storeId: f
              }),
              p = function(o) {
                var {
                  shopConfig: t,
                  goodsPriceInfo: e
                } = o, {
                  showBuyRecord: s,
                  goodsDetailSales: i
                } = t, {
                  soldNum: r
                } = e, u = s ? {
                  show: 1,
                  limit: !1
                } : {
                  show: 0,
                  limit: !1
                };
                if (i) try {
                  u = JSON.parse(i) || u
                } catch (o) {}
                if (!u) return r > 0;
                var {
                  show: a = 0,
                  limit: c = !1,
                  limit_num: n = 0
                } = u;
                return 0 != +a && (c ? r >= n : r > 0)
              }({
                shopConfig: i,
                goodsPriceInfo: e
              });
            return {
              postage: r,
              storeId: f,
              soldNum: n,
              stockNum: d,
              hideStock: g,
              isOutlink: u,
              isHotel: c,
              showBuyRecord: l,
              goodsDetailSales: h,
              showStockNum: m,
              showSoldNum: p,
              showBlock: !(u || !(r || m || p)),
              soldNumText: (o = n, o > 99999 ? "10万+" : o),
              stockNumText: a(d)
            }
          }
        }
      },
      n = {
        getters: {
          packageBuy() {
            var {
              orderPromotion: o = []
            } = this.promotionActivity, t = o.filter(o => "packageBuy" === o.key);
            if (t.length) {
              var e = {
                url: "",
                goodsList: []
              };
              return t.forEach(o => {
                e.url = o.url, e.goodsList.push(o.goodsModel)
              }), e
            }
            return null
          },
          goodsPackageBuyOpt() {
            return {
              show: !!this.packageBuy,
              packageBuy: this.packageBuy
            }
          }
        }
      },
      d = e("9ZMt");
    var g = [c, n].reduce((o, t) => Object(u.c)(o, t), {});

    function l(o) {
      return Object(i.a)({
        state: () => Object(s.a)({}, function() {
          var {
            distribution: o = {},
            goodsBaseInfo: t = {},
            goodsPriceInfo: e = {},
            shopConfig: s = {},
            multistore: i = {},
            umpActivityData: {
              promotionActivity: r = {}
            } = {}
          } = d.default.getGlobal("GOODS_DATA") || {};
          return {
            goodsBaseInfo: t,
            distribution: o,
            shopConfig: s,
            multistore: i,
            goodsPriceInfo: e,
            promotionActivity: r,
            themeCSS: "",
            pageStyleCSS: ""
          }
        }(), g.state),
        getters: Object(s.a)({}, g.getters),
        actions: Object(s.a)({}, g.getActions(o))
      })
    }
    var h = {
      data() {
        return this.store = l(this.ctx), Object(i.c)(this, ["goodsBaseInfo", "distribution", "shopConfig", "multistore", "goodsPriceInfo", "promotionActivity", "marketing"]), Object(s.a)({}, Object(i.d)(this, ["goodsStockOpt", "goodsPackageBuyOpt"]), {
          showPackageBuy: !0
        })
      },
      created() {
        Object(r.e)(this, {
          showPackageBuy: o => {
            this.showPackageBuy = o
          }
        })
      }
    };
    t.default = d.default.component(h)
  }
}));