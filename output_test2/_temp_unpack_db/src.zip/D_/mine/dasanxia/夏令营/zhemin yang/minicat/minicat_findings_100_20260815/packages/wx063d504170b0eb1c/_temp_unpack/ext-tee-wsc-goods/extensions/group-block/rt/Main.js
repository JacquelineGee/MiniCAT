var r = require("~/r");
r("1Wce", Object.assign({}, require("~/v.js").modules, require("~/c.js").modules, {
  "1Wce": function(e, t, r) {
    r.r(t);
    var s, a = r("Fcif"),
      i = r("YeA1"),
      o = r("VmHG"),
      n = r("Shdd"),
      u = r("w2Y9"),
      c = r.n(u);
    ! function(e) {
      e.FreightInsurance = "freightInsurance", e.FreightInsurancePro = "freightInsurancePro", e.SupportQuickRefund = "supportQuickRefund", e.IsExpiredAutoRefund = "isExpiredAutoRefund", e.SupportUnconditionalReturn = "supportUnconditionalReturn", e.SupportBarter = "supportBarter", e.SupplierDirect = "supplierDirect", e.HaitaoTaxContains = "haitaoTaxContains", e.PhysicalStore = "physicalStore", e.CashOnDelivery = "cashOnDelivery", e.HaitaoTaxExtraPays = "haitaoTaxExtraPays", e.TaxFreeExpress = "taxFreeExpress", e.OverseaDirectMail = "overseaDirectMail", e.UnsupportRefund = "unsupportRefund", e.UnsupportRefundNoReason = "unsupportRefundNoReason", e.SupportExpress = "supportExpress", e.SupportSelfFetch = "supportSelfFetch", e.SupportLocalDelivery = "supportLocalDelivery", e.IsSecuredTransactions = "isSecuredTransactions", e.IsSecuredTransactionsKuaishou = "isSecuredTransactionsKuaishou", e.AfterSalesFromShop = "afterSalesFromShop", e.PayShopDirectly = "payShopDirectly"
    }(s || (s = {}));
    var d = [{
      key: s.FreightInsurance,
      show(e) {
        var {
          shopConfig: t
        } = e;
        return 1 === Number(t.supportFreightInsurance)
      }
    }, {
      key: s.FreightInsurancePro,
      show(e) {
        var {
          shopConfig: t
        } = e;
        return 2 === Number(t.supportFreightInsurance)
      }
    }, {
      key: s.SupportQuickRefund,
      show(e) {
        var {
          goodsBaseInfo: t
        } = e;
        return t.supportQuickRefund
      }
    }, {
      key: s.IsExpiredAutoRefund,
      show(e) {
        var t, {
          goodsActivity: r
        } = e;
        return null == (t = r.virtualTicket) ? void 0 : t.isExpiredAutoRefund
      }
    }, {
      key: s.SupportBarter,
      show(e) {
        var t, {
          goodsBaseInfo: r
        } = e;
        return 1 === (null == (t = r.barterModel) ? void 0 : t.isSupportBarter)
      }
    }, {
      key: s.SupportUnconditionalReturn,
      show(e) {
        var {
          goodsBaseInfo: t
        } = e;
        return t.supportUnconditionalReturn
      }
    }, {
      key: s.SupplierDirect,
      show(e) {
        var t, {
          goodsBaseInfo: r,
          staticConfig: s
        } = e;
        return r.fxTradeMode === (null == s || null == (t = s.fxMode) ? void 0 : t.PROMOTION)
      },
      parser(e) {
        var t, {
            goodsBaseInfo: r,
            staticConfig: s
          } = e,
          a = null == (t = s.certUrlMap) ? void 0 : t.shopInfo;
        return a ? {
          url: c.a.add(a, {
            kdt_id: r.supplierKdtId,
            show: "supplier",
            no_footer: 1,
            no_btn: 1
          })
        } : null
      }
    }, {
      key: s.HaitaoTaxContains,
      show(e) {
        var {
          goodsBaseInfo: t,
          goodsActivity: r
        } = e;
        return t.isHaitao && r.haitao && 0 !== r.haitao.tariffRule
      }
    }, {
      key: s.PhysicalStore,
      show(e) {
        var {
          shopConfig: t,
          env: r
        } = e;
        return t.hasPhysicalStore && !r.isNewHopeKdt
      }
    }, {
      key: s.CashOnDelivery,
      show(e) {
        var {
          payWays: t
        } = e;
        return t.cashOnDelivery
      }
    }, {
      key: s.HaitaoTaxExtraPays,
      show(e) {
        var {
          goodsBaseInfo: t,
          goodsActivity: r
        } = e;
        return t.isHaitao && r.haitao && 0 === r.haitao.tariffRule
      }
    }, {
      key: s.TaxFreeExpress,
      show(e) {
        var t, {
          goodsActivity: r
        } = e;
        return 1210 === (null == (t = r.haitao) ? void 0 : t.haiTaoTradeMode)
      }
    }, {
      key: s.OverseaDirectMail,
      show(e) {
        var t, {
          goodsActivity: r
        } = e;
        return 9610 === (null == (t = r.haitao) ? void 0 : t.haiTaoTradeMode)
      }
    }, {
      key: s.UnsupportRefund,
      show(e) {
        var t, {
          goodsMetaInfo: r
        } = e;
        return !(null != (t = r.refund) && t.isSupport)
      }
    }, {
      key: s.UnsupportRefundNoReason,
      show(e) {
        var {
          goodsBaseInfo: t,
          goodsActivity: r
        } = e;
        return t.isHaitao && r.haitao || t.isPrescriptionCategory
      }
    }, {
      key: s.SupportExpress,
      show(e) {
        var {
          distribution: t
        } = e;
        return t.supportExpress
      },
      parser(e) {
        var {
          distribution: t
        } = e, {
          expressFee: r,
          expressPayMode: s
        } = t, a = "免运费" === r ? r : "运费：" + r;
        return s && (a = "为运费到付，运费最终以物流公司计算为准"), {
          desc: "可选择快递发货配送上门，本商品" + a + "。"
        }
      }
    }, {
      key: s.SupportSelfFetch,
      show(e) {
        var {
          distribution: t
        } = e;
        return t.supportSelfFetch
      }
    }, {
      key: s.SupportLocalDelivery,
      show(e) {
        var {
          distribution: t
        } = e;
        return t.supportLocalDelivery
      },
      parser(e) {
        var {
          distribution: t
        } = e;
        return {
          desc: "可选择同城配送并预约送达时间" + (t.localDeliveryFee ? "，本商品运费：" + t.localDeliveryFee : "") + "。"
        }
      }
    }, {
      key: s.IsSecuredTransactions,
      show(e) {
        var {
          shopConfig: t,
          env: r
        } = e;
        return t.isSecuredTransactions && "kuaishou" !== r.platform
      }
    }, {
      key: s.IsSecuredTransactionsKuaishou,
      show(e) {
        var {
          shopConfig: t,
          env: r
        } = e;
        return t.isSecuredTransactions && "kuaishou" === r.platform
      }
    }, {
      key: s.AfterSalesFromShop,
      show(e) {
        var {
          shopConfig: t
        } = e;
        return !t.isSecuredTransactions
      }
    }, {
      key: s.PayShopDirectly,
      show(e) {
        var {
          shopConfig: t
        } = e;
        return !t.isSecuredTransactions
      }
    }];
    var h = {
        getters: {
          goodsServiceOpt() {
            var e, t = {
                shopConfig: this.shopConfig,
                env: this.env,
                payWays: this.payWays,
                goodsMetaInfo: this.goodsMetaInfo,
                goodsBaseInfo: this.goodsBaseInfo,
                goodsActivity: this.goodsActivity,
                supplier: this.supplier,
                distribution: this.distribution,
                staticConfig: this.staticConfig,
                themeCSS: this.themeCSS
              },
              r = (e = t, d.reduce((t, r) => {
                var {
                  key: s,
                  show: i,
                  parser: o
                } = r;
                if (!i || "function" == typeof i && !i(e)) return t;
                var {
                  serviceTagMap: n = {}
                } = e.staticConfig, u = n[s], c = o ? o(e) : u;
                return (c || u) && t.push(Object(a.a)({}, u, c)), t
              }, [])),
              s = r.slice(0, 3) || [];
            return Object(a.a)({}, t, {
              serviceDescList: r,
              serviceBarList: s,
              serviceBarTitle: s.map(e => e.tag).join(" · ")
            })
          }
        }
      },
      p = r("uzJ0"),
      l = r.n(p),
      v = r("KEq0"),
      g = r.n(v),
      f = r("q29p"),
      S = r.n(f),
      k = r("NHEX"),
      y = r.n(k),
      D = r("US/N"),
      I = {
        state: {
          selectedSku: {},
          selectedProp: {},
          priceBarList: [],
          activeDateSkuId: 0
        },
        getters: {
          showSkuBar() {
            var {
              virtualTicket: e,
              periodbuy: t
            } = this.goodsActivity, {
              hideGoodsBottom: r
            } = this.env;
            if (t) return !this.pageFeature.showForbidBuyBtn;
            if (r) return !1;
            var {
              itemSalePropList: s = []
            } = this.goodsBaseInfo, {
              tree: a = []
            } = this.goodsSkuData.goods || {};
            return a.length + s.length > 0 || (null == e ? void 0 : e.isPriceCalendar)
          },
          isSkuBarDisabled() {
            return !!this.shopConfig.isCloseBusiness
          },
          skuBarDesc() {
            var {
              skuExtraData: e = {}
            } = this;
            return "共" + e.barPictureCount + "种" + e.barPictureName + "可选"
          },
          skuExtraData() {
            if (!this.showSkuBar) return {};
            var {
              selectedSku: e,
              selectedProp: t
            } = this, {
              tree: r = []
            } = this.goodsSkuData.goods || {}, {
              itemSalePropList: s = [],
              pictures: i
            } = this.goodsBaseInfo, o = i || [], n = [], u = "", c = r[0] || {}, d = 0;
            y()(c, "v.0.imgUrl", "") && (n = (c.v || []).filter(e => (d++, !e.defaultSkuImg)).map(e => g()(e.imgUrl || o, "small")), u = c.k);
            var h = r.reduce((e, t) => Object(a.a)({}, e, {
                [t.kS]: t
              }), {}),
              p = [],
              l = Object.keys(e);
            l.forEach(t => {
              var r = h[t] || null;
              if (e[t] && r) {
                for (var s = e[t], a = null, i = 0; i < r.v.length; i++)
                  if (r.v[i].id === +s) {
                    a = r.v[i];
                    break
                  } p.push({
                  id: r.kId,
                  name: r.k,
                  value: a
                })
              }
            }), e && 0 !== l.length || (p = r.map(e => ({
              id: e.kId,
              name: e.k,
              value: null
            })));
            var v = [];
            return s.forEach(e => {
              var r = [];
              t[e.kId] && t[e.kId].length > 0 && (r = (e.v || []).filter(r => t[e.kId].indexOf(r.id) > -1)), v.push({
                id: e.kId,
                name: e.k,
                value: r
              })
            }), {
              barPictures: n.slice(0, 5),
              barPictureName: u,
              barPictureCount: d,
              selectedSkuTree: p,
              selectedPropList: v
            }
          },
          skuBarInfo() {
            if (!this.showSkuBar) return {};
            var {
              selectedSkuTree: e = [],
              selectedPropList: t = []
            } = this.skuExtraData, {
              tree: r = []
            } = this.goodsSkuData.goods || {}, s = [], a = [], i = !0, o = !1;
            (e.length ? e : r.map(e => ({
              name: e.k
            }))).forEach(e => {
              e.value ? (s.push(e.value.name), o = !0) : (a.push(e.name), i = !1)
            }), t.forEach(e => {
              e.value && e.value.length > 0 ? (s.push(...e.value.map(e => e.name)), o = !0) : (a.push(e.name), i = !1)
            });
            var n = "";
            return n = o ? s.join("；") : a.join("；"), {
              isAnySelected: o,
              isAllSelected: i,
              showText: n
            }
          },
          SelectSkuOpt() {
            var {
              isPriceCalendar: e = !1
            } = this.goodsActivity.virtualTicket || {}, {
              showForbidBuyBtn: t
            } = this.pageFeature, r = !t && e && this.priceBarList.length;
            return {
              show: this.showSkuBar,
              showPriceCalendarBar: r,
              isSkuBarDisabled: this.isSkuBarDisabled,
              priceBarList: this.priceBarList,
              skuExtraData: this.skuExtraData,
              skuBarDesc: this.skuBarDesc,
              skuBarInfo: this.skuBarInfo
            }
          }
        },
        getActions: () => ({
          formatDateList(e) {
            return (e || []).map(e => {
              var t = new Date(e.stockDate),
                r = t.getMonth() + 1,
                s = r > 9 ? r : "0" + r,
                i = t.getDate(),
                o = void 0 === e.activityPrice ? e.originPrice : e.activityPrice;
              return Object(a.a)({}, e, {
                day: s + "-" + (i > 9 ? i : "0" + i),
                price: "¥" + l()(o),
                selected: e.dateSkuId === this.activeDateSkuId,
                currentPrice: o
              })
            }).filter(e => e.currentPrice)
          },
          updateCalendar(e) {
            var {
              dateSkuId: t,
              nearDateList: r
            } = e;
            this.activeDateSkuId = t, this.priceBarList = this.formatDateList(r)
          },
          onSkuSelected(e) {
            var {
              selectedSkuComb: t,
              pluginsResult: r = {}
            } = e;
            this.selectedSku = t || {}, r.ecard && this.updateCalendar(r.ecard), r.goodsAttributes && (this.selectedProp = r.goodsAttributes)
          },
          fetchNearDateList(e) {
            var t, r;
            if (null == e || null == (t = e.virtualTicket) ? void 0 : t.isPriceCalendar) {
              var s = new Date;
              s.setMonth(s.getMonth() + 4), s.setDate(0);
              var {
                alias: a,
                id: i
              } = this.goodsBaseInfo, o = {
                alias: a,
                activityType: 0,
                activityAlias: "",
                itemId: i,
                kdtId: this.kdtId,
                beginDate: S()(new Date, "YYYY-MM-DD"),
                endDate: S()(s, "YYYY-MM-DD"),
                itemPreOrderTime: null == e || null == (r = e.virtualTicket) ? void 0 : r.itemPreOrderTime
              };
              Object(D.default)({
                path: "/wscgoods/getNearDateList.json",
                data: o
              }).then(e => {
                this.priceBarList = this.formatDateList(e.nearlyFourDayMarketableDate)
              })
            }
          }
        })
      },
      B = {
        getters: {
          ServiceCategoryOpt() {
            return {
              goodsBaseInfo: this.goodsBaseInfo,
              shopConfig: this.shopConfig,
              themeVars: this.themeCSS + this.pageStyleCSS
            }
          }
        }
      },
      m = r("9ZMt");
    var b = [h, I, B].reduce((e, t) => Object(n.c)(e, t), {});

    function C(e) {
      return Object(o.a)({
        state: () => Object(a.a)({}, function() {
          var {
            shopConfig: e = {},
            payWays: t = {},
            goodsMetaInfo: r = {},
            goodsBaseInfo: s = {},
            goodsActivity: a = {},
            supplier: i = {},
            distribution: o = {},
            staticConfig: n = {},
            goodsSkuData: u = {},
            pageFeature: c = {},
            env: d = {},
            kdtId: h = 0
          } = m.default.getGlobal("GOODS_DATA") || {};
          return {
            shopConfig: e,
            env: d,
            payWays: t,
            goodsMetaInfo: r,
            goodsBaseInfo: s,
            goodsActivity: a,
            supplier: i,
            distribution: o,
            staticConfig: n,
            goodsSkuData: u,
            pageFeature: c,
            kdtId: h,
            pageStyleCSS: "",
            themeCSS: ""
          }
        }(), b.state),
        getters: Object(a.a)({}, b.getters),
        actions: Object(a.a)({}, b.getActions(e))
      })
    }
    var w = {
      data() {
        return this.store = C(this.ctx), Object(o.c)(this, ["shopConfig", "env", "payWays", "goodsMetaInfo", "goodsBaseInfo", "goodsActivity", "distribution", "staticConfig", "goodsSkuData", "pageFeature", "kdtId"]), Object(a.a)({}, Object(o.d)(this, ["goodsServiceOpt", "SelectSkuOpt", "ServiceCategoryOpt"]), {
          skuSelected: {},
          showServiceBar: !0,
          goodsServiceOpts: {}
        })
      },
      watch: {
        goodsServiceOpt: {
          handler(e) {
            e && (this.goodsServiceOpts = e, this.ctx.data.serviceDescList = e.serviceDescList)
          },
          immediate: !0
        }
      },
      created() {
        Object(i.d)(this, {
          "sku:selected": e => {
            this.store.onSkuSelected(e)
          }
        }), Object(i.b)(this, {
          goodsActivity: e => this.store.fetchNearDateList(e)
        }), Object(i.e)(this, {
          setShowServiceBar: e => {
            this.showServiceBar = !!e
          },
          setServiceDescList: e => {
            this.ctx.data.serviceDescList = e, e.length > 0 && (this.goodsServiceOpts.serviceDescList = e)
          }
        })
      },
      methods: {
        onSkuShow() {
          this.ctx.event.emit("sku:show")
        }
      }
    };
    t.default = m.default.component(w)
  }
}));