var r = require("~/r");
r("DANr", Object.assign({}, require("~/v.js").modules, require("~/c.js").modules, {
  DANr: function(t, e, i) {
    i.r(e);
    var o = i("Fcif"),
      s = i("EqB2"),
      a = i("/XVY"),
      r = Object(a.a)({
        isShowAllGoodsTag: {
          default: !1
        },
        goodsListConfig: {
          default: () => ({})
        },
        type: {
          default: ""
        },
        tagsConfig: {
          default: () => ({})
        },
        tabs: {
          default: () => []
        },
        queryExtra: {
          default: () => ({})
        }
      }),
      c = i("pXyP"),
      n = i("Ix7h"),
      d = i("Tewj"),
      l = {
        mixins: [Object(s.a)({
          optDesc: r
        })],
        props: {
          kdtId: {
            type: Number
          },
          pageScrollKey: {
            type: String,
            default: "showcase-container:page-scroll"
          }
        },
        data: () => ({
          activeTab: 0,
          activedTabs: {
            tab0: !0
          },
          curId: "id_" + Math.round(1e3 * Math.random()),
          tabPid: Math.round(1e3 * Math.random()),
          zIndex: 1,
          stickyTop: 0,
          isSticky: !1
        }),
        computed: {
          goodsTagsTopStyle() {
            return "top: " + this.stickyTop + "px; margin-bottom: 7px; padding: 0 " + ("2" === this.opt.tagsConfig.navStyle ? "8px" : "0") + ";"
          },
          goodsExtra() {
            var {
              type: t,
              tabs: e,
              itemCardOpt: i,
              layoutOpt: s,
              itemIds: a = null,
              queryExtra: r,
              preLoadGoodsInfoOpt: c,
              skeletonOpt: n
            } = this.opt;
            return e.map((e, d) => ({
              queryExtra: Object(o.a)({}, r || {}, {
                type: t,
                alias: e.alias || "",
                pageSize: 12,
                isGlobalTag: +e.isGlobalTag || 0,
                isShowAll: e.isShowAll,
                goodsNumber: e.goodsNumber,
                activityPriceIndependent: 1,
                needOPriceAndTagsOpt: 1,
                supportCombo: 1
              }),
              itemCardOpt: i,
              layoutOpt: s,
              type: t,
              itemIds: a,
              preLoadGoodsInfoOpt: 0 === d ? c : null,
              skeletonOpt: n,
              isShowGoodsAddNumber: this._opt.isShowGoodsAddNumber
            }))
          },
          isShowGoodsAddNumber() {
            var t;
            return (null == (t = this._opt) ? void 0 : t.isShowGoodsAddNumber) || !1
          },
          curActiveTab: {
            get() {
              return this.activeTab
            },
            set(t) {
              this.activeTab = t
            }
          },
          tabInfo() {
            var {
              tagsConfig: t
            } = this.opt;
            return {
              tabType: "0" === t.navStyle ? "line" : "card",
              offsetTop: this.stickyTop
            }
          },
          showTabs() {
            return (this.opt.tabs || []).map((t, e) => {
              var i = Object(o.a)({}, t || {});
              return this.activedTabs["tab" + e] && (i.isVIf = !0), +e == +this.activeTab ? i.warpStyle = "display:block" : i.warpStyle = "display:none", i
            })
          }
        },
        watch: {
          curActiveTab(t) {
            this.activedTabs["tab" + t] || (this.activedTabs = Object(o.a)({}, this.activedTabs, {
              ["tab" + t]: !0
            }))
          }
        },
        mounted() {
          this.initSticky()
        },
        destroyed() {
          this.onPageScrollFn && d.default.off(this.pageScrollKey, this.onPageScrollFn)
        },
        methods: {
          handleBuyClick(t) {
            this.$emit("button-click", t)
          },
          handleItemClick(t) {
            var {
              link: e = {}
            } = t, {
              query: i = {},
              umpType: s,
              activityId: a
            } = e, r = {};
            s && a && (r = {
              activityId: a,
              umpType: s
            });
            var c = Object(o.a)({}, t, {
              link: Object(o.a)({}, e, {
                query: Object(o.a)({}, i, r)
              })
            });
            this.$emit("item-click", c)
          },
          onClickTab(t) {
            var {
              index: e
            } = t;
            this.curActiveTab = e
          },
          onPullDownRefresh() {
            this.curActiveTab = 0
          },
          initSticky() {
            var {
              tagsConfig: t
            } = this.opt;
            "1" === t.sticky && (this.isSticky = !1, c.a.setControlSub(this.handleStickyChange, this, "goodsTagsTop"), c.a.setCheckItem("goodsTagsTop", this.opt.zIndex || 110), this.onPageScrollFn = Object(n.a)(this.onPageScroll, 50), this.currentPageY = 0, this.$nextTick(() => {
              this.createSelectorQuery().select("#" + this.curId).boundingClientRect(t => {
                t && c.a.setWillStickyComponent({
                  name: "goodsTagsTop",
                  type: "fixed",
                  positionTop: t.top,
                  elementHeight: 44,
                  zIndex: this.zIndex || 110
                })
              }).exec()
            }), d.default.on(this.pageScrollKey, this.onPageScrollFn))
          },
          onPageScroll(t) {
            this.createSelectorQuery().select("#" + this.curId).boundingClientRect(e => {
              if (e) {
                var i = t.scrollTop === this.currentPageY ? "bottom" === this.lastDirection : t.scrollTop > this.currentPageY;
                this.lastDirection = i ? "bottom" : "up", this.currentPageY = t.scrollTop;
                var o = e.bottom,
                  s = c.a.getHasTop(),
                  a = !1;
                if (i ? (a = e.top < s && o > s, !this.isSticky && e.top < s && o - s < 45 && (a = !1)) : a = o - (this.isSticky ? 0 : 44) > s && e.top + (this.isSticky ? 44 : 0) < s, this.isSticky !== a) {
                  this.isSticky = a, this.zIndex = a ? 109 : 1, c.a.setItem("goodsTagsTop", 44, a);
                  var {
                    positionTop: r = 0
                  } = c.a.getItem("goodsTagsTop") || {};
                  this.isStartFixed = a, this.stickyTop = r
                }
              }
            }).exec()
          },
          handleStickyChange(t) {
            var {
              type: e,
              stickyTop: i = 0
            } = t;
            if ("stickyTop" === e) this.stickyTop = i;
            else if ("setItem" === e) {
              var {
                positionTop: o = 0
              } = c.a.getItem("goodsTagsTop") || {};
              this.stickyTop = o
            }
          },
          handleGoodsComponentLoaded() {
            this.componentLoaded || (this.$emit("component-loaded"), this.componentLoaded = !0)
          }
        },
        ud: !0
      },
      p = i("9ZMt");
    e.default = p.default.component(l)
  }
}));