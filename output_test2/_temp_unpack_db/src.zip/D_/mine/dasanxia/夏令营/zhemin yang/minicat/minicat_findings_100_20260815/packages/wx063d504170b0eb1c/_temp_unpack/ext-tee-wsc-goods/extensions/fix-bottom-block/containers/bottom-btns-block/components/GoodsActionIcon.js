var r = require("~/r");
r("1bZz", Object.assign({}, require("~/v.js").modules, {
  "1bZz": function(e, t, r) {
    r.r(t);
    var i = {
        name: "goods-action-icon",
        props: {
          btn: Object
        },
        methods: {
          handleClick(e) {
            this.$emit("btn-click", e)
          }
        },
        ud: !0
      },
      n = r("9ZMt");
    t.default = n.default.component(i)
  }
}));