var r = require("~/r");
r("FLTL", Object.assign({}, require("~/v.js").modules, {
  FLTL: function(t, o, r) {
    r.r(o);
    var e = {
        data() {
          var t;
          return {
            protocolIsCloudSlot: !(null == (t = this.ctx.data.cloudDesignConfig) || !t.replacedSlots.includes("account-protocol-content"))
          }
        }
      },
      c = r("9ZMt");
    o.default = c.default.component(e)
  }
}));