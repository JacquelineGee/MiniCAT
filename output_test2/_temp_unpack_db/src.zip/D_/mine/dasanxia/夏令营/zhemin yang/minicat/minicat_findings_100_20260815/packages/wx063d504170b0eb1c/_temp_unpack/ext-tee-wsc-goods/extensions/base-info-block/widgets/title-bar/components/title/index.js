var r = require("~/r");
r("+gBI", Object.assign({}, require("~/v.js").modules, {
  "+gBI": function(t, a, o) {
    o.r(a);
    var e = o("KEq0"),
      r = o.n(e),
      i = {
        props: {
          opt: Object,
          goodsHaitaoTax: String,
          isShowShareIcon: {
            type: Boolean,
            default: !0
          }
        },
        data: () => ({
          goodsRetailTag: "https://img01.yzcdn.cn/public_files/2019/08/19/a4db0d30f3814d2d2117c91e5a6e2958.png"
        }),
        computed: {
          shareIcon() {
            return this.opt.shareIcon
          },
          goodsTag() {
            return this.opt.isHaitao ? r()("public_files/51d3a73eafb988565c4ad04c76b99d15.png", "small") : ""
          },
          goodsHaitaoCountry() {
            var {
              haitao: t = {}
            } = this.opt.goodsActivity;
            return t && t.sourceCountryName || ""
          },
          isShowBrandTitle() {
            var {
              brandInfoModel: t
            } = this.opt;
            return t && t.authorizationMark
          },
          tagStyle() {
            return this.goodsTag ? "width: " + (this.opt.isHaitao ? 30 : 38) + "px;" : ""
          }
        },
        methods: {
          handleShareClick() {
            this.$emit("share")
          }
        },
        ud: !0
      },
      s = o("9ZMt");
    a.default = s.default.component(i)
  }
}));