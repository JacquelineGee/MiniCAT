var r = require("~/r");
r("HOEn", Object.assign({}, require("~/v.js").modules, require("~/c.js").modules, {
  HOEn: function(t, e, s) {
    s.r(e);
    var i = s("Fcif"),
      a = s("VmHG"),
      r = s("YeA1"),
      o = s("Shdd"),
      n = s("NHEX"),
      u = s.n(n),
      c = s("tS13"),
      d = s("US/N"),
      h = s("AGZf"),
      p = s("ONqW"),
      l = Object(p.a)();
    var m = s("zjWU"),
      g = s("KhBQ"),
      k = s("Tewj"),
      v = s("5Xe+"),
      b = s.n(v);

    function S(t) {
      var {
        cartText: e
      } = t, s = e ? "加入" + e : "";
      return {
        skuConfig: Object(i.a)({}, this.ctx.data.skuConfig, {
          addCartText: s
        })
      }
    }

    function f(t) {
      var {
        periodbuy: e,
        virtualTicket: s
      } = t, i = {
        periodBuy: e
      };
      return i.ecard = s ? {
        instructions: s.ecardInstructions,
        isPriceCalendar: 3 === s.validityType,
        itemPreOrderTimeStr: s.itemPreOrderTxt,
        itemPreOrderModel: s.itemPreOrderModel
      } : null, i
    }

    function y(t) {
      var {
        isFreeInterest: e,
        isInstallment: s
      } = t;
      if (s) return {
        installment: {
          isInstallment: s,
          isFreeInterest: e
        }
      }
    }

    function O(t) {
      var {
        subType: e,
        ladderList: s
      } = t || {}, i = "ladderGroupOn" === e;
      return {
        ladderGroupOn: i ? {
          isLadderGroupon: i,
          ladderList: s
        } : null
      }
    }

    function D(t) {
      var {
        coupon: e = {}
      } = t;
      return {
        couponTips: e
      }
    }
    var I = {
        state: {
          showEvent: null,
          hasSkuDirectOrderDone: !0,
          activityName: "",
          supportSkuDirectOrder: !1,
          goodsBaseInfo: {},
          buyConfig: {},
          goodsPriceInfo: {},
          goodsSkuData: {},
          goodsMetaInfo: {},
          shopBaseInfo: {},
          showSku: !1,
          showSelfSelectedCombo: !1,
          skuData: {},
          skuConfig: {},
          featureSwitch: {},
          shopMetaInfo: {},
          goodsActivity: {},
          pointsConfig: {},
          multiSkuDecision: {},
          themeVars: "",
          selectedSkuComb: null,
          kdtId: 0,
          explainVideoFullScreen: !1,
          hasOpenExplainVideo: !1,
          themeTag: {},
          pageVars: "",
          skuBtnClickStartTime: 0
        },
        getters: {
          skuGoods() {
            var t, e, {
              goods: s
            } = (t = this.goodsBaseInfo, e = u()(t, "pictures[0].url"), {
              goods: Object(i.a)({}, t, {
                picture: e
              })
            });
            return Object(i.a)({}, b()(s, ["isHaitao", "picture", "priceTags", "id", "alias", "title"]), b()(this.goodsMetaInfo, ["showStockLackReminder", "stockRemindStatus"]))
          }
        },
        getActions: function(t) {
          return {
            beforeShowSku(t) {
              var {
                event: e,
                sku: s
              } = t, {
                directAddCart: a,
                directOrder: r,
                submitAction: o
              } = e, {
                limit: n,
                collectionId: d,
                price: h,
                stockNum: p,
                pointsPrice: l
              } = s || {}, m = u()(n, "startSaleNum", 1), g = Object(i.a)({}, e, {
                skuData: {
                  messages: {},
                  cartMessages: {},
                  selectedNum: m,
                  goodsId: this.goodsBaseInfo.id,
                  selectedSkuComb: {
                    id: d,
                    price: h,
                    stockNum: p,
                    pointsPrice: l
                  }
                }
              });
              return a ? (this.doSkuSubmit(g), !1) : !(r && !this.supportSkuDirectOrder) || (this.doSkuSubmit(Object(i.a)({}, g, {
                submitAction: o || c.d.TRADE_SUBMIT
              })), !1)
            },
            saveBigButtons(t) {
              var e = t.filter(t => t.primary && (t.btnActive === c.a.OPEN_SKU || "groupOn" === t.activityName && t.btnActive === c.a.WX_SUBSCRIBE)).pop();
              this.primaryBtn = e, !e && t.length > 0 && (this.defaultPreviewBtn = [...t].pop())
            },
            showBizSku(e) {
              if (this.hasSkuDirectOrderDone = !0, e) {
                var {
                  activityName: s
                } = e, a = this.goodsSkuData[s], r = s !== this.activityName;
                if (this.beforeShowSku({
                    event: e,
                    sku: a
                  })) {
                  if (this.customLogger("addCart" === e.skuScene ? m.b.add_cart : m.b.buy_now, "sku弹出成功"), this.skuData = a, t.data.skuData = a, this.activityName = s, this.showEvent = Object(i.a)({}, this.showEvent, e, {
                      skuOptions: {
                        resetStepperOnHide: !1,
                        resetSku: r
                      }
                    }), !this.supportSkuDirectOrder) {
                    this.showSku = !0;
                    var {
                      comboType: o,
                      isCombo: n
                    } = this.goodsBaseInfo.comboMark || {};
                    return this.showSelfSelectedCombo = n && 1 === o, void m.a.start({
                      name: m.b.sku_popup_open
                    })
                  }
                  t.event.emit("skuOrder:show", this.showEvent)
                }
              }
            },
            doSkuSubmit(t) {
              var {
                showStockLackReminder: e,
                stockRemindStatus: s
              } = this.goodsMetaInfo, {
                isHqShopPreview: a = !1
              } = this.shopBaseInfo, {
                activityName: r,
                skuData: {
                  selectedSkuComb: o
                },
                extraParams: n = {}
              } = t, {
                supportSkuDirectOrder: u
              } = n, d = this.goodsSkuData[r] || {}, p = Object(i.a)({}, t, {
                activityInfo: d.activityInfo || {}
              }), {
                stockNum: l,
                skuId: g
              } = o || {}, v = !0;
              if (e && 0 === l) {
                var b = s[g];
                p.subscribeSceneV2 = c.e.STOCK_REMINDER, p.subscribeStatus = b, v = !b
              }
              var S = "addCart" === t.skuScene,
                f = S ? m.b.add_cart : m.b.buy_now;
              if (this.showSku && (f = S ? m.b.sku_cart : m.b.sku_buy, m.a.start({
                  name: f
                }), this.skuBtnClickStartTime || (this.skuBtnClickStartTime = Date.now())), a) {
                return this.customLogger(f, "总店预览商品不支持下单购买"), this.skuBtnClickStartTime = 0, h.a.loading({
                  message: "总店预览商品不支持下单购买",
                  duration: 2e3,
                  position: "bottom"
                })
              }
              this.submitAction(p), v && !u && "buy" !== p.skuScene && this.onHideSku(), S && k.default.trigger("addCartSuccess", "addCartSku", t.skuData)
            },
            resolveProcess(e) {
              var s = this;
              void 0 === e && (e = {});
              var {
                goods: a
              } = this.goodsSkuData, r = (e.selectedSkuComb || {}).price || (a || {}).price || 0, o = Object(i.a)({}, this.showEvent || {}, e, {
                priceBlock: {
                  price: r
                }
              }), n = JSON.stringify(e.pluginsResult || {});
              t.process.invokePipe("skuUpdate", o).then(function(t) {
                void 0 === t && (t = {});
                var e = JSON.stringify(t.pluginsResult || {});
                n !== e && s.onPluginsChange({
                  name: "skuPayWays",
                  priority: 60,
                  pluginsResult: t.pluginsResult
                })
              })
            },
            skuSelected(t) {
              this.onSkuSelected(Object(i.a)({}, t, {
                origin: "sku"
              }))
            },
            onSkuSelected(e) {
              this.selectedSkuComb = e.selectedSkuComb, t.event.emit("sku:selected", e), this.onEstimateUpdate(e), this.resolveProcess(e), this.emitTradePrefetch()
            },
            getUserStateSkuDirectOrder(t) {
              var {
                isSkuDirectOrder: e = !1
              } = t;
              this.showEvent = t, this.hasSkuDirectOrderDone && (e ? (this.hasSkuDirectOrderDone = !1, this.handleSkuOrderEvent(this.showEvent), this.customLogger("addCart" === t.skuScene ? m.b.add_cart : m.b.buy_now, "sku直接下单")) : (this.setSupportSkuDirectOrder(!1), this.showBizSku(this.showEvent)))
            },
            setSupportSkuDirectOrder(e) {
              this.supportSkuDirectOrder = e, t.data.supportSkuDirectOrder = e
            },
            handleSkuOrderEvent(e) {
              var {
                alias: s,
                id: i,
                title: a
              } = this.goodsBaseInfo;
              Object(d.default)({
                path: "/wscgoods/tee-app/sku-direct-order.json",
                data: {
                  alias: s
                },
                withCredentials: !0
              }).then(s => {
                var {
                  userStateSupportSkuDirectOrder: r = !1
                } = s, o = !Object(g.c)() && r;
                this.setSupportSkuDirectOrder(o), o && (t.data.ecard = null, function(t, e) {
                  l.log({
                    et: "view",
                    ei: "sku_creat_order_component_view",
                    en: "商详sku下单组件曝光",
                    params: {
                      goods_id: t,
                      goods_name: e,
                      component: "sku_creat_order_component"
                    }
                  })
                }(i, a)), this.showBizSku(e)
              }).catch(() => {
                this.setSupportSkuDirectOrder(!1), this.showBizSku(e)
              })
            },
            showNearSku() {
              var {
                activityName: e,
                bigButtons: s
              } = t.data, a = this.showEvent || this.primaryBtn;
              if (e && (a = {
                  activityName: e
                }), !a) {
                a = Object(i.a)({}, this.defaultPreviewBtn || {}, {
                  name: "preview-buy",
                  activityName: "goods",
                  btnActive: c.a.OPEN_SKU,
                  skuScene: c.c.PREVIEW_SKU
                });
                var r = "";
                Array.isArray(a.main) && a.main.length > 0 && (r = a.main[0].text || ""), t.data.skuConfig = Object(i.a)({}, t.data.skuConfig, {
                  previewText: r
                })
              }
              s[0].skuScene === c.c.ADD_CART && (s[1] || {}).skuScene === c.c.BUY && (a.skuScene = c.c.SEL_SKU), this.showBizSku(a)
            },
            onHideSku() {
              this.showSku = !1
            },
            onNumChange(e) {
              t.event.emit("sku:num-change", e), this.skuNum = e, this.emitTradePrefetch(), l.log({
                et: "click",
                ei: "click_sku_number",
                en: "点击sku弹层数量控件"
              })
            },
            onPreview(e) {
              l.log({
                et: "click",
                ei: "click_sku_pic",
                en: "点击sku弹层中图片"
              }), t.event.emit("sku:preview-click", Object(i.a)({}, e, {
                uiType: "SKU"
              }))
            },
            onSkuOpened() {
              this.customLogger(m.b.sku_popup_open, "sku弹出成功");
              try {
                t.hummer.mark.end("goods-detail-sku-popup")
              } catch (t) {}
            },
            customLogger(t, e, s) {
              void 0 === s && (s = "finish"), m.a.end({
                name: t,
                type: s,
                level: "finish" === s ? "info" : "error",
                extra: {
                  message: e
                }
              })
            }
          }
        }
      },
      P = {
        getActions: function(t) {
          return {
            submitAction(e) {
              var {
                link: s,
                submitAction: i,
                subscribeSceneV2: a
              } = e, {
                pageName: o,
                query: n = {},
                type: u = "navigate"
              } = s || {};
              switch (i) {
                case c.d.JUMP_LINK:
                  Object(r.a)().dmc[u](o, n);
                  break;
                case c.d.SUBSCRIBE:
                  a && t.event.emit("subscribe:show", e);
                  break;
                case c.d.TRADE_SUBMIT:
                  if (a) {
                    t.event.emit("subscribe:show", e), this.skuBtnClickStartTime = 0;
                    break
                  }
                  this.startTradeSubmit(e);
                  break;
                case c.d.SHARE:
                case c.d.BREAK:
                  break;
                default:
                  this.resolveUmpCustomEvent({
                    type: i,
                    data: e
                  }), t.event.emit("custom:event", {
                    type: i,
                    data: e
                  });
              }
            }
          }
        }
      },
      C = s("9ZMt"),
      w = s("sXPE"),
      T = s("nTO+");
    var B = s("pn6R"),
      j = s.n(B),
      E = s("lgMb"),
      _ = s("WQRT");

    function x(t) {
      return Object(d.requestV2)({
        method: "POST",
        path: "/wsctrade/order/goodsBook.json",
        data: Object(_.b)(t)
      }).catch(function(t) {
        void 0 === t && (t = {}), Object(E.b)(t, {
          message: "下单失败，请稍后重试"
        })
      })
    }
    var A = s("f6Yk"),
      N = s("+I+c"),
      R = s("aOlM"),
      G = ["skuData"],
      U = Object(R.a)(t => {
        t.tradePrefetchHandler()
      }, 200),
      V = "pedding",
      F = "fulfilled",
      K = "rejected";
    var L = C.default.getApp(),
      M = {
        state: {
          skuScene: "",
          bookKey: 0,
          postData: {},
          skuDirectOrderScene: "",
          guarantee: {},
          isLoading: !1,
          goodsCombineInfo: {},
          tradePrefetchCahceData: {}
        },
        getActions: function(t) {
          return Object(i.a)({}, function(t) {
            return {
              setTradePrefetchRef(t) {
                this.prefetchRef = t
              },
              emitTradePrefetch() {
                var e;
                1 == +(null == (e = t.data.pageSwitch) ? void 0 : e.prefetch_bookKey_switch) && (this.skuDirectOrderScene || t.data.supportSkuDirectOrder || (this.resetTradePrefetchData(), U(this), clearTimeout(this.tradePrefetchTimer), this.tradePrefetchTimer = setTimeout(() => {
                  this.resetTradePrefetchData()
                }, 18e3)))
              },
              tradePrefetchHandler() {
                this.prefetchRef && this.prefetchRef.validate({
                  noToast: !0
                }).then(t => {
                  var {
                    skuData: e
                  } = t, s = Object(N.a)(t, G), a = this.goodsSkuData[this.activityName] || {}, {
                    activityInfo: r = {}
                  } = a;
                  this.startTradeSubmit(Object(i.a)({
                    skuData: e
                  }, s, {
                    activityInfo: r,
                    skuScene: c.c.BUY
                  }), !0)
                }).catch(() => {})
              },
              resetTradePrefetchData() {
                this.tradePrefetchCahceData = {}
              }
            }
          }(t), {
            setOrderKeepData(e) {
              var {
                displayData: s = {},
                orderData: i = {}
              } = e || {}, {
                bookKey: a
              } = i;
              a === this.bookKey && (t.data.displayData = s, t.data.orderData = i, t.event.emit("ORDER_KEEP:open"))
            },
            bindOrderKeepHandler() {
              L.on("order:leave:stop", this.setOrderKeepData)
            },
            offOrderKeepHandler() {
              L.off("order:leave:stop", this.setOrderKeepData)
            },
            setPostDataProcess: e => t.process.invokePipe("setTradePostData", e),
            startTradeSubmit(e, s) {
              var a = this,
                {
                  skuScene: r,
                  skuData: n,
                  pluginsResult: d,
                  activityInfo: h,
                  extraParams: p = {},
                  activityName: g = "goods"
                } = e;
              this.currentActivityName = g, this.isPrefetchProcess = s;
              var {
                skuDirectOrderScene: k,
                skuNameForLog: v
              } = p;
              this.skuDirectOrderScene = k;
              var S = t.logger.getLogParams(),
                f = A.a && Object(A.a)() || {},
                {
                  fromSource: y
                } = t.env.getQuery(),
                O = t.data.explainVideoFullScreen || !1,
                D = !O && t.data.hasOpenExplainVideo || !1;
              this.skuScene = r;
              var I, {
                isCombo: P = !1,
                comboGroupModels: B = [],
                comboType: E = 0
              } = this.goodsCombineInfo || {};
              this.isBuyScene = r === c.c.BUY, this.loggerKeyName = this.isBuyScene ? m.b.buy_now : m.b.add_cart, this.showSku && (this.loggerKeyName = this.isBuyScene ? m.b.sku_buy : m.b.sku_cart);
              try {
                this.postData = (t => {
                  var {
                    skuData: e,
                    goods: s,
                    shop: a,
                    activityInfo: r,
                    pluginsResult: o = {},
                    goodsGrowthParams: n,
                    logParams: c,
                    pageQuery: d,
                    platform: h,
                    bosWorkFlow: p,
                    isFromItemDetail: l,
                    fromSource: m,
                    combineGoodsData: g,
                    isFromExplainVideo: k,
                    hasOpenExplainVideo: v
                  } = t, b = u()(c, "context.dc_ps", ""), S = u()(c, "context.click_id", ""), f = Object(i.a)({}, c.context, c.plat, {
                    uuid: c.user.uuid || "",
                    userId: c.user.li || "",
                    platform: h
                  }, d), {
                    scene: y
                  } = C.default.getAppOptions();
                  y && (f.scene = y);
                  var O = {
                      dcPs: b,
                      biz_trace_point_ext: JSON.stringify(Object(i.a)({}, n, f))
                    },
                    D = {
                      bosWorkFlow: p,
                      isFromItemDetail: l,
                      source: "goods_detail"
                    };
                  S && (O.gdtClickId = S), m && (O.from_source = m);
                  var {
                    activityType: I
                  } = r || {}, {
                    selectedSkuComb: P = {}
                  } = e || {};
                  return I === w.b.POINTS && (D.isPoints = 1, O.points_price = P.pointsPrice), (k || v) && (O.extra = Object(i.a)({}, O.extra || {}, {
                    IS_FROM_EXPLAIN_VIDEO: k,
                    HAS_OPEN_EXPLAIN_VIDEO: v
                  })), Object(T.a)({
                    skuData: e,
                    goods: s,
                    shop: a,
                    pluginsResult: o,
                    activityInfo: r,
                    commonExtra: D,
                    goodsExtra: O,
                    combineGoodsData: g
                  })
                })(Object(i.a)({
                  skuData: j()(n),
                  pluginsResult: d,
                  activityInfo: h
                }, (I = t.data, {
                  goods: Object(i.a)({}, b()(I.goodsBaseInfo, ["id", "supportUnconditionalReturn"]), {
                    postage: I.distribution.postage
                  }),
                  shop: {
                    multistore: I.multistore,
                    kdtId: I.shopBaseInfo.kdtId
                  }
                }), {
                  goodsGrowthParams: f,
                  logParams: S,
                  pageQuery: t.env.getQuery(),
                  platform: C.default.getEnv(),
                  bosWorkFlow: this.buyConfig.bosWorkFlow,
                  isFromItemDetail: this.supportSkuDirectOrder,
                  fromSource: y,
                  combineGoodsData: {
                    flag: r,
                    isCombo: P,
                    comboType: E,
                    comboGroupModels: e.isCombo ? e.groupList : B
                  },
                  isFromExplainVideo: O,
                  hasOpenExplainVideo: D
                }))
              } catch (t) {
                this.handleCommonError(t, "[商详页下单-startTradeSubmit.formatGoodsPostData]")
              }
              Object(o.a)(this, [this.setUmpTradeData, this.setPostDataProcess], this.postData).then(t => {
                t && (this.postData = t, this.doCheckBeforeSubmit())
              }).catch(function(t) {
                void 0 === t && (t = {}), a.submitlogger(t.message || "商品数据处理错误", "error")
              }), this.isPrefetchProcess || function(t, e) {
                var s = {
                  [c.c.BUY]: {
                    type: "buy",
                    name: "立即购买"
                  },
                  [c.c.ADD_CART]: {
                    type: "add_cart",
                    name: "添加购物车"
                  }
                } [t];
                if (s) {
                  var {
                    goods: i,
                    guarantee: a,
                    skuInfo: r,
                    shopConfig: o
                  } = e, n = {
                    et: "click",
                    ei: s.type,
                    en: s.name,
                    params: {
                      sku_id: r.id,
                      sku_name: r.name,
                      num: r.num,
                      goods_alias: i.alias,
                      goods_id: i.id,
                      goods_name: i.title,
                      group_ids: [],
                      picture_url: i.picture,
                      price: i.minPrice / 100,
                      show_price: i.price,
                      guarantee_on: a.yzGuarantee,
                      beauty_rights: a.hasBeautyRights,
                      eat_rights: a.hasEatRights,
                      freight_insurance: 1 === Number(o.supportFreightInsurance),
                      freight_insurance_pro: 2 === Number(o.supportFreightInsurance)
                    }
                  };
                  l.log(n)
                }
              }(r, {
                goods: Object(i.a)({}, this.goodsBaseInfo, this.goodsPriceInfo),
                skuInfo: {
                  id: this.postData.skuId,
                  name: v || [],
                  num: this.postData.num
                },
                guarantee: this.guarantee,
                shopConfig: t.data.shopConfig
              })
            },
            saveGuaranteeData(t) {
              this.guarantee = t
            },
            doCheckBeforeSubmit() {
              !this.isLoading || this.isPrefetchProcess ? this.isBuyScene && 1 === this.buyConfig.buyLimitType ? this.isPrefetchProcess || (this.submitlogger("需要先关注店铺公众号"), this.skuBtnClickStartTime = 0, t.event.emit("follow:show", {
                extraData: {
                  bizCode: 7,
                  activityKey: this.goodsBaseInfo.alias
                }
              })) : this.submitData() : this.supportSkuDirectOrder || Object(h.a)("正在前往下单，请稍候")
            },
            submitData() {
              if (this.isPrefetchProcess || (this.isLoading = !0), this.isBuyScene) {
                var {
                  cartMessages: e,
                  num: s,
                  skuId: i
                } = this.postData || {}, a = {
                  messages: e,
                  num: s,
                  skuId: i,
                  goodsAlias: this.goodsBaseInfo.alias,
                  activityName: this.currentActivityName
                };
                t.process.invokePipe("beforeBuy", a).then(e => t.cloud.invoke("beforeBuy", b()(a, ["skuId", "num", "messages"])).then(() => {
                  var {
                    umpExt: t
                  } = e || {};
                  t && (this.postData.cloudExtension = {
                    umpExt: t
                  }), this.buy()
                }, this.handleBeforeBuyError)).catch(this.handleBeforeBuyError)
              } else this.addCart()
            },
            buyHandlerCache(t) {
              var e, s, {
                doPromise: i,
                response: a
              } = this.tradePrefetchCahceData || {};
              return i ? (e = i, s = {}, Promise.race([e, s]).then(t => t === s ? V : F).catch(() => K)).then(t => t === F ? a : i).catch(() => x(t)) : x(t)
            },
            prefetchBookKey() {
              var {
                postData: t
              } = this, e = x(t);
              this.tradePrefetchCahceData.doPromise = e, e.then(t => {
                this.tradePrefetchCahceData.response = t
              })
            },
            buy() {
              if (this.isPrefetchProcess) this.prefetchBookKey();
              else {
                var {
                  postData: e
                } = this;
                t.data.distribution && t.data.distribution.supportSelfFetch && s.e("packages/async-main/chunk").then(s.bind(null, "7y9c")).then(t => {
                  var {
                    fetchDefaultSelffetchPoint: s,
                    formatGoodsParams: i
                  } = t;
                  s(i(e))
                }), this.buyHandlerCache(e).then(s => {
                  if (!s) throw new Error("获取bookkey接口失败");
                  this.afterSubmitData({
                    res: s
                  }), this.bookKey = s.bookKey;
                  var a = u()(e, "common.orderFrom"),
                    r = function(t) {
                      var e = t.buyUrl;
                      return "weapp" === C.default.getEnv() && (e = "/packages/order/index?bookKey=" + t.bookKey, t.orderFrom && (e += "&orderFrom=" + t.orderFrom)), e
                    }(Object(i.a)({}, s, {
                      kdtId: e.kdtId,
                      orderFrom: a
                    })),
                    o = {
                      bookKey: s.bookKey,
                      buyUrl: r,
                      goodsAlias: this.goodsBaseInfo.alias,
                      messages: e.cartMessages,
                      num: e.num,
                      skuId: e.skuId,
                      activityName: this.currentActivityName
                    };
                  t.process.invokePipe("afterBuy", o).then(e => {
                    t.cloud.invoke("afterBuy", o).then(() => {
                      var {
                        extOrderQuery: r
                      } = e || {}, o = r ? {
                        ext_query: JSON.stringify(r)
                      } : {};
                      this.supportSkuDirectOrder ? t.event.emit("skuBookkey:finish", {
                        bookKey: s.bookKey,
                        skuDirectOrderScene: this.skuDirectOrderScene
                      }) : (t.process.invoke("navigateToTradeBuy", {
                        navigateParams: Object(i.a)({}, o, {
                          bookKey: s.bookKey,
                          orderFrom: a,
                          yzGuarantee: t.data.yzGuarantee,
                          freightInsurance: t.data.shopConfig.supportFreightInsurance
                        })
                      }), this.resetTradePrefetchData(), this.submitHummerLogger("goods-buy-now"), this.submitlogger("跳转下单页成功"))
                    }).catch(this.handleBuyError)
                  }).catch(this.handleBuyError)
                }).catch(this.handleBuyError)
              }
            },
            addCart() {
              var {
                num: e,
                skuId: s,
                cartMessages: a
              } = this.postData, r = {
                messages: a,
                num: e,
                skuId: s
              };
              t.process.invokePipe("beforeCartSubmit", Object(i.a)({}, r, {
                goodsAlias: this.goodsBaseInfo.alias
              })).then(e => {
                t.cloud.invoke("beforeCartAdd", r).then(() => {
                  var t;
                  e && Object.assign(this.postData.commonExtra, Object(i.a)({}, [e])), (t = this.postData, Object(d.requestV2)({
                    path: "/wscshop/trade/cart/goods.json",
                    method: "POST",
                    header: {
                      "content-type": "application/x-www-form-urlencoded"
                    },
                    data: Object(_.a)(t)
                  }).then(() => (Object(h.a)("已成功添加到购物车"), {
                    success: !0
                  })).catch(function(t) {
                    return void 0 === t && (t = {}), Object(E.b)(t, {
                      message: "添加购物车失败，请稍后重试"
                    }), {
                      success: !1,
                      err: t
                    }
                  })).then(t => {
                    this.afterSubmitData({
                      res: t,
                      options: {
                        skuId: s
                      }
                    }), getApp().trigger("component:sku:cart");
                    var e = {
                      type: "finish",
                      message: "加入购物车成功"
                    };
                    if (!t.success) {
                      var {
                        err: i = {}
                      } = t;
                      (i.code || i.data && i.data.code) && (e.type = "error"), e.message = "加入购物车失败 " + JSON.stringify(i), this.skuBtnClickStartTime = 0
                    }
                    this.submitHummerLogger("goods-add-cart"), this.submitlogger(e.message, e.type)
                  }).catch(t => this.handleCartError(t, "addCard"))
                }).catch(t => this.handleCartError(t, "addCard"))
              }).catch(t => this.handleCartError(t, "beforeCartSubmit"))
            },
            afterSubmitData(e) {
              var {
                res: s,
                options: a
              } = e;
              this.isLoading = !1;
              var {
                skuScene: r
              } = this;
              t.event.emit("trade:finish", Object(i.a)({}, s, {
                skuScene: r
              }, a)), this.umpTradeFinish()
            },
            handleBeforeBuyError(t) {
              this.handleCommonError(t, "[商详页下单-beforeBuy]")
            },
            handleCartError(t, e) {
              this.handleCommonError(t, "[商详页加购-" + e + "]")
            },
            handleBuyError(e) {
              this.handleCommonError(e, "[商详页下单-buy]"), this.supportSkuDirectOrder && t.event.emit("skuBookkey:finish", null)
            },
            handleCommonError(e, s) {
              void 0 === e && (e = {}), s && (e.message = s + " " + e.message), this.isLoading = !1, t.hummer && t.hummer.capture(e), this.submitlogger(e.message, "error")
            },
            submitlogger(t, e) {
              void 0 === e && (e = "finish"), "error" === e && (this.skuBtnClickStartTime = 0), this.customLogger(this.loggerKeyName, t, e)
            },
            submitHummerLogger(e) {
              try {
                this.skuBtnClickStartTime && (t.hummer.mark.start(e, this.skuBtnClickStartTime), t.hummer.mark.end(e), this.skuBtnClickStartTime = 0)
              } catch (t) {}
            }
          })
        }
      },
      H = s("YehF"),
      q = s("+66q"),
      W = new(s("Hpq+").a),
      z = {
        state: {
          extraData: {},
          skuNum: 1,
          periodBuy: null,
          couponTips: {},
          ladderGroupOn: null,
          ecard: null,
          showVirtualTicketIntro: !0,
          pluginNames: [],
          pluginsGoods: ""
        },
        getters: {
          selectedId() {
            var {
              skuId: t,
              id: e
            } = this.selectedSkuComb || {};
            return e || t || (this.goodsSkuData.goods || {}).skuId || 0
          },
          goodsAttributesOpt() {
            var t = (this.goodsMetaInfo || {}).supportItemProps || !0,
              {
                itemSalePropList: e,
                id: s
              } = this.goodsBaseInfo,
              i = t ? e : null;
            return {
              show: !!(i || []).length,
              kdtId: this.shopBaseInfo.kdtId,
              goodsId: s,
              goodsAttributes: i,
              skuId: this.selectedId,
              price: (this.selectedSkuComb || {}).price || 0,
              activityName: (this.showEvent || {}).activityName,
              activityInfo: (this.skuData || {}).activityInfo
            }
          },
          periodBuyOpt() {
            var t, {
              skuId: e,
              id: s
            } = this.selectedSkuComb || {};
            return {
              show: !!this.periodBuy,
              skuNum: this.skuNum,
              periodBuy: this.periodBuy,
              selectedId: e || s || 0,
              tags: null == (t = this.skuData) ? void 0 : t.tags
            }
          },
          ecardOpt() {
            var {
              id: t,
              alias: e
            } = this.goodsBaseInfo, {
              noneSku: s,
              activityInfo: i,
              price: a,
              oldPrice: r
            } = this.skuData || {}, {
              price: o = a,
              oldPrice: n = r
            } = this.selectedSkuComb || {};
            return {
              show: !!this.ecard,
              ecard: this.ecard,
              goodsId: t,
              alias: e,
              activityInfo: i,
              noneSku: s,
              skuId: this.selectedId,
              kdtId: this.shopBaseInfo.kdtId,
              price: o,
              oldPrice: n,
              selectedSkuComb: this.selectedSkuComb,
              showInstructions: this.showVirtualTicketIntro
            }
          },
          ladderGrouponOpt() {
            var {
              activityName: t
            } = this.showEvent || {}, {
              noneSku: e
            } = this.skuData || {};
            return {
              show: !!this.ladderGroupOn,
              activityName: t,
              ladderGroupOn: this.ladderGroupOn,
              noneSku: e,
              skuId: this.selectedId,
              selectedSkuComb: this.selectedSkuComb
            }
          },
          sellingPointOpt() {
            var t = Object(H.f)(this.shopMetaInfo) || Object(H.g)(this.shopMetaInfo);
            return {
              show: this.featureSwitch.showGoodsSellingPoint && !t,
              alias: this.goodsBaseInfo.alias
            }
          },
          couponTipsOpt() {
            var {
              type: t,
              skuPrices: e,
              havingInSourcingCouponNum: s
            } = this.currentActivity, i = t === q.k.INSOURCING_FISSION, {
              couponSkuPrices: a
            } = this.couponTips || {};
            return {
              show: (a || "").length || i,
              couponTips: this.couponTips,
              noneSku: (this.goodsSkuData.goods || {}).noneSku,
              skuId: (this.selectedSkuComb || {}).skuId || 0,
              skuNum: this.skuNum,
              currentActivity: {
                type: t,
                skuPrices: e,
                havingInSourcingCouponNum: s
              }
            }
          }
        },
        getActions: t => ({
          onCouponVisible(e) {
            t.data.showCouponTips = e
          },
          onPluginsChange(t) {
            this.extraData = W.update(t)
          },
          hideVirtualTicketIntro() {
            this.showVirtualTicketIntro = !1
          },
          resetPlugins(t) {
            this.pluginsGoods !== t && W.reset(), this.pluginsGoods = t
          }
        })
      },
      Q = s("lCVF"),
      J = s.n(Q),
      X = s("xers"),
      Y = s.n(X),
      $ = s("Nvad");
    var Z = ["customerDiscount", "timelimitedDiscount", "meetReduce", "bale", "secondHalfDiscount", "carriageDiscount", "cashBack", "cashbackPro", "customerPostageFree"],
      tt = {
        state: {
          showQi: !1,
          isEqualPriceSku: !1,
          estimatePriceData: {},
          userGoodsStateParams: {},
          marketing: {},
          isCoupon: !1
        },
        getters: {
          estimatePriceOpt() {
            var {
              num: t,
              estimatedPrice: e,
              showQi: s
            } = this.estimatePriceData;
            return {
              show: t > 1,
              num: t,
              estimatedPrice: e,
              showQi: s
            }
          }
        },
        getActions: t => ({
          estimateActivity() {
            if (void 0 !== this.activitySupport) return this.activitySupport;
            var {
              activities: t = []
            } = this.marketing || {}, e = !t.some(t => Z.indexOf(t.type) < 0);
            return this.activitySupport = e && !this.isCoupon, this.activitySupport
          },
          updateEstimateTags() {
            var t, e, {
                tag: s,
                num: i
              } = this.estimatePriceData,
              a = "estimatePrice";
            if (1 !== i) {
              var r = (null == (t = this.extraData) || null == (e = t.view) ? void 0 : e.tags) || [];
              if (r.length) {
                var o = r.filter(t => t.tagType !== a),
                  n = o.length ? o : null;
                this.onPluginsChange({
                  name: a,
                  priority: 10,
                  view: {
                    tags: n
                  }
                })
              }
            } else {
              var {
                tags: u = []
              } = this.goodsSkuData.goods || {}, c = "fullPresale" === (u[0] || {}).type ? [u[0] || "", s] : [s];
              this.onPluginsChange({
                name: a,
                priority: 10,
                view: {
                  tags: c
                }
              })
            }
          },
          onEstimateUpdate(t) {
            var {
              selectedSkuComb: e = null
            } = t, s = {};
            if (e) {
              var {
                skuId: i,
                oldPrice: a,
                price: r
              } = e;
              s.estimatedPriceSkuId = i, s.priceWithProperties = a || r
            }
            this.getEstimateData(s)
          },
          getEstimateData(e) {
            return this.estimateActivity() ? (s = Object(i.a)({}, this.userGoodsStateParams, e), Object(d.default)({
              path: "/wscgoods/activity-api/goods-estimated-price.json",
              data: s,
              method: "POST",
              withCredentials: !0
            })).then(e => {
              var s;
              if (Y()(e)) return t.data.estimatePriceData = {}, this.estimatePriceData = {}, void this.updateEstimateTags();
              var {
                timeLimitDiscountPromotion: a,
                customDiscountPromotion: r,
                buttonUmpText: o
              } = e || {}, n = a ? J()(a.timeLimitDiscountPrice) : "", u = r ? J()(r.customDiscountPrice) : "", {
                minPrice: c,
                maxPrice: d
              } = this.goodsSkuData.goods || {}, h = c !== d && o.umpTag.indexOf("起") > -1, p = h ? o.umpTag : o.umpTag.replace("起", ""), {
                umpType: l = ""
              } = e, m = ((t, e) => {
                var s = t.split("¥"),
                  i = s[0] + "¥",
                  [a] = s[1].split("起");
                return {
                  containerStyle: "display: inline-flex; align-items: center; height: 20px; padding: 0 var(--theme-goods-price-tag-padding, 6px); color: var(--ump-main-text, #fff); background: var(--ump-main-bg, #323233); border-radius:1rem;",
                  preText: i,
                  preStyle: "font-size: 12px;",
                  text: a,
                  textStyle: "font-size:16px;font-weight:var(--theme-common-price-font-weight, 600px);padding:0;position: relative;font-family: var(--price-font-family)",
                  sufText: t.indexOf("起") > -1 ? "起" : "",
                  sufStyle: "font-size: 12px; margin-left: 2px;",
                  type: e,
                  tagType: "estimatePrice",
                  umpType: "coupon"
                }
              })(p, l), g = Object(i.a)({}, e, {
                estimatedPrice: Object($.b)(J()(e.estimatedPrice)),
                totalOriginalPrice: J()(e.totalOriginalPrice),
                promotionDetailList: (null == e || null == (s = e.promotionDetailList) ? void 0 : s.map(t => Object(i.a)({}, t, {
                  totalDecreaseAmount: J()(t.totalDecreaseAmount),
                  promotionPrice: J()(t.promotionPrice)
                }))) || [],
                totalPrice: n || u,
                buttonUmpText: Object(i.a)({}, o, {
                  umpTag: p
                }),
                tag: m,
                showQi: h
              });
              t.data.estimatePriceData = g, this.estimatePriceData = g, this.updateEstimateTags()
            }).catch(() => {
              t.data.estimatePriceData = {}, this.estimatePriceData = {}
            }) : (t.data.estimatePriceData = {}, Promise.resolve());
            var s
          },
          onBtnClick(e) {
            var s, {
                estimatePriceData: i
              } = t.data,
              {
                isCoupon: a
              } = this;
            if (!Y()(i)) {
              var r = 1 === (null == (s = e.main) ? void 0 : s.length),
                {
                  umpTag: o = ""
                } = i.buttonUmpText || {},
                n = r ? 2 : a ? 1 : 0,
                u = o.indexOf("起") > -1;
              Object(p.a)().log({
                et: "click",
                ei: "click_buy",
                en: "点击立即购买",
                params: {
                  isshow_price: n,
                  isshow_qi: u ? 0 : 1,
                  component: "estimated_price"
                }
              })
            }
          }
        })
      },
      et = {
        getters: {
          couponIntroOpt() {
            var t = u()(this.goodsActivity, "virtualCoupon.skuExtraModels", []),
              e = !!t.length,
              s = null;
            return e && (s = t.find(t => t.skuId === this.selectedId)), {
              show: e && !!s,
              detail: s
            }
          }
        }
      },
      st = s("w2Y9"),
      it = s.n(st);
    var at = 1,
      rt = 2,
      ot = (t, e) => Object(r.a)().dmc.navigate(t, e),
      nt = t => {
        var {
          data: {
            currentActivity: e,
            kdtId: s
          },
          customOptions: i
        } = t, {
          ctx: a
        } = i, {
          activityId: r
        } = e;
        return r ? nt.isAjaxing ? Object(h.a)("正在砍价中") : (nt.isAjaxing = !0, h.a.loading({
          message: "正在砍价...",
          forbidClick: !0
        }), void Object(d.default)({
          method: "POST",
          path: it.a.add("/wscump/bargain-purchase/create.json", {
            kdtId: s,
            activityId: r
          }),
          data: {
            kdtId: s,
            activityId: r
          },
          withCredentials: !0
        }).then(t => {
          h.a.clear(), nt.isAjaxing = !1, ot("BargainPurchase", {
            sponsorId: t.sponsorId,
            umpActivityId: r,
            kdtId: s,
            isFirstCut: 1
          })
        }).catch(t => {
          if (nt.isAjaxing = !1, 160540352 === t.code) return a.event.emit("follow:show", {
            extraData: {
              bizCode: 1,
              bizSubCode: 0,
              activityKey: r
            }
          }), void h.a.clear();
          a.event.emit("helpcutErr:show", {
            errMsg: t.msg || "发起砍价失败，请重试"
          })
        })) : Object(h.a)("无法砍价，请联系商家处理")
      },
      ut = {
        [q.j.UMP_GO_2_DETAIL]: t => {
          var {
            data: e
          } = t, {
            alias: s
          } = e;
          ot("GoodsDetail", {
            alias: s
          })
        },
        [q.j.UMP_SHOW_QUESTION]: t => {
          var {
            customOptions: e,
            data: s
          } = t, {
            questionId: i
          } = s;
          e.ctx.event.emit("question:show", {
            questionId: i
          })
        },
        [q.j.ORDER_SECKILL]: t => {
          var {
            customOptions: e
          } = t, {
            currentActivity: s,
            kdtId: a,
            alias: r,
            query: o,
            ctx: n
          } = e, {
            useFollow: u = !1,
            useQuestion: c = !1,
            useDirect: h = !1,
            questionId: p = "",
            activityId: l = 0,
            followWays: m = []
          } = s, g = "weapp" === C.default.getEnv(), k = () => {
            var t;
            (t = {
              kdtId: a,
              seckillId: l,
              pushWay: g ? 2 : 1
            }, Object(d.requestV2)({
              path: "wscgoods/seckill-api/seckill-question-remind.json",
              data: t,
              method: "POST",
              withCredentials: !0
            })).then(() => {
              ot("GoodsDetail", Object(i.a)({
                alias: r
              }, o))
            }).catch(t => Object(E.b)(t, {
              message: "秒杀预约失败，请稍后重试"
            }))
          };
          h || u && g && !m.includes(rt) || u && !g && !m.includes(at) ? k() : c ? n.event.emit("question:show", {
            questionId: p
          }) : u && k()
        },
        [q.j.UMP_GO_2_WEBVIEW]: t => {
          var {
            data: e
          } = t, {
            url: s,
            link: i
          } = e;
          if (i) {
            var {
              pageName: a,
              query: r
            } = i;
            ot(a, r)
          } else ot(s)
        },
        [q.j.START_CUT]: nt,
        [q.j.UMP_SHOW_SHARE]: t => {
          var {
            customOptions: e
          } = t;
          e.ctx.event.emit("share:show")
        },
        [q.j.SHOW_IN_SOURCING_FISSION_COUPON]: t => {
          var {
            customOptions: e
          } = t;
          e.ctx.event.emit("inSourcingFissionCoupon:show")
        },
        [q.j.PRODUCT_LAUNCH_RESERVATION]: t => {
          var {
            customOptions: e,
            data: s
          } = t, {
            ctx: a,
            goodsId: r
          } = e;
          a.event.emit("subscribe:show", Object(i.a)({}, s, {
            btnActive: c.a.WX_SUBSCRIBE,
            subscribeSceneV2: c.e.SALE_REMINDER,
            itemId: r
          }))
        }
      };
    var ct = s("3t/z"),
      dt = s("X9+V"),
      ht = [I, P, M, {
        state: {
          currentActivity: {},
          umpActivity: {},
          query: {}
        },
        getActions: function(t) {
          return {
            resolveUmpCustomEvent(e) {
              ! function(t) {
                var {
                  type: e,
                  data: s,
                  customOptions: i
                } = t, a = ut[e];
                a && a({
                  type: e,
                  data: s,
                  customOptions: i
                })
              }(Object(i.a)({}, e, {
                customOptions: {
                  ctx: t,
                  alias: this.goodsBaseInfo.alias,
                  currentActivity: this.currentActivity,
                  query: this.query,
                  kdtId: this.shopBaseInfo.kdtId,
                  goodsId: this.goodsBaseInfo.id
                }
              }))
            },
            umpTradeFinish() {
              var {
                type: e
              } = this.query;
              "gift" === e && t.dmc.navigate("GiftWeapp")
            },
            setUmpTradeData(e) {
              try {
                var {
                  activityType: s = 0
                } = e, i = 99999 === s;
                return Object(ct.a)(e, {
                  isCoupon: Object(dt.b)({
                    umpActivity: this.umpActivity
                  }),
                  umpActivity: this.umpActivity,
                  skuShowData: {
                    skuScene: this.skuScene
                  },
                  isGroupOn: this.currentActivity.type === q.a.GROUP_ON,
                  query: this.query,
                  isGift: i,
                  goodsEstimatePriceData: this.goodsEstimatePriceData || {}
                })
              } catch (e) {
                throw e.message = ((t, e, s) => "goods-detail_ump_trade-submit: " + t + ", " + e + ", " + s.toString())("处理跳转下单页数据异常", "tradePostData", e.message), t.hummer && t.hummer.capture(e), e
              }
            },
            updateQuery(t) {
              this.query = t
            }
          }
        }
      }, z, tt, et].reduce((t, e) => Object(o.c)(t, e), {});
    var pt = {
      data() {
        var t;
        return this.store = (t = this.ctx, Object(a.a)({
          state: () => Object(i.a)({}, ht.state),
          getters: Object(i.a)({}, ht.getters),
          actions: Object(i.a)({}, ht.getActions(t))
        })), Object(a.c)(this, ["goodsBaseInfo", "shopBaseInfo", "buyConfig", "goodsPriceInfo", "goodsSkuData", "goodsMetaInfo", "goodsCombineInfo", "currentActivity", "umpActivity", "featureSwitch", "shopMetaInfo", "goodsActivity", "periodBuy", "couponTips", "ladderGroupOn", "ecard", "kdtId", "themeVars", "userGoodsStateParams", "marketing", "isCoupon", "multiSkuDecision", "pointsConfig", "skuConfig", "explainVideoFullScreen", "hasOpenExplainVideo", "themeTag", "pageVars"]), Object(i.a)({
          needIsSleep: !1,
          themeColors: {}
        }, Object(a.d)(this, ["goodsBaseInfo", "showSelfSelectedCombo", "showSku", "skuGoods", "skuData", "skuConfig", "kdtId", "showEvent", "themeVars", "goodsAttributesOpt", "periodBuyOpt", "ecardOpt", "ladderGrouponOpt", "sellingPointOpt", "couponTipsOpt", "estimatePriceOpt", "couponIntroOpt", "extraData", "multiSkuDecision", "pointsConfig", "explainVideoFullScreen", "hasOpenExplainVideo", "themeTag", "pageVars"]))
      },
      computed: {
        showSkuHeader() {
          var {
            replacedSlots: t
          } = this.ctx.data.cloudDesignConfig || {};
          return !!(t || []).includes("goods-detail-sku-header")
        },
        zIndex() {
          return this.explainVideoFullScreen ? 10004 : 100
        },
        popCustomStyle() {
          return this.themeVars + this.pageVars || ""
        }
      },
      watch: {
        sellingPointOpt: {
          handler(t) {
            this.ctx.data.sellingPointOpt = t
          },
          immediate: !0
        },
        skuGoods: {
          handler(t) {
            this.ctx.data.goods = t, this.store.resetPlugins(null == t ? void 0 : t.alias)
          },
          immediate: !0
        }
      },
      created() {
        Object(a.b)(this, ["onHideSku", "onSkuSubmit", "onSkuOpened", "onPreview", "onSkuSelected", "skuSelected", "showNearSku", "doSkuSubmit", "onPluginsChange", "onNumChange", "onCouponVisible", "customLogger"]), this.store.updateQuery(this.$getPageQuery()), this.init()
      },
      mounted() {
        this.$nextTick(() => {
          this.store.setTradePrefetchRef(this.$refs.goodsSku)
        })
      },
      destroyed() {
        var {
          store: t
        } = this;
        t && (clearTimeout(t.tradePrefetchTimer), t.offOrderKeepHandler())
      },
      methods: {
        assignCtxData(t) {
          return e => {
            var s = t.call(this, e);
            s && Object.assign(this.ctx.data, s)
          }
        },
        init() {
          var {
            saveBigButtons: t,
            getUserStateSkuDirectOrder: e,
            submitAction: s,
            saveGuaranteeData: i,
            onBtnClick: a,
            hideVirtualTicketIntro: o,
            getEstimateData: n,
            startTradeSubmit: u,
            bindOrderKeepHandler: d
          } = this.store;
          Object(r.b)(this, {
            shopConfig: this.assignCtxData(S),
            goodsActivity: this.assignCtxData(f),
            payWays: this.assignCtxData(y),
            currentActivity: this.assignCtxData(O),
            umpActivity: this.assignCtxData(D),
            bigButtons: t,
            themeColors: t => {
              this.themeColors = t, t && Object.assign(this.ctx.data, t)
            }
          }), Object(r.d)(this, {
            "skuOrder:selected": this.onSkuSelected,
            "sku:preview-click": this.onPreview,
            showNearSku: this.showNearSku,
            "sku:show": e,
            "submit:act": s,
            "skuSubmit:act": this.doSkuSubmit,
            guaranteeSetupReady: i,
            "big-btn:click": a,
            "sku:hide": this.onHideSku,
            hideVirtualTicketIntro: o
          }), Object(r.c)(this, ["userGoodsStateParams", "marketing", "isCoupon"], {
            callback: () => {
              n()
            }
          }), Object(r.e)(this, {
            addCart: t => {
              u({
                skuScene: c.c.ADD_CART,
                skuData: t,
                pluginsResult: {},
                activityInfo: {},
                extraParams: {}
              })
            }
          }), this.ctx.data.displayData = {}, this.ctx.data.orderData = {}, d()
        }
      }
    };
    e.default = C.default.component(pt)
  },
  "Hpq+": function(t, e, s) {
    var i = s("Fcif"),
      a = s("xers"),
      r = s.n(a);
    e.a = class {
      constructor() {
        this.plugins = {}, this.priority = 0
      }
      get sortedPlugins() {
        return Object.values(this.plugins).sort((t, e) => t.priority - e.priority)
      }
      reset() {
        this.plugins = {}
      }
      update(t) {
        var {
          name: e,
          pluginsResult: s = {}
        } = t, a = this.plugins[e], o = JSON.stringify(s) === JSON.stringify((null == a ? void 0 : a.pluginsResult) || {}), n = !r()(t.pluginsResult || {}) && !o, u = !r()((null == a ? void 0 : a.view) || {}) || !r()((null == t ? void 0 : t.view) || {});
        return this.plugins[e] = t, Object(i.a)({}, this.getData(), {
          pluginsResultUpdate: n,
          viewUpdate: u
        })
      }
      getData() {
        return this.sortedPlugins.reduce((t, e) => {
          var {
            view: s = {},
            pluginsResult: a = {},
            invalidMessage: r = {}
          } = e;
          return {
            view: Object(i.a)({}, t.view, s),
            pluginsResult: Object(i.a)({}, t.pluginsResult, a),
            invalidMessage: Object(i.a)({}, t.invalidMessage, r)
          }
        }, {
          view: {},
          pluginsResult: {},
          invalidMessage: {}
        })
      }
    }
  }
}));