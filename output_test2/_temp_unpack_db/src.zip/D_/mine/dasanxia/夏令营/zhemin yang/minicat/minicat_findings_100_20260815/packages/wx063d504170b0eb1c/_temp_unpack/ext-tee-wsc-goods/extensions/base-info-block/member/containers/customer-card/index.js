var r = require("~/r");
r("GJ8L", Object.assign({}, require("~/v.js").modules, {
  GJ8L: function(e, t, i) {
    i.r(t);
    var a = i("9ZMt"),
      o = i("AGZf"),
      l = {
        et: "view",
        ei: "view_activite_card",
        en: "权益卡激活曝光"
      },
      c = {
        et: "click",
        ei: "click_activite_card",
        en: "权益卡激活点击"
      },
      r = {
        methods: {
          benefitcardLogView() {
            this.logger(l)
          },
          benefitcardClick(e) {
            void 0 === e && (e = {}), e.mobile || Object(o.a)("授权失败，请重试"), this.logger(c), this.show = !0
          }
        }
      },
      n = i("eijD"),
      d = i("w2Y9"),
      s = i.n(d),
      u = i("YeA1"),
      g = i("ONqW"),
      m = {
        methods: {
          discountLogView() {
            setTimeout(() => {
              Object(g.a)().log({
                et: "view",
                ei: "goodsdetail_mj",
                en: "商详页入会组件曝光"
              })
            }, 500)
          },
          submitClickLogger: () => new Promise(e => {
            Object(g.a)().log({
              et: "click",
              ei: "click_lead_membercenter",
              en: "商详页_引导办卡/办会员点击"
            }), setTimeout(() => e(), 800)
          }),
          discountClick() {
            var e = this;
            return Object(n.a)(function*() {
              var t, i, a, o, l, c;
              if (null != (t = e.opt) && t.mobile) {
                var r = s.a.add(e.$getPageRoute(), e.$getPageQuery()),
                  n = (null == (i = e.opt) || null == (a = i.recommendedPriceModel) ? void 0 : a.cardUrl) || "";
                if (null != (o = e.opt) && null != (l = o.extraAction) && l.supportFastJoin) e.opt.extraAction.fastJoin();
                else if (yield e.submitClickLogger(), n.indexOf("packages/levelcenter/plus/index") > -1) {
                  var d;
                  null == (d = Object(u.a)()) || d.dmc.navigate(n)
                } else {
                  var g = {
                      guideType: "goods",
                      redirectUrl: r
                    },
                    m = s.a.get("src", n, !0);
                  m && (n = m), null == (c = Object(u.a)()) || c.dmc.navigate(s.a.add(n, g))
                }
              } else e.reload()
            })()
          }
        }
      },
      p = i("Nvad"),
      v = {
        name: "benefit-card",
        mixins: [r, m],
        props: {
          opt: {
            type: Object,
            default: () => ({})
          }
        },
        computed: {
          mainText() {
            return Object(p.b)(this.opt.mainText)
          }
        },
        watch: {
          "opt.show": function(e) {
            e && this[this.opt.type + "LogView"]()
          }
        },
        methods: {
          reload() {
            a.default.$native.startPullDownRefresh()
          },
          handleClick(e) {
            this[this.opt.type + "Click"](e)
          }
        },
        ud: !0
      };
    t.default = a.default.component(v)
  }
}));