var r = require("~/r");
r("YvGZ", Object.assign({}, require("~/v.js").modules, require("~/c.js").modules, {
  YvGZ: function(t, e, n) {
    n.r(e);
    var i = n("9ZMt"),
      s = n("gBZH"),
      a = n("bAmA"),
      o = n.n(a),
      r = ["mobile", "nicknameAndAvatar"],
      h = t => Array.isArray(t) && t.length > 0,
      u = {
        name: "goods-big-btn",
        props: {
          btn: Object,
          kdtId: Number,
          first: Boolean,
          last: Boolean,
          disabled: Boolean,
          hasWxUnionId: Boolean
        },
        computed: {
          noNeedUnionScene() {
            var t = [s.a.ADD_CART, s.a.NORMAL_BUY].includes(this.btn.accountUnionScene);
            return "qq" === i.default.getEnv() && t
          },
          authTypeList() {
            return this.noNeedUnionScene ? [] : !1 === this.hasWxUnionId ? h(this.btn.authTypeList) ? o()(["nicknameAndAvatar", "mobile"].concat(this.shopMobileAuth || [])) : ["nicknameAndAvatar", "mobile"] : this.btn.isHaitaoForbiden ? ["mobile"] : h(this.btn.authTypeList) ? this.btn.authTypeList : this.btn.needSkuPop && !this.btn.isSkuDirectOrder || this.authScene ? [] : r
          },
          authScene() {
            var {
              accountUnionScene: t,
              submitAction: e
            } = this.btn;
            return "ORDER_SECKILL" === e ? t : this.btn.needSkuPop && !this.btn.isSkuDirectOrder || this.noNeedUnionScene || (this.btn.authTypeList || []).length > 0 || this.btn.isHaitaoForbiden ? "" : t || ""
          },
          isUnRenderAuth() {
            return !this.authScene && 0 === this.authTypeList.length
          }
        },
        methods: {
          handleBigButtonClick() {
            this.$emit("btn-click", this.btn)
          }
        },
        ud: !0
      };
    e.default = i.default.component(u)
  }
}));