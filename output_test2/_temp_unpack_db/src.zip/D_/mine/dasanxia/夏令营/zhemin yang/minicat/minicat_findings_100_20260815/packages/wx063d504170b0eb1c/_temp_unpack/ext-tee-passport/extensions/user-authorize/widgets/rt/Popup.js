var r = require("~/r");
r("Bk6F", Object.assign({}, require("~/v.js").modules, {
  Bk6F: function(t, o, r) {
    r.r(o);
    var e = r("qo/7"),
      n = {
        mixins: [Object(e.a)("popup")],
        ud: !0
      },
      u = r("9ZMt");
    o.default = u.default.component(n)
  },
  "qo/7": function(t, o, r) {
    function e(t) {
      return {
        data() {
          var {
            cloudDesignConfig: o
          } = this.ctx.data;
          return {
            protocolIsCloudSlot: !!o && o.replacedSlots.includes("account-protocol-content"),
            protocolSource: "@ext/authorize/" + t + "_" + Date.now()
          }
        }
      }
    }
    r.d(o, "a", function() {
      return e
    })
  }
}));