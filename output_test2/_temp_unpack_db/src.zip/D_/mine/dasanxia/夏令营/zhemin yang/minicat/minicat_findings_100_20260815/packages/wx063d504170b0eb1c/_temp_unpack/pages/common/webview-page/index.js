var r = require("~/r");
r("u1mO", Object.assign({}, require("~/v.js").modules, require("~/c.js").modules, {
  u1mO: function(e, t, s) {
    s.r(t);
    var a = s("2wjL"),
      o = s("42EB"),
      i = s("GFyo"),
      r = s("Yt9W");
    Page({
      onLoad(e) {
        void 0 === e && (e = {}), e.title && wx.setNavigationBarTitle({
          title: decodeURIComponent(e.title)
        }), e.src = e.src || e.url, e.src && this.setData({
          viewSrc: decodeURIComponent(e.src)
        }), this.setWebviewLog(), this.__webviewMsg = {}, this._isNeedLog = !1
      },
      onShow() {
        this._isNeedLog && this.enterPageLog()
      },
      setWebviewLog() {
        getApp().request({
          path: "/wscgoods/weapp/get-page-gray-release.json",
          query: {
            pageKey: "weapp-log-shop"
          }
        }).then(e => {
          this._isNeedLog = e, e && this.enterPageLog()
        })
      },
      enterPageLog() {
        Object(r.d)("pages/common/webview-page/index", "", {}, "weappWebview")
      },
      handlePostMessage(e) {
        o.a.call(this, e.detail.data || []), e.detail.data.forEach(e => {
          "chosenAppointment" === e.type ? Object(i.g)("chosenAppointment", e) : e.checkedStudent && Object(i.g)("recentSelectedStudent", e.checkedStudent)
        })
      },
      onShareAppMessage() {
        var {
          src: e,
          url: t
        } = this.options || {}, s = e || t, o = s ? a.a.add("/" + this.route, {
          src: s
        }) : "/packages/home/dashboard/index";
        return this.__webviewMsg["ZNB.share"] || {
          path: o
        }
      }
    })
  }
}));