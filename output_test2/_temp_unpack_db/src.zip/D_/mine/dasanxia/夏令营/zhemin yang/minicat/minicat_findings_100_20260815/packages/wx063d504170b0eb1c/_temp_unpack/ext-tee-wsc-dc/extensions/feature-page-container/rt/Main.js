var r = require("~/r");
r("95NW", Object.assign({}, require("~/v.js").modules, {
  "95NW": function(t, e, a) {
    a.r(e);
    var s = a("YeA1"),
      o = {
        data: () => ({
          featurePageBgColor: "",
          isFromTimeline: !1,
          isWebviewFeature: !1,
          copyrightBgColor: "f9f9f9",
          showCustomTabBar: !1
        }),
        created() {
          Object(s.b)(this, ["featurePageBgColor", "isFromTimeline", "isWebviewFeature", "copyrightBgColor"]);
          var t = this.$getPageRoute();
          ["pages/home/dashboard/index", "pages/tab/one/index", "pages/tab/two/index", "pages/tab/three/index"].includes(t) ? this.showCustomTabBar = !1 : this.showCustomTabBar = !0, this.buyButtonStyleUnWatch = this.ctx.watch("buyButtonStyle", this.handleBuyButtonStyle)
        },
        mounted() {
          var t;
          this.ctx.data.isHomePage && (null == (t = this._$native.getTabBar()) || t.setData({
            selectedIndex: 0
          }))
        },
        destroyed() {
          this.buyButtonStyleUnWatch && this.buyButtonStyleUnWatch()
        },
        methods: {
          handleBuyButtonStyle(t) {
            var {
              setPageStyle: e
            } = this.$root;
            e && t && e(t)
          }
        },
        ud: !0
      },
      i = a("9ZMt");
    e.default = i.default.component(o)
  }
}));