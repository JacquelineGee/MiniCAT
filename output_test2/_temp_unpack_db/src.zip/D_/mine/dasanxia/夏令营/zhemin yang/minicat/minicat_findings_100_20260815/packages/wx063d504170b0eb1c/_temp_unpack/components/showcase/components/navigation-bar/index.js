var r = require("~/r");
r("864p", Object.assign({}, require("~/v.js").modules, require("~/c.js").modules, {
  "864p": function(e, a, t) {
    t.r(a);
    var i, n = t("Fcif"),
      o = t("lZq6"),
      s = t("GXW/"),
      r = t("taYb"),
      l = t("GFa9"),
      c = t("Eagg"),
      g = t("MLLI"),
      h = t("QLod"),
      p = t("z1RG"),
      {
        NEW_FEATURE_ROUTE: d,
        APP_FEATURE_ROUTE: u,
        NEW_MARKETING_PAGE_ROUTE: v,
        NEW_HOMEPAGE_ROUTE: _,
        APP_HOMEPAGE_ROUTE: m,
        OLD_GOODS_ROUTE: f,
        NEW_GOODS_ROUTE: O,
        TEMPLATE_ROUTE: b,
        TAB_THREE_ROUTE: T,
        APP_TAB_THREE_ROUTE: E,
        TAB_TWO_ROUTE: y,
        APP_TAB_TWO_ROUTE: P,
        TAB_ONE_ROUTE: S,
        APP_TAB_ONE_ROUTE: k,
        EXT_NEW_FEATURE_ROUTE: C,
        EXT_NEW_MARKETING_PAGE_ROUTE: j,
        EXT_TAB_ONE_ROUTE: w,
        EXT_TAB_TWO_ROUTE: U,
        EXT_TAB_THREE_ROUTE: A,
        EXT_NEW_HOMEPAGE_ROUTE: I,
        OLD_NEW_FEATURE_ROUTE: D,
        OLD_TAB_ONE_ROUTE: x,
        OLD_TAB_TWO_ROUTE: R,
        OLD_TAB_THREE_ROUTE: N,
        OLD_NEW_HOMEPAGE_ROUTE: G,
        USERCENTER_ROUTE: L,
        SHOPNOTE_DETAIL_ROUTE: M,
        PACKAGES_USERCENTER_ROUTE: F
      } = h.b,
      W = {
        home: "onHomeTap",
        search: "onSearchTap",
        usercenter: "onUserCenterTap",
        shopcar: "onShopCarTap",
        allGoods: "onAllGoodsTap",
        marketingPage: "onMarketingPageTap"
      },
      H = {
        [d]: 0,
        [u]: 0,
        [v]: 0,
        [T]: 0,
        [E]: 0,
        [y]: 0,
        [P]: 0,
        [S]: 0,
        [k]: 0,
        [b]: 0,
        [b]: 5,
        [f]: 2,
        [O]: 2,
        [_]: 5,
        [m]: 5,
        [C]: 0,
        [j]: 0,
        [w]: 0,
        [U]: 0,
        [A]: 0,
        [I]: 5,
        [D]: 0,
        [x]: 0,
        [R]: 0,
        [N]: 0,
        [G]: 5,
        [M]: 6,
        [L]: 7,
        [F]: 7
      },
      B = {
        navColor: "#ffffff",
        textColor: "#000000",
        sysPath: [],
        customPath: [],
        supportPages: ["0", "2", "5"],
        hotKeys: []
      },
      K = t("JIO9"),
      q = (t("R18q"), t("jA1y")),
      $ = function(e) {
        return void 0 === e && (e = !0), Object(q.d)({
          path: "/wscshop/top-nav/getConfig.json",
          origin: "h5",
          data: {
            withCache: e
          }
        })
      },
      X = t("zMoS"),
      z = t("DXKY"),
      V = t("hTAu"),
      J = t("Ix7h"),
      Y = t("YeA1"),
      Q = t("4jn8"),
      Z = t("Tewj"),
      {
        dmc: ee
      } = Object(Y.a)(),
      ae = getApp(),
      {
        NEW_HOMEPAGE_ROUTE: te,
        APP_HOMEPAGE_ROUTE: ie,
        NEW_GOODS_ROUTE: ne,
        OLD_GOODS_ROUTE: oe,
        TEE_NEW_HOMEPAGE_ROUTE: se,
        EXT_NEW_HOMEPAGE_ROUTE: re,
        EXT_CORE_HOMEPAGE_ROUTE: le,
        GOODS_DETAIL_TOUTE: ce,
        KQ_GOODS_DETAIL: ge
      } = h.b,
      he = !1;
    Component({
      behaviors: [o.a, s.a],
      properties: {
        titleText: String,
        openCustomNav: Boolean,
        navigationbarConfigData: {
          type: Object,
          value: {},
          observer: "initImmersionData"
        },
        switchPageOptions: Object
      },
      data: {
        canUseNav: !0,
        fontSizeSetting: 16,
        height: Object(h.e)(),
        paddingTop: (null == (i = Object(g.b)()) ? void 0 : i.statusBarHeight) || 20,
        textWidth: 161,
        showImmersionMenuMain: !1,
        showMenuMain: !1,
        showMenuBack: !1,
        customIconStyle: "",
        isMenuOpen: !1,
        configData: B,
        isChannels: Object(c.b)(),
        useImmersion: !1,
        immersionUpShow: !1,
        cd: {},
        needPointClickNav: !1,
        contactExtra: {
          sourceParam: "",
          businessId: ""
        },
        specialSupport: !1,
        originImmersion: !1,
        opacityVal: 0
      },
      attached() {
        this.getConfig(), this.getImInfo(), this.initOriginImmersion(), ae.on("app:chainstore:kdtid:update", () => {
          he = !1, this.isComponentHide || ae.getEnterCacheConfig("proxyWxJumpPadding") ? this._cacheFunc = () => {
            this.getConfig()
          } : this.getConfig()
        }), p.a.setStickyControlCheckItem("customNavigation", 9999999999, !0)
      },
      ready() {
        this.pageScrollFn = Object(J.a)(this.onPageScrollIntersectionObserver.bind(this), 50)
      },
      destroyed() {
        z.a.off("onPageScroll" + this.getPageKey(), this.pageScrollFn), this.opacityFn && Z.default.off("onNavOpacityChange", this.opacityFn)
      },
      pageLifetimes: {
        show() {
          this._cacheFunc && (this._cacheFunc(), this._cacheFunc = null)
        }
      },
      methods: {
        getShowComponentData() {
          var {
            configData: e,
            navigationbarConfigData: a
          } = this.data, t = Object(X.a)(a, "shortcut_list", []), i = t.length > 0 && "back" === t[0].key;
          if (!this.isFirstPage() && !i) {
            var o = "https://img01.yzcdn.cn/upload_files/2023/08/16/FqxHFkCQQvsOpUbIqWR2aFIG_LfW.png";
            t.unshift({
              key: "back",
              show: 1,
              title: "返回",
              images: {
                after_slide: o,
                before_slide: "https://img01.yzcdn.cn/upload_files/2023/08/16/FgCOwpyU3CBjnt9a6FBhKIUycPU3.png",
                standard: o
              }
            })
          }
          return t && t.length && (t = t.filter(e => e.show).slice(0, 3)), "global" === a.style_color_type && e && (a.style_color_custom_background_color = e.navColor, a.style_color_custom_font_color = e.textColor && e.textColor.includes("#fff") ? "white" : "black"), Object(n.a)({}, a, {
            shortcut_list: t
          })
        },
        init() {
          var {
            top: e,
            height: a,
            right: t,
            width: i,
            canUseNav: n
          } = h.a, o = Object(h.e)(!1), s = Object(g.b)(), {
            statusBarHeight: r
          } = s, {
            windowWidth: l,
            fontSizeSetting: p
          } = s, d = l - t, u = l - 2 * i - 4 * d, v = getCurrentPages(), {
            configData: _
          } = this.data, m = v[v.length - 1].route, f = v.length > 1;
          !f && (m === ce || m === ge) && (f = !0);
          var O = m === te || m === ie || m === se || m === re || m === le;
          O && (f = !1), 0 !== m.indexOf(ne) && 0 !== m.indexOf(oe) || (m = ne);
          var b, T, E, y = (b = m, T = this.data.configData.supportPages, void 0 !== (E = H[b]) && (T || []).map(e => +e).indexOf(E) > -1),
            P = (e => h.c.includes(e))(m),
            S = _.sysPath.length + _.customPath.length > 1,
            k = Object(h.f)(m),
            {
              type: C,
              open: j
            } = k || {};
          "back" === C && (f = j);
          var w = S && y || ("home" === C ? j : !O),
            U = !1;
          ae.forceShowHome() && (U = !0, w = !0);
          var A = "width: " + (f ? i : a) + "px;height: " + a + "px;left: " + d + "px;top: " + e + "px;border-radius: " + o + "px;";
          Object(c.b)() && (Object(c.a)() || (r = 0), A = "width: 32px;height: 32px;left: 7px;top: " + (r + 3) + "px;border:none;", o = r + 40, u = 173);
          var I = "top: " + (o + 13) + "px;left: " + d + "px",
            D = "left: " + ((f ? i / 4 * 3 : a / 2) - 7) + "px";
          this.initImmersionData(), this.triggerEvent("set-height", o), this.setData({
            showMenuMain: w,
            showImmersionMenuMain: U,
            height: o,
            fontSizeSetting: p,
            canUseNav: n,
            textWidth: u,
            showMenuBack: f,
            customIconStyle: A,
            openMenuStyle: I,
            openMenuAfterStyle: D,
            currentSupport: y,
            specialSupport: P,
            isSkyline: "skyline" === this.renderer
          })
        },
        isFirstPage() {
          var e = getCurrentPages();
          return !!(2 === e.length && e[0] && e[0].route && e[0].route.includes("pages/common/blank-page/index")) || !(e.length > 1)
        },
        initImmersionData() {
          var {
            origin_immersion: e,
            navigationbar_config_type: a
          } = this.data.navigationbarConfigData || {};
          if (e) return Z.default.off("onPageScroll" + this.getPageKey(), this.pageScrollFn), Z.default.on("onPageScroll" + this.getPageKey(), this.pageScrollFn), void this.setData({
            originImmersion: !0
          });
          var t = !1;
          if (Object.keys(this.data.navigationbarConfigData || {}).length) {
            if ("global" === a) return;
            t = !0;
            var i = this.getShowComponentData();
            z.a.off("onPageScroll" + this.getPageKey(), this.pageScrollFn), Z.default.off("onPageScroll" + this.getPageKey(), this.pageScrollFn), z.a.on("onPageScroll" + this.getPageKey(), this.pageScrollFn), Z.default.on("onPageScroll" + this.getPageKey(), this.pageScrollFn), this.setData({
              cd: i,
              useImmersion: t,
              needPointClickNav: this.getNeedPointClickNav()
            })
          }
        },
        getNeedPointClickNav() {
          var {
            useImmersion: e,
            immersionUpShow: a,
            navigationbarConfigData: t
          } = this.data;
          return !(!e || a || "gaussianblur" === t.style_color_custom_type || "immersion" !== t.navigationbar_type)
        },
        getPageKey() {
          return this.__pageEventUniqueKey || (this.__pageEventUniqueKey = Object(V.a)()), this.__pageEventUniqueKey
        },
        onPageScrollIntersectionObserver(e) {
          if (this.data.originImmersion) {
            var a = 0;
            e.scrollTop > 10 && (a = 1), this.setData({
              opacityVal: a
            })
          } else {
            var t = !1;
            e.scrollTop > 10 && (t = !0), t !== this.data.immersionUpShow && this.setData({
              immersionUpShow: t
            }), wx.nextTick(() => {
              this.setData({
                needPointClickNav: this.getNeedPointClickNav()
              })
            })
          }
        },
        handleNavOpacity(e) {
          this.data.originImmersion && this.setData({
            opacityVal: e
          })
        },
        getStoreConfig: () => wx.getStorage("__TOP_NAV_CONFIG__").then(e => {
          var {
            time: a = 0,
            data: t = B
          } = e || {};
          return new Date().getTime() - a > 6e5 || !he ? $() : {
            data: t,
            cache: !0
          }
        }).catch(() => $()),
        getConfig() {
          (ae.isHqEnterShop() ? Promise.resolve() : ae.waitForEnterShop()).then(() => this.isComponentHide ? new Promise(e => {
            this._cacheFunc = () => {
              e(this.getStoreConfig())
            }
          }) : this.getStoreConfig()).then(e => {
            var a, t = getCurrentPages(),
              i = t[t.length - 1].route,
              o = Object(h.f)(i),
              {
                type: s,
                open: l,
                sysPath: c = [],
                customPath: g = []
              } = o || {},
              p = "menu" !== s || l;
            if (e && e.data && !e.cache) {
              try {
                var d = JSON.parse(e.data).find(e => "shop_top_nav" === e.type);
                d && (a = r.a.toCamelCase(d))
              } catch (e) {
                a = B
              }
              p && (a.sysPath.push(...c), a.customPath.push(...g)), a.sysPath = p ? a.sysPath.filter(e => 1 === e.show).map((e, a, t) => Object(n.a)({}, e, {
                _right: t.length > 4 && (a + 1) % 4 == 0 || a === t.length - 1 ? 0 : 24
              })) : [], a.customPath = p ? a.customPath.map((e, t) => Object(n.a)({}, e, {
                _right: a.customPath.length > 4 && (t + 1) % 4 == 0 || t === a.customPath.length - 1 ? 0 : 24
              })) : [], wx.setStorage("__TOP_NAV_CONFIG__", {
                data: a,
                time: new Date().getTime()
              }), he = !0
            } else a = e.data;
            return a
          }).catch(e => {}).then(e => {
            var {
              navigationbarConfigData: a
            } = this.data, {
              special_nav_bg_color: t,
              special_nav_color: i
            } = a, o = e || Object(n.a)({}, B);
            t && (o.navColor = t), i && (o.textColor = i), this.setData({
              configData: o
            }, this.init.bind(this))
          })
        },
        onMenuTap() {
          ae.logger.log({
            et: "click",
            ei: "nav_button_weapp",
            en: "导航按钮点击",
            si: ae.getKdtId(),
            params: {
              is_show: Number(this.data.isMenuOpen)
            }
          });
          var {
            configData: {
              sysPath: e,
              customPath: a
            },
            currentSupport: t
          } = this.data;
          t && e.length + a.length > 1 ? this.onOpenMenuStatusChange() : this.onHomeTap()
        },
        onOpenMenuStatusChange() {
          this.setData({
            isMenuOpen: !this.data.isMenuOpen
          })
        },
        onImmersionTap(e) {
          this[{
            search: "onSearchTap",
            marketingPage: "onMarketingPageTap",
            allGoods: "onAllGoodsTap",
            shopcar: "onShopCarTap",
            usercenter: "onUserCenterTap",
            home: "onHomeTap",
            back: "onBackTap"
          } [e.detail.key]](), this.logNavTapEvent({
            event_key: e.detail.key
          })
        },
        onMenuSysPathTap(e) {
          var {
            detail: a
          } = e;
          this[W[a]](), this.logNavTapEvent({
            event_key: a
          })
        },
        onHomeTap() {
          l.a.switchTab({
            url: "/" + ie
          })
        },
        onUserCenterTap() {
          ee.switchTab("Usercenter").catch(() => {
            ee.navigate("Usercenter")
          })
        },
        onShopCarTap() {
          Object(Q.a)({
            path: "/pages/goods/cart/index",
            fail() {
              l.a.navigate({
                url: "/packages/goods/cart/index"
              })
            }
          })
        },
        onAllGoodsTap() {
          ee.navigate("AllGoodsList")
        },
        onMarketingPageTap() {
          l.a.navigate({
            url: "/packages/ext-marketing-page/index"
          })
        },
        onBackTap() {
          1 === getCurrentPages().length ? this.onHomeTap() : wx.navigateBack()
        },
        onSearchTap() {
          l.a.navigate({
            url: "/packages/shop/search-page/index?keepWords=&isFromList=1"
          })
        },
        onMenuCustomPathTap(e) {
          var {
            detail: a
          } = e;
          Object(K.a)(a, a), this.logNavTapEvent({
            event_key: "custom_path",
            custom_title: a.title,
            custom_url: a.link_url
          })
        },
        handleScroll() {
          p.a.setStickyControlItem("customNavigation", this.data.height, !0)
        },
        getImInfo() {
          ae.getDefaultImData().then(e => {
            this.setData({
              contactExtra: e
            })
          })
        },
        openImmersiveStatus() {
          this.opacityFn = Object(J.a)(this.handleNavOpacity, 50), Z.default.on("onNavOpacityChange", this.opacityFn, this);
          Z.default.on("onSetImmersiveReady", () => {
            Z.default.trigger("onSetImmersive", {
              status: !0,
              navHeight: this.data.height
            })
          }, this), this.setData({
            originImmersion: !0
          })
        },
        initOriginImmersion() {
          var e = getCurrentPages(),
            a = e[e.length - 1].route;
          if (a === ce || a === ge) {
            var t = "goods_detail_navigation_bar_style",
              i = ae.getShopConfigDataSync();
            0 === Object.keys(i).length ? ae.getShopConfigData().then(e => {
              "1" === e[t] && this.openImmersiveStatus()
            }) : "1" === i[t] && this.openImmersiveStatus()
          }
        },
        logNavTapEvent(e) {
          var a = getCurrentPages(),
            t = a[a.length - 1].route;
          ae.logger.log({
            et: "click",
            ei: "shortcut_item_click",
            en: "快捷按钮点击情况",
            si: ae.getKdtId(),
            params: Object(n.a)({
              component: "navigation_bar_weapp",
              page_key: t
            }, e)
          })
        }
      }
    })
  },
  JIO9: function(e, a, t) {
    t.d(a, "a", function() {
      return w
    });
    var i = t("+I+c"),
      n = t("Fcif"),
      o = t("9ZMt"),
      s = t("US/N"),
      r = t("hHpg"),
      l = t("xers"),
      c = t.n(l),
      g = t("w2Y9"),
      h = t.n(g),
      p = t("tuFO"),
      d = t.n(p),
      u = t("4c+U"),
      v = t("ONqW"),
      _ = e => {
        var {
          videoDynamicParams: a,
          linkTitle: t
        } = e;
        return Object(n.a)({}, a, {
          image_url: null == e ? void 0 : e.imageUrl,
          link_title: t
        })
      },
      m = t("YeA1"),
      f = t("7WUL"),
      O = (t("SVbq"), t("tmLU")),
      b = (t("4jn8"), t("2wjL")),
      T = t("R18q"),
      E = o.default.getApp();

    function y(e) {
      var a = E.getKdtId();
      Object(O.c)({
        navigatePath: "retail-shelf",
        navigateCb: t => {
          setTimeout(() => {
            T.a.mark.start("retail_shelf_init_" + E.globalData.shelfParams.mode), T.a.mark.start("retail_shelf_config");
            var i = "/" + e + "&prefetchKey=" + t + "&prefetchKdtId=" + a;
            o.default.$native.navigateTo({
              url: i
            })
          }, 150)
        },
        prefetchCb: () => {
          var a, {
            mode: t,
            filter: i
          } = b.a.getAll(e) || {};
          return 0 !== t || i ? Promise.reject() : (a = {
            mode: t
          }, Object(s.default)({
            path: "retail/h5/miniprogram/shelf-config/getFirstLevelConfigs",
            method: "POST",
            data: Object(n.a)({}, a, {
              useSwitch: "v2",
              supportUnavailableGoods: 2
            })
          }))
        }
      })
    }
    var P = (e, a) => {
        o.default.$native.getSetting({
          success: t => {
            var i = t.authSetting["scope.userLocation"];
            void 0 === i || !0 === i ? o.default.$native.getLocation({
              type: "gcj02",
              fail: () => {
                null != a && a.handleShowAuthDialog && a.handleShowAuthDialog()
              },
              success: () => {
                y(e)
              }
            }) : !1 === i && y(e)
          }
        })
      },
      S = (e, a) => {
        var {
          linkType: t,
          linkUrl: i
        } = e;
        [f.c.SELF, f.c.TAKEOUT, f.c.SaleToday, f.c.SaleAdvance].includes(t) ? (E.globalData.shelfParams = {
          mode: f.d[t]
        }, P(f.e[t], a)) : [f.c.SCAN_GO, f.c.FREE_GO].includes(t) ? (T.a.mark.start("scan_order_decorate"), o.default.navigate({
          url: "/" + i
        })) : [f.c.SHELF_GOODS, f.c.SHELF_GROUP].includes(t) ? (e => {
          var {
            linkId: a,
            linkType: t,
            alias: i,
            extraData: n = {}
          } = e, o = "shelf_goods" === t, s = ((e, a, t) => e && a && t ? a.includes(1) && t.includes(1) ? 0 : 1 : 0)(o, n[o ? "groupSupportDeliveryType" : "deliveryType"], o ? n.goodSupportDeliveryType : [1, 2, 3]), r = {
            mode: s
          };
          E.globalData.shelfParams = {
            mode: s
          }, "shelf_goods" === t && Object.assign(r, {
            fromShared: 1,
            sharedGoodsIdProp: a,
            sharedGoodsAliasProp: i
          }), P(h.a.add(f.f, r))
        })(e) : t === f.c.WX_SCAN_CODE && (E.logger && E.logger.log({
          et: "custom",
          ei: "click_wx_scan_code",
          en: "点击扫一扫链接"
        }), wx.scanCode({
          success: e => {
            e.path ? (Object(r.a)({
              type: "success",
              message: "识别成功，正在跳转",
              duration: 0
            }), wx.navigateTo({
              url: "/" + e.path,
              complete: () => {
                r.a.clear()
              }
            })) : r.a.fail("仅能扫此商家桌码/店铺码哦")
          },
          fail: () => {
            r.a.error("识别失败")
          }
        }))
      },
      k = ["type"],
      C = (getApp(), ["/pages/home/dashboard/index", "/pages/goods/cart/index", "/pages/usercenter/dashboard/index", "/pages-retail/usercenter/dashboard-v2/index"]),
      j = (e, a) => {
        "web" === o.default.getEnv() ? a && o.default.navigate({
          url: a
        }) : e && o.default.navigate({
          url: e
        })
      };
    var w = function(e, a) {
      void 0 === a && (a = {});
      var {
        dmc: t
      } = Object(m.a)(), {
        type: l = ""
      } = e, g = "", p = !1, {
        alias: O,
        linkType: b = "",
        linkId: T = "",
        linkUrl: E = "",
        linkTitle: y = "",
        extraData: P = {},
        query: w = {},
        goodsAlias: U
      } = e, {
        kdtId: A,
        banner_id: I,
        imageUrl: D,
        goodsPreloadOpt: x,
        title: R
      } = a, N = {
        kdt_id: A
      }, G = {};
      if (I && (G.banner_id = I), "chat" === (l = b || l)) {
        if ("web" === o.default.getEnv() && a) {
          var L = Object(u.a)(a);
          L && t.navigate(h.a.add(L, G))
        }
      } else if ("homepage" === l) t.switchTab("Home", Object(n.a)({}, G, N)).catch(() => {
        t.navigate("Home", Object(n.a)({}, G, N))
      });
      else if ("goods" === l && O) {
        var {
          image: M = {}
        } = x || {};
        t.navigate("GoodsDetail", Object(n.a)({
          alias: O
        }, w, G), {
          bizParams: {
            alias: O,
            image: {
              url: D || M.url,
              width: M.width,
              height: M.height
            },
            title: R
          }
        })
      } else if ("feature" === l && O) t.navigate("Feature", Object(n.a)({
        alias: O
      }, G));
      else if ("tag" === l) {
        var F = O ? {
          alias: O
        } : h.a.getAll(E);
        F.alias && t.navigate("GoodsTag", Object(n.a)({
          alias: F.alias,
          title: y
        }, G))
      } else if ("cart" === l) t.switchTab("Cart", Object(n.a)({}, G, N)).catch(() => {
        t.navigate("Cart", Object(n.a)({}, G, N))
      });
      else if ("usercenter" === l) t.switchTab("Usercenter", Object(n.a)({}, G, N)).catch(() => {
        t.navigate("Usercenter", Object(n.a)({}, G, N))
      });
      else if ("shopnote" === l) t.switchTab("Shopnote", Object(n.a)({}, G, N)).catch(() => {
        t.navigate("Shopnote", Object(n.a)({}, G, N))
      });
      else if ("allgoods" === l) t.navigate("AllGoodsList", Object(n.a)({
        title: y
      }, G));
      else if ("coupon" === l) t.navigate("CouponDetail", Object(n.a)({
        id: e.link_id || e.linkId,
        type: 7 === (e.coupon_type || e.couponType) ? "promocard" : ""
      }, G));
      else if ("point_card" === l) j("/packages/pointstore/goods-details/index?goods_id=" + e.pointGoodsId + "&" + I + "=" + I, E);
      else if ("pointsstore" === l) t.navigate("PointGoodsList", Object(n.a)({}, G, N));
      else if ("seckill" === l) "web" === o.default.getEnv() && E ? j("", "" + E) : "web" === o.default.getEnv() ? t.navigate("Seckill", Object(n.a)({
        alias: U,
        ump_alias: O,
        ump_type: "seckill",
        activityType: "seckill"
      }, w, N)) : t.navigate("Seckill", Object(n.a)({
        alias: O
      }, U ? {
        goodsAlias: U
      } : {}, G));
      else if ("bargain" === l) t.navigate("GoodsDetail", Object(n.a)({
        alias: O,
        umpType: e.umpType || "",
        activityId: e.activityId
      }, G));
      else if ("paidcolumn" === l) t.navigate("PaidContentColumn", Object(n.a)({
        alias: O
      }, G));
      else if ("paidcontent" === l) t.navigate("PaidContentContent", Object(n.a)({
        alias: O
      }, G));
      else if ("mypaidcontent" === l) t.navigate("PaidContentList", Object(n.a)({}, G, N));
      else if ("paidlive" === l) t.navigate("PaidContentLive", Object(n.a)({
        alias: O
      }, G));
      else if ("allcourse" === l) t.navigate("EduGoodsList", Object(n.a)({}, G, N));
      else if ("course" === l || "educourse" === l || "allofflinecourse" === l || "eduappointment" === l || "course_group" === l || "course_category" === l || "edumoments" === l) {
        if ("web" === o.default.getEnv()) j("", E);
        else {
          var W = E.replace(/^http(s)?:\/\/shop\d+-?\d+/, "https://h5");
          t.navigate("EduWebview", Object(n.a)({
            targetUrl: W
          }, G))
        }
      } else if ("link" === l) {
        var {
          linkUrl: H
        } = e;
        H && /mp.weixin.qq.com\/s/.test(H) && t.navigate("CommonWebview", Object(n.a)({
          src: H
        }, G))
      } else if ("weapplink" === l && "1" === P.linkType) {
        "/" !== (g = P.myWeappLink)[0] && (g = "/" + g);
        var B = g.split("?")[0];
        if (C.indexOf(B) > -1 && (p = !0), 0 === (g = h.a.remove(g, "shopAutoEnter")).indexOf("/pages/common/blank-page/index")) {
          var K = h.a.getAll(g);
          if (K.weappSharePath) {
            var q = decodeURIComponent(K.weappSharePath);
            q = h.a.remove(q, "shopAutoEnter"), K.weappSharePath = q, g = h.a.add("/pages/common/blank-page/index", K)
          }
        }
        if (!c()(a) && !p) {
          var {
            banner_id: $
          } = a;
          g = h.a.add(g, {
            banner_id: $
          })
        }
        o.default.navigate({
          url: g
        }).catch(() => {
          wx.reLaunch({
            url: g
          })
        })
      } else if ("weapplink" === l && "2" === P.linkType) + P.useShortLink || +P.use_short_link ? o.default.$native.navigateToMiniProgram({
        shortLink: P.shortLink || P.short_link
      }) : o.default.$native.navigateToMiniProgram({
        appId: P.otherWeappAppid || P.other_weapp_appid,
        path: P.otherWeappLink || P.other_weapp_link
      });
      else if ("calendar_checkin" === l) t.navigate("Checkin", Object(n.a)({}, N, G));
      else if ("zodiac" === l) t.navigate("LuckyLottery", Object(n.a)({
        alias: O
      }, G));
      else if ("shopnote_detail" === l) t.navigate("ShopnoteDetail", Object(n.a)({
        noteAlias: O
      }, G));
      else if ("mp_article" === l) t.navigate("MpArticle", Object(n.a)({
        noteAlias: O
      }, G));
      else if ("hotellist" === l || "recharge_center" === l || "point_coupon" === l || "room_typelist" === l || "combolist" === l) "web" === o.default.getEnv() ? j("", E) : t.navigate("CommonWebview", Object(n.a)({
        src: E
      }, G));
      else if ("period_list" === l) t.navigate("PeriodBuyList", Object(n.a)({}, N, G));
      else if ("point_store" === l) t.navigate("PointGoodsList", Object(n.a)({}, N, G));
      else if ("groupon" === l || "collector_card" === l || "gift_card" === l) E && o.default.navigate({
        url: E
      });
      else if ("weapp_marketing_page" === l || "marketing_page" === l) t.navigate("MarketingPage", Object(n.a)({}, N, G, {
        id: P.id || ""
      }));
      else if ("survey" === l || "guaguale" === l || "history" === l) j("", E);
      else if ("video_number" === l) {
        var X = o.default.$native.getStorageSync("channelsLiveInfo") || "";
        if (!X) return;
        var {
          feedId: z,
          nonceId: V
        } = JSON.parse(X);
        o.default.$native.openChannelsLive && o.default.$native.openChannelsLive({
          feedId: z,
          nonceId: V,
          finderUserName: T
        })
      } else if ("social_fans" === l) {
        var {
          qrcode: J
        } = e, Y = d()(h.a.add("/v3/message/live-qrcode/member", {
          kdtId: A,
          activitiesId: J
        }), "h5", A);
        o.default.$native.navigateTo({
          url: "/pages/common/webview-page/index?src=" + encodeURIComponent(Y)
        })
      } else if ("weapp_web_link" === l) j(h.a.add(E, G), h.a.add(E, Object(n.a)({}, N, G)));
      else {
        if ("red-package" === l) return o.default.$native.showRedPackage({
          url: E
        }), {};
        if ("member_code" === l) o.default.$native.navigateTo({
          url: "/packages/member-code/index"
        });
        else if ("vipcenter" === l) o.default.$native.navigateTo({
          url: "/packages/shop/levelcenter/free/index"
        });
        else if ("pay_vipcenter" === l) o.default.$native.navigateTo({
          url: "/packages/shop/levelcenter/plus/index"
        });
        else if ("shop_ranking_list" === l) {
          var {
            tabType: Q
          } = e;
          if (Q) {
            var Z = d()(h.a.add("/wscshop/showcase/shop-ranking-list", {
              type: Q
            }), "h5", A);
            o.default.$native.navigateTo({
              url: "/pages/common/webview-page/index?src=" + encodeURIComponent(Z)
            })
          }
        } else if ("video_number_dynamic" === l) {
          var {} = e, ee = Object(i.a)(e.videoDynamicParams, k);
          (e => {
            var a = _(e);
            Object(v.a)().log({
              et: "click",
              ei: "wxvideo_video_click",
              en: "视频号动态点击",
              params: a
            })
          })(e), o.default.$native.openChannelsActivity && o.default.$native.openChannelsActivity(Object(n.a)({}, ee, {
            success: () => {
              (e => {
                var a = _(e);
                Object(v.a)().log({
                  et: "custom",
                  ei: "wxvideo_video_jump_success",
                  en: "视频号动态跳转成功",
                  params: a
                })
              })(e)
            },
            fail: a => {
              ((e, a) => {
                var t = _(e);
                Object(v.a)().log({
                  et: "custom",
                  ei: "wxvideo_video_jump_fail",
                  en: "视频号动态跳转失败",
                  params: Object(n.a)({}, t, {
                    error_msg: null == a ? void 0 : a.errMsg
                  })
                })
              })(e, a)
            }
          }))
        } else if ("storelist" === l || "nearby_store_way" === l) o.default.$native.navigateTo({
          url: "/packages/shop/physical-store/index"
        });
        else if ("goods_classify" === l) t.navigate("CommonWebview", Object(n.a)({
          src: E
        }, G));
        else if (Object.values(f.c).includes(l)) {
          var {
            context: ae
          } = a;
          S(e, ae)
        } else ["booking_mall", "express_mall"].includes(l) && Object(s.default)({
          method: "GET",
          path: "wscdeco/decorate-api/getMallFeatureByType.json",
          data: {
            type: l
          }
        }).then(e => {
          var {
            alias: a
          } = e;
          a ? t.navigate("Feature", {
            alias: a
          }) : Object(r.a)("未启用相关微页面")
        })
      }
    }
  }
}));