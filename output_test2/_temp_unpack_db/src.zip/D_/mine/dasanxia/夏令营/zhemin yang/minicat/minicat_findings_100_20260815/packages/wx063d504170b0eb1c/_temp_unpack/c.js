exports.ids = [1], exports.modules = {
  "+165": function(e, t) {
    e.exports = function(e, t) {
      return e.has(t)
    }
  },
  "+Iya": function(e, t, n) {
    n.d(t, "a", function() {
      return i
    });
    var r = n("Fcif"),
      a = n("0hwI"),
      i = function(e) {
        return void 0 === e && (e = {}), a.a.get({
          url: "/wscdeco/tee/goodsByTagAlias.json",
          data: Object(r.a)({}, e, {
            isShowPeriod: 1
          })
        })
      }
  },
  "+fxQ": function(e, t, n) {
    n.d(t, "a", function() {
      return i
    }), n.d(t, "b", function() {
      return o
    }), n.d(t, "c", function() {
      return s
    });
    var r = n("YeA1"),
      {
        dmc: a
      } = Object(r.a)(),
      i = {
        REQUEST: "request",
        DOWNLOAD: "download",
        UPLOAD: "upload",
        WS_REQUEST: "wsRequest",
        WEBVIEW: "webview"
      },
      o = e => a.domain.readDomain(e).then(e => "https://" + e.domain),
      s = function(e, t) {
        return void 0 === t && (t = i.WEBVIEW), a.transformDomain(e, {
          priorityCache: !0,
          group: t
        })
      }
  },
  "/3Ts": function(e, t, n) {
    n.d(t, "a", function() {
      return a
    });
    var r = n("Fcif"),
      a = (e, t) => {
        var n = JSON.parse(JSON.stringify(e));
        for (var a in t) e[a] && null === t[a] ? delete n[a] : (e[a] || t[a] && t[a]._assign) && (delete t[a]._assign, n[a] = Object(r.a)({}, e[a] || {}, t[a]));
        return n
      }
  },
  "/pw/": function(e, t, n) {
    n.d(t, "a", function() {
      return o
    });
    var r = n("LniI"),
      a = n.n(r),
      i = n("Rz+h");
    class o {
      constructor(e) {
        this.ctx = e.ctx
      }
    }
    o.widgets = {
      Main: a.a
    }, o.lambdas = {
      jumpToLink: i.a
    }
  },
  "03az": function(e, t, n) {
    n.d(t, "d", function() {
      return r
    }), n.d(t, "a", function() {
      return a
    }), n.d(t, "c", function() {
      return o
    }), n.d(t, "b", function() {
      return s
    });

    function r(e) {
      return "[object String]" == Object.prototype.toString.call(e) ? new Date(e.replace(/-/g, "/")) : new Date(e)
    }

    function a(e, t) {
      var n = i(e),
        r = i(t);
      return Math.floor((r.getTime() - n.getTime()) / 864e5) + 1
    }

    function i(e) {
      var t = r(e);
      return t.setHours(0), t.setMinutes(0), t.setSeconds(0), t.setMilliseconds(0), t
    }

    function o(e) {
      var t = e.getMonth() + 1;
      t = 1 === t.toString().length ? "0" + t : t;
      var n = e.getDate();
      return t + "月" + (n = 1 === n.toString().length ? "0" + n : n) + "日"
    }

    function s(e, t) {
      var n = {
        "M+": e.getMonth() + 1,
        "d+": e.getDate(),
        "h+": e.getHours(),
        "m+": e.getMinutes(),
        "s+": e.getSeconds(),
        "q+": Math.floor((e.getMonth() + 3) / 3),
        S: e.getMilliseconds()
      };
      for (var r in /(y+)/.test(t) && (t = t.replace(RegExp.$1, (e.getFullYear() + "").substr(4 - RegExp.$1.length))), n) new RegExp("(" + r + ")").test(t) && (t = t.replace(RegExp.$1, 1 == RegExp.$1.length ? n[r] : ("00" + n[r]).substr(("" + n[r]).length)));
      return t
    }
  },
  "0KRy": function(e, t, n) {
    var r = n("LSEb")(n("s3UK"), "Map");
    e.exports = r
  },
  "0WZd": function(e, t, n) {
    function r(e) {
      return e ? 1 : 0
    }

    function a(e) {
      return new Promise(function(t) {
        return setTimeout(function() {
          return t()
        }, e)
      })
    }

    function i(e, t) {
      return !(!Array.isArray(e) || !Array.isArray(t) || e.length !== t.length || e.slice().sort().join("") !== t.slice().sort().join(""))
    }
    n.d(t, "d", function() {
      return r
    }), n.d(t, "c", function() {
      return a
    }), n.d(t, "b", function() {
      return i
    }), n.d(t, "a", function() {
      return s
    });
    var o = n("QxN7");

    function s(e) {
      var t = e.allowDenyCustom,
        n = e.scene,
        r = e.authTypeList,
        a = e.authAllowDenyMap;
      return !(r || []).includes(o.AuthType.PROTOCOL) && (n ? function(e) {
        var t = e.authTypeList,
          n = e.authAllowDenyMap;
        if (!t || 0 === t.length) return !1;
        if (t.includes(o.AuthType.PROTOCOL)) return !1;
        var r = n || {};
        return 1 === t.length ? !!r[t[0]] : !(2 !== t.length || !t.includes(o.AuthType.MOBILE) || !t.includes(o.AuthType.NICKNAME_AND_AVATAR)) && !(!r.mobile || !r.nicknameAndAvatar)
      }({
        authTypeList: r,
        authAllowDenyMap: a
      }) : !!t)
    }
  },
  "0i4I": function(e, t, n) {
    n.d(t, "a", function() {
      return i
    });
    var r = Behavior({
        methods: {
          $emit() {
            this.triggerEvent(...arguments)
          },
          set(e, t) {
            return this.setData(e, t), new Promise(e => wx.nextTick(e))
          },
          getRect(e, t) {
            return new Promise(n => {
              wx.createSelectorQuery().in(this)[t ? "selectAll" : "select"](e).boundingClientRect(e => {
                t && Array.isArray(e) && e.length && n(e), !t && e && n(e)
              }).exec()
            })
          }
        }
      }),
      a = {
        ancestor: {
          linked(e) {
            this.parent = e
          },
          unlinked() {
            this.parent = null
          }
        },
        descendant: {
          linked(e) {
            this.children = this.children || [], this.children.push(e)
          },
          unlinked(e) {
            this.children = (this.children || []).filter(t => t !== e)
          }
        }
      };

    function i(e) {
      void 0 === e && (e = {});
      var t, n, i, o = {};
      t = e, n = o, i = {
        data: "data",
        props: "properties",
        mixins: "behaviors",
        methods: "methods",
        beforeCreate: "created",
        created: "attached",
        mounted: "ready",
        relations: "relations",
        destroyed: "detached",
        watch: "observers",
        classes: "externalClasses"
      }, Object.keys(i).forEach(e => {
        t[e] && (n[i[e]] = t[e])
      });
      var {
        relation: s
      } = e;
      s && function(e, t, n) {
        var {
          type: r,
          name: i,
          linked: o,
          unlinked: s,
          linkChanged: c
        } = n, {
          beforeCreate: u,
          destroyed: d
        } = t;
        "descendant" === r && (e.created = function() {
          u && u.bind(this)(), this.children = this.children || []
        }, e.detached = function() {
          this.children = [], d && d.bind(this)()
        }), e.relations = Object.assign(e.relations || {}, {
          ["../" + i + "/index"]: {
            type: r,
            linked(e) {
              a[r].linked.bind(this)(e), o && o.bind(this)(e)
            },
            linkChanged(e) {
              c && c.bind(this)(e)
            },
            unlinked(e) {
              a[r].unlinked.bind(this)(e), s && s.bind(this)(e)
            }
          }
        })
      }(o, e, s), o.externalClasses = o.externalClasses || [], o.externalClasses.push("custom-class"), o.behaviors = o.behaviors || [], o.behaviors.push(r), e.field && o.behaviors.push("wx://form-field"), o.properties && Object.keys(o.properties).forEach(e => {
        Array.isArray(o.properties[e]) && (o.properties[e] = null)
      }), o.options = {
        multipleSlots: !0,
        addGlobalClass: !0
      }, Component(o)
    }
  },
  "0lqJ": function(e, t, n) {
    n.d(t, "a", function() {
      return a
    });
    var r = n("xih6");

    function a() {
      var e = getCurrentPages() || [],
        t = e[e.length - 1] || {},
        n = Object(r.a)(),
        a = getApp().globalData.tabbarOriginList,
        i = void 0 === a ? [] : a,
        o = n.findIndex(function(e) {
          return ("/" + t.route).startsWith(e)
        });
      return o === n.length - 1 && i.length ? i.length - 1 : o
    }
  },
  "1F1z": function(e, t, n) {
    var r = n("jA1y"),
      a = n("taYb"),
      i = getApp(),
      o = {},
      s = {},
      c = Object.prototype.hasOwnProperty,
      u = !1,
      d = !0;

    function l(e, t) {
      void 0 === t && (t = {});
      var {
        useCache: n = !1,
        singleRequest: r = !0
      } = t;
      return n && c.call(o, e) ? Promise.resolve(o[e]) : new Promise((t, a) => {
        u && r || (u = !0, i.carmen({
          api: "weapp.wsc.item.detail/1.0.0/get",
          query: {
            alias: e,
            fans_type: i.getFansType()
          },
          success: r => {
            u = !1, n && (o[e] = r), r.dataVersion = "v1", t(r)
          },
          fail: e => {
            u = !1, a(e.msg || "获取商品信息失败")
          }
        }))
      })
    }
    t.a = {
      getSkuDataIron: function(e, t) {
        void 0 === t && (t = {});
        var {
          useCache: n = !1
        } = t;
        return n && c.call(s, e) ? Promise.resolve(s[e]) : i.request({
          path: "v2/showcase/sku/skudata.json",
          query: {
            alias: e,
            oid: i.getOfflineId()
          }
        }).then(t => (n && (s[e] = t), t))
      },
      getSkuData: function(e, t) {
        if (void 0 === t && (t = {}), !d) return l(e, t);
        var {
          useCache: n = !1,
          singleRequest: s = !0,
          activityTypes: p
        } = t, {
          goodsIdForBirthday: h = ""
        } = t;
        return n && c.call(o, e) ? Promise.resolve(o[e]) : u && s ? void 0 : (u = !0, r.c({
          path: "/wscshop/sku/skudata.json",
          data: {
            alias: e,
            fans_type: i.getFansType(),
            offlineId: i.getOfflineId(),
            bizScene: "goods_sku_component",
            activityTypes: p,
            isCombo: !0,
            birthdayScene: "WEAAPP_DECORATE_GOODS",
            goodsIdForBirthday: h
          }
        }).then(r => (u = !1, r && !1 === r.value ? (d = !1, l(e, t)) : (n && (o[e] = r), function(e, t) {
          var n = {},
            {
              price: r,
              quota: i,
              quotaUsed: o,
              itemDataModel: {
                itemId: s,
                isVirtual: c,
                goodsType: u,
                title: d,
                startSaleNum: l,
                pictures: p,
                origin: h,
                validityType: f,
                startSoldTime: g
              },
              preSaleExtraModel: v,
              itemActivitySpuModels: m,
              maxPrice: y,
              minPrice: b,
              option: {
                hideCart: _ = !1
              } = {}
            } = e,
            O = {};
          if (n.sku = a.a.toSnakeCase(e, !1), v) {
            var {
              skuDepositModels: S = [],
              deposit: w,
              maxDeposit: I,
              minDeposit: P
            } = v;
            O.extend = a.a.toSnakeCase(v), void 0 !== w && (O.deposit = {
              deposit: w,
              max: I,
              min: P
            });
            var k = {};
            S.reduce((e, t) => (e[t.skuId] = t.deposit, e), k), n.sku.list.forEach(e => (k[e.id] && (e.deposit = k[e.id]), e))
          }
          n.sku = Object.assign(n.sku, O, {
            goods_type: u,
            max_price: y / 100 + "",
            min_price: b / 100 + ""
          }), n.sku.list.forEach(e => {
            e.price = e.price / 100 + ""
          }), n.brief = {
            item_id: s,
            title: d,
            presale: v ? 1 : 0,
            presale_info_new: n.sku.pre_sale_extra_model,
            quota: i,
            quota_used: o,
            start_sale_num: l,
            is_virtual: c,
            picture: p,
            alias: t,
            price: r,
            origin: h,
            hide_shopcart: +_,
            startSoldTime: g
          }, 3 == +c && (n.virtual = {
            validity_type: f
          });
          if (m && m[0]) {
            var {
              type: j,
              price: x,
              minPrice: T,
              maxPrice: E,
              list: A = [],
              oldPrice: C,
              priceTitle: D
            } = m[0];
            x !== C && (n.activity = {
              goods_preference: {
                show_price: x,
                price_range: {
                  min: T / 100 + "",
                  max: E / 100 + ""
                },
                type: j,
                skus: A.reduce((e, t) => (e[t.id] = {
                  price: t.price / 100 + ""
                }, e), {}),
                quota: i,
                quota_used: o,
                priceTitle: D
              }
            })
          }
          return n.components = [{
            picture: p,
            type: "config",
            is_virtual: c
          }], n.item_sale_prop_list = n.sku.item_sale_prop_list, n
        }(r, e)))).catch(e => (u = !1, i.logger.requestError({
          name: "common-sku-error",
          message: e.msg || "获取商品信息失败",
          alert: "warn",
          detail: e
        }), Promise.reject(e.msg || "获取商品信息失败"))))
      },
      getActivity: function(e) {
        return i.request({
          path: "/wscshop/ump/activityInfo/activity.json",
          query: {
            goods_id: e
          }
        })
      }
    }
  },
  "1LD1": function(e, t, n) {
    var r;
    ! function(e) {
      e.IOS = "ios", e.ANDROID = "android", e.UNKNOWN = "unknown"
    }(r || (r = {}))
  },
  "1nOt": function(e, t, n) {
    n.d(t, "a", function() {
      return a
    });
    var r = n("ONqW"),
      a = function(e) {
        void 0 === e && (e = {});
        var {
          freightInsurance: t,
          supportFreightInsurance: n
        } = e;
        Object(r.a)().log({
          et: "custom",
          ei: "view_freight_insurance_data",
          en: "包退运费时间",
          params: {
            freightInsurance: t,
            supportFreightInsurance: n,
            typeFreightInsurance: typeof t
          }
        })
      }
  },
  "2Dtx": function(e, t, n) {
    function r(e) {
      if (!e) return "";
      var t = "";
      for (var n in e) {
        if (Object.prototype.hasOwnProperty.call(e, n)) e[n] && (t += n + ":" + e[n] + ";")
      }
      return t
    }
    n.d(t, "a", function() {
      return r
    })
  },
  "2Pst": function(e, t, n) {
    n.d(t, "a", function() {
      return s
    });
    var r = n("EYwr"),
      a = n.n(r),
      i = n("vXaX"),
      o = n.n(i);
    class s {
      constructor(e) {
        this.ctx = e.ctx, this.ctx.process.define("showYZIm", e => {})
      }
    }
    s.components = {
      MessageContactButton: a.a
    }, s.widgets = {
      MessageContact: o.a
    }
  },
  "2bgu": function(e, t, n) {
    n.d(t, "b", function() {
      return i
    }), n.d(t, "a", function() {
      return o
    });
    var r = n("9ZMt"),
      a = "https://h5.youzan.com";

    function i(e) {
      var t, n;
      e.url = e.needPrefixDomain ? (t = e.url, void 0 === n && (n = a), n && ! function(e) {
        return 0 === e.indexOf("http") || 0 === e.indexOf("//")
      }(t) ? n + t : (t.startsWith("http://") && (t = t.replace("http://", "https://")), t)) : e.url, r.default.navigate(e)
    }
    var o = {
      init: function() {}
    }
  },
  "31OO": function(e, t, n) {
    var r = n("Fcif"),
      a = n("+66q"),
      i = (e, t) => {
        var {
          activities: n
        } = t || {}, a = (n || []).find(t => t.type === e.type);
        return a ? Object(r.a)({}, a.activityInfo, {
          activityInfo: a.activityInfo
        }, e) : e
      },
      o = n("xyw3"),
      s = (e, t, n) => t === n ? Object(o.a)(e).toYuan() : Object(o.a)(t).toYuan() + "-" + Object(o.a)(n).toYuan(),
      c = n("3m7Z"),
      u = {
        containerStyle: "display: inline-flex; align-items: center; height: 20px; padding: 0 var(--theme-goods-price-tag-padding, 6px); color: var(--ump-main-text, #ffffff); background: var(--ump-main-bg, #323233); border-radius:1rem;",
        preStyle: "font-size: 12px;",
        textStyle: "font-size: 16px; font-family: var(--price-font-family);font-weight: var(--theme-common-price-font-weight) 600; padding: 0;",
        sufStyle: "font-size: 12px; margin-left: 2px;",
        umpType: "coupon"
      },
      d = (e, t, n) => {
        var a = t.replace("券后￥", "").split(" ");
        return Object(r.a)({}, u, {
          preText: e,
          text: a[0],
          sufText: a[1] || "",
          type: n
        })
      },
      l = (a.f, {
        [a.a.HELPCUT]: e => {
          var {
            activityId: t
          } = e;
          return {
            type: a.a.HELPCUT,
            identification: t
          }
        },
        [a.a.INSOURCING_FISSION]: e => {
          var {
            umpAlias: t
          } = e;
          return {
            type: a.a.INSOURCING_FISSION,
            identification: t
          }
        },
        [a.a.LUCKYDRAW_GROUP]: e => {
          var {
            activityId: t
          } = e;
          return {
            type: a.a.LUCKYDRAW_GROUP,
            identification: t
          }
        },
        [a.a.SECKILL]: e => {
          var {
            umpAlias: t
          } = e;
          return {
            type: a.a.SECKILL,
            identification: t
          }
        }
      }),
      p = [a.k.SECKILL],
      h = (e, t, n, i, o, s) => {
        var u;
        u = s.umpSkuData;
        var {
          currentActivity: l = {},
          umpActivity: h = {}
        } = e, f = Object.keys(u).reduce((e, n) => (e[n] = Object(r.a)({}, t.goods, u[n], p.includes(n) ? {
          disableSoldoutSku: !0
        } : {}), e), t);
        return i && (f = ((e, t, n, i) => {
          var {
            type: o,
            isStart: s
          } = i, u = {};
          return Object.keys(e).forEach(i => {
            var l = e[i],
              {
                noneSku: p,
                list: h
              } = l,
              {
                voucherPreferenceCopyWriting: f,
                couponSkuPrices: g = {},
                couponPreferenceModels: [{
                  isNewcomerVoucher: v = !1
                }]
              } = t,
              m = h,
              y = l.priceTags || [],
              b = Array.from(new Set([...(n.tags || []), ...(l.priceTags || [])])),
              _ = b.reduce((e, t) => Object(r.a)({}, e, {
                [t.type]: t
              }), {}),
              O = !!o,
              {
                needMergeTag: S = {},
                restTags: w
              } = (e => {
                var t = e.findIndex(e => Object.keys(a.l).indexOf(e.type) > -1),
                  n = [...e.slice(0, t), ...e.slice(t + 1)];
                return {
                  needMergeTag: e[t],
                  restTags: n
                }
              })(b),
              I = O ? _[o] : S,
              P = !1,
              k = "券后￥",
              j = "coupon";
            I && (P = Object.keys(a.l).indexOf(I.type) > -1), P && O && (k = a.l[I.type], j = I.type);
            var x = f;
            v && (k = "新人专享￥", x = f.replace(/新人专享￥|券后￥/g, "")), I = d(k, x, j);
            var T = Object(c.e)(g);
            p || (m = h.map(e => {
              var {
                skuId: t
              } = e;
              if (!T[t]) return e;
              var {
                priceTitle: n
              } = T[t], a = v ? n.replace(/新人专享￥/g, "") : n, o = d(k, a, j), s = Object(r.a)({}, e, {
                priceTitle: [o],
                tags: [o],
                tagsConfig: {
                  [I.type]: o
                },
                id: t
              });
              return "depositExpansion" === i && (s.tagsConfig[i + "Extra"] = {
                text: e.priceTitle
              }), s
            })), i !== a.a.GROUP_ON && i !== a.a.TIMELIMITED_DISCOUNT || s || (I = {
              text: a.m[o]
            });
            var E = O ? [I] : [I, ...w];
            u[i] = Object(r.a)({}, l, {
              priceTags: E,
              tags: E,
              list: m
            }), a.g.indexOf(i) > -1 && (u[i].priceTags = [...y, I], u[i].tags = [I])
          }), u
        })(f, h.coupon, n, l)), o && (f = (e => {
          var {
            goods: t = {}
          } = e, {
            priceTags: n = []
          } = t, a = [...n, {
            text: "送礼"
          }];
          return Object(r.a)({}, e, {
            gift: Object(r.a)({}, t, {
              activityInfo: {
                activityType: 99999
              },
              priceTags: a,
              tags: a
            })
          })
        })(f)), f
      };
    t.a = {
      state: {
        goodsActivity: {},
        umpActivity: null,
        alias: "",
        kdtId: 0,
        query: {},
        goodsBaseInfo: {},
        goodsEstimatePriceData: {},
        marketing: {},
        currentActivity: {}
      },
      getActions: e => ({
        setActivityInfoForPrice(e) {
          var {
            umpType: t
          } = e, n = l(t), r = n ? n(e) : {};
          this.setCtxData(r, "activityInfoForPrice")
        },
        setUmpShareIcon(t) {
          var n = (this.marketing.activities || []).find(e => e.type === a.a.SHARE_ENCOURAGE);
          return n ? (e.logger && e.logger.log({
            et: "custom",
            ei: "view_share_activity",
            en: "分享有礼活动曝光",
            params: {
              activityId: n.activityId
            }
          }), Object(r.a)({}, t, {
            color: "var(--ump-icon, #323233)",
            icon: "point-gift",
            wordStyle: "color: var(--ump-icon, #323233)",
            animation: !0
          })) : t
        },
        parseUmpActivies(t) {
          try {
            var n, {
                sku: o = {},
                priceInfo: c = {},
                activity: u = {},
                marketing: l = {},
                pageFeature: p = {},
                ump: f
              } = t,
              g = ((e, t) => {
                var n;
                n = e.ump;
                var {
                  umpActivity: r,
                  marketActivity: o,
                  promotionActivity: s
                } = n, {
                  currentActivity: c
                } = n, u = ["seckill", "tuan", "fCode", "auction"];
                return Object.keys(r).forEach(t => {
                  var n = "ladderGroupOn" === t ? "groupOn" : t;
                  a.f.indexOf(t) > -1 && u.includes(n) && (e.pageFeature.showMultiStoreRecommend = !1)
                }), c = i(c, e.marketing), Object.keys(o).forEach(t => {
                  o[t] = i(o[t], e.marketing)
                }), {
                  umpActivity: r,
                  currentActivity: c,
                  marketActivity: o,
                  promotionActivity: s
                }
              })(t);
            this.goodsActivity = u;
            var v = [],
              {
                umpActivity: m,
                currentActivity: y = {}
              } = g;
            Object.getOwnPropertyNames(m).forEach(e => {
              v.push((e => {
                var {
                  type: t = "",
                  couponPreferenceModels: n = [],
                  id: r,
                  activityId: i,
                  alias: o,
                  activityAlias: s
                } = e;
                switch (t) {
                  case a.a.COUPON:
                    return {
                      act_id: n.map(e => e.id).join(","), act_type: t
                    };
                  default:
                    return {
                      act_type: t, act_id: r || i || o || s || ""
                    };
                }
              })(m[e]))
            }), e.logger.log({
              et: "custom",
              ei: "view_goods",
              params: {
                ump_params: v
              }
            }), n = f.isCoupon;
            var {
              showGiftBtn: b
            } = p, _ = h(g, o, c, n, b, f), O = ((e, t, n, i, o) => {
              var {
                currentActivity: c = {},
                umpActivity: u = {}
              } = e, {
                type: l,
                subType: p,
                ladderPrice: h = {}
              } = c, f = p || l;
              if (!f) {
                if (i) {
                  var {
                    coupon: g = {}
                  } = u, {
                    voucherPreferenceCopyWriting: v,
                    couponPreferenceModels: [{
                      isNewcomerVoucher: m = !1
                    }]
                  } = g, {
                    tags: y = []
                  } = n;
                  if (y.forEach((e, t) => {
                      Object.keys(a.l).indexOf(e.type) > -1 && (y[t] = d(a.l[e.type], v, e.type))
                    }), m) {
                    var b = v.replace(/新人专享￥|券后￥/g, "");
                    y = [d("新人专享￥", b, "coupon")]
                  } else 0 === y.length && v && (y = [d("券后￥", v, "coupon")]);
                  return Object(r.a)({}, n, {
                    tags: y
                  })
                }
                return n
              }
              var _ = {},
                O = "ladderGroupOn" === f;
              if (O) {
                var S = -1,
                  w = -1;
                Object.keys(h).forEach(e => {
                  h[e].forEach(e => {
                    var {
                      skuPrice: t
                    } = e;
                    S = S < 0 ? t : Math.min(S, t), w = w < 0 ? t : Math.max(w, t)
                  })
                }), _ = {
                  ladderMinPrice: S,
                  ladderMaxPrice: w
                }
              }
              var I = t[f],
                {
                  price: P,
                  minPrice: k,
                  maxPrice: j,
                  oldPrice: x,
                  oldMinPrice: T,
                  oldMaxPrice: E,
                  tags: A = [],
                  maxDepositPrice: C,
                  minDepositPrice: D,
                  startPrice: M,
                  stockNum: N
                } = I,
                L = !!f && a.i.indexOf(f) > -1,
                U = n.hideStock || ["seckill", "helpCut", "auction"].indexOf(f) > -1,
                R = Object(r.a)({
                  hideStock: U,
                  showPriceBlock: !!(() => {
                    var {
                      presale: e
                    } = o || {};
                    if (!!e) {
                      var {
                        preSaleEnd: t
                      } = e, {
                        joinActivityStatus: n
                      } = c;
                      return t < Date.now() && +n === a.d.NOT_PARTICIPATE
                    }
                    return !1
                  })() || !L,
                  price: s(P, k, j),
                  minPrice: O ? _.ladderMinPrice : k,
                  maxPrice: O ? _.ladderMaxPrice : j,
                  originPrice: s(x, T, E),
                  depositPrice: s(D, D, C),
                  originMinPrice: T,
                  originMaxPrice: E,
                  oldMinPrice: T,
                  oldMaxPrice: E,
                  tags: f === a.a.FCODE ? [] : A,
                  startPrice: M
                }, _, {
                  stockNum: N
                }),
                B = {};
              return f === a.a.FCODE && (B.soldNum = 0, B.stockNum = 1), Object(r.a)({}, n, R, B)
            })(g, _, c, n, u);
            this.marketing = l, this.currentActivity = y;
            var S = l.activities || [],
              w = S.find(e => e.type === a.a.FANS_BENEFIT),
              I = S.find(e => e.type === a.a.WECOM_FANS_BENEFIT),
              P = S.find(e => e.type === a.a.SHARE_ENCOURAGE);
            return this.setCtxData(Object(r.a)({}, g, {
              fansBenefit: w,
              wecomFansBenefit: I,
              isGroupOn: y.type === a.a.GROUP_ON,
              seActivity: P,
              buttonUmpTimelimitModel: this.marketing.buttonUmpTimelimitModel,
              isCoupon: n,
              isNotPresent: y.type !== a.a.PRESENT_EXCHANGE,
              marketing: this.marketing
            })), Object(r.a)({}, t, {
              umpActivityData: g,
              sku: _,
              priceInfo: O
            })
          } catch (t) {
            throw t.message = (k = "处理营销数据异常", j = "parseUmpActivies", x = t.message, "goods-detail_ump_page-setup: " + k + ", " + j + ", " + x.toString()), e.hummer && e.hummer.capture(t), t
          }
          var k, j, x
        }
      })
    }
  },
  "3Hke": function(e, t, n) {
    n.d(t, "a", function() {
      return u
    });
    var r = n("SVbq"),
      a = n("mQXz"),
      i = n.n(a),
      o = n("w2Y9"),
      s = n.n(o),
      c = n("u8kV");

    function u() {
      var e = Object(c.d)(),
        t = "/" + encodeURIComponent(s.a.add(e.route, i()(e.options || {}, "subKdtId")));
      return Object(r.m)({
        redirectUrl: t
      })
    }
  },
  "3XjN": function(e, t, n) {
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.default = void 0;
    var r, a = (r = n("O1uH")) && r.__esModule ? r : {
      default: r
    };
    var i = function(e, t) {
      return Array.isArray(e) ? 0 !== e.length ? (0, a.default)(e, t, function(e, t) {
        return e > t
      }) : void 0 : e
    };
    t.default = i, e.exports = t.default
  },
  "3hrn": function(e, t) {},
  "3m7Z": function(e, t, n) {
    n.d(t, "b", function() {
      return i
    }), n.d(t, "e", function() {
      return o
    }), n.d(t, "d", function() {
      return s
    }), n.d(t, "a", function() {
      return c
    }), n.d(t, "c", function() {
      return u
    });
    var r = n("Fcif"),
      a = n("+66q"),
      i = function(e) {
        void 0 === e && (e = {});
        var t, {
            startTime: n = 0,
            endTime: r = 0,
            serverDeltaTime: a = 0,
            current: i = +new Date
          } = e,
          o = +new Date(n),
          s = +new Date(r),
          c = o - a,
          u = s - a,
          d = 0,
          l = !1,
          p = !1;
        return c - i > 0 ? (t = "距开始仅剩", d = c) : u - i > 0 ? (t = "距结束仅剩", d = u, l = !0) : (t = "活动已结束", d = i, l = !0, p = !0), {
          startAt: c,
          endAt: u,
          countDownDesc: t,
          endTimeAt: d,
          isStart: l,
          isEnd: p,
          serverStartAt: o,
          serverEndAt: s,
          startTime: n,
          endTime: r
        }
      },
      o = function(e) {
        return void 0 === e && (e = []), e.reduce((e, t) => Object(r.a)({}, e, {
          [t.skuId]: t
        }), {})
      },
      s = e => {
        var {
          orderActivityInfo: t
        } = e, {
          code: n,
          id: r,
          alias: a,
          type: i
        } = t;
        return {
          activityType: i,
          activityAlias: a,
          activityId: r,
          activityCode: n
        }
      },
      c = (e, t) => {
        var {
          skuPrices: n,
          ladderPrice: i,
          skuStocks: c,
          spuPrice: u,
          spuStock: d,
          type: l
        } = e, {
          noneSku: p,
          list: h
        } = t, f = o(n), g = o(c), v = o(h), m = h, y = 1 / 0, b = -1 / 0, _ = i || {};
        Object.keys(_).forEach(e => {
          _[e].forEach(e => {
            var {
              skuPrice: t
            } = e;
            y = Math.min(y, t), b = Math.max(b, t)
          })
        }), p || (m = h.map(e => {
          var {
            skuId: t
          } = e, n = _[t], i = {}, {
            isActivitySku: o
          } = f[t] || {}, s = {};
          if (!1 === o && (s = {
              priceTitle: [{
                text: "",
                type: l
              }],
              tags: []
            }), n) {
            var c = 1 / 0,
              u = -1 / 0;
            n.forEach(e => {
              c = Math.min(c, e.skuPrice), u = Math.max(u, e.skuPrice)
            }), i.minPrice = c, i.maxPrice = u
          }
          return Object(r.a)({}, e, {
            oldPrice: v[t].price
          }, f[t], g[t], {
            id: t
          }, i, {
            priceTitle: a.m[l]
          }, s)
        }));
        var {
          minPrice: O,
          oldMinPrice: S,
          oldMaxPrice: w,
          price: I
        } = t, P = -1 / 0, k = t.price;
        S = 0 === S ? 1 / 0 : S;
        var j = 0,
          x = 0;
        return p ? (t.collectionPrice = t.price, S = w = k, P = Math.max(b, u.price), O = Math.min(y, u.price), I = u.price, j = d ? d.stockNum : t.stockNum, x = t.soldNum) : m.forEach(e => {
          t.stockNum > 0 && 0 === e.stockNum && l !== a.k.LIMITED_SECKILL || (O = Math.min(O, e.price), P = Math.max(P, e.price), S = Math.min(S, e.oldPrice), w = Math.max(w, e.oldPrice), j += e.stockNum, x += e.soldNum)
        }), O === P && (I = O), t.price = t.price || O || P || 0, isFinite(w) || (w = 0), isFinite(S) || (S = 0), isFinite(P) && !Number.isNaN(P) || (P = t.maxPrice), Object(r.a)({}, t, e, {
          list: m,
          minPrice: Math.min(O, y),
          price: I,
          maxPrice: P,
          oldPrice: k,
          oldMinPrice: S,
          oldMaxPrice: w,
          ladderMinPrice: y,
          ladderMaxPrice: b,
          activityInfo: s(e),
          stockNum: j,
          soldNum: x
        })
      },
      u = (e, t) => {
        var {
          sku: n = {}
        } = e, {
          goods: a = {}
        } = n, {
          limit: i = {}
        } = a, {
          quota: o,
          quotaUsed: s,
          quotaCycle: c
        } = t;
        return Object(r.a)({}, i, {
          quota: o || i.quota,
          quotaUsed: s || i.quotaUsed || 0,
          quotaCycle: c || i.quotaCycle || 0
        })
      }
  },
  "3t/z": function(e, t, n) {
    n.d(t, "a", function() {
      return o
    });
    var r = n("US/N"),
      a = n("tS13"),
      i = n("+66q");

    function o(e, t) {
      var {
        skuId: n,
        kdtId: o,
        num: s,
        isAbleGetCoupons: c = !0
      } = e, {
        isCoupon: u,
        umpActivity: d,
        isGroupOn: l,
        skuShowData: p,
        isGift: h,
        query: f,
        goodsEstimatePriceData: g
      } = t, {
        activityType: v,
        activityAlias: m,
        activityId: y,
        activityCode: b
      } = e, {
        num: _
      } = g;
      i.f.indexOf(v) > -1 && Object.assign(e.commonExtra, {
        activity_type: b || 0,
        activity_id: y,
        activity_alias: m
      }), v === i.a.FCODE && (e.goodsExtra.fcode = f.f_code);
      var O = !h && l && p.skuScene === a.c.SEL_SKU,
        S = null,
        w = !1;
      if (null != g && g.estimatedPriceCoupon) {
        var {
          isHoldCoupon: I
        } = g.estimatedPriceCoupon;
        w = !I && s >= _ && s <= 4
      }
      if (u && !O) {
        var {
          coupon: {
            couponPreferenceModels: P,
            couponSkuPrices: k
          }
        } = d;
        P.length && (S = P[0].alias);
        var j = {};
        (k || []).forEach(e => {
          j[e.skuId] = {
            preferentialCoupon: e.useThresholdAndValueCopywriting,
            activityAlias: e.activityAlias
          }
        }), j[n] && (S = j[n].activityAlias)
      } else if (w) {
        var {
          alias: x
        } = g.estimatedPriceCoupon;
        S = x
      }
      return h && (e.commonExtra.order_type = 1, e.activityType = 0), S && c ? function(e) {
        var {
          alias: t,
          kdtId: n,
          source: a
        } = e;
        return Promise.resolve(r).then(e => e.default({
          path: "/wscgoods/getCoupon.json",
          data: {
            alias: t,
            kdtId: n,
            source: a,
            requestId: t + "-" + new Date().getTime()
          },
          withCredentials: !0
        }))
      }({
        alias: S,
        kdtId: o,
        source: "goods_details_auto_take"
      }).then(() => (e.commonExtra.preToastDesc = "已为你领取1张优惠券，下单享优惠", e)).catch(function(t) {
        void 0 === t && (t = {
          msg: "领取失败"
        });
        var {
          msg: n
        } = t;
        return e.commonExtra.preToastDesc = n, e
      }) : e
    }
  },
  "3uds": function(e, t, n) {
    n.d(t, "d", function() {
      return r
    }), n.d(t, "e", function() {
      return a
    }), n.d(t, "c", function() {
      return i
    }), n.d(t, "b", function() {
      return o
    }), n.d(t, "a", function() {
      return s
    });
    var r = "showcase-container:pulldown-refresh",
      a = "showcase-container:reach-bottom",
      i = "showcase-container:page-show",
      o = "showcase-container:page-hide",
      s = ["hot_words_reference"]
  },
  "3vAz": function(e, t, n) {
    n.d(t, "a", function() {
      return r
    }), n.d(t, "b", function() {
      return a
    });
    var r = {
        timelimitedDiscount: "timelimitedDiscount",
        discountInvite: "discountInvite",
        discount: "discount",
        customerDiscount: "customerDiscount",
        groupOn: "groupOn",
        points: "points",
        luckyDrawGroup: "luckyDrawGroup",
        helpCut: "helpCut",
        tuan: "tuan",
        seckill: "seckill",
        auction: "auction",
        fCode: "fCode",
        present: "present",
        inSourcingFission: "inSourcingFission",
        presale: "presale"
      },
      a = {
        timelimitedDiscount: 0,
        groupOn: 2,
        ladderGroupOn: 2,
        customerDiscount: 1,
        discount: 1,
        deposit: 3,
        depositExpansion: 3,
        fullPresale: 3,
        coupon: 4,
        goods: 4
      }
  },
  "42EB": function(e, t, n) {
    n.d(t, "a", function() {
      return a
    });
    var r = n("Fcif");

    function a(e) {
      void 0 === e && (e = []), this.__webviewMsg || (this.__webviewMsg = {}), e.filter(e => "object" == typeof e && e.type).forEach(e => {
        var {
          type: t,
          payload: n,
          config: a
        } = e;
        "object" != typeof(n = n || a || {}) && (n = {
          payload: n
        }), this.__webviewMsg[t] = Object(r.a)({}, this.__webviewMsg[t] || {}, n)
      })
    }
  },
  "49Kr": function(e, t, n) {
    var r = n("zHBu"),
      a = n("VlGz"),
      i = /^[\x00-\x20\u00a0\u1680\u2000-\u200a\u2028\u2029\u202f\u205f\u3000\ufeff]+/,
      o = /[\n\r\t]/g,
      s = /^[A-Za-z][A-Za-z0-9+-.]*:\/\//,
      c = /:\d+$/,
      u = /^([a-z][a-z0-9.+-]*:)?(\/\/)?([\\/]+)?([\S\s]*)/i,
      d = /^[a-zA-Z]:/;

    function l(e) {
      return (e || "").toString().replace(i, "")
    }
    var p = [
        ["#", "hash"],
        ["?", "query"],
        function(e, t) {
          return g(t.protocol) ? e.replace(/\\/g, "/") : e
        },
        ["/", "pathname"],
        ["@", "auth", 1],
        [NaN, "host", void 0, 1, 1],
        [/:(\d*)$/, "port", void 0, 1],
        [NaN, "hostname", void 0, 1, 1]
      ],
      h = {
        hash: 1,
        query: 1
      };

    function f(e) {
      var t, n = ("undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).location || {},
        r = {},
        a = typeof(e = e || n);
      if ("blob:" === e.protocol) r = new m(unescape(e.pathname), {});
      else if ("string" === a)
        for (t in r = new m(e, {}), h) delete r[t];
      else if ("object" === a) {
        for (t in e) t in h || (r[t] = e[t]);
        void 0 === r.slashes && (r.slashes = s.test(e.href))
      }
      return r
    }

    function g(e) {
      return "file:" === e || "ftp:" === e || "http:" === e || "https:" === e || "ws:" === e || "wss:" === e
    }

    function v(e, t) {
      e = (e = l(e)).replace(o, ""), t = t || {};
      var n, r = u.exec(e),
        a = r[1] ? r[1].toLowerCase() : "",
        i = !!r[2],
        s = !!r[3],
        c = 0;
      return i ? s ? (n = r[2] + r[3] + r[4], c = r[2].length + r[3].length) : (n = r[2] + r[4], c = r[2].length) : s ? (n = r[3] + r[4], c = r[3].length) : n = r[4], "file:" === a ? c >= 2 && (n = n.slice(2)) : g(a) ? n = r[4] : a ? i && (n = n.slice(2)) : c >= 2 && g(t.protocol) && (n = r[4]), {
        protocol: a,
        slashes: i || g(a),
        slashesCount: c,
        rest: n
      }
    }

    function m(e, t, n) {
      if (e = (e = l(e)).replace(o, ""), !(this instanceof m)) return new m(e, t, n);
      var i, s, c, u, h, y, b = p.slice(),
        _ = typeof t,
        O = this,
        S = 0;
      for ("object" !== _ && "string" !== _ && (n = t, t = null), n && "function" != typeof n && (n = a.parse), i = !(s = v(e || "", t = f(t))).protocol && !s.slashes, O.slashes = s.slashes || i && t.slashes, O.protocol = s.protocol || t.protocol || "", e = s.rest, ("file:" === s.protocol && (2 !== s.slashesCount || d.test(e)) || !s.slashes && (s.protocol || s.slashesCount < 2 || !g(O.protocol))) && (b[3] = [/(.*)/, "pathname"]); S < b.length; S++) "function" != typeof(u = b[S]) ? (c = u[0], y = u[1], c != c ? O[y] = e : "string" == typeof c ? ~(h = "@" === c ? e.lastIndexOf(c) : e.indexOf(c)) && ("number" == typeof u[2] ? (O[y] = e.slice(0, h), e = e.slice(h + u[2])) : (O[y] = e.slice(h), e = e.slice(0, h))) : (h = c.exec(e)) && (O[y] = h[1], e = e.slice(0, h.index)), O[y] = O[y] || i && u[3] && t[y] || "", u[4] && (O[y] = O[y].toLowerCase())) : e = u(e, O);
      n && (O.query = n(O.query)), i && t.slashes && "/" !== O.pathname.charAt(0) && ("" !== O.pathname || "" !== t.pathname) && (O.pathname = function(e, t) {
        if ("" === e) return t;
        for (var n = (t || "/").split("/").slice(0, -1).concat(e.split("/")), r = n.length, a = n[r - 1], i = !1, o = 0; r--;) "." === n[r] ? n.splice(r, 1) : ".." === n[r] ? (n.splice(r, 1), o++) : o && (0 === r && (i = !0), n.splice(r, 1), o--);
        return i && n.unshift(""), "." !== a && ".." !== a || n.push(""), n.join("/")
      }(O.pathname, t.pathname)), "/" !== O.pathname.charAt(0) && g(O.protocol) && (O.pathname = "/" + O.pathname), r(O.port, O.protocol) || (O.host = O.hostname, O.port = ""), O.username = O.password = "", O.auth && (~(h = O.auth.indexOf(":")) ? (O.username = O.auth.slice(0, h), O.username = encodeURIComponent(decodeURIComponent(O.username)), O.password = O.auth.slice(h + 1), O.password = encodeURIComponent(decodeURIComponent(O.password))) : O.username = encodeURIComponent(decodeURIComponent(O.auth)), O.auth = O.password ? O.username + ":" + O.password : O.username), O.origin = "file:" !== O.protocol && g(O.protocol) && O.host ? O.protocol + "//" + O.host : "null", O.href = O.toString()
    }
    m.prototype = {
      set: function(e, t, n) {
        var i = this;
        switch (e) {
          case "query":
            "string" == typeof t && t.length && (t = (n || a.parse)(t)), i[e] = t;
            break;
          case "port":
            i[e] = t, r(t, i.protocol) ? t && (i.host = i.hostname + ":" + t) : (i.host = i.hostname, i[e] = "");
            break;
          case "hostname":
            i[e] = t, i.port && (t += ":" + i.port), i.host = t;
            break;
          case "host":
            i[e] = t, c.test(t) ? (t = t.split(":"), i.port = t.pop(), i.hostname = t.join(":")) : (i.hostname = t, i.port = "");
            break;
          case "protocol":
            i.protocol = t.toLowerCase(), i.slashes = !n;
            break;
          case "pathname":
          case "hash":
            if (t) {
              var o = "pathname" === e ? "/" : "#";
              i[e] = t.charAt(0) !== o ? o + t : t
            } else i[e] = t;
            break;
          case "username":
          case "password":
            i[e] = encodeURIComponent(t);
            break;
          case "auth":
            var s = t.indexOf(":");
            ~s ? (i.username = t.slice(0, s), i.username = encodeURIComponent(decodeURIComponent(i.username)), i.password = t.slice(s + 1), i.password = encodeURIComponent(decodeURIComponent(i.password))) : i.username = encodeURIComponent(decodeURIComponent(t));
        }
        for (var u = 0; u < p.length; u++) {
          var d = p[u];
          d[4] && (i[d[1]] = i[d[1]].toLowerCase())
        }
        return i.auth = i.password ? i.username + ":" + i.password : i.username, i.origin = "file:" !== i.protocol && g(i.protocol) && i.host ? i.protocol + "//" + i.host : "null", i.href = i.toString(), i
      },
      toString: function(e) {
        e && "function" == typeof e || (e = a.stringify);
        var t, n = this,
          r = n.host,
          i = n.protocol;
        i && ":" !== i.charAt(i.length - 1) && (i += ":");
        var o = i + (n.protocol && n.slashes || g(n.protocol) ? "//" : "");
        return n.username ? (o += n.username, n.password && (o += ":" + n.password), o += "@") : n.password ? (o += ":" + n.password, o += "@") : "file:" !== n.protocol && g(n.protocol) && !r && "/" !== n.pathname && (o += "@"), (":" === r[r.length - 1] || c.test(n.hostname) && !n.port) && (r += ":"), o += r + n.pathname, (t = "object" == typeof n.query ? e(n.query) : n.query) && (o += "?" !== t.charAt(0) ? "?" + t : t), n.hash && (o += n.hash), o
      }
    }, m.extractProtocol = v, m.location = f, m.trimLeft = l, m.qs = a, e.exports = m
  },
  "4Kfr": function(e, t, n) {
    function r() {
      try {
        var e = getApp(),
          t = (null == getCurrentPages ? void 0 : getCurrentPages()) || [],
          n = t.length > 0 ? t[t.length - 1] : {},
          r = (null == n ? void 0 : n.options) || {};
        if (null != r && r.from_params) return (null == e ? void 0 : e.getBuyerId()) || ""
      } catch (e) {}
      return ""
    }
    n.d(t, "a", function() {
      return r
    })
  },
  "4XQZ": function(e, t, n) {
    n.d(t, "a", function() {
      return a
    });
    var r = n("wB7X"),
      a = {
        show: Boolean,
        title: String,
        message: String,
        useSlot: Boolean,
        className: String,
        customStyle: String,
        asyncClose: Boolean,
        messageAlign: String,
        overlayStyle: String,
        useTitleSlot: Boolean,
        showCancelButton: Boolean,
        closeOnClickOverlay: Boolean,
        confirmButtonOpenType: String,
        width: {
          type: null,
          default: 320
        },
        zIndex: {
          type: Number,
          default: 2e3
        },
        confirmButtonText: {
          type: String,
          default: "确认"
        },
        cancelButtonText: {
          type: String,
          default: "取消"
        },
        confirmButtonColor: {
          type: String,
          default: r.f
        },
        cancelButtonColor: {
          type: String,
          default: r.b
        },
        showConfirmButton: {
          type: Boolean,
          default: !0
        },
        overlay: {
          type: Boolean,
          default: !0
        },
        transition: {
          type: String,
          default: "scale"
        },
        isPageDefault: Boolean
      }
  },
  "4a20": function(e, t) {
    e.exports = function(e) {
      return this.__data__.has(e)
    }
  },
  "4cW6": function(e, t, n) {
    n.d(t, "b", function() {
      return a
    }), n.d(t, "a", function() {
      return i
    });
    n("bb6g"), n("Tewj");
    var r = n("Br49"),
      a = (r.a, r.c),
      i = r.b
  },
  "4mhO": function(e, t) {
    e.exports = function(e) {
      return this.__data__.set(e, "__lodash_hash_undefined__"), this
    }
  },
  "5+rW": function(e, t, n) {
    var r = new RegExp("(%[a-f0-9]{2})|([^%]+?)", "gi"),
      a = new RegExp("(%[a-f0-9]{2})+", "gi");

    function i(e, t) {
      try {
        return [decodeURIComponent(e.join(""))]
      } catch (e) {}
      if (1 === e.length) return e;
      t = t || 1;
      var n = e.slice(0, t),
        r = e.slice(t);
      return Array.prototype.concat.call([], i(n), i(r))
    }

    function o(e) {
      try {
        return decodeURIComponent(e)
      } catch (a) {
        for (var t = e.match(r) || [], n = 1; n < t.length; n++) t = (e = i(t, n).join("")).match(r) || [];
        return e
      }
    }
    e.exports = function(e) {
      if ("string" != typeof e) throw new TypeError("Expected `encodedURI` to be of type `string`, got `" + typeof e + "`");
      try {
        return e = e.replace(/\+/g, " "), decodeURIComponent(e)
      } catch (t) {
        return function(e) {
          for (var t = {
              "%FE%FF": "��",
              "%FF%FE": "��"
            }, n = a.exec(e); n;) {
            try {
              t[n[0]] = decodeURIComponent(n[0])
            } catch (e) {
              var r = o(n[0]);
              r !== n[0] && (t[n[0]] = r)
            }
            n = a.exec(e)
          }
          t["%C2"] = "�";
          for (var i = Object.keys(t), s = 0; s < i.length; s++) {
            var c = i[s];
            e = e.replace(new RegExp(c, "g"), t[c])
          }
          return e
        }(e)
      }
    }
  },
  "5HXs": function(e, t, n) {
    function r(e) {
      var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
      if ("string" == typeof e) return (t + e).trim();
      var n = Array.isArray(e) ? e : Object.keys(e).filter(function(t) {
        return e[t]
      });
      return n.reduce(function(e, n) {
        return "".concat(e ? "".concat(e, " ") : "").concat(t + n)
      }, "")
    }
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.default = void 0;
    var a = function(e) {
      var t = e.prefix,
        n = void 0 === t ? "" : t,
        a = e.block,
        i = e.elementPrefix,
        o = void 0 === i ? "__" : i,
        s = e.modifierPrefix,
        c = void 0 === s ? "--" : s;
      return function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
          t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "",
          i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "",
          s = "".concat(n).concat(a),
          u = e ? r(e, s + o) : "",
          d = t && !u ? " ".concat(r(t, s + c)) : "",
          l = t && u ? " ".concat(r(t, u + c)) : "",
          p = i ? " ".concat(r(i)) : "",
          h = e ? u + l : s + d;
        return (h + p).trim()
      }
    };
    t.default = a, e.exports = t.default
  },
  "5JV4": function(e, t, n) {
    n.d(t, "a", function() {
      return d
    });
    var r = n("9ZMt"),
      a = n("MLLI"),
      i = Object(a.b)(),
      o = {
        bottom: 58,
        height: 32,
        left: 278,
        right: 365,
        top: 26,
        width: 87
      },
      s = {
        inited: !1,
        rectInfo: {}
      },
      c = () => {
        var e, {
            statusBarHeight: t = 20,
            system: n
          } = i,
          a = t + (/android/i.test(n) ? 48 : 44);
        try {
          e = r.default.$native.getMenuButtonBoundingClientRect()
        } catch (e) {}
        return e || (e = Object.create(null)), e.top = e.top || a, s.rectInfo = e, s.inited = !0, e
      },
      u = Object.create(null);

    function d() {
      var {
        top: e,
        height: t
      } = u, {
        statusBarHeight: n = 20
      } = i, r = e - n + 6 + t + n;
      return r <= 105 ? r : 105
    }
    Object.keys(o).forEach(e => {
      Object.defineProperty(u, e, {
        get() {
          if (!s.inited || !s.rectInfo[e] && "canUseNav" !== e) {
            var t = c()[e];
            return t || !1 === t ? t : (setTimeout(c, 300), o[e])
          }
          return s.rectInfo[e]
        }
      })
    })
  },
  "5kn2": function(e, t, n) {
    n.d(t, "b", function() {
      return K
    }), n.d(t, "a", function() {
      return Y
    }), n.d(t, "d", function() {
      return ve
    }), n.d(t, "c", function() {
      return te
    });
    var r, a, i, o, s, c = n("Y28S"),
      u = n("w2Y9"),
      d = n.n(u),
      l = n("9DIb"),
      p = n.n(l),
      h = n("tuFO"),
      f = n.n(h),
      g = function() {
        return (g = Object.assign || function(e) {
          for (var t, n = 1, r = arguments.length; n < r; n++)
            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
          return e
        }).apply(this, arguments)
      },
      v = "salesman_advance_personal_space_ability",
      m = "/wscsalesman/salesman/shop/checkShopAbility.json",
      y = "/wscsalesman/bind-customer.json",
      b = "/wscump/salesman/share.json",
      _ = function() {},
      O = function() {
        function e(e) {
          var t = e.kdtId,
            n = void 0 === t ? "" : t,
            r = e.rootKdtId,
            a = e.buyerId,
            i = e.guideBindSourceType,
            o = e.st,
            s = e.buildEnv,
            c = e.runEnv,
            u = e.path,
            d = e.query,
            l = void 0 === d ? {} : d,
            p = e.fromSeller,
            h = e.shareInfo,
            f = void 0 === h ? {} : h,
            g = e.goodsInfo,
            v = void 0 === g ? {} : g,
            m = e.shareData,
            y = void 0 === m ? {} : m,
            b = e.rightsInfo,
            O = void 0 === b ? {} : b,
            S = e.scenes,
            w = void 0 === S ? "" : S,
            I = e.smartTextData,
            P = e.nativeAjax,
            k = void 0 === P ? function() {
              return Promise.resolve()
            } : P,
            j = e.nativeAjaxUseCdn,
            x = void 0 === j ? function() {
              return Promise.resolve()
            } : j,
            T = e.nativeMonitor,
            E = void 0 === T ? _ : T,
            A = e.nativeLogger,
            C = void 0 === A ? _ : A,
            D = e.nativeNavigate,
            M = void 0 === D ? _ : D,
            N = e.nativeYunExtension,
            L = void 0 === N ? function() {
              return Promise.resolve([])
            } : N,
            U = e.h5UrlLogParams,
            R = void 0 === U ? {} : U,
            B = e.h5SetShareData,
            F = void 0 === B ? _ : B,
            q = e.hasGuideMaterial,
            H = void 0 !== q && q,
            z = e.offlineId,
            G = void 0 === z ? "" : z;
          this.kdtId = n, this.rootKdtId = r || this.getKdtId(), this.buyerId = a, this.buildEnv = s, this.st = o || l.st || 1, this.guideBindSourceType = i || 14, this.runEnv = c || s, this.path = u, this.query = l, this.fromSeller = p || l.fromSeller || l.sl || l.sls, this.shareInfo = f, this.goodsInfo = v, this.shareData = y, this.rightsInfo = O, this.scenes = w, this.smartTextData = I, this.nativeLogger = C, this.nativeNavigate = M, this.nativeYunExtension = L, this.nativeAjax = k, this.nativeAjaxUseCdn = x, this.nativeMonitor = E, this.h5UrlLogParams = R, this.h5SetShareData = F, this.hasGuideMaterial = H, this.offlineId = G, this.shopAbilities = {}, this.updateAbility(this.getKdtId())
        }
        return e.prototype.update = function(e, t) {
          "kdtId" === e && this.updateAbility(t), this[e] = t
        }, e.prototype.batchUpdate = function(e) {
          var t = this;
          Object.keys(e).forEach(function(n) {
            "kdtId" === n && t.updateAbility(e[n]), t[n] = e[n]
          })
        }, e.prototype.getKdtId = function() {
          return "function" == typeof this.kdtId ? this.kdtId() : this.kdtId
        }, e.prototype.getBuyerId = function() {
          return "function" == typeof this.buyerId ? this.buyerId() : this.buyerId
        }, e.prototype.monitor = function(e) {
          return void 0 === e && (e = {}), this.nativeMonitor({
            appName: "wsc-h5-salesman",
            logIndex: "wsc_wap_salesman_share_track",
            topic: "front",
            extra: g({
              kdtId: this.getKdtId(),
              type: this.buildEnv,
              buyerId: this.getBuyerId()
            }, e)
          })
        }, e.prototype.ajax = function(e) {
          return e.url = e.path, this.nativeAjax(e)
        }, e.prototype.navigate = function(e) {
          if ("web" === this.buildEnv) return this.nativeNavigate(e);
          var t = e.url,
            n = e.weappUrl,
            r = e.qqUrl,
            a = "";
          switch (!0) {
            case "weapp" === this.buildEnv:
              a = n || t;
              break;
            case "qq" === this.buildEnv:
              a = r || t;
          }
          return this.nativeNavigate({
            url: a
          })
        }, e.prototype.updateAbility = function(e) {
          this.getKdtId() !== e && this.getShopAbility(e, v)
        }, e.prototype.getShopAbility = function(e, t) {
          var n = this;
          if (e) {
            var r = {
              data: {
                kdtId: e,
                abilityName: t
              },
              method: "GET",
              url: m,
              path: m
            };
            return this.nativeAjaxUseCdn(r).then(function(e) {
              var r;
              return n.update("shopAbilities", g(g({}, n.shopAbilities), ((r = {})[t] = e.valid, r))), Promise.resolve(e.valid)
            }).catch(function() {
              return Promise.resolve(!1)
            })
          }
        }, e
      }(),
      S = "share",
      w = "copy",
      I = "tuwenPoster",
      P = "code",
      k = "salesman",
      j = "material",
      x = "guideMaterial",
      T = "zoom",
      E = "guide",
      A = "promote",
      C = "zonePoster",
      D = "weappLink",
      M = ((r = {})[k] = E, r[j] = x, r),
      N = [k, A, T],
      L = {
        web: [
          [S, w, I, P],
          [E, j]
        ],
        weapp: [
          [S, I, P],
          [E, j]
        ],
        qq: [
          [S, P]
        ]
      },
      U = {
        default: L,
        shop_note: L,
        benefit_card: L,
        salesman_coupon: {
          weapp: [
            [S, P],
            [E, j]
          ]
        },
        zone: {
          weapp: [
            [S, P, C],
            [E, j]
          ]
        },
        salesman_goods: {
          weapp: [
            [P, E, j]
          ]
        },
        goods: {
          web: [
            [S, w, P, E, j]
          ],
          weapp: [
            [S, D, P, E, j]
          ],
          qq: [
            [S, P, E]
          ],
          weappRunEnv: [
            [P, E, j]
          ]
        }
      },
      R = {
        Goods: "goods",
        BenefitCard: "benefit_card",
        ShopNote: "shop_note",
        Feature: "feature",
        FeaturePage: "feature_page",
        HomePage: "home_page",
        SalesmanZone: "zone",
        SalesmanGoods: "salesman_goods",
        SalesmanCoupon: "salesman_coupon"
      },
      B = ((a = {})[R.Goods] = "商品", a[R.Feature] = "微页面", a[R.FeaturePage] = "微页面", a[R.HomePage] = "首页", a),
      F = ["zoom", "zonePoster", "material", "promote"],
      q = ["promote"],
      H = ((i = {})[v] = ["zoom"], i),
      z = {
        web: [
          ["share", "copy", "tuwenPoster", "code"],
          ["salesman", "material", "zoom"]
        ],
        weapp: [
          ["share", "tuwenPoster", "code"],
          ["salesman", "material", "zoom"]
        ],
        qq: [
          ["share", "code"]
        ]
      },
      G = ((o = {
        default: z
      })[R.ShopNote] = z, o[R.BenefitCard] = z, o[R.Feature] = {
        weapp: [
          ["share", "featurePoster", "code"],
          ["salesman", "material", "zoom"]
        ]
      }, o[R.FeaturePage] = {
        weapp: [
          ["share", "featurePoster", "code", "weappLink"],
          ["salesman", "material", "zoom"]
        ]
      }, o[R.HomePage] = {
        weapp: [
          ["share", "featurePoster", "code", "weappLink"],
          ["salesman", "material", "zoom"]
        ]
      }, o[R.SalesmanCoupon] = {
        weapp: [
          ["share", "code"],
          ["salesman", "material"]
        ]
      }, o[R.SalesmanZone] = {
        weapp: [
          ["share", "code", "zonePoster"],
          ["salesman", "material"]
        ]
      }, o[R.SalesmanGoods] = {
        weapp: [
          ["code", "salesman", "material", "zoom"]
        ]
      }, o[R.Goods] = {
        web: [
          ["share", "copy", "code", "salesman"]
        ],
        weapp: [
          ["share", "weappLink", "code", "salesman"]
        ],
        qq: [
          ["share", "code", "salesman", "zoom"]
        ],
        weappRunEnv: [
          ["code", "salesman"]
        ]
      }, o);
    ! function(e) {
      e.share = "share", e.code = "code", e.tuwenPoster = "tuwenPoster", e.featurePoster = "featurePoster", e.goodsPoster = "goodsPoster", e.zonePoster = "zonePoster", e.link = "link", e.weappLink = "weappLink", e.copy = "copy", e.custom = "custom"
    }(s || (s = {}));
    var W, K, Y, V = function(e) {
        return "//b.yzcdn.cn/salesman/cube/" + e
      },
      X = function(e) {
        var t = e.runEnv,
          n = e.shareData,
          r = void 0 === n ? {} : n,
          a = e.kdtId,
          i = e.hasGuideMaterial,
          o = r.salesmanName,
          c = void 0 === o ? "销售员" : o;
        return {
          share: {
            id: "share",
            title: t === K.qq ? "分享给好友" : "微信好友",
            openType: "share",
            type: s.share,
            iconUrl: t === K.qq ? V("share_qq.png") : V("share.png")
          },
          code: {
            id: "code",
            title: t === K.weapp || t === K.qq ? "小程序码" : "二维码",
            type: s.code,
            iconUrl: t === K.weapp || t === K.qq ? V("wecode.png") : V("qrcode.png")
          },
          weappLink: {
            id: "weappLink",
            title: "小程序链接",
            type: s.weappLink,
            iconUrl: V("weappLink.png")
          },
          tuwenPoster: {
            id: "tuwenPoster",
            title: "分享海报",
            type: s.tuwenPoster,
            iconUrl: V("NdzsNJ.png")
          },
          featurePoster: {
            id: "featurePoster",
            title: "分享海报",
            type: s.featurePoster,
            iconUrl: V("NdzsNJ.png")
          },
          goodsPoster: {
            id: "goodsPoster",
            title: "分享海报",
            type: s.goodsPoster,
            iconUrl: V("poster.png")
          },
          zonePoster: {
            id: "zonePoster",
            title: "空间海报",
            type: s.zonePoster,
            iconUrl: V("poster.png")
          },
          promote: {
            id: "promote",
            iconUrl: V("promoteicon.png"),
            title: "专属推广页",
            type: s.link,
            webUrl: "/wscsalesman/promotion/promote",
            weappUrl: "/packages/salesman/promote/index"
          },
          salesman: {
            id: "salesman",
            iconUrl: V("salesman_o.png"),
            title: c + "中心",
            type: s.link,
            weappUrl: "/packages/salesman/salesman-center/index",
            webUrl: "/wscump/salesman/index"
          },
          guide: {
            id: "guide",
            iconUrl: V("salesman.png"),
            title: "导购工作台",
            type: s.link,
            weappUrl: "/pages/common/webview-page/index?src=" + encodeURIComponent("https://h5.youzan.com/guide/center/home?kdt_id=" + a),
            webUrl: "/guide/center/home"
          },
          material: {
            id: "material",
            iconUrl: V("meterial.png"),
            title: "素材中心",
            type: s.link,
            weappUrl: "/packages/salesman/zone/material/index",
            webUrl: "/wscump/salesman/zone/material"
          },
          guideMaterial: {
            id: "guideMaterial",
            iconUrl: V("meterial.png"),
            title: "素材中心",
            type: s.link,
            weappUrl: i ? "/packages/guide/zone/material/index" : "/packages/salesman/zone/material/index",
            webUrl: "/guide/zone/material"
          },
          zoom: {
            id: "zoom",
            iconUrl: V("zoom.png"),
            title: "个人空间",
            type: s.link,
            weappUrl: "/packages/salesman/zone/home/index",
            webUrl: "/wscump/salesman/zone/home"
          },
          center: {
            id: "center",
            iconUrl: V("zoom.png"),
            title: "个人中心",
            type: s.link,
            weappUrl: "/packages/usercenter/dashboard/index",
            webUrl: "/wscuser/membercenter"
          },
          copy: {
            id: "copy",
            iconUrl: V("copy.png"),
            title: "复制链接",
            type: s.copy
          }
        }
      },
      J = (W = function(e, t) {
        return (W = Object.setPrototypeOf || {
            __proto__: []
          }
          instanceof Array && function(e, t) {
            e.__proto__ = t
          } || function(e, t) {
            for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
          })(e, t)
      }, function(e, t) {
        function n() {
          this.constructor = e
        }
        W(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
      }),
      $ = function() {
        return ($ = Object.assign || function(e) {
          for (var t, n = 1, r = arguments.length; n < r; n++)
            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
          return e
        }).apply(this, arguments)
      },
      Z = Object.prototype.hasOwnProperty,
      Q = function(e) {
        function t() {
          return null !== e && e.apply(this, arguments) || this
        }
        return J(t, e), t.getCubeShow = function(e) {
          var t = e.share,
            n = e.freedomShare;
          return t || n
        }, t.prototype.handleLog = function(e, n) {
          if (void 0 === e && (e = {}), void 0 === n && (n = {}), this.shareData && t.getCubeShow(this.shareData)) {
            var r = this.scenes,
              a = this.shareData,
              i = this.getKdtId(),
              o = this.goodsInfo || {},
              s = o.id || o.goodsId || o.itemId,
              c = (a || n).seller,
              u = a || n,
              d = u.sl,
              l = u.salesmanType;
            c = c || d;
            var p = e.params,
              h = i + "-" + c;
            e.params = $($({
              scenes: r,
              sl: c,
              mark: h,
              goods_id: s,
              salesman_type: l
            }, p), n), this.nativeLogger(e)
          }
        }, t.prototype.getH5GoodsUrl = function(e, t, n) {
          void 0 === n && (n = {});
          var r = "";
          if (e = e || this.goodsInfo, t = t || this.shareData, window && window.location && window.location.href) r = window.location.href, r = d.a.remove(r, "sid"), r = d.a.remove(r, "isWeapp"), r = d.a.remove(r, "hide_buy_btn");
          else if (e.alias) {
            var a = e.alias,
              i = e.goodsActivityInfo || {},
              o = i.activityType,
              s = i.activityAlias,
              u = i.type,
              l = i.activityId;
            if (r = f()("wscgoods/detail/" + a, "h5", this.getKdtId() || ""), u || o) {
              var p = {
                ump_type: u || o,
                ump_alias: s,
                activityType: u || o,
                activityId: l
              };
              "seckill" === p.activityType && delete p.activityId, r = d.a.add(r, p)
            }
          }
          var h = $($($({}, Object(c.c)({
            sl: t.seller || "",
            kdtId: this.getKdtId() || ""
          })), {
            sub_kdt_id: this.getKdtId() || t.dsKdtId
          }), n);
          return d.a.add(r, h)
        }, t.prototype.getWeappGoodsPath = function(e) {
          var t = e || {},
            n = t.activityType,
            r = void 0 === n ? 0 : n,
            a = t.activityAlias,
            i = void 0 === a ? "" : a,
            o = t.activityId,
            s = void 0 === o ? 0 : o,
            c = t.goodsAlias,
            u = void 0 === c ? "" : c,
            d = t.alias,
            l = {
              alias: u || (void 0 === d ? "" : d)
            };
          return 6 === r && (l = $($({}, l), {
            activityType: "seckill",
            umpAlias: i,
            umpType: "seckill"
          })), 21 === r && (l = $($({}, l), {
            activityType: "helpCut",
            activityId: s
          })), {
            basePath: "packages/goods/detail/index",
            query: l
          }
        }, t.prototype.setShareOption = function() {
          if ("web" === this.buildEnv) {
            var e = this.shareInfo.url;
            e || (e = this.goodsInfo.alias ? this.getH5GoodsUrl() : window.location.href), e = d.a.add(e, {
              st: this.st
            }), e = Object(c.a)({
              url: e,
              sl: this.shareData.seller,
              kdtId: this.getKdtId(),
              shareParams: this.h5UrlLogParams
            }), this.update("shareInfo", $($({}, this.shareInfo), {
              url: e
            }));
            var t = {};
            this.shareInfo.title && (t.title = "[分享]" + this.shareInfo.title), this.shareInfo.cover && (t.cover = this.shareInfo.cover, t.imgUrl = this.shareInfo.cover), this.shareInfo.desc && (t.desc = this.shareInfo.desc), this.h5SetShareData(t)
          }
        }, t.prototype.getIconGroup = function(e, n, r, a, i) {
          var o, s;
          void 0 === a && (a = {}), void 0 === i && (i = !1), e = e || this.shareData, n = n || this.goodsInfo, r = r || this.scenes;
          var c, u = e.isShoppingGuide,
            d = X({
              runEnv: this.runEnv,
              shareData: e,
              kdtId: this.getKdtId(),
              hasGuideMaterial: i
            }),
            l = u ? U : G;
          c = Z.call(l, r) ? l[r] : l.default;
          var p = [];
          p = this.buildEnv === K.web ? c[this.runEnv + "RunEnv"] || c[this.runEnv] || [] : c[this.runEnv] || [];
          var h = a[this.runEnv] || [],
            f = h.length ? h : p,
            g = function(e, t, r) {
              return e.map(function(e) {
                if ("string" == typeof e) return r(t[e], n);
                if (Array.isArray(e)) return g(e, t, r);
                var a = e.id || "",
                  i = t[a] || {};
                return r($($({}, i), e), n)
              })
            };
          return t.filterDisabledOptionArray({
            optionList: g(f, d, this.formatIconOption.bind(this)),
            shareData: e,
            runEnv: this.runEnv,
            kdtId: this.getKdtId(),
            hasGuideMaterial: i,
            formatIconOption: this.formatIconOption.bind(this),
            abilities: (o = {}, o[v] = null === (s = this.shopAbilities) || void 0 === s ? void 0 : s[v], o)
          })
        }, t.prototype.formatIconOption = function(e, t) {
          if ("link" === e.type) {
            if (e.webUrl && (e.webUrl = f()(d.a.add(e.webUrl, {
                kdtId: this.getKdtId()
              }), "h5", this.getKdtId())), "promote" === e.id) {
              var n = t.goodsActivityInfo,
                r = void 0 === n ? {} : n,
                a = {
                  activityAlias: r.activityAlias || "",
                  activityType: r.type || r.activityType || "",
                  activityId: r.activityId || "",
                  umpType: r.type || r.activityType || ""
                };
              "web" === this.buildEnv && e.webUrl && (e.webUrl = d.a.add(e.webUrl, $({
                alias: t.alias,
                refUrl: encodeURIComponent(this.shareInfo.url)
              }, a))), "weapp" === this.runEnv && e.weappUrl && (e.weappUrl = d.a.add(e.weappUrl, $({
                alias: t.alias,
                itemId: t.id
              }, a)))
            }
            var i = e[this.buildEnv + "Url"];
            return !i && "web" !== this.runEnv && e.webUrl && (i = "weapp" !== this.runEnv ? "/pages/web-view/index?url=" + encodeURIComponent(e.webUrl) : "/pages/common/webview-page/index?src=" + encodeURIComponent(e.webUrl)), $($({}, e), {
              url: i
            })
          }
          return e
        }, t.filterDisabledOptionArray = function(e) {
          var t = e.optionList,
            n = e.shareData,
            r = e.runEnv,
            a = e.kdtId,
            i = e.hasGuideMaterial,
            o = e.formatIconOption,
            s = e.abilities,
            c = function(e, t) {
              var n = [];
              return e.forEach(function(e) {
                Array.isArray(e) ? n.push(c(e, t)) : t.includes(e.id) || n.push(e)
              }), n
            },
            u = function(e) {
              var t = [];
              return e.forEach(function(e) {
                if (Array.isArray(e)) t.push(u(e));
                else if (e.id && Z.call(M, e.id)) {
                  var s = e && e.id,
                    c = M[s],
                    d = X({
                      runEnv: r,
                      shareData: n,
                      kdtId: a,
                      hasGuideMaterial: i
                    }),
                    l = o(d[c], {});
                  t.push(l)
                } else t.push(e)
              }), t
            },
            d = t,
            l = n.isShoppingGuide;
          return l || n.allowMoments || (d = c(d, F)), n.allowGoodsRecommend || (d = c(d, q)), l && (d = c(d, N), d = u(d)), s && Object.keys(s).forEach(function(e) {
            s[e] || (d = c(d, H[e]))
          }), d
        }, t
      }(O),
      ee = function(e) {
        return {
          et: "click",
          ei: "share",
          en: "分享",
          params: {
            share_type: "salesman",
            share_cmpt: e
          }
        }
      },
      te = {
        nativeCustom: ee("native_custom"),
        poster: ee("poster"),
        copylink: ee("copylink"),
        copyWeappLink: ee("weapp_link"),
        qrCode: ee("qr_code"),
        miniprogram: ee("miniprogram"),
        savepictures: ee("savepictures"),
        clickShare: {
          et: "click",
          ei: "sales_money",
          en: "点赚字",
          params: {
            version: "v2"
          }
        },
        salesMoneyView: {
          et: "view",
          ei: "salesmoney_view",
          en: "赚字曝光",
          params: {
            version: "v2"
          }
        }
      },
      ne = ["salesman_coupon"],
      re = function() {
        var e = function(t, n) {
          return (e = Object.setPrototypeOf || {
              __proto__: []
            }
            instanceof Array && function(e, t) {
              e.__proto__ = t
            } || function(e, t) {
              for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
            })(t, n)
        };
        return function(t, n) {
          function r() {
            this.constructor = t
          }
          e(t, n), t.prototype = null === n ? Object.create(n) : (r.prototype = n.prototype, new r)
        }
      }(),
      ae = function() {
        return (ae = Object.assign || function(e) {
          for (var t, n = 1, r = arguments.length; n < r; n++)
            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
          return e
        }).apply(this, arguments)
      },
      ie = function(e) {
        function t() {
          return null !== e && e.apply(this, arguments) || this
        }
        return re(t, e), t.prototype.bindRelation = function() {
          var e = this,
            t = this.fromSeller,
            n = this.st,
            r = this.guideBindSourceType,
            a = void 0 === r ? 14 : r,
            i = (this.query || {}).from_params;
          if (t) {
            this.monitor({
              url: y,
              path: this.path,
              sellerFrom: t,
              guideBindSourceType: a,
              bindSourceType: n
            });
            var o = function() {
              return e.ajax({
                path: y,
                method: "POST",
                data: {
                  sellerFrom: t,
                  guideBindSourceType: a,
                  bindSourceType: n,
                  fromParams: i
                }
              })
            };
            return o().catch(o)
          }
          return Promise.resolve()
        }, t.prototype.getShareData = function() {
          var e = this,
            t = {
              type: "NORMAL"
            };
          return this.goodsInfo.id && (t.goodsId = this.goodsInfo.id), "web" === this.buildEnv && (t.redirectUrl = encodeURIComponent(window.location.href)), this.monitor({
            path: this.path,
            url: b
          }), this.ajax({
            path: b,
            data: t,
            config: {
              cache: !0,
              expire: 10
            }
          }).then(function(t) {
            var n = p()(t);
            return n.isShoppingGuide = 1 === n.salesmanType, e.update("shareData", n), ne.includes(e.scenes) && e.update("kdtId", n.dsKdtId), e.handleLog(te.salesMoneyView), n
          })
        }, t.prototype.getSmartText = function(e) {
          var t = this;
          return this.ajax({
            path: "/wscsalesman/common-api/smart-text/getSmartText.json",
            method: "GET",
            data: e
          }).then(function(e) {
            return t.update("smartTextData", e), e
          })
        }, t.prototype.getShareMoney = function(e, t, n) {
          var r = {
              goodsId: e
            },
            a = "/guide/salesman-cube/getShareMoney.json";
          t && (r.rateShareList = t.filter(function(e) {
            return !!e.stockNum
          }).map(function(e) {
            return {
              skuId: e.id,
              price: e.price
            }
          })), n && (a = "/guide/goods/batchBudgetCommission.json", r.budgetGoods = [{
            goodsId: e,
            minPrice: n.minPrice,
            maxPrice: n.maxPrice
          }]);
          var i = this.shareData.salesmanType === Y.Guide,
            o = i ? a : "/wscsalesman/share-icon/share-money/getShareMoney.json";
          return i && this.shareInfo.shortLinkKdtId && (r.shareKdtId = this.shareInfo.shortLinkKdtId), this.ajax({
            path: o,
            method: "POST",
            data: r,
            contentType: "application/json"
          })
        }, t.prototype.getShareMoneyRange = function(e, t, n) {
          var r = {
            goodsId: e,
            showPoints: !0
          };
          t && (r.rateShareList = t.filter(function(e) {
            return !!e.stockNum
          }).map(function(e) {
            return {
              skuId: e.id,
              price: e.price
            }
          })), n && (r = ae(ae({}, r), n));
          return this.ajax({
            path: "/wscsalesman/share-icon/share-money/getShareMoneyV2.json",
            method: "POST",
            data: r,
            contentType: "application/json"
          })
        }, t.prototype.checkIconIsRecruitEntry = function(e) {
          return void 0 === e && (e = function() {}), this.shareData.freedomShare ? this.navigate({
            url: f()("/wscump/salesman/tutorial?kdt_id=" + this.getKdtId(), "h5", this.getKdtId()),
            weappUrl: "/packages/salesman/tutorial/index"
          }) : e()
        }, t.prototype.subscribeMessage = function(e) {
          var t = this;
          if (void 0 === e && (e = function() {}), "weapp" !== this.buildEnv || !wx.requestSubscribeMessage) return e();
          this.ajax({
            path: "/wscump/salesman/im/getSubMsg.json"
          }).then(function(n) {
            if (Array.isArray(n) && n.length) {
              (r = n, new Promise(function(e) {
                wx.requestSubscribeMessage({
                  tmplIds: r,
                  success: function(t) {
                    "requestSubscribeMessage:ok" === t.errMsg ? e(!0) : e()
                  },
                  fail: function() {
                    e()
                  }
                })
              })).then(function(r) {
                r && t.ajax({
                  path: "/wscump/salesman/im/subscriptionCallback.json",
                  method: "POST",
                  data: {
                    scene: "salesmanOrder",
                    templateIdList: n
                  }
                }), e()
              })
            } else {
              var r;
              e()
            }
          }).catch(e)
        }, t.prototype.getTaxSignInfo = function() {
          return this.ajax({
            path: "/wscsalesman/common-api/assets/new-tax/getShopAndUserTaxInfo.json"
          })
        }, t.prototype.getOpenAssistantData = function() {
          return this.ajax({
            path: "/wscsalesman/operation/salesman-aide/isNeedGuide.json",
            data: {
              isForCenter: !1
            },
            method: "POST"
          })
        }, t.prototype.getShopRights = function() {
          var e = this;
          return this.ajax({
            path: "/wscump/salesman/shop/checkShopRights.json"
          }).then(function(t) {
            return e.update("rightsInfo", t), t
          }).catch(function() {
            return {}
          })
        }, t.prototype.getNewBeginGuide = function() {
          return this.ajax({
            path: "/wscump/salesman/guide/is-success-guide.json",
            data: {
              type: 14
            }
          })
        }, t.prototype.completeNewBeginGuide = function() {
          return this.ajax({
            path: "/wscump/salesman/guide/add-success-guide.json",
            method: "POST",
            data: {
              type: 14
            }
          })
        }, t.prototype.publishMaterial = function(e) {
          return this.ajax({
            path: "/wscump/salesman/zone/publishMoments.json",
            method: "POST",
            data: e
          }).then(function() {
            return {
              material: 1
            }
          }).catch(function() {
            return {
              material: 0
            }
          })
        }, t.prototype.getShortUrl = function(e) {
          return this.ajax({
            path: "/wscshop/ump/salesman/short-url.json",
            data: {
              url: e
            }
          }).catch(function() {
            return e
          })
        }, t.prototype.getUrlWithSl = function(e) {
          var t = ae(ae({}, Object(c.c)({
            sl: this.shareData.seller,
            kdtId: this.getKdtId()
          })), {
            sub_kdt_id: this.getKdtId() || this.shareData.dsKdtId
          });
          return d.a.add(e, t)
        }, t.prototype.getSlUrl = function(e) {
          var t = this.getUrlWithSl(e);
          return this.getShortUrl(t).catch(function() {
            return t
          })
        }, t.prototype.getShortLink = function(e, t) {
          void 0 === e && (e = {}), void 0 === t && (t = {});
          var n = this.getShortLinkParams(e, t);
          return this.ajax({
            method: "POST",
            contentType: "application/json",
            data: n,
            path: "/wscsalesman/common-api/short-link/generateShortLink.json"
          })
        }, t.prototype.getShortLinkParams = function(e, t) {
          void 0 === e && (e = {}), void 0 === t && (t = {});
          var n = this,
            r = n.shareData,
            a = n.query,
            i = n.path,
            o = n.offlineId,
            s = n.scenes,
            u = this.getKdtId(),
            l = ae(ae(ae({
              offlineId: o
            }, a), Object(c.c)({
              sl: r.seller,
              kdtId: u
            })), e);
          [R.HomePage, R.FeaturePage].includes(s) && (l.kdt_id = u);
          var p = d.a.add(i, l),
            h = B[s] || "商品";
          return ae({
            isPermanent: !1,
            pageTitle: h,
            pageUrl: p
          }, t)
        }, t
      }(Q),
      oe = function() {
        var e = function(t, n) {
          return (e = Object.setPrototypeOf || {
              __proto__: []
            }
            instanceof Array && function(e, t) {
              e.__proto__ = t
            } || function(e, t) {
              for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
            })(t, n)
        };
        return function(t, n) {
          function r() {
            this.constructor = t
          }
          e(t, n), t.prototype = null === n ? Object.create(n) : (r.prototype = n.prototype, new r)
        }
      }(),
      se = function() {
        return (se = Object.assign || function(e) {
          for (var t, n = 1, r = arguments.length; n < r; n++)
            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
          return e
        }).apply(this, arguments)
      },
      ce = function(e, t) {
        var n = {};
        for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
        if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
          var a = 0;
          for (r = Object.getOwnPropertySymbols(e); a < r.length; a++) t.indexOf(r[a]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[a]) && (n[r[a]] = e[r[a]])
        }
        return n
      },
      ue = "pages/common/blank-page/index",
      de = "pages/common/webview-page/index",
      le = "packages/goods/detail/index",
      pe = function(e) {
        function t() {
          return null !== e && e.apply(this, arguments) || this
        }
        return oe(t, e), t.prototype.generateCodeJsonOrPosterJsonParams = function(e, n) {
          void 0 === e && (e = {}), void 0 === n && (n = {});
          var r = t.getAppSceneObj(se({
              kdtId: this.rootKdtId,
              guestKdtId: this.getKdtId(),
              page: this.path,
              goodsInfo: this.goodsInfo,
              sl: this.shareData.seller,
              share_from: "poster",
              offlineId: this.offlineId
            }, n)),
            a = r.sceneObj,
            i = r.formatGoodsInfo;
          return se(se(se({}, i), {
            kdtId: this.rootKdtId,
            page: this.path,
            scene: encodeURIComponent(JSON.stringify(a))
          }), e)
        }, t.prototype.generateCreatePosterJsonParams = function(e, t) {
          var n = this.shareData;
          return se({
            page: "weapp" === this.runEnv ? ue : this.path,
            scene: JSON.stringify(se(se(se({
              kdtId: this.rootKdtId,
              guestKdtId: this.getKdtId(),
              page: this.path
            }, this.query), Object(c.c)({
              sl: n.seller,
              kdtId: this.getKdtId()
            })), t))
          }, e)
        }, t.prototype.getCodeParams = function(e) {
          var t = this.goodsInfo;
          if ("qq" === this.runEnv) return "web" === this.buildEnv ? this.generateCodeJsonOrPosterJsonParams({
            page: le
          }, {
            share_from: "qrcode",
            page: le
          }) : this.generateCodeJsonOrPosterJsonParams({}, {
            share_from: "qrcode"
          });
          if ("weapp" !== this.runEnv || !t || !t.weappUrl) return {
            kdtId: this.rootKdtId,
            isWeapp: "weapp" === this.runEnv ? 1 : 0,
            url: e
          };
          if ("weapp" === this.runEnv) {
            var n = t.weappUrl.split("?")[0] || le;
            return this.generateCodeJsonOrPosterJsonParams({
              isWeapp: 1,
              url: e,
              weappUrl: "pages/common/blank-page/index"
            }, {
              page: n,
              share_from: "qrcode"
            })
          }
        }, t.prototype.getZonePosterParams = function(e) {
          var t = e.salesmanAvatar,
            n = e.nickname,
            r = e.backgroundUrl;
          return this.generateCreatePosterJsonParams({
            type: "moment",
            page: ue,
            avatar: t,
            nickname: n,
            backgroundImg: r,
            width: 292,
            height: 422
          }, {
            page: "packages/salesman/zone/home/index"
          })
        }, t.prototype.getGoodsPosterParams = function(e) {
          void 0 === e && (e = {
            params: {},
            scene: {}
          });
          var t = this.goodsInfo.goodsAlias || this.goodsInfo.alias;
          if ("web" === this.buildEnv) {
            if ("weapp" === this.runEnv) return this.generateCodeJsonOrPosterJsonParams(se({
              qrCodeType: "weapp",
              isWeapp: 1,
              alias: t,
              page: ue
            }, e.params), se({
              page: "/" + le,
              share_from: "poster"
            }, e.scene));
            if ("qq" === this.runEnv) return this.generateCodeJsonOrPosterJsonParams(se({
              page: "/" + le,
              alias: t
            }, e.params), se({
              page: "/" + le,
              share_from: "poster"
            }, e.scene));
            var n = this.shareInfo.url,
              r = this.generateCodeJsonOrPosterJsonParams(se({
                alias: t,
                url: encodeURIComponent(Object(c.a)({
                  url: n,
                  sl: this.shareData.seller,
                  st: 3,
                  kdtId: this.getKdtId()
                }))
              }, e.params));
            return delete r.scene, r
          }
          return "weapp" === this.buildEnv ? this.generateCodeJsonOrPosterJsonParams(se({
            page: ue,
            alias: t
          }, e.params), se({
            page: "/" + le,
            share_from: "poster"
          }, e.scene)) : this.generateCodeJsonOrPosterJsonParams(se(se({}, e.params), {
            alias: t
          }), e.scene)
        }, t.prototype.getGoodsPosterInfo = function() {
          var e = this.goodsInfo,
            n = t.formatGoodsActivityParams(e);
          return this.ajax({
            path: "/wscgoods/poster/goods-poster-info.json",
            data: n,
            method: "GET"
          })
        }, t.prototype.getGoodsPoster = function(e) {
          var t = this;
          void 0 === e && (e = {
            params: {},
            scene: {}
          });
          var n = this.getGoodsPosterParams(e);
          return this.nativeYunExtension(n).then(function(e) {
            return e.length ? e[0] : t.ajax({
              path: "/wscgoods/weapp-poster/goods.json",
              data: n,
              method: "GET"
            })
          }).then(function(e) {
            return e.imgUrl ? e : Promise.reject("生成失败")
          })
        }, t.prototype.getCodeOrQrCode = function() {
          var e = this;
          if ("web" === this.buildEnv) {
            var t = this.shareInfo.url;
            return t = d.a.add(t, {
              st: 1
            }), "web" === this.runEnv ? (this.handleLog(te.qrCode), t = d.a.add(t, {
              share_cmpt: "qr_code"
            })) : (this.handleLog(te.miniprogram), t = d.a.add(t, {
              share_cmpt: "miniprogram"
            })), this.getSlUrl(t).then(function(t) {
              var n = e.getCodeParams(t);
              return e.ajax({
                path: "/wscump/salesman/poster/getCode.json",
                data: n
              })
            })
          }
          this.handleLog(te.miniprogram);
          var n = this.generateCreatePosterJsonParams({
            type: "qrcode",
            width: 292,
            height: 292
          });
          return this.createPosterRequest(n)
        }, t.prototype.createPosterRequest = function(e) {
          return this.ajax({
            path: "/wscsalesman/poster-service/create-poster.json",
            data: e
          })
        }, t.prototype.getZoneCodePoster = function() {
          if ("web" === this.runEnv || "weapp" === this.runEnv) {
            this.handleLog(te.poster, {
              posterType: "zoomPoster"
            });
            var e = this.getZonePosterParams(this.rightsInfo);
            return this.createPosterRequest(e)
          }
          return Promise.resolve()
        }, t.prototype.getTuwenPoster = function() {
          if (this.handleLog(te.poster, {
              posterType: "tuwenPoster"
            }), "web" === this.buildEnv) {
            var e, t = this.shareInfo.url;
            return e = "weapp" === this.runEnv ? this.generateCreatePosterJsonParams({
              type: "tuwen",
              page: ue
            }, {
              page: de,
              src: encodeURIComponent(t)
            }) : "qq" === this.runEnv ? {
              type: "tuwen",
              page: "pages/web-view/index?url=" + encodeURIComponent(t),
              scene: JSON.stringify({
                kdtId: this.getKdtId()
              })
            } : {
              kdtId: this.getKdtId(),
              isWeapp: 0,
              url: t
            }, this.createPosterRequest(e)
          }
          var n = this.generateCreatePosterJsonParams({
            type: "tuwen"
          });
          return this.createPosterRequest(n)
        }, t.prototype.getFeaturePoster = function(e, t) {
          void 0 === e && (e = {}), void 0 === t && (t = {}), this.handleLog(te.poster, {
            posterType: "featurePoster"
          });
          var n = this.generateFeaturePosterParams(e, t);
          return this.ajax({
            path: "/wscshop/poster/feature.json",
            data: n
          })
        }, t.prototype.generateFeaturePosterParams = function(e, t) {
          var n;
          void 0 === e && (e = {}), void 0 === t && (t = {});
          var r = this.getKdtId();
          if ("weapp" === this.buildEnv) return se({
            isV2: 1,
            page: ue,
            pageType: "homepage",
            kdtId: r,
            scene: se(se({
              page: this.path,
              guestKdtId: r,
              kdtId: r,
              alias: null === (n = this.query) || void 0 === n ? void 0 : n.alias
            }, Object(c.c)({
              sl: this.shareData.seller,
              kdtId: r
            })), t)
          }, e);
          var a = Object(c.a)({
              url: this.shareInfo.url,
              sl: this.shareData.seller,
              kdtId: this.getKdtId()
            }),
            i = window._global.poster_info,
            o = (void 0 === i ? {} : i).more,
            s = void 0 === o ? {} : o;
          if ("weapp" === this.runEnv) {
            var u = s.alias || d.a.get("alias") || "";
            return se({
              isV2: 1,
              page: ue,
              pageType: s.pageType || "homepage",
              qrCodeType: "weapp",
              kdtId: r,
              alias: u,
              scene: encodeURIComponent(JSON.stringify(se(se({
                page: de,
                kdtId: r,
                guestKdtId: r,
                src: encodeURIComponent(a),
                alias: u
              }, Object(c.c)({
                sl: this.shareData.seller,
                kdtId: this.getKdtId()
              })), t)))
            }, e)
          }
          return {
            kdtId: r,
            url: a,
            pageType: s.pageType || "homepage",
            alias: s.alias || ""
          }
        }, t.getAppSceneObj = function(e) {
          var n = e.kdtId,
            r = e.guestKdtId,
            a = e.goodsInfo,
            i = e.page,
            o = e.sl,
            s = e.share_from,
            u = ce(e, ["kdtId", "guestKdtId", "goodsInfo", "page", "sl", "share_from"]),
            d = t.formatGoodsActivityParams(a);
          return {
            formatGoodsInfo: d,
            sceneObj: se(se(se({
              kdtId: n,
              guestKdtId: r || n,
              page: i,
              share_from: s
            }, u), d), Object(c.c)({
              sl: o,
              kdtId: r
            }))
          }
        }, t.formatGoodsActivityParams = function(e) {
          var t = {},
            n = e.goodsAlias || e.alias;
          t.alias = n;
          var r = e.goodsActivityInfo;
          if (!r) return t;
          var a = r.activityId,
            i = r.type,
            o = r.activityType,
            s = void 0 === o ? i : o,
            c = r.activityAlias || e.activityAlias;
          return (a || s) && ("helpCut" === s || 21 === s ? (t.activityType = "helpCut", t.umpType = "helpCut", t.activityId = a) : 6 === s || "seckill" === s ? (t.umpType = "seckill", t.activityType = "seckill", t.umpAlias = c) : "luckyDrawGroup" === i ? (t.activityId = a, t.activityType = "luckyDrawGroup") : (t.activityId = a, t.activityType = s)), t
        }, t
      }(ie),
      he = function() {
        var e = function(t, n) {
          return (e = Object.setPrototypeOf || {
              __proto__: []
            }
            instanceof Array && function(e, t) {
              e.__proto__ = t
            } || function(e, t) {
              for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
            })(t, n)
        };
        return function(t, n) {
          function r() {
            this.constructor = t
          }
          e(t, n), t.prototype = null === n ? Object.create(n) : (r.prototype = n.prototype, new r)
        }
      }(),
      fe = function(e) {
        function t() {
          return null !== e && e.apply(this, arguments) || this
        }
        return he(t, e), t.prototype.checkHasGuideMaterial = function() {
          var e, t = this;
          return (e = "weapp" === this.buildEnv ? Promise.resolve(!0) : this.ajax({
            path: "/guide/salesman-cube/hasGuideMaterial.json"
          })).then(function(e) {
            return t.update("hasGuideMaterial", e), e
          }), e
        }, t
      }(pe),
      ge = function() {
        var e = function(t, n) {
          return (e = Object.setPrototypeOf || {
              __proto__: []
            }
            instanceof Array && function(e, t) {
              e.__proto__ = t
            } || function(e, t) {
              for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
            })(t, n)
        };
        return function(t, n) {
          function r() {
            this.constructor = t
          }
          e(t, n), t.prototype = null === n ? Object.create(n) : (r.prototype = n.prototype, new r)
        }
      }();
    ! function(e) {
      e.weapp = "weapp", e.qq = "qq", e.web = "web"
    }(K || (K = {})),
    function(e) {
      e[e.Guide = 1] = "Guide", e[e.Salesman = 2] = "Salesman"
    }(Y || (Y = {}));
    var ve = function(e) {
      function t() {
        return null !== e && e.apply(this, arguments) || this
      }
      return ge(t, e), t.getInstance = function(e) {
        return !t.instance && e && (t.instance = new t(e)), t.instance
      }, t.instance = null, t
    }(fe)
  },
  "5mDF": function(e, t, n) {
    n.d(t, "a", function() {
      return i
    });
    var r = n("9ME7"),
      a = n.n(r);
    class i {
      constructor(e) {
        this.ctx = e.ctx
      }
    }
    i.widgets = {
      GoodsShowcase: a()
    }
  },
  "6MKc": function(e, t, n) {
    n.d(t, "l", function() {
      return i
    }), n.d(t, "j", function() {
      return o
    }), n.d(t, "a", function() {
      return s
    }), n.d(t, "m", function() {
      return c
    }), n.d(t, "k", function() {
      return u
    }), n.d(t, "d", function() {
      return d
    }), n.d(t, "b", function() {
      return l
    }), n.d(t, "f", function() {
      return p
    }), n.d(t, "n", function() {
      return h
    }), n.d(t, "c", function() {
      return f
    }), n.d(t, "h", function() {
      return g
    }), n.d(t, "i", function() {
      return v
    });
    var r = n("6S0u"),
      a = n("ECkf");

    function i(e, t, n) {
      return Math.min(Math.max(e, t), n)
    }

    function o(e) {
      Object(a.e)() ? wx.nextTick(e) : setTimeout(() => {
        e()
      }, 1e3 / 30)
    }

    function s(e) {
      if (Object(r.b)(e)) return e = String(e), Object(r.e)(e) ? e + "px" : e
    }

    function c(e) {
      return setTimeout(() => {
        e()
      }, 1e3 / 30)
    }

    function u(e, t) {
      return Object(r.g)(e) ? Object.keys(e).reduce((n, r) => (t.includes(r) || (n[r] = e[r]), n), {}) : {}
    }

    function d(e, t) {
      return new Promise(n => {
        wx.createSelectorQuery().in(e).select(t).boundingClientRect().exec(function(e) {
          return void 0 === e && (e = []), n(e[0])
        })
      })
    }

    function l(e, t) {
      return new Promise(n => {
        wx.createSelectorQuery().in(e).selectAll(t).boundingClientRect().exec(function(e) {
          return void 0 === e && (e = []), n(e[0])
        })
      })
    }

    function p(e, t) {
      Object(a.c)() ? e.groupSetData(t) : t()
    }

    function h(e) {
      return Object(r.h)(e) ? e : Promise.resolve(e)
    }
    n.d(t, "g", function() {
      return r.b
    }), n.d(t, "e", function() {
      return a.f
    });

    function f() {
      var e = getCurrentPages();
      return e[e.length - 1]
    }
    var g = ["mac", "windows"].includes(Object(a.f)().platform),
      v = "wxwork" === Object(a.f)().environment
  },
  "6NLS": function(e, t, n) {
    n.d(t, "a", function() {
      return a
    });
    var r = n("BANk");

    function a(e, t) {
      void 0 === t && (t = {});
      var a = n("US/N").default;
      return "string" == typeof t && (t = {
        fileType: t
      }), a({
        path: t.uploadToShop ? "/wscshop/token/shop-image-token.json" : "/wscshop/token/upload-image.json",
        data: {
          kdt_id: t.kdtId
        }
      }).then(function(n) {
        var a = n.token;
        return new Promise(function(n, i) {
          return Object(r.a)({
            url: "https://up.yzcdn.cn/",
            filePath: e,
            fileName: "file",
            fileType: t.fileType || "image",
            formData: {
              token: a,
              "x:skip_save": 1
            },
            success: function(t) {
              var r, a = t.data;
              if (200 != +t.statusCode) return i(new Error("上传文件失败"));
              try {
                r = JSON.parse(a)
              } catch (e) {
                return i(new Error("解析文件失败"))
              }
              if (!r || 0 !== r.code) return i(new Error("上传文件失败"));
              r.data.originFile = e, r.data.success = !0, n(r.data)
            }
          })
        })
      })
    }
  },
  "6i0Q": function(e, t, n) {
    var r = n("Fcif"),
      a = n("uhII"),
      i = {
        general: "general",
        "main-bg": "main-bg",
        "main-text": "main-text",
        "vice-bg": "vice-bg",
        "vice-text": "vice-text",
        "gradient-start": "start-bg",
        "gradient-end": "end-bg"
      },
      o = null;
    t.a = {
      getThemeType() {
        return this.getTheme().then(e => e.type)
      },
      getTheme: () => new Promise((e, t) => {
        if (!getApp) return e({
          type: 0,
          colors: Object(r.a)({}, a.b)
        });
        getApp().getShopTheme().then(t => {
          e(t)
        }).catch(() => t())
      }),
      getThemeColorWithType(e) {
        var t = i[e];
        return t ? o ? o[t] : a.b[t] : e
      },
      getThemeColor(e) {
        return this.getTheme().then(t => (o = t.colors, this.getThemeColorWithType(e)))
      },
      switchHexToRgb(e) {
        var t = 0,
          n = 0,
          r = 0,
          a = e => parseInt(e, 16);
        if (3 === (e = e.slice(1)).length || 6 === e.length) return 3 === e.length ? (t = 17 * a(e[0]), n = 17 * a(e[1]), r = 17 * a(e[2])) : (t = a(e[1]) + 16 * a(e[0]), n = a(e[3]) + 16 * a(e[2]), r = a(e[5]) + 16 * a(e[4])), [t, n, r]
      }
    }
  },
  "7/pW": function(e, t, n) {
    n.d(t, "a", function() {
      return c
    });
    var r = n("9mFz"),
      a = n("y293"),
      i = Behavior({
        properties: {
          rmId: {
            type: String
          },
          _rm: {
            type: Object
          },
          _rw: {
            type: Object
          }
        },
        attached() {
          var {
            rmId: e
          } = this.data;
          if (e) {
            var t = Object(a.a)(this)[Symbol.for("vm")].$root.MNQXvtPXxgBH.getModuleContext(e, {
                onlyCtx: !1
              }),
              n = t.hasOwnProperty("store") && !t.moduleId,
              r = n ? t.ctx : t;
            n && (this.store = t.store), this.ctx = r
          }
        },
        detached() {
          this.data.rmId && (this.store && (this.store = null), this.ctx = null)
        }
      }),
      o = Behavior({
        created() {
          this._isRantaWeapp = !0, this[r.a] = []
        },
        detached() {
          this[r.a].forEach(e => null == e ? void 0 : e())
        }
      });
    var s = n("u8kV"),
      c = function(e) {
        e.behaviors = e.behaviors || [];
        var t, n = new s.a;
        return e.behaviors.push(n.getBehavior()), (t = e).behaviors || (t.behaviors = []), t.behaviors.push(o, i), Component(t)
      }
  },
  "7IP4": function(e, t) {
    e.exports = function() {}
  },
  "7WUL": function(e, t, n) {
    n.d(t, "b", function() {
      return r
    }), n.d(t, "a", function() {
      return a
    }), n.d(t, "c", function() {
      return i
    }), n.d(t, "d", function() {
      return o
    }), n.d(t, "f", function() {
      return s
    }), n.d(t, "e", function() {
      return c
    });
    var r = ["offlinepage", "weapplink", "goods", "tag", "weappfeature", "feature", "homepage", "usercenter", "cart", "allgoods", "chat", "pointsstore", "coupon", "platform_coupon", "seckill", "zodiac", "paidcolumn", "paidcontent", "mypaidcontent", "paidlive", "shopnote", "calendar_checkin", "shopnote_detail", "allcourse", "course", "educourse", "allofflinecourse", "eduappointment", "course_group", "course_category", "edumoments", "hotellist", "recharge_center", "red-package", "member_code", "vipcenter", "mp_article", "marketing_page", "video_number", "video_number_dynamic", "goods_classify", "booking_mall", "express_mall"],
      a = ["/pages/home/dashboard/index", "/pages/goods/cart/index", "/pages/usercenter/dashboard/index", "/pages-retail/usercenter/dashboard-v2/index"],
      i = {
        SCAN_GO: "scan_order_way",
        FREE_GO: "free_order_way",
        SELF: "self_order_way",
        TAKEOUT: "takeout_order_way",
        SaleToday: "sale_today",
        SaleAdvance: "sale_advance",
        NEARBY_STORE: "nearby_store_way",
        SHELF_GOODS: "shelf_goods",
        SHELF_GROUP: "shelf_group",
        WX_SCAN_CODE: "wx_scan_code"
      },
      o = {
        [i.SELF]: 0,
        [i.SaleToday]: 0,
        [i.SaleAdvance]: 0,
        [i.TAKEOUT]: 1
      },
      s = "packages/retail-shelf/shelf/index",
      c = {
        [i.SELF]: s + "?mode=0",
        [i.SaleToday]: s + "?mode=0&filter=1",
        [i.SaleAdvance]: s + "?mode=0&filter=2",
        [i.TAKEOUT]: s + "?mode=1"
      }
  },
  "7WjY": function(e, t, n) {
    n.d(t, "a", function() {
      return r
    });
    var r = {
      kdtId: 0,
      im: null,
      nav: {},
      vip: null,
      base: null,
      store: null,
      config: null,
      copyright: {
        isCustomized: !1,
        logo: "https://img01.yzcdn.cn/weapp/wsc/jda6QN.png"
      },
      theme: {
        themeClass: "th0",
        isFantasy: !1,
        themeFetched: !1,
        type: 0
      },
      isMultiStore: !1,
      autoEntryStore: 0,
      soldOutRecommend: !1,
      openHideStore: 0,
      multiStoreSwitch: !1,
      hideTopBar: 0,
      hasBase: !1,
      logo: "",
      shop_name: "",
      shop_type: 0,
      kdt_id: 0,
      service: {},
      security: {},
      wechat_sync_shopping_list: 0,
      isServiceDue: !1,
      virtualGoodsCannotWePay: !1,
      offlineId: 0,
      chainStoreInfo: {},
      shop_business_isopen: !0,
      suspend_message: ""
    }
  },
  "7ayS": function(e, t, n) {
    n.d(t, "a", function() {
      return i
    });
    var r = n("iNgw"),
      a = n.n(r);
    class i {
      constructor(e) {
        var {
          ctx: t,
          wrapperType: n
        } = e;
        this.ctx = t, this.wrapperType = n
      }
    }
    i.widgets = {
      Main: a()
    }
  },
  "7o+A": function(e, t) {
    e.exports = function(e) {
      var t = typeof e;
      return "string" == t || "number" == t || "symbol" == t || "boolean" == t ? "__proto__" !== e : null === e
    }
  },
  "7sy2": function(e, t, n) {
    n.d(t, "a", function() {
      return l
    }), n.d(t, "b", function() {
      return h
    }), n.d(t, "d", function() {
      return f
    }), n.d(t, "e", function() {
      return g
    }), n.d(t, "c", function() {
      return v
    }), n.d(t, "f", function() {
      return m
    });
    var r = n("Fcif"),
      a = n("3tyi"),
      i = n("PZW/"),
      o = n("2wjL"),
      s = n("zMoS"),
      c = n("sbwY"),
      u = n("Y28S"),
      {
        state: d
      } = c.a;

    function l(e) {
      var t, n = Object(a.a)(e || {}, ["from_params", "IS_SALES", "NEW_SALES_KDTID", "NEW_SALES_ID"]),
        r = getApp();
      if (!n.from_params) {
        var i, o, s = null == r || null == (i = r.logger) ? void 0 : i.getLogParams();
        n.from_params = (null == s || null == (o = s.context) ? void 0 : o.from_params) || ""
      }
      n.from_params || (n.from_params = (null == r || null == (t = r.globalData) ? void 0 : t.from_params) || "");
      return n
    }

    function p(e) {
      return null != e && e.path ? o.a.add("/" + (null == e ? void 0 : e.path), (null == e ? void 0 : e.query) || {}) : ""
    }

    function h(e, t) {
      var {
        level: n = "info",
        message: a,
        detail: i = {},
        extra: o = {}
      } = e;
      void 0 === t && (t = {});
      try {
        var s, c, u, d, l = getApp(),
          h = (null == l || null == (s = l.logger) ? void 0 : s.getGlobal()) || {};
        null == l || null == (c = l.logger) || null == c.appError || c.appError({
          appName: "guide-b-h5",
          logIndex: "guide_b_log",
          name: "weapp",
          message: a,
          level: n,
          extra: Object(r.a)({
            sourceApp: "weapp",
            userId: (null == h || null == (u = h.user) ? void 0 : u.li) || "",
            mobile: (null == h || null == (d = h.user) ? void 0 : d.m) || ""
          }, o),
          detail: Object(r.a)({}, i, {
            url: p(t)
          })
        })
      } catch (e) {}
    }

    function f(e, t) {
      try {
        var n;
        t = t || getApp();
        var a = Object(r.a)({}, (null == e ? void 0 : e.query) || {}, (null == d || null == (n = d.sceneData) ? void 0 : n.pageData) || {});
        Object(i.a)({
          query: a,
          url: p(e),
          sourceApp: "weapp",
          appObj: t
        })
      } catch (t) {
        h({
          level: "error",
          message: "关联关系上报_兜底catch",
          detail: {
            error: t
          }
        }, e)
      }
    }
    var g = e => {
      var t, {
          query: n
        } = null == (t = wx) || null == t.getLaunchOptionsSync ? void 0 : t.getLaunchOptionsSync(),
        a = getApp(),
        {
          from_params: i,
          IS_SALES: o,
          NEW_SALES_ID: s,
          NEW_SALES_KDTID: c
        } = l(n);
      return a.request(Object(r.a)({}, e, {
        header: Object(r.a)({}, e.header, {
          "x-guide-biz-data": "from_params=" + i + ";is_sales=" + o + ";new_sales_kdtId=" + c + ";new_salesId=" + s
        })
      }))
    };

    function v(e) {
      return !("" === (t = e) || null == t || "null" === t || "undefined" === t) && /[^\s]+~[^\s]+/.test(e);
      var t
    }

    function m(e) {
      var t = "";
      try {
        var n = getApp(),
          a = null == n ? void 0 : n.logger,
          i = Object(s.a)(null == a ? void 0 : a.getLogParams(), "context.from_params", ""),
          {
            from_params: c
          } = o.a.getAll(e) || {},
          d = /(sl|sales_id)~/.test(c);
        if (h({
            message: "webview页更新小程序上下文数据_前置打点",
            detail: {
              h5Url: e
            },
            extra: {
              isValid: v(c),
              hasSL: d,
              fromParamsStrOfH5Query: c,
              fromParamsStrOfContext: i
            }
          }), c !== i && v(c) && d) {
          var l = Object(u.d)(i || ""),
            p = Object(u.d)(c),
            f = Object(u.e)(Object(r.a)({}, l, p));
          h({
            message: "webview页更新小程序上下文数据_有有效from_params值",
            detail: {
              mergedFromParamsStr: f,
              fromPramsObjOfContext: l,
              fromPramsObjOfH5Query: p
            }
          }), t = f, null == a || a.setContext({
            from_params: f
          }, 1)
        }
      } catch (e) {
        h({
          level: "error",
          message: "webview页更新小程序上下文数据_失败",
          detail: {
            error: e
          }
        })
      }
      return t
    }
  },
  "7yS6": function(e, t, n) {
    var r;
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.default = void 0;
    var a = ((r = n("HmHG")) && r.__esModule ? r : {
      default: r
    }).default;
    t.default = a, e.exports = t.default
  },
  "82CI": function(e, t, n) {
    n.d(t, "b", function() {
      return r
    }), n.d(t, "d", function() {
      return a
    }), n.d(t, "a", function() {
      return i
    }), n.d(t, "c", function() {
      return o
    });
    var r = 100,
      a = 30,
      i = 54,
      o = 16
  },
  "87Y/": function(e, t, n) {
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.default = function(e) {
      var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
      if ("string" != typeof e) return "";
      3 === (e = e.slice(1)).length && (e = e[0] + e[0] + e[1] + e[1] + e[2] + e[2]);
      return "rgba(" + parseInt(e.slice(0, 2), 16) + "," + parseInt(e.slice(2, 4), 16) + "," + parseInt(e.slice(4, 6), 16) + "," + t + ")"
    }, e.exports = t.default
  },
  "8B9M": function(e, t, n) {
    n("Fcif"), n("taYb");
    var r = n("QTc8"),
      a = n("jA1y"),
      i = n("2ktG"),
      o = () => {},
      s = {},
      c = {
        globalData: {
          shopInfo: {
            isMultiStore: !1
          }
        },
        db: r.a,
        carmen: a.b,
        request: a.c,
        logger: {
          requestError: o,
          onError: o,
          getGlobal: o,
          appError: o
        },
        isSwitchTab: () => Promise.resolve(!1),
        updateYouzanUserInfo() {},
        getOfflineId() {
          var {
            shopInfo: e = {}
          } = s;
          return e.offlineId || 0
        },
        getKdtId: () => s.kdtId || 0,
        getFansType: () => "",
        getSessionId() {
          var {
            token: e = {}
          } = s;
          return e.sessionId || ""
        },
        getShopConfigData: () => new Promise(e => {
          e({
            show_buy_btn: !0,
            hide_shopping_cart: !1
          })
        }),
        getShopInfo: () => Promise.resolve({}),
        getImData: () => new Promise(e => {
          e({})
        }),
        getUserInfo() {},
        getPointsName: () => Promise.resolve({
          pointsName: "积分"
        }),
        getPoints: () => Object(a.c)({
          path: "wscump/integral/user_points.json"
        })
      };
    c.storage = Object(i.a)(), t.a = function() {
      return getApp ? getApp() : c
    }
  },
  "8Ggg": function(e, t, n) {
    function r(e) {
      return Math.sqrt(Math.pow(e[0].clientX - e[1].clientX, 2) + Math.pow(e[0].clientY - e[1].clientY, 2))
    }

    function a(e, t, n) {
      return Math.min(Math.max(e, t), n)
    }

    function i() {
      var e = {
        startX: 0,
        startY: 0,
        deltaX: 0,
        deltaY: 0,
        offsetX: 0,
        offsetY: 0,
        direction: "",
        isVertical: null,
        isHorizontal: null,
        move: null,
        start: null,
        reset: null
      };
      return e.isVertical = () => "vertical" === e.direction, e.isHorizontal = () => "horizontal" === e.direction, e.move = t => {
        var n, r, a = t.touches[0];
        e.deltaX = a.clientX - e.startX, e.deltaY = a.clientY - e.startY, e.offsetX = Math.abs(e.deltaX), e.offsetY = Math.abs(e.deltaY), e.direction || (e.direction = (n = e.offsetX, r = e.offsetY, n > r && n > 10 ? "horizontal" : r > n && r > 10 ? "vertical" : ""))
      }, e.start = t => {
        e.reset(), e.startX = t.touches[0].clientX, e.startY = t.touches[0].clientY
      }, e.reset = () => {
        e.deltaX = 0, e.deltaY = 0, e.offsetX = 0, e.offsetY = 0, e.direction = ""
      }, e
    }
    n.d(t, "a", function() {
      return r
    }), n.d(t, "b", function() {
      return a
    }), n.d(t, "c", function() {
      return i
    })
  },
  "8VmE": function(e, t) {
    function n() {
      return e.exports = n = Object.assign ? Object.assign.bind() : function(e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];
          for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
        }
        return e
      }, e.exports.__esModule = !0, e.exports.default = e.exports, n.apply(this, arguments)
    }
    e.exports = n, e.exports.__esModule = !0, e.exports.default = e.exports
  },
  "8zua": function(e, t, n) {
    n.d(t, "a", function() {
      return r
    });
    var r = {
      UNKNOWN: -1,
      GROW: 1,
      REGISTER: 2,
      CONSUME: 3,
      SAVING: 4
    }
  },
  "9+N+": function(e, t, n) {
    n.d(t, "b", function() {
      return a
    }), n.d(t, "a", function() {
      return i
    });
    var r = n("9ZMt");

    function a(e) {
      r.default.$native.onError(e)
    }

    function i(e) {
      r.default.$native.offError(e)
    }
  },
  "9+gc": function(e, t, n) {
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.default = void 0;
    var r = function(e) {
      var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : new Date,
        n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "day",
        r = t.getFullYear(),
        a = t.getMonth(),
        i = t.getDate();
      return new Date("year" === n ? r + e : r, "month" === n ? a + e : a, "day" === n ? i + e : i)
    };
    t.default = r, e.exports = t.default
  },
  "9Bnu": function(e, t, n) {
    t.a = () => getApp().resolveTeeAPI().then(e => e.getUserPrivacy())
  },
  "9DLJ": function(e, t, n) {
    n.d(t, "c", function() {
      return r
    }), n.d(t, "b", function() {
      return a
    }), n.d(t, "i", function() {
      return i
    }), n.d(t, "k", function() {
      return o
    }), n.d(t, "j", function() {
      return s
    }), n.d(t, "a", function() {
      return c
    }), n.d(t, "h", function() {
      return u
    }), n.d(t, "e", function() {
      return l
    }), n.d(t, "g", function() {
      return p
    }), n.d(t, "f", function() {
      return h
    }), n.d(t, "d", function() {
      return f
    }), n.d(t, "l", function() {
      return g
    });
    var r = {
        ACTIVE: "#f44",
        UNACTIVATED: "#969799",
        RESET_UNACTIVE: "#666"
      },
      a = {
        SHOP: "shop",
        CUSTOM: "custom"
      },
      i = {
        DEFAULT: 1,
        MAIN_ICON: 2,
        XUAN_FU: 3,
        MAIN_ICON_STYLE_TWO: 4
      },
      o = {
        WSC: "packages/usercenter/dashboard/index",
        RETAIL: "packages/retail/usercenter/dashboard-v2/index"
      },
      s = /packages\/(retail\/)?usercenter\/dashboard(-v2)?\/index/,
      c = {
        OLD: "packages/shop/goods/all/index",
        NEW: "packages/goods-list/all/index"
      },
      u = {
        ["/" + c.OLD]: "AllGoodsList"
      },
      d = "packages",
      l = {
        TRANS: d + "/home/tab/one",
        EXT: d + "/ext-home/tab/one",
        OLD: d + "/old-home/tab/one"
      },
      p = {
        TRANS: d + "/home/tab/two",
        EXT: d + "/ext-home/tab/two",
        OLD: d + "/old-home/tab/two"
      },
      h = {
        TRANS: d + "/home/tab/three",
        EXT: d + "/ext-home/tab/three",
        OLD: d + "/old-home/tab/three"
      },
      f = {
        TRANS: d + "/home/dashboard/index",
        EXT: d + "/ext-home/dashboard/index",
        OLD: d + "/old-home/dashboard/index"
      },
      g = {
        TRANS: d + "/usercenter/dashboard/index",
        PAGE: "pages/usercenter/dashboard/index"
      }
  },
  "9DaQ": function(e, t, n) {
    n.d(t, "a", function() {
      return i
    });
    var r = n("h+Rz"),
      a = {
        ParamsError: 100,
        Timeout: 996,
        NoSupport: 997,
        Unknown: 998,
        Navigate: {},
        Device: {},
        Location: {
          Unsupport: 130,
          Timeout: 131
        },
        Media: {
          InvalidVideoSelection: 140
        },
        Network: {},
        View: {},
        Storage: {},
        Setting: {},
        Message: {},
        Share: {},
        Log: {},
        Event: {}
      };

    function i(e) {
      var t, n, i, o = e.phoneNumber;
      return "string" != typeof o ? Promise.reject((n = (t = {
        code: a.ParamsError,
        message: "phoneNumber类型出错"
      }).code, i = t.message, {
        name: "TeeError",
        code: n,
        message: i,
        error_msg: i
      })) : r.a.makePhoneCall({
        phoneNumber: o
      })
    }
  },
  "9KEa": function(e, t, n) {
    n.d(t, "a", function() {
      return a
    });
    var r = {
      inited: !1,
      isFetching: !1,
      systemInfo: {
        SDKVersion: "",
        batteryLevel: 100,
        benchmarkLevel: 1,
        brand: "",
        fontSizeSetting: 16,
        language: "zh",
        model: "",
        pixelRatio: 1,
        platform: "",
        screenHeight: 0,
        screenWidth: 0,
        statusBarHeight: 0,
        system: "",
        version: "",
        windowHeight: 0,
        windowWidth: 0
      }
    };
    r.isFetching || (r.isFetching = !0, wx.getSystemInfo({
      success(e) {
        void 0 === e && (e = {}), r.systemInfo = e, r.inited = !0
      },
      fail(e) {},
      complete() {
        r.isFetching = !1
      }
    }));
    var a = Object.create(null);
    Object.keys(r.systemInfo).forEach(e => {
      Object.defineProperty(a, e, {
        get: () => r.inited ? r.systemInfo[e] : (r.systemInfo = wx.getSystemInfoSync(), r.inited = !0, r.systemInfo)[e]
      })
    }), Object.defineProperty(a, "isAndroid", {
      get: () => /android/i.test(a.system)
    }), Object.defineProperty(a, "isIphoneX", {
      get: () => /iphone x/i.test(a.model)
    }), t.b = function(e) {
      return void 0 === e && (e = !0), r.inited && e || (r.systemInfo = wx.getSystemInfoSync(), r.inited = !0), r.systemInfo
    }
  },
  "9VdR": function(e, t, n) {
    n.r(t), n.d(t, "getClipboardData", function() {
      return r.a
    }), n.d(t, "setClipboardData", function() {
      return r.b
    }), n.d(t, "getSystemInfo", function() {
      return a.a
    }), n.d(t, "getSystemInfoSync", function() {
      return a.b
    }), n.d(t, "makePhoneCall", function() {
      return i.a
    }), n.d(t, "getLaunchOptionsSync", function() {
      return o.a
    }), n.d(t, "ScanType", function() {
      return u
    }), n.d(t, "scanCode", function() {
      return d
    }), n.d(t, "getPerformance", function() {
      return l.a
    }), n.d(t, "chooseImage", function() {
      return p.b
    }), n.d(t, "previewImage", function() {
      return p.d
    }), n.d(t, "saveImageToPhotosAlbum", function() {
      return p.e
    }), n.d(t, "detectWebpSupport", function() {
      return p.c
    }), n.d(t, "checkCanWebp", function() {
      return p.a
    }), n.d(t, "chooseVideo", function() {
      return h
    }), n.d(t, "saveVideoToPhotosAlbum", function() {
      return f
    }), n.d(t, "previewMedia", function() {
      return v
    }), n.d(t, "getAuthCode", function() {
      return m.a
    }), n.d(t, "openAddress", function() {
      return y
    }), n.d(t, "requestSubscribeMessage", function() {
      return b
    }), n.d(t, "request", function() {
      return _.a
    }), n.d(t, "uploadFile", function() {
      return O.a
    }), n.d(t, "getNetworkType", function() {
      return S.a
    }), n.d(t, "getShareInfo", function() {
      return w.a
    }), n.d(t, "showShareMenu", function() {
      return w.f
    }), n.d(t, "updateShareMenu", function() {
      return w.g
    }), n.d(t, "hideShareMenu", function() {
      return w.b
    }), n.d(t, "shareFileMessage", function() {
      return w.c
    }), n.d(t, "shareVideoMessage", function() {
      return w.d
    }), n.d(t, "showShareImageMenu", function() {
      return w.e
    }), n.d(t, "stopPullDownRefresh", function() {
      return I.b
    }), n.d(t, "startPullDownRefresh", function() {
      return I.a
    }), n.d(t, "setNavigationBarTitle", function() {
      return P.b
    }), n.d(t, "setNavigationBarColor", function() {
      return P.a
    }), n.d(t, "pageScrollTo", function() {
      return k.a
    }), n.d(t, "createIntersectionObserver", function() {
      return j.a
    }), n.d(t, "getMenuButtonBoundingClientRect", function() {
      return x
    }), n.d(t, "downloadFile", function() {
      return T
    }), n.d(t, "disableAlertBeforeUnload", function() {
      return E
    }), n.d(t, "enableAlertBeforeUnload", function() {
      return A
    }), n.d(t, "getLocation", function() {
      return C.b
    }), n.d(t, "chooseLocation", function() {
      return C.a
    }), n.d(t, "getExtConfigSync", function() {
      return D.a
    }), n.d(t, "setStorageSync", function() {
      return M.h
    }), n.d(t, "getStorageSync", function() {
      return M.d
    }), n.d(t, "removeStorageSync", function() {
      return M.f
    }), n.d(t, "clearStorageSync", function() {
      return M.b
    }), n.d(t, "setStorage", function() {
      return M.g
    }), n.d(t, "getStorage", function() {
      return M.c
    }), n.d(t, "removeStorage", function() {
      return M.e
    }), n.d(t, "clearStorage", function() {
      return M.a
    }), n.d(t, "onError", function() {
      return N.b
    }), n.d(t, "offError", function() {
      return N.a
    }), n.d(t, "onUnhandledRejection", function() {
      return L.b
    }), n.d(t, "offUnhandledRejection", function() {
      return L.a
    }), n.d(t, "onPageNotFound", function() {
      return U.b
    }), n.d(t, "offPageNotFound", function() {
      return U.a
    }), n.d(t, "on", function() {
      return B
    }), n.d(t, "off", function() {
      return F
    }), n.d(t, "openSetting", function() {
      return q
    }), n.d(t, "navigateToMiniProgram", function() {
      return H
    }), n.d(t, "navigateBackMiniProgram", function() {
      return z
    }), n.d(t, "openEmbeddedMiniProgram", function() {
      return G
    }), n.d(t, "offEmbeddedMiniProgramHeightChange", function() {
      return W
    }), n.d(t, "onEmbeddedMiniProgramHeightChange", function() {
      return K
    });
    var r = n("Q56H"),
      a = n("MLLI"),
      i = n("9DaQ"),
      o = n("mM1a"),
      s = n("9ZMt"),
      c = n("h+Rz"),
      u = function(e) {
        return e.barCode = "barCode", e.qrCode = "qrCode", e.datamatrix = "datamatrix", e.pdf417 = "pdf417", e
      }({});

    function d(e) {
      var t = e.scanType,
        n = c.a.scanCode;
      return s.default && s.default.getEnv && "ant" === s.default.getEnv() && (t = function(e) {
        var t;
        void 0 === e && (e = [u.barCode, u.qrCode]);
        var n = ((t = {})[u.datamatrix] = "dmCode", t[u.pdf417] = "pdf417Code", t);
        return e.map(function(e) {
          return n[e] ? n[e] : e
        })
      }(t), n = c.a.scan), n({
        scanType: t
      })
    }
    var l = n("HSl3"),
      p = n("882d");

    function h(e) {
      return c.a.chooseVideo(e)
    }

    function f(e) {
      return c.a.saveVideoToPhotosAlbum(e)
    }
    var g = n("nibL");

    function v(e) {
      return Object(g.a)(Array.isArray(e.sources), "previewMedia options.sources accept type `PreviewMediaSource[]`"), c.a.previewMedia(e)
    }
    var m = n("MVYo");

    function y() {
      return c.a.chooseAddress().then(function(e) {
        return {
          address: e.detailInfo,
          city: e.cityName,
          county: e.countyName,
          userName: e.userName,
          tel: e.telNumber,
          province: e.provinceName,
          areaCode: "",
          postalCode: e.postalCode
        }
      })
    }

    function b(e) {
      return c.a.requestSubscribeMessage(e)
    }
    var _ = n("akjn"),
      O = n("BANk"),
      S = n("Tr3L"),
      w = n("GRMa"),
      I = n("TO+A"),
      P = n("R2NP"),
      k = n("fChk"),
      j = n("Vnr7");

    function x() {
      return c.a.getMenuButtonBoundingClientRect()
    }

    function T(e) {
      return c.a.downloadFile(e)
    }

    function E() {
      return c.a.disableAlertBeforeUnload()
    }

    function A(e) {
      return c.a.enableAlertBeforeUnload(e)
    }
    var C = n("hcPn"),
      D = n("U0uK"),
      M = n("GFyo"),
      N = n("9+N+"),
      L = n("LHnf"),
      U = n("Xr+B"),
      R = n("pnMF");

    function B(e, t) {
      R.a.on(e, t)
    }

    function F(e, t) {
      R.a.off(e, t)
    }

    function q() {
      return c.a.openSetting()
    }

    function H(e) {
      return c.a.navigateToMiniProgram(e)
    }

    function z(e) {
      return c.a.navigateBackMiniProgram(e)
    }

    function G(e) {
      return c.a.openEmbeddedMiniProgram(e)
    }

    function W(e) {
      return c.a.offEmbeddedMiniProgramHeightChange(e)
    }

    function K(e) {
      return c.a.onEmbeddedMiniProgramHeightChange(e)
    }
  },
  "9aUh": function(e, t) {
    e.exports = function(e) {
      var t = typeof e;
      return null != e && ("object" == t || "function" == t)
    }
  },
  AfOI: function(e, t, n) {
    var r;
    n.d(t, "a", function() {
        return r
      }),
      function(e) {
        e.NORMAL = "normal", e.SEPARATE = "separate"
      }(r || (r = {}))
  },
  AqAW: function(e, t, n) {
    var r = n("DXKY"),
      a = n("8B9M");

    function i() {
      var e = getCurrentPages() || [];
      return e.length ? e[e.length - 1].route : ""
    }
    t.a = {
      _isAppEvent: !0,
      on(e, t, n) {
        var o = Object(a.a)();
        (n = n || this || {})._route = i(), r.a.on.apply(o, [e, t, n])
      },
      once(e, t, n) {
        var o = Object(a.a)();
        (n = n || this || {})._route = i(), r.a.once.apply(o, [e, t, n])
      },
      off(e, t, n) {
        r.a.off.apply(Object(a.a)(), [e, t, n || this || {}])
      },
      trigger() {
        for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
        r.a.trigger.apply(Object(a.a)(), t)
      }
    }
  },
  B9LC: function(e, t, n) {
    var r = n("DXqK");

    function a(e, t) {
      this.tid = null, this.leftTime = 0;
      var n = Date.now();
      t = t || {}, this.isTimeList = Array.isArray(e), this.leftTime = e, this.options = t, this.isTimeList ? this._walkTimeList(n, this.leftTime) : this._walkTime(n, this.leftTime)
    }
    a.prototype = {
      stop() {
        clearTimeout(this.tid), this.tid = null, this.stopped = !0
      },
      start() {
        if (!this.tid) {
          this.stopped = !1;
          var e = Date.now();
          this.isTimeList ? this._walkTimeList(e, this.leftTime) : this._walkTime(e, this.leftTime)
        }
      },
      setTime(e) {
        this.stop(), this.leftTime = e, this.isTimeList = Array.isArray(e), this.start()
      },
      _walkTime(e, t) {
        t <= 0 ? this.options.onEnd && this.options.onEnd() : this.stopped || (this.tid = setTimeout(() => {
          var n = Date.now(),
            a = t - (n - e),
            i = Object(r.c)(a);
          this.options.onChange && this.options.onChange(i.data, i.strData), this.leftTime = a, this._walkTime(n, this.leftTime)
        }, this.options.timeout || 500))
      },
      _walkTimeList(e, t) {
        if (t.forEach((e, n) => {
            "number" == typeof e && e <= 0 && ("function" == typeof this.options.onEnd && this.options.onEnd(n), t[n] = void 0)
          }), t.reduce((e, t) => e && void 0 === t, !0)) return this.stop();
        this.stopped || (this.tid = setTimeout(() => {
          var n = Date.now(),
            a = t.map(t => void 0 === t ? t : t - (n - e)),
            i = a.map(e => void 0 === e ? {} : Object(r.c)(e));
          "function" == typeof this.options.onChange && this.options.onChange(i.map(e => e.data), i.map(e => e.strData)), this.leftTime = a, this._walkTimeList(n, this.leftTime)
        }, this.options.timeout || 500))
      }
    }, t.a = a
  },
  BAZ7: function(e, t) {
    e.exports = function(e, t, n) {
      for (var r = -1, a = null == e ? 0 : e.length; ++r < a;)
        if (n(t, e[r])) return !0;
      return !1
    }
  },
  BILe: function(e, t, n) {
    n.d(t, "a", function() {
      return r
    }), n.d(t, "b", function() {
      return a
    }), n.d(t, "c", function() {
      return o
    });
    var r, a, i = n("QxN7");
    ! function(e) {
      e.NONE = "none", e.PENDING = "pending", e.READY = "ready", e.ERROR = "error"
    }(r || (r = {})),
    function(e) {
      e.NATIVE = "native", e.YOUZAN = "youzan"
    }(a || (a = {}));
    var o = [i.AuthPopType.MOBILE, i.AuthPopType.PROTOCOL, i.AuthPopType.FILL_NICKNAME_AND_AVATAR, i.AuthPopType.YZ_AUTH, i.AuthPopType.FILL_YZ_AUTH]
  },
  BKUC: function(e, t, n) {
    n.d(t, "a", function() {
      return a
    });
    var r = ["country", "province", "city", "county", "community", "addressDetail", "address_detail", "houseNumber"];

    function a(e, t, n, a) {
      void 0 === t && (t = 0), void 0 === n && (n = r.length), void 0 === a && (a = "");
      var i = r.slice(t, n);
      return e[i[1]] && e[i[1]] === e[i[2]] && i.splice(1, 1), "中国" === e[i[0]] && i.shift(0), i.filter(t => e[t]).map(t => e[t]).join(a)
    }
  },
  BXdv: function(e, t, n) {
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.default = function(e, t) {
      var n = "".concat(e);
      t || (t = 0); - 1 === n.indexOf(".") && (n += ".");
      if (n += new Array(t + 1).join("0"), new RegExp("^(-|\\+)?(\\d+(\\.\\d{0,".concat(t + 1, "})?)\\d*$")).test(n)) {
        var r = "0".concat(RegExp.$2),
          a = RegExp.$1,
          i = !0;
        if (RegExp.$3.length === t + 2) {
          var o = r.match(/\d/g);
          if (parseInt(o[o.length - 1], 10) > 4)
            for (var s = o.length - 2; s >= 0 && (o[s] = "".concat(parseInt(o[s], 10) + 1), "10" === o[s]); s--) o[s] = "0", i = 1 !== s;
          r = o.join("").replace(new RegExp("(\\d+)(\\d{".concat(t, "})\\d$")), "$1.$2")
        }
        return i && (r = r.substr(1)), (a + r).replace(/\.$/, "")
      }
      return "".concat(e)
    }, e.exports = t.default
  },
  BaeO: function(e, t, n) {
    n.d(t, "a", function() {
      return a
    });
    var r = n("Fcif");
    class a {
      constructor(e) {
        this.getSalesmanTradeData = e => {
          var t, n;
          null != (t = this.query) && t.paymentSuccessRedirect && (e = Object(r.a)({}, e, {
            commonExtra: Object(r.a)({}, e.commonExtra, {
              payment_success_redirect: null == (n = this.query) ? void 0 : n.paymentSuccessRedirect
            })
          }));
          return e
        }, this.ctx = e.ctx
      }
      beforePageMount(e) {
        var {
          query: t
        } = e;
        this.query = t, this.ctx.process.define("setSalesmanTradeData", this.getSalesmanTradeData)
      }
      pageDestroyed() {
        this.ctx.process.undef("setSalesmanTradeData", this.getSalesmanTradeData)
      }
    }
  },
  BoIy: function(e, t, n) {
    n.d(t, "a", function() {
      return o
    });
    var r = n("Fcif"),
      a = n("8B9M"),
      i = "iPhone-X" === Object(a.a)().deviceType ? 84 : 50;
    class o {
      constructor(e, t) {
        void 0 === e && (e = 30), void 0 === t && (t = 10);
        var n = getCurrentPages(),
          r = n[n.length - 1].__wxExparserNodeId__,
          a = o.instanceMap[r];
        if (a) return a;
        this.id = r, this.base = e, this.gap = t, this.iconMap = {}, o.instanceMap[this.id] = this
      }
      setBase(e) {
        return this.base = e, this
      }
      setGap(e) {
        return this.gap = e, this
      }
      setIcon(e, t) {
        void 0 === t && (t = {});
        var {
          __wxExparserNodeId__: n
        } = e;
        return this.iconMap[n] && (t.priority = t.priority || this.iconMap[n].priority || 0, t.height = 0 === t.height ? 0 : t.height || this.iconMap[n].height, t.cb = t.cb || this.iconMap[n].cb), Object.keys(this.iconMap).some(e => this.iconMap[e].priority === t.priority && (delete this.iconMap[e], !0)), this.iconMap[n] = Object(r.a)({
          ctx: e
        }, t), Object.keys(this.iconMap).sort((e, t) => this.iconMap[t].priority - this.iconMap[e].priority).reduce((e, n, r, a) => {
          var {
            ctx: i,
            priority: o,
            height: s,
            cb: c
          } = this.iconMap[n];
          return a.length > 1 && o <= t.priority && ("function" == typeof c ? c.call(i, e) : Array.isArray(c) && "function" == typeof c[0] && c[0].call(i, e)), e + s + (s > 0 ? this.gap : 0)
        }, i + this.base), this
      }
      setAlone(e, t) {
        return Object.keys(this.iconMap).forEach(n => {
          var {
            ctx: r,
            cb: a
          } = this.iconMap[n];
          n !== e.__wxExparserNodeId__ && Array.isArray(a) && "function" == typeof a[1] && a[1].call(r, t)
        }), this
      }
      destroy(e) {
        var {
          __wxExparserNodeId__: t
        } = e;
        t && (delete this.iconMap[t], 0 === Object.keys(this.iconMap).length && delete o.instanceMap[this.id])
      }
    }
    o.instanceMap = {}
  },
  Br49: function(e, t, n) {
    var r, a, i, o;
    n.d(t, "a", function() {
        return r
      }), n.d(t, "c", function() {
        return a
      }), n.d(t, "b", function() {
        return i
      }), n.d(t, "d", function() {
        return o
      }),
      function(e) {
        e.POPUP_TRIGGER = "user-authorize:popup-trigger", e.POPUP_CALLBACK = "user-authorize:popup-callback", e.USER_INFO_CHANGED = "passport-tee-auth-success"
      }(r || (r = {})),
      function(e) {
        e.POPUP_SHOW = "popup-show"
      }(a || (a = {})),
      function(e) {
        e.POPUP_VISIBLE = "popup-visible", e.SHOW_TOAST = "toast", e.OPEN_WEBVIEW = "on-open-webview", e.POPUP_AUTH_SUCCESS = "success", e.POPUP_AUTH_FAIL = "fail", e.AUTH_POPUP_SHOW = "auth-popup-show", e.AUTH_STATUS_CHANGE = "auth-status-change"
      }(i || (i = {})),
      function(e) {
        e.MAIN = "main", e.POPUP = "popup"
      }(o || (o = {}))
  },
  BrFj: function(e, t, n) {
    n.d(t, "h", function() {
      return p
    }), n.d(t, "g", function() {
      return h
    }), n.d(t, "a", function() {
      return f
    }), n.d(t, "e", function() {
      return g
    }), n.d(t, "d", function() {
      return m
    }), n.d(t, "b", function() {
      return y
    }), n.d(t, "f", function() {
      return b
    }), n.d(t, "c", function() {
      return _
    });
    var r = n("Fcif"),
      a = n("US/N"),
      i = n("9DIb"),
      o = n.n(i);

    function s() {
      return getApp({
        allowDefault: !0
      }) || {}
    }

    function c(e) {
      return new Promise(t => {
        var n = s();
        e && n.prefetchCache ? t(delete n.prefetchCache[e]) : t(!1)
      })
    }

    function u(e) {
      var t, {
        prefetchKey: n,
        fallback: a
      } = e;
      return (t = n, new Promise((e, n) => {
        var {
          prefetchCache: r
        } = s(), a = (r || {})[t];
        return a && a.value ? a.expiredAt < Date.now() ? n("cache is expired") : e(a.value) : n("no cache")
      })).then(e => (c(n), Object(r.a)({}, e, {
        __isPrefetched: !0
      }))).catch(e => (c(n), a()))
    }

    function d(e) {
      var t, n = e.subKdtId || e.sub_kdt_id || 0,
        {
          alias: a,
          umpAlias: i = "",
          umpType: s = "",
          type: c = "",
          activityType: u = "",
          activityId: d = "",
          oid: l = 0
        } = o()(e);
      return Object(r.a)({}, e, {
        ump_alias: i,
        ump_type: s,
        activityId: d,
        activityType: (t = u || c, ["share_goods", "new_goods"].includes(t) ? "" : t),
        alias: a,
        subKdtId: +n,
        oid: l,
        fullPresaleSupportCart: "true",
        platform: "weixin",
        client: "weapp",
        isGoodsWeappNative: 1,
        withoutSkuDirectOrder: "1"
      })
    }
    var l = {
      listGoodsSalableStore: !1,
      hqStoreSearchService: !1
    };

    function p(e) {
      return l.listGoodsSalableStore ? Promise.reject() : (l.listGoodsSalableStore = !0, Object(a.default)({
        path: "/wscgoods/detail-api/list-goods-salable-store.json",
        data: e,
        method: "POST",
        withCredentials: !0
      }))
    }
    var h = e => Object(a.default)({
      method: "GET",
      path: "/wscshopcore/getPhysicalStoreList.json",
      data: e
    });

    function f() {
      return Object(a.default)({
        method: "GET",
        path: "/wscshopcore/getStoreConfig.json"
      })
    }

    function g(e) {
      return Object(a.default)({
        path: "/v2/showcase/goods/retailSellingShops.json",
        data: {
          alias: e
        }
      })
    }
    var v = function(e, t) {
        void 0 === e && (e = {});
        var {
          goodsData: n
        } = e;
        "function" == typeof t && n && t(e)
      },
      m = (e, t) => new Promise((n, r) => {
        (function(e) {
          var t = d(e);
          return Object(a.default)({
            path: "/wscgoods/tee-app/detail.json",
            data: t,
            withCredentials: !0,
            origin: "h5m",
            options: {
              useCdn: !0
            }
          })
        })(e).then(function(e) {
            if (void 0 === e && (e = {}), v(e, t), function(e) {
                void 0 === e && (e = {});
                var {
                  needRedirect: t,
                  goodsData: n
                } = e;
                return !(!t && n)
              }(e)) return n(e)
          }).catch(e => {}),
          function(e) {
            var t = () => Object(a.requestV2)({
              path: "/wscgoods/tee-app/detail-v2.json",
              data: d(e),
              withCredentials: !0
            });
            return u({
              prefetchKey: e.prefetchKey || "fetch:lanunch:goodsDetail",
              fallback: t
            }).then(e => e && e.goodsData ? e : t())
          }(e).then(function(e) {
            void 0 === e && (e = {}), v(e, t), n(e)
          }).catch(e => r(e))
      }),
      y = () => Object(a.default)({
        path: "/wscgoods/detail-api/cart-count.json",
        withCredentials: !0
      });

    function b(e) {
      return Object(a.default)({
        path: "/wscgoods/tee-app/sku-direct-order-complete.json",
        data: e,
        withCredentials: !0
      })
    }

    function _(e) {
      return Object(a.requestUseCdn)({
        path: "/wscdeco/biz-component/list.json",
        data: e,
        withCredentials: !0
      })
    }
  },
  BwoW: function(e, t, n) {
    n.d(t, "a", function() {
      return l
    });
    var r = n("Y28S"),
      a = n("w2Y9"),
      i = n.n(a),
      o = n("US/N"),
      s = n("YeA1"),
      c = n("9ZMt"),
      u = n("zjWU"),
      d = function(e, t) {
        void 0 === t && (t = "error"), u.a.end({
          name: u.b.goods_detail,
          type: t,
          level: "error" === t ? "error" : "info",
          extra: {
            message: e
          }
        })
      },
      l = (e, t, n) => {
        var {
          msg: a,
          data: u = {},
          message: l,
          deal: p
        } = e;
        if (p) return Promise.reject(e);
        "object" == typeof e && (e.deal = !0);
        var {
          NO_TRY: h
        } = e, f = a || l || u.msg || u.message || "", g = e.code || u.code, {
          showError: v = !0
        } = u || {}, m = !0;
        if (301010050 !== g && 5001001 !== g && 1001001 !== g || (h = !0, m = !1), 302 === g) {
          var {
            location: y
          } = u || {};
          f = "Redirect to " + y, v = !1;
          var {
            sl: b,
            sls: _
          } = t, O = Object(r.c)({
            sl: b,
            sls: _
          });
          if (y) {
            var S = i.a.add(y, O);
            return Object(s.a)().dmc.redirectTo(S), void d("特殊商品重定向", "finish")
          }
          m = !1
        }
        160900100 === g && (v = !1, f = "多网点，需要跳转至网点选择", m = !1), 429 !== g && 101302001 !== g && 101302002 !== g || (f = "店铺太火爆啦，请稍后重试", m = !1), m && function(e, t, n) {
          void 0 === e && (e = ""), void 0 === t && (t = {}), void 0 === n && (n = {});
          var {
            code: r = 0,
            message: a = "",
            stack: i = ""
          } = t, s = JSON.stringify({
            title: e,
            extra: {
              code: r,
              message: a,
              stack: i,
              info: t,
              extra: n
            }
          });
          Object(o.default)({
            path: "/wscgoods/log",
            method: "GET",
            data: {
              logtype: c.default.getEnv(),
              msg: s,
              timestamp: +new Date
            }
          })
        }("ext-tee-wsc-goods::page-setup:error", e, {
          query: t
        }), e.isClientError && (f = "系统繁忙，请刷新重试"), d(h ? "商品不存在" : f || "系统繁忙，请刷新重试", h || g || !v ? "finish" : "error");
        var w, I = {},
          P = (getCurrentPages() || []).length > 1,
          k = f || "系统繁忙，请刷新重试",
          j = h ? "进店逛逛" : "刷新";
        return v && m && (w = {
          name: "errorDialog",
          message: k,
          extra: e
        }, getApp().logger.requestError(w)), v && wx.showModal({
          content: k,
          showCancel: P,
          cancelText: "返回",
          confirmText: j,
          confirmColor: "#EE0A24",
          cancelColor: "#323233",
          success(e) {
            e.confirm ? h ? Object(s.a)().dmc.switchTab("Home", I) : n() : e.cancel && P && c.default.navigateBack()
          },
          fail() {
            wx.showToast({
              message: k
            })
          }
        }), Promise.reject(e)
      }
  },
  C6tv: function(e, t, n) {
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.default = function(e) {
      return null !== e && ("object" == typeof e || "function" == typeof e)
    }
  },
  CR7H: function(e, t, n) {
    n.d(t, "b", function() {
      return o
    }), n.d(t, "c", function() {
      return s
    }), n.d(t, "a", function() {
      return c
    });
    var r, a = n("bb6g"),
      i = n("oGZU"),
      o = function(e) {
        r = e
      },
      s = function(e) {
        return void 0 === e && (e = {}), Object(i.a)({
          method: "POST",
          path: "/passport/api/authorize-dialog/user-auth.json",
          origin: "uic",
          query: {
            kdt_id: r
          },
          data: Object(a.__assign)({
            protocolVersion: 1
          }, e),
          withCredentials: !0
        })
      },
      c = function(e) {
        return void 0 === e && (e = {}), Object(i.a)({
          method: "POST",
          origin: "uic",
          path: "/passport/general/login/auth.json",
          query: {
            kdt_id: r
          },
          data: e,
          withCredentials: !0
        })
      }
  },
  CzB4: function(e, t, n) {
    var r = n("w5ta"),
      a = n("RW/s"),
      i = n("0KRy");
    e.exports = function() {
      this.size = 0, this.__data__ = {
        hash: new r,
        map: new(i || a),
        string: new r
      }
    }
  },
  DLzb: function(e, t, n) {
    n.d(t, "a", function() {
      return r
    });
    var r = (e, t) => {
      e.logger.setEvent({
        params: {
          slg: t
        }
      }), e.logger.setContext({
        slg: t
      }, t ? 30 : -1)
    }
  },
  DRK6: function(e, t) {},
  DXyM: function(e, t, n) {
    n.d(t, "a", function() {
      return u
    });
    var r = n("+Y/m"),
      a = n.n(r),
      i = n("6iAT"),
      o = n.n(i),
      s = n("ucHI"),
      c = n.n(s);
    class u {
      constructor(e) {
        this.ctx = e.ctx
      }
    }
    u.widgets = {
      Main: a.a,
      EcardIntro: o(),
      CouponIntro: c()
    }
  },
  DZMJ: function(e, t, n) {
    var r = n("FEiO"),
      a = Object.prototype.hasOwnProperty;
    e.exports = function(e) {
      var t = this.__data__;
      if (r) {
        var n = t[e];
        return "__lodash_hash_undefined__" === n ? void 0 : n
      }
      return a.call(t, e) ? t[e] : void 0
    }
  },
  E5w5: function(e, t, n) {
    var r;
    ! function(e) {
      e.IOS = "ios", e.ANDROID = "android", e.UNKNOWN = "unknown"
    }(r || (r = {}))
  },
  Eagg: function(e, t, n) {
    n.d(t, "e", function() {
      return a
    }), n.d(t, "b", function() {
      return i
    }), n.d(t, "d", function() {
      return o
    }), n.d(t, "c", function() {
      return s
    }), n.d(t, "a", function() {
      return c
    });
    n("eijD"), n("9KEa"), getApp();
    var r = {};

    function a() {
      if (r.scene) return r.scene;
      var {
        scene: e
      } = wx && wx.getEnterOptionsSync ? wx.getEnterOptionsSync() || {} : wx.getLaunchOptionsSync() || {};
      return r.scene = e, r.scene
    }

    function i() {
      var e = a();
      return [1177, 1176, 1175, 1195, 1208].includes(e)
    }

    function o() {
      return 1208 === a()
    }

    function s() {
      var e = a();
      return 1177 === e || 1176 === e
    }
    wx && (null == wx.onAppHide || wx.onAppHide(() => {
      r = {}
    }));
    i();

    function c() {
      return 1195 === a()
    }
  },
  EzII: function(e, t, n) {
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.default = void 0;
    var r = function() {
      var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [],
        t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "",
        n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
        r = {};
      return e && 0 !== e.length && "string" == typeof t ? (e.forEach(function(e, a) {
        var i = n + a,
          o = t ? "".concat(t, "[").concat(i, "]") : i;
        r[o] = e
      }), r) : r
    };
    t.default = r, e.exports = t.default
  },
  F6OL: function(e, t, n) {
    var r;
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.default = void 0;
    var a = {
      compareVersions: ((r = n("NgLJ")) && r.__esModule ? r : {
        default: r
      }).default
    };
    t.default = a, e.exports = t.default
  },
  F6Qw: function(e, t, n) {
    n.d(t, "a", function() {
      return i
    });
    var r = n("ABDU"),
      a = n.n(r);
    class i {
      constructor(e) {
        this.ctx = e.ctx, this.widget = a.a
      }
    }
    i.widgets = {
      MainWidget: a()
    }
  },
  F9Sv: function(e, t, n) {
    n.d(t, "a", function() {
      return s
    });
    var r = n("9KEa"),
      a = n("QLod"),
      i = 20;

    function o(e, t, n) {
      return Math.round(e * n / t)
    }

    function s(e, t) {
      void 0 === e && (e = {}), void 0 === t && (t = {});
      var {
        windowWidth: n
      } = Object(r.b)(), {
        supportCustomNav: s = !1
      } = t, {
        detail: c = {},
        touches: [u = {}] = []
      } = e, d = c.x || u.pageX, l = c.y || u.pageY;
      if ("number" != typeof d || "number" != typeof l) return null;
      var p = Object(a.e)();
      if (s) {
        if (l <= p) return null;
        l -= p
      }
      return {
        loc_x: o(d, n, i),
        loc_y: o(l, n, i)
      }
    }
  },
  FEiO: function(e, t, n) {
    var r = n("LSEb")(Object, "create");
    e.exports = r
  },
  FfeU: function(e, t) {
    var n = "object" == typeof global && global && global.Object === Object && global;
    e.exports = n
  },
  GE03: function(e, t, n) {
    var r = n("xkFB"),
      a = n("4mhO"),
      i = n("4a20");

    function o(e) {
      var t = -1,
        n = null == e ? 0 : e.length;
      for (this.__data__ = new r; ++t < n;) this.add(e[t])
    }
    o.prototype.add = o.prototype.push = a, o.prototype.has = i, e.exports = o
  },
  GFa9: function(e, t, n) {
    var r = n("2wjL"),
      a = n("8B9M"),
      i = {
        navigate: o,
        redirect: s
      };

    function o(e) {
      void 0 === e && (e = {}), (getCurrentPages() || []).length >= 10 ? s(e) : wx.navigateTo(e)
    }

    function s(e) {
      void 0 === e && (e = {}), wx.redirectTo(e)
    }
    t.a = {
      switchTab: function(e, t) {
        void 0 === e && (e = {}), void 0 === t && (t = "navigate");
        var n = Object(a.a)(),
          r = i[t] || o;
        n.isSwitchTab(e.url).then(t => {
          if (t) return wx.reLaunch(e);
          r(e)
        })
      },
      navigate: o,
      redirect: s,
      reLaunch: function(e) {
        void 0 === e && (e = {}), wx.reLaunch(e)
      },
      contactBack: function(e) {
        var {
          detail: t
        } = e;
        t.path && wx.navigateTo({
          url: r.a.add(t.path, t.query)
        })
      },
      navigateWithBack: function(e) {
        var t = function(e) {
          var t = -1,
            n = getCurrentPages() || [],
            a = n.findIndex(t => {
              var {
                route: n,
                options: a
              } = t, i = r.a.add(n, a);
              return i === e || "/" + i === e
            });
          a > -1 && (t = n.length - a - 1);
          return t
        }(e.url);
        if (t > -1) return wx.navigateBack({
          delta: t
        });
        o(e)
      }
    }
  },
  GGNd: function(e, t, n) {
    n.d(t, "a", function() {
      return a
    });
    var r = n("/XVY"),
      a = Object(r.a)({
        tags: {
          default: () => []
        },
        type: {
          default: ""
        }
      })
  },
  GI0s: function(e, t, n) {
    var r = n("jgJv"),
      a = n("vMVM"),
      i = n("HLVI"),
      o = r ? r.toStringTag : void 0;
    e.exports = function(e) {
      return null == e ? void 0 === e ? "[object Undefined]" : "[object Null]" : o && o in Object(e) ? a(e) : i(e)
    }
  },
  GRMa: function(e, t, n) {
    n.d(t, "a", function() {
      return a
    }), n.d(t, "f", function() {
      return i
    }), n.d(t, "g", function() {
      return o
    }), n.d(t, "b", function() {
      return s
    }), n.d(t, "c", function() {
      return c
    }), n.d(t, "d", function() {
      return u
    }), n.d(t, "e", function() {
      return d
    });
    var r = n("h+Rz");

    function a(e) {
      return r.a.getShareInfo(e)
    }

    function i(e) {
      return r.a.showShareMenu(e)
    }

    function o(e) {
      return r.a.updateShareMenu(e)
    }

    function s(e) {
      return void 0 === e && (e = ["shareAppMessage", "shareTimeline"]), r.a.hideShareMenu(e)
    }

    function c(e) {
      return r.a.shareFileMessage(e)
    }

    function u(e) {
      return r.a.shareVideoMessage(e)
    }

    function d(e) {
      return r.a.showShareImageMenu(e)
    }
  },
  GUWE: function(e, t, n) {
    n.d(t, "a", function() {
      return u
    }), n.d(t, "b", function() {
      return d
    }), n.d(t, "c", function() {
      return l
    });
    var r = n("Fcif"),
      a = n("ONqW"),
      i = n("NHEX"),
      o = n.n(i),
      s = n("noo5"),
      c = (n("BrFj"), n("hcPn"));
    var u = (e, t) => t.needGetLocation ? Object(c.b)().then(e => {
      var {
        longitude: t,
        latitude: n
      } = e;
      return Promise.resolve({
        lng: +t,
        lat: +n
      })
    }).catch(() => Promise.resolve({
      lng: 0,
      lat: 0
    })) : Promise.resolve({
      lat: 0,
      lng: 0
    });

    function d(e, t) {
      var {
        lng: n,
        lat: i
      } = t, {
        goodsData: s,
        shopData: c,
        pageParams: u,
        offlineData: d,
        shopMetaInfo: l
      } = e, {
        alias: p,
        goods: {
          id: h
        },
        shopConfig: f = {},
        delivery: g = {}
      } = s, {
        kdtId: v
      } = c, {
        id: m
      } = d || {}, {
        shopType: y,
        shopRole: b
      } = l, {
        supportExpress: _ = !0,
        supportLocalDelivery: O = !0,
        supportSelfFetch: S = !0
      } = g, {
        hideShoppingCart: w = 0,
        freightInsurance: I = 1,
        isGift: P = 1,
        isWebImInGoods: k = 1,
        isWish: j = 1,
        showBuyBtn: x = 1,
        showShopBtn: T = 1,
        showWscWebIm: E = 1,
        scrmCreditDiyName: A = "{}",
        goodsActivityTagsPreposition: C = 1
      } = f, D = {};
      try {
        D = JSON.parse(A)
      } catch (e) {}
      var {
        name: M = "积分"
      } = D, N = Object(r.a)({}, u, {
        alias: p,
        goodsId: h,
        kdtId: v,
        offlineId: m,
        stockNum: o()(s, "skuInfo.spuStock.stockNum", 0),
        supportExpress: _,
        supportLocalDelivery: O,
        supportSelfFetch: S,
        shopType: y,
        shopRole: b,
        pointsName: M,
        hideShoppingCart: w,
        freightInsurance: I,
        isGift: P,
        isWebImInGoods: k,
        isWish: j,
        showBuyBtn: x,
        showShopBtn: T,
        showWscWebIm: E,
        soldOutRecommendSwitch: o()(s, "shop.multiStore.setting.soldOutRecommendSwitch", !1),
        isFastBuy: o()(s, "fastbuyFeature.isFastBuy", !1),
        buyBtnConfig: o()(s, "shopConfig.buyBtnConfig", ""),
        goodsActivityTagsPreposition: C,
        extra: {
          needUnstartActivityInfo: "true",
          fullPresaleSupportCart: "true"
        }
      }), {
        shareUserId: L,
        shareGroupId: U
      } = u || {};
      N.extra = Object(r.a)({}, N.extra, {
        shareUserId: L,
        shareGroupId: U
      });
      var R = Object(a.a)().getLogParams() || {},
        {
          scene: B
        } = R.context || {};
      1177 === B && (N.extra = {
        sceneId: String(B)
      }, d.status && d.offlineSettings && d.offlineSettings.separateStock && (N.extra.independentStock = "1"));
      return Object(r.a)({}, N, {
        lng: n,
        lat: i
      })
    }

    function l(e, t) {
      return Promise.resolve().then(() => u(e, t.offlineData)).then(e => {
        var {
          lng: n,
          lat: a
        } = e;
        return ((e, t) => {
          var {
            lng: n = 0,
            lat: a = 0
          } = t, {
            offlineData: i = {}
          } = e, o = d(e, {
            lng: n,
            lat: a
          });
          return Promise.resolve(e).then(function(t) {
            void 0 === t && (t = {});
            var c = function(e, t) {
                void 0 === e && (e = {});
                var {
                  marketing: n,
                  pageFeature: r,
                  quotaUsed: a,
                  hasPurchaseRight: i,
                  haitaoTariffAmount: o = "",
                  salableStores: s,
                  soldNum: c,
                  spuStock: u,
                  skuStocks: d,
                  buyLimitType: l,
                  physicalStores: p,
                  buyLimitGuideInfo: h,
                  bosWorkFlow: f,
                  itemExtendInfo: g = {},
                  logistics: v,
                  wholesalerModel: m
                } = e;
                return {
                  pageFeature: r,
                  goodsExtra: {
                    quotaUsed: a,
                    hasPurchaseRight: i,
                    haitaoTariffAmount: o,
                    pointsName: t
                  },
                  buyLimitType: l,
                  salableStores: s,
                  soldNum: c,
                  spuStock: u,
                  skuStocks: d,
                  isFastBuy: !1,
                  marketing: n,
                  physicalStores: p,
                  buyLimitGuideInfo: h,
                  bosWorkFlow: f,
                  itemExtendInfo: g,
                  logistics: v,
                  wholesalerModel: m
                }
              }(t, o.pointsName),
              {
                lng: u,
                lat: d
              } = i.address || {},
              l = Object(s.calculateDistance)(d, u, a, n);
            return c.geoLocationData = {
              distance: l,
              lng: n,
              lat: a
            }, c.userGoodsStateParams = o, Promise.resolve(Object(r.a)({}, e, c))
          })
        })(t, {
          lng: n,
          lat: a
        })
      })
    }
  },
  "GXW/": function(e, t, n) {
    var r = n("Fcif"),
      a = n("lOd/"),
      i = n("OPDa"),
      o = n("x5Yp"),
      s = n("GrZP");
    t.a = Behavior({
      behaviors: [s.a],
      methods: {
        getComponentLoggerExtraParams(e) {
          return void 0 === e && (e = {}), Object(o.a)(e) && (e = this.data.componentData), Object(a.a)(e)
        },
        getComponentIndex() {
          var {
            componentData: e
          } = this.data, {
            componentIndex: t = 0
          } = e;
          return t
        },
        getComponentLoggerType(e) {
          return void 0 === e && (e = ""), e || (e = this.data.componentData.type), Object(a.b)(e)
        },
        getLoggerSpm: () => i.a.getPageSpmTypeId(),
        getPageRandomNumber: () => a.c,
        getBannerId(e) {
          return void 0 === e && (e = 0), this.getLoggerSpm() + "~" + this.getComponentLoggerType() + "." + (this.getComponentIndex() + 1) + "~" + e + "~" + this.getPageRandomNumber()
        },
        getCloudLoggerInfo(e) {
          var t = getCurrentPages(),
            {
              loggerParams: n,
              top: a,
              left: i,
              title: o
            } = e,
            {
              components_style_is_hotarea: s,
              item_type: c
            } = n || {},
            u = s ? {
              hotarea_top: a,
              hotarea_left: i
            } : {};
          return "image_ad" === c && (u.image_title = o), Object(r.a)({
            page_url: t[t.length - 1].route,
            img_url: e.imageUrl
          }, u)
        }
      }
    })
  },
  GYYO: function(e, t, n) {
    n.d(t, "a", function() {
      return r
    });
    var r = Behavior({
      properties: {
        url: String,
        linkType: {
          type: String,
          value: "navigateTo"
        }
      },
      methods: {
        jumpLink(e) {
          void 0 === e && (e = "url");
          var t = this.data[e];
          t && ("navigateTo" === this.data.linkType && getCurrentPages().length > 9 ? wx.redirectTo({
            url: t
          }) : wx[this.data.linkType]({
            url: t
          }))
        }
      }
    })
  },
  GrZP: function(e, t, n) {
    var r = n("XCh3");
    t.a = Behavior({
      methods: {
        ensureAppLogger(e, t) {
          if ("view" !== e || t.length) {
            var n = Object(r.b)(e, t);
            Object(r.a)(n)
          }
        }
      }
    })
  },
  "HC+1": function(e, t, n) {
    n.d(t, "b", function() {
      return U
    }), n.d(t, "a", function() {
      return R
    });
    var r = n("bb6g"),
      a = n("pn6R"),
      i = n.n(a),
      o = n("QxN7"),
      s = n("R4YI"),
      c = n("BILe"),
      u = n("CR7H"),
      d = n("mQt2"),
      l = o.platform.authLogger.logAll,
      p = function(e) {
        return Object(d.a)().then(function(t) {
          return t.getUserAuthData(e)
        })
      },
      h = function(e) {
        return Object(d.a)().then(function(t) {
          return t.getFallbackUserAuthData(e)
        })
      },
      f = function(e) {
        return Object(u.c)(Object(r.__assign)({
          url: ""
        }, e)).catch(function(t) {
          throw l({
            logName: "更新用户授权状态异常",
            logData: Object(r.__assign)(Object(r.__assign)({}, e), {
              errMsg: Object(o.getErrorMsg)(t)
            })
          }), t
        })
      },
      g = n("eWMZ"),
      v = n("YeA1"),
      m = function(e) {
        var t = "授权组件初始化降级",
          n = Object(r.__assign)(Object(r.__assign)({}, e), {
            tee_env: o.teeEnv,
            component: "user_authorize"
          });
        ! function(e) {
          var t = (Object(v.a)() || {}).logger;
          "function" == typeof(null == t ? void 0 : t.log) && t.log(e)
        }({
          ei: "user_authorize_demotion",
          et: "custom",
          en: t,
          params: n
        }), o.platform.authLogger.logSkynet(t, n)
      },
      y = n("bmpj"),
      b = o.platform.authLogger.logAll,
      _ = function(e) {
        var t = e.scene,
          n = e.authTypeList,
          r = e.kdtId,
          a = e.appId,
          i = e.ignoreCache,
          s = e.nativeAbility,
          c = e.needLatestNicknameAndAvatar,
          u = e.needUnionId,
          d = e.retryCount,
          l = void 0 === d ? 0 : d,
          f = p({
            authTypeList: n,
            scene: t,
            kdtId: r,
            appId: a,
            nativeAbility: s,
            needLatestNicknameAndAvatar: c,
            needUnionId: u,
            ignoreCache: i
          }),
          v = new Promise(function(e, t) {
            setTimeout(function() {
              return t("获取授权数据超时")
            }, g.b)
          });
        return Promise.race([f, v]).then(function(t) {
          return {
            authData: t,
            authOptions: e
          }
        }).catch(function(r) {
          var a = Object(o.getErrorMsg)(r);
          if (b({
              logName: "授权组件获取数据异常",
              logData: {
                errMsg: a,
                error: r,
                options: e,
                retryCount: l
              }
            }), !(l >= 3)) throw r;
          return h({
            scene: t,
            authTypeList: n,
            needLatestNicknameAndAvatar: c,
            needUnionId: u
          }).then(function(t) {
            return m({
              reason: a,
              options: e
            }), {
              authData: t,
              authOptions: e,
              downgrade: !0,
              error: r
            }
          })
        }).catch(function(e) {
          throw e
        })
      },
      O = function(e) {
        var t = e.authTypeList,
          n = e.hasAuth,
          r = e.scene,
          a = e.userDeny,
          i = e.bizDataMap;
        return n ? Promise.resolve() : f(a ? {
          denyList: t,
          scene: r
        } : {
          typeList: t,
          bizDataMap: Object(y.a)(i)
        })
      },
      S = n("0WZd"),
      w = n("7yS6"),
      I = n.n(w),
      P = o.platform.authLogger,
      k = P.logAuthClick,
      j = P.logAuthOne,
      x = P.logAuthEnd,
      T = P.logSkynet,
      E = I()(k, 3e3, {
        trailing: !0
      }),
      A = {
        getLogParams: function(e) {
          var t = this.$_initData || {},
            n = t.authData || {},
            a = this.userInfo || {};
          try {
            var s = Object(r.__assign)(Object(r.__assign)({}, e), {
              eventTime: Date.now(),
              ctx: {
                cpnType: "tee",
                kdtId: this.kdtId,
                privacy: this.authState,
                authPopType: this.authPopType,
                buttonType: this.buttonType,
                dialogType: this.dialogType,
                authTypeList: this.userAuthList,
                authPopTypeList: this.authList,
                nativeAuthPopType: this.nativeAuthPopType,
                nativeAbility: this.nativeAbility,
                supportFillNick: this.supportFillNick,
                noMobileFallback: this.noMobileFallback,
                allowDenyMap: this.$_authAllowDenyMap,
                status: this.status,
                downgrade: this.downgrade,
                authorizing: this.authorizing,
                retryCount: this.$_retryCount,
                errMsg: Object(o.getErrorMsg)(this.$_error)
              },
              biz: {
                scene: this.scene,
                authTypeList: this.authTypeList,
                allowDeny: this.allowDeny,
                cpnMode: this.type,
                disabled: this.disabled,
                needUnionId: this.needGetUnionId,
                needLatestNicknameAndAvatar: this.needUpdateNicknameAndAvatar
              },
              userInfo: {
                uid: a.userId,
                login: Object(S.d)(a.hasLogin)
              },
              init: {
                downgrade: t.downgrade,
                errMsg: Object(o.getErrorMsg)(t.error),
                privacy: n.authState,
                customAuthData: n.customAuthData,
                sceneAuthData: n.sceneAuthData
              }
            });
            return i()(s)
          } catch (e) {
            return T("授权日志转换异常", {
              errMsg: Object(o.getErrorMsg)(e),
              err: e
            }), {}
          }
        },
        logAuthClick: function(e) {
          E(this.getLogParams(e))
        },
        logAuthOne: function(e) {
          var t;
          j(this.getLogParams({
            auth: {
              cur: {
                mobile: e.mobile,
                authPopType: e.authPopType,
                authTypeList: e.authTypeList,
                authPopTypeList: e.authPopTypeList,
                agree: Object(S.d)(e.agree),
                allowDeny: Object(S.d)(e.allowDeny),
                verifyType: null !== (t = e.verifyType) && void 0 !== t ? t : o.MobileVerifyType.Unknown
              },
              his: this.$_authHistory
            }
          }))
        },
        logAuthEnd: function(e) {
          var t = (e || {}).success;
          x(this.getLogParams({
            success: Object(S.d)(t)
          }))
        }
      },
      C = {
        execAuthOneAfterHooks: function(e) {
          var t = e.agree,
            n = e.authTypes,
            r = void 0 === n ? [] : n,
            a = {
              actionType: t ? o.AuthActionType.Agree : o.AuthActionType.Disagree,
              authTypeList: r,
              authState: this.authState,
              leftAuthTypeList: this.userAuthList.slice(0),
              pageUrl: Object(o.getPageURL)()
            };
          return o.hooks.executeHookAsync(o.hooks.authorizeHook.authItemAfter.get, [a], !0).then(function(e) {
            var t = e;
            return Array.isArray(e) && e.length && (t = e[0]), void 0 === t || !!t
          }).catch(function(e) {
            return !1
          })
        }
      },
      D = o.platform.authLogger.logAll,
      M = Object(r.__assign)(Object(r.__assign)(Object(r.__assign)({}, A), C), {
        handleBtnClick: function(e) {
          Object(s.b)(s.a.buttonClickAfter.get), this.logAuthClick({
            btnDetail: e
          })
        },
        handleBtnDisabledClick: function(e) {
          var t = this,
            n = function(n) {
              t.logAuthClick({
                message: n,
                btnDetail: e
              })
            };
          n("授权组件按钮快速点击"), !this.authorizing && this.disabled && (this.status === c.a.ERROR && (this.$_retryCount = this.$_retryCount + 1 || 1, n("授权组件按钮点击重试"), this.rerender({
            source: "retry",
            ignoreCache: !0
          })), this.showToast({
            message: "系统处理中，请稍后重试",
            forbidClick: !0
          }))
        },
        rerender: function(e) {
          var t = this;
          if (!this.ready) return Promise.reject("unready");
          if (this.disabled) return this.buttonType = -1, this.status = c.a.NONE, Promise.reject("disabled");
          Object(u.b)(this.kdtId);
          var n = e || {},
            r = n.source,
            a = n.nativeAbility,
            i = n.ignoreCache,
            s = void 0 !== i && i;
          return this.status = c.a.PENDING, this.fetchAuthData({
            ignoreCache: s,
            nativeAbility: a
          }).then(this.renderAuthData).then(function(e) {
            return t.status = c.a.READY, t.$_error = null, e
          }).catch(function(e) {
            throw t.status = c.a.ERROR, t.$_error = e, D({
              logName: "授权组件渲染异常",
              logData: {
                errMsg: Object(o.getErrorMsg)(e),
                error: e
              }
            }), "retry" === r && t.showToast({
              message: "授权初始化失败，请稍后重试",
              forbidClick: !0
            }), e
          })
        },
        fetchAuthData: function(e) {
          var t = e || {},
            n = t.ignoreCache,
            r = t.nativeAbility;
          return _({
            ignoreCache: n,
            nativeAbility: r,
            kdtId: this.kdtId,
            appId: this.appId || Object(o.getAppId)(),
            scene: this.scene,
            authTypeList: this.authTypeList,
            needLatestNicknameAndAvatar: this.needUpdateNicknameAndAvatar,
            needUnionId: this.needGetUnionId,
            retryCount: this.$_retryCount
          })
        },
        renderAuthData: function(e) {
          var t = this,
            n = e.authData,
            r = e.downgrade,
            a = n.authPopType,
            o = n.authState,
            s = n.authTypeList,
            c = n.authPopTypeList,
            u = n.userInfo,
            d = n.platformConfig,
            l = n.authButtonType,
            p = n.authDialogType,
            h = n.sceneAuthData,
            f = n.nativeAuthPopType,
            g = n.nativeAbility,
            v = n.supportFillNickAvatar,
            m = n.randomNickList,
            y = n.noMobileFallback,
            b = (h || {}).authAllowDenyMap;
          return this.authPopType = a || "", this.buttonType = l || "", this.dialogType = p || "", this.authState = o, this.userAuthList = s, this.authList = c, this.nativeAuthPopType = f || "", this.userInfo = u, this.supportFillNick = v, this.aNickList = m, this.noMobileFallback = !!y, this.config = d, this.downgrade = r, this.$_nativeAbility = g, this.$_authAllowDenyMap = b, Promise.resolve().then(function() {
            t.$_initData = i()(e)
          }).catch(function(e) {}), e
        },
        updateAuth: function(e) {
          var t = e.authTypeList,
            n = e.userDeny,
            r = e.hasAuth,
            a = e.bizDataMap;
          return O({
            scene: this.scene,
            authTypeList: t,
            hasAuth: r,
            userDeny: n,
            bizDataMap: a
          })
        },
        updateAuthNext: function(e) {
          var t = this,
            n = e.authPopType,
            r = e.authTypeList,
            a = e.agree,
            i = e.nextAuthData;
          return this.execAuthOneAfterHooks({
            authTypes: r,
            agree: a
          }).then(function(e) {
            e && a && i.authPopType !== n && t.showPopup()
          })
        },
        handleAuthStatusChange: function(e) {
          var t = (e || {}).authorizing;
          this.authorizing = t
        },
        handleAuthorize: function(e) {
          var t = this,
            n = e || {},
            a = n.userAuthList,
            i = void 0 === a ? [] : a,
            s = n.type,
            c = n.popupType,
            u = n.hasAuth,
            d = n.data,
            l = n.cb,
            p = n.onError,
            h = n.userDeny,
            f = n.allowDeny,
            g = d || {},
            v = g.mobile,
            m = g.verifyType,
            y = g.needMobileAuth,
            b = !h,
            _ = {
              authPopType: s,
              agree: b,
              authTypeList: i,
              allowDeny: f,
              mobile: v,
              verifyType: m,
              needMobileAuth: y
            },
            O = function(e) {
              try {
                l && l()
              } catch (e) {}
              return e
            };
          if (!s) return O(), void this.success();
          var w = Array.isArray(s) ? s : [s];
          this.authorizing = !0, this.updateAuth({
            authTypeList: i,
            userDeny: h,
            hasAuth: u,
            bizDataMap: this.bizDataMap
          }).then(function() {
            if (t.$_authHistory = (t.$_authHistory || []).concat(s + "_" + Object(S.d)(b)), t.logAuthOne(_), b && w.includes(o.AuthPopType.MOBILE)) return new Promise(function(e) {
              t.$emit("on-login", function() {
                return e()
              })
            })
          }).then(function() {
            return t.fetchAuthData({
              ignoreCache: !0
            })
          }).then(O).then(function(e) {
            return Promise.resolve().then(function() {
              b && t.exposeAuthPopupEvent(w, c, "auth-popup-allow"), t.$_event.authSuccess({
                authTypeList: i,
                authPopTypeList: w,
                scene: t.scene,
                userDeny: h
              })
            }), e
          }).then(function(e) {
            return Object(S.c)(200).then(function() {
              return e
            })
          }).then(function(e) {
            t.renderAuthData(e);
            var n = e.authData;
            return 0 === n.authTypeList.length ? (t.logAuthEnd({
              success: !0
            }), void t.success()) : t.updateAuthNext({
              authPopType: s,
              authTypeList: i,
              agree: b,
              nextAuthData: n
            })
          }).catch(function(e) {
            var n = Object(o.getErrorMsg)(e);
            throw D({
              logName: "单项授权异常",
              logData: Object(r.__assign)(Object(r.__assign)({}, _), {
                errMsg: n,
                err: e
              })
            }), t.showToast({
              message: "授权失败，" + (n || "请稍后重试")
            }), p && p(e), e
          }).finally(function() {
            t.authorizing = !1
          })
        }
      }),
      N = n("pTxV"),
      L = {
        appId: String,
        customStyle: String,
        scene: String,
        authTypeList: {
          type: Array,
          value: []
        },
        kdtId: Number,
        trigger: String,
        needUpdateNicknameAndAvatar: {
          type: Boolean,
          default: !1
        },
        needGetUnionId: {
          type: Boolean,
          default: !1
        },
        type: {
          type: String,
          default: N.UserAuthorizeType.NORMAL
        },
        zIndex: Number,
        desc: {
          type: String,
          default: void 0
        },
        disabled: {
          type: Boolean,
          default: !1
        },
        privacyProtocol: Object,
        userProtocol: Object,
        popupCustomStyle: String,
        allowDeny: Boolean,
        protocolSource: String,
        protocolIsCloudSlot: {
          type: Boolean,
          default: !1
        },
        bizDataMap: Object
      },
      U = function(e) {
        return Object(r.__assign)(Object(r.__assign)({}, L), e)
      },
      R = function(e) {
        return Object(r.__assign)(Object(r.__assign)({}, M), e)
      }
  },
  HE1N: function(e, t, n) {
    var r = n("cm7J"),
      a = Array.prototype.splice;
    e.exports = function(e) {
      var t = this.__data__,
        n = r(t, e);
      return !(n < 0) && (n == t.length - 1 ? t.pop() : a.call(t, n, 1), --this.size, !0)
    }
  },
  HLVI: function(e, t) {
    var n = Object.prototype.toString;
    e.exports = function(e) {
      return n.call(e)
    }
  },
  HbRL: function(e, t, n) {
    function r(e, t) {
      try {
        if (e === t || !e || !t) return 0;
        for (var n = e.split("."), r = t.split("."), a = n.length, i = r.length, o = 0, s = Math.min(a, i); o < s; o++) {
          var c = parseInt(n[o], 10),
            u = parseInt(r[o], 10);
          if (isNaN(c) && (c = 0), isNaN(u) && (u = 0), c !== u) return c > u ? 1 : -1
        }
        return a > i ? 1 : a < i ? -1 : 0
      } catch (e) {
        return -1
      }
    }
    n.d(t, "a", function() {
      return r
    })
  },
  Hhx2: function(e, t, n) {
    n.d(t, "a", function() {
      return o
    }), n.d(t, "h", function() {
      return c
    }), n.d(t, "e", function() {
      return u
    }), n.d(t, "d", function() {
      return d
    }), n.d(t, "i", function() {
      return l
    }), n.d(t, "c", function() {
      return p
    }), n.d(t, "g", function() {
      return h
    }), n.d(t, "f", function() {
      return f
    }), n.d(t, "b", function() {
      return g
    });
    var r = n("Fcif"),
      a = n("taYb"),
      i = n("a1Mm"),
      o = function(e) {
        void 0 === e && (e = {});
        var t = (e = a.a.toCamelCase(e)).tree && e.tree.map(e => {
          var t = e.v.map(e => (e.imgUrl = Object(i.a)(e.imgUrl), e));
          return Object(r.a)({}, e, {
            v: t
          })
        });
        return Object(r.a)({}, e, {
          tree: t
        })
      },
      s = function(e) {
        void 0 === e && (e = []);
        var t = {};
        return e.forEach(e => {
          t[e.kS] = e.v
        }), t
      },
      c = function(e, t) {
        void 0 === e && (e = []);
        var n = Object.keys(t).filter(e => "" !== t[e]);
        return e.length === n.length
      },
      u = function(e, t) {
        return void 0 === e && (e = []), e.filter(e => Object.keys(t).every(n => String(e[n]) === String(t[n])))[0]
      },
      d = function(e, t) {
        if (void 0 === e && (e = []), 0 === e.length) return [];
        var n = s(e);
        return Object.keys(t).reduce((e, r) => {
          var a = n[r],
            i = t[r];
          if ("" !== i) {
            var o = a.filter(e => e.id === i)[0];
            o && e.push(o)
          }
          return e
        }, [])
      },
      l = function(e, t, n) {
        void 0 === e && (e = []);
        var {
          key: a,
          valueId: i
        } = n, o = Object(r.a)({}, t || {}, {
          [a]: i
        }), s = Object.keys(o).filter(e => "" !== o[e]);
        return e.filter(e => s.every(t => String(o[t]) === String(e[t]))).reduce((e, t) => e + t.stockNum, 0) > 0
      },
      p = (e, t) => {
        var n = [];
        return (e || []).forEach(e => {
          if (t[e.kId] && t[e.kId].length > 0) {
            var a = [];
            e.v.forEach(n => {
              t[e.kId].indexOf(n.id) > -1 && a.push(Object(r.a)({}, n))
            }), n.push(Object(r.a)({}, e, {
              v: a
            }))
          }
        }), n
      },
      h = (e, t) => 0 === e.length || !e.filter(e => {
        var {
          isNecessary: t
        } = e;
        return !1 !== t
      }).some(e => {
        var {
          kId: n
        } = e;
        return 0 === (t[n] || []).length
      }),
      f = e => {
        var {
          skuTree: t = [],
          selectedSku: n,
          properties: r,
          selectedProp: a
        } = e, i = t.filter(e => !n[e.kS]).map(e => {
          var {
            k: t
          } = e;
          return t
        }), o = r.filter(e => {
          var {
            isNecessary: t
          } = e;
          return !1 !== t
        }).filter(e => {
          var {
            kId: t
          } = e;
          return 0 === (a[t] || []).length
        }).map(e => {
          var {
            k: t
          } = e;
          return t
        });
        return [...i, ...o].length > 0 ? "请选择" + [...i, ...o].join("、") : ""
      };

    function g(e) {
      var {
        available_coupon_act_ids: t,
        availableCouponActIds: n
      } = e.option || {};
      return t && t.length ? t[0] : n && n.length ? n[0] : null
    }
  },
  HmHG: function(e, t, n) {
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.default = function(e, t, n) {
      var r, a, i = n || {},
        o = i.leading,
        s = i.trailing,
        c = 0,
        u = function() {
          for (var t = [], n = 0; n < arguments.length; n++) t[n] = arguments[n];
          c = !1 === o ? 0 : new Date().getTime(), r = null, e.apply(a, t), r || (a = null)
        },
        d = function() {
          for (var n = [], i = 0; i < arguments.length; i++) n[i] = arguments[i];
          var d = new Date().getTime();
          c || !1 !== o || (c = d);
          var l = t - (d - c);
          a = this, l <= 0 || l > t ? (r && clearTimeout(r), r = null, c = d, e.apply(a, n), r || (a = null)) : r || !1 === s || (r = setTimeout(function() {
            return u.apply(a, n)
          }, l))
        };
      return d.cancel = function() {
        r && clearTimeout(r), c = 0, r = null
      }, d
    }
  },
  IIov: function(e, t, n) {
    var r;
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.default = void 0;
    var a = ((r = n("49Kr")) && r.__esModule ? r : {
      default: r
    }).default;
    t.default = a, e.exports = t.default
  },
  IL7q: function(e, t, n) {
    var r = Object.getOwnPropertySymbols,
      a = Object.prototype.hasOwnProperty,
      i = Object.prototype.propertyIsEnumerable;

    function o(e) {
      if (null == e) throw new TypeError("Object.assign cannot be called with null or undefined");
      return Object(e)
    }
    e.exports = function() {
      try {
        if (!Object.assign) return !1;
        var e = new String("abc");
        if (e[5] = "de", "5" === Object.getOwnPropertyNames(e)[0]) return !1;
        for (var t = {}, n = 0; n < 10; n++) t["_" + String.fromCharCode(n)] = n;
        if ("0123456789" !== Object.getOwnPropertyNames(t).map(function(e) {
            return t[e]
          }).join("")) return !1;
        var r = {};
        return "abcdefghijklmnopqrst".split("").forEach(function(e) {
          r[e] = e
        }), "abcdefghijklmnopqrst" === Object.keys(Object.assign({}, r)).join("")
      } catch (e) {
        return !1
      }
    }() ? Object.assign : function(e, t) {
      for (var n, s, c = o(e), u = 1; u < arguments.length; u++) {
        for (var d in n = Object(arguments[u])) a.call(n, d) && (c[d] = n[d]);
        if (r) {
          s = r(n);
          for (var l = 0; l < s.length; l++) i.call(n, s[l]) && (c[s[l]] = n[s[l]])
        }
      }
      return c
    }
  },
  J8k1: function(e, t, n) {
    t.a = ["text", "title", "store", "search", "feature_video_search", "coupon", "cube_v3", "notice", "groupon", "points_goods", "goods", "goods_recommend", "tag_list_top", "tag_list_left", "ump_seckill"]
  },
  J9xP: function(e, t, n) {
    var r = n("cm7J");
    e.exports = function(e) {
      return r(this.__data__, e) > -1
    }
  },
  JdrY: function(e, t, n) {
    n.d(t, "j", function() {
      return r
    }), n.d(t, "e", function() {
      return a
    }), n.d(t, "f", function() {
      return i
    }), n.d(t, "g", function() {
      return o
    }), n.d(t, "l", function() {
      return s
    }), n.d(t, "k", function() {
      return c
    }), n.d(t, "h", function() {
      return u
    }), n.d(t, "a", function() {
      return d
    }), n.d(t, "d", function() {
      return l
    }), n.d(t, "i", function() {
      return p
    }), n.d(t, "b", function() {
      return h
    }), n.d(t, "c", function() {
      return f
    });
    var r = {
        HOME: 1,
        CART: 2,
        WISH: 3,
        CONTACT: 4,
        SHARE: 5,
        USERCENTER: 6,
        BACK_TO_TOP: 7,
        SCAN: 8,
        GUANG_LIVE: 20,
        GOODS_SHOWCASE: 21,
        WECHAT_VIDEO: 22,
        CUSTOME: [101, 102, 103, 104, 105, 106, 107, 108, 109]
      },
      a = {
        1: "主页",
        2: "购物车",
        3: "心愿单",
        4: "客服",
        5: "分享",
        6: "个人中心",
        7: "顶部",
        8: "扫一扫"
      },
      i = {
        1: "/pages/home/dashboard/index",
        "1-retail": "/pages-retail/home-shelf/index",
        2: "/packages/goods/cart/index",
        6: "/packages/usercenter/dashboard/index",
        "6-retail": "/packages/retail/usercenter/dashboard-v2/index"
      },
      o = /\/(v2|wscshop)\/(showcase\/)?(goods|seckill)(\/adv)?/,
      s = /\/wscgoods\/wholesale_detail/,
      c = {
        1: [/^(packages|pages)\/home\/dashboard/, /^packages\/tee-home|ext-home\/dashboard/, /\/(v2|wscshop)\/(showcase\/)?(homepage|home)/],
        3: [/^(packages|pages)\/home\/feature/, /^packages\/tee-home|ext-home\/feature/, /^(packages|pages)\/home\/tab/, /^packages\/ext-home\/tab\/(one|two|three)/, /\/(v2|wscshop)\/(showcase\/)?feature(?!\/goods\/all)/],
        8: [/^pages\/goods\/detail/, /^packages\/goods(:?-v\d+)?\//, o, /\/wscgoods\/(detail|seckill)/, s, /\/pay\/wscgoods_order/],
        9: [/^packages\/shop\/goods\/all/, /^packages\/shop\/goods\/group/, /^packages\/goods-list\/tag/, /^packages\/goods-list\/all/, /^packages\/shop\/goods\/tag-list\/index/, /\/wscshop\/(tag|allgoods)/, /\/v2\/(showcase\/)?(tag|allgoods)/, /\/feature\/goods\/all/, /\/wscshop\/showcase\/tag/]
      },
      u = {
        HOME: 1,
        FEATURE: 3,
        GOODS_DETAIL: 8,
        GOODS_GROUP: 9
      },
      d = {
        ADD_CART: "submit:act",
        PULL_DOWN: "home:refresh",
        SHARE: "share:show",
        SHOW_GOODS_CASE: "goods:showcase",
        PAGE_SCROLL: "page:scroll",
        CREATE_OR_UPDATE_INDEPENDENT_ICON: "create:or:update:inderendent:icon",
        UPDATE_ICON_POSITION: "floating:nav:update:position",
        SHOW_WISH_PANEL: "floating:nav:wish:show",
        WISH_STATE_CHANGE: "wish:state:change"
      },
      l = {
        1: !0,
        3: !0,
        8: !0,
        9: !1
      },
      p = {
        1: "homepage",
        3: "micropage"
      },
      h = {
        GOODS_SHOWCASE: 10
      },
      f = {
        iconUrl: "https://b.yzcdn.cn/public_files/53ad2c5a0f8d476e9a9ccf9fadff7710.png",
        independent: !0,
        navType: 5,
        order: 1,
        status: 1,
        title: "分享",
        isExtra: !0,
        isReplace: !0
      }
  },
  JijB: function(e, t, n) {
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.default = function(e) {
      var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "YYYY:MM:DD";
      e || 0 === e || (e = new Date);
      if ("Invalid Date" === (e = new Date(e)).toString()) throw new Error("Invalid Date");
      var n = function(e) {
          return ("00" + e).slice(-2)
        },
        r = {
          "YYYY|yyyy": e.getFullYear(),
          "YY|yy": e.getFullYear().toString().substr(2),
          MM: n(e.getMonth() + 1),
          M: e.getMonth() + 1,
          "DD|dd": n(e.getDate()),
          "D|d": e.getDate(),
          "HH|hh": n(e.getHours()),
          "H|h": e.getHours(),
          mm: n(e.getMinutes()),
          m: e.getMinutes(),
          ss: n(e.getSeconds()),
          s: e.getSeconds()
        };
      return Object.keys(r).forEach(function(e) {
        t = t.replace(new RegExp(e), r[e])
      }), t
    }, e.exports = t.default
  },
  JjL0: function(e, t) {},
  K3Aj: function(e, t, n) {
    n.d(t, "a", function() {
      return o
    }), n.d(t, "b", function() {
      return s
    });
    var r = n("MLLI"),
      a = n("hmrP"),
      i = n.n(a);

    function o() {
      var {
        windowWidth: e
      } = Object(r.b)(), t = Math.min(e, 540);
      return i.a.isMobile() || function() {
        var {
          model: e
        } = Object(r.b)();
        return i.a.isIPad() || /ipad/gi.test(e)
      }() ? e : t
    }

    function s(e) {
      var t = document.createElement("a");
      t.href = e, t.style.display = "none", document.body.appendChild(t), t.click(), document.body.removeChild(t)
    }
  },
  KQ2A: function(e, t, n) {
    n.d(t, "d", function() {
      return v
    }), n.d(t, "c", function() {
      return y
    }), n.d(t, "a", function() {
      return b
    }), n.d(t, "b", function() {
      return _
    });
    var r = n("Fcif"),
      a = n("GFa9"),
      i = n("8B9M"),
      o = n("Yt9W"),
      s = n("jA1y"),
      c = n("2wjL"),
      u = Object(i.a)();

    function d(e) {
      var t = c.a.getAll() || {},
        n = Object(r.a)({
          goods_id: e.goodsId,
          num: e.num,
          sku_id: e.skuId,
          price: e.price || 0,
          dc_ps: o.b.getDCPS(),
          qr: e.qr || "",
          tpps: t.tp_ps || ""
        }, e.messages, {
          extensions: e.extensions || {},
          isInstallment: Boolean(e.isInstallment),
          propertyIds: e.propertyIds || []
        }),
        a = {
          kdt_id: e.kdtId || u.getKdtId(),
          postage: e.postage || 0,
          activity_alias: e.activityAlias,
          activity_id: e.activityId,
          activity_type: e.activityType,
          use_wxpay: e.useWxpay || 0,
          order_from: e.orderFrom || "",
          cloud_order_ext: e.cloudOrderExt || "",
          couponId: e.couponId
        };
      "string" == typeof e.price && e.price.indexOf(!1) && (n.price = 100 * +e.price), e.isPoints && (n.points_price = e.pointsPrice, n.price = e.remainPrice), e.fcode && (n.fcode = e.fcode), "number" == typeof e.deliverTime && (n.deliver_time = e.deliverTime), e.gdtClickId && (n.gdt_id = e.gdtClickId), e.channelId && (n.channel_id = e.channelId);
      var i = e.storeId || u.getOfflineId();
      return i && (a.store_id = i), e.umpStepPerson && (a.ladder_num = e.umpStepPerson), e.hotelGoods && (a.hotel_goods = e.hotelGoods), e.appointmentTime && (a.card_goods = {
        appointment_time: e.appointmentTime
      }), e.orderType && (a.order_type = e.orderType), e.isPoints && (a.is_points = e.isPoints), e.from && (a.from = e.from), e.loginTicket && (a.loginTicket = e.loginTicket), e.paymentSuccessRedirect && (a.payment_success_redirect = e.paymentSuccessRedirect), e.selectedInstallmentPeriod && (a.installmentRate = e.installmentRate, a.selectedInstallmentPeriod = e.selectedInstallmentPeriod), {
        goodsData: n,
        commonData: a
      }
    }
    var l = "buyNow",
      p = "addCart";

    function h(e) {
      var {
        comboDetailModel: t,
        skuId: n,
        flag: r
      } = e, {
        comboGroupModels: a = []
      } = t, i = {};
      i = 1 !== a.length || a[0].skuId ? a.find(e => e.skuId === n) || {} : a[0];
      var {
        comboSubItemModels: o = [],
        goodsComboGroupId: s = ""
      } = i;
      return {
        subComboList: o.reduce((e, t) => {
          if (0 === t.isDisplay) return e;
          var {
            skuRelatedModels: n = [],
            propModels: a = []
          } = t, i = [], o = a.reduce((e, t) => {
            var {
              textModels: n
            } = t;
            return n.forEach(t => {
              e.push(t.id)
            }), e
          }, []);
          return n.forEach(e => {
            var {
              combineNum: t,
              itemId: n,
              price: a,
              skuId: c
            } = e, u = {
              goodsId: n,
              num: t,
              price: a,
              skuId: c
            };
            r === l && (u.groupId = s), o.length && (u.propertyIds = o), i.push(u)
          }), e.push(...i), e
        }, []),
        goodsComboGroupId: s
      }
    }
    var f = Object(i.a)(),
      g = {
        actName: "buy",
        et: "click",
        ei: "buy",
        en: "购买"
      };

    function v(e) {
      var t;
      void 0 === e && (e = {});
      var {
        et: n,
        ei: a,
        en: i
      } = g;
      return f.logger && f.logger.log({
        et: n,
        ei: a,
        en: i,
        params: {
          price: 100 * (e.price || 0),
          goods_id: e.goodsId,
          goods_name: null == (t = e.itemDataModel) ? void 0 : t.title,
          num: e.num,
          sku_id: e.skuId
        },
        si: f.getKdtId()
      }), y(function(e) {
        var {
          goodsData: t,
          commonData: n
        } = d(e), {
          itemDataModel: a
        } = e, {
          comboMark: i = {},
          comboDetailModel: o = {}
        } = a || {}, {
          isCombo: s = !1,
          comboType: c = 0
        } = i;
        if (s) {
          var u = h({
              comboDetailModel: o,
              skuId: t.sku_id,
              flag: l
            }),
            {
              subComboList: p = []
            } = u;
          t.extra = {
            COMBO_INFO: {
              comboType: c,
              subComboList: p
            }
          }
        }
        var {
          birthdayInfo: f = {}
        } = e;
        return t.extra || (t.extra = {}), t.extra = Object.assign({}, t.extra, f), {
          goodsList: [Object(r.a)({}, t)],
          extraData: n
        }
      }(e))
    }

    function m(e, t) {
      var n = getCurrentPages().pop();
      return n && n[e] ? n[e](t) : Promise.resolve()
    }

    function y(e) {
      void 0 === e && (e = {});
      var {
        goodsList: t = [],
        extraData: n = {}
      } = e;
      if (t && 0 !== t.length) {
        var i = n.storeId || n.store_id || f.getOfflineId();
        return i && (n.store_id = i), wx.showLoading(),
          function(e) {
            void 0 === e && (e = {});
            var t = {
              success: !0
            };
            if (e.couponId) return (n = {
              id: e.couponId
            }, Object(s.c)({
              path: "/wsctrade/order/detail/getVoucher.json",
              method: "POST",
              data: {
                activityId: n.id,
                bizName: "showcase",
                source: "wap_showcase"
              }
            })).then(() => t).catch(() => t);
            var n;
            return Promise.resolve(t)
          }(n).then(() => m("beforeBuyEvent", Object(r.a)({}, t[0] || {}))).then(() => Object(s.c)({
            header: {
              "content-type": "application/x-www-form-urlencoded"
            },
            path: "/wsctrade/order/goodsBook.json",
            data: {
              goodsList: JSON.stringify(t),
              common: JSON.stringify(n),
              biz_trace_point_ext: o.b.getTradeLog()
            },
            method: "POST"
          })).then(e => {
            var {
              bookKey: r
            } = e;
            if (r) {
              var i = "/packages/order/index?bookKey=" + r;
              return n.orderFrom && (i += "&orderFrom=" + n.orderFrom), m("afterBuyEvent", {
                goodsList: t,
                extraData: n,
                url: i,
                bookKey: r
              }).then(() => (a.a.navigate({
                url: i
              }), wx.hideLoading(), Promise.resolve())).catch(e => (wx.hideLoading(), Promise.reject(e)))
            }
            return wx.hideLoading(), Promise.reject()
          }).catch(function(e) {
            void 0 === e && (e = {}), wx.hideLoading(), !e.noToast && wx.showToast({
              title: e.msg || e.message || "购买失败，重新试试",
              icon: "none",
              duration: 2e3
            })
          })
      }
      wx.showToast({
        title: "购买未选择商品",
        icon: "none",
        duration: 2e3
      })
    }

    function b(e, t, n) {
      void 0 === t && (t = {}), f.logger && f.logger.log({
        et: t.et || "click",
        ei: t.ei || "add_cart",
        en: t.en || "添加购物车",
        params: t.params || {
          goods_id: e.goodsId,
          num: e.num,
          sku_id: e.skuId
        }
      });
      var a = function(e) {
          var {
            goodsData: t,
            commonData: n
          } = d(e), a = Object(r.a)({}, t, n, {
            messages: JSON.stringify(e.cartMessages || []),
            biz_trace_point_ext: o.b.getTradeLog(),
            extensions: JSON.stringify(t.extensions),
            propertyIds: JSON.stringify(t.propertyIds)
          }), {
            comboDetailModel: i,
            comboMark: s
          } = e.itemDataModel || {};
          if (s && s.isCombo) {
            var {
              isCombo: c = !1,
              comboType: u = 0
            } = s;
            if (c) {
              var {
                subComboList: l,
                goodsComboGroupId: f
              } = h({
                comboDetailModel: i,
                skuId: t.sku_id,
                flag: p
              }), g = [{
                id: f,
                subComboList: l
              }];
              a.comboType = u, a.isCombo = c, a.groupList = JSON.stringify(g)
            }
          }
          return e.cartBizMarkDTO && (a.cartBizMarkDTO = e.cartBizMarkDTO || {}), a
        }(e),
        {
          birthdayInfo: i = {}
        } = e;
      return a.extra = JSON.stringify(i), Object(s.c)({
        path: "/wscshop/trade/cart/goods.json",
        header: {
          "content-type": n || "application/x-www-form-urlencoded"
        },
        data: a,
        method: "POST"
      })
    }

    function _(e) {
      return Object(s.c)({
        path: "/wscgoods/detail-api/calculate-price.json",
        method: "POST",
        data: Object(r.a)({}, e, {
          itemSalePropList: JSON.stringify(e.itemSalePropList)
        })
      })
    }
  },
  KhBQ: function(e, t, n) {
    n.d(t, "c", function() {
      return f
    }), n.d(t, "b", function() {
      return m
    }), n.d(t, "d", function() {
      return y
    }), n.d(t, "a", function() {
      return b
    });
    var r = n("Fcif"),
      a = n("BrFj"),
      i = n("US/N"),
      o = n("2wjL"),
      s = n("KEq0"),
      c = n.n(s),
      u = n("5Xe+"),
      d = n.n(u),
      l = n("YeA1"),
      p = n("Sipi"),
      h = n("GFyo");

    function f() {
      var e = getCurrentPages();
      return "packages/goods/share/index" === e[e.length - 1].route
    }

    function g(e, t) {
      var {
        needRedirect: n,
        redirectPath: a,
        metadata: i,
        goodsData: o
      } = t;
      return f() ? Promise.resolve(t) : n ? (Object(l.a)().dmc.redirectTo(a, Object(r.a)({}, e, i)), Promise.reject({
        msg: "商品后端重定向 ->" + a,
        data: {
          showError: !1
        }
      })) : Promise.resolve(t)
    }

    function v(e, t, n) {
      var {
        shopMetaInfo: i = {}
      } = n || {}, {
        kdtId: s
      } = i;
      if (function(e) {
          var {
            shopMetaInfo: t = {}
          } = e || {};
          return !!t.isChainStore
        }(n)) {
        var c = Object(r.a)({}, t);
        return delete c.shopAutoEnter, delete c.subKdtId, delete c.sub_kdt_id,
          function(e, t) {
            var n = o.a.add(e.env.route, t);
            return e.dmc.route.createUrl("GoodsDetail", t).then(e => e.url).catch(() => n)
          }(e, c).then(i => {
            var [o] = e.process.invoke("autoEnterShop", t, {
              redirectUrl: i,
              forceKdtId: s
            });
            return o.then(e => e && e !== s ? Object(a.d)(Object(r.a)({}, c, {
              subKdtId: e
            })) : Promise.resolve(n))
          })
      }
      return Promise.resolve(n)
    }

    function m(e, t) {
      var n = "goodsDetail-" + t,
        a = Object(p.b)(n),
        i = {};
      if (a) {
        var {
          title: o = "",
          image: s = {},
          price: u = ""
        } = a;
        e.data.goodsBaseInfo = {
          alias: t,
          title: o,
          pictures: [Object(r.a)({}, s, {
            url: c()(s.url, "!260x0.jpg")
          })]
        }, i = {
          goodsPriceInfo: {
            price: u
          }
        }, Object(h.e)(n)
      }
      Object(h.c)("goodsDetailRanta").then(function(n) {
        void 0 === n && (n = {});
        var a = {},
          o = n.data || null;
        if (o) {
          var {
            shopBaseInfo: s,
            theme: c,
            env: u,
            retail: l,
            kdtId: p,
            shopConfig: h,
            showTopBar: f
          } = o;
          a = {
            shopBaseInfo: s,
            shopConfig: h,
            theme: c,
            env: u,
            retail: l,
            kdtId: p,
            showTopBar: f
          }, o[t] && (i = Object(r.a)({}, i, d()(o[t], ["goodsBaseInfo", "goodsMetaInfo", "distribution"])))
        }
        Object.assign(e.data, a, i)
      })
    }

    function y(e) {
      Object(h.c)("goodsDetailRanta").then(function(t) {
        void 0 === t && (t = {});
        var {
          alias: n,
          kdtId: a,
          goodsBaseInfo: i,
          shopBaseInfo: o,
          shopConfig: s,
          goodsMetaInfo: c,
          theme: u,
          env: d,
          retail: l,
          distribution: p,
          showTopBar: f
        } = e, g = Object(r.a)({}, t.data), {
          goodsRecord: v = []
        } = g;
        (g.shopBaseInfo = o, g.shopConfig = s, g.theme = u, g.env = d, g.retail = l, g.kdtId = a, g.showTopBar = f, (v = v.filter(e => e !== n)).push(n), v.length > 10) && delete g[v.shift()];
        g.goodsRecord = v, g[n] = {
          goodsBaseInfo: i,
          goodsMetaInfo: c,
          distribution: p
        }, Object(h.g)("goodsDetailRanta", g)
      })
    }

    function b(e, t, n) {
      function r(e, t) {
        var {
          kdtId: r
        } = (e || {}).shopMetaInfo || {};
        r && Object(i.setKdtId)(r), e && e.goodsData && n instanceof Function && t(e)
      }
      return Object(a.d)(t).then(function(e) {
        return void 0 === e && (e = {}), g(t, e)
      }).then(a => (r(a, n), v(e, t, a))).then(e => {
        var {
          goodsData: t,
          shopMetaInfo: a = {}
        } = e || {}, {
          isChainStore: i
        } = a;
        return t ? (i && r(e, n), Promise.resolve(e)) : Promise.reject({
          code: 301010050,
          msg: "商品不存在"
        })
      })
    }
  },
  LHcj: function(e, t, n) {
    n.d(t, "d", function() {
      return a
    }), n.d(t, "c", function() {
      return o
    }), n.d(t, "a", function() {
      return s
    }), n.d(t, "b", function() {
      return c
    });
    var r = n("2ktG"),
      a = Object(r.a)(),
      i = {};

    function o(e, t) {
      i[e] = t
    }

    function s(e) {
      return i[e]
    }

    function c(e) {
      delete i[e]
    }
  },
  LHnf: function(e, t, n) {
    n.d(t, "b", function() {
      return a
    }), n.d(t, "a", function() {
      return i
    });
    var r = n("9ZMt");

    function a(e) {
      r.default.$native.onUnhandledRejection(e)
    }

    function i(e) {
      r.default.$native.offUnhandledRejection(e)
    }
  },
  LSEb: function(e, t, n) {
    var r = n("Yzgk"),
      a = n("X/0h");
    e.exports = function(e, t) {
      var n = a(e, t);
      return r(n) ? n : void 0
    }
  },
  LYai: function(e, t, n) {
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.default = void 0;
    var r = function(e) {
      var t = {
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        "\"": "&quot;",
        "'": "&#x27;"
      };
      return "".concat(e).replace(/(&|<|>|"|')/g, function(e) {
        return t[e]
      })
    };
    t.default = r, e.exports = t.default
  },
  LrYe: function(e, t, n) {
    t.a = {
      mounted() {
        this._onPageScroll()
      },
      methods: {
        _getCurrentPage() {
          if ("function" == typeof getCurrentPages) {
            var e = getCurrentPages();
            return e && e.length ? e[e.length - 1] || {} : null
          }
        },
        _onPageScroll() {
          var e = this._getCurrentPage();
          if (e && e.onPageScroll) {
            if ("function" != typeof this.onPageScroll) return;
            var t = e.onPageScroll;
            e.onPageScroll = n => {
              t.call(e, n), this.onPageScroll(n)
            }
          }
        }
      }
    }
  },
  LvFB: function(e, t, n) {
    n.d(t, "a", function() {
      return d
    });
    var r = n("Fcif"),
      a = n("lE6+"),
      i = n("0lqJ"),
      o = n("xRet");
    var s = n("vpHN");

    function c() {
      var e = getCurrentPages(),
        t = "";
      try {
        t = e[e.length - 1].__wxExparserNodeId__
      } catch (e) {}
      return t
    }
    var u = {
        "packages/usercenter/dashboard/index": "usercenter",
        "pages/home/tab/one": "h-t-1",
        "pages/home/tab/two": "h-t-2",
        "pages/home/tab/three": "h-t-3"
      },
      d = {
        data: {
          attachedPageId: ""
        },
        onLoad(e) {
          this.containerOptions = e, this.setAttachedPageId(), this.onRantaPageAttached(), this.triggerRantaTabPageReady()
        },
        onShow() {
          var e, t;
          (this.getTabBar() && this.getTabBar().setData({
            selectedIndex: Object(i.a)()
          }), this.attachedPage) && (null == (e = (t = this.attachedPage).onShow) || e.call(t))
        },
        onUnload() {
          var e, t;
          this.attachedPage && (null == (e = (t = this.attachedPage).onUnload) || e.call(t))
        },
        onHide() {
          var e, t;
          this.attachedPage && (null == (e = (t = this.attachedPage).onHide) || e.call(t))
        },
        onShareAppMessage(e) {
          var t, n;
          return this.attachedPage ? null == (t = (n = this.attachedPage).onShareAppMessage) ? void 0 : t.call(n, e) : {}
        },
        onReachBottom() {
          var e, t;
          this.attachedPage && (null == (e = (t = this.attachedPage).onReachBottom) || e.call(t))
        },
        onPageScroll(e) {
          var t, n;
          this.attachedPage && (null == (t = (n = this.attachedPage).onPageScroll) || t.call(n, e))
        },
        onPullDownRefresh(e) {
          var t, n;
          this.attachedPage && (null == (t = (n = this.attachedPage).onPullDownRefresh) || t.call(n, e))
        },
        setAttachedPageId() {
          u[this.route] || new Promise(function(e, t) {
            Object(a.a)().then(function(n) {
              var r = Object(i.a)(),
                a = n[r] || {},
                s = a.routingType,
                c = a.attachedId;
              if (s === o.c && c) return e(c);
              t(n[r])
            })
          }).then(e => {
            this.setData({
              attachedPageId: e
            })
          }).catch(e => {
            if (delete getApp().globalData.tabBarParams, !e) return wx.reLaunch({
              url: "/pages/home/dashboard/index"
            });
            var t = Object(s.b)(e);
            wx.reLaunch({
              url: "/" + t
            })
          })
        },
        triggerRantaTabPageReady() {
          u[this.route] && getApp().trigger("ranta-tab-page-ready-" + c())
        },
        onRantaPageAttached() {
          getApp().on("async-page-attached-" + c(), e => {
            var t, n, {
                rantaCtx: a
              } = e,
              {
                attachedPageId: i
              } = this.data;
            i || (i = u[this.route]), this.attachedPage = this.selectComponent("#" + i);
            var o = {
              _route: this.route
            };
            null == a || null == (t = a.env) || null == (n = t.router) || null == n.updateRoute || n.updateRoute(this.route), Object.assign(this.attachedPage[Symbol.for("vm")], o);
            var {
              tabBarParams: s = {}
            } = getApp().globalData, c = s[i];
            if ("retail-shelf" === i) {
              var {
                tabbarOriginList: d = {}
              } = getApp().globalData, l = d.find(e => "retail-shelf" === e.attachedId), {
                extra: p = {}
              } = l || {}, h = wx.getStorageSync("ExtraArgsFromShopSelectToOriginalPage") || {};
              wx.clearStorageSync("ExtraArgsFromShopSelectToOriginalPage"), c = Object(r.a)({}, p, c, h)
            }
            "feature" === i && (c = Object(r.a)({}, this.containerOptions, c)), this.execPageLifeCycle(this.attachedPage, c || this.containerOptions), delete getApp().globalData.tabBarParams
          })
        },
        onTabPageAttached(e) {
          this.attachedPage = this.selectComponent("#" + e.currentTarget.id);
          var t = Object(r.a)({
            route: this.route,
            __route__: this.route
          }, this.attachedPage.__freeData__ || {});
          Object.assign(this.attachedPage, t);
          var {
            tabBarParams: n = {}
          } = getApp().globalData, a = n[e.currentTarget.id];
          this.execPageLifeCycle(this.attachedPage, a || this.containerOptions), delete getApp().globalData.tabBarParams
        },
        execPageLifeCycle(e, t) {
          Object(a.a)().then(n => {
            var r = getApp(),
              a = n[Object(i.a)()],
              {
                spm: o
              } = a || {};
            if (o) {
              var s = getCurrentPages(),
                {
                  route: c
                } = s[s.length - 1];
              r.logger.spmHelper.setMoreSpm({
                [c]: o
              })
            }
            null == e.onLoad || e.onLoad(t || {}), null == e.onShow || e.onShow(), null == e.onReady || e.onReady()
          })
        }
      }
  },
  "M+mJ": function(e, t, n) {
    var r = n("DXKY"),
      {
        on: a,
        once: i,
        off: o,
        trigger: s
      } = r.a,
      c = {
        off: o,
        trigger: s
      };
    Object.assign(c, {
      on: a,
      once: i
    }), t.a = c
  },
  MJHg: function(e, t, n) {
    n.d(t, "a", function() {
      return o
    });
    var r = n("6MKc"),
      a = n("6S0u"),
      i = e => ({
        enter: "van-" + e + "-enter van-" + e + "-enter-active enter-class enter-active-class",
        "enter-to": "van-" + e + "-enter-to van-" + e + "-enter-active enter-to-class enter-active-class",
        leave: "van-" + e + "-leave van-" + e + "-leave-active leave-class leave-active-class",
        "leave-to": "van-" + e + "-leave-to van-" + e + "-leave-active leave-to-class leave-active-class"
      });

    function o(e) {
      return Behavior({
        properties: {
          customStyle: String,
          show: {
            type: Boolean,
            value: e,
            observer: "observeShow"
          },
          duration: {
            type: null,
            value: 300,
            observer: "observeDuration"
          },
          name: {
            type: String,
            value: "fade"
          }
        },
        data: {
          type: "",
          inited: !1,
          display: !1
        },
        ready() {
          !0 === this.data.show && this.observeShow(!0, !1)
        },
        methods: {
          observeShow(e, t) {
            e !== t && (e ? this.enter() : this.leave())
          },
          enter() {
            this.enterFinishedPromise || (this.enterFinishedPromise = new Promise(e => {
              var {
                duration: t,
                name: n
              } = this.data, o = i(n), s = Object(a.f)(t) ? t.enter : t;
              "enter" !== this.status && (this.status = "enter", this.$emit("before-enter"), Object(r.m)(() => {
                "enter" === this.status && (this.$emit("enter"), this.setData({
                  inited: !0,
                  display: !0,
                  classes: o.enter,
                  currentDuration: s
                }), Object(r.m)(() => {
                  "enter" === this.status && (this.transitionEnded = !1, this.setData({
                    classes: o["enter-to"]
                  }), e())
                }))
              }))
            }))
          },
          leave() {
            this.enterFinishedPromise && this.enterFinishedPromise.then(() => {
              if (this.data.display) {
                var {
                  duration: e,
                  name: t
                } = this.data, n = i(t), o = Object(a.f)(e) ? e.leave : e;
                this.status = "leave", this.$emit("before-leave"), Object(r.m)(() => {
                  "leave" === this.status && (this.$emit("leave"), this.setData({
                    classes: n.leave,
                    currentDuration: o
                  }), Object(r.m)(() => {
                    "leave" === this.status && (this.transitionEnded = !1, setTimeout(() => {
                      this.onTransitionEnd(), this.enterFinishedPromise = null
                    }, o), this.setData({
                      classes: n["leave-to"]
                    }))
                  }))
                })
              }
            })
          },
          onTransitionEnd() {
            if (!this.transitionEnded) {
              this.transitionEnded = !0, this.$emit("after-" + this.status);
              var {
                show: e,
                display: t
              } = this.data;
              !e && t && this.setData({
                display: !1
              })
            }
          }
        }
      })
    }
  },
  Mqxx: function(e, t, n) {
    n.d(t, "a", function() {
      return l
    }), n.d(t, "d", function() {
      return p
    }), n.d(t, "f", function() {
      return h
    }), n.d(t, "e", function() {
      return f
    }), n.d(t, "b", function() {
      return m
    }), n.d(t, "c", function() {
      return b
    });
    var r = n("Fcif"),
      a = n("z24M"),
      i = n("50K0"),
      o = n("SVbq"),
      s = {};
    var c, u = (c = wx.request, function(e) {
      return new Promise((t, n) => {
        var i = c && c(Object(r.a)({}, e || {}, {
          header: {
            "Extra-Data": JSON.stringify({
              is_weapp: 1,
              client: "weapp",
              bizEnv: "wsc",
              skip_sid: 1,
              version: Object(a.a)("userVersion")
            })
          },
          success(e) {
            var r, a;
            0 === (null == e || null == (r = e.data) ? void 0 : r.code) ? t(null == e || null == (a = e.data) ? void 0 : a.data) : n(null == e ? void 0 : e.data)
          },
          reject: n
        }));
        i && i.then && i.catch && i.then(t, n)
      })
    });

    function d(e) {
      var {
        path: t,
        kdtId: n,
        hadEnterShop: r
      } = e;
      return u({
        url: "https://h5.youzan.com/wscdeco/homepage-detail.json",
        data: {
          stage: 16,
          check_multi_store: 1,
          fetchSepHqStoreDetail: Object(o.z)() ? 1 : 0,
          close_chainstore_webview_limit: !0,
          check_old_home: 1,
          hadEnterShop: r,
          kdt_id: n || Object(a.a)("kdtId"),
          version_control: JSON.stringify({
            use_native_feature_page: 1,
            feature_page_path: t
          })
        }
      })
    }

    function l(e, t) {
      return t({
        path: "/wscdeco/brand-feature-detail.json",
        data: {
          stage: 16,
          hadEnterShop: !0,
          kdt_id: e,
          labelType: "usercenter,freeMemberCenter,payMemberCenter"
        }
      })
    }

    function p(e) {
      return i.a.getMiniappPrefetchData("homeFeature", {}).then(t => {
        var n, {
          kdtId: r,
          homeDetailInfo: i
        } = e;
        if (i) return i.needEnterShop = !1, i;
        if (!t || null == t || null == (n = t.components) || !n.length) return d(e).catch(e => Promise.reject({
          type: "homeErr",
          err: e
        }));
        var {
          shopMetaInfo: {
            kdtId: s
          } = {}
        } = t;
        return +s != +r ? d(e).then(e => e).catch(e => Promise.reject({
          type: "homeErr",
          err: e
        })) : (+Object(a.a)("kdtId") != +s && (t.needEnterShop = !1, Object(o.k)("装修使用预拉取", t)), t)
      }).catch(t => t && "homeErr" === t.type ? Promise.reject(t.err) : d(e))
    }
    var h = (e, t, n) => {
        var {
          pageData: a
        } = n, {
          guestKdtId: i,
          shopAutoEnter: o
        } = a || {}, s = i || e;
        return Object(r.a)({}, t, {
          kdt_id: s,
          shopAutoEnter: o
        })
      },
      f = (e, t) => {
        var n = s[e.key];
        return n ? Promise.resolve(n) : u({
          url: "https://h5.youzan.com/v3/weapp/scene-code-v2.json",
          data: e
        }).then(n => {
          var {
            pageData: r
          } = n;
          return s[e.key] = h(e.kdt_id, t, {
            pageData: r
          }), s[e.key]
        })
      },
      g = {
        fetch: null,
        result: null
      };

    function v() {
      return u({
        url: "https://h5.youzan.com/wscdeco/homepage-video-ad.json",
        data: {
          kdtId: Object(a.a)("kdtId")
        }
      }).then(e => (g.result = e, e))
    }

    function m() {
      return g.result ? Promise.resolve(g.result) : (g.fetch || (g.fetch = i.a.getMiniappPrefetchData("homeAd").then(e => e ? (g.result = e, e) : v().catch(e => Promise.reject(e))).catch(e => v())), g.fetch)
    }

    function y() {
      var e = "global_custom_loading";
      return u({
        url: "https://h5.youzan.com/wscshopcore/extension/configs.json",
        method: "POST",
        data: {
          keys: [e],
          kdtId: Object(a.a)("kdtId")
        }
      }).then(t => {
        var n = t[e] || "{}",
          {
            open: r,
            resource: a
          } = JSON.parse(n);
        return r ? a : ""
      })
    }

    function b() {
      return new Promise(e => {
        i.a.getMiniappPrefetchData("globalCustomLoading").then(t => {
          e(null == t ? y() : t)
        }).catch(() => {
          e(y())
        })
      })
    }
  },
  NV8i: function(e, t, n) {
    n.d(t, "a", function() {
      return E
    });
    var r = n("RmQ0"),
      a = n.n(r),
      i = n("0guW"),
      o = n.n(i),
      s = n("DLGB"),
      c = n.n(s),
      u = n("jS7c"),
      d = n.n(u),
      l = n("lOCs"),
      p = n.n(l),
      h = n("MytQ"),
      f = n.n(h),
      g = n("3v4F"),
      v = n.n(g),
      m = n("oWIT"),
      y = n.n(m),
      b = n("87nt"),
      _ = n.n(b),
      O = n("SlE4"),
      S = n.n(O),
      w = n("rPml"),
      I = n.n(w),
      P = n("/vm6"),
      k = n.n(P),
      j = n("wHg8"),
      x = n.n(j),
      T = n("5kn2");
    class E {
      constructor(e) {
        this.ctx = e.ctx, this.ctx.instance = new T.d({
          nativeYunExtension: this.getPosterByYunExtension
        }), this.ctx.emitter = {}
      }
      getPosterByYunExtension(e) {
        try {
          return this.ctx.process.invokePipe("beforeGenerateSalesmanGoodsPosterEvent", e).catch(() => Promise.resolve([]))
        } catch (e) {
          return Promise.resolve([])
        }
      }
      beforePageMount(e) {
        var {
          query: t,
          route: n
        } = e;
        this.ctx.instance.batchUpdate({
          path: n,
          query: t
        })
      }
    }
    E.widgets = {
      Widget: a(),
      CubeHeader: o(),
      CubeTabContainer: c(),
      CubeTabPromote: p(),
      CubeTabPoster: d(),
      AssistantPop: f(),
      CubeFooter: v(),
      MainFrame: y(),
      NewBeginPop: _(),
      PosterPop: S(),
      PromoteTip: I(),
      ShareMask: k(),
      TaxSignPop: x()
    }
  },
  NW04: function(e, t, n) {
    n.d(t, "c", function() {
      return a
    }), n.d(t, "a", function() {
      return i
    }), n.d(t, "b", function() {
      return o
    });
    var r = n("US/N");
    n("9ZMt"), n("MLLI");

    function a(e) {
      return "object" != typeof e || null == e ? "" : Object.keys(e).map(function(t) {
        var n = e[t];
        return "object" == typeof n ? "--" + t + ": linear-gradient(to right, " + n.start + ", " + n.end + ")" : "--" + t + ": " + n
      }).join(";").concat(";")
    }
    var i = a({
      general: "#f44",
      "main-bg": "#f44",
      "main-text": "#fff",
      "vice-bg": "#f85",
      "vice-text": "#fff",
      "start-bg": "#ff6060",
      "end-bg": "#f44"
    });

    function o(e) {
      var t = null == e ? {} : {
        kdt_id: e
      };
      return Object(r.default)({
        path: "/wscshop/shop/theme_and_colors.json",
        method: "GET",
        query: t
      })
    }
  },
  NWgQ: function(e, t, n) {
    var r = n("X7EK"),
      a = n("IL7q"),
      i = n("5+rW");

    function o(e, t) {
      return t.encode ? t.strict ? r(e) : encodeURIComponent(e) : e
    }

    function s(e) {
      var t = e.indexOf("?");
      return -1 === t ? "" : e.slice(t + 1)
    }

    function c(e, t) {
      var n = function(e) {
          var t;
          switch (e.arrayFormat) {
            case "index":
              return function(e, n, r) {
                t = /\[(\d*)\]$/.exec(e), e = e.replace(/\[\d*\]$/, ""), t ? (void 0 === r[e] && (r[e] = {}), r[e][t[1]] = n) : r[e] = n
              };
            case "bracket":
              return function(e, n, r) {
                t = /(\[\])$/.exec(e), e = e.replace(/\[\]$/, ""), t ? void 0 !== r[e] ? r[e] = [].concat(r[e], n) : r[e] = [n] : r[e] = n
              };
            default:
              return function(e, t, n) {
                void 0 !== n[e] ? n[e] = [].concat(n[e], t) : n[e] = t
              };
          }
        }(t = a({
          arrayFormat: "none"
        }, t)),
        r = Object.create(null);
      return "string" != typeof e ? r : (e = e.trim().replace(/^[?#&]/, "")) ? (e.split("&").forEach(function(e) {
        var t = e.replace(/\+/g, " ").split("="),
          a = t.shift(),
          o = t.length > 0 ? t.join("=") : void 0;
        o = void 0 === o ? null : i(o), n(i(a), o, r)
      }), Object.keys(r).sort().reduce(function(e, t) {
        var n = r[t];
        return Boolean(n) && "object" == typeof n && !Array.isArray(n) ? e[t] = function e(t) {
          return Array.isArray(t) ? t.sort() : "object" == typeof t ? e(Object.keys(t)).sort(function(e, t) {
            return Number(e) - Number(t)
          }).map(function(e) {
            return t[e]
          }) : t
        }(n) : e[t] = n, e
      }, Object.create(null))) : r
    }
    t.extract = s, t.parse = c, t.stringify = function(e, t) {
      !1 === (t = a({
        encode: !0,
        strict: !0,
        arrayFormat: "none"
      }, t)).sort && (t.sort = function() {});
      var n = function(e) {
        switch (e.arrayFormat) {
          case "index":
            return function(t, n, r) {
              return null === n ? [o(t, e), "[", r, "]"].join("") : [o(t, e), "[", o(r, e), "]=", o(n, e)].join("")
            };
          case "bracket":
            return function(t, n) {
              return null === n ? o(t, e) : [o(t, e), "[]=", o(n, e)].join("")
            };
          default:
            return function(t, n) {
              return null === n ? o(t, e) : [o(t, e), "=", o(n, e)].join("")
            };
        }
      }(t);
      return e ? Object.keys(e).sort(t.sort).map(function(r) {
        var a = e[r];
        if (void 0 === a) return "";
        if (null === a) return o(r, t);
        if (Array.isArray(a)) {
          var i = [];
          return a.slice().forEach(function(e) {
            void 0 !== e && i.push(n(r, e, i.length))
          }), i.join("&")
        }
        return o(r, t) + "=" + o(a, t)
      }).filter(function(e) {
        return e.length > 0
      }).join("&") : ""
    }, t.parseUrl = function(e, t) {
      return {
        url: e.split("?")[0] || "",
        query: c(s(e), t)
      }
    }
  },
  "NYj+": function(e, t, n) {
    n.d(t, "a", function() {
      return r
    });
    var r = {
      title: [Number, String],
      icon: String,
      size: String,
      label: [Number, String],
      center: Boolean,
      isLink: Boolean,
      required: Boolean,
      clickable: {
        type: Boolean,
        default: !1
      },
      titleWidth: String,
      customStyle: String,
      arrowDirection: String,
      border: {
        type: Boolean,
        default: !0
      }
    }
  },
  Na6L: function(e, t, n) {
    function r(e) {
      var t;
      if (e) t = e;
      else {
        var n = getCurrentPages();
        t = n[n.length - 1]
      }
      if (!t.__uniqueKey__) {
        var r = function(e) {
          for (var t = 5381, n = e.length; n;) t = 33 * t ^ e.charCodeAt(--n);
          return t >>> 0
        }(t.route + JSON.stringify(t.options));
        t.__uniqueKey__ = r
      }
      return t.__uniqueKey__
    }
    n.d(t, "a", function() {
      return r
    })
  },
  "NeL/": function(e, t, n) {
    function r(e, t) {
      var n = "../" + e + "/index";
      return {
        relations: {
          [n]: {
            type: "ancestor",
            linked() {
              t && t.call(this)
            },
            linkChanged() {
              t && t.call(this)
            },
            unlinked() {
              t && t.call(this)
            }
          }
        },
        mixin: Behavior({
          created() {
            Object.defineProperty(this, "parent", {
              get: () => this.getRelationNodes(n)[0]
            }), Object.defineProperty(this, "index", {
              get: () => {
                var e, t;
                return null === (t = null === (e = this.parent) || void 0 === e ? void 0 : e.children) || void 0 === t ? void 0 : t.indexOf(this)
              }
            })
          }
        })
      }
    }

    function a(e, t) {
      var n = "../" + e + "/index";
      return {
        relations: {
          [n]: {
            type: "descendant",
            linked(e) {
              t && t.call(this, e)
            },
            linkChanged(e) {
              t && t.call(this, e)
            },
            unlinked(e) {
              t && t.call(this, e)
            }
          }
        },
        mixin: Behavior({
          created() {
            Object.defineProperty(this, "children", {
              get: () => this.getRelationNodes(n) || []
            })
          }
        })
      }
    }
    n.d(t, "b", function() {
      return r
    }), n.d(t, "a", function() {
      return a
    })
  },
  NgLJ: function(e, t, n) {
    function r(e) {
      return (r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
        return typeof e
      } : function(e) {
        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
      })(e)
    }
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.validateOperator = function(e) {
      if ("string" != typeof e) throw new TypeError("Invalid operator type, expected string but got " + r(e));
      if (-1 === a.indexOf(e)) throw new TypeError("Invalid operator, expected one of " + a.join("|"))
    }, t.default = t.OperatorResMap = void 0;
    var a = [">", ">=", "=", "<", "<="];
    t.OperatorResMap = {
      ">": [1],
      ">=": [1, 0],
      "=": [0],
      "<=": [-1, 0],
      "<": [-1]
    };
    var i = /^v?(?:\d+)(\.(?:[x*]|\d+)(\.(?:[x*]|\d+)(\.(?:[x*]|\d+))?(?:-[\da-z\-]+(?:\.[\da-z\-]+)*)?(?:\+[\da-z\-]+(?:\.[\da-z\-]+)*)?)?)?$/i;

    function o(e) {
      var t, n, r = e.replace(/^v/, "").replace(/\+.*$/, ""),
        a = (n = "-", -1 === (t = r).indexOf(n) ? t.length : t.indexOf(n)),
        i = r.substring(0, a).split(".");
      return i.push(r.substring(a + 1)), i
    }

    function s(e) {
      return isNaN(Number(e)) ? e : Number(e)
    }

    function c(e) {
      if ("string" != typeof e) throw new TypeError("Invalid argument expected string");
      if (!i.test(e)) throw new Error("Invalid argument not valid semver ('" + e + "' received)")
    }
    var u = function(e, t) {
      [e, t].forEach(c);
      for (var n = o(e), r = o(t), a = 0; a < Math.max(n.length - 1, r.length - 1); a++) {
        var i = parseInt(n[a] || "0", 10),
          u = parseInt(r[a] || "0", 10);
        if (i > u) return 1;
        if (u > i) return -1
      }
      var d = n[n.length - 1],
        l = r[r.length - 1];
      if (d && l) {
        var p = d.split(".").map(s),
          h = l.split(".").map(s);
        for (a = 0; a < Math.max(p.length, h.length); a++) {
          if (void 0 === p[a] || "string" == typeof h[a] && "number" == typeof p[a]) return -1;
          if (void 0 === h[a] || "string" == typeof p[a] && "number" == typeof h[a]) return 1;
          if (p[a] > h[a]) return 1;
          if (h[a] > p[a]) return -1
        }
      } else if (d || l) return d ? -1 : 1;
      return 0
    };
    t.default = u
  },
  O1uH: function(e, t, n) {
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.default = void 0;
    var r, a = (r = n("NHEX")) && r.__esModule ? r : {
      default: r
    };
    var i = function(e, t, n) {
      var r, i, o = function(e) {
        return e
      };
      o = "string" == typeof t ? function(e) {
        return (0, a.default)(e, t, null)
      } : t;
      for (var s = 0; s < e.length; s++) {
        var c = e[s],
          u = o(c);
        null == u || isNaN(+u) || (void 0 !== i ? n(u, i) && (r = c, i = u) : (i = u, r = c))
      }
      return r
    };
    t.default = i, e.exports = t.default
  },
  OF9M: function(e, t) {
    e.exports = function(e) {
      var t = -1,
        n = Array(e.size);
      return e.forEach(function(e) {
        n[++t] = e
      }), n
    }
  },
  "OMz+": function(e, t, n) {
    n.d(t, "b", function() {
      return a
    }), n.d(t, "a", function() {
      return i
    });
    var r = n("xih6");

    function a(e) {
      if (!e) return !1;
      var t = "/" + e.replace(/^\//, "");
      return Object(r.a)().some(e => t.startsWith(e))
    }

    function i() {
      var e = getCurrentPages() || [];
      return a("/" + (e[e.length - 1] || {}).route)
    }
  },
  OPDa: function(e, t, n) {
    var r = (wx.spm || (wx.spm = {
      initSpm() {
        var e = getApp().logger;
        e && e.spmHelper.initSpm()
      },
      getPageSpmTypeId() {
        var e = getApp().logger;
        return e && e.spmHelper.gettCurrentPageSpm()
      },
      setCurrentSpm(e, t, n, r) {
        void 0 === r && (r = []);
        var a = getApp().logger;
        return a && a.spmHelper.setCurrentSpm(e, t, n, r)
      },
      getSpm() {
        var e = getApp().logger;
        return e && e.spmHelper.getSpm()
      },
      removePageSpm() {
        var e = getApp().logger;
        return e && e.spmHelper.removePageSpm()
      }
    }), wx.spm);
    t.a = r
  },
  PHxc: function(e, t, n) {
    var r = n("cm7J");
    e.exports = function(e, t) {
      var n = this.__data__,
        a = r(n, e);
      return a < 0 ? (++this.size, n.push([e, t])) : n[a][1] = t, this
    }
  },
  POYE: function(e, t, n) {
    n.d(t, "a", function() {
      return a
    }), n.d(t, "b", function() {
      return s
    });
    var r = n("Fcif"),
      a = {
        hqHomeToOtherHome: !1,
        cacheKdtId: {},
        cacheNavConfig: {},
        isWxProxyDone: !1,
        isProxyUpdateKdtId: !1,
        proxyUpdateEmitFunc: [],
        lastOnlineKdtId: null,
        proxyWxJumpPadding: !1,
        onAppRoutePadding: !1,
        blockEnterShopType: !1,
        isEnterWbViewPage: !1,
        switchShopRangeCache: {},
        hideUrl: "",
        tabbarNavCacheMap: {}
      },
      i = e => JSON.parse(JSON.stringify(e)),
      o = i(a),
      s = () => {
        var {
          tabbarNavCacheMap: e
        } = a;
        a = Object(r.a)({}, i(o), {
          tabbarNavCacheMap: e
        })
      }
  },
  PYDc: function(e, t, n) {
    var r = n("FEiO");
    e.exports = function() {
      this.__data__ = r ? r(null) : {}, this.size = 0
    }
  },
  Pv1N: function(e, t, n) {
    var r = n("XS2z");
    n.d(t, "UserAuthorizeType", function() {
      return r.a
    });
    n("1LD1"), n("nHpP"), n("DRK6"), n("3hrn"), n("PzrG")
  },
  Pz1p: function(e, t, n) {
    n.d(t, "a", function() {
      return a
    });
    var r = n("MLLI");

    function a() {
      var e = Object(r.b)().model.replace(/\s/g, "-"),
        t = !1;
      return /iPhone SE/i.test(e) || (t = /iphone-x|iPhone11|iPhone13|iPhone12(?!,8>)|iPhone14|iPhone15|iPhone16|iPhone17|iPhone-14|iPhone-12/i.test(e)), t
    }
  },
  PzrG: function(e, t) {},
  Q4pQ: function(e, t, n) {
    n.d(t, "a", function() {
      return o
    });
    var r = n("Fcif"),
      a = n("q3MX"),
      i = n("ONqW"),
      o = e => {
        try {
          var t = Object(i.a)(),
            {
              kdt_id: n,
              from_params: o,
              sl: s
            } = e,
            c = t.getLogParams(),
            {
              event: u,
              context: d
            } = c,
            {
              sl: l,
              from_params: p
            } = d,
            h = (() => {
              var e, t, n = Object(a.b)({
                  yai: "shop_guide_c",
                  app: "ext-tee-wsc-goods",
                  requestUrl: "https://tj1.youzan.com/v3/js/log"
                }),
                r = Object(i.a)();
              return n.setEvent(null == (e = r.getLogParams()) ? void 0 : e.event), n.setUser(null == (t = r.getLogParams()) ? void 0 : t.user), n
            })();
          (s || o || l || p) && h.log(Object(r.a)({}, u, {
            si: n,
            et: "view",
            ei: "customer_visit_with_sl",
            en: "客户访问带导购标页面",
            params: {
              sl: s,
              fromParams: o,
              ctxSl: l,
              ctxFromParams: p,
              bizChannel: "goods"
            }
          }))
        } catch (e) {}
      }
  },
  Q56H: function(e, t, n) {
    n.d(t, "a", function() {
      return a
    }), n.d(t, "b", function() {
      return i
    });
    var r = n("h+Rz");

    function a() {
      return r.a.getClipboardData()
    }

    function i(e) {
      return r.a.setClipboardData({
        data: e
      })
    }
  },
  QFll: function(e, t, n) {
    n.d(t, "c", function() {
      return r
    }), n.d(t, "b", function() {
      return a
    }), n.d(t, "a", function() {
      return i
    });
    var r = {
        WSC: "packages/usercenter/dashboard/index",
        RETAIL: "packages/retail/usercenter/dashboard-v2/index"
      },
      a = /packages\/(retail\/)?usercenter\/dashboard(-v2)?\/index/,
      i = {
        OLD: "packages/shop/goods/all/index",
        NEW: "packages/goods-list/all/index"
      };
    i.OLD
  },
  QLod: function(e, t, n) {
    n.d(t, "b", function() {
      return c
    }), n.d(t, "c", function() {
      return u
    }), n.d(t, "a", function() {
      return f
    }), n.d(t, "e", function() {
      return g
    }), n.d(t, "d", function() {
      return y
    }), n.d(t, "f", function() {
      return m
    });
    n("Fcif");
    var r = n("Sd3C"),
      a = n("9KEa"),
      i = n("z2TJ"),
      o = "packages",
      s = "pages",
      c = {
        NEW_FEATURE_ROUTE: o + "/home/feature/index",
        TAB_ONE_ROUTE: o + "/home/tab/one",
        TAB_TWO_ROUTE: o + "/home/tab/two",
        TAB_THREE_ROUTE: o + "/home/tab/three",
        NEW_HOMEPAGE_ROUTE: o + "/home/dashboard/index",
        APP_FEATURE_ROUTE: s + "/home/feature/index",
        APP_TAB_ONE_ROUTE: s + "/home/tab/one",
        APP_TAB_TWO_ROUTE: s + "/home/tab/two",
        APP_TAB_THREE_ROUTE: s + "/home/tab/three",
        APP_HOMEPAGE_ROUTE: s + "/home/dashboard/index",
        OLD_GOODS_ROUTE: s + "/goods/",
        GOODS_DETAIL_TOUTE: s + "/goods/detail/index",
        KQ_GOODS_DETAIL: o + "/goods/detail/index",
        NEW_GOODS_ROUTE: o + "/goods/",
        TEMPLATE_ROUTE: o + "/showcase-template/index",
        RETAIL_HOME: "pages-retail/home-shelf/index",
        EXT_NEW_FEATURE_ROUTE: o + "/ext-home/feature/index",
        OLD_NEW_FEATURE_ROUTE: o + "/old-home/feature/index",
        EXT_NEW_MARKETING_PAGE_ROUTE: o + "/ext-marketing-page/index",
        EXT_TAB_ONE_ROUTE: o + "/ext-home/tab/one",
        OLD_TAB_ONE_ROUTE: o + "/old-home/tab/one",
        EXT_TAB_TWO_ROUTE: o + "/ext-home/tab/two",
        OLD_TAB_TWO_ROUTE: o + "/old-home/tab/two",
        EXT_TAB_THREE_ROUTE: o + "/ext-home/tab/three",
        OLD_TAB_THREE_ROUTE: o + "/old-home/tab/three",
        EXT_NEW_HOMEPAGE_ROUTE: o + "/ext-home/dashboard/index",
        OLD_NEW_HOMEPAGE_ROUTE: o + "/old-home/dashboard/index",
        USERCENTER_ROUTE: s + "/usercenter/dashboard/index",
        PACKAGES_USERCENTER_ROUTE: o + "/usercenter/dashboard/index",
        SHOPNOTE_DETAIL_ROUTE: o + "/shop/shopnote/detail/index"
      },
      u = [o + "/shop/levelcenter/free/index", o + "/shop/levelcenter/plus/index"],
      d = Object.keys(c),
      l = {
        bottom: 58,
        height: 32,
        left: 278,
        right: 365,
        top: 26,
        width: 87,
        canUseNav: !0
      },
      p = {
        inited: !1,
        rectInfo: {}
      },
      h = () => {
        var e, {
            statusBarHeight: t = 20,
            SDKVersion: n,
            isAndroid: r
          } = a.a,
          o = t + (r ? 48 : 44);
        try {
          e = wx.getMenuButtonBoundingClientRect()
        } catch (e) {}
        return e || (e = Object.create(null)), n && (e.canUseNav = Object(i.a)("2.5.2", n) < 1), e.top = e.top || o, p.rectInfo = e, p.inited = !0, e
      },
      f = Object.create(null);
    Object.keys(l).forEach(e => {
      Object.defineProperty(f, e, {
        get() {
          if (!p.inited || !p.rectInfo[e] && "canUseNav" !== e) {
            var t = h()[e];
            return t || !1 === t ? t : (setTimeout(h, 300), l[e])
          }
          return p.rectInfo[e]
        }
      })
    });
    var g = function(e) {
        void 0 === e && (e = !0);
        var {
          top: t,
          height: n,
          canUseNav: r
        } = f, i = e ? a.a : wx.getSystemInfoSync(), {
          statusBarHeight: o = 20
        } = i, s = t - o + 6 + n + o;
        return r ? s <= 105 ? s : 105 : 0
      },
      v = [],
      m = e => v.find(t => t.route.indexOf(e)),
      y = function(e) {
        if (void 0 === e && (e = ""), !e) {
          var t = Object(r.b)();
          e = t.route
        }
        return d.some(t => e.indexOf(c[t]) > -1)
      }
  },
  QNh1: function(e, t, n) {
    n.d(t, "a", function() {
      return i
    });
    var r = n("DBeL"),
      a = n.n(r);
    class i {
      constructor(e) {
        this.ctx = e.ctx
      }
    }
    i.widgets = {
      Widget: a()
    }
  },
  QNtA: function(e, t, n) {
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.default = void 0;
    var r = i(n("UdN6")),
      a = i(n("eX/V"));

    function i(e) {
      return e && e.__esModule ? e : {
        default: e
      }
    }
    var o = function(e) {
      var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "default",
        n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "zh";
      if (t = t || "default", e instanceof Date) return e;
      if ("number" == typeof e) return new Date(e);
      var i = r.default.parse(e, t, "string" == typeof n ? a.default[n] : n);
      return i || null
    };
    t.default = o, e.exports = t.default
  },
  QSkc: function(e, t, n) {
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.default = void 0;
    var r = function(e) {
      return e >= 0 && e < 10 ? "0".concat(e) : String(e)
    };
    t.default = r, e.exports = t.default
  },
  QTc8: function(e, t, n) {
    var r = {},
      a = 1;
    t.a = {
      set(e) {
        var t = "db_" + a++;
        return r[t] = e, t
      },
      delete(e) {
        delete r[e]
      },
      get(e, t) {
        void 0 === t && (t = !0);
        var n = r[e];
        return t && delete r[e], n
      }
    }
  },
  QlcU: function(e, t, n) {
    n.d(t, "j", function() {
      return r
    }), n.d(t, "i", function() {
      return a
    }), n.d(t, "c", function() {
      return i
    }), n.d(t, "g", function() {
      return o
    }), n.d(t, "h", function() {
      return s
    }), n.d(t, "e", function() {
      return d
    }), n.d(t, "d", function() {
      return l
    }), n.d(t, "f", function() {
      return p
    }), n.d(t, "a", function() {
      return h
    }), n.d(t, "b", function() {
      return f
    });
    var r = {
        new: 1,
        old: 0
      },
      a = {
        show: 1,
        hidden: 0
      },
      i = {
        default: 1,
        custom: 2
      },
      o = {
        WeiXin: "WeiXin",
        WeiXinGroup: "WeiXinGroup",
        WecomGroup: "wecomGroup"
      },
      s = {
        [o.WeiXin]: "member",
        [o.WeiXinGroup]: "group",
        [o.WecomGroup]: "wecom-group"
      },
      c = "https://img01.yzcdn.cn",
      u = c + "/weapp/wsc/4RYyjww.png",
      d = {
        member: c + "/weapp/wsc/1c9OGo.png",
        group: u,
        wecomGroup: u,
        official: c + "/weapp/wsc/UJ60enB.png"
      },
      l = {
        member: "添加微信",
        group: "加入微信群",
        wecomGroup: "加入企业微信群",
        official: "关注公众号"
      },
      p = {
        member: "点击" + l.member,
        group: "点击" + l.group,
        wecomGroup: "点击" + l.wecomGroup,
        official: "点击" + l.official
      },
      h = "/packages/home/dashboard/index",
      f = c + "/weapp/wsc/1fxuP9X.png"
  },
  R18q: function(e, t, n) {
    n.d(t, "a", function() {
      return i
    }), n.d(t, "b", function() {
      return o
    });
    var r = n("Oq22"),
      a = n("Qzzd"),
      i = {
        init: () => i,
        mark: r.a,
        setEnv: a.c,
        setExtra: a.d,
        addTrack: () => {},
        capture: a.b,
        captureEvent: () => {},
        captureXhr: () => {},
        addProcessor: () => 0,
        removeProcessor: () => {},
        addFilter: () => 0,
        removeFilter: () => {},
        addCaptor: () => 0,
        removeCaptor: () => {},
        setPageGroup: () => {},
        setOptions: a.e,
        markRendered: () => {}
      },
      o = () => {}
  },
  R2NP: function(e, t, n) {
    n.d(t, "b", function() {
      return a
    }), n.d(t, "a", function() {
      return i
    });
    var r = n("h+Rz");

    function a(e) {
      return r.a.setNavigationBarTitle({
        title: e
      })
    }

    function i(e) {
      return r.a.setNavigationBarColor(e)
    }
  },
  R4YI: function(e, t, n) {
    n.d(t, "a", function() {
      return b
    }), n.d(t, "b", function() {
      return O
    });
    var r, a, i, o, s, c, u, d = n("3tAa");
    (r = Object(d.a)("getAppTokenHook", void 0))[0], r[1], (a = Object(d.a)("checkLoginGlobalHook", void 0))[0], a[1], (i = Object(d.a)("teeLoginFailHook", void 0))[0], i[1], (o = Object(d.a)("beforeYouzanLoginHook", void 0))[0], o[1], (s = Object(d.a)("youzanLoginFailHook", void 0))[0], s[1];

    function l(e, t) {
      var n = Object(d.a)(e, t);
      return {
        get: n[0],
        set: n[1]
      }
    }! function(e) {
      e.NativeMobile = "mobile_n", e.NativeNickAvatar = "nick_n", e.YZButton = "yz"
    }(c || (c = {})),
    function(e) {
      e.YZMobile = "mobile_yz", e.YZProtocol = "protocol_yz", e.YZAuth = "auth_yz", e.YZUserInfo = "info_yz"
    }(u || (u = {}));
    var p;
    ! function(e) {
      e[e.Unknown = -1] = "Unknown", e[e.Password = 0] = "Password", e[e.Sms = 1] = "Sms", e[e.Yz = 2] = "Yz", e[e.Weapp = 3] = "Weapp", e[e.AppSdk = 4] = "AppSdk"
    }(p || (p = {}));
    var h, f, g, v, m, y, b = {
        mobileChange: l("mobileChangeHook"),
        authItemAfter: l("authOneAfterHook"),
        buttonClickAfter: l("authBtnClickAfterHook"),
        popupShowAfter: l("authPopupShowAfterHook")
      },
      _ = (h = "protocolBeforeAgreeHook", g = Object(d.a)(h, f), v = g[0], m = g[1], y = function() {
        return v() || []
      }, function(e, t, n) {
        try {
          if (!e) return n;
          var r = e();
          if (!r) return n;
          var a = t || [];
          return Array.isArray(r) ? Promise.all(r.map(function(e) {
            return e.apply(void 0, a)
          })) : r.apply(void 0, a)
        } catch (e) {}
        return n
      }),
      O = function() {
        for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
        return Promise.resolve().then(function() {
          return _.apply(void 0, e)
        })
      }
  },
  RSyW: function(e, t, n) {
    var r = n("Fcif"),
      a = n("NHEX"),
      i = n.n(a),
      o = n("lCVF"),
      s = n.n(o),
      c = n("sXPE");
    t.a = {
      state: {
        points: null,
        buyLimitGuideInfo: {},
        shopConfig: {}
      },
      getActions: () => ({
        formatSku(e, t) {
          var n = t.goods,
            a = c.g.reduce((t, a) => {
              var i = e[a];
              return i && (t[a] = Object(r.a)({}, n, function(e, t) {
                var {
                  discount: n,
                  spuPrice: {
                    price: a,
                    pointsPrice: i,
                    pointsPriceText: o
                  },
                  skuPrices: s,
                  skuStocks: u,
                  activityInfo: d,
                  type: l,
                  quotaNum: p,
                  quotaUsed: h,
                  spuStock: f = {},
                  totalNum: g = t.stockNum
                } = e, v = 1 / 0, m = 0, y = 1 / 0, b = 0, _ = 0, O = {};
                s.length > 0 && (s.forEach(e => {
                  if (e.recommendedPrice) {
                    if (e.isVipPriceAdvantage = e.recommendedPrice < e.price, e.isVipPriceAdvantage) {
                      var t = e.price - e.recommendedPrice;
                      y = Math.min(y, t), b = Math.max(b, t)
                    }
                    0 === _ && (_ = e.isVipPriceAdvantage), _ = _ && e.isVipPriceAdvantage
                  }
                  O[e.skuId] = Object(r.a)({}, e)
                }), (u || []).forEach(e => {
                  Object.assign(O[e.skuId], e)
                })), (t.list || []).length || (v = Math.min(v, a), m = Math.max(m, a));
                var S = (t.list || []).map(e => {
                    var n = Object(r.a)({}, e, O[e.skuId] || {}, {
                      oldPrice: e.price
                    });
                    return t.stockNum > 0 && 0 === n.stockNum || (v = Math.min(v, n.price), m = Math.max(m, n.price)), n
                  }),
                  w = [...(t.priceTags || [])],
                  I = c.e[l];
                w.push({
                  text: I,
                  type: l
                });
                var P = Object(r.a)({}, t.limit);
                return p && (P.quota = p, P.quotaUsed = h, P.quotaCycle = 0), Object(r.a)({
                  stockNum: g
                }, f, {
                  discount: n,
                  price: a || v || 0,
                  pointsPrice: i,
                  pointsPriceText: o,
                  minPrice: v,
                  maxPrice: m,
                  oldPrice: t.price,
                  oldMinPrice: t.minPrice,
                  oldMaxPrice: t.maxPrice,
                  list: S,
                  priceTags: w,
                  limit: P,
                  activityInfo: d,
                  minVipSavedPrice: y,
                  maxVipSavedPrice: b,
                  isAllVipPriceAdvantage: _
                })
              }(i, n), {
                useCustomTags: !1
              })), t
            }, t);
          if (a[c.f.POINTS]) {
            var i = a[c.f.POINTS];
            i.showPeriodText = !1, i.buyWayText = "兑换", i.limit && (i.limit.startSaleNum = 1)
          }
          return a
        },
        formatPriceInfo(e, t) {
          var n = {
              tags: t.tags || []
            },
            a = e[c.f.DISCOUNT];
          if (a) {
            var {
              minPrice: i,
              maxPrice: o,
              oldMinPrice: u,
              oldMaxPrice: d,
              priceTags: l,
              pointsPriceText: p
            } = a;
            Object.assign(n, {
              price: s()({
                min: i,
                max: o
              }, "-"),
              minPrice: i,
              maxPrice: o,
              oldPrice: s()({
                min: u,
                max: d
              }, "-"),
              oldMinPrice: u,
              oldMaxPrice: d,
              pointsPriceText: p,
              tags: l.filter(e => [c.a.CUSTOMER_DISCOUNT, c.a.GOODS_SCAN].indexOf(e.type) > -1)
            })
          }
          if (e[c.f.POINTS]) {
            var {
              pointsPriceText: h
            } = e[c.f.POINTS];
            Object.assign(n, {
              pointsPriceText: h
            })
          }
          return Object(r.a)({}, t, n)
        },
        parseMemeberActivies(e) {
          var {
            marketing: t,
            sku: n,
            priceInfo: a,
            buyLimitGuideInfo: o = {}
          } = e, s = function(e) {
            var {
              activities: t,
              orderActivity: n
            } = e || {}, r = {}, {
              code: a = 0,
              alias: i = "",
              id: o = 0,
              type: s
            } = n || {};
            return (t || []).forEach(e => {
              n && s === e.type && (e.activityInfo = {
                activityType: a,
                activityAlias: i,
                activityId: o
              });
              var t = e.recommendedPriceModel || {};
              switch (e.type) {
                case c.a.CUSTOMER_DISCOUNT:
                  1 != +e.discount && (r[c.f.DISCOUNT] = e), 1 === t.recommendedStatus && (r[c.f.DISCOUNT_INVITE] = e);
                  break;
                case c.a.GOODS_SCAN:
                  r[c.f.DISCOUNT] = e;
                  break;
                case c.a.POINTS:
                  e.activityInfo || (e.activityInfo = {
                    activityAlias: "",
                    activityId: e.id,
                    activityType: 5
                  }), r[c.f.POINTS] = e;
                  break;
                case c.a.SCRM_CARRIER:
                  r[c.a.SCRM_CARRIER] = e;
              }
            }), r
          }(t), u = this.formatSku(s, n), d = this.formatPriceInfo(u, a), {
            supportItemProps: l
          } = e;
          return this.points = !!i()(s, c.f.POINTS, null), this.buyLimitGuideInfo = o, this.points && (l = !1), this.setCtxData(s, "memberActivity"), this.setCtxData(o, "buyLimitGuideInfo"), Object(r.a)({}, e, {
            sku: u,
            priceInfo: d,
            supportItemProps: l,
            memberActivity: s,
            buyLimitGuideInfo: o
          })
        },
        setPointsConfig() {
          this.setCtxData(this.shopConfig.pointsConfig, "pointsConfig")
        }
      })
    }
  },
  "RW/s": function(e, t, n) {
    var r = n("iOq2"),
      a = n("HE1N"),
      i = n("VZJX"),
      o = n("J9xP"),
      s = n("PHxc");

    function c(e) {
      var t = -1,
        n = null == e ? 0 : e.length;
      for (this.clear(); ++t < n;) {
        var r = e[t];
        this.set(r[0], r[1])
      }
    }
    c.prototype.clear = r, c.prototype.delete = a, c.prototype.get = i, c.prototype.has = o, c.prototype.set = s, e.exports = c
  },
  RY8z: function(e, t, n) {
    var r = n("GFa9");
    t.a = r.a
  },
  Rm8A: function(e, t, n) {
    var r = n("bb6g"),
      a = n("9ZMt"),
      i = n("QxN7"),
      o = n("Tewj"),
      s = n("DXKY"),
      c = n("Xdhg"),
      u = n("pTxV"),
      d = i.platform.authLogger,
      l = ["weapp", "ks", "tt"],
      p = function() {
        function e(e, t) {
          this.path = e, this.isSeparated = t, this.offEventHandler = [], this.init()
        }
        return e.prototype.init = function() {
          var e = c.a.register(u.EventRegisterType.MAIN, this.path);
          e && (this.id = e)
        }, e.prototype.setCallback = function(e) {
          this.callbackMap = e
        }, e.prototype.onAuthSync = function(e) {
          var t = Object(i.onUserAuthSync)(e);
          this.offEventHandler.push(t)
        }, e.prototype.onAuthSuccess = function(e) {
          var t = this,
            n = Object(i.onUserAuthSuccess)(function(n) {
              n.__comId !== t.id && e(n)
            });
          if (this.offEventHandler.push(n), l.indexOf(a.default.getEnv()) > -1) {
            var r = "account:user-authorize:native-auth-success",
              o = function(t) {
                d.logSkynet("触发已废弃事件", {
                  eventName: r,
                  params: t
                }), e(t)
              };
            s.a.on(r, o), this.offEventHandler.push(function() {
              return s.a.off(r, o)
            })
          }
        }, e.prototype.onUserInfoChanged = function(e) {
          o.default.on(u.EventName.USER_INFO_CHANGED, e), this.offEventHandler.push(function() {
            return o.default.off(u.EventName.USER_INFO_CHANGED, e)
          })
        }, e.prototype.onLoginEndEvent = function(e) {
          var t = function(t) {
            !t.cache && e()
          };
          o.default.on(i.TEE_LOGIN_END_EVENT, t), this.offEventHandler.push(function() {
            return o.default.off(i.TEE_LOGIN_END_EVENT, t)
          })
        }, e.prototype.offEvent = function() {
          this.offEventHandler.forEach(function(e) {
            return e()
          }), this.offEventHandler = []
        }, e.prototype.callPopup = function(e, t) {
          if (this.isSeparated) {
            var n = c.a.getLatestPopupId(t, this.path);
            o.default.trigger(u.EventName.POPUP_TRIGGER, {
              type: u.EventPopupTriggerTypes.POPUP_SHOW,
              data: e,
              mainId: this.id,
              callback: this.callbackMap,
              popupId: n
            })
          }
        }, e.prototype.authSuccess = function(e) {
          Object(i.emitUserAuthSuccess)(Object(r.__assign)(Object(r.__assign)({}, e), {
            __comId: this.id
          }))
        }, e
      }();
    t.a = p
  },
  RqPZ: function(e, t, n) {
    var r = n("GI0s"),
      a = n("9aUh");
    e.exports = function(e) {
      if (!a(e)) return !1;
      var t = r(e);
      return "[object Function]" == t || "[object GeneratorFunction]" == t || "[object AsyncFunction]" == t || "[object Proxy]" == t
    }
  },
  "Rz+h": function(e, t, n) {
    n.d(t, "a", function() {
      return N
    });
    var r = n("+I+c"),
      a = n("Fcif"),
      i = n("9ZMt"),
      o = n("xers"),
      s = n.n(o),
      c = n("w2Y9"),
      u = n.n(c),
      d = n("tuFO"),
      l = n.n(d),
      p = n("4c+U"),
      h = "packages/retail-shelf/shelf/index",
      f = {
        SCAN_GO: "scan_order_way",
        FREE_GO: "free_order_way",
        SELF: "self_order_way",
        TAKEOUT: "takeout_order_way",
        NEARBY_STORE: "nearby_store_way",
        SHELF_GOODS: "shelf_goods",
        SHELF_GROUP: "shelf_group",
        WX_SCAN_CODE: "wx_scan_code",
        SaleToday: "sale_today",
        SaleAdvance: "sale_advance"
      },
      g = {
        [f.SELF]: 0,
        [f.SaleToday]: 0,
        [f.SaleAdvance]: 0,
        [f.TAKEOUT]: 1
      },
      v = {
        [f.SELF]: h + "?mode=0",
        [f.SaleToday]: h + "?mode=0&filter=1",
        [f.SaleAdvance]: h + "?mode=0&filter=2",
        [f.TAKEOUT]: h + "?mode=1"
      },
      m = n("US/N"),
      y = n("tmLU"),
      b = n("Oq22"),
      _ = n("AGZf"),
      O = (n("4jn8"), n("2wjL")),
      S = n("ONqW"),
      w = i.default.getApp();

    function I(e) {
      var t = w.getKdtId();
      Object(y.c)({
        navigatePath: "retail-shelf",
        navigateCb: n => {
          setTimeout(() => {
            b.a.start("retail_shelf_init_" + w.globalData.shelfParams.mode), b.a.start("retail_shelf_config");
            var r = "/" + e + "&prefetchKey=" + n + "&prefetchKdtId=" + t;
            i.default.$native.navigateTo({
              url: r
            })
          }, 150)
        },
        prefetchCb: () => {
          var t, {
            mode: n,
            filter: r
          } = O.a.getAll(e) || {};
          return 0 !== n || r ? Promise.reject() : (t = {
            mode: n
          }, Object(m.default)({
            path: "retail/h5/miniprogram/shelf-config/getFirstLevelConfigs",
            method: "POST",
            data: Object(a.a)({}, t, {
              useSwitch: "v2",
              supportUnavailableGoods: 2
            })
          }))
        }
      })
    }
    var P = (e, t) => {
        i.default.$native.getSetting({
          success: n => {
            var r = n.authSetting["scope.userLocation"];
            void 0 === r || !0 === r ? i.default.$native.getLocation({
              type: "gcj02",
              fail: () => {
                null != t && t.handleShowAuthDialog && t.handleShowAuthDialog()
              },
              success: () => {
                I(e)
              }
            }) : !1 === r && I(e)
          }
        })
      },
      k = (e, t) => {
        var {
          linkType: n,
          linkUrl: r
        } = e;
        [f.SELF, f.TAKEOUT, f.SaleToday, f.SaleAdvance].includes(n) ? (w.globalData.shelfParams = {
          mode: g[n]
        }, P(v[n], t)) : [f.SCAN_GO, f.FREE_GO].includes(n) ? (b.a.start("scan_order_decorate"), i.default.navigate({
          url: "/" + r
        })) : [f.SHELF_GOODS, f.SHELF_GROUP].includes(n) ? (e => {
          var {
            linkId: t,
            linkType: n,
            alias: r,
            extraData: a = {}
          } = e, i = "shelf_goods" === n, o = ((e, t, n) => e && t && n ? t.includes(1) && n.includes(1) ? 0 : 1 : 0)(i, a[i ? "groupSupportDeliveryType" : "deliveryType"], i ? a.goodSupportDeliveryType : [1, 2, 3]), s = {
            mode: o
          };
          w.globalData.shelfParams = {
            mode: o
          }, "shelf_goods" === n && Object.assign(s, {
            fromShared: 1,
            sharedGoodsIdProp: t,
            sharedGoodsAliasProp: r
          }), P(u.a.add(h, s))
        })(e) : n === f.WX_SCAN_CODE && (Object(S.a)().log({
          et: "custom",
          ei: "click_wx_scan_code",
          en: "点击扫一扫链接"
        }), wx.scanCode({
          success: e => {
            e.path ? (Object(_.a)({
              type: "success",
              message: "识别成功，正在跳转",
              duration: 0
            }), wx.navigateTo({
              url: "/" + e.path,
              complete: () => {
                _.a.clear()
              }
            })) : _.a.fail("仅能扫此商家桌码/店铺码哦")
          },
          fail: () => {
            _.a.error("识别失败")
          }
        }))
      },
      j = n("SVbq"),
      x = e => {
        var {
          videoDynamicParams: t,
          linkTitle: n
        } = e;
        return Object(a.a)({}, t, {
          image_url: null == e ? void 0 : e.imageUrl,
          link_title: n
        })
      },
      T = n("YeA1"),
      E = ["type"],
      A = ["/pages/home/dashboard/index", "/pages/goods/cart/index", "/pages/usercenter/dashboard/index", "/pages-retail/usercenter/dashboard-v2/index"];
    var C = 1,
      D = 2,
      M = (e, t) => {
        "web" === i.default.getEnv() ? t && i.default.navigate({
          url: t
        }) : e && i.default.navigate({
          url: e
        })
      },
      N = function(e, t) {
        void 0 === t && (t = {});
        var n, {
            dmc: o
          } = Object(T.a)(),
          {
            type: c = ""
          } = e,
          d = "",
          h = !1,
          {
            alias: g,
            linkType: v = "",
            linkId: y = "",
            linkUrl: b = "",
            linkTitle: O = "",
            extraData: w = {},
            query: I = {},
            goodsAlias: P
          } = e,
          {
            kdtId: N,
            banner_id: L,
            imageUrl: U,
            goodsPreloadOpt: R,
            title: B
          } = t,
          F = {
            kdt_id: N
          },
          q = {};
        if (L && (q.banner_id = L), "chat" === (c = v || c)) {
          if ("web" === i.default.getEnv() && t) {
            var H = Object(p.a)(t);
            H && i.default.navigate({
              url: u.a.add(H, q)
            })
          }
        } else if ("homepage" === c) o.switchTab("Home", Object(a.a)({}, q, F)).catch(() => {
          o.navigate("Home", Object(a.a)({}, q, F))
        });
        else if ("goods" === c && g) {
          var {
            image: z = {}
          } = R || {};
          o.navigate("GoodsDetail", Object(a.a)({
            alias: g
          }, I, q), {
            bizParams: {
              alias: g,
              image: {
                url: U || z.url,
                width: z.width,
                height: z.height
              },
              title: B
            }
          })
        } else if ("feature" === c && g) {
          var G = getApp(),
            W = (n = getCurrentPages()).length > 0 ? n[n.length - 1].route : "";
          if (!G.isChainStoreSync() || !Object(j.y)(W)) return void o.navigate("Feature", Object(a.a)({
            alias: g
          }, q));
          var {
            enterConfig: K = {},
            featureSource: Y,
            kdtId: V
          } = w, {
            mode: X
          } = K;
          if (G.featureJump({
              bannerIdOpt: q,
              alias: g,
              enterConfig: K
            })) return;
          if (!X) {
            if (Y === C) return void o.navigate("Feature", Object(a.a)({
              alias: g,
              kdtId: V
            }, q));
            if (Y === D) {
              var J = Object(a.a)({
                alias: g
              }, q);
              return Object(j.y)(W) && (J.shopAutoEnter = 4), void o.navigate("Feature", J)
            }
          }
          o.navigate("Feature", Object(a.a)({
            alias: g
          }, q))
        } else if ("tag" === c) {
          var $ = g ? {
            alias: g
          } : u.a.getAll(b);
          $.alias && o.navigate("GoodsTag", Object(a.a)({
            alias: $.alias,
            title: O
          }, q))
        } else if ("cart" === c) o.switchTab("Cart", Object(a.a)({}, q, F)).catch(() => {
          o.navigate("Cart", Object(a.a)({}, q, F))
        });
        else if ("usercenter" === c) o.switchTab("Usercenter", Object(a.a)({}, q, F)).catch(() => {
          o.navigate("Usercenter", Object(a.a)({}, q, F))
        });
        else if ("shopnote" === c) o.switchTab("Shopnote", Object(a.a)({}, q, F)).catch(() => {
          o.navigate("Shopnote", Object(a.a)({}, q, F))
        });
        else if ("allgoods" === c) o.navigate("AllGoodsList", Object(a.a)({
          title: O
        }, q));
        else if ("coupon" === c) "web" === i.default.getEnv() && b ? M("", "" + b) : o.navigate("CouponDetail", Object(a.a)({
          id: e.link_id || e.linkId,
          type: 7 === (e.coupon_type || e.couponType) ? "promocard" : ""
        }, q));
        else if ("point_card" === c) M("/packages/pointstore/goods-details/index?goods_id=" + e.pointGoodsId + "&" + L + "=" + L, b);
        else if ("pointsstore" === c) o.navigate("PointGoodsList", Object(a.a)({}, q, F));
        else if ("seckill" === c) "web" === i.default.getEnv() && b ? M("", "" + b) : "web" === i.default.getEnv() ? o.navigate("Seckill", Object(a.a)({
          alias: P,
          ump_alias: g,
          ump_type: "seckill",
          activityType: "seckill"
        }, I, F)) : o.navigate("Seckill", Object(a.a)({
          alias: g
        }, P ? {
          goodsAlias: P
        } : {}, q));
        else if ("bargain" === c) o.navigate("GoodsDetail", Object(a.a)({
          alias: g,
          umpType: e.umpType || "",
          activityId: e.activityId
        }, q));
        else if ("paidcolumn" === c) o.navigate("PaidContentColumn", Object(a.a)({
          alias: g
        }, q));
        else if ("paidcontent" === c) o.navigate("PaidContentContent", Object(a.a)({
          alias: g
        }, q));
        else if ("mypaidcontent" === c) o.navigate("PaidContentList", Object(a.a)({}, q, F));
        else if ("paidlive" === c) o.navigate("PaidContentLive", Object(a.a)({
          alias: g
        }, q));
        else if ("allcourse" === c) o.navigate("EduGoodsList", Object(a.a)({}, q, F));
        else if ("course" === c || "educourse" === c || "allofflinecourse" === c || "eduappointment" === c || "course_group" === c || "course_category" === c || "edumoments" === c) {
          if ("web" === i.default.getEnv()) M("", b);
          else {
            var Z = b.replace(/^http(s)?:\/\/shop\d+-?\d+/, "https://h5");
            o.navigate("EduWebview", Object(a.a)({
              targetUrl: Z
            }, q))
          }
        } else if ("link" === c) {
          var {
            linkUrl: Q
          } = e;
          "web" === i.default.getEnv() && Q && M("", Q), Q && /mp.weixin.qq.com\/s/.test(Q) && o.navigate("CommonWebview", Object(a.a)({
            src: Q
          }, q))
        } else if ("weapplink" === c && "1" === w.linkType) {
          "/" !== (d = w.myWeappLink)[0] && (d = "/" + d);
          var ee = d.split("?")[0];
          if (A.indexOf(ee) > -1 && (h = !0), 0 === (d = u.a.remove(d, "shopAutoEnter")).indexOf("/pages/common/blank-page/index")) {
            var te = u.a.getAll(d);
            if (te.weappSharePath) {
              var ne = decodeURIComponent(te.weappSharePath);
              ne = u.a.remove(ne, "shopAutoEnter"), te.weappSharePath = ne, d = u.a.add("/pages/common/blank-page/index", te)
            }
          }
          if (!s()(t) && !h) {
            var {
              banner_id: re
            } = t;
            d = u.a.add(d, {
              banner_id: re
            })
          }
          i.default.navigate({
            url: d
          }).catch(() => {
            i.default.$native.reLaunch({
              url: d
            })
          })
        } else if ("weapplink" === c && "2" === w.linkType) {
          getApp().logger.skynetLog({
            appName: "wsc",
            message: "跳转其他小程序",
            detail: Object(a.a)({}, w)
          }), +w.useShortLink || +w.use_short_link ? i.default.$native.navigateToMiniProgram({
            shortLink: w.shortLink || w.short_link
          }) : i.default.$native.navigateToMiniProgram({
            appId: w.otherWeappAppid || w.other_weapp_appid,
            path: w.otherWeappLink || w.other_weapp_link
          })
        } else if ("calendar_checkin" === c) o.navigate("Checkin", Object(a.a)({}, F, q));
        else if (["guaguale", "wheel", "zodiac", "crazyguess"].includes(c)) {
          var ae = b || "",
            ie = "";
          ae.includes("lottery") && (ie = "LuckyLottery"), ae.includes("cards") && (ie = "Cards"), ae.includes("zodiac") && (ie = "Zodiac"), ae.includes("crazy") && (ie = "CrazyGuess"), ie && o.navigate(ie, Object(a.a)({
            alias: g
          }, q))
        } else if ("shopnote_detail" === c) o.navigate("ShopnoteDetail", Object(a.a)({
          noteAlias: g
        }, q));
        else if ("mp_article" === c) o.navigate("MpArticle", Object(a.a)({
          noteAlias: g
        }, q));
        else if ("hotellist" === c || "recharge_center" === c || "point_coupon" === c || "room_typelist" === c || "combolist" === c) "web" === i.default.getEnv() ? M("", b) : o.navigate("CommonWebview", Object(a.a)({
          src: b
        }, q));
        else if ("period_list" === c) o.navigate("PeriodBuyList", Object(a.a)({}, F, q));
        else if ("point_store" === c) o.navigate("PointGoodsList", Object(a.a)({}, F, q));
        else if ("groupon" === c || "collector_card" === c || "gift_card" === c) b && i.default.navigate({
          url: b
        });
        else if ("weapp_marketing_page" === c || "marketing_page" === c) o.navigate("MarketingPage", Object(a.a)({}, F, q, {
          id: w.id || ""
        }));
        else if ("survey" === c || "guaguale" === c || "history" === c) M("", b);
        else if ("video_number" === c) {
          var oe = i.default.$native.getStorageSync("channelsLiveInfo") || "";
          if (!oe) return;
          var {
            feedId: se,
            nonceId: ce
          } = JSON.parse(oe);
          i.default.$native.openChannelsLive && i.default.$native.openChannelsLive({
            feedId: se,
            nonceId: ce,
            finderUserName: y
          })
        } else if ("social_fans" === c) {
          var {
            qrcode: ue
          } = e, de = l()(u.a.add("/v3/message/live-qrcode/member", {
            kdtId: N,
            activitiesId: ue
          }), "h5", N);
          i.default.$native.navigateTo({
            url: "/pages/common/webview-page/index?src=" + encodeURIComponent(de)
          })
        } else if ("weapp_web_link" === c) M(u.a.add(b, q), u.a.add(b, Object(a.a)({}, F, q)));
        else {
          if ("red-package" === c) return i.default.$native.showRedPackage({
            url: b
          }), {};
          if ("member_code" === c) i.default.$native.navigateTo({
            url: "/packages/member-code/index"
          });
          else if ("vipcenter" === c) i.default.$native.navigateTo({
            url: "/packages/shop/levelcenter/free/index"
          });
          else if ("category" === c) M("", u.a.add(b, Object(a.a)({}, F, q)));
          else if ("pay_vipcenter" === c) i.default.$native.navigateTo({
            url: "/packages/shop/levelcenter/plus/index"
          });
          else if ("shop_ranking_list" === c) {
            var {
              tabType: le
            } = e;
            if (le) {
              var pe = l()(u.a.add("/wscshop/showcase/shop-ranking-list", {
                type: le
              }), "h5", N);
              i.default.$native.navigateTo({
                url: "/pages/common/webview-page/index?src=" + encodeURIComponent(pe)
              })
            }
          } else if ("video_number_dynamic" === c) {
            var {} = e, he = Object(r.a)(e.videoDynamicParams, E);
            (e => {
              var t = x(e);
              Object(S.a)().log({
                et: "click",
                ei: "wxvideo_video_click",
                en: "视频号动态点击",
                params: t
              })
            })(e), i.default.$native.openChannelsActivity && i.default.$native.openChannelsActivity(Object(a.a)({}, he, {
              success: () => {
                (e => {
                  var t = x(e);
                  Object(S.a)().log({
                    et: "custom",
                    ei: "wxvideo_video_jump_success",
                    en: "视频号动态跳转成功",
                    params: t
                  })
                })(e)
              },
              fail: t => {
                ((e, t) => {
                  var n = x(e);
                  Object(S.a)().log({
                    et: "custom",
                    ei: "wxvideo_video_jump_fail",
                    en: "视频号动态跳转失败",
                    params: Object(a.a)({}, n, {
                      error_msg: null == t ? void 0 : t.errMsg
                    })
                  })
                })(e, t)
              }
            }))
          } else if ("storelist" === c || "nearby_store_way" === c) i.default.$native.navigateTo({
            url: "/packages/shop/physical-store/index"
          });
          else if ("goods_classify" === c) o.navigate("CommonWebview", Object(a.a)({
            src: b
          }, q));
          else if (Object.values(f).includes(c)) {
            var {
              context: fe
            } = t;
            k(e, fe)
          } else ["booking_mall", "express_mall"].includes(c) && Object(m.default)({
            method: "GET",
            path: "wscdeco/decorate-api/getMallFeatureByType.json",
            data: {
              type: c
            }
          }).then(e => {
            var {
              alias: t
            } = e;
            t ? o.navigate("Feature", {
              alias: t
            }) : Object(_.a)("未启用相关微页面")
          })
        }
      }
  },
  Sd3C: function(e, t, n) {
    n.d(t, "d", function() {
      return c
    }), n.d(t, "b", function() {
      return u
    }), n.d(t, "c", function() {
      return d
    });
    var r = n("2wjL"),
      a = n("WLNV"),
      i = n("+fxQ"),
      o = {
        cashier: "https://cashier.youzan.com",
        uic: "https://uic.youzan.com",
        carmen: "https://open.youzan.com",
        h5: "https://h5.youzan.com",
        h5m: "https://h5.m.youzan.com",
        trade: "https://trade.youzan.com",
        qiniu: "https://img01.yzcdn.cn",
        money: "https://money.youzan.com",
        guang: "https://g.youzan.com",
        baymax: "https://open.youzan.com/bifrost"
      },
      s = {
        origin: "carmen",
        pathname: "",
        query: {}
      };
    var c = e => ((e => /^http:\/\//.test(e))(e) && (e = e.replace("http://", "https://")), e),
      u = () => {
        var e = getCurrentPages() || [];
        return e[e.length - 1] || {}
      },
      d = function(e) {
        void 0 === e && (e = {});
        var {
          withSlash: t,
          withQuery: n
        } = e, {
          route: a,
          options: i = {}
        } = u();
        if (!a) return "";
        var o = a;
        return t && (o = "/" + o), n && (o = r.a.add(o, i)), o
      };
    t.a = function(e) {
      var t = ((e = Object(a.a)({}, s, e)).pathname || "").startsWith("/");
      return Object(i.b)(e.origin).then(t => t || o[e.origin]).catch(() => o[e.origin]).then(n => {
        var a = n + (t ? "" : "/") + e.pathname;
        return r.a.add(a, e.query)
      })
    }
  },
  Shdd: function(e, t, n) {
    n.d(t, "c", function() {
      return o
    }), n.d(t, "a", function() {
      return s
    }), n.d(t, "b", function() {
      return c
    });
    var r = function() {
        return (r = Object.assign || function(e) {
          for (var t, n = 1, r = arguments.length; n < r; n++)
            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
          return e
        }).apply(this, arguments)
      },
      a = function(e, t, n, r) {
        return new(n || (n = Promise))(function(a, i) {
          function o(e) {
            try {
              c(r.next(e))
            } catch (e) {
              i(e)
            }
          }

          function s(e) {
            try {
              c(r.throw(e))
            } catch (e) {
              i(e)
            }
          }

          function c(e) {
            var t;
            e.done ? a(e.value) : (t = e.value, t instanceof n ? t : new n(function(e) {
              e(t)
            })).then(o, s)
          }
          c((r = r.apply(e, t || [])).next())
        })
      },
      i = function(e, t) {
        var n, r, a, i, o = {
          label: 0,
          sent: function() {
            if (1 & a[0]) throw a[1];
            return a[1]
          },
          trys: [],
          ops: []
        };
        return i = {
          next: s(0),
          throw: s(1),
          return: s(2)
        }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
          return this
        }), i;

        function s(i) {
          return function(s) {
            return function(i) {
              if (n) throw new TypeError("Generator is already executing.");
              for (; o;) try {
                if (n = 1, r && (a = 2 & i[0] ? r.return : i[0] ? r.throw || ((a = r.return) && a.call(r), 0) : r.next) && !(a = a.call(r, i[1])).done) return a;
                switch (r = 0, a && (i = [2 & i[0], a.value]), i[0]) {
                  case 0:
                  case 1:
                    a = i;
                    break;
                  case 4:
                    return o.label++, {
                      value: i[1],
                      done: !1
                    };
                  case 5:
                    o.label++, r = i[1], i = [0];
                    continue;
                  case 7:
                    i = o.ops.pop(), o.trys.pop();
                    continue;
                  default:
                    if (!(a = o.trys, (a = a.length > 0 && a[a.length - 1]) || 6 !== i[0] && 2 !== i[0])) {
                      o = 0;
                      continue
                    }
                    if (3 === i[0] && (!a || i[1] > a[0] && i[1] < a[3])) {
                      o.label = i[1];
                      break
                    }
                    if (6 === i[0] && o.label < a[1]) {
                      o.label = a[1], a = i;
                      break
                    }
                    if (a && o.label < a[2]) {
                      o.label = a[2], o.ops.push(i);
                      break
                    }
                    a[2] && o.ops.pop(), o.trys.pop();
                    continue;
                }
                i = t.call(e, o)
              } catch (e) {
                i = [6, e], r = 0
              } finally {
                n = a = 0
              }
              if (5 & i[0]) throw i[1];
              return {
                value: i[0] ? i[1] : void 0,
                done: !0
              }
            }([i, s])
          }
        }
      },
      o = function(e, t) {
        return void 0 === e && (e = {}), void 0 === t && (t = {}), {
          state: r(r({}, e.state), t.state),
          getters: r(r({}, e.getters), t.getters),
          getActions: function(n) {
            var a, i;
            return r(r(r(r({}, null == e ? void 0 : e.actions), null == t ? void 0 : t.actions), null === (a = null == e ? void 0 : e.getActions) || void 0 === a ? void 0 : a.call(e, n)), null === (i = null == t ? void 0 : t.getActions) || void 0 === i ? void 0 : i.call(t, n))
          }
        }
      },
      s = function(e, t, n) {
        return t.reduce(function(t, n) {
          return a(void 0, void 0, void 0, function() {
            var r;
            return i(this, function(a) {
              switch (a.label) {
                case 0:
                  return [4, t];
                case 1:
                  return r = a.sent(), [2, n.bind(e)(r)];
              }
            })
          })
        }, Promise.resolve(n))
      },
      c = function(e, t, n) {
        return function(a) {
          return void 0 === a && (a = {}), new Promise(function(i) {
            e.createSelectorQuery().select(t).boundingClientRect().exec(function(e) {
              var t, o = e[0] ? e[0].top : 0;
              i(r(r({}, a), ((t = {})[n] = o, t)))
            })
          })
        }
      }
  },
  T6h7: function(e, t, n) {
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.default = void 0;
    var r, a = (r = n("ZxyO")) && r.__esModule ? r : {
      default: r
    };
    var i = function(e, t) {
      return e = new a.default(e), t = new a.default(t), parseFloat(e.minus(t).toFixed())
    };
    t.default = i, e.exports = t.default
  },
  "TO+A": function(e, t, n) {
    n.d(t, "b", function() {
      return a
    }), n.d(t, "a", function() {
      return i
    });
    var r = n("h+Rz");

    function a() {
      return r.a.stopPullDownRefresh()
    }

    function i() {
      return r.a.startPullDownRefresh()
    }
  },
  TOEM: function(e, t, n) {
    n.d(t, "a", function() {
      return a
    });
    var r = n("/XVY"),
      a = Object(r.a)({
        btnName: {
          default: ""
        },
        qrcode: {
          default: 0
        },
        isH5Support: {
          default: !1
        },
        isWeappContactSupport: {
          default: !1
        },
        isWeappSupport: {
          default: !1
        },
        customLogo: {
          default: ""
        },
        title: {
          default: ""
        },
        scene: {
          default: ""
        },
        bgColor: {
          default: ""
        },
        logo: {
          default: ""
        },
        subType: {
          default: 1
        },
        desc: {
          default: ""
        },
        type: {
          default: ""
        },
        headImageUrl: {
          default: ""
        },
        qrCodeUrl: {
          default: ""
        },
        imgOpt: {
          default: {}
        },
        cardBg: {
          default: ""
        },
        isFillet: {
          default: "1"
        },
        pagePadding: {
          default: 0
        },
        componentVersion: {
          default: "0"
        },
        logoType: {
          default: "1"
        }
      })
  },
  Tr3L: function(e, t, n) {
    n.d(t, "a", function() {
      return a
    });
    var r = n("h+Rz");

    function a() {
      return r.a.getNetworkType()
    }
  },
  TzfB: function(e, t, n) {
    n.d(t, "a", function() {
      return a
    });
    var r = n("ECkf"),
      a = Behavior({
        externalClasses: ["hover-class"],
        properties: {
          id: String,
          buttonId: String,
          lang: String,
          businessId: Number,
          sessionFrom: String,
          sendMessageTitle: String,
          sendMessagePath: String,
          sendMessageImg: String,
          showMessageCard: Boolean,
          appParameter: String,
          ariaLabel: String,
          openType: String,
          getUserProfileDesc: String
        },
        data: {
          canIUseGetUserProfile: Object(r.b)()
        },
        methods: {
          onGetUserInfo(e) {
            this.triggerEvent("getuserinfo", e.detail)
          },
          onContact(e) {
            this.triggerEvent("contact", e.detail)
          },
          onGetPhoneNumber(e) {
            this.triggerEvent("getphonenumber", e.detail)
          },
          onGetRealTimePhoneNumber(e) {
            this.triggerEvent("getrealtimephonenumber", e.detail)
          },
          onError(e) {
            this.triggerEvent("error", e.detail)
          },
          onLaunchApp(e) {
            this.triggerEvent("launchapp", e.detail)
          },
          onOpenSetting(e) {
            this.triggerEvent("opensetting", e.detail)
          },
          onAgreePrivacyAuthorization(e) {
            this.triggerEvent("agreeprivacyauthorization", e.detail)
          },
          onChooseAvatar(e) {
            this.triggerEvent("chooseavatar", e.detail)
          }
        }
      })
  },
  UL3R: function(e, t, n) {
    n.d(t, "a", function() {
      return i
    });
    var r = n("Fcif"),
      a = n("svh/");

    function i(e) {
      void 0 === e && (e = {});
      var t = e.mapData || {};
      return e.getters && (t = Object(r.a)({}, t, Object(a.f)(e.getters))), e.state && (t = Object(r.a)({}, t, Object(a.h)(e.state))), e.mapData = t, e
    }
  },
  VZJX: function(e, t, n) {
    var r = n("cm7J");
    e.exports = function(e) {
      var t = this.__data__,
        n = r(t, e);
      return n < 0 ? void 0 : t[n][1]
    }
  },
  VbZR: function(e, t) {
    e.exports = function(e) {
      return e != e
    }
  },
  VdoR: function(e, t, n) {
    var r = n("Pv5g"),
      a = Object(r.a)({
        appName: "wsc",
        logIndex: "new_wsc_weapp_log"
      });
    t.a = a
  },
  Vg0o: function(e, t, n) {
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.default = void 0;
    var r = h(n("QSkc")),
      a = h(n("5HXs")),
      i = h(n("LYai")),
      o = h(n("vgDv")),
      s = h(n("e2Yn")),
      c = h(n("OK7I")),
      u = h(n("9DIb")),
      d = h(n("w4n3")),
      l = h(n("cWxX")),
      p = h(n("s0cO"));

    function h(e) {
      return e && e.__esModule ? e : {
        default: e
      }
    }
    var f = {
      addZero: r.default,
      bem: a.default,
      escape: i.default,
      unescape: o.default,
      getLength: s.default,
      makeRandomString: c.default,
      mapKeysToCamelCase: u.default,
      mapKeysToSnakeCase: d.default,
      toCamelCase: l.default,
      toSnakeCase: p.default
    };
    t.default = f, e.exports = t.default
  },
  VlGz: function(e, t, n) {
    var r = Object.prototype.hasOwnProperty;

    function a(e) {
      try {
        return decodeURIComponent(e.replace(/\+/g, " "))
      } catch (e) {
        return null
      }
    }

    function i(e) {
      try {
        return encodeURIComponent(e)
      } catch (e) {
        return null
      }
    }
    t.stringify = function(e, t) {
      t = t || "";
      var n, a, o = [];
      for (a in "string" != typeof t && (t = "?"), e)
        if (r.call(e, a)) {
          if ((n = e[a]) || null != n && !isNaN(n) || (n = ""), a = i(a), n = i(n), null === a || null === n) continue;
          o.push(a + "=" + n)
        } return o.length ? t + o.join("&") : ""
    }, t.parse = function(e) {
      for (var t, n = /([^=?#&]+)=?([^&]*)/g, r = {}; t = n.exec(e);) {
        var i = a(t[1]),
          o = a(t[2]);
        null === i || null === o || i in r || (r[i] = o)
      }
      return r
    }
  },
  VmCB: function(e, t, n) {
    n.d(t, "a", function() {
      return y
    });
    var r, a, i = n("Fcif"),
      o = n("9DIb"),
      s = n.n(o),
      c = n("NHEX"),
      u = n.n(c),
      d = 0,
      l = 1,
      p = ((r = {})[d] = "全款预售", r[l] = "定金预售", r),
      h = ((a = {})[d] = "fullPresale", a[l] = "deposit", a),
      f = n("KEq0"),
      g = n.n(f);
    var v = {
      price: 0,
      oldPrice: 0,
      priceTitle: "",
      notShowPriceTitle: !1,
      soldNum: 0,
      stockNum: 0
    };

    function m(e) {
      return void 0 === e && (e = []), e.reduce((e, t) => Object(i.a)({}, e, {
        [t.skuId]: t
      }), {})
    }

    function y(e, t, n) {
      void 0 === n && (n = {});
      var r = u()(e, "staticData.goodsData", {}),
        a = u()(t, "showDefaultCartText"),
        {
          skuInfo: o,
          goods: c
        } = r,
        d = u()(c, "periodBuyExtra", null),
        f = function(e, t, n) {
          void 0 === e && (e = {}), void 0 === t && (t = null);
          var {
            props: r = [],
            messages: a = [],
            skus: o = [],
            hideStock: c = !1,
            birthdayInfo: d = {}
          } = e, l = [], p = r.map(e => (e.v = e.v.map(e => {
            var {
              imgUrl: t
            } = e;
            return t && (t = g()(t)), Object(i.a)({}, e, {
              imgUrl: t
            })
          }), e)), h = Object(i.a)({}, v, {
            hideStock: c,
            tree: p,
            list: l,
            messages: a,
            birthdayInfo: d
          }), f = m(e.skuPrices), y = m(e.skuStocks);
          if (n.isDisplaySkuPicture && p.length > 0 && (p[0].largeImageMode = !0), t) {
            var b = m(t.skuPrices),
              _ = m(t.skuStocks);
            l = o.map(e => {
              var {
                skuId: t
              } = e, n = f[t].price, r = _[t];
              r && r.disable && (r = Object(i.a)({}, r, {
                stockNum: 0
              }));
              var a = b[t];
              return a && a.price > 0 && (a = Object(i.a)({}, a, {
                notShowPriceTitle: a.price >= n
              })), Object(i.a)({}, v, e, {
                oldPrice: n
              }, a, r, {
                id: t
              })
            }), h = Object(i.a)({}, h, t.spuStock, t.spuPrice, {
              collectionId: u()(t, "spuStock.skuId", 0),
              collectionPrice: u()(t, "spuPrice.price", 0),
              oldPrice: u()(e, "spuPrice.price", 0),
              list: l
            })
          } else l = o.map(e => {
            var {
              skuId: t
            } = e;
            return Object(i.a)({}, v, e, {
              oldPrice: 0
            }, f[t], y[t], {
              id: t
            })
          }), h = Object(i.a)({}, h, e.spuStock, e.spuPrice, {
            collectionId: u()(e, "spuStock.skuId", 0),
            collectionPrice: u()(e, "spuPrice.price", 0),
            list: l
          });
          var O = 1 / 0,
            S = 0,
            w = 1 / 0,
            I = 0,
            P = 0 === h.list.length;
          return P ? (h.collectionPrice = O = S = h.price, w = I = h.oldPrice || 0) : (h.stockNum = h.list.reduce((e, t) => e + (t.stockNum || 0), 0), h.list.forEach(e => {
            e.disable || h.stockNum > 0 && 0 === e.stockNum || (O = Math.min(O, e.price), S = Math.max(S, e.price), w = Math.min(w, e.oldPrice), I = Math.max(I, e.oldPrice))
          }), h.price = O || S || 0, h.oldPrice = w || I || 0), h.price = h.price || O || S || 0, isFinite(I) || (I = 0), h.oldPrice = h.oldPrice || w || I || 0, s()(Object(i.a)({}, h, {
            noneSku: P,
            minPrice: O,
            maxPrice: S,
            oldMinPrice: w,
            oldMaxPrice: I,
            previewOnClickImage: !1
          }))
        }(o, null, c),
        y = function(e, t) {
          return void 0 === t && (t = {}), {
            quota: e.quota || 0,
            quotaUsed: (t.goodsExtra || {}).quotaUsed || e.quotaUsed || 0,
            singleQuota: e.isHaitao || e.isVirtualTicket || e.isVirtualCoupon ? 100 : 0,
            quotaCycle: e.quotaCycle,
            startSaleNum: e.startSaleNum || 1
          }
        }(c, n);
      if (f.limit = y, f.stepperTitle = d ? "每期配送数量" : a ? "购买数量" : "数量", c.preSaleInfo) {
        var {
          preSaleType: b
        } = c.preSaleInfo, _ = p[b], O = h[b];
        if (f.priceTags = [{
            text: _,
            type: O
          }], b === l) {
          var S = function(e, t) {
            var {
              price: n,
              minPrice: r,
              maxPrice: a,
              list: o
            } = t, {
              deposit: s,
              minDeposit: c,
              maxDeposit: u,
              skuDepositModels: d
            } = e;
            if (d && d.length) {
              var l = d.reduce((e, t) => Object(i.a)({}, e, {
                [t.skuId]: t.deposit
              }), {});
              o.forEach(e => {
                e.price = l[e.skuId]
              })
            }
            return {
              price: s || c || u || 0,
              minPrice: c || s,
              maxPrice: u || s,
              oldPrice: n,
              oldMinPrice: r,
              oldMaxPrice: a,
              list: o,
              pricePrefix: "定金"
            }
          }(c.preSaleInfo, f);
          Object.assign(f, S)
        }
      }
      return {
        goods: f
      }
    }
  },
  Vnr7: function(e, t, n) {
    n.d(t, "a", function() {
      return a
    });
    var r = n("9ZMt");

    function a(e, t) {
      return r.default.$native.createIntersectionObserver(e, t)
    }
  },
  W3qh: function(e, t, n) {
    n.d(t, "a", function() {
      return s
    });
    var r = n("3lAQ"),
      a = n.n(r),
      i = n("F0jR"),
      o = n.n(i);
    class s {
      constructor(e) {
        this.ctx = e.ctx
      }
    }
    s.widgets = {
      Main: a(),
      SubmitNotice: o()
    }
  },
  WNIS: function(e, t, n) {
    n.d(t, "j", function() {
      return r
    }), n.d(t, "a", function() {
      return a
    }), n.d(t, "b", function() {
      return i
    }), n.d(t, "e", function() {
      return o
    }), n.d(t, "c", function() {
      return s
    }), n.d(t, "i", function() {
      return c
    }), n.d(t, "h", function() {
      return u
    }), n.d(t, "l", function() {
      return d
    }), n.d(t, "k", function() {
      return l
    }), n.d(t, "g", function() {
      return p
    }), n.d(t, "f", function() {
      return h
    }), n.d(t, "d", function() {
      return f
    });
    var r = {
        NUM: 1,
        DISCOUNT: 2,
        EXCHANGE: 3,
        BUY_PRESENT: 4,
        EXPRESS: 5
      },
      a = {
        FIXED: 1,
        ASSIGNED: 2,
        RANDOM: 3,
        NOASSIGNED: 4
      },
      i = {
        Valid: 1,
        Used: 2,
        Expired: 3,
        Invalid: 4,
        Locked: 5
      },
      o = {
        Code: "code",
        Card: "card",
        Thirdparty: "thirdparty"
      },
      s = {
        Normal: 0,
        Code: 1,
        Thirdparty: 2
      },
      c = {
        Birthday: 1,
        MemberDay: 2,
        Festival: 3
      },
      u = {
        NotStart: 0,
        InProgress: 1,
        Terminated: 2,
        ActivePause: 3,
        AbnormalPause: 4,
        Finished: 5
      },
      d = "scene-market-subscribe",
      l = "cimWeMiniProMsg",
      p = "points-expire-subscribe",
      h = "maCrmMiniProPoint",
      f = {
        homeOrFeature: "homeOrFeature",
        memberCenterClick: "memberCenterClick",
        levelGuide: "levelGuide"
      }
  },
  WOkX: function(e, t, n) {
    n.d(t, "b", function() {
      return o
    }), n.d(t, "c", function() {
      return s
    }), n.d(t, "a", function() {
      return c
    });
    var r = n("Y28S"),
      a = getApp(),
      i = () => (a = a || getApp()).getKdtId(),
      o = e => {
        var {
          sl: t,
          sls: n,
          oldFromParamsData: a = {}
        } = e, o = i();
        return Object(r.b)({
          sl: t,
          sls: n,
          oldFromParamsData: a,
          kdtId: o
        })
      },
      s = e => {
        var {
          sl: t,
          sls: n,
          oldFromParamsData: a
        } = e, o = i();
        return Object(r.c)({
          sl: t,
          sls: n,
          oldFromParamsData: a,
          kdtId: o
        })
      };

    function c(e) {
      var {
        url: t,
        sl: n,
        sls: a
      } = e, o = i();
      return Object(r.a)({
        url: t,
        sl: n,
        sls: a,
        kdtId: o
      })
    }
  },
  WQRT: function(e, t, n) {
    n.d(t, "c", function() {
      return o
    }), n.d(t, "d", function() {
      return s
    }), n.d(t, "a", function() {
      return u
    }), n.d(t, "b", function() {
      return d
    });
    var r = n("NHEX"),
      a = n.n(r),
      i = function() {
        return (i = Object.assign || function(e) {
          for (var t, n = 1, r = arguments.length; n < r; n++)
            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
          return e
        }).apply(this, arguments)
      };

    function o(e) {
      var t = a()(e, "goods.id", 0),
        n = a()(e, "goods.postage", 0);
      return {
        goodsId: t,
        kdtId: a()(e, "shop.kdtId", 0),
        storeId: a()(e, "shop.multistore.id", 0),
        storeName: a()(e, "shop.multistore.name", 0),
        postage: "string" != typeof n ? n : 0
      }
    }

    function s(e) {
      var t = e.selectedNum,
        n = void 0 === t ? 0 : t,
        r = e.selectedSkuComb,
        a = void 0 === r ? {
          id: 0,
          price: 0
        } : r,
        o = e.messages,
        s = void 0 === o ? {} : o,
        c = e.cartMessages,
        u = void 0 === c ? {} : c,
        d = e.birthdayVal,
        l = void 0 === d ? {} : d,
        p = a.id,
        h = void 0 === p ? 0 : p,
        f = a.price,
        g = void 0 === f ? 0 : f;
      return i(i({}, a), {
        skuId: h,
        num: n,
        price: g,
        messages: s,
        cartMessages: u,
        birthdayRelation: {
          BIRTHDAY_RELATION_NET_ORDER_MARK: l.birthdayRelationNetOrderMark,
          RELATION_BLESSING: l.text,
          RELATION_TYPE_ID: l.key,
          RELATION_TYPE_NAME: l.name
        }
      })
    }

    function c(e) {
      var t = i(i({
          goods_id: e.goodsId,
          num: e.num,
          sku_id: e.skuId,
          price: e.price || 0,
          extra: e.birthdayRelation
        }, e.messages), e.goodsExtra),
        n = i({
          kdt_id: e.kdtId,
          store_id: e.storeId || 0,
          store_name: e.storeName || "",
          postage: e.postage || 0,
          activity_alias: e.activityAlias || "",
          activity_id: e.activityId || 0,
          activity_type: e.activityType || 0,
          use_wxpay: e.useWxpay || 0,
          from: e.from || ""
        }, e.commonExtra);
      return e.from && (n.from = e.from), {
        goodsData: t,
        commonData: n
      }
    }

    function u(e) {
      var t = c(e),
        n = t.goodsData,
        r = t.commonData,
        a = n.propertyIds;
      a && (n.propertyIds = JSON.stringify(a));
      var o = [];
      return Object.keys(e.cartMessages).forEach(function(t) {
        o.push(e.cartMessages[t])
      }), i(i(i({}, n), r), {
        messages: JSON.stringify(o),
        extra: JSON.stringify(n.extra || {})
      })
    }

    function d(e) {
      var t = c(e),
        n = t.goodsData,
        r = t.commonData,
        a = {
          goodsList: JSON.stringify([n]),
          common: JSON.stringify(r)
        };
      return e.extra && (a.extra = JSON.stringify(e.extra)), e.cloudExtension && (a.cloudExtension = e.cloudExtension), a
    }
  },
  WjON: function(e, t, n) {
    var r = n("zcvR");
    e.exports = function(e) {
      var t = r(this, e).delete(e);
      return this.size -= t ? 1 : 0, t
    }
  },
  WlwD: function(e, t, n) {
    n.d(t, "a", function() {
      return l
    });
    var r = n("Tewj"),
      a = n("ML4D"),
      i = n.n(a),
      o = n("JdrY"),
      s = n("n0bX"),
      c = n.n(s),
      u = n("gKWa"),
      d = n.n(u);
    class l {
      constructor(e) {
        this.ctx = e.ctx, this.widget = i.a, this.ctx.data.random = Math.random()
      }
      onPullDownRefresh() {
        r.default.trigger(o.a.PULL_DOWN)
      }
      onPageScroll(e) {
        r.default.trigger(o.a.PAGE_SCROLL, e)
      }
    }
    l.widgets = {
      Main: i(),
      FloatingNavBg: c(),
      SubItem: d()
    }
  },
  Wnk8: function(e, t, n) {
    n.d(t, "a", function() {
      return o
    });
    var r = n("1pB4"),
      a = e => ({
        enter: "vt-" + e + "-enter vt-" + e + "-enter-active enter-class enter-active-class",
        "enter-to": "vt-" + e + "-enter-to vt-" + e + "-enter-active enter-to-class enter-active-class",
        leave: "vt-" + e + "-leave vt-" + e + "-leave-active leave-class leave-active-class",
        "leave-to": "vt-" + e + "-leave-to vt-" + e + "-leave-active leave-to-class leave-active-class"
      }),
      i = () => new Promise(e => setTimeout(e, 1e3 / 30)),
      o = function(e, t) {
        return void 0 === t && (t = "name"), {
          props: {
            customStyle: String,
            show: {
              type: Boolean,
              default: e
            },
            duration: {
              type: null,
              default: 300
            },
            name: {
              type: String,
              default: "fade"
            },
            enterIsSleep: {
              type: Boolean,
              default: !0
            }
          },
          watch: {
            show(e, t) {
              e !== t && (e ? this.enter() : this.leave())
            }
          },
          mounted() {
            this.show ? this.enter() : this.leave()
          },
          data() {
            return {
              inited: !1,
              classes: "",
              style: this._getStyle()
            }
          },
          logicData: () => ({
            display: !1,
            currentDuration: 0,
            transitionEnded: !1
          }),
          created() {
            ["duration", "status", "display", "customStyle"].forEach(e => {
              this.$watch(e, () => {
                this.style = this._getStyle()
              })
            })
          },
          methods: {
            _getStyle() {
              var {
                duration: e
              } = this, t = Object(r.f)(e) ? "enter" === this.status ? e.enter : e.leave : e;
              return "\n          -webkit-transition-duration: " + t + "ms;\n          transition-duration: " + t + "ms;\n          " + (this.display ? "" : "display: none;") + "\n          " + this.customStyle + "\n        "
            },
            enter() {
              var e = this[t],
                n = a(e);
              this.status = "enter", this.$emit("before-enter"), (this.enterIsSleep ? Promise.resolve().then(i) : Promise.resolve()).then(() => {
                if (this.checkStatus("enter"), this.$emit("enter"), this.inited = !0, this.display = !0, this.classes = n.enter, this.enterIsSleep) return i()
              }).then(() => {
                this.checkStatus("enter"), this.transitionEnded = !1, setTimeout(() => this.onTransitionEnd()), this.classes = n["enter-to"]
              }).catch(() => {})
            },
            leave() {
              if (this.display) {
                var {
                  duration: e
                } = this, n = this[t], o = a(n), s = Object(r.f)(e) ? e.leave : e;
                this.status = "leave", this.$emit("before-leave"), Promise.resolve().then(i).then(() => {
                  this.checkStatus("leave"), this.$emit("leave"), this.classes = o.leave
                }).then(i).then(() => {
                  this.checkStatus("leave"), this.transitionEnded = !1, setTimeout(() => this.onTransitionEnd(), s), this.classes = o["leave-to"]
                }).catch(() => {})
              }
            },
            checkStatus(e) {
              if (e !== this.status) throw new Error("incongruent status: " + e)
            },
            onTransitionEnd() {
              if (!this.transitionEnded) {
                this.transitionEnded = !0, this.$emit("after-" + this.status);
                var {
                  show: e,
                  display: t
                } = this;
                !e && t && (this.display = !1)
              }
            }
          }
        }
      }
  },
  "X/0h": function(e, t) {
    e.exports = function(e, t) {
      return null == e ? void 0 : e[t]
    }
  },
  X3j9: function(e, t, n) {
    n.d(t, "a", function() {
      return i
    });
    var r = n("Fcif"),
      a = n("noo5");

    function i(e, t, n, i) {
      var o, {
          geoLocationData: s,
          salableStores: c = []
        } = t,
        {
          status: u,
          id: d,
          name: l,
          hideStore: p,
          openMultiStoreSwitch: h = 0
        } = e,
        {
          city: f = "",
          district: g = "",
          address: v = ""
        } = e.address || {};
      return n && (n.showMultiStoreRecommend = !!d && !i.goods.stockNum), {
        id: d,
        name: l,
        address: "" + f + g + v,
        isMultiStoreEnabled: !!u,
        openMultiStoreSwitch: h,
        hideStore: p,
        distance: s.distance || 0,
        salableStores: (o = c, o && o.length > 0 ? o.map(e => Object(r.a)({}, e, {
          query: {
            oid: e.id
          },
          distance: Object(a.formatDistance)(e.distance)
        })) : [])
      }
    }
  },
  X7EK: function(e, t, n) {
    e.exports = function(e) {
      return encodeURIComponent(e).replace(/[!'()*]/g, function(e) {
        return "%" + e.charCodeAt(0).toString(16).toUpperCase()
      })
    }
  },
  "X9+V": function(e, t, n) {
    n.d(t, "a", function() {
      return s
    }), n.d(t, "c", function() {
      return c
    }), n.d(t, "b", function() {
      return u
    });
    var r = n("Fcif"),
      a = n("YnUx"),
      i = n.n(a);

    function o(e, t, n) {
      if (void 0 === t && (t = 2), void 0 === n && (n = !1), "number" != typeof e) return "";
      var r = (e / 100).toFixed(t);
      return n ? parseFloat(r) : r
    }
    var s = function(e, t) {
        return void 0 === t && (t = "~"), i()(e) ? o(e.min) + t + o(e.max) : o(e)
      },
      c = function(e, t) {
        return void 0 === t && (t = {}), void 0 !== e.isStarted && !1 === e.isStarted ? {} : Object(r.a)({}, t, {
          quota: e.quota || 0,
          quotaUsed: e.quotaUsed || 0,
          quotaCycle: e.quotaCycle || 0
        })
      };

    function u(e) {
      var {
        umpActivity: t
      } = e;
      return Object.keys(t).indexOf("coupon") > -1
    }
  },
  XCh3: function(e, t, n) {
    n.d(t, "b", function() {
      return i
    }), n.d(t, "a", function() {
      return o
    });
    var r = n("8B9M"),
      a = Object(r.a)(),
      i = (e, t) => {
        var n = {};
        switch (e) {
          case "view":
            n = {
              et: "view",
              ei: "view",
              en: "商品曝光",
              params: {
                view_objs: t
              }
            };
            break;
          case "open_goods":
            n = {
              et: "click",
              ei: "open_goods",
              en: "打开商品详情",
              params: t
            };
            break;
          case "click_buy":
            n = {
              et: "click",
              ei: "click_buy",
              en: "点击购买",
              params: t
            };
            break;
          case "click_content":
            n = {
              et: "click",
              ei: "click_content",
              en: "组件点击",
              params: t
            };
            break;
          case "logger":
            n = t;
        }
        return n
      },
      o = e => {
        a.logger.log(e)
      }
  },
  XS2z: function(e, t, n) {
    var r;
    n.d(t, "a", function() {
        return r
      }),
      function(e) {
        e.NORMAL = "normal", e.SEPARATE = "separate"
      }(r || (r = {}))
  },
  XXCu: function(e, t) {
    e.exports = function(e) {
      var t = this.has(e) && delete this.__data__[e];
      return this.size -= t ? 1 : 0, t
    }
  },
  Xdhg: function(e, t, n) {
    var r = n("Br49");
    t.a = {
      register: function(e, t, n) {
        var a = t + "%" + e + "%" + Date.now() + "%" + Math.floor(1e4 * Math.random() + 1);
        if (e === r.d.POPUP && n) {
          if (n.__userAuthorizePopups = n.__userAuthorizePopups || [], n.__userAuthorizePopups.length > 0) return "";
          n.__userAuthorizePopups.push(a)
        }
        return a
      },
      remove: function(e, t, n) {
        try {
          if (e === r.d.POPUP && Array.isArray(n.__userAuthorizePopups)) {
            var a = n.__userAuthorizePopups.indexOf(t);
            n.__userAuthorizePopups.splice(a, 1)
          }
          return t
        } catch (e) {
          return !1
        }
      },
      getLatestPopupId: function(e, t) {
        var n = e.__userAuthorizePopups;
        if (Array.isArray(n)) return n[n.length - 1]
      }
    }
  },
  Xq7Z: function(e, t, n) {
    n.d(t, "k", function() {
      return r
    }), n.d(t, "j", function() {
      return a
    }), n.d(t, "g", function() {
      return i
    }), n.d(t, "f", function() {
      return o
    }), n.d(t, "c", function() {
      return s
    }), n.d(t, "e", function() {
      return c
    }), n.d(t, "m", function() {
      return u
    }), n.d(t, "i", function() {
      return d
    }), n.d(t, "a", function() {
      return l
    }), n.d(t, "h", function() {
      return p
    }), n.d(t, "b", function() {
      return h
    }), n.d(t, "d", function() {
      return f
    }), n.d(t, "l", function() {
      return g
    });
    var r = {
        0: "card",
        1: "waterfall",
        2: "simple",
        3: "promotion",
        4: "multi",
        5: "card2",
        6: "points",
        7: "card-shadow",
        8: "tag-left"
      },
      a = {
        CARD: 0,
        WATERFALL: 1,
        SIMPLE: 2,
        PROMOTION: 3,
        MULTI: 4,
        CARD2: 5,
        POINTS: 6,
        CARD_SHADOW: 7,
        TAG_LEFT: 8
      },
      i = {
        0: "big",
        1: "small",
        2: "hybrid",
        3: "list",
        5: "three",
        6: "swipe"
      },
      o = {
        BIG: 0,
        SMALL: 1,
        HYBRID: 2,
        LIST: 3,
        MULTI: 4,
        THREE: 5,
        SWIPE: 6
      },
      s = {
        0: "new-arrival",
        1: "hot-sale",
        2: "new",
        3: "hot"
      },
      c = {
        0: "3:2",
        1: "1:1",
        2: "3:4",
        3: "16:9"
      },
      u = {
        1: "normal",
        2: "bold"
      },
      d = {
        1: "rect",
        2: "circle"
      },
      l = {
        SMALL: "small",
        BIG: "big"
      },
      p = {
        COLUMN: "https://img01.yzcdn.cn/public_files/2018/08/20/d5b6ccfc9383b976fc02a88f43f49ef2.png",
        TEXT: "https://img01.yzcdn.cn/public_files/2018/08/20/b24699aee714351838f730cdb59de84a.png",
        AUDIO: "https://img01.yzcdn.cn/public_files/2018/08/20/e05ef730df7b6fb43844b908734a9fc0.png",
        VIDEO: "https://img01.yzcdn.cn/public_files/2018/08/20/0bfab52c6a9c77b58ca686567479b4ab.png",
        LIVE: "https://img01.yzcdn.cn/public_files/2018/08/20/aac3b43a16195809ab479746236a457c.png"
      },
      h = {
        COLUMN: "",
        TEXT: "",
        AUDIO: "",
        VIDEO: "",
        LIVE: ""
      },
      f = {
        READ: "免费试读",
        LISTEN: "免费试听",
        WATCH: "免费试看"
      },
      g = "https://img01.yzcdn.cn/weapp/wsc/lPgl6z.png"
  },
  "Xr+B": function(e, t, n) {
    n.d(t, "b", function() {
      return a
    }), n.d(t, "a", function() {
      return i
    });
    var r = n("9ZMt");

    function a(e) {
      r.default.$native.onPageNotFound(e)
    }

    function i(e) {
      r.default.$native.offPageNotFound(e)
    }
  },
  Y0JT: function(e, t, n) {
    n.d(t, "a", function() {
      return s
    });
    var r = n("COAg"),
      a = n.n(r),
      i = n("vmqh"),
      o = n.n(i);
    class s {
      constructor(e) {
        this.ctx = e.ctx
      }
    }
    s.widgets = {
      Main: a(),
      NavigationBar: o()
    }
  },
  Y2PO: function(e, t, n) {
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.default = void 0;
    var r, a = (r = n("O1uH")) && r.__esModule ? r : {
      default: r
    };
    var i = function(e, t) {
      return Array.isArray(e) ? 0 !== e.length ? (0, a.default)(e, t, function(e, t) {
        return e < t
      }) : void 0 : e
    };
    t.default = i, e.exports = t.default
  },
  Yfvy: function(e, t, n) {
    n.d(t, "a", function() {
      return a
    }), n.d(t, "b", function() {
      return i
    });
    var r = {};
    var a = e => r[e] || [],
      i = (e, t) => ({})
  },
  YnUx: function(e, t, n) {
    var r;
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.default = void 0;
    var a = ((r = n("C6tv")) && r.__esModule ? r : {
      default: r
    }).default;
    t.default = a, e.exports = t.default
  },
  "Yof+": function(e, t, n) {
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.default = function(e, t, n) {
      if (!e) return;
      if (e.length === +e.length)
        for (var r = 0, a = e.length; r < a; r++) t.call(n, e[r], r, e);
      else
        for (var i = Object.keys(e), o = 0, s = i.length; o < s; o++) t.call(n, e[i[o]], i[o], e)
    }, e.exports = t.default
  },
  Yt9W: function(t, n, r) {
    r.d(n, "e", function() {
      return g
    }), r.d(n, "c", function() {
      return v
    }), r.d(n, "a", function() {
      return m
    }), r.d(n, "g", function() {
      return y
    }), r.d(n, "d", function() {
      return b
    }), r.d(n, "f", function() {
      return _
    });
    var a = r("Fcif"),
      i = r("2wjL"),
      o = r("2ktG"),
      s = r("xqQ2");

    function c(t, n) {
      void 0 === n && (n = "");
      try {
        t()
      } catch (t) {
        var r = getApp() || {},
          {
            logger: a = {}
          } = r;
        a.onError && a.onError({
          name: "log 打点报错",
          message: e.msg || e.message || "",
          detail: {
            msg: n
          }
        })
      }
    }
    class u extends s.a {
      addSessionParams() {
        for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
        c(() => super.addSessionParams(...t), "addSessionParams error")
      }
      setBizInfo() {
        for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
        c(() => super.setBizInfo(...t), "setBizInfo error")
      }
      appShow() {
        for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
        c(() => super.appShow(...t), "appShow error")
      }
      appHide() {
        for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
        c(() => super.appHide(...t), "appHide error")
      }
      pageShow() {
        for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
        c(() => super.pageShow(...t), "pageShow error")
      }
      pageHide() {
        for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
        c(() => super.pageHide(...t), "pageHide error")
      }
      log() {
        for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
        c(() => super.log(...t), "log error")
      }
      performance() {}
      updateSession() {}
    }
    var d = u,
      l = r("OPDa"),
      p = r("wfgx"),
      {
        getSpm: h
      } = p.a,
      f = function() {
        return Object(o.a)({}).get("logv3:dc_ps") || ""
      };

    function g(e) {
      var t = getApp();
      t.logger.pageHide({
        id: e
      }), t.logger.pageEvent.params = {}
    }

    function v(e, t) {
      void 0 === e && (e = {}), void 0 === t && (t = getApp());
      var n = t.globalData.adData || {},
        r = t.globalData.loggerData || {};
      t.globalData.adData = {
        gdtVid: e.gdt_vid || n.gdtVid || "",
        qzGdt: e.qz_gdt || n.qzGdt || "",
        weixinadinfo: e.weixinadinfo || n.weixinadinfo || "",
        sceneType: e.scene_type || n.sceneType || ""
      }, t.globalData.loggerData = {
        chan_id: e.chan_id || r.chan_id || "",
        room_id: e.room_id || r.room_id || ""
      }
    }

    function m() {
      var e = getApp();
      e && (e.globalData.loggerData = {})
    }
    var y = function(e, t) {
      void 0 === t && (t = getApp());
      var n = t.getKdtId() || "",
        r = t.getMobile() || "",
        i = t.getBuyerId() || "",
        o = t.getToken() || {},
        {
          openId: s = "",
          yzUserId: c = "",
          userId: u = "",
          platformFansId: d = "",
          unionId: l = ""
        } = o,
        p = i || c || u,
        h = u,
        f = d;
      e.setBizInfo({
        mobile: r,
        userId: p,
        kdtId: n
      });
      var g = t.globalData.adData || {},
        v = t.globalData.loggerData || {},
        m = {
          union_id: l,
          yz_uid: p,
          buyerId: i,
          buyer_id: i,
          open_id: s,
          fans_id: h,
          yz_fans_id: f
        };
      e.setPageParams(Object(a.a)({
        oid: t.getOfflineId(),
        hq_kdt_id: t.getHQKdtId()
      }, m, {
        chan_id: v.chan_id,
        room_id: v.room_id,
        weixinadinfo: g.weixinadinfo
      })), e.setUser(Object(a.a)({}, m))
    };

    function b(e, t, n, r, i, o) {
      void 0 === n && (n = {});
      var s = getApp();
      l.a.setCurrentSpm(e, t, r, i), n && n.en && (s.logger.setPageName(n.en), delete n.en);
      var c = !1;
      if (i && i.length) {
        var u = i[i.length - 1];
        u._isNewlyOpen || (c = !0, u._isNewlyOpen = !0)
      }
      y(s.logger), s.logger.setPageParams(Object(a.a)({}, n, {
        is_newly_open: c,
        is_retail: s.globalData.isRetailApp
      })), s.logger.pageShow({
        id: t
      }, o)
    }

    function _(e, t) {
      t = t || {}, getApp().logger.appError({
        message: e,
        detail: Object(a.a)({}, t, {
          spm: h()
        })
      })
    }
    d.processShareData = function(e) {
      void 0 === e && (e = {});
      var t = getApp(),
        n = f(),
        r = e.path || "/packages/home/dashboard/index",
        o = {};
      return i.a.getAll(r).kdt_id || (o.kdt_id = t.getKdtId()), n && (o.dc_ps = n), t.getShopInfoSync().isMultiStore && (r = i.a.add(r, {
        offlineId: t.getOfflineId()
      })), r = i.a.add(r, o), Object(a.a)({}, e, {
        path: r
      })
    }, d.getDCPS = f, d.getTradeLog = function(e) {
      void 0 === e && (e = {});
      var t = getApp().logger.getGlobal() || {},
        n = t.user || {},
        r = t.context || {},
        i = t.plat || {};
      return JSON.stringify(Object(a.a)({}, r, i, {
        platform: "weapp",
        uuid: n.uuid,
        userId: n.li || ""
      }, e))
    };
    n.b = d
  },
  Yzgk: function(e, t, n) {
    var r = n("RqPZ"),
      a = n("zc1V"),
      i = n("9aUh"),
      o = n("bE7W"),
      s = /^\[object .+?Constructor\]$/,
      c = Function.prototype,
      u = Object.prototype,
      d = c.toString,
      l = u.hasOwnProperty,
      p = RegExp("^" + d.call(l).replace(/[\\^$.*+?()[\]{}|]/g, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$");
    e.exports = function(e) {
      return !(!i(e) || a(e)) && (r(e) ? p : s).test(o(e))
    }
  },
  ZIOE: function(e, t, n) {
    n.r(t), n.d(t, "getShopInfoParams", function() {
      return I
    }), n.d(t, "fetchLaunchJsonCallback", function() {
      return P
    }), n.d(t, "getKdtId", function() {
      return k
    }), n.d(t, "updateKdtId", function() {
      return j
    }), n.d(t, "setShopInfo", function() {
      return x
    }), n.d(t, "getShopTheme", function() {
      return A
    }), n.d(t, "getHiddenPowerBy", function() {
      return C
    }), n.d(t, "getShopConfigData", function() {
      return D
    }), n.d(t, "getCopyright", function() {
      return M
    }), n.d(t, "getNavConfigSync", function() {
      return N
    }), n.d(t, "getNavConfig", function() {
      return L
    }), n.d(t, "getShopInfo", function() {
      return R
    }), n.d(t, "waitForEnterShop", function() {
      return B
    }), n.d(t, "getShopInfoSync", function() {
      return F
    }), n.d(t, "getShopConfigDataSync", function() {
      return q
    }), n.d(t, "getOfflineId", function() {
      return H
    }), n.d(t, "getOfflineSeparatePrice", function() {
      return z
    }), n.d(t, "setOfflineId", function() {
      return G
    }), n.d(t, "getHQKdtId", function() {
      return W
    }), n.d(t, "getCryptoInfo", function() {
      return K
    });
    var r = n("eijD"),
      a = n("Fcif"),
      i = n("uhII"),
      o = i.a,
      s = n("jA1y"),
      c = (n("Tewj"), n("qHGj")),
      u = n("zMoS"),
      d = n("DXKY"),
      l = n("taYb"),
      p = n("x5Yp"),
      h = n("/duV"),
      f = n("sbwY"),
      g = n("7WjY"),
      v = n("rBuL"),
      m = n("LHcj"),
      y = n("lRMv"),
      b = n("bBDD"),
      _ = n("f9/1"),
      O = n("SVbq"),
      {
        state: S,
        commit: w
      } = f.a;

    function I() {
      return {
        weapp_type: S.config.weappType,
        share_offline_id: Object(m.a)("current_share_offline_id") || "",
        not_enter_shop: "1",
        global_theme_version: 1
      }
    }

    function P(e) {
      void 0 === e && (e = {});
      var {
        fromCache: t,
        cacheData: n = {},
        enable_http2: r = !1,
        enable_cdn: i = !1,
        mall_shop_config_data: o
      } = e, s = getApp();
      return s && s.globalData && (s.globalData.enableHttp2 = r, s.globalData.enableCdn = i, s.globalData.mall_shop_config_data = o), t && n.refreshPromise.then(e => {
        var {
          shop_meta_info: t = {}
        } = e, n = 2 == +Object(u.a)(S, "shop.shopMetaInfo.shop_role", null);
        if (!+k() || !n || +k() === t.kdt_id || 1 !== t.shop_role) return e
      }), Object(a.a)({}, e, {
        _fromCache: t
      })
    }

    function k() {
      return Object(h.c)() || Object(u.a)(S, "shop.kdtId", null)
    }

    function j(e, t, n) {
      if (void 0 === e && (e = 0), void 0 === t && (t = !1), void 0 === n && (n = {}), +e > 0) return Object(h.q)(e, Object(a.a)({}, n, {
        force: t
      }))
    }

    function x(e) {
      return void 0 === e && (e = {}), w("UPDATE_SHOP_DATA", e), Object(_.getEnterCacheConfig)("isProxyUpdateKdtId") || d.a.trigger("shop:info:change", e), S.shop
    }

    function T(e) {
      return () => new Promise(t => {
        var n = S.shop[e] || {};
        S.shop.hasBase && 0 !== Object.keys(n).length ? t(S.shop[e]) : d.a.once("shop:" + e + ":resolved", () => t(S.shop[e]))
      })
    }
    Object(h.f)({
      request: function() {
        var e = I(),
          t = {
            skipShopInfo: !0,
            cache: !0,
            needRefresh: !0,
            expire: 30
          };
        return function e(t, n) {
          void 0 === n && (n = 3);
          return t().catch(r => n > 0 ? e(t, n - 1) : Promise.reject(r))
        }(() => s.c({
          path: "wscshop/weapp/launch.json",
          data: Object(a.a)({}, e, {
            need_cnd: !0
          }),
          config: t
        })).then(function(e) {
          return void 0 === e && (e = {}), P(e)
        }).catch(e => (d.a.trigger("shop:info:fetch:fail"), Promise.reject(e)))
      },
      pick: e => {
        var {
          type: t,
          colors: n
        } = e.shop_theme_data;
        return {
          shop: l.a.toCamelCase(Object(a.a)({}, e.shop_meta_info, {
            logo: Object(u.a)(e, "shop_info.logo")
          })),
          multiStore: l.a.toCamelCase(e.offline_data),
          theme: {
            type: t,
            colors: n || i.b
          }
        }
      },
      onShopInfoChange: (e, t, n) => ((e, t) => {
        var {
          isFromBlankPageOrOnLaunch: n = !1
        } = t;
        Object(_.createChainStoreEvent)();
        var {
          _fromCache: r
        } = e, s = {}, {
          shop_info: c = {},
          offline_data: u = {},
          copyright_data: l = {},
          mall_shop_config_data: p = {},
          business_data: h,
          is_hide_power_by: f,
          is_stop_we_pay_for_vitual: v,
          shop_theme_data: m = {},
          shop_meta_info: y,
          shop_business_config: b = {},
          shop_nav_data: O = {},
          crypto_info: w = {}
        } = e;
        s.isMultiStore = u.is_multi_store, s.autoEntryStore = u.auto_entry_store, s.soldOutRecommend = u.sold_out_recommend, s.offlineSeparatePrice = u.offline_separate_price, s.openHideStore = +e.mall_shop_config_data.open_hide_store, s.multiStoreSwitch = 1 == +e.mall_shop_config_data.open_multi_store_switch, s.isDecorateFollowHq = 0 == +e.mall_shop_config_data.subshop_decorate_independent, s.hideTopBar = +e.mall_shop_config_data.hide_top_bar, s.hasBase = !0, s.nav = O.data || {}, Object.assign(s, c), s.base = Object(a.a)({}, c), s.isServiceDue = c.service && "WEAPP_AVAILABLE" !== c.service.status, s.security = {}, s.security.joined = 0 != +c.security.joined, s.virtualGoodsCannotWePay = v, Object.assign(S.shop, s), s.copyright = Object(a.a)({}, S.shop.copyright || {}, {
          isCustomized: !!l.is_logo_customized,
          isWeixinSelfHoldPay: e.is_weixin_self_hold_pay,
          hideFooter: l.hide_footer,
          hideQuickEntry: l.hide_quick_entry,
          hideLogo: l.hide_logo,
          hidePoweredBy: l.hide_powered_by || f
        }), s.copyright.isCustomized && (s.copyright.logo = l.customized_logo || g.a.copyright.logo), s.config = p, s.shop_business_isopen = b.is_open, s.suspend_message = b.next_open_time_note || b.suspend_message, s.im = h.status < 0 ? {} : {
          businessId: h.business_id,
          areaCode: h.area_code
        }, s.vip = {
          isBigShop: f
        }, s.cryptoInfo = w;
        var I = o[m.type] || "th0";
        s.theme = {
          themeClass: I,
          isFantasy: "th11" === I,
          themeFetched: !0,
          type: m.type,
          colors: m.colors || i.b
        }, s.shopMetaInfo = y;
        var P = Object(_.setChainStoreInfo)({
          shopMetaInfo: y,
          shopInfo: c,
          isFromBlankPageOrOnLaunch: n
        });

        function k() {
          d.a.trigger("app:multi:store:resolved", {
            store: u,
            fromCache: r
          }), d.a.trigger("app:chain:store:resolved", {
            shopMetaInfo: y,
            shopInfo: c,
            isFromBlankPageOrOnLaunch: n
          }), d.a.trigger("shop:copyright:resolved", s.copyright), d.a.trigger("shop:nav:resolved", s.nav), d.a.trigger("shop:config:resolved", s.config), d.a.trigger("shop:im:resolved", s.config), d.a.trigger("shop:vip:resolved", s.vip), d.a.trigger("shop:theme:resolved", s.theme), d.a.trigger("shop:info:change", s), d.a.trigger("shop:info:fetch:success")
        }
        return x(Object(a.a)({}, s, P)), Object(_.getEnterCacheConfig)("isProxyUpdateKdtId") ? Object(_.cacheProxyUpdateEmit)(k) : k(), s
      })(t, n),
      onKdtIdChange: (e, t) => function(e, t) {
        e = +e, Object(v.b)(), e && (e !== +t ? (Object(v.c)(e), w("UPDATE_SHOP_DATA", {
          kdtId: e
        }), s.f({
          kdtId: e
        }), d.a.trigger("shop:kdt_id:change", e)) : s.f({
          offlineId: H(),
          kdtId: e
        }))
      }(e, t)
    });
    var E = e => {
        if (!e) return {};
        if (!O.x) return e;
        var t = Object(_.getEnterCacheConfig)("tabbarNavCacheMap");
        return Object(_.forceUseHqTabbar)() && (e.list = l.a.toSnakeCase(t[Object(h.e)()].navList)), e
      },
      A = T("theme"),
      C = T("vip"),
      D = T("config"),
      M = T("copyright"),
      N = function() {
        var e = Object(r.a)(function*() {
          var e = yield T("nav");
          return E(e)
        });
        return function() {
          return e.apply(this, arguments)
        }
      }(),
      L = () => {
        var {
          nav: e
        } = S.shop;
        return E(e)
      };

    function U(e, t) {
      return void 0 === t && (t = {}), new Promise(n => {
        if (Object(c.d)(t)) n(e.shop);
        else if (Object(c.c)(t)) {
          var {
            needEnterShop: r
          } = Object(b.j)(t);
          Object(y.j)("getShopInfo").then(t => {
            t && r ? getApp().once("app:chainstore:kdtid:update", () => n(e.shop)) : n(e.shop)
          })
        } else n(e.shop)
      })
    }
    var R = () => new Promise(e => {
      var {
        shopMetaInfo: t,
        hasBase: n
      } = S.shop || {};
      n ? e(U(S, t)) : d.a.once("shop:info:fetch:success", () => {
        var {
          shopMetaInfo: t
        } = S.shop || {};
        e(U(S, t))
      })
    });

    function B() {
      return new Promise(e => {
        R().then(t => {
          1 != +Object(u.a)(t, "shopMetaInfo.shop_role") ? e(t) : getApp().once("app:chainstore:kdtid:update", () => {
            e(S.shop)
          })
        })
      })
    }

    function F() {
      return Object(p.a)(S.shop) ? {
        base: {},
        security: {},
        nav: {}
      } : S.shop
    }

    function q() {
      return Object(u.a)(S, "shop.config", {})
    }

    function H() {
      return Object(h.d)() || Object(u.a)(S, "shop.offlineId", "")
    }

    function z() {
      return Object(u.a)(S, "shop.offlineSeparatePrice", 0)
    }

    function G() {}

    function W() {
      return null
    }
    var K = () => S.shop.cryptoInfo || {}
  },
  Zf9w: function(e, t, n) {
    n.d(t, "m", function() {
      return c
    }), n.d(t, "g", function() {
      return l
    }), n.d(t, "e", function() {
      return u
    }), n.d(t, "f", function() {
      return d
    }), n.d(t, "d", function() {
      return p
    }), n.d(t, "i", function() {
      return f
    }), n.d(t, "j", function() {
      return g
    }), n.d(t, "l", function() {
      return v
    }), n.d(t, "b", function() {
      return h
    }), n.d(t, "c", function() {
      return m
    }), n.d(t, "h", function() {
      return y
    }), n.d(t, "k", function() {
      return x
    }), n.d(t, "n", function() {
      return k
    }), n.d(t, "a", function() {
      return E
    });
    var r, a = n("9ZMt"),
      i = n("MLLI"),
      o = a.default.getEnv(),
      s = {};

    function c() {
      var e, t;
      if (s.scene) return s.scene;
      var n = (null == (e = a.default.$native) ? void 0 : e.getEnterOptionsSync) || (null == (t = a.default.$native) ? void 0 : t.getLaunchOptionsSync),
        {
          scene: r
        } = n ? n() : {};
      return s.scene = r, s.scene
    }

    function u() {
      var e = c();
      return [1177, 1176, 1175, 1195, 1208].indexOf(e) > -1
    }

    function d() {
      var e = c();
      return Promise.resolve([1177, 1176, 1175, 1195, 1208].indexOf(e) > -1)
    }

    function l() {
      if ("weapp" === o) {
        var {
          statusBarHeight: e,
          platform: t
        } = Object(i.b)();
        return (0 === e || u()) && /(ios|android|devtools)/i.test(t)
      }
      return !1
    }

    function p() {
      return 1195 === c()
    }

    function h() {
      return 1177 === c()
    }

    function f() {
      var e = c();
      return 1177 === e || 1176 === e
    }

    function g() {
      return 1208 === c()
    }

    function v(e) {
      var t = c(),
        {
          from_source: n
        } = e;
      return (l() || [1177, 1176, 1175, 1195, 1208].includes(t)) && "wechatChannel" === n
    }

    function m() {
      return !0
    }

    function y(e) {
      return new Promise(t => t("TRUE" === (null == e ? void 0 : e.TRADE_MODULE_ORDER) || d()))
    }
    null == (r = a.default.$native) || null == r.onAppHide || r.onAppHide(() => {
      s = {}
    });
    var b, _ = n("eijD"),
      O = n("US/N"),
      S = () => Object(O.default)({
        path: "/wscwxvideo/trade-module/weapp-trade-module-status.json"
      }),
      w = n("8mzt");

    function I(e, t) {
      t = t || {}, w.a.log({
        appName: "wsc",
        logIndex: "new_wsc_weapp_log",
        level: "info",
        name: "[weapp]-wxvideo-" + e,
        message: JSON.stringify(t)
      })
    }
    var P = {};

    function k(e) {
      return j.apply(this, arguments)
    }

    function j() {
      return (j = Object(_.a)(function*(e) {
        if (void 0 === e && (e = !0), e && null != P.tradeModuleStatus) return P.tradeModuleStatus;
        var t = yield S();
        return P.tradeModuleStatus = t, P.tradeModuleStatus
      })).apply(this, arguments)
    }

    function x() {
      return T.apply(this, arguments)
    }

    function T() {
      return (T = Object(_.a)(function*() {
        return (yield k()).WEAPP_TRADE_MODULE_V3_IS_ENABLE
      })).apply(this, arguments)
    }
    null == (b = a.default.$native) || null == b.onAppHide || b.onAppHide(() => {
      P = {}
    });
    var E = () => new Promise((e, t) => {
      var n, r;
      return null != (n = P) && n.checkBeforeAddOrderResult ? e(null == (r = P) ? void 0 : r.checkBeforeAddOrderResult) : a.default.$native.checkBeforeAddOrder ? a.default.$native.checkBeforeAddOrder({
        success(t) {
          var n;
          P.checkBeforeAddOrderResult = null == t ? void 0 : t.data, e(null == t ? void 0 : t.data), null != t && null != (n = t.data) && n.traceId || I("交易组件下单--调用wx.checkBeforeAddOrder未返回traceId参数", t)
        },
        fail(e) {
          I("交易组件下单--调用wx.checkBeforeAddOrder失败", e), t(e)
        }
      }) : (I("交易组件下单--基础库版本不够无法调用wx.checkBeforeAddOrder", {}), void t({}))
    })
  },
  aBIM: function(e, t, n) {
    var r = n("zcvR");
    e.exports = function(e) {
      return r(this, e).get(e)
    }
  },
  aCmY: function(e, t) {
    e.exports = function(e, t, n, r) {
      for (var a = e.length, i = n + (r ? 1 : -1); r ? i-- : ++i < a;)
        if (t(e[i], i, e)) return i;
      return -1
    }
  },
  b2OE: function(e, t, n) {
    var r = n("LSEb")(n("s3UK"), "Set");
    e.exports = r
  },
  b4An: function(e, t, n) {
    n.d(t, "a", function() {
      return c
    });
    var r = n("qYBx"),
      a = {
        base: "https://www.youzan.com",
        bbs: "https://bbs.youzan.com",
        cdn: "https://b.yzcdn.cn/",
        wap: "https://h5.youzan.com/v2",
        imgqn: "https://img01.yzcdn.cn",
        uic: "https://uic.youzan.com",
        trade: "https://trade.koudaitong.com",
        trade_youzan: "https://trade.youzan.com",
        im: "https://b-im.youzan.com",
        www: "https://www.youzan.com/v2",
        store: "https://store.youzan.com",
        shop: "http://detail.youzan.com",
        shop_wap: "https://shop255245.youzan.com/v2",
        h5: "https://h5.youzan.com",
        passport: "https://passport.youzan.com",
        renzheng: "https://renzheng.youzan.com/online",
        finance: "https://finance.youzan.com",
        guang: "https://h5.guang.com"
      },
      i = /(h5|wap)(\.youzan\.com)/,
      o = /(shop[^.]+)(\.youzan\.com)/,
      s = [40461684];

    function c(e, t, n, c) {
      void 0 === c && (c = {});
      var u = r.f.full(e, t, a) || "",
        d = c,
        l = d.notReplaceDomain,
        p = void 0 !== l && l,
        h = d.ignoreReplaceCheck,
        f = void 0 !== h && h,
        g = d.staticPageReg,
        v = void 0 === g ? [] : g,
        m = d.staticPageUrlMiddle,
        y = void 0 === m ? "" : m;
      return f || ("undefined" != typeof window && r.a.ua.isMiniProgramWebview() && (p = !0), s.indexOf(+n) > -1 && (p = !0)), +n >= 0 && "string" == typeof u && !p && (u = u.replace(i, function(e, t, r) {
        return "shop" + (Number(n) + 192168) + r
      })), y && o.test(u) && v.some(function(e) {
        return (t = e, "[object RegExp]" === Object.prototype.toString.call(t) ? t : new RegExp(t)).test(u);
        var t
      }) && (u = u.replace(o, function(e, t, n) {
        return "" + t + y + n
      })), u
    }
  },
  bAmA: function(e, t, n) {
    var r = n("i/JN");
    e.exports = function(e) {
      return e && e.length ? r(e) : []
    }
  },
  bBDD: function(e, t, n) {
    n.d(t, "h", function() {
      return h
    }), n.d(t, "g", function() {
      return f
    }), n.d(t, "f", function() {
      return g
    }), n.d(t, "e", function() {
      return v
    }), n.d(t, "i", function() {
      return m
    }), n.d(t, "a", function() {
      return y
    }), n.d(t, "b", function() {
      return b
    }), n.d(t, "c", function() {
      return _
    }), n.d(t, "j", function() {
      return S
    }), n.d(t, "d", function() {
      return P
    });
    var r = n("Fcif"),
      a = n("eijD"),
      i = n("taYb"),
      o = n("YehF"),
      s = n("qHGj"),
      c = n("2xJD"),
      u = n("lRMv"),
      d = n("POYE"),
      l = n("wYCQ");

    function p(e) {
      return Object(o.c)(e) && !Object(o.d)(e)
    }

    function h(e) {
      return Object(o.c)(e) || Object(s.d)(e)
    }

    function f(e) {
      return !Object(s.d)(e)
    }

    function g(e) {
      return Object(c.a)(e)
    }

    function v(e) {
      return Object(s.b)(e)
    }

    function m(e) {
      return 1 === e.shop_role
    }

    function y() {
      var e = getCurrentPages();
      if (0 === e.length) {
        var {
          path: t,
          query: n
        } = wx.getLaunchOptionsSync();
        return {
          path: t,
          query: n
        }
      }
      var {
        route: r,
        options: a
      } = e[e.length - 1];
      return "pages/common/blank-page/index" === r ? (getApp().globalData || {}).enterShopInfo : {
        path: r,
        query: a
      }
    }

    function b() {
      var {
        path: e = "",
        query: t = ""
      } = y() || {}, n = i.a.toCamelCase(t);
      return {
        route: e.replace(/^pages(-|\/)/, "packages/"),
        camelQuery: n,
        path: e,
        query: t
      }
    }

    function _() {
      return O.apply(this, arguments)
    }

    function O() {
      return (O = Object(a.a)(function*() {
        return (yield Object(u.k)())[u.b.ignoreConfig] || {}
      })).apply(this, arguments)
    }

    function S(e, t, n) {
      return w.apply(this, arguments)
    }

    function w() {
      return (w = Object(a.a)(function*(e, t, n) {
        void 0 === e && (e = {}), void 0 === n && (n = !1);
        var {
          route: r,
          camelQuery: a,
          path: i,
          query: o
        } = b(), s = yield _(), {
          globalEnterStoreIgnore: c = []
        } = s, u = c.includes(t || r), d = a.umpAlias && a.umpType;
        return {
          needEnterShop: (n || !Object(l.g)("proxyWxJumpPadding")) && !p(e) && f(e) && !u && !d,
          path: i,
          query: o,
          route: r
        }
      })).apply(this, arguments)
    }

    function I() {
      return (I = Object(a.a)(function*(e) {
        try {
          var [t, n] = yield Promise.all([_(), Object(u.k)()]), {
            webviewList: a = [],
            designEnterStoreIgnore: i = [],
            onRouteIgnoreCheck: o = []
          } = t;
          if (n[u.b.loadIdCheck]) {
            var s = {
              routeIgnore: o.includes(e),
              loadIdCheck: !0
            };
            return a.includes(e) ? Object(r.a)({}, s, {
              type: "webview"
            }) : i.includes(e) ? Object(r.a)({}, s, {
              type: "design"
            }) : s
          }
        } catch (e) {}
        return {
          loadIdCheck: !1
        }
      })).apply(this, arguments)
    }

    function P(e) {
      return function(e) {
        return I.apply(this, arguments)
      }(e).then(t => !!t.type && (d.a.blockEnterShopType = t.type, Object(u.f)({
        text: "[wx] 阻塞" + t.type + "页面触发全局进店, url:" + e
      }), "webview" === t.type && u.t.set("_is_init_enter_shop_", !0), !0))
    }
  },
  bE7W: function(e, t) {
    var n = Function.prototype.toString;
    e.exports = function(e) {
      if (null != e) {
        try {
          return n.call(e)
        } catch (e) {}
        try {
          return e + ""
        } catch (e) {}
      }
      return ""
    }
  },
  bIWf: function(e, t, n) {
    n.d(t, "a", function() {
      return i
    });
    var r = n("OhE7"),
      a = n.n(r);
    class i {
      constructor(e) {
        this.ctx = e.ctx
      }
    }
    i.components = {
      SubscribeGuide: a()
    }
  },
  bSoS: function(e, t, n) {
    n.d(t, "a", function() {
      return i
    });
    var r = n("AYC7"),
      a = n.n(r);
    class i {}
    i.widgets = {
      Main: a.a
    }
  },
  bdYe: function(e, t, n) {
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.default = void 0;
    var r, a = (r = n("ZxyO")) && r.__esModule ? r : {
      default: r
    };
    var i = function(e, t) {
      return e = new a.default(e), t = new a.default(t), parseFloat(e.div(t).toFixed())
    };
    t.default = i, e.exports = t.default
  },
  bmpj: function(e, t, n) {
    n.d(t, "a", function() {
      return s
    });
    var r = n("bb6g"),
      a = n("9ZMt"),
      i = n("qYBx");

    function o() {
      var e, t = "",
        n = a.default.getApp() || {};
      if (!(t = (a.default.getAppOptions() || {}).query.from_params || "") && (null === (e = n.logger) || void 0 === e ? void 0 : e.getLogParams)) {
        var r = n.logger.getLogParams();
        t = r && i.d.get(r, "context.from_params") || ""
      }
      return t || (t = n.globalData && n.globalData.from_params || ""), t
    }

    function s(e) {
      return Object(r.__assign)(Object(r.__assign)(Object(r.__assign)({}, e), (i = (null === (n = (t = a.default.$native).getStorageSync) || void 0 === n ? void 0 : n.call(t, "_customer_latitude_cache")) || {}).lat && i.lng ? {
        lat: String(i.lat),
        lng: String(i.lng)
      } : {}), {
        from_params: o()
      });
      var t, n, i
    }
  },
  bs6A: function(e, t, n) {
    t.a = {
      mounted() {
        this._initPullDownRefresh()
      },
      methods: {
        _getCurrentPage() {
          if ("function" == typeof getCurrentPages) {
            var e = getCurrentPages();
            return e && e.length ? e[e.length - 1] || {} : null
          }
        },
        _initPullDownRefresh() {
          var e = this._getCurrentPage();
          if (e && e.onPullDownRefresh) {
            if ("function" != typeof this.onPullDownRefresh) return;
            var t = e.onPullDownRefresh;
            e.onPullDownRefresh = n => {
              t.call(e, n), this.onPullDownRefresh()
            }
          }
        }
      }
    }
  },
  "bsB/": function(e, t, n) {
    n.d(t, "b", function() {
      return d
    }), n.d(t, "a", function() {
      return l
    }), n.d(t, "e", function() {
      return p
    }), n.d(t, "c", function() {
      return h
    }), n.d(t, "d", function() {
      return f
    });
    var r = n("Fcif"),
      a = n("hHpg"),
      i = n("KDJo"),
      o = n("eCH0"),
      s = getApp(),
      c = "/wscump/common/",
      u = function(e) {
        return s.request({
          path: c + "get-template.json",
          query: {
            scene: e
          }
        })
      };

    function d(e) {
      var {
        templateIdList: t = [],
        scene: n = "",
        needAlwaysToast: r = !1,
        successCallBack: i = null,
        rejectCallBack: u = null,
        failCallBack: d = null,
        showCallBack: l = null,
        closeCallBack: p = null,
        logParam: h = {}
      } = e, f = Object.keys(h).length > 0;
      t.length > 0 ? Object(o.d)({
        templates: t,
        onSuccess: e => {
          for (var r in e)
            if ("errMsg" !== r && "reject" === e[r]) {
              u && u();
              break
            } var {
            acceptTemplateIdList: o = []
          } = function(e) {
            void 0 === e && (e = {});
            var t = [];
            try {
              for (var n in e) "errMsg" !== n && "accept" === e[n] && t.push(n)
            } catch (e) {}
            return {
              acceptTemplateIdList: t
            }
          }(e);
          if (o.length) return f && s.logger.log({
              et: "click",
              ei: "allow_msg_subscribe",
              en: "允许订阅小程序消息",
              params: h
            }),
            function(e) {
              var {
                scene: t = "",
                templateIdList: n = []
              } = e;
              return s.request({
                path: c + "subscription-callback.json",
                query: {
                  scene: t,
                  templateIdList: JSON.stringify(n)
                }
              })
            }({
              scene: n,
              templateIdList: o
            }).then(function(e) {
              var {
                value: t = !1
              } = void 0 === e ? {} : e;
              t ? i && i(o) : Object(a.a)("授权失败")
            }).catch(() => {
              Object(a.a)("授权失败")
            });
          wx.getSetting({
            withSubscriptions: !0
          }).then(e => {
            var {
              mainSwitch: n,
              itemSettings: r
            } = e.subscriptionsSetting, a = t.every(e => r && "reject" === r[e.templateId]);
            !n || a ? d && d() : p && p()
          }).catch(() => {
            p && p()
          }), f && s.logger.log({
            et: "click",
            ei: "refuse_msg_subscribe",
            en: "拒绝订阅小程序消息",
            params: h
          })
        },
        onFail: () => {
          d && d()
        },
        onShowTips: () => {
          r && Object(a.a)({
            duration: 3e3,
            position: "top",
            message: "勾选“总是保持以上选择”后，点击“允许”，即可长期获取签到提醒。"
          }), f && s.logger.log({
            et: "click",
            ei: "msg_subscribe_view",
            en: "小程序订阅消息弹窗曝光",
            params: h
          }), l && l()
        },
        onCloseTips: () => {
          p && p()
        }
      }) : p && p()
    }

    function l(e) {
      var {
        scene: t = "",
        pageId: n = null
      } = e;
      return Promise.all([s.request({
        path: "/wscdeco/im/common/is-shop-not-in-black-list.json"
      }), s.getShopInfo()]).then(e => {
        var [{
          value: r
        }, {
          shopInfo: a = {}
        }] = e;
        return Object(i.c)(a) && r && null !== n ? Promise.all([u(t), Object(o.c)(n)]).then(e => {
          var [{
            templateIdList: t = []
          }, {
            templateList: n = []
          }] = e;
          return [...t.map(e => ({
            templateId: e
          })), ...n]
        }) : u(t).then(e => {
          var {
            templateIdList: t
          } = e;
          return t.map(e => ({
            templateId: e
          }))
        })
      })
    }

    function p(e) {
      e.needAlwaysToast && wx.showLoading(), l({
        scene: e.scene,
        pageId: e.pageId
      }).then(t => {
        wx.hideLoading(), d(Object(r.a)({
          templateIdList: t
        }, e))
      }).catch(e => {
        e.msg && wx.showToast({
          title: e.msg,
          icon: "none"
        })
      })
    }

    function h(e) {
      var {
        scene: t = ""
      } = e;
      return new Promise(e => {
        s.request({
          path: c + "is-auth-for-push.json",
          query: {
            scene: t
          }
        }).then(t => {
          t && e(t.value)
        }).catch(e => {
          e && wx.showToast({
            title: e,
            icon: "none"
          })
        })
      })
    }

    function f() {
      return new Promise(e => {
        s.request({
          path: c + "is-subscription-msg-available.json"
        }).then(t => {
          t && e(t.value)
        }).catch(e => {
          e && wx.showToast({
            title: e,
            icon: "none"
          })
        })
      })
    }
  },
  c4zd: function(e, t, n) {
    n.d(t, "a", function() {
      return a
    }), n.d(t, "b", function() {
      return i
    });
    var r = n("US/N");

    function a(e) {
      return void 0 === e && (e = "cashier"),
        function(t) {
          var n = t.origin,
            a = t.method,
            i = t.path,
            o = t.data,
            s = {
              origin: n || e,
              method: a,
              path: "/" + i,
              data: o,
              withCredentials: !0
            };
          return Object(r.default)(s)
        }
    }
    var i = a()
  },
  caDb: function(e, t, n) {
    n.d(t, "a", function() {
      return i
    });
    var r = n("nSh/"),
      a = n.n(r);
    class i {
      constructor(e) {
        this.ctx = e.ctx
      }
    }
    i.widgets = {
      Widget: a()
    }
  },
  cm7J: function(e, t, n) {
    var r = n("dIZa");
    e.exports = function(e, t) {
      for (var n = e.length; n--;)
        if (r(e[n][0], t)) return n;
      return -1
    }
  },
  d6Vr: function(e, t, n) {
    var r = n("s3UK")["__core-js_shared__"];
    e.exports = r
  },
  dAi7: function(e, t, n) {
    n.d(t, "a", function() {
      return s
    }), n.d(t, "b", function() {
      return u
    }), n.d(t, "d", function() {
      return d
    }), n.d(t, "c", function() {
      return h
    });
    var r = n("Fcif"),
      a = n("jA1y"),
      i = n("z24M"),
      o = n("J8k1");

    function s(e) {
      return a.c({
        path: "/wscuser/membercenter/init-data.json",
        method: "get",
        data: Object(r.a)({}, e, {
          currentKdtId: e.onlineKdtId,
          needConsumptionAboveCoupon: 1
        }),
        query: {
          kdt_id: e.kdtId
        }
      })
    }

    function c(e) {
      return a.c({
        path: "/wscuser/membercenter/global.json",
        method: "get",
        data: Object(r.a)({}, e, {
          adaptorComponents: o.a.join(",")
        }),
        query: {
          kdt_id: e.kdtId
        }
      })
    }

    function u(e) {
      return Promise.all([c(e), s(e)])
    }

    function d(e) {
      var t = Object(i.a)() || {};
      if (!e.isChainStoreSync() && t.kdtId && t.userVersion) return u({
        kdtId: t.kdtId,
        version: t.userVersion,
        onlineKdtId: t.kdtId
      })
    }

    function l(e) {
      return a.c({
        path: "/wscuser/membercenter/user-center-config.json",
        method: "get",
        data: {
          kdtId: e,
          platform: 2
        }
      })
    }

    function p(e) {
      return a.c({
        path: "/wscuser/membercenter/contact.json",
        method: "get",
        data: {
          kdt_id: e
        }
      })
    }

    function h(e) {
      if (e.isChainStoreSync()) return e.waitForEnterShop().then(() => function(e) {
        var {
          kdtId: t
        } = e;
        return Promise.all([a.c({
          path: "/retail/h5/user/memberInfo.json",
          method: "get"
        }), l(t), p(t)])
      }({
        kdtId: e.getKdtId()
      }))
    }
  },
  dIZa: function(e, t) {
    e.exports = function(e, t) {
      return e === t || e != e && t != t
    }
  },
  dO0t: function(e, t) {},
  dWkE: function(e, t, n) {
    var r = n("umDW");
    n.d(t, "b", function() {
      return r.b
    }), t.a = r.a
  },
  dsC0: function(e, t, n) {
    n.d(t, "e", function() {
      return f
    }), n.d(t, "h", function() {
      return v
    }), n.d(t, "n", function() {
      return m
    }), n.d(t, "g", function() {
      return _
    }), n.d(t, "b", function() {
      return O
    }), n.d(t, "o", function() {
      return w
    }), n.d(t, "i", function() {
      return I
    }), n.d(t, "k", function() {
      return k.a
    }), n.d(t, "l", function() {
      return P
    }), n.d(t, "d", function() {
      return C
    }), n.d(t, "c", function() {
      return D
    }), n.d(t, "p", function() {
      return L
    }), n.d(t, "m", function() {
      return U
    }), n.d(t, "q", function() {
      return R
    }), n.d(t, "a", function() {
      return B
    }), n.d(t, "j", function() {
      return F
    }), n.d(t, "f", function() {
      return q
    });
    var r = n("Fcif"),
      a = n("9DIb"),
      i = n.n(a),
      o = n("mQXz"),
      s = n.n(o),
      c = n("w2Y9"),
      u = n.n(c),
      d = n("KEq0"),
      l = n.n(d),
      p = n("NHEX"),
      h = n.n(p);

    function f(e, t) {
      var {
        type: n,
        goods: a
      } = e, {
        umpAlias: o = "",
        umpType: c = "",
        activityId: d = "",
        activityType: p = ""
      } = i()(t), f = s()(t, ["ump_alias", "ump_type", "access_token", "app_id", "prefetchKey"]), g = function(e) {
        return void 0 === e && (e = {}), u.a.add("/pages/goods/detail/index", e)
      }(Object(r.a)({}, f, {
        umpType: c,
        umpAlias: o,
        activityId: d,
        activityType: p,
        alias: a.alias
      })), v = h()(e, "fastbuyFeature.isFastBuy", !1), m = h()(e, "fastbuyFeature.showGoodsShopSign", !0);
      return Object(r.a)({}, a, {
        type: n,
        path: g,
        picture: l()(h()(a, "pictures.0.url", "")),
        pictures: a.pictures || [],
        video: a.video || {},
        explainVideo: a.explainVideo || {},
        sellPoint: a.sellPoint || "",
        isOutlink: 0 === a.buyWay,
        outlinkUrl: a.buyUrl,
        isHaitao: a.isHaitao || a.isHaiTao,
        isMedicine: a.isOtcCategory || a.isPrescriptionCategory,
        isFastBuy: v,
        verifyStatus: a.verifyStatus || 2,
        showGoodsShopSign: m
      })
    }
    var g = n("Nvad");

    function v(e, t, n, r) {
      void 0 === e && (e = {}), void 0 === t && (t = {}), void 0 === n && (n = {}), void 0 === r && (r = {});
      var a = t.goods,
        {
          minPrice: i,
          maxPrice: o,
          stockNum: s,
          hideStock: c,
          oldMaxPrice: u,
          oldMinPrice: d,
          priceTags: l = []
        } = a,
        {
          showPrice: p,
          showOldPrice: h
        } = Object(g.a)(a),
        {
          goods: f
        } = e,
        {
          isDeposit: v,
          isEnd: m
        } = n.presale || {},
        {
          soldNum: y
        } = r,
        b = "";
      return v && (b = "定金"), {
        showPriceBlock: !0,
        showOriginPrice: !0,
        showBanner: v && !m,
        price: p,
        oldPrice: h,
        priceLabel: b,
        oldMinPrice: d,
        oldMaxPrice: u,
        minPrice: i,
        maxPrice: o,
        stockNum: s,
        hideStock: c,
        soldNum: null === y ? f.soldNum : y,
        tags: [...l]
      }
    }

    function m(e, t) {
      return Object(r.a)({}, e, {
        name: e.shopName,
        city: e.city || "",
        province: e.province || "",
        address: e.address || "",
        rootKdtId: t.rootKdtId,
        phone: e.phone || ""
      })
    }
    var y = n("zMoS"),
      b = n("9ZMt");

    function _(e, t) {
      var {
        goods: n,
        shopConfig: r
      } = e, {
        goodsExtra: a = {},
        pageFeature: i = {},
        soldNum: o = null
      } = t, {
        hasPurchaseRight: s = !0,
        isGoodsCollected: c = !1
      } = a, u = Object(y.a)(n, "refundModel", {}), d = b.default.getEnv(), l = "weapp" === d || "web" === d, {
        localDelivery: p = 1,
        goodsSupplyReminder: h
      } = r, f = Object(y.a)(n, "ecardExtra", null), g = Object(y.a)(n, "periodBuyExtra", null), {
        itemType: v,
        isDisplay: m
      } = n, _ = !0;
      (0 == +p || f || g || n.isHaitao || +n.isInstallment || n.isCatering) && (_ = !1);
      var O = l && 1 == +h && "FENXIAO" !== v && 1 === m,
        S = {
          isGoodsCollected: c,
          isSupportFCode: Object(y.a)(i, "extra.supportFCode", !1),
          limitBuy: !s,
          supportItemProps: _,
          refund: {
            isSupport: Object(y.a)(u, "isSupportRefund", 1),
            type: u.refundType,
            interval: u.periodMillSeconds
          },
          showStockLackReminder: O
        };
      return o && (S.soldNum = o), S
    }

    function O(e, t) {
      var {
        delivery: n
      } = e, {
        customerPostageFree: a
      } = t, i = Object(y.a)(n, "postage.desc", "");
      return a && a.isCustomerPostage && (i = "免运费"), Object(r.a)({}, n, {
        postage: i,
        expressFee: Object(y.a)(n, "express.desc", ""),
        localDeliveryFee: Object(y.a)(n, "localDelivery.desc", ""),
        expressPayMode: Object(y.a)(n, "postage.expressPayMode")
      })
    }
    var S = e => JSON.parse(e || "{}");

    function w(e) {
      var t = "web" === b.default.getEnv(),
        n = Object(r.a)({}, e, {
          isShowBuyBtn: e.showBuyBtn,
          isYouzanSecured: e.isYouzanSecured,
          isSecuredTransactions: e.isSecuredTransactions,
          showRecommendGoods: t ? e.goodsRecommend : e.goodsRecommendForWeapp,
          showBuyRecord: e.buyRecord,
          showCustomerReviews: e.customerReviews,
          evaluationMemberLabel: e.evaluationMemberLabel || 0,
          showBuyerShows: Boolean(e.buyerShow),
          showPersonalRecommendGoods: e.personalRecommendWindowGoods,
          isSimplifiedWsc: e.isSimplifiedWsc,
          supportFreightInsurance: e.freightInsurance,
          hideShoppingCart: e.hideShoppingCart,
          hasPhysicalStore: e.teamPhysical,
          isWeixinPayOrigin: 1 == +e.weixinPayOrigin,
          principalCertType: e.principalCertType || 0,
          brandCertType: e.brandCertType || 0,
          goodsDetailBuyRecord: e.goodsDetailBuyRecord || "",
          goodsDetailBuyRecordMin: +e.goodsDetailBuyRecordMin,
          goodsDetailSales: e.goodsDetailSales || null,
          buyBtnConfig: e.buyBtnConfig || null,
          webImInGoodsConfig: e.webImInGoodsConfig || null,
          shopOperateDurationYears: e.shopOperateDurationYears || 0,
          shopOperateDurationTagSwitch: e.shopOperateDurationTagSwitch || 0,
          weixinTransactionSecured: e.weixinTransactionSecured,
          goodsSalesReminder: e.goodsSalesReminder,
          goodsSupplyReminder: e.goodsSupplyReminder,
          goodsVideoDanmakuSwitch: 1 == +e.goodsVideoDanmakuSwitch
        }),
        a = S(e.goodsTradeMarquee);
      a.type = (a.type || "").split(",").filter(e => !["", void 0].includes(e)).map(e => +e), n.goodsTradeMarquee = a;
      var {
        open: i
      } = S(e.goodsRecommendForYou);
      n.openRecommendForYou = i;
      var {
        default: o,
        label: s
      } = S(e.customCartName);
      return n.showDefaultCartText = !+o, n.cartText = (s || "").substr(0, 4), n.goodsFavorableRate = S(e.goodsFavorableRate), n.pointsConfig = S(e.scrmCreditDiyName), n
    }

    function I(e) {
      var {
        goods: t,
        shopConfig: n
      } = e, r = Object(y.a)(t, "youzanGuaranteeModel", {});
      return {
        on: r.youzanGuarantee || 0,
        style: n.guaranteeShowStyleType,
        desc: r.guaranteedComponents || []
      }
    }

    function P(e) {
      var {
        pageFeature: t = {}
      } = e;
      return Object(r.a)({}, t, {
        showBuyBtn: t.showBuyButton,
        showCartBtn: t.showCartButton,
        showPointsBtn: t.showPointsButton,
        showForbidBuyBtn: t.showForbidBuyButton,
        showGiftBtn: t.showGiftButton,
        showMiniShopBtn: t.showMiniShopButton,
        showMiniCartBtn: t.showMiniCartButton,
        showMiniPointsBtn: t.showMiniPointsButton,
        showShareBtn: t.showShareButton,
        showImBtn: t.showImButton
      })
    }
    var k = n("X3j9"),
      j = n("q29p"),
      x = n.n(j);

    function T(e, t) {
      var {
        haoTaoItemExtra: n = {},
        isHaitao: a
      } = e, i = h()(t, "haitaoTariffAmount", "");
      if (a && n) {
        var o = i || n.tariffAmount;
        return Object(r.a)({}, n, {
          tariffAmount: o
        })
      }
      return null
    }

    function E(e, t) {
      var n = e.ecardExtra || {};
      if (!e.ecardExtra) return null;
      var {
        ecardRules: a,
        ecardInstructions: i
      } = function(e, t) {
        var {
          validityType: n,
          effectiveType: r,
          effectiveDelayHours: a,
          itemValidityDay: i,
          itemValidityStart: o,
          itemValidityEnd: s,
          holidaysAvailable: c,
          instructions: u
        } = e || {}, d = [], l = ["永久有效", i + "天内使用有效", x()(o, "YYYY年MM月DD日") + " - " + x()(s, "YYYY年MM月DD日") + "内使用有效", "在所选使用日期内当天有效"];
        d.push(l[n] || "");
        var p = ["立即生效", a + "小时后生效", "次日生效"];
        d.push(p[r] ? "购买后" + p[r] : ""), d.push("节假日" + (0 === c ? "不" : "") + "可用");
        var {
          isSupport: h,
          type: f,
          interval: g
        } = t.refund;
        if (h) {
          if (0 === f) d.push("未使用卡券随时可申请退款");
          else if (1 === f) {
            var v = Math.floor(g / 24 / 60 / 60 / 1e3),
              m = g % 864e5,
              y = Math.floor(m / 60 / 60 / 1e3),
              b = v ? v + "天" : "",
              _ = y ? y + "小时" : "";
            d.push("未使用卡券在过期前" + (b + _) + "随时可以申请退款")
          }
        } else d.push("不支持申请退款");
        u && d.push(u || "");
        var O = [...d],
          S = O.pop(),
          w = O.join("，");
        return {
          ecardRules: d,
          ecardInstructions: S ? [w, "其他说明：" + S] : [w]
        }
      }(n, t), {
        itemPreOrderTime: o
      } = n, s = (o || "").split("-"), c = s[0] || "", u = s[1] || "";
      return Object(r.a)({}, n, {
        isPriceCalendar: 3 === n.validityType,
        ecardRules: a,
        ecardInstructions: i,
        itemPreOrderTxt: c ? (0 == +c ? "当天" : "前" + c + "天") + " " + u : "",
        itemPreOrderModel: c ? {
          day: c,
          time: u
        } : null
      })
    }

    function A(e) {
      var t = h()(e, "periodBuyExtra", null);
      return t ? {
        description: t.description,
        period: t.period,
        deliveryTimeList: t.deliverTime,
        periodSku: t.skuExtras,
        deliverTimeId: "1"
      } : null
    }

    function C(e, t, n, r) {
      var {
        goods: a
      } = e, {
        goodsExtra: i,
        marketing: o,
        ump: s = {}
      } = t, {
        outerActivities: c = []
      } = o || {};
      return {
        presale: s.presale,
        waitToSold: s.waitToSold,
        haitao: T(a, i),
        virtualCoupon: a.couponGoodsExtraModel,
        virtualTicket: E(a, n),
        periodbuy: A(a),
        enjoyBuy: c.length
      }
    }

    function D(e) {
      var {
        displayData: t = {},
        platform: n = "",
        pageParams: a,
        platformSpecialUI: i
      } = e, {
        dangerousPlatform: o = [],
        hideRankingPlatform: s = [],
        hideShareIcon: c = []
      } = i || {};
      return Object(r.a)({}, t, {
        platform: n,
        showSku: "true" === a.showsku,
        isDangerous: o.indexOf(n) > -1,
        hideShareIcon: c.indexOf(n) > -1,
        hideRanking: s.indexOf(n) > -1,
        isMobile: !0
      })
    }
    var M = n("NW04"),
      N = Object(M.c)({
        "price-font-family": "Avenir"
      });

    function L(e) {
      var {
        theme: t
      } = e;
      return t ? {
        themeColors: t.colors,
        themeVars: Object(M.c)(t.colors),
        pageVars: N
      } : {
        themeColors: null,
        themeVars: M.a,
        pageVars: N
      }
    }

    function U(e) {
      var {
        goods: t,
        shopConfig: n
      } = e;
      return {
        cashOnDelivery: !t.isVirtual && +n.codPay,
        isInstallment: t.isInstallment,
        isFreeInterest: t.freeInterest,
        isPriorUse: n.priorUse
      }
    }

    function R(e) {
      if (void 0 === e && (e = []), !Array.isArray(e) || !e.length) return {};
      var t = {};
      return e.forEach(e => {
        t[e.type] = e
      }), t
    }

    function B(e) {
      void 0 === e && (e = {});
      var {
        appConfig: t
      } = e, n = {
        appConfig: null,
        appEngineConfig: null
      };
      return t && (n.appConfig = t), n
    }

    function F(e) {
      var {
        logistics: t
      } = e || {};
      return (t || {}).logisticsTimelinessInfo || {}
    }

    function q(e) {
      var {
        goods: t
      } = e, {
        comboDetailModel: n,
        comboMark: a = {}
      } = t;
      return a.isCombo ? Object(r.a)({}, n, a) : {
        isCombo: !1
      }
    }
  },
  dst7: function(e, t, n) {
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.default = void 0;
    var r = function() {
      var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
      return ([].slice.call(arguments, 1) || []).forEach(function(t) {
        if (t)
          for (var n in t) e[n] = t[n]
      }), e
    };
    t.default = r, e.exports = t.default
  },
  e2Yn: function(e, t, n) {
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.default = void 0;
    var r = function(e) {
      for (var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 2, n = 0, r = 0; r < e.length; r++) {
        var a = e.charCodeAt(r);
        a >= 1 && a <= 126 || a >= 65376 && a <= 65439 ? n++ : n += t
      }
      return n
    };
    t.default = r, e.exports = t.default
  },
  eCH0: function(e, t, n) {
    n.d(t, "a", function() {
      return r
    }), n.d(t, "c", function() {
      return i
    }), n.d(t, "b", function() {
      return o
    }), n.d(t, "d", function() {
      return h
    }), n.d(t, "e", function() {
      return y
    });
    var r = {
        SIGN: "RLQD_NEW",
        COUPON: "coupon_notice_scene"
      },
      a = n("jA1y");

    function i(e) {
      return Object(a.c)({
        path: "/v3/message/wechat-push/query-wechat-subscribe-result.json",
        method: "POST",
        withCredentials: !0,
        data: {
          pageId: e
        }
      })
    }

    function o(e) {
      return Object(a.c)({
        path: "/v3/message/wechat-push/template.json",
        method: "GET",
        withCredentials: !0,
        data: {
          scene: e
        }
      })
    }
    var s = n("Fcif"),
      c = n("+I+c"),
      u = n("QxN7"),
      d = ["level", "detail"],
      l = getApp();

    function p(e, t, n) {
      var r = n || {},
        {
          level: a,
          detail: i
        } = r,
        o = Object(c.a)(r, d),
        p = Object(u.getErrorMsg)(t);
      l.logger.skynetLog({
        message: "[消息订阅] " + e + (p ? "：" + p : ""),
        level: a,
        extra: {
          bizName: "消息订阅",
          logName: e,
          logMsg: p
        },
        detail: Object(s.a)({}, t, o, i)
      })
    }

    function h(e) {
      var t, n, r;
      void 0 === e && (e = {});
      var i = null == (t = e.templates) || null == (n = t.map(e => "string" == typeof e ? {
          templateId: e
        } : e)) ? void 0 : n.filter(e => null == e ? void 0 : e.templateId),
        o = i.map(e => e.templateId).slice(0, 3);
      if (!wx.canIUse("requestSubscribeMessage")) return p("功能不支持"), null == e.onFail || e.onFail({
        errCode: "UNSUPPORTED",
        errMsg: "当前小程序基础库不支持订阅"
      }), void(null == e.onComplete || e.onComplete());
      if (!Array.isArray(o) || !o.length) return p("模板为空"), null == e.onFail || e.onFail({
        errCode: "NO_TEMPLATE",
        errMsg: "templates列表为空"
      }), void(null == e.onComplete || e.onComplete());
      var s = setTimeout(() => {
          null == e.onShowTips || e.onShowTips()
        }, 800),
        c = getApp();
      p("开始订阅", {
        templateIds: o
      }), null == (r = c.logger) || r.log({
        et: "view",
        ei: "show_subscribe",
        en: "唤起授权",
        params: {
          component: "subscribe_push"
        }
      });
      var {
        subscribePos: u,
        subscribeSource: d,
        deliveryWay: l
      } = e.onSelfLog || {};
      wx.requestSubscribeMessage({
        tmplIds: o,
        success: t => {
          p("订阅成功", {
            res: t,
            templateIds: o
          });
          var n, r, s = o.some(e => "accept" === t[e]);
          if (s) {
            e.noToast || wx.showToast({
              title: "订阅通知成功",
              icon: "success"
            });
            var h, f = i.filter(e => "accept" === t[null == e ? void 0 : e.templateId] && (null == e ? void 0 : e.subscribeTemplateId));
            if (f.length) n = f, Object(a.c)({
              path: "/v3/message/wechat-push/subscribe-callback.json",
              method: "POST",
              withCredentials: !0,
              data: {
                templateList: n
              }
            }), null == (h = c.logger) || h.log({
              et: "click",
              ei: "click_subscribe",
              en: "点击订阅",
              params: {
                component: "subscribe_push"
              }
            })
          }
          u && (null == (r = c.logger) || r.log({
            et: "click",
            ei: s ? "accept_msg_subscribe" : "reject_msg_subscribe",
            en: s ? "接受授权订阅小程序消息" : "拒绝授权订阅小程序消息",
            params: {
              subscribe_pos: u,
              subscribe_source: d,
              delivery_way: l
            }
          }));
          null == e.onSuccess || e.onSuccess(t)
        },
        fail: t => {
          p("订阅失败", t, {
            templateIds: o
          });
          var n, r = "订阅微信通知失败 " + (t.errCode || "");
          t.errMsg && t.errMsg.indexOf("switched off") > -1 ? r = "请在小程序设置中允许订阅消息" : 20001 === (null == t ? void 0 : t.errCode) && (p("删除失效模板", t, {
            templateIds: o
          }), n = o, Object(a.c)({
            path: "/v3/message/wechat-push/callback-remove-unused-template.json",
            method: "POST",
            withCredentials: !0,
            data: {
              wechatTemplateIdList: n
            }
          })), e.noToast || wx.showToast({
            title: r,
            icon: "none"
          }), null == e.onFail || e.onFail(t)
        },
        complete: () => {
          s && clearTimeout(s), null == e.onCloseTips || e.onCloseTips(), null == e.onComplete || e.onComplete()
        }
      })
    }
    var f = n("KDJo"),
      g = n("2xJD"),
      v = n("YehF"),
      m = getApp();

    function y(e) {
      var t, {
          pageId: n,
          scene: r,
          subscribePage: i,
          subscribeType: o,
          authorizationType: s,
          windowType: c,
          options: u,
          supportRetail: d = !0,
          noToast: l = !0
        } = e,
        {
          next: y
        } = u || {},
        b = m.globalData.hasSubscribedByApp || 0;
      if (b && b >= 3) return p("次数超过阈值", {
        times: b
      }), void y();
      Object(a.c)({
        path: "/wscdeco/shop/get-shop-meta-info-by-kdtId.json",
        data: t
      }).then(e => {
        var t = Object(f.e)(e) && !Object(g.c)(e),
          _ = d && (Object(v.f)(e) || Object(v.g)(e) || Object(v.b)(e));
        return t || _ ? (n || (t && (n = 3), _ && (n = 5)), n && r ? Object(a.c)({
          path: "/wscdeco/im/common/is-subscription-in-white-list.json",
          data: {}
        }).then(e => {
          if (!!!e.value) return p("非白名单"), void y();
          var t = {
            pageId: n,
            scene: r,
            windowType: c,
            authorizationType: s
          };
          return function(e) {
            return void 0 === e && (e = {}), Object(a.c)({
              path: "/wscdeco/im/common/get-template.json",
              data: e
            })
          }(t).catch(e => (p("查询模板失败", e, {
            level: "warn",
            detail: {
              params: t
            }
          }), [])).then(e => Array.isArray(e) && e.length ? new Promise((t, r) => {
            var {
              onSuccess: d,
              onFail: p,
              onComplete: f,
              onShowTips: g,
              onCloseTips: v
            } = u;
            h({
              pageId: n,
              templates: e,
              noToast: l,
              onSuccess: e => {
                var n, r;
                (d && d(), !0 === Object.values(e).some(e => "accept" === e)) ? ((e => {
                  Object(a.c)({
                    path: "/wscdeco/im/common/add-authorize-log.json",
                    data: e,
                    method: "post"
                  })
                })({
                  authorizationType: s
                }), null == (n = m.logger) || n.log({
                  et: "click",
                  ei: "allow_msg_subscribe",
                  en: "允许订阅小程序消息",
                  params: {
                    subscribe_page: i,
                    subscribe_type: o
                  }
                }), t()) : null == (r = m.logger) || r.log({
                  et: "click",
                  ei: "refuse_msg_subscribe",
                  en: "拒绝订阅小程序消息",
                  params: {
                    subscribe_page: i,
                    subscribe_type: o
                  }
                })
              },
              onFail: e => {
                p && p(), r(e)
              },
              onComplete: () => {
                f && f()
              },
              onShowTips: () => {
                var e, t;
                g && g(), t = b + 1, m.globalData.hasSubscribedByApp = t, (e => {
                  Object(a.c)({
                    path: "/wscdeco/im/common/add-user-behavior.json",
                    data: e,
                    method: "post"
                  })
                })({
                  windowType: c
                }), null == (e = m.logger) || e.log({
                  et: "click",
                  ei: "msg_subscribe_view",
                  en: "小程序订阅消息弹窗曝光",
                  params: {
                    subscribe_page: i,
                    subscribe_type: o
                  }
                })
              },
              onCloseTips: () => {
                v && v()
              }
            })
          }) : (p("模板为空"), void y()))
        }) : (p("参数不正确"), void y())) : (p("店铺类型不支持"), void y())
      }).catch(e => {
        throw p("未知异常", e), e
      })
    }
  },
  eWMZ: function(e, t, n) {
    n.d(t, "a", function() {
      return r
    }), n.d(t, "b", function() {
      return a
    }), n.d(t, "c", function() {
      return i
    });
    var r = "+86",
      a = 1e4,
      i = "https://www.youzan.com/intro/rule/detail?alias=14nykbyyf&pageType=rules"
  },
  exMg: function(e, t, n) {
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.default = void 0;
    var r, a = (r = n("ZxyO")) && r.__esModule ? r : {
      default: r
    };
    var i = function(e, t) {
      return e = new a.default(e), t = new a.default(t), parseFloat(e.times(t).toFixed())
    };
    t.default = i, e.exports = t.default
  },
  f6Yk: function(e, t, n) {
    n.d(t, "a", function() {
      return f
    }), n.d(t, "b", function() {
      return p
    });
    var r = n("Fcif"),
      a = n("9ZMt"),
      i = (n("cWxX"), n("s0cO")),
      o = n.n(i),
      s = n("GFyo"),
      c = n("Sipi"),
      u = "cookie",
      d = "query",
      l = {
        atr_uuid: {
          transType: u
        },
        yzk_ex: {
          transType: u
        },
        pageType: {
          transType: d
        },
        tui_platform: {
          transType: d
        },
        tui_click: {
          transType: d
        },
        wecom_uuid: {
          transType: d
        },
        fromSource: {
          transType: d
        }
      };

    function p(e) {
      return void 0 === e && (e = {}), Object(s.c)("cpsGrowthCookie").then(t => {
        var {
          data: n
        } = t;
        return Object(s.g)("cpsGrowthCookie", Object(r.a)({}, n || {}, e))
      })
    }

    function h(e) {
      var t = "";
      switch (l[e] ? l[e].transType : null) {
        case u:
          t = function(e) {
            var t = "";
            try {
              var {
                [e]: n
              } = Object(c.b)("cpsGrowthCookie") || {};
              t = n || ""
            } catch (e) {}
            return t
          }(e);
          break;
        case d:
          t = function(e) {
            var {
              query: t
            } = a.default.getAppOptions() || {};
            return t[e] || ""
          }(e);
      }
      return t
    }

    function f(e) {
      var t = {},
        n = e || l;
      return Object.keys(n).forEach(e => {
        t[o()(e)] = h(e)
      }), t
    }
  },
  "f9/1": function(e, t, n) {
    n.r(t), n.d(t, "setSwitchShopRangeCache", function() {
      return _.s
    }), n.d(t, "forceUseHqTabbar", function() {
      return _.e
    }), n.d(t, "forceShowHome", function() {
      return _.d
    }), n.d(t, "getEnterCacheConfig", function() {
      return _.g
    }), n.d(t, "getWxPage", function() {
      return _.i
    }), n.d(t, "setEnterCacheConfig", function() {
      return _.q
    }), n.d(t, "cacheProxyUpdateEmit", function() {
      return _.a
    }), n.d(t, "isHqEnterShop", function() {
      return _.k
    }), n.d(t, "isWxProxyDone", function() {
      return _.n
    }), n.d(t, "isProxyUpdateKdtId", function() {
      return _.m
    }), n.d(t, "notUpdateKdtIdInChain", function() {
      return _.o
    }), n.d(t, "featureJump", function() {
      return w
    }), n.d(t, "getCurrentPageOption", function() {
      return x
    }), n.d(t, "updateChainStoreInfo", function() {
      return T
    }), n.d(t, "isChainStoreSync", function() {
      return E
    }), n.d(t, "setChainStoreInfo", function() {
      return A
    }), n.d(t, "getHQKdtId", function() {
      return D
    }), n.d(t, "isShopHq", function() {
      return M
    }), n.d(t, "setIsReLaunch", function() {
      return N
    }), n.d(t, "checkReLaunchShopSelect", function() {
      return L
    }), n.d(t, "redirectToMemberShopWhenAuthorize", function() {
      return R
    }), n.d(t, "createChainStoreEvent", function() {
      return B
    }), n.d(t, "checkSpecialShopDZ", function() {
      return F
    });
    var r = n("Fcif"),
      a = n("DXKY"),
      i = n("Tewj"),
      o = n("zMoS"),
      s = n("2wjL"),
      c = n("jA1y"),
      u = n("qHGj"),
      d = n("YehF"),
      l = n("2xJD"),
      p = n("UyoQ"),
      h = n("lRMv"),
      f = n("sbwY"),
      g = n("ZIOE"),
      v = n("rBuL"),
      m = n("/duV"),
      y = n("bBDD"),
      b = n("SVbq"),
      _ = n("wYCQ"),
      O = (n("+I+c"), n("eijD"), n("xih6"), n("POYE"), "/pages/home/feature/index"),
      S = function(e, t) {
        return void 0 === t && (t = "navigateTo"), Object(b.o)({
          redirectUrl: encodeURIComponent(e)
        }, {
          redirectType: t
        })
      };

    function w(e) {
      void 0 === e && (e = {});
      var {
        enterConfig: t,
        bannerIdOpt: n,
        alias: a,
        callback: i,
        jumpType: o = "navigateTo"
      } = e, {
        mode: c,
        kdtIdList: u
      } = t;
      if (!t) return !1;
      if (c && Object(b.C)({
          sceneId: b.e.FEATURE,
          sceneSource: "CUSTOM"
        }), c === b.f.Enter) {
        var d = Object(r.a)({
          alias: a
        }, n);
        return d.shopAutoEnter = 4, i && i(), wx[o]({
          url: s.a.add(O, d)
        }), !0
      }
      if (c === b.f.Assign && +u[0] != +Object(m.c)()) return i && i(), wx[o]({
        url: s.a.add(O, Object(r.a)({
          alias: a,
          kdtId: u[0]
        }, n))
      }), !0;
      if (c === b.f.Select) {
        var l = Object(_.s)({
            enterConfig: t
          }),
          p = Object(r.a)({
            alias: a
          }, n, {
            enterShopId: l
          });
        return i && i(), S(s.a.add(O, p), o), !0
      }
    }
    var {
      state: I
    } = f.a, P = !1, k = "packages", j = () => {
      var e = "/" + k + "/home/dashboard/index",
        t = getCurrentPages();
      if (t.length > 0) {
        var {
          route: n,
          options: r = {}
        } = t[t.length - 1];
        e = s.a.add("/" + n, r)
      }
      return encodeURIComponent(e)
    };

    function x() {
      var e = getCurrentPages();
      if (0 === e.length) {
        var {
          path: t,
          query: n
        } = wx.getLaunchOptionsSync();
        return {
          path: t,
          query: n
        }
      }
      var {
        route: r,
        options: a
      } = e[e.length - 1];
      return "pages/common/blank-page/index" === r ? (getApp().globalData || {}).enterShopInfo : {
        path: r,
        query: a
      }
    }

    function T() {
      var {
        shopMetaInfo: e = {}
      } = I.shop;
      Object(y.g)(e) && (Object(y.i)(e) || getApp().trigger("app:chainstore:kdtid:update", {
        kdtId: e.kdt_id
      }), getApp().trigger("app:chainstore:change:update", {
        kdtId: e.kdt_id
      }))
    }

    function E() {
      var {
        shopMetaInfo: e = {}
      } = I.shop;
      return Object.keys(e).length ? Object(u.b)(e) : Object(h.r)()
    }

    function A(e) {
      var {
        shopMetaInfo: t,
        shopInfo: n
      } = e, a = {
        isRetailShop: Object(d.e)(t),
        isRootShop: Object(y.i)(t),
        isChainStore: Object(y.e)(t),
        isMultiOnlineShop: Object(y.g)(t),
        isEduChainStore: Object(y.f)(t),
        isOnline: t.online_shop_open,
        isEduShop: Object(l.c)(t),
        isUnitedHqStore: !1,
        isPureOffineShop: Object(y.h)(t)
      };
      return a.isChainStore && a.isOnline && Object(_.q)("lastOnlineKdtId", t.kdt_id), {
        chainStoreInfo: Object(r.a)({
          showBtn: !!t.show_retail_switch_btn,
          showUserLocation: t.show_user_location,
          onlineShopVisitModel: t.online_shop_visit_model,
          logo: n.logo,
          name: t.shop_name,
          rootKdtId: t.root_kdt_id
        }, a),
        shopType: a
      }
    }

    function C(e) {
      var {
        shopMetaInfo: t,
        isFromBlankPageOrOnLaunch: n
      } = e, {
        route: a
      } = Object(y.b)();
      Promise.all([Object(y.j)(t), Object(y.d)(a)]).then(e => {
        var [t, a] = e, {
          needEnterShop: i,
          path: o,
          query: c
        } = t;
        if (i) {
          if (a) return;
          var u = s.a.add("/" + o, c);
          Object(h.g)(n ? Object(r.a)({}, c, {
            redirectUrl: u,
            logTag: "global"
          }) : {
            redirectUrl: u,
            logTag: "global"
          }).then(e => {
            e && getApp().dontUpdateKdtIdByServer()
          })
        } else Object(h.j)("updateChainStoreInfo").then(e => {
          if (e) {
            var {
              shopMetaInfo: t = {},
              shopInfo: n
            } = getApp().getShopInfoSync();
            T()
          }
        })
      }).catch(() => {
        Object(h.f)({
          err: "[wx] 全局进店处理失败"
        })
      })
    }

    function D() {
      var {
        shop: e
      } = I;
      return Object(o.a)(e, "chainStoreInfo.rootKdtId") || e.kdt_id || Object(m.e)() || null
    }

    function M() {
      return !!Object(h.r)() && Object(m.c)() === D()
    }

    function N(e) {
      P = e
    }

    function L() {
      P && (P = !0, wx.reLaunch({
        url: "/" + k + "/shop-select/chain-store/shopselect/index?dbKey=location&from=new&redirectUrl=" + j()
      }))
    }
    var U = "";

    function R(e) {
      var t = +Object(v.b)(); - 1 !== [90957577, 54731005, 42865412].indexOf(t) && e.on("app:token:success", e => {
        var {
          yzUserId: t
        } = e;
        if (U || (U = t), U !== t) {
          U = t;
          var n = +Object(g.getKdtId)();
          c.c({
            path: "/wscshop/weapp/getMemberStore.json"
          }).then(e => {
            var {
              kdtId: t,
              shopMetaInfo: r
            } = e;
            if (t && +t !== n && Object(p.a)(r)) {
              var i = decodeURIComponent(j());
              i = s.a.add(i, {
                subKdtId: t
              }), i = s.a.remove(i, "shopAutoEnter"), Object(g.updateKdtId)(t, !1, {
                mark: "[chain-store.js]redirectToMemberShopWhenAuthorize"
              }), a.a.once("shop:info:fetch:success", () => {
                wx.reLaunch({
                  url: i
                })
              }, this)
            }
          })
        }
      })
    }

    function B() {
      a.a.off("app:chain:store:resolved", C), a.a.on("app:chain:store:resolved", C)
    }

    function F() {
      return [19171281].includes(+Object(m.c)())
    }
    i.default.on(b.d.a_enter_c, T), i.default.on(b.d.shop_c, g.fetchLaunchJsonCallback)
  },
  fChk: function(e, t, n) {
    n.d(t, "a", function() {
      return a
    });
    var r = n("h+Rz");

    function a(e) {
      return r.a.pageScrollTo(e)
    }
  },
  fNGs: function(e, t, n) {
    var r = n("Qcor"),
      a = n.n(r);
    class i {
      constructor(e) {
        this.ctx = e.ctx
      }
    }
    i.widgets = {
      Main: a()
    }, t.a = i
  },
  fZnw: function(e, t, n) {
    n.d(t, "a", function() {
      return a
    }), n.d(t, "c", function() {
      return i
    }), n.d(t, "b", function() {
      return o
    });
    var r = n("Fcif");

    function a(e) {
      return function(t) {
        return new Promise((n, a) => {
          e.call(e, Object(r.a)({}, t, {
            success: n,
            fail: a
          }))
        })
      }
    }
    var i = e => function(t, n) {
      return void 0 === n && (n = {}), new Promise((a, i) => e(Object(r.a)({}, t, {
        success: a,
        fail: i
      }), n))
    };

    function o(e, t) {
      if (void 0 === t && (t = {}), !/^wx\./.test(e)) throw new Error("promisifyCall 仅支持 wx 的接口调用");
      var n = e.substr(3);
      if (!wx[n]) throw new Error("不存在 " + e + " API");
      return new Promise((e, a) => {
        wx[n](Object(r.a)({}, t, {
          success(n) {
            t.success && t.success(n), t.complete && t.complete(n), e(n)
          },
          fail(e) {
            t.fail && t.fail(e), t.complete && t.complete(e), a(e)
          }
        }))
      })
    }
  },
  fmSs: function(e, t, n) {
    var r;
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.default = void 0;
    var a = ((r = n("URSu")) && r.__esModule ? r : {
      default: r
    }).default;
    t.default = a, e.exports = t.default
  },
  gBZH: function(e, t, n) {
    n.d(t, "a", function() {
      return r
    });
    var r = {
      ADD_CART: "add_shopping_car",
      NORMAL_BUY: "click_buy_now",
      GROUP_BUY: "together_group_purchase",
      GET_COUPON: "get_coupon",
      GET_DISCOUNT: "get_discount_code",
      SIGN_IN: "click_sign_in",
      POINTS_BUY: "points_exchange"
    }
  },
  gKCo: function(e, t, n) {
    n.d(t, "a", function() {
      return i
    }), n.d(t, "b", function() {
      return o
    });
    var r = n("Fcif"),
      a = n("dsC0");

    function i(e, t) {
      var {
        goodsData: n,
        pageParams: i,
        shopData: o,
        shopMetaInfo: s,
        staticConfig: c
      } = e, u = Object(a.g)(n, {}), {
        price: d
      } = Object(a.h)(n, t), l = Object.freeze({
        showPriceBlock: !0,
        showOriginPrice: !0,
        price: d
      });
      return {
        goodsBaseInfo: Object(r.a)({
          firstRenderPriceInfo: l
        }, Object(a.e)(n, i)),
        shopConfig: Object(a.o)(n.shopConfig),
        shopData: o,
        alias: n.alias,
        kdtId: o.kdtId,
        distribution: Object(a.b)(n, {}),
        goodsMetaInfo: u,
        staticConfig: c,
        shopBaseInfo: Object(a.n)(Object(r.a)({}, n.shop, o), s)
      }
    }

    function o(e) {
      var {
        staticData: t,
        asyncGoodsData: n,
        goodsSkuData: i,
        activitySkuData: o,
        serverStatus: s
      } = e, {
        goodsData: c,
        shopMetaInfo: u,
        offlineData: d,
        shopData: l,
        isOwnerTeam: p = !1,
        featureSwitch: h = {},
        apolloSwitch: f
      } = t, {
        mpAccount: g
      } = l, v = {
        buyLimitType: n.buyLimitType,
        bosWorkFlow: n.bosWorkFlow
      }, m = Object(a.g)(c, n), y = Object(a.b)(c, n), b = Object(a.i)(c), _ = (c.goods || {}).youzanGuaranteeModelV2, O = Object(a.l)(n), S = Object(a.q)(c.extendModelList), w = Object(a.k)(d, n, O, i), I = Object(a.d)(c, n, m, s), P = Object(a.h)(c, i, I, n), k = Object(a.c)(t), j = Object(a.p)(t), x = Object(a.m)(c), T = Object(a.a)(t), E = Object(a.j)(n), A = {
        logined: !0,
        isAdmin: p
      };
      return Object(r.a)({
        shopMpInfo: g,
        goodsSkuData: i,
        activitySkuData: o,
        goodsMetaInfo: m,
        goodsPriceInfo: P,
        distribution: y,
        guarantee: b,
        guaranteeData: _,
        pageFeature: O,
        offlineId: w.id || 0,
        multistore: w,
        goodsActivity: I,
        env: k,
        pageSwitch: f
      }, j, {
        payWays: x,
        serverStatus: s,
        buyConfig: v,
        goodsExtendInfo: S,
        physicalStores: n.physicalStores,
        openAppConfig: T,
        userState: A,
        shopMetaInfo: u,
        logisticsTimeliness: E,
        featureSwitch: h
      })
    }
  },
  gNlG: function(e, t, n) {
    var r = n("DXKY"),
      a = n("hTAu");
    t.a = Behavior({
      methods: {
        setPageScrollControlSubscribe(e, t) {
          var n = Object(a.a)();
          return r.a.on("onPageScroll" + n, e, t), n
        },
        delPageScrollControlSubscribe(e, t, n) {
          void 0 === n && (n = Object(a.a)()), r.a.off("onPageScroll" + n, e, t)
        }
      }
    })
  },
  h4Sw: function(e, t, n) {
    t.a = {
      cacheKey: {
        addressDowngrade: "address_downgrade"
      },
      eventKey: {
        selfFetchCity: "self-fetch-city-change",
        addressSelect: "address-select",
        addressDelete: "address-delete",
        addressSave: "address-save",
        couponChange: "order-coupon-change",
        showExpressWay: "show-express-way",
        addressCity: "address-city-change",
        addressMap: "address-map-change",
        showContact: "show-contact",
        showSelfFetchShop: "show-self-fetch-shop",
        showSelfFetchTime: "show-self-fetch-time",
        showTradeRecharge: "show-trade-recharge",
        contactError: "contact-error",
        idcardError: "idcard-error",
        presaleDisagreeToast: "presale-disagree-toast",
        showIdcardPopup: "show-idcard-popup"
      },
      phaseStatus: {
        WAIT_PAY: "待付款",
        WAIT_PAY_START: "未开始",
        PAID: "已付",
        CLOSE: "已关闭",
        SUCCESS: "已完成"
      },
      freightInsuranceTag: {
        NONE: "0",
        SELF: "1",
        FREE: "2"
      },
      groupon: {
        forbidReceive: 0,
        optionalReceive: 1,
        forceReceive: 2
      },
      activityMap: {
        3: "降价拍",
        4: "拼团",
        6: "秒杀",
        8: "赠品",
        10: "会员折扣",
        11: "限时折扣",
        23: "抽奖团",
        24: "换购",
        26: "拼团"
      },
      shopStock: {
        default: 0,
        full: 1,
        none: 2,
        part: 3
      },
      umpBenefitChannelType: {
        subscription: 118,
        wechatWork: 119
      },
      appointmentType: {
        regular: 1,
        instant: 2
      }
    }
  },
  hDMN: function(e, t, n) {
    n.d(t, "a", function() {
      return s
    });
    var r = n("6U3b"),
      a = n.n(r),
      i = n("8S+i"),
      o = n.n(i);
    class s {
      constructor(e) {
        var {
          ctx: t,
          totalPageNum: n,
          useLoadMore: r
        } = e;
        this.ctx = t, this.totalPageNum = n, this.useLoadMore = r
      }
    }
    s.widgets = {
      Main: a(),
      RecommendGoodsTitle: o()
    }
  },
  hTAu: function(e, t, n) {
    function r(e) {
      var t;
      if (e) t = e;
      else {
        var n = getCurrentPages();
        t = n[n.length - 1]
      }
      if (!t.__uniqueKey__) {
        var r = function(e) {
          for (var t = 5381, n = e.length; n;) t = 33 * t ^ e.charCodeAt(--n);
          return t >>> 0
        }(t.route + JSON.stringify(t.options));
        t.__uniqueKey__ = r
      }
      return t.__uniqueKey__
    }
    n.d(t, "a", function() {
      return r
    })
  },
  "i/JN": function(e, t, n) {
    var r = n("GE03"),
      a = n("l3+0"),
      i = n("BAZ7"),
      o = n("+165"),
      s = n("pZIW"),
      c = n("OF9M");
    e.exports = function(e, t, n) {
      var u = -1,
        d = a,
        l = e.length,
        p = !0,
        h = [],
        f = h;
      if (n) p = !1, d = i;
      else if (l >= 200) {
        var g = t ? null : s(e);
        if (g) return c(g);
        p = !1, d = o, f = new r
      } else f = t ? [] : h;
      e: for (; ++u < l;) {
        var v = e[u],
          m = t ? t(v) : v;
        if (v = n || 0 !== v ? v : 0, p && m == m) {
          for (var y = f.length; y--;)
            if (f[y] === m) continue e;
          t && f.push(m), h.push(v)
        } else d(f, m, n) || (f !== h && f.push(m), h.push(v))
      }
      return h
    }
  },
  i0JV: function(e, t, n) {
    var r = n("FEiO"),
      a = Object.prototype.hasOwnProperty;
    e.exports = function(e) {
      var t = this.__data__;
      return r ? void 0 !== t[e] : a.call(t, e)
    }
  },
  iIKO: function(e, t, n) {
    n.d(t, "a", function() {
      return i
    });
    var r = n("ubH4"),
      a = n.n(r);
    class i {
      constructor(e) {
        this.ctx = e.ctx
      }
    }
    i.widgets = {
      Main: a()
    }
  },
  iOq2: function(e, t) {
    e.exports = function() {
      this.__data__ = [], this.size = 0
    }
  },
  jA1y: function(e, t, n) {
    n.d(t, "f", function() {
      return D
    }), n.d(t, "g", function() {
      return M
    }), n.d(t, "e", function() {
      return N
    }), n.d(t, "c", function() {
      return L
    }), n.d(t, "d", function() {
      return U
    }), n.d(t, "b", function() {
      return R
    }), n.d(t, "a", function() {
      return B
    });
    var r = n("eijD"),
      a = n("Fcif"),
      i = n("DXKY"),
      o = n("WLNV"),
      s = n("taYb"),
      c = n("Sd3C"),
      u = n("8B9M"),
      d = n("z24M"),
      l = n("aOlM"),
      p = n("2wjL"),
      h = n("7sy2");

    function f(e, t) {
      return void 0 === t && (t = {}), p.a.add(e, t).replace(/^http(s)?:\/\/[^/]*\//, "storage://").replace(/access_token=([^&]*)/, "").replace(/app_id=([^&]*)/, "")
    }

    function g(e) {
      var t = getApp();
      if (t && t.logger) {
        var n = t.logger.getLogParams(),
          {
            user: r,
            context: a
          } = n,
          i = null == a ? void 0 : a.from_params;
        Object(h.c)(i) && (e.from_params = i), r.uuid && (e.uuid = r.uuid, e.ftime = r.ftime)
      }
    }
    var v = {
        inited: !1,
        cacheKeySet: new Set,
        cacheKeyMap: Object.create(null),
        cacheStorage: {}
      },
      m = Object(l.a)(() => {
        wx.setStorage({
          key: "request-cache",
          data: {
            cacheKeyMap: v.cacheKeyMap,
            cacheStorage: v.cacheStorage
          }
        })
      }, 1e3),
      y = () => {
        if (!v.inited) {
          v.inited = !0;
          var e = Object.create(null);
          try {
            e = wx.getStorageSync("request-cache") || {}
          } catch (e) {}
          var {
            cacheKeyMap: t = {},
            cacheStorage: n = {}
          } = e, r = +new Date / 1e3;
          Object.keys(t).forEach(e => {
            var a = t[e].expireTime - r;
            a > 0 && _(e, n[e], a)
          })
        }
      };

    function b(e) {
      v.cacheKeySet.delete(e), delete v.cacheKeyMap[e], delete v.cacheStorage[e]
    }

    function _(e, t, n) {
      void 0 === n && (n = 86400);
      var r = +new Date / 1e3;
      v.cacheKeySet.add(e), v.cacheKeyMap[e] = {
        key: e,
        createTime: r,
        expireTime: r + n
      }, v.cacheStorage[e] = t
    }

    function O(e, t) {
      var {
        url: n,
        data: r
      } = e;
      void 0 === t && (t = null), y();
      var a = f(n, r);
      if (v.cacheKeySet.has(a)) {
        var i = +new Date / 1e3,
          o = v.cacheStorage[a];
        if (o) {
          if ("number" == typeof t && i < v.cacheKeyMap[a].createTime + t) return S(o);
          if ("number" != typeof t && i < v.cacheKeyMap[a].expireTime) return S(o)
        }
        b(a)
      }
      return null
    }

    function S(e) {
      return "object" == typeof e ? JSON.parse(JSON.stringify(e)) : e
    }
    var w = n("R18q"),
      I = n("US/N"),
      P = {
        config: {},
        method: "GET",
        header: {}
      },
      k = {
        origin: "carmen",
        header: {
          "content-type": "application/x-www-form-urlencoded"
        }
      },
      j = {
        origin: "h5",
        header: {
          "content-type": "application/json"
        }
      },
      x = {
        origin: "baymax",
        header: {
          "content-type": "application/x-www-form-urlencoded"
        }
      },
      T = {
        appId: "",
        version: "",
        kdtId: "",
        offlineId: "",
        accessToken: "",
        sessionId: "",
        hasShop: !1,
        hasToken: !1
      },
      E = [],
      A = [],
      C = [];

    function D(e) {
      var {
        offlineId: t,
        kdtId: n
      } = e;
      "offlineId" in e && (T.offlineId = t), T.hasShop = !0, n && function(e) {
        void 0 === e && (e = ""), T.kdtId = e, T.hasKdtId = !!e;
        for (var t = A.shift(); t;) t(), t = A.shift()
      }(n);
      for (var r = C.shift(); r;) r(), r = C.shift()
    }

    function M(e) {
      e = s.a.toCamelCase(e), T.hasToken = !0, T.tokenTime = Date.now(), T.accessToken = e.accessToken, T.sessionId = e.sessionId;
      for (var t = E.shift(); t;) t(), t = E.shift()
    }

    function N(e) {
      void 0 === e && (e = {}), T = Object(a.a)({}, T, e), Object(I.setRequestDep)(T)
    }

    function L(e) {
      return q(e = Object(o.a)({}, j, e))
    }

    function U(e) {
      return L(e = Object(o.a)({}, e, {
        config: {
          useCdn: !0
        }
      }))
    }

    function R(e) {
      if (!(e = F(e = Object(o.a)({}, k, e))).api) throw new Error("Carmen 接口必须提供 api");
      return e.path = ("/api/oauthentry/" + e.api).replace("//", "/"), q(e)
    }

    function B(e) {
      if (!(e = F(e = Object(o.a)({}, x, e))).api) throw new Error("彩虹桥接口必须提供 api");
      return e.path = ("/api/" + e.api).replace("//", "/"), q(e)
    }

    function F(e) {
      void 0 === e && (e = {});
      var t = t => Object(a.a)({}, e, {
          query: Object(a.a)({}, e.query, {
            retail_source: t
          })
        }),
        n = (Object(u.a)() || {}).globalData || {},
        r = Object(d.a)("userVersion");
      switch (n.scene) {
        case 1:
          return t("MINAPP-SCAN-" + (r = r || "3.8.0"));
        case 2:
          return t("MINAPP-FREE-" + (r = r || "3.12.0"));
        case 3:
          return t("MINAPP-SHELF-" + (r = r || "1.0.0"));
        default:
          return e;
      }
    }

    function q(e) {
      return e = Object(o.a)({}, P, e), new Promise((t, n) => {
        var {
          success: r,
          fail: a,
          complete: i
        } = e;
        e.success = e => {
          try {
            r ? r(e) && t(e) : t(e), i && i(e)
          } catch (e) {}
        }, e.fail = e => {
          a ? a(e) && n(e) : n(e), i && i(e)
        }, G(e.config, () => function(e) {
          return z.apply(this, arguments)
        }(e))
      })
    }

    function H(e) {
      return (t, n) => new Promise((t, n) => {
        var r = Object(u.a)(),
          i = r && r.globalData && r.globalData.enableHttp2;
        wx.request(Object(a.a)({}, e, {
          success: e => t(e),
          fail: e => n(e),
          enableHttp2: i,
          complete: t => {
            try {
              w.a.captureXhr({
                statusCode: t.statusCode || 0,
                method: e.method,
                url: e.url,
                params: e.data
              })
            } catch (e) {
              var n = Object(u.a)();
              n.logger && n.logger.appError({
                name: "hummer_sdk_error",
                message: e.message,
                detail: {}
              })
            }
          }
        }))
      }).catch(function(e, t, n) {
        return t => {
          var r = t.res || t.message || t || {},
            a = ("carmen" === e.origin ? r.error_response : r) || {};
          if (i.a.trigger("request:api:fail", {
              requestOptions: e,
              response: a
            }), n) {
            var o = a.errMsg || a.msg || a.message || "接口调用失败，请稍后重试";
            e.fail({
              code: a.code || -9999,
              msg: o,
              res: a
            })
          }
          return Promise.reject("请求失败")
        }
      }(e, 0, n)).then(function(e, t, n) {
        return r => {
          var o = function(e, t) {
              var n = t;
              if ("string" === e.dataType && "string" == typeof t) try {
                n = JSON.parse(t)
              } catch (e) {
                var r = t.toString().replace(/[\u0000-\u001f\u007f-\u009f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g, "");
                try {
                  n = JSON.parse(r)
                } catch (e) {}
              }
              return n
            }(e, r.data),
            s = {
              code: r.code || -9999,
              msg: r.errMsg || r.msg || "服务器请求失败，请稍后重试",
              res: o
            };
          if (200 !== r.statusCode) return i.a.trigger("request:server:fail", {
            requestOptions: e,
            response: r
          }), n && e.fail(s), Promise.reject(s);
          r = o;
          var c = "carmen" === e.origin,
            u = "baymax" === e.origin;
          if (function(e) {
              void 0 === e && (e = {});
              var t = 0 === e.code,
                n = !0 === e.success;
              return void 0 !== e.response && !e.error_response || t || n
            }(r)) {
            var d = c ? r.response : r.data;
            "object" != typeof d && (d = {
              value: d
            }), t && function(e, t) {
              var {
                url: n,
                data: r,
                expire: a = 86400
              } = e;
              y();
              var i = f(n, r);
              if (v.cacheKeySet.size > 25) {
                var o = [...v.cacheKeySet].map(e => v.cacheKeyMap[e]);
                o.sort((e, t) => e.expireTime - t.expireTime);
                for (var s = v.cacheKeySet.size - 25, c = +new Date / 1e3, u = 0; u < o.length; u += 1) {
                  var d = o[u];
                  if (b(d.key), u > s && d.expireTime > c) break
                }
              }
              _(i, S(t), a), m()
            }(Object(a.a)({}, e, {
              expire: e._options.config.expire
            }), d);
            try {
              n && e.success(d)
            } catch (t) {
              i.a.trigger("request:business:fail", {
                requestOptions: e,
                response: r,
                error: t
              })
            }
            return d
          }
          return c && (r = r.error_response), u && (r.gw_err_resp ? ((r = r.gw_err_resp).code = r.err_code, r.msg = r.err_msg) : r.msg = r.message), -1 === r.code || (40010 === r.code || 40009 === r.code) && c || 4205 === r.code ? new Promise((r, a) => {
            function o() {
              n && e.fail(s), a()
            }

            function c() {
              i.a.off("auth:token:fail", o), K(e._options).then(a => {
                var i = H(e = a);
                r(i(t, n))
              })
            }
            if (i.a.once("auth:token:fail", o), T.hasToken && e.requestTime < T.tokenTime) return G(e._options.config, c);
            T.hasToken && (i.a.trigger("auth:login"), T.hasKdtId = !1, T.hasToken = !1, T.hasShop = !1), G(e._options.config, c)
          }).catch(e => {}) : (i.a.trigger("request:code:fail", {
            requestOptions: e,
            response: r
          }), s.code = r.code, s.msg = r.msg, n && e.fail(s), Promise.reject(s))
        }
      }(e, t, n))
    }

    function z() {
      return (z = Object(r.a)(function*(e) {
        void 0 === e && (e = {});
        var t = yield K(e), {
          success: n
        } = e, r = H(t);
        if (e.config || (e.config = {}), e.config.cache) {
          var i = O(t, e.config.expire);
          if (t.method && "GET" !== t.method) return r(!1, !0);
          if (e.config.forceRefreshCache || !i) return r(!0, !0);
          if (i && (i.fromCache = !0), e.config.needRefresh && i) return n(Object(a.a)({}, i, {
            cacheData: {
              refresh: !0,
              refreshPromise: r(!0, !1)
            }
          }));
          n(i)
        } else r(!1, !0)
      })).apply(this, arguments)
    }

    function G(e, t) {
      var n = () => {
          if (!e.skipKdtId && !T.hasKdtId) return W(A, t, e);
          t()
        },
        r = () => {
          if (!e.skipShopInfo && !T.hasShop) return W(C, n, e);
          n()
        },
        a = () => {
          if (!e.skipToken && !T.hasToken) return W(E, r, e);
          r()
        };
      "low" === e.priority ? setTimeout(() => a(), 800) : a()
    }

    function W(e, t, n) {
      void 0 === n && (n = {}), "high" === n.priority ? e.unshift(t) : e.push(t)
    }

    function K(e) {
      var {
        method: t,
        query: i = {},
        path: o,
        success: s,
        fail: d,
        dataType: l = "string"
      } = e, {
        data: p = {},
        origin: h,
        header: f = {}
      } = e, {
        noQuery: v,
        noStoreId: m,
        skipToken: y,
        useCdn: b
      } = e.config;
      if (!h) throw new Error("所有请求必须指定 origin:", o);
      m || (i.store_id = T.offlineId || ""), v || (i.app_id = T.appId, i.kdt_id = i.kdt_id || i.kdtId || T.kdtId || "", i.access_token = T.accessToken || "");
      var _ = {
        is_weapp: 1,
        sid: T.sessionId,
        version: T.version,
        client: "weapp",
        bizEnv: "wsc"
      };
      y && (_.skip_sid = 1), g(_);
      try {
        var O = getApp();
        O && O.globalData && O.globalData.enableCdn && b && (f = Object(a.a)({}, f), delete _.sid, delete _.uuid, delete i.access_token, "h5" === h && (h = "h5m"))
      } catch (e) {}
      try {
        if (/^\/(wscaccount|passport)/.test(o) && !f["page-path"]) {
          var S, w = getCurrentPages(),
            I = null == (S = w[w.length - 1]) ? void 0 : S.route;
          f["page-path"] = I
        }
      } catch (e) {}
      return f["Extra-Data"] = JSON.stringify(_), Object(c.a)({
        origin: h,
        pathname: o,
        query: i
      }).then(function() {
        var a = Object(r.a)(function*(r) {
          var a = Object(u.a)() || {},
            {
              key: i,
              apis: o = []
            } = a.getCryptoInfo() || {},
            [c] = r.split("?");
          if (o.indexOf(c) > -1 && i) {
            var {
              encryptedData: g,
              encryptedRSAKey: v
            } = yield function(e, t) {
              return n.e("packages/async-main/chunk").then(n.t.bind(null, "sbP3", 7)).then(n => {
                var {
                  key: r,
                  iv: a
                } = n.utils.generateKeyAndIv();
                return {
                  encryptedData: n.aes.encrypt({
                    data: JSON.stringify(e),
                    key: r,
                    iv: a
                  }),
                  encryptedRSAKey: n.rsa.encrypt({
                    data: r + ":" + a,
                    publicKey: t
                  })
                }
              })
            }(p, i);
            f["x-auth-token"] = v, p = {
              encryptedData: g
            }
          }
          return {
            origin: h,
            _options: e,
            requestTime: Date.now(),
            url: r,
            data: p,
            header: f,
            method: (t || "GET").toUpperCase(),
            success: s,
            fail: d,
            dataType: l
          }
        });
        return function(e) {
          return a.apply(this, arguments)
        }
      }())
    }
    I.beforeHooks.add(e => {
      var t = JSON.parse(e.header["Extra-Data"] || "{}");
      return g(t), e.header["Extra-Data"] = JSON.stringify(t), !0
    })
  },
  jgJv: function(e, t, n) {
    var r = n("s3UK").Symbol;
    e.exports = r
  },
  kFi4: function(e, t, n) {
    n.d(t, "e", function() {
      return r
    }), n.d(t, "a", function() {
      return a
    }), n.d(t, "f", function() {
      return i
    }), n.d(t, "d", function() {
      return o
    }), n.d(t, "b", function() {
      return s
    }), n.d(t, "c", function() {
      return c
    });
    var r = "#ee0a24",
      a = "#1989fa",
      i = "#fff",
      o = "#07c160",
      s = "#323233",
      c = "#969799"
  },
  kZMD: function(e, t, n) {
    n.d(t, "a", function() {
      return r
    });
    var r = {
      methods: {
        resetTouchStatus() {
          this.direction = "", this.deltaX = 0, this.deltaY = 0, this.offsetX = 0, this.offsetY = 0
        },
        touchStart(e) {
          this.resetTouchStatus();
          var t = e.touches[0];
          this.startX = t.clientX, this.startY = t.clientY
        },
        touchMove(e) {
          var t, n, r = e.touches[0];
          this.deltaX = r.clientX - this.startX, this.deltaY = r.clientY - this.startY, this.offsetX = Math.abs(this.deltaX), this.offsetY = Math.abs(this.deltaY), this.direction = this.direction || (t = this.offsetX, n = this.offsetY, t > n && t > 10 ? "horizontal" : n > t && n > 10 ? "vertical" : "")
        }
      }
    }
  },
  kjqZ: function(e, t, n) {
    var r = n("Pv5g"),
      a = Object(r.a)({
        appName: "wsc",
        logIndex: "new_wsc_weapp_log"
      });
    t.a = a
  },
  kqRw: function(e, t, n) {
    n.d(t, "a", function() {
      return s
    });
    var r = n("RL9e"),
      a = n.n(r),
      i = n("4oC7"),
      o = n.n(i);
    class s {}
    s.widgets = {
      Main: a(),
      NormalCover: o()
    }
  },
  "l3+0": function(e, t, n) {
    var r = n("ofiy");
    e.exports = function(e, t) {
      return !!(null == e ? 0 : e.length) && r(e, t, 0) > -1
    }
  },
  "lOd/": function(e, t, n) {
    n.d(t, "c", function() {
      return s
    }), n.d(t, "b", function() {
      return d
    }), n.d(t, "a", function() {
      return l
    });
    n("Fcif");
    var r = n("zMoS"),
      a = (n("taYb"), n("1Uvd")),
      i = (e, t) => {
        e = Object(e);
        var n = {};
        return Object.keys(e).forEach(r => {
          var a = e[r];
          n[t(a, r, e)] = a
        }), n
      },
      o = (e, t) => {
        for (var n = -1, a = t.length, i = {}; ++n < a;) {
          var o = t[n],
            s = o.split(".").pop(),
            c = Object(r.a)(e, o);
          i[s] = c
        }
        return i
      },
      s = Object(a.a)(8),
      c = {
        ump_seckill: "seckill",
        ump_limitdiscount: "limitdiscount",
        goods_recommend: "recommend",
        cube_v3: "cube",
        image_text_nav: "image_nav",
        coupon: "promocard",
        "knowledge-goods": "knowledge_goods"
      },
      u = {
        goods: "size",
        tag_list_top: ["size"],
        tag_list_left: ["size"],
        recommend: ["goods_components.size"],
        seckill: ["size"],
        groupon: ["size", "groupon_type"],
        limitdiscount: ["layout"],
        shop_banner_weapp: ["store_info_style"],
        image_ad: e => {
          var t = {},
            n = Object(r.a)(e, "show_method", 0);
          if (t.components_style_show_method = n, t.components_style_size = Object(r.a)(e, "size", 0), 7 == +n) {
            var a = Object(r.a)(e, "sub_entry[0].hot_areas", !1);
            t.components_style_is_hotarea = a ? 1 : 0
          }
          return t
        },
        image_nav: ["show_method", "slide_setting"],
        audio: ["style"],
        points_goods: ["size"],
        period_buy: ["size"],
        knowledge_goods: ["knowledge_goods_data.list_mode"],
        goods_new: ["layout"],
        rishiji_ump: e => {
          var t = {};
          return t.components_style_left_type = Object(r.a)(e, "ump_data[0].type", 0), t.components_style_right_type = Object(r.a)(e, "ump_data[1].type", 0), t
        },
        bargain: ["size"],
        social_fans: e => {
          var t = "",
            {
              scene: n,
              subType: r
            } = e || {};
          return 2 == +r ? t = 3 : "WeiXin" === n ? t = 2 : "WeiXinGroup" === n && (t = 1), {
            sub_type: t
          }
        }
      },
      d = e => c[e] || e,
      l = e => {
        var t = d(e.type),
          n = u[t],
          r = {};
        switch (Object.prototype.toString.call(n)) {
          case "[object String]":
            r = i(o(e, [n]), (e, t) => "components_style_" + t);
            break;
          case "[object Array]":
            r = i(o(e, n), (e, t) => "components_style_" + t);
            break;
          case "[object Function]":
            r = n(e);
            break;
          default:
            r = {};
        }
        return r
      }
  },
  lOyf: function(e, t, n) {
    n.d(t, "a", function() {
      return i
    });
    var r = n("9KEa");

    function a() {
      var {
        model: e
      } = r.a;
      return e.replace(/\s/g, "-")
    }

    function i() {
      var e = a() || "";
      return !/iPhone SE/i.test(e) && /iphone-x|iPhone11|iPhone13|iPhone12(?!,8>)|iPhone14|iPhone15|iPhone-14|iPhone-12|iPhone16|iPhone17/i.test(e)
    }
  },
  lRMv: function(e, t, n) {
    n.d(t, "i", function() {
      return v
    }), n.d(t, "e", function() {
      return m
    }), n.d(t, "g", function() {
      return y
    }), n.d(t, "h", function() {
      return b
    }), n.d(t, "q", function() {
      return O
    });
    var r = n("Fcif"),
      a = n("eijD"),
      i = n("+I+c"),
      o = (n("RY8z"), n("2wjL")),
      s = (n("3tyi"), n("Mqxx")),
      c = n("SVbq"),
      u = n("0+Ak"),
      d = n("50K0"),
      l = n("R18q");
    n.d(t, "d", function() {
      return c.g
    }), n.d(t, "t", function() {
      return c.A
    }), n.d(t, "s", function() {
      return c.y
    }), n.d(t, "j", function() {
      return c.n
    }), n.d(t, "r", function() {
      return c.x
    }), n.d(t, "k", function() {
      return c.p
    }), n.d(t, "o", function() {
      return c.u
    }), n.d(t, "l", function() {
      return c.q
    }), n.d(t, "p", function() {
      return c.v
    }), n.d(t, "n", function() {
      return c.s
    }), n.d(t, "f", function() {
      return c.h
    }), n.d(t, "u", function() {
      return c.C
    }), n.d(t, "a", function() {
      return c.a
    }), n.d(t, "c", function() {
      return c.e
    }), n.d(t, "b", function() {
      return c.b
    }), n.d(t, "m", function() {
      return c.r
    });
    var p = ["redirectUrl", "logTag", "enterLogId", "ignoreCheckShopType", "needAuthProtocol", "prefetchStatus", "chainBizType", "prefetchKdtId"],
      h = ["scene"],
      f = ["scene"],
      g = ["scene"],
      v = Object(u.b)({
        type: u.a.DEFAULT
      }),
      m = {
        RUNNING: 2,
        STOP: 3
      };
    var y = (e, t) => {
        var {
          redirectUrl: n,
          logTag: r,
          enterLogId: a = null,
          ignoreCheckShopType: o,
          needAuthProtocol: s,
          prefetchStatus: u,
          chainBizType: d,
          prefetchKdtId: l
        } = e, h = Object(i.a)(e, p);
        return Object(c.i)(h, {
          redirectUrl: n,
          forceKdtId: t,
          logTag: r,
          enterLogId: a,
          prefetchStatus: u,
          prefetchKdtId: l,
          needAuthProtocol: s,
          ignoreCheckShopType: o,
          chainBizType: d
        })
      },
      b = () => {
        getApp().getShopInfo().then(e => {
          var {
            config: t = {}
          } = e, {
            shop_operation_status: n
          } = t; + n === m.STOP && wx.redirectTo({
            url: "/packages/common/out-of-service/index"
          })
        })
      },
      _ = (e, t) => {
        var {
          scene: n
        } = e, r = Object(i.a)(e, h);
        return Object(s.e)({
          key: n,
          kdt_id: t
        }, r).catch(() => e)
      },
      O = function() {
        var e = Object(a.a)(function*(e) {
          var t = Date.now(),
            {
              path: n,
              query: a,
              kdtId: u
            } = e,
            p = (e => {
              if (Object(c.y)(e)) return !0
            })(n);
          if (l.a.mark.start("scan_order_on_launch"), Object(c.w)(Object(r.a)({}, e, {
              getApollo: !p
            })), !Object(c.x)() || !p) return e;
          var h = {},
            v = "";
          try {
            var m = function(e, t) {
                void 0 === e && (e = {});
                var {
                  scene: n
                } = e, r = Object(i.a)(e, f);
                return n ? Promise.race([new Promise(e => {
                  d.a.getMiniappPrefetchRawData("scanCode").then(a => {
                    var {
                      fetchedData: i,
                      fetchedQuery: o
                    } = a || {};
                    i && (null == o ? void 0 : o.scene) === n && e(Object(s.f)(t, r, a))
                  })
                }), _(e, t)]).then(e => e).catch(() => e) : Promise.resolve(e)
              }(a, u),
              {
                status: b,
                uuid: O,
                prefetchKdtId: S = "",
                prefetchData: w
              } = yield Object(c.B)();
            if (["DELAY_ENTER_SHOP", "notChainStore"].includes(b)) return e;
            var {
              scene: I
            } = a, P = Object(i.a)(a, g), {
              scanCode: k
            } = w || {};
            h = I && k && k.data && k.query.scene === I ? Object(s.f)(u, P, k.data) : yield m, v = o.a.add("/" + n, h);
            var {
              kdtId: j,
              homeDetailInfo: x
            } = yield y(Object(r.a)({
              kdt_id: u
            }, h, {
              redirectUrl: v,
              enterLogId: O,
              logTag: "on_launch",
              prefetchStatus: b,
              prefetchKdtId: S,
              chainBizType: c.a.HOME,
              needAuthProtocol: !0,
              ignoreCheckShopType: !0,
              supportPreHomeDetail: 1
            })), T = j || h.kdt_id || u;
            return Object(c.k)("on_launch", Date.now() - t, T), {
              path: n,
              query: h,
              kdtId: T,
              homeDetailInfo: x,
              hadEnterShop: !0
            }
          } catch (e) {
            return Object(c.k)("on_launch_error", e), {
              path: n,
              query: h,
              hadEnterShop: !1
            }
          }
        });
        return function(t) {
          return e.apply(this, arguments)
        }
      }()
  },
  lZq6: function(e, t, n) {
    var r = n("DXKY"),
      a = n("hTAu"),
      i = () => {},
      o = Behavior({
        properties: {
          pageLifetimes: {
            type: Array,
            value: []
          }
        },
        pageLifetimes: {
          show() {
            this.isComponentHide = !1
          },
          hide() {
            this.isComponentHide = !0
          }
        },
        attached() {
          this.pageKey = Object(a.a)(), this.data.pageLifetimes.forEach(e => {
            r.a.on(e + this.pageKey, this[e] || i, this)
          })
        },
        detached() {
          this.data.pageLifetimes.forEach(e => {
            r.a.off(e + this.pageKey, this[e] || i, this)
          })
        }
      });
    t.a = Behavior({
      behaviors: [o],
      properties: {
        componentData: {
          type: Object,
          value: {}
        },
        index: Number,
        kdtId: Number,
        hqKdtId: Number,
        buyerId: Number,
        appId: String,
        offlineId: Number,
        pageRandomNumber: String,
        extraData: {
          type: Object,
          value: {}
        },
        isPlugin: Boolean
      }
    })
  },
  mQt2: function(e, t, n) {
    var r;

    function a() {
      return r || (r = n.e("packages/async-tee/chunk").then(n.bind(null, "JvWB")).then(function(e) {
        return e.default
      }).catch(function(e) {
        throw r = null, e
      })), r
    }
    n.d(t, "a", function() {
      return a
    })
  },
  mgUg: function(e, t, n) {
    n.d(t, "a", function() {
      return r
    });
    var r = {
      DISABLE: "0",
      DEFAULT: "1",
      CUSTOM: "2"
    }
  },
  mjlp: function(e, t, n) {
    n.d(t, "a", function() {
      return g
    });
    var r = n("BfBv"),
      a = n.n(r),
      i = n("I6uD"),
      o = n.n(i),
      s = n("byaO"),
      c = n.n(s),
      u = n("XALw"),
      d = n.n(u),
      l = n("Qqcz"),
      p = n.n(l),
      h = n("vMjE"),
      f = n.n(h);
    class g {
      constructor(e) {
        this.ctx = e.ctx
      }
    }
    g.widgets = {
      GoodsPopupContainer: a(),
      UmpVisitGift: o(),
      GiftPop: c(),
      VisitGift: d(),
      CouponItem: p(),
      CouponList: f()
    }
  },
  nHpP: function(e, t, n) {
    var r, a, i, o;
    ! function(e) {
      e.POPUP_TRIGGER = "user-authorize:popup-trigger", e.POPUP_CALLBACK = "user-authorize:popup-callback", e.USER_INFO_CHANGED = "passport-tee-auth-success"
    }(r || (r = {})),
    function(e) {
      e.POPUP_SHOW = "popup-show"
    }(a || (a = {})),
    function(e) {
      e.POPUP_VISIBLE = "popup-visible", e.SHOW_TOAST = "toast", e.OPEN_WEBVIEW = "on-open-webview", e.POPUP_AUTH_SUCCESS = "success", e.POPUP_AUTH_FAIL = "fail", e.AUTH_POPUP_SHOW = "auth-popup-show", e.AUTH_STATUS_CHANGE = "auth-status-change"
    }(i || (i = {})),
    function(e) {
      e.MAIN = "main", e.POPUP = "popup"
    }(o || (o = {}))
  },
  nKXO: function(e, t, n) {
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.default = void 0;
    var r = m(n("pn6R")),
      a = m(n("Yof+")),
      i = m(n("dst7")),
      o = m(n("yq5R")),
      s = m(n("EzII")),
      c = m(n("NHEX")),
      u = m(n("ajWA")),
      d = m(n("xers")),
      l = m(n("6UHP")),
      p = m(n("3XjN")),
      h = m(n("Y2PO")),
      f = m(n("fmSs")),
      g = m(n("mQXz")),
      v = m(n("5Xe+"));

    function m(e) {
      return e && e.__esModule ? e : {
        default: e
      }
    }
    var y = {
      cloneDeep: r.default,
      each: a.default,
      extend: i.default,
      extractQuery: o.default,
      getConcatData: s.default,
      get: c.default,
      isArray: u.default,
      isEmpty: d.default,
      isPlainObject: l.default,
      maxBy: p.default,
      minBy: h.default,
      merge: f.default,
      omit: g.default,
      pick: v.default
    };
    t.default = y, e.exports = t.default
  },
  "nTO+": function(e, t, n) {
    n.d(t, "a", function() {
      return o
    });
    var r = n("WQRT"),
      a = n("tS13"),
      i = function() {
        return (i = Object.assign || function(e) {
          for (var t, n = 1, r = arguments.length; n < r; n++)
            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
          return e
        }).apply(this, arguments)
      },
      o = function(e) {
        var t = e.skuData,
          n = e.goods,
          o = e.shop,
          s = e.activityInfo,
          c = e.pluginsResult,
          u = e.goodsExtra,
          d = void 0 === u ? {} : u,
          l = e.commonExtra,
          p = void 0 === l ? {} : l,
          h = e.combineGoodsData,
          f = void 0 === h ? {
            flag: "",
            isCombo: !1,
            comboType: 0,
            comboGroupModels: []
          } : h,
          g = c || {},
          v = g.goodsAttributes,
          m = g.periodBuy,
          y = g.ecard,
          b = g.installment,
          _ = g.ladderGroupOn,
          O = f.flag,
          S = f.isCombo,
          w = f.comboType,
          I = f.comboGroupModels,
          P = S && w === a.b.SELF_SELECT_COMBO;
        if (_ && _.scale && (p.ladder_num = _.scale), void 0 !== n.supportUnconditionalReturn && (d.isSevenDayUnconditionalReturn = n.supportUnconditionalReturn), v) {
          var k = [];
          Object.keys(v).forEach(function(e) {
            k = k.concat(v[e])
          }), d.propertyIds = k
        }
        if (m && (d.deliverTime = m.deliverTimeId), y && (t.selectedSkuComb.id = y.dateSkuId, p.card_goods = {
            appointment_time: y.appointmentTime
          }), b) {
          var j = b.rate,
            x = b.period;
          d.isInstallment = !0, p.installmentRate = j, p.selectedInstallmentPeriod = x
        }
        if (S && !P) {
          var T = t.selectedSkuComb.id,
            E = 1 === I.length ? I[0] : I.find(function(e) {
              return e.skuId === T
            });
          if (E) {
            var A = E.comboSubItemModels,
              C = E.goodsComboGroupId,
              D = [];
            if (A.forEach(function(e) {
                if (1 === e.isDisplay) {
                  var t = e.skuRelatedModels,
                    n = e.propModels,
                    r = [];
                  n && n.forEach(function(e) {
                    e.textModels.forEach(function(e) {
                      r.push(e.id)
                    })
                  }), t && t.forEach(function(e) {
                    var t = e.combineNum,
                      n = {
                        goodsId: e.itemId,
                        num: t,
                        price: e.price,
                        skuId: e.skuId,
                        propertyIds: r
                      };
                    r && r.length && (n.propertyIds = r), D.push(n)
                  })
                }
              }), O === a.c.ADD_CART) {
              var M = [{
                id: C,
                subComboList: D
              }];
              d.isCombo = !0, d.comboType = w, d.groupList = JSON.stringify(M)
            }
            O === a.c.BUY && (d.extra = {
              COMBO_INFO: {
                comboType: w,
                subComboList: D.map(function(e) {
                  return e.groupId = C, e
                })
              }
            })
          }
        }
        if (S && P) {
          if (O === a.c.ADD_CART) {
            M = I;
            d.isCombo = !0, d.comboType = w, d.groupList = JSON.stringify(M)
          }
          O === a.c.BUY && (d.extra = {
            COMBO_INFO: {
              comboType: w,
              subComboList: I
            }
          })
        }
        return i(i(i(i({}, Object(r.c)({
          goods: n,
          shop: o
        })), Object(r.d)(t)), s || {}), {
          goodsExtra: d,
          commonExtra: p
        })
      }
  },
  nhoV: function(e, t) {},
  noo5: function(e, t, n) {
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.formatDistance = function(e) {
      if (!e) return "";
      if (e <= 100) return "<100m";
      if (e > 100 && e <= 1e3) return "".concat((0, a.default)(e, 0), "m");
      if (e > 1e3 && e < 1e4) return "".concat((0, a.default)(e / 1e3, 1), "km");
      return ">10km"
    }, t.calculateDistance = function(e, t, n, r) {
      if (!i(e, t) || !i(n, r)) return -1;
      var a = e * Math.PI / 180,
        o = n * Math.PI / 180,
        s = (e - n) * Math.PI / 180,
        c = (t - r) * Math.PI / 180,
        u = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(s / 2), 2) + Math.cos(a) * Math.cos(o) * Math.pow(Math.sin(c / 2), 2)));
      return u *= 6378137, u = Math.round(1e3 * u) / 1e3
    };
    var r, a = (r = n("BXdv")) && r.__esModule ? r : {
      default: r
    };

    function i(e, t) {
      return function(e) {
        return e >= -90 && e <= 90
      }(e) && function(e) {
        return e >= -180 && e <= 180
      }(t)
    }
  },
  oGZU: function(e, t, n) {
    n.d(t, "a", function() {
      return i
    }), n.d(t, "d", function() {
      return o
    }), n.d(t, "c", function() {
      return s
    }), n.d(t, "b", function() {
      return c
    });
    var r = n("bb6g"),
      a = n("QxN7"),
      i = function(e) {
        var t = Object(r.__assign)(Object(r.__assign)({}, e), {
          header: Object(r.__assign)({
            ppt: JSON.stringify({
              cmp: "tee"
            })
          }, e.header)
        });
        return Object(a.baseRequest)(t)
      },
      o = function(e) {
        return e.ticket ? i({
          method: "POST",
          origin: "uic",
          path: "/passport/api/login-dialog/sms.json",
          data: e,
          config: {},
          withCredentials: !0
        }) : i({
          method: "POST",
          origin: "uic",
          path: "/passport/general/sms/for/login.json",
          data: e,
          config: {},
          withCredentials: !0
        })
      },
      s = function(e) {
        return i({
          method: "POST",
          origin: "uic",
          path: "/passport/general/login/sms.json",
          data: e,
          config: {},
          withCredentials: !0
        })
      },
      c = function(e) {
        return i({
          method: "POST",
          origin: "uic",
          path: "/passport/api/login-dialog/by-pass.json",
          data: e,
          config: {},
          withCredentials: !0
        })
      }
  },
  oagz: function(e, t) {
    e.exports = function(e, t, n) {
      for (var r = n - 1, a = e.length; ++r < a;)
        if (e[r] === t) return r;
      return -1
    }
  },
  ofiy: function(e, t, n) {
    var r = n("aCmY"),
      a = n("VbZR"),
      i = n("oagz");
    e.exports = function(e, t, n) {
      return t == t ? i(e, t, n) : r(e, a, n)
    }
  },
  pF6A: function(e, t, n) {
    var r = n("9ZMt"),
      a = n("yDO/"),
      {
        useTpx: i,
        useTvw: o
      } = r.default.style;
    t.a = {
      computed: {
        capLayoutItemStyle() {
          var {
            itemMargin: e,
            type: t
          } = this.opt.layoutOpt, n = "margin: " + i(e / 2) + ";";
          return [a.f.TWO, a.f.THREE, a.f.SWIPE, a.f.HYBRID].includes(t) && (n += "height: calc(100% - " + e + "px)"), n
        }
      },
      methods: {
        getCapLayoutItemWrapStyle(e) {
          var {
            itemWidth: t,
            type: n
          } = this.opt.layoutOpt;
          if ("hybrid" === n) return e % 3 == 0 ? "width: 100%;" : "width: 50%;";
          if ("string" == typeof t && /tvw$/.test(t.trim())) {
            var r = +t.replace("tvw", "");
            return "width: " + o(r)
          }
          return "number" == typeof t ? "width: " + i(t) : void 0
        }
      }
    }
  },
  "pOq+": function(e, t, n) {
    n.d(t, "a", function() {
      return a
    });
    var r = n("1pB4");

    function a(e) {
      return Array.isArray(e) ? e.filter(e => null != e && "" !== e).map(e => a(e)).join(";") : Object(r.f)(e) ? Object.keys(e).filter(t => null != e[t] && "" !== e[t]).map(t => [t, [e[t]]].join(":")).join(";") : e
    }
  },
  pTxV: function(e, t, n) {
    var r = n("AfOI");
    n.d(t, "UserAuthorizeType", function() {
      return r.a
    });
    n("E5w5");
    var a = n("Br49");
    n.d(t, "EventName", function() {
      return a.a
    }), n.d(t, "EventPopupTriggerTypes", function() {
      return a.c
    }), n.d(t, "EventRegisterType", function() {
      return a.d
    });
    n("JjL0"), n("dO0t"), n("nhoV")
  },
  pXyP: function(e, t, n) {
    var r = n("5JV4"),
      a = {
        __map: {},
        __sub: [],
        __list: [],
        __willStickyComponentList: [],
        __willStickyComponentChangeSub: [],
        setCheckItem(e, t, n) {
          void 0 === t && (t = 0);
          var {
            __list: r = []
          } = this, a = r.findIndex(t => t.key === e);
          a < 0 && (r.push({
            key: e,
            weight: t
          }), this.__list = r), a > -1 && n && (r[a] = {
            key: e,
            weight: t
          }, this.__list = r)
        },
        getCheckList(e, t, n) {
          var r = e.find(e => e.key === t) || {
            weight: 0
          };
          return n ? e.filter(e => e.weight >= r.weight) : e.filter(e => e.weight <= r.weight)
        },
        clearCheckWeightItem(e) {
          var {
            __list: t = [],
            __map: n = {}
          } = this;
          this.getCheckList(t, e, !1).forEach(e => {
            delete n[e.key]
          }), this.__map = n
        },
        getHasTop(e) {
          var t = Object(r.a)(),
            {
              __map: n = {}
            } = this;
          for (var a in n) a !== e && (t += +n[a].height);
          return t
        },
        getNextTop(e) {
          var {
            __list: t = [],
            __map: n = {}
          } = this;
          return this.getCheckList(t, e, !0).reduce((e, t) => {
            var {
              key: r
            } = t, a = n[r];
            return e + (a && !a.isHide ? a.height : 0)
          }, Object(r.a)())
        },
        hasItem(e) {
          var {
            __map: t
          } = this;
          return Object.prototype.hasOwnProperty.call(t, e)
        },
        setItem(e, t, n) {
          var {
            __map: r = {}
          } = this;
          if (n) {
            var a = this.getNextTop(e),
              i = {
                height: t,
                positionTop: a,
                nextTop: a + t
              };
            this.hasItem(e) || (r[e] = i, this.setSub())
          } else this.hasItem(e) && (delete r[e], this.setSub());
          this.__map = r
        },
        setSub() {
          var {
            __sub: e
          } = this;
          e.forEach(e => {
            e.fn.call(e.ctx, {
              type: "setItem"
            })
          })
        },
        getItem(e) {
          return this.__map[e]
        },
        setControlSub(e, t, n) {
          var {
            __sub: r = []
          } = this;
          r.findIndex(e => e.type === n) < 0 && (r.push({
            type: n,
            ctx: t,
            fn: e
          }), this.__sub = r)
        },
        delControlSub(e) {
          var {
            __sub: t = []
          } = this, n = t.findIndex(t => t.type === e);
          n > -1 && (t.splice(n, 1), this.__sub = t)
        },
        publicControlSub(e) {
          var {
            __sub: t = [],
            __map: n = {}
          } = this, {
            positionTop: r
          } = n[e];
          this.updateMap(), t.forEach(t => {
            var {
              type: a
            } = t;
            if (a !== e && this.hasItem(a)) {
              var {
                positionTop: i
              } = n[a], o = i;
              i >= r && t.fn.call(t.ctx, {
                type: "stickyTop",
                stickyTop: o
              })
            }
          })
        },
        updateMap() {
          var {
            __map: e
          } = this;
          for (var t of Object.keys(e)) {
            var n = this.getNextTop(t),
              r = e[t];
            r.positionTop = n, r.nextTop = n + r.height
          }
        },
        setIsShow(e, t) {
          var {
            __map: n
          } = this, r = n[e];
          r && (r.isHide = !t)
        },
        setHeight(e, t) {
          var {
            __map: n
          } = this, r = n[e];
          r && (r.height = t)
        },
        setWillStickyComponent(e) {
          var {
            name: t,
            type: n,
            positionTop: r,
            elementHeight: a,
            zIndex: i
          } = e, o = this.__willStickyComponentList || [];
          o.some(e => e.name === t) ? o.map(e => e.positionTop > r ? {
            name: t,
            type: n,
            positionTop: r,
            elementHeight: a,
            zIndex: i
          } : e) : (o.push({
            name: t,
            type: n,
            positionTop: r,
            elementHeight: a,
            zIndex: i
          }), this.__willStickyComponentList = o, (this.__willStickyComponentChangeSub || []).forEach(e => Object.values(e)[0]()))
        },
        setWillStickyComponentChangeSub(e, t) {
          var n = this.__willStickyComponentChangeSub || [];
          n.push({
            [e]: t
          });
          var r = new Set;
          this.__willStickyComponentChangeSub = n.filter(e => {
            var t = Object.keys(e)[0];
            return !r.has(t) && r.add(t)
          })
        },
        getWillStickyComponent() {
          return this.__willStickyComponentList || []
        },
        resetData() {
          this.__map = {}, this.__sub = [], this.__list = [], this.__willStickyComponentList = [], this.__willStickyComponentChangeSub = []
        }
      };
    t.a = a
  },
  pZIW: function(e, t, n) {
    var r = n("b2OE"),
      a = n("7IP4"),
      i = n("OF9M"),
      o = r && 1 / i(new r([, -0]))[1] == 1 / 0 ? function(e) {
        return new r(e)
      } : a;
    e.exports = o
  },
  pfnQ: function(e, t, n) {
    var r = n("8mzt");
    r.a.config({
      appName: "wsc",
      logIndex: "new_wsc_weapp_log"
    }), t.a = r.a
  },
  pn6R: function(e, t, n) {
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.cloneDeepSimple = function(e) {
      return o(e, !0)
    }, t.default = void 0;
    var r = i(n("rmWm")),
      a = i(n("YIkY"));

    function i(e) {
      return e && e.__esModule ? e : {
        default: e
      }
    }

    function o(e) {
      var t, n = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
        i = (0, a.default)(e);
      if ("object" !== i && "array" !== i) return (0, r.default)(e, i);
      for (var o = [], c = [{
          value: e,
          key: void 0,
          ctx: null
        }], u = 0, d = function() {
          var e = c[u],
            r = e.value,
            a = e.key,
            i = e.ctx;
          n || o.forEach(function(e) {
            if (e === r) throw new Error("Deep copy circular structure")
          });
          var d = s(r),
            l = d.value,
            p = d.needCycle;
          i ? i[a] = l : t = l, p && (n || o.push(r), Object.keys(r).forEach(function(e) {
            c.push({
              value: r[e],
              key: e,
              ctx: l
            })
          })), u++
        }; c.length > u;) d();
      return t
    }

    function s(e) {
      var t = (0, a.default)(e);
      switch (t) {
        case "object":
          return function(e) {
            var t = e.constructor;
            if (!t) return !1;
            var n = t.prototype;
            return !!n && !!n.hasOwnProperty("isPrototypeOf")
          }(e) ? {
            value: new e.constructor,
            needCycle: !0
          } : {
            value: e,
            needCycle: !1
          };
        case "array":
          return {
            value: new e.constructor, needCycle: !0
          };
        default:
          return {
            value: (0, r.default)(e, t), needCycle: !1
          };
      }
    }
    var c = o;
    t.default = c
  },
  q3MX: function(e, t, n) {
    n.d(t, "b", function() {
      return j
    });
    var r = n("9ZMt"),
      a = {
        batch: !0,
        plat: {},
        env: {},
        context: {},
        user: {},
        spm: {},
        autoClick: !0,
        autoNodeClick: !0,
        autoNodeView: !0,
        autoEnterpage: !0,
        autoSinglePageEnterpage: !0,
        autoSpm: !0,
        autoABTest: !0,
        autoTrackFormSubmit: !0,
        enableEvents: {
          onAppLaunch: !0,
          onAppShow: !0,
          onAppHide: !0,
          beforePageCreate: !0,
          pageCreated: !0,
          onPageShow: !0,
          onPageHide: !0,
          pageDestroyed: !0,
          onRootClick: !0
        }
      };

    function i(e) {
      return e && "object" == typeof e && !Array.isArray(e)
    }

    function o(e) {
      for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
      if (!n.length) return e;
      var a = n.shift();
      if (i(e) && i(a))
        for (var s in a) i(a[s]) ? (e[s] || Object.assign(e, {
          [s]: {}
        }), o(e[s], a[s])) : Object.assign(e, {
          [s]: a[s]
        });
      return o(e, ...n)
    }
    var s = e => Object.assign(Object.assign(Object.assign({}, a), e), {
      enableEvents: Object.assign(Object.assign({}, a.enableEvents), e.enableEvents)
    });

    function c(e) {
      if (!e) throw new Error("Logger Plugin:请传入埋点初始化配置.");
      var {
        plat: t = {},
        yai: n
      } = e;
      if (!n && !t.yai) throw new Error("Logger Plugin:请传入埋点初始化配置yai或者plat.yai.")
    }
    var u = () => {},
      d = {
        setPlat: u,
        setEnv: u,
        setEvent: u,
        setUser: u,
        setContext: u,
        appShow: u,
        appHide: u,
        enterpage: u,
        visitpage: u,
        leavepage: u,
        log: u,
        click: u,
        view: u,
        getData: u,
        getBannerId: u,
        getShareParams: u,
        setBeforeAppshow: u,
        setBeforeEnterpage: u,
        spmHelper: {
          getSpm: u,
          getPageSpm: u,
          setMoreSpm: u,
          setCurrentSpm: u
        },
        getCarrierParams: u,
        viewObserver: u
      },
      l = r.default.getEnv();

    function p() {
      try {
        return "web" === l ? {
          windowWidth: (t = document.body.getClientRects()[0]).width,
          windowHeight: t.height
        } : (e = (r.default.$native.getSystemInfoSync || r.default.$native.getSystemInfo)()) instanceof Promise ? {} : e
      } catch (e) {
        return {}
      }
      var e, t
    }
    var h = 20;

    function f(e, t, n) {
      return void 0 === t && (t = 1), Math.round(e * n / t)
    }

    function g(e) {
      return null == e
    }
    var v = ["is_share", "dc_ps", "banner_id", "from_source", "from_params", "wxShoppingListScene"];
    var m = new class {
      constructor(e) {
        this.logger = e, this._bizInfo = {}
      }
      set bizInfo(e) {
        this._bizInfo = o({}, this._bizInfo, e)
      }
      get bizInfo() {
        return Object.assign({}, this._bizInfo)
      }
      clearBizInfo() {
        this._bizInfo = {}
      }
      setLogBizInfo() {
        var {
          kdtId: e
        } = this._bizInfo;
        e && this.logger.setEvent({
          si: e
        })
      }
      updateSession(e) {
        void 0 === e && (e = {});
        var t = e.query || {},
          n = Object.keys(t).filter(e => v.indexOf(e) >= 0);
        n.length && this.logger.setContext(Object.assign({}, n.reduce((e, n) => (e[n] = t[n], e), {})), 120)
      }
      logEnterpage(e) {
        var {
          route: t,
          pageType: n,
          pageId: r,
          params: a = {},
          page: i,
          logUrl: o,
          pageShown: s
        } = e, {
          spmHelper: c,
          setEvent: u,
          enterpage: d
        } = this.logger;
        c.setCurrentSpm(t, r || this.bizInfo.kdtId, n), u({
            en: i.pageTitle || "",
            params: Object.assign(Object.assign({}, a), {
              ranta_page: 1,
              is_newly_open: !i.pageShown,
              page_title: i.pageTitle
            })
          }),
          function(e) {
            var {
              user: t
            } = e, {
              li: n,
              m: r
            } = t;
            n && r || !0
          }(this.logger.getData()), d({}, o, {
            pageShown: s
          })
      }
      hotClick(e) {
        var t = function(e, t) {
          var {
            windowWidth: n
          } = p(), {
            detail: r
          } = e, {
            clientX: a,
            clientY: i,
            x: o,
            y: s
          } = r || {}, c = a || o, u = i || s;
          return g(c) || g(u) ? null : {
            loc_x: f(c, n, h),
            loc_y: f(u, n, h)
          }
        }(e);
        if (t) {
          var n = {
            et: "custom",
            ei: "hot_click",
            en: "热力图点击",
            params: Object.assign({
              is_fix: 0
            }, t)
          };
          this.bizInfo.kdtId && (n.si = this.bizInfo.kdtId), this.logger.log(n)
        }
      }
      leavepage(e) {
        this.logger.leavepage({
          durl: e
        })
      }
    }(d);
    class y {
      constructor(e, t, n) {
        this.autoEnterpage = !t && e, this.asyncEnterpage = t, this.asyncCount = t ? -1 : 0, this.isRedirectPage = n, this.pageCreated = !1, this.pageShown = !1, this.pageParams = {}, this.query = {}, ["pageId", "pageType", "pageTitle", "rurl", "displayUrl", "route"].forEach(e => {
          this[e] = ""
        })
      }
      setPageCreated() {
        this.pageCreated = !0
      }
      setPageAsyncLog(e) {
        this.asyncEnterpage && !e || (this.autoEnterpage = !e, this.asyncEnterpage = e, this.asyncCount = -1 === this.asyncCount ? 1 : this.asyncCount + 1)
      }
      setUrl(e, t) {
        void 0 === t && (t = {}), this.route = e, this.query = t, this.displayUrl = function(e, t) {
          void 0 === t && (t = {});
          var n = e;
          return n && Object.keys(t).forEach((e, r) => {
            n += "" + (0 === r ? "?" : "&") + e + "=" + t[e]
          }), n
        }(e, t)
      }
      setPageConfig(e) {
        void 0 === e && (e = {});
        var {
          pageType: t,
          pageId: n,
          title: r,
          eventParams: a = {}
        } = e;
        if (this.pageTitle = r || this.pageTitle || "", t && (this.pageType = t), n && (this.pageId = n), "object" != typeof a);
        else {
          var i = ((e, t) => {
            for (var n = Object.keys(e), r = [], a = 0; a < n.length; a++) t.hasOwnProperty(n[a]) && r.push(n[a]);
            return r
          })(a, this.pageParams);
          i.length, this.pageParams = Object.assign(Object.assign({}, this.pageParams), a)
        }
        this.asyncEnterpage && this.pageCreated && (this.asyncCount--, this.enterpage())
      }
      get canEnterpage() {
        return !(this.isRedirectPage || !this.pageCreated) && !!(this.autoEnterpage || this.asyncEnterpage && 0 === this.asyncCount)
      }
      enterpage(e, t) {
        if (e && this.setUrl(this.route, e), this.canEnterpage) {
          var n = {
              rurl: this.rurl || "",
              durl: this.displayUrl
            },
            {
              pageType: r,
              pageId: a,
              pageParams: i
            } = this;
          m.logEnterpage({
            route: this.route,
            pageType: r,
            pageId: a,
            params: Object.assign(Object.assign({}, i), {
              is_page_not_log_enterpage: +!!t
            }),
            page: this,
            logUrl: n,
            pageShown: this.pageShown
          }), this.pageShown = !0, this.autoEnterpage = !0
        }
      }
      leavePage() {
        try {
          this.pageShown || (this.asyncCount = 0, this.enterpage(void 0, !1));
          var e = this.displayUrl || "",
            t = e || "";
          this.autoEnterpage && !this.isRedirectPage && m.leavepage(e), this.rurl = t, this.pageShown = !0
        } catch (e) {}
      }
    }
    class b {
      constructor(e) {
        this.logger = e, this.PAGE_VISIT_HISTORY = []
      }
      get latestPage() {
        return this.PAGE_VISIT_HISTORY[this.PAGE_VISIT_HISTORY.length - 1]
      }
      get currentPage() {
        return this.latestPage
      }
      getPageHistory() {
        return [...this.PAGE_VISIT_HISTORY]
      }
      savePageHistory(e) {
        this.PAGE_VISIT_HISTORY.push(e)
      }
      checkLastPage(e) {
        var t = this.latestPage;
        return t && t.route === e ? t : null
      }
      removeLastPage() {
        0 != this.PAGE_VISIT_HISTORY.length && this.PAGE_VISIT_HISTORY.pop()
      }
      setCurrentPage(e, t, n, r) {
        void 0 === t && (t = ""), void 0 === n && (n = !1), void 0 === r && (r = !1);
        var a = new y(e.autoEnterpage, n, r);
        return this.savePageHistory(a), this.setCurrentPageUrl(t), a
      }
      setCurrentPageUrl(e) {
        this.latestPage.setUrl(e)
      }
      setPageCreated() {
        this.currentPage.setPageCreated()
      }
      enterpage(e) {
        this.currentPage && this.currentPage.enterpage(e)
      }
      leavepage() {
        this.currentPage && this.currentPage.leavePage()
      }
      destoryPage() {
        try {
          var e = this.currentPage;
          (e.autoEnterpage || e.asyncEnterpage && e.asyncCount > 0) && this.leavepage(), this.removeLastPage()
        } catch (e) {}
      }
    }
    var _ = function(e) {
        for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
        e && e(...n)
      },
      O = function(e, t, n) {
        var a = e.init(),
          i = new b(a);
        m.logger = a;
        var {
          asyncPageTypes: s = [],
          spm: c = {},
          redirectPages: u = [],
          enableEvents: d = {}
        } = n;
        d.onAppLaunch && _(t.onAppLaunch, function() {
          a.setEnv({
            rtpl: "1.1.53"
          }), a.spmHelper.setMoreSpm(n.spm)
        }), d.onAppShow && _(t.onAppShow, e => {
          m.updateSession(Object.assign({}, e)), m.setLogBizInfo(), a.appShow(e)
        }), d.onAppHide && _(t.onAppHide, () => {
          a.appHide()
        }), d.beforePageCreate && _(t.beforePageCreate, () => {
          var e = function() {
              try {
                var e = getCurrentPages() || [];
                return (e[e.length - 1] || {}).route || ""
              } catch (e) {}
              try {
                return window.document.location.pathname
              } catch (e) {}
              return ""
            }(),
            t = s.includes(c[e]),
            r = u.includes(e);
          i.setCurrentPage(n, e, t, r)
        }), d.pageCreated && _(t.pageCreated, () => {
          i.setPageCreated()
        }), d.onPageShow && _(t.onPageShow, function(e) {
          var {
            route: t = "",
            query: n = {}
          } = void 0 === e ? {} : e;
          m.updateSession(Object.assign({}, n)), i.enterpage(n)
        }), d.onPageHide && _(t.onPageHide, () => {
          i.leavepage()
        }), d.pageDestroyed && _(t.pageDestroyed, () => {
          i.destoryPage()
        }), d.onRootClick && _(t.onRootClick, e => {
          n.autoClick && m.hotClick(e)
        });
        var l = {
          setBeforeAppshow(e) {
            a.setBeforeAppshow && a.setBeforeAppshow(() => e(l))
          },
          setBeforeEnterpage(e) {
            a.setBeforeEnterpage && a.setBeforeEnterpage(() => e(l))
          },
          setPageAsyncLog(e) {
            void 0 === e && (e = !0);
            var t = i.currentPage;
            t && t.setPageAsyncLog(e)
          },
          setPageInitConfig(e) {
            void 0 === e && (e = {});
            var t = i.currentPage;
            t && (t.autoEnterpage && t.pageShown || t.setPageConfig(e))
          },
          view(e) {
            a.log(o({
              en: "曝光",
              ei: "view",
              et: "view",
              params: {}
            }, e))
          },
          getLogParams: () => a.getData(),
          setEvent(e, t) {
            void 0 === t && (t = "page");
            var {
              si: n
            } = e;
            n && (m.bizInfo = {
              kdtId: n
            }), a.setEvent(e, t)
          },
          setContext(e, t) {
            Array.isArray(e) && (t = (e = e[0])[1]), a.setContext(e, t)
          }
        };
        return ["getSpm", "getPageSpm", "setMoreSpm", "setCurrentSpm"].forEach(e => {
          l[e] = function() {
            return a.spmHelper[e] && a.spmHelper[e](...arguments)
          }
        }), ["enterpage", "leavepage", "log", "click", "getData", "setUser", "setPlat", "setEnv", "getCarrierParams", "refreshPageFlag", "viewObserver"].forEach(e => {
          l[e] = function() {
            return a[e] && a[e](...arguments)
          }
        }), r.default.setGlobal("logger", l), l
      },
      S = n("xqQ2"),
      w = e => {
        var {
          yai: t,
          plat: n,
          batch: r,
          user: a,
          env: i,
          context: s,
          event: c,
          beforeAppshow: u,
          beforeEnterpage: d,
          eventQueueMaxLength: l,
          eventQueuePollingInterval: p
        } = e;
        return {
          plat: o({}, {
            yai: t
          }, n),
          batch: r,
          user: a,
          env: i,
          context: s,
          event: c,
          beforeAppshow: u,
          beforeEnterpage: d,
          eventQueueMaxLength: l,
          eventQueuePollingInterval: p
        }
      };
    var I = {
      getPageSpm: "gettCurrentPageSpm"
    };

    function P(e) {
      var t = Object.assign({}, d);
      return {
        init: function() {
          t = function(e) {
            var t = w(Object.assign({}, e));
            return new S.a(t)
          }(e);
          var n = {};
          ["log", "setEvent", "setPlat", "setEnv", "setContext", "setUser", "appShow", "appHide", "visitpage", "click", "view", "getBannerId", "getShareParams", "setBeforeAppshow", "setBeforeEnterpage", "refreshPageFlag", "setPageAsyncLog", "viewObserver"].forEach(e => {
            n[e] = function() {
              return t[e] && t[e](...arguments)
            }
          });
          var r = {};
          return ["getSpm", "getPageSpm", "setMoreSpm", "setCurrentSpm"].forEach(e => {
            var n = I[e] || e;
            r[e] = function() {
              return t.spmHelper && t.spmHelper[n](...arguments)
            }
          }), Object.assign(Object.assign(Object.assign(Object.assign({}, n), {
            enterpage: function(e) {
              for (var n = arguments.length, r = new Array(n > 1 ? n - 1 : 0), a = 1; a < n; a++) r[a - 1] = arguments[a];
              t.pageShow(e, ...r)
            },
            leavepage: function() {
              t.pageHide()
            },
            getData: function() {
              return t.getLogParams()
            },
            spmHelper: r
          }), r), {
            getCarrierParams: function(e) {
              return e ? "" : {}
            }
          })
        }
      }
    }

    function k(e, t) {
      c(e);
      var n = P(w(e));
      return O(n, t, s(e))
    }

    function j(e) {
      return c(e), P(w(s(e))).init()
    }
    k.pluginName = "logger";
    t.a = k
  },
  qJXH: function(e, t, n) {
    n.d(t, "c", function() {
      return Y
    }), n.d(t, "a", function() {
      return $
    });
    var r = n("vB9s"),
      a = n("qTUJ"),
      i = n("AqAW"),
      o = n("DXKY"),
      s = n("svh/"),
      c = n("UL3R"),
      u = {
        onShow(e) {
          var t = null;
          if (1037 != +e.scene) return t = null, void(this.globalData.navigateMiniProgramConfig = t);
          t = ((e.referrerInfo || {}).extraData || {}).config || {}, this.globalData.navigateMiniProgramConfig = t
        },
        onHide() {}
      },
      d = {
        globalCollectFormId(e) {
          var {
            detail: t
          } = e, n = t.formId;
          n && getApp().carmen({
            api: "wsc.weapp.formid/1.0.0/add",
            data: {
              weapp_type: "custom",
              form_id: n
            }
          })
        }
      },
      l = n("Fcif"),
      p = n("Yt9W"),
      h = n("R18q"),
      f = "packages",
      g = "packages/goods",
      v = ["pages/goods/detail/index", g + "/detail/index", g + "/groupon/index", g + "/help-cut/index", g + "/lucky-draw-group/index", g + "/tuan/index", g + "/present/index", g + "/points/index", g + "/seckill/index", g + "-v2/detail/index", g + "-v2/groupon/index", g + "-v2/help-cut/index", g + "-v2/lucky-draw-group/index", g + "-v2/tuan/index", g + "-v2/present/index", g + "-v2/points/index", g + "-v2/seckill/index", g + "-v3/detail/index", g + "-v3/groupon/index", g + "-v3/help-cut/index", g + "-v3/lucky-draw-group/index", g + "-v3/tuan/index", g + "-v3/present/index", g + "-v3/points/index", g + "-v3/seckill/index", f + "/paidcontent/content/index", f + "/paidcontent/column/index", f + "/paidcontent/live/index", f + "/card/detail/index"],
      m = [f + "/shop/goods/tag-list/index", f + "/shop/goods/all/index", f + "/shop/goods/search/index", f + "/goods-list/tag/index", f + "/goods-list/all/index", f + "/goods-list/search-result/index"],
      y = [f + "/new-punch/introduction/index", f + "/new-punch/task/index"],
      b = {
        "packages/paidcontent/list/index": "type"
      },
      _ = [f + "/ump/bargain-purchase/home/index", f + "/ump/helpcut/index", f + "/ump/discount-packages/index", f + "/ump/collect-gift/home/index"],
      O = [f + "/shop/salesman/promote/index"],
      S = [f + "/short-video/index"];

    function w() {
      var e = getCurrentPages(),
        t = e[e.length - 1],
        n = t.route;
      return b[n] && t.options && t.options[b[n]] && (n = n + "?" + b[n] + "=" + t.options[b[n]]), n
    }

    function I() {
      var e = getApp(),
        t = function() {
          var e = getCurrentPages() || [{}];
          if (0 !== e.length) {
            var t = e[e.length - 1],
              {
                route: n = "",
                options: r = {}
              } = t,
              a = n;
            return a && Object.keys(r).forEach((e, t) => {
              a += "" + (0 === t ? "?" : "&") + e + "=" + r[e]
            }), a
          }
        }();
      t && (e._rurl = t)
    }
    var P = {
        onLoad(e) {
          var t = getApp(),
            {
              id: n
            } = this.data,
            r = w();
          t.logger.performance("page", "pageload"), t.logger.updateSession({
            query: e
          }), Object(p.c)(e), Object(p.g)(t.logger), v.indexOf(r) >= 0 && !n ? (this.once("goodsDetail:loaded", () => {
            t.logger.performance("app", "pageshow"), t.logger.performance("page", "pageshow", !1, r)
          }), this.once("goodsDetail:speedindex", () => {
            t.logger.performance("app", "speedindex"), t.logger.performance("page", "speedindex", !1, r)
          }), this.once("goodsDetail:pagefinished", () => {
            null == h.a || h.a.markRendered("fs"), t.logger.performance("app", "pagefinished"), t.logger.performance("page", "pagefinished", !1, r)
          }), this.once("quanyika:loaded", () => {
            t.logger.performance("app", "pageshow"), t.logger.performance("page", "pageshow", !1, r)
          })) : "packages/order/index" !== r || n ? "packages/shop/shopnote/detail/index" !== r || n ? "packages/shop/shopnote/mparticle/detail/index" !== r || n ? _.indexOf(r) >= 0 ? this.once("umpActivity:loaded", () => {
            t.logger.performance("app", "pageshow"), t.logger.performance("page", "pageshow", !1, r)
          }) : t.logger.performance("app", "pageshow", !0) : this.once("mpArticleDetail:loaded", () => {
            t.logger.performance("app", "pageshow"), t.logger.performance("page", "pageshow", !1, r)
          }) : this.once("shopNoteDetail:loaded", () => {
            t.logger.performance("app", "pageshow"), t.logger.performance("page", "pageshow", !1, r)
          }) : this.once("order:loaded", () => {
            t.logger.performance("app", "pageshow"), t.logger.performance("page", "pageshow", !1, r)
          }), this.__firstShow = !0
        },
        onShow() {
          var e = this,
            t = getApp(),
            {
              params: n,
              spm: r,
              id: a = this.data.id,
              url: i = w(),
              isAsync: o,
              title: s
            } = this.logConfig || {};
          if (this.__isPageHide = !1, !o) {
            t.logger.setPageName(s || "");
            var c = getCurrentPages() || [];
            if (this.__firstShow) {
              if (this.__firstShow = !1, v.indexOf(i) >= 0 && !a) this.once("goodsDetail:loaded", (e, t) => {
                this.enterpageLog([i, e, {
                  live_id: t.liveId
                }, r, c], t.title)
              }), this.once("paidContent:loaded", (e, t) => {
                this.enterpageLog([i, e, {}, r, c], t.title)
              });
              else if (m.indexOf(i) >= 0) this.once("goodsTag:loaded", function(t, n) {
                var {
                  spmType: r
                } = void 0 === n ? {} : n;
                e.enterpageLog([i, a, t, r, c], s)
              });
              else if (y.indexOf(i) >= 0 && !a) this.once("punch:loaded", e => {
                this.enterpageLog([i, e, {}, r, c])
              });
              else if ("packages/shop/shopnote/detail/index" !== i || a) {
                if ("packages/shop/shopnote/mparticle/detail/index" !== i || a) {
                  if (_.indexOf(i) >= 0) this.once("umpActivity:loaded", (e, t) => {
                    this.enterpageLog([i, e, t, r, c])
                  });
                  else if (O.indexOf(i) >= 0) this.once("salesmanDetail:loaded", (e, t) => {
                    this.enterpageLog([i, e, t, r, c])
                  });
                  else if (S.indexOf(i) >= 0) this.once("shortVideo:loaded", e => {
                    this.enterpageLog([i, e, {}, r, c])
                  });
                  else {
                    var u = this.$log;
                    this.enterpageLog([i, this.data.featureId || a, n || u, r, c])
                  }
                } else this.once("mpArticleDetail:loaded", e => {
                  this.enterpageLog([i, e, {}, r, c])
                }), this.once("mpArticleDetail:show", e => {
                  this.enterpageLog([i, e, {}, r, c])
                });
              } else this.once("shopNoteDetail:loaded", e => {
                this.enterpageLog([i, e, {}, r, c])
              });
            } else this.enterpageLog()
          }
        },
        onHide() {
          !this.__isPageHide && Object(p.e)("hide"), this.__isPageHide = !0, I()
        },
        onUnload() {
          !this.__isPageHide && Object(p.e)("unload"), this.__isPageHide = !0, I()
        },
        __yzLog__(e) {
          var t = getApp();
          t.logger.log(Object(l.a)({}, e, {
            si: t.getKdtId()
          }))
        },
        enterpageLog(e, t) {
          (this.__firstShow = !1, this._logParams = e || this._logParams || [], this._logTitle = t || this._logTitle || "", this._logTitle) && getApp().logger.setPageName(this._logTitle);
          Object(p.d)(...this._logParams)
        },
        onPullDownRefresh() {
          var e = getApp();
          e.logger && e.logger.log({
            et: "custom",
            ei: "page_pull_down_refresh",
            en: "页面下拉刷新",
            si: e.getKdtId()
          })
        },
        onReachBottom() {
          var e = getApp();
          e.logger && e.logger.log({
            et: "custom",
            ei: "page_reach_bottom",
            en: "页面上拉触底",
            si: e.getKdtId()
          })
        }
      },
      k = n("RY8z"),
      j = {
        navigate: "navigate",
        redirect: "redirect",
        switch: "switchTab"
      },
      x = {
        globalNavigate(e) {
          var {
            currentTarget: t = {}
          } = e, {
            dataset: n = {}
          } = t, {
            type: r = "navigate",
            url: a = ""
          } = n;
          if (a) {
            var i = j[r];
            i && k.a[i]({
              url: a
            })
          }
        }
      },
      T = {
        onLoad() {},
        setYZData: n("Qb5n").b
      },
      E = n("2wjL"),
      A = n("JQZX"),
      C = n("WOkX"),
      D = n("lRMv"),
      M = n("4Kfr"),
      N = {
        menu: "native_wechat",
        button: "native_custom"
      };

    function L(e, t) {
      return () => {
        "function" == typeof e && e.call(this), this.__yzLog__({
          et: "click",
          ei: "share_result",
          en: "分享结果",
          params: {
            share_result: t
          }
        })
      }
    }
    var U = function(e) {
        if (e.onShareAppMessage) {
          var t = e.onShareAppMessage;
          e.onShareAppMessage = function() {
            for (var e = getApp(), n = arguments.length, r = new Array(n), a = 0; a < n; a++) r[a] = arguments[a];
            var i = t.call(this, ...r),
              o = i.loggerParams || {};
            this.__yzLog__({
              et: "click",
              ei: "share",
              en: "转发",
              params: Object(l.a)({
                share_cmpt: "native_custom"
              }, o)
            });
            var s = r[0].from,
              c = N[s],
              u = i.path || "/packages/home/dashboard/index",
              d = E.a.getAll(u),
              {
                ban_default_kdt_id: p
              } = d,
              h = Object(l.a)({}, d, D.i, {
                is_share: 1,
                share_cmpt: c
              }),
              f = Object(M.a)();
            f && (h.guide_second_sharer_id = f), this.data.salesman && this.data.salesman.share && (h = Object(l.a)({}, h, Object(C.c)({
              sl: this.data.salesman.seller
            }))), h.kdt_id = "true" === p ? d.kdt_id || e.getKdtId() || "" : e.getKdtId() || "";
            var g = e.logger.getGlobal() || {},
              v = g.context || {},
              m = g.user || {};
            v.dc_ps && (h.dc_ps = v.dc_ps || ""), m.uuid && (h.from_uuid = m.uuid || ""), e.getShopInfoSync().isMultiStore && (h.offlineId = e.getOfflineId()), u = E.a.add(u, h), i.noOfflineId && (u = E.a.remove(u, "offlineId"));
            var y = i && i.jumpBlankPage ? u : "/pages/common/blank-page/index?weappSharePath=" + encodeURIComponent(u);
            delete i.jumpBlankPage;
            var b = Object(l.a)({}, i, {
              path: y,
              success: L.call(this, i.success, "success"),
              fail: L.call(this, i.fail, "fail")
            });
            return b
          }
        }
        if (e.onShareTimeline) {
          var n = e.onShareTimeline;
          e.onShareTimeline = function() {
            for (var e = arguments.length, t = new Array(e), r = 0; r < e; r++) t[r] = arguments[r];
            var a = n.call(this, ...t),
              {
                query: i = ""
              } = a,
              o = ["shopAutoEnter=1"],
              s = Object(M.a)();
            if (s && o.push("guide_second_sharer_id=" + s), this.data.salesman && this.data.salesman.share) {
              var c = Object(l.a)({}, Object(C.c)({
                sl: this.data.salesman.seller
              }));
              Object(A.a)(c, (e, t) => {
                o.push(t + "=" + e)
              })
            }
            var u = o.join("&"),
              d = i ? i + "&" + u : u,
              p = Object(l.a)({}, a, {
                query: d
              });
            return p
          }
        }
      },
      R = n("42EB"),
      B = n("zMoS"),
      F = n("sbwY"),
      q = n("/duV"),
      {
        state: H
      } = F.a,
      z = ["packages/user/integral/index", "packages/trade/order/list/index", "packages/trade/order/result/index", "packages/card/list/index", "packages/order/paid/index", "packages/usercenter/dashboard/index", "packages/user/coupon/list/index", "packages/user/coupon/qrcode/index", "packages/user/coupon/detail/index", "packages/user/coupon/shop/index", "packages/common/stop-service/index", /pages-youzan\//];
    var G = {
        onLoad() {
          this.on("app:offlineId:change", this.offlinedIdChange)
        },
        offlinedIdChange(e) {
          this._checkShop(), this.whenOfflineChange && this.whenOfflineChange(e)
        },
        onShow() {
          this.setPageShop(), this._checkShop(), this.on("app:init:nostoreid", this._checkShop), o.a.on("shop:info:change", this.setPageShop)
        },
        onHide() {
          this.off("app:init:nostoreid", this._checkShop), o.a.off("shop:info:change", this.setPageShop)
        },
        onUnload() {
          this.off("app:init:nostoreid", this._checkShop), o.a.off("shop:info:change", this.setPageShop)
        },
        setPageShop() {
          var e, t = getApp(),
            n = {},
            r = H.shop,
            a = this.data.CURRENT_GLOBAL_SHOP || {},
            i = Object.keys(a).length > 0,
            o = r.base || {},
            s = r.store || {},
            c = !!i && (r.offlineId !== a.offlineId || Object(B.a)(r, "chainStoreInfo.name") !== Object(B.a)(a, "chainStoreInfo.name") || 0 !== (s.id || 0));
          this.data.isMultiStore !== r.isMultiStore && (n.isMultiStore = r.isMultiStore || !1, n.multiStoreSwitch = r.multiStoreSwitch || !1, n.openHideStore = r.openHideStore || !1), this.data.soldOutRecommend !== r.soldOutRecommend && (n.soldOutRecommend = r.soldOutRecommend || !1), r.isMultiStore && (o = Object(l.a)({
            multiStoreSwitch: r.multiStoreSwitch || !1
          }, r.base, s, {
            offlineId: r.offlineId,
            isMultiStore: !0,
            hideStore: r.openHideStore || !1
          })), r.chainStoreInfo && (o.chainStoreInfo = r.chainStoreInfo), (o.shop_business_isopen || o.suspend_message) && (o.shop_business_isopen = r.shop_business_isopen, o.suspend_message = r.suspend_message), i && !c || (n.CURRENT_GLOBAL_SHOP = o), "{}" !== JSON.stringify(n) && (this.setYZData(n), t.trigger("page-global-shop-change", {
            storeChanged: c,
            updateData: n
          })), (o.service && "SHOP_CLOSE" === o.service.status || o.online_channel_service && "SHOP_CLOSE" === o.online_channel_service.status) && !this.pageHasCheck && (e = this.route, z.some(t => t === e || t.test && t.test(e)) || wx.redirectTo({
            url: "/packages/common/stop-service/index"
          }), this.pageHasCheck = !0)
        },
        maybeInRetailPage: e => (void 0 === e && (e = ""), "string" == typeof e && ~e.indexOf("retail")),
        _checkShop() {
          Object(q.b)(this.route)
        }
      },
      W = n("7sy2"),
      K = Object(r.a)();

    function Y() {
      for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
      return K({}, ...t, u)
    }
    var V = Object(r.a)(),
      X = (t.b = function() {
        for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
        var r = V({}, T, i.a, {
          data: {
            pageWindowLock: !1
          },
          onLoad(e) {
            var t = getApp();
            t.getShopTheme().then(e => {
              var {
                themeClass: n,
                isFantasy: r,
                themeFetched: a
              } = e;
              t.themeClass = n, this.setYZData({
                themeClass: n,
                isFantasy: r,
                themeFetched: a
              })
            }), this.setYZData({
              wscpage: {},
              themeClass: t.themeClass,
              deviceType: t.deviceType || "",
              appType: "wsc",
              isTabPage: !0
            }), t.isSwitchTab().then(e => {
              this.setYZData({
                isTabPage: e
              })
            }), t._routeStack ? t._routeStack.push(this.route) : t._routeStack = [this.route], this.__query__ = e
          },
          onUnload() {
            var e = getApp(),
              t = (e._routeStack || []).findIndex(e => this && e === this.route); - 1 !== t && e._routeStack.splice(t, 1), this.off(null, null)
          },
          onShow() {
            o.a.trigger("page:lifetimes:show", {
              route: this.route
            }), Object(W.d)({
              path: this.route,
              query: this.__query__
            })
          },
          onHide() {
            o.a.trigger("page:lifetimes:hide", {
              route: this.route
            })
          },
          __resolveMessage: R.a
        }, G, ...t, P, d, x);
        return U(r), Page(r)
      }, ["onLoad", "onReady", "onShow", "onHide", "onUnload", "onPullDownRefresh", "onReachBottom", "onPageScroll", "onTabItemTap"]),
      J = ["data", "mapData", "watch", "state", "getters"];

    function $() {
      for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
      var r = Object(s.i)([T, i.a, {
        data: {
          pageWindowLock: !1
        },
        onLoad(e) {
          var t = getApp();
          t.getShopTheme().then(e => {
            var {
              themeClass: n,
              isFantasy: r,
              themeFetched: a
            } = e;
            t.themeClass = n, this.setYZData({
              themeClass: n,
              isFantasy: r,
              themeFetched: a
            })
          }), this.setYZData({
            wscpage: {},
            themeClass: t.themeClass,
            deviceType: t.deviceType || "",
            appType: "wsc",
            isTabPage: !0
          }), t.isSwitchTab().then(e => {
            this.setYZData({
              isTabPage: e
            })
          }), t._routeStack ? t._routeStack.push(this.route) : t._routeStack = [this.route], this.__query__ = e, Object.defineProperty(this, "$dispatch", {
            get() {
              return this.$store.dispatch
            }
          }), Object.defineProperty(this, "$commit", {
            get() {
              return this.$store.commit
            }
          })
        },
        onUnload() {
          var e = getApp(),
            t = (e._routeStack || []).findIndex(e => this && e === this.route); - 1 !== t && e._routeStack.splice(t, 1), this.off(null, null)
        },
        onShow() {
          Object(W.d)({
            path: this.route,
            query: this.__query__
          })
        }
      }, G, ...t, P, d, x], X.concat(J));
      U(r), Object(c.a)(r);
      var o = r.onLoad || function() {};
      return r.onLoad = function(e) {
        e = Object(a.a)(e), this.options = e || {}, o.call(this, e)
      }, Object(s.b)(r)
    }
  },
  qako: function(e, t, n) {
    var r = function(e, t) {
        var n = [];
        return e.forEach(e => {
          try {
            var r = e.callback.apply(e.ctx, t);
            n.push(r)
          } catch (e) {
            n.push(Promise.reject(e))
          }
        }), Promise.all(n)
      },
      a = {
        onAsync: function(e, t, n) {
          return this._events || (this._events = {}), (this._events[e] || (this._events[e] = [])).push({
            callback: t,
            context: n,
            ctx: n || {}
          }), this
        },
        offAsync: function(e, t, n) {
          if (!e && !t && !n) return this._events = {}, this;
          for (var r = e ? [e] : Object.keys(this._events), a = 0, i = r.length; a < i; a++) {
            e = r[a], this._events[e] && (this._events[e] = [], delete this._events[e])
          }
          return this
        },
        triggerAsync: function(e) {
          if (!this._events) return Promise.resolve([]);
          for (var t = this._events[e], n = arguments.length, a = new Array(n > 1 ? n - 1 : 0), i = 1; i < n; i++) a[i - 1] = arguments[i];
          return t ? r(t, a) : Promise.resolve([])
        }
      };
    t.a = a
  },
  qnge: function(e, t, n) {
    n.d(t, "a", function() {
      return i
    });
    var r = n("GZxp"),
      a = n.n(r);
    class i {
      constructor(e) {
        this.ctx = e.ctx
      }
    }
    i.widgets = {
      Main: a()
    }
  },
  qwv7: function(e, t, n) {
    n.d(t, "a", function() {
      return i
    });
    var r = n("AiY9"),
      a = n.n(r);
    class i {
      constructor(e) {
        this.ctx = e.ctx
      }
    }
    i.widgets = {
      Main: a.a
    }
  },
  rBuL: function(e, t, n) {
    n.d(t, "c", function() {
      return u
    }), n.d(t, "a", function() {
      return d
    }), n.d(t, "b", function() {
      return l
    });
    var r = n("Fcif"),
      a = n("/ftW"),
      i = n("z24M"),
      o = {
        current: 0,
        originKdtId: Object(i.a)("kdtId")
      },
      s = !1;

    function c() {
      return new Promise(e => {
        if (s) e();
        else {
          var t = o.originKdtId;
          a.a.getAsync("app:kdt_id").then(e => {
            var {
              current: n = 0
            } = e;
            o.current = n || t
          }).catch(() => {
            o.current = t
          }).finally(() => {
            s = !0, e()
          })
        }
      })
    }

    function u(e) {
      e && c().then(() => function(e) {
        o.current = e, a.a.setAsync("app:kdt_id", {
          current: e
        }, {
          expire: .02
        })
      }(e))
    }

    function d() {
      return new Promise(e => {
        c().then(() => {
          e(Object(r.a)({}, o))
        })
      })
    }

    function l() {
      return o.originKdtId
    }
  },
  rIfD: function(e, t, n) {
    n.d(t, "a", function() {
      return a
    });
    var r = n("US/N"),
      a = e => Object(r.default)({
        origin: "cashier",
        path: "/pay/wsctrade/order/buy/exchangeCoupon.json",
        method: "POST",
        data: e,
        withCredentials: !0
      })
  },
  rLrQ: function(e, t, n) {
    n.d(t, "a", function() {
      return o
    });
    var r = n("Fcif"),
      a = n("cxMM"),
      i = n.n(a);
    class o {
      constructor(e) {
        var {
          ctx: t,
          cloudConfig: n = {}
        } = e, {
          appStyleConfig: a = {}
        } = t.data, {
          objectToCSS: i
        } = t.lambdas;
        this.ctx = t, this.ctx.data.pageStyleConfig = Object(r.a)({}, a, n), this.ctx.data.pageStyleCSS = i(a, "--theme-") + i(n, "--theme-page-")
      }
    }
    o.widgets = {
      Main: i()
    }
  },
  rqVN: function(e, t, n) {
    var r = n("u8kV");
    n.d(t, "a", function() {
      return r.b
    }), t.b = r.c
  },
  rtA3: function(e, t, n) {
    n.d(t, "a", function() {
      return a
    });
    var r = n("/XVY"),
      a = Object(r.a)({
        type: {
          default: "one"
        },
        layoutMargin: {
          default: 0
        },
        itemMargin: {
          default: 0
        },
        itemWidth: {
          default: null
        },
        canUseScrollView: {
          default: !0
        },
        customClass: {
          type: String,
          default: ""
        }
      })
  },
  s0cO: function(e, t, n) {
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.default = void 0;
    var r = function(e) {
      return e.replace(/[A-Z]/g, function(e) {
        return "_".concat(e[0].toLowerCase())
      })
    };
    t.default = r, e.exports = t.default
  },
  s3UK: function(e, t, n) {
    var r = n("FfeU"),
      a = "object" == typeof self && self && self.Object === Object && self,
      i = r || a || Function("return this")();
    e.exports = i
  },
  sIkL: function(e, t, n) {
    n.d(t, "a", function() {
      return O
    });
    var r = n("Fcif"),
      a = n("+I+c"),
      i = n("+66q"),
      o = (n("3m7Z"), n("tS13")),
      s = n("gBZH"),
      c = n("X9+V"),
      u = [o.c.BUY, o.c.SEL_SKU],
      d = function(e, t) {
        return void 0 === t && (t = +new Date), e - t > 0
      },
      l = function(e, t) {
        return void 0 === t && (t = +new Date), e - t < 0
      },
      p = n("JijB"),
      h = n.n(p),
      f = n("jmjq"),
      g = n.n(f),
      v = n("w2Y9"),
      m = n.n(v),
      y = ["bigButtons", "disabledBigButton"],
      b = {
        [i.a.GROUP_ON]: function(e, t) {
          var n;
          void 0 === e && (e = []);
          var {
            currentActivity: a,
            kdtId: u,
            priceInfo: d,
            sku: l,
            marketing: {
              buttonUmpTextModel: p,
              activities: h
            }
          } = t, {
            type: f,
            subType: g,
            buttonType: v,
            groupAlias: m,
            isStart: y
          } = a, {
            minPrice: b,
            oldMinPrice: _
          } = l[g || f], {
            ladderMinPrice: O,
            ladderMaxPrice: S
          } = d, w = a.type === i.a.GROUP_ON && a.subType === i.a.LADDER_GROUP_ON, I = {
            main: [{
              text: "立即开团"
            }, {
              text: p && p.umpTag ? p.umpTag : w ? Object(c.a)(O) + (O === S ? "" : "起") : "￥" + Object(c.a)(b, 2)
            }],
            primary: !0,
            explainVideoBtnText: i.b,
            skuScene: o.c.BUY,
            accountUnionScene: s.a.GROUP_BUY,
            btnActive: o.a.WX_SUBSCRIBE,
            activityName: g || f,
            subscribeSceneV2: "groupOn"
          };
          if (1 == e.length) {
            var P = e[0];
            P.SKU_SCENE != o.c.BUY && P.SKU_SCENE != o.c.ADD_CART || (j.skuScene = P.skuScene)
          }
          var k = {
              main: [{
                text: "立即开团"
              }],
              primary: !0,
              skuScene: o.c.BUY,
              accountUnionScene: s.a.GROUP_BUY,
              btnActive: o.a.WX_SUBSCRIBE,
              activityName: g || f,
              subscribeSceneV2: "groupOn"
            },
            j = {
              main: [{
                text: y ? "单独购买" : "非活动价购买"
              }, {
                text: "￥" + Object(c.a)(_, 2)
              }],
              skuScene: o.c.SEL_SKU,
              accountUnionScene: s.a.NORMAL_BUY,
              btnActive: "openSku",
              activityName: "goods"
            },
            x = {
              main: [{
                text: "查看我的团"
              }],
              primary: !0,
              btnActive: o.a.SUBMIT,
              submitAction: i.j.UMP_GO_2_WEBVIEW,
              link: {
                pageName: "GrouponDetail",
                query: {
                  alias: a.groupAlias,
                  type: a.code,
                  kdt_id: u
                }
              }
            },
            T = {
              main: [{
                text: "加入购物车"
              }],
              skuScene: o.c.ADD_CART,
              accountUnionScene: s.a.ADD_CART,
              btnActive: "openSku",
              activityName: "goods"
            };
          if (m && !i.e.includes(v)) return [j, x];
          switch (v) {
            case 0:
            case 2:
              e.push(j), e.push(I);
              break;
            case 1:
              e.push(j), e.push(x);
              break;
            case 3:
              var {
                avatar: E = "", nickName: A = ""
              } = (null == (n = h.find(e => "groupOn" === e.type)) ? void 0 : n.shareUserInfo) || {}, C = A;
              C.length > 5 && (C = C.substr(0, 5) + "..."), k.main[0].text = "和" + C + "一起拼", k.main[0].avatar = E, e = [k];
              break;
            case 4:
              e.push(j), x.main[0].text = "￥" + Object(c.a)(b, 2) + "参团", e.push(x);
              break;
            case 5:
              e.push(T), j.primary = !0, e.push(j);
          }
          return e.map(e => Object(r.a)({}, e))
        },
        [i.a.TIMELIMITED_DISCOUNT]: function(e, t) {
          void 0 === e && (e = []);
          var n = [...e],
            {
              currentActivity: a,
              limitedEstimate: o = {},
              umpActivity: s = {}
            } = t,
            {
              isStart: c
            } = a,
            d = e.findIndex(e => e.primary),
            l = Object.keys(s).indexOf("coupon") > -1,
            p = o && o.buttonUmpText && 1 === (null == o ? void 0 : o.num) && !l,
            {
              marketing: {
                buttonUmpTextModel: h
              }
            } = t;
          if (!c && -1 !== d && u.includes(n[d].skuScene) && (n[d].main = [{
              text: "非活动价购买"
            }]), h && -1 !== d && n[d].main.length < 2) {
            var {
              umpTag: f
            } = h;
            n[d].main.push({
              text: f
            })
          }
          if (-1 !== d && c && n.forEach(e => {
              e.activityName = i.a.TIMELIMITED_DISCOUNT, e.explainVideoBtnText = i.b
            }), p && c) {
            var {
              umpTag: g
            } = o.buttonUmpText;
            n[d].main.push({
              text: g
            })
          }
          return n.map(e => Object(r.a)({}, e))
        },
        [i.a.SECKILL]: function(e, t) {
          void 0 === e && (e = []);
          var {
            currentActivity: n,
            alias: a
          } = t, {
            startAt: c,
            endAt: u,
            current: p = +new Date,
            isCheckRight: h,
            isPassCheck: f,
            questionId: g,
            bookingNumText: v = "0"
          } = n;
          e.length = 0;
          var m = {
            main: [{
              text: "非活动价购买"
            }],
            btnActive: o.a.SUBMIT,
            submitAction: i.j.UMP_GO_2_DETAIL,
            alias: a
          };
          return l(u, p) ? (m.primary = !0, e.push(m), e) : (d(c, p) ? (e.push(m), h && !f && e.push({
            main: [{
              text: "立即预约"
            }, {
              text: v + "人已预约"
            }],
            skuScene: o.c.RESERVATION,
            btnActive: o.a.WX_SUBSCRIBE,
            accountUnionScene: s.a.NORMAL_BUY,
            submitAction: i.j.ORDER_SECKILL,
            questionId: g,
            subscribeSceneV2: "umpSeckillBookRemind"
          })) : !h || f ? e.push({
            main: [{
              text: "立即秒杀"
            }],
            primary: !0,
            explainVideoBtnText: i.b,
            skuScene: o.c.BUY,
            accountUnionScene: s.a.NORMAL_BUY,
            btnActive: o.a.OPEN_SKU,
            activityName: i.a.SECKILL
          }) : e.push(m), e.map(e => Object(r.a)({}, e)))
        },
        [i.a.DEPOSIT_EXPANSION]: function(e) {
          void 0 === e && (e = []);
          var t = e.findIndex(e => e.primary);
          return e[t].activityName = i.a.DEPOSIT_EXPANSION, e.map(e => Object(r.a)({}, e))
        },
        [i.a.HELP_DEPOSIT_EXPANSION]: function(e, t) {
          void 0 === e && (e = []);
          var {
            currentActivity: n,
            kdtId: a
          } = t, s = e.findIndex(e => e.primary), {
            goodsActivity: c
          } = t, {
            presale: u
          } = c, {
            isStart: d,
            joinActivityStatus: l,
            voucherId: p,
            activityId: f
          } = n, {
            balanceDueStart: g,
            balanceDueEnd: v,
            preSaleEnd: m,
            shipTimeStr: y
          } = u, b = {}, _ = "支付定金", O = [{
            text: h()(m, "MM.DD HH:mm:ss") + " 定金截止"
          }, {
            text: y
          }];
          if (!d) return e;
          if (3 === l) O = [], _ = "已完成购买，看看其他商品", Object.assign(b, {
            btnActive: o.a.SUBMIT,
            submitAction: o.d.JUMP_LINK,
            link: {
              pageName: "Home",
              query: {
                kdt_id: a
              },
              type: "switchTab"
            }
          });
          else {
            var S = l === i.d.HELPING,
              w = l === i.d.HELPING && g < Date.now() || l === i.d.BALANCE_PAYMENT;
            (S || w) && (w ? (_ = "支付尾款", O = [{
              text: h()(v, "MM.DD HH:mm:ss") + " 尾款截止"
            }, {
              text: y
            }]) : (_ = "查看助力", O = [{
              text: h()(g, "MM.DD HH:mm:ss") + " 支付尾款"
            }, {
              text: y
            }]), b.link = {
              pageName: "HandselExpand",
              query: {
                voucherId: p,
                kdt_id: a,
                activityId: f
              }
            }, b.btnActive = o.a.SUBMIT, b.submitAction = i.j.UMP_GO_2_WEBVIEW)
          }
          return l === i.d.NOT_PARTICIPATE ? b.explainVideoBtnText = i.b : b.explainVideoBtnText = i.c, [Object(r.a)({}, e[s], b, {
            activityName: i.a.HELP_DEPOSIT_EXPANSION,
            sub: O,
            main: [{
              text: _
            }]
          })].map(e => Object(r.a)({}, e))
        },
        [i.a.PRESENT_EXCHANGE]: () => [{
          main: [{
            text: "领取赠品"
          }],
          btnActive: o.a.OPEN_SKU,
          skuScene: o.c.BUY,
          accountUnionScene: s.a.NORMAL_BUY,
          primary: !0,
          activityName: i.a.PRESENT_EXCHANGE
        }],
        [i.a.AUCTION]: (e, t) => {
          var {
            currentActivity: n,
            kdtId: r
          } = t, {
            status: a
          } = n;
          return "ENDED" === a || "SOLD_OUT" === a ? [{
            name: "homepage",
            main: [{
              text: "查看店铺其他商品"
            }],
            btnActive: o.a.SUBMIT,
            submitAction: o.d.JUMP_LINK,
            link: {
              pageName: "Home",
              query: {
                kdt_id: r
              },
              type: "switchTab"
            },
            primary: !0
          }] : [{
            main: [{
              text: "立即拿下"
            }],
            skuScene: o.c.BUY,
            accountUnionScene: s.a.NORMAL_BUY,
            btnActive: o.a.OPEN_SKU,
            activityName: i.a.AUCTION
          }]
        },
        [i.a.HELPCUT]: (e, t) => {
          var {
            currentActivity: n,
            kdtId: r,
            sku: a,
            query: c
          } = t, {
            isStart: u,
            isEnd: d,
            status: l
          } = n, {
            oldMinPrice: p,
            minPrice: h
          } = a[i.a.HELPCUT];
          if (d && !(l > 1)) return [{
            name: "homepage",
            main: [{
              text: "查看店铺其他商品"
            }],
            btnActive: o.a.SUBMIT,
            submitAction: o.d.JUMP_LINK,
            link: {
              pageName: "Home",
              query: {
                kdt_id: r
              },
              type: "switchTab"
            },
            primary: !0
          }];
          var f = [{
              main: [{
                text: "单独购买"
              }, {
                text: "￥" + g()(p)
              }],
              skuScene: o.c.SEL_SKU,
              accountUnionScene: s.a.NORMAL_BUY,
              btnActive: "openSku",
              activityName: "goods"
            }],
            v = null;
          if (u) switch (l) {
            case 2:
              v = {
                forbid: !0,
                skuScene: o.c.DISABLE,
                main: [{
                  text: "已砍价购买"
                }],
                disabled: !0,
                activityName: i.a.HELPCUT
              };
              break;
            case 3:
              v = {
                main: [{
                  text: "正在砍价"
                }],
                activityName: i.a.HELPCUT,
                primary: !0,
                btnActive: o.a.SUBMIT,
                submitAction: i.j.UMP_GO_2_WEBVIEW,
                link: {
                  pageName: "BargainPurchase",
                  query: {
                    umpAlias: c.umpAlias,
                    sponsorId: n.sponsorId,
                    umpActivityId: n.activityId,
                    kdtId: r
                  }
                }
              };
              break;
            default:
              v = {
                main: [{
                  text: "立即砍价拿"
                }, {
                  text: "￥" + g()(h)
                }],
                primary: !0,
                activityName: i.a.HELPCUT,
                skuScene: o.c.RESERVATION,
                btnActive: o.a.WX_SUBSCRIBE,
                accountUnionScene: s.a.NORMAL_BUY,
                submitAction: i.j.START_CUT,
                subscribeSceneV2: "helpcut",
                currentActivity: n,
                kdtId: r
              };
          }
          return v && f.push(v), f
        },
        [i.a.INSOURCING_FISSION]: (e, t) => {
          var {
            currentActivity: n,
            sku: r,
            kdtId: a
          } = t, {
            hasBuyThreshold: c,
            isStart: u,
            isEnd: d,
            havingInSourcingCouponNum: l
          } = n, {
            minPrice: p,
            oldMinPrice: h,
            list: f,
            spuPrice: v
          } = r[i.a.INSOURCING_FISSION], m = l >= (() => {
            if (0 === f.length) return v.needInSourcingCouponNum || 0;
            var e = f.filter(e => !e.notJoinActivity && e.stockNum > 0).sort((e, t) => e.needInSourcingCouponNum - t.needInSourcingCouponNum)[0];
            return e && e.needInSourcingCouponNum || 0
          })();
          if (!u || d) return [{
            main: [{
              text: "查看店铺其他商品"
            }],
            skuScene: o.c.JUMP_LINK,
            primary: !0,
            btnActive: o.a.SUBMIT,
            submitAction: o.d.JUMP_LINK,
            link: {
              pageName: "Home",
              query: {
                kdt_id: a
              },
              type: "switchTab"
            }
          }];
          var y = [{
            main: [{
              text: "内购价购买"
            }, {
              text: "￥" + g()(p)
            }],
            primary: !0,
            skuScene: o.c.BUY,
            accountUnionScene: s.a.NORMAL_BUY,
            activityName: i.a.INSOURCING_FISSION,
            btnActive: m ? o.a.OPEN_SKU : o.a.SUBMIT,
            submitAction: m ? void 0 : i.j.SHOW_IN_SOURCING_FISSION_COUPON
          }];
          return c && y.unshift({
            main: [{
              text: "直接购买"
            }, {
              text: "￥" + g()(h)
            }],
            skuScene: o.c.SEL_SKU,
            accountUnionScene: s.a.NORMAL_BUY,
            btnActive: "openSku",
            activityName: "goods"
          }), y
        },
        [i.a.SECOND_HALF_DISCOUNT]: (e, t) => {
          var {
            marketing: {
              buttonUmpTextModel: n
            },
            limitedEstimate: a = {}
          } = t, i = e.findIndex(e => e.primary), {
            buttonUmpText: o = {}
          } = a;
          return n && n.umpTag && !o.umpTag && e[i].main.push({
            text: n.umpTag
          }), e.map(e => Object(r.a)({}, e))
        },
        [i.a.TUAN]: (e, t) => {
          var {
            currentActivity: n,
            kdtId: r
          } = t, {
            isEnd: a,
            isCash: c,
            state: u
          } = n;
          if (a) return [{
            name: "homepage",
            main: [{
              text: "查看店铺其他商品"
            }],
            btnActive: o.a.SUBMIT,
            submitAction: o.d.JUMP_LINK,
            link: {
              pageName: "Home",
              query: {
                kdt_id: r
              },
              type: "switchTab"
            },
            primary: !0
          }];
          var d = [];
          c && d.push({
            main: [{
              text: "邀请下单返现"
            }],
            skuScene: o.c.RESERVATION,
            btnActive: o.a.SUBMIT,
            accountUnionScene: s.a.NORMAL_BUY,
            submitAction: i.j.UMP_SHOW_SHARE
          });
          var l = null;
          switch (u) {
            case "on":
              l = {
                main: [{
                  text: "立即参团"
                }],
                primary: !0,
                skuScene: o.c.BUY,
                accountUnionScene: s.a.GROUP_BUY,
                btnActive: "openSku",
                activityName: i.a.TUAN
              };
              break;
            default:
              l = {
                main: [{
                  text: "即将开始"
                }],
                primary: !0,
                disabled: !0,
                skuScene: o.c.DISABLE
              };
          }
          return l && d.push(l), d
        },
        [i.a.LUCKYDRAW_GROUP]: (e, t) => {
          var {
            currentActivity: n,
            kdtId: r
          } = t, {
            isStart: a,
            isEnd: c,
            activityId: u,
            ownGroup: d
          } = n, l = (() => {
            var e = {
              kdt_id: r,
              activity_id: u
            };
            if (d) {
              var {
                alias: t,
                orderNo: n
              } = d;
              t && (e.group_alias = t), n && (e.order_no = n)
            }
            return {
              pageName: "LotteryDetail",
              query: e
            }
          })();
          if (c || !a) return [{
            name: "homepage",
            main: [{
              text: "查看店铺其他商品"
            }],
            btnActive: o.a.SUBMIT,
            submitAction: o.d.JUMP_LINK,
            link: {
              pageName: "Home",
              query: {
                kdt_id: r
              },
              type: "switchTab"
            },
            primary: !0
          }];
          var p = [],
            h = null;
          switch (n.buttonType) {
            case 1:
              h = {
                main: [{
                  text: "立即0元开团"
                }],
                primary: !0,
                skuScene: o.c.BUY,
                accountUnionScene: s.a.GROUP_BUY,
                btnActive: o.a.WX_SUBSCRIBE,
                activityName: i.a.LUCKYDRAW_GROUP,
                subscribeSceneV2: "lottery"
              };
              break;
            case 2:
              h = {
                main: [{
                  text: "查看我的团"
                }],
                link: l,
                skuScene: o.c.JUMP_LINK,
                activityName: i.a.HELPCUT,
                primary: !0,
                btnActive: o.a.SUBMIT,
                submitAction: i.j.UMP_GO_2_WEBVIEW
              };
              break;
            default:
              h = {
                name: "homepage",
                main: [{
                  text: "查看店铺其他商品"
                }],
                btnActive: o.a.SUBMIT,
                submitAction: o.d.JUMP_LINK,
                link: {
                  pageName: "Home",
                  query: {
                    kdt_id: r
                  },
                  type: "switchTab"
                },
                primary: !0
              };
          }
          return h && p.push(h), p
        },
        [i.a.COUPON]: (e, t) => {
          var n = [...e],
            a = e.findIndex(e => e.primary),
            i = [o.c.BUY, o.c.SEL_SKU],
            {
              marketing: {
                buttonUmpTextModel: s
              }
            } = t;
          if (s && -1 !== a && n[a].main.length < 2) {
            var {
              umpTag: c,
              buyButtonText: u
            } = s;
            u && i.includes(n[a].skuScene) ? n[a].main = [{
              text: u
            }, {
              text: c
            }] : n[a].main.push({
              text: c
            })
          }
          return n.map(e => Object(r.a)({}, e))
        },
        [i.a.FCODE]: (e, t) => e.map(e => Object(r.a)({}, e, {
          activityName: i.a.FCODE,
          skuScene: o.c.BUY
        })),
        [i.a.LIMITED_SECKILL]: function(e, t) {
          void 0 === e && (e = []);
          var {
            currentActivity: n,
            alias: r
          } = t, {
            startAt: a,
            endAt: c
          } = n;
          return (e => e - +new Date < 0)(c) || (e => e - +new Date > 0)(a) ? e : [{
            main: [{
              text: "马上抢"
            }],
            primary: !0,
            skuScene: o.c.BUY,
            accountUnionScene: s.a.NORMAL_BUY,
            btnActive: o.a.OPEN_SKU,
            activityName: i.a.LIMITED_SECKILL
          }]
        },
        [i.a.PRODUCT_LAUNCH]: (e, t) => {
          if (Boolean(t.goodsActivity.waitToSold)) {
            var n = [e[0]],
              r = e.find(e => e.skuScene === o.c.SUBSCRIBE),
              a = {
                main: [{
                  text: "立即预约"
                }],
                primary: !0,
                skuScene: o.c.CUSTOM,
                btnActive: "submit",
                accountUnionScene: s.a.NORMAL_BUY,
                submitAction: i.j.PRODUCT_LAUNCH_RESERVATION,
                currentActivity: t.currentActivity,
                goodsId: t.alias
              };
            return r && (a.startSoldTime = r.startSoldTime), n.push(a), n
          }
          return e
        },
        [i.a.ESTIMATA_PRICE]: (e, t) => {
          var {
            limitedEstimate: n = {},
            umpActivity: a = {},
            extra: i = {}
          } = t, o = e.findIndex(e => e.primary), s = Object.keys(a).indexOf("coupon") > -1, c = n && n.buttonUmpText && 1 === (null == n ? void 0 : n.num) && !s, {
            buttonUmpText: u = {}
          } = n, {
            buyButtonText: d
          } = i, l = [...e];
          if (c && -1 !== o) {
            var {
              umpTag: p,
              buyButtonText: h
            } = u;
            !d && h ? l[o].main = [{
              text: h
            }, {
              text: p
            }] : l[o].main.push({
              text: u.umpTag
            })
          }
          return l.map(e => Object(r.a)({}, e))
        }
      },
      _ = {
        [i.a.GROUP_ON]: (e, t) => {
          var {
            currentActivity: n
          } = t, {
            isStart: r
          } = n;
          return r ? e : {
            text: "活动即将开始"
          }
        },
        [i.a.TIMELIMITED_DISCOUNT]: (e, t) => {
          var {
            currentActivity: n
          } = t, {
            isStart: r
          } = n;
          return r ? e : {
            text: "活动即将开始"
          }
        },
        [i.a.SECKILL]: (e, t) => {
          var {
            currentActivity: n
          } = t, {
            startAt: r,
            current: a = +new Date,
            endAt: i,
            isCheckRight: o,
            isPassCheck: s,
            buyNeedBook: c
          } = n;
          return l(i, a) ? {
            text: "活动已结束"
          } : !d(r, a) || o && (!o || s || c) ? d(r, a) && o && !s && c ? {
            text: "活动即将开始，预约后才能参加秒杀活动哦"
          } : d(r, a) && o && s ? {
            text: "您已成功预约，活动暂未开始，也可非活动价购买哦"
          } : d(r, a) || !o || s ? e : {
            text: "您未预约此活动，无法参加秒杀，下次记得预约哦"
          } : {
            text: "秒杀活动即将开始"
          }
        },
        [i.a.DEPOSIT_EXPANSION]: (e, t) => {
          var {
            currentActivity: n
          } = t, {
            isStart: r
          } = n;
          return r ? e : {
            text: "活动即将开始"
          }
        },
        [i.a.HELP_DEPOSIT_EXPANSION]: (e, t) => {
          var {
            currentActivity: n
          } = t, {
            isStart: r
          } = n;
          return r ? e : {
            text: "活动即将开始"
          }
        },
        [i.a.AUCTION]: (e, t) => {
          var {
            currentActivity: n
          } = t, {
            status: r
          } = n;
          switch (r) {
            case "ENDED":
              "活动已结束";
              break;
            case "SOLD_OUT":
              "已售罄";
          }
          return e
        },
        [i.a.HELPCUT]: (e, t) => {
          var {
            currentActivity: n
          } = t, {
            isStart: r,
            isEnd: a,
            status: i
          } = n;
          return r ? a && !(i > 1) ? {
            text: "砍价活动已结束，去看看其他商品吧"
          } : e : {
            text: "活动即将开始"
          }
        },
        [i.a.INSOURCING_FISSION]: (e, t) => {
          var n, {
              currentActivity: r
            } = t,
            {
              startAt: a,
              endAt: i
            } = r,
            o = (n = +new Date, a - n > 0),
            s = (() => {
              var e = +new Date;
              return i - e < 0
            })();
          return o ? {
            text: "活动即将开始"
          } : s ? {
            text: "活动已结束，去看看其他商品吧"
          } : e
        },
        [i.a.TUAN]: (e, t) => {
          var {
            currentActivity: n
          } = t, {
            isStart: r,
            isEnd: a
          } = n;
          return r ? a ? {
            text: "活动已结束"
          } : e : {
            text: "活动即将开始"
          }
        },
        [i.a.LUCKYDRAW_GROUP]: (e, t) => {
          var {
            currentActivity: n,
            kdtId: r
          } = t, {
            isStart: a,
            isEnd: i,
            activityId: o
          } = n;
          return a ? i ? {
            text: "查看中奖结果",
            url: m.a.add("https://h5.youzan.com/wscump/collage/lottery/detail", {
              kdt_id: r,
              activity_id: o
            })
          } : e : {
            text: "活动即将开始"
          }
        }
      },
      O = {
        buttonFormaterFactory(e, t, n) {
          var i = b[e];
          if (i) {
            var {
              bigButtons: o = [],
              disabledBigButton: s
            } = t, c = Object(a.a)(t, y), u = "presentExchange" === e;
            o.some(e => e.waitToSold);
            if (u) {
              var d = i(o, n);
              return Object(r.a)({
                bigButtons: d
              }, c, {
                disabledBigButton: null
              })
            }
            var l = i(o, Object(r.a)({}, n, t));
            return Object(r.a)({
              bigButtons: l
            }, c, {
              disabledBigButton: s
            })
          }
          return t
        },
        tipsFormaterFactory(e, t, n) {
          var r = _[e];
          return r ? r(t, n) : t
        }
      }
  },
  sXPE: function(e, t, n) {
    var r;
    n.d(t, "a", function() {
      return a
    }), n.d(t, "f", function() {
      return i
    }), n.d(t, "g", function() {
      return o
    }), n.d(t, "e", function() {
      return s
    }), n.d(t, "b", function() {
      return c
    }), n.d(t, "d", function() {
      return u
    }), n.d(t, "c", function() {
      return d
    }), n.d(t, "h", function() {
      return l
    });
    var a = {
        DISCOUNT: "discount",
        DISCOUNT_INVITE: "discountInvite",
        CUSTOMER_DISCOUNT: "customerDiscount",
        POINTS: "pointsExchange",
        GOODS_SCAN: "goodsScan",
        SCRM_CARRIER: "scrmCarrier"
      },
      i = {
        DISCOUNT: "discount",
        DISCOUNT_INVITE: "discountInvite",
        POINTS: "points"
      },
      o = [i.POINTS, i.DISCOUNT, a.DISCOUNT_INVITE],
      s = ((r = {})[a.CUSTOMER_DISCOUNT] = "会员价", r[a.POINTS] = "积分兑换", r[a.GOODS_SCAN] = "扫码优惠价", r),
      c = {
        POINTS: 5
      },
      u = {
        FREE_MEMBER: 1,
        PAY_MEMBER: 2,
        FREE_BENEFIT_CARD: 3,
        PAY_BENEFIT_CARD: 4
      },
      d = {
        LIMIT: 1,
        ALLOW: 0
      },
      l = {
        LIMIT_BUY_GUIDE: "limitBuyGuide"
      }
  },
  sbwY: function(e, t, n) {
    var r = n("Fcif"),
      a = n("svh/"),
      i = n("jA1y"),
      o = n("3tyi"),
      s = n("z24M"),
      c = n("7WjY"),
      u = new a.d({
        state: {
          config: {
            grantType: "yz_union",
            weappType: "",
            version: Object(s.a)("userVersion")
          },
          pluginData: {},
          token: {},
          shop: c.a,
          sceneData: {},
          userInfo: {
            poi: null
          }
        },
        mutations: {
          UPDATE_TOKEN(e, t) {
            e.token = t;
            var n = Object(o.a)(t, ["avatar", "gender", "kdtId", "mobile", "openId", "userId", "yzUserId", "nickName", "fansType", "viewTrack2", "platformFansId", "isDefaultAvatar"]);
            n.nickname = n.nickName, delete n.nickName, e.userInfo = n
          },
          UPDATE_CONFIG(e, t) {
            Object.assign(e.config, t), e.config.appId && i.e({
              appId: e.config.appId,
              version: e.config.version
            })
          },
          UPDATE_PLUGIN_DATA(e, t) {
            var {
              pluginData: n
            } = e;
            n.pluginHostAppId = t.appId, n.pluginHostOpenId = t.openId
          },
          UPDATE_USER_INFO(e, t) {
            e.userInfo = Object(r.a)({}, e.userInfo, t, {
              isDefaultAvatar: !1
            })
          },
          UPDATE_SCENE_DATA(e, t) {
            e.sceneData = Object(r.a)({}, e.sceneData, t)
          },
          UPDATE_SHOP_DATA(e, t) {
            void 0 === t && (t = {}), e.shop = Object(r.a)({}, e.shop, t)
          }
        }
      });
    t.a = u
  },
  tkH8: function(e, t, n) {
    function r(e, t) {
      void 0 === t && (t = 2);
      for (var n = e + ""; n.length < t;) n = "0" + n;
      return n
    }
    n.d(t, "c", function() {
      return a
    }), n.d(t, "b", function() {
      return i
    }), n.d(t, "a", function() {
      return o
    });

    function a(e) {
      return {
        days: Math.floor(e / 864e5),
        hours: Math.floor(e % 864e5 / 36e5),
        minutes: Math.floor(e % 36e5 / 6e4),
        seconds: Math.floor(e % 6e4 / 1e3),
        milliseconds: Math.floor(e % 1e3)
      }
    }

    function i(e, t) {
      var {
        days: n
      } = t, {
        hours: a,
        minutes: i,
        seconds: o,
        milliseconds: s
      } = t;
      return -1 === e.indexOf("DD") ? a += 24 * n : e = e.replace("DD", r(n)), -1 === e.indexOf("HH") ? i += 60 * a : e = e.replace("HH", r(a)), -1 === e.indexOf("mm") ? o += 60 * i : e = e.replace("mm", r(i)), -1 === e.indexOf("ss") ? s += 1e3 * o : e = e.replace("ss", r(o)), e.replace("SSS", r(s, 3))
    }

    function o(e, t) {
      return Math.floor(e / 1e3) === Math.floor(t / 1e3)
    }
  },
  tqDJ: function(e, t, n) {
    n.d(t, "a", function() {
      return f
    });
    var r = n("a1Mm"),
      a = n("zMoS"),
      i = n("taYb"),
      o = n("1F1z");

    function s(e) {
      return e > 9 ? e : "0" + e
    }

    function c(e) {
      var t = new Date(e);
      return s(t.getMonth() + 1) + "." + s(t.getDate()) + " " + s(t.getHours()) + ":" + s(t.getMinutes()) + ":" + s(t.getSeconds())
    }
    var u = n("Hhx2"),
      d = n("KQ2A"),
      l = getApp(),
      p = ["降价拍", "团购返现", "多人拼团", "周期购", "定金膨胀", "阶梯拼团", "积分兑换"],
      h = {
        customerDiscount: "会员折扣",
        timelimitedDiscount: "限时折扣"
      };

    function f(e, t) {
      if (wx.showToast({
          title: "加载中",
          icon: "loading"
        }), !e) return Promise.reject("alias is " + e);
      var {
        timingSaleHideBuyBtnInSku: n
      } = t || {};
      return Promise.all([o.a.getSkuData(e, t), l.getShopConfigData()]).then(e => o.a.getActivity(e[0].brief.item_id).then(t => t && p.some(e => t.indexOf(e) >= 0) ? Promise.reject() : e)).then(t => {
        var o, [s, p = {}] = t;
        wx.hideToast();
        var f, g, {
            brief: v,
            sku: m = {},
            components: y = [],
            dataVersion: b
          } = s,
          {
            item_id: _,
            title: O,
            presale: S = 0,
            presale_info_new: w,
            quota_used: I,
            startSoldTime: P
          } = v,
          k = Object(a.a)(s, "activity.goods_preference", {}),
          j = k.type || "",
          x = Object(a.a)(k, "is_started", !(b && "v1" === b)),
          T = k.priceTitle || "",
          E = +v.start_sale_num || 1,
          A = i.a.toCamelCase(s.item_sale_prop_list || []),
          C = E > 1 ? [E + "件起售"] : [],
          {
            hide_stock: D,
            cart_text: M = "加入购物车"
          } = m,
          {
            picture: N,
            quota: L,
            is_virtual: U
          } = v,
          R = "default",
          B = !0,
          F = !0,
          q = !1,
          H = !1,
          z = "立即购买";
        if (N = Object(a.a)(N, "[0].url", ""), L = +L ? Math.max(L, 1) : 0, U = !!+U, D = !(!+D && !+Object(a.a)(y, "0.hide_stock")), "depositExpansion" === j || U && 3 === Object(a.a)(s, "virtual.validity_type") || Array.isArray(m)) return Promise.reject({
          jumpToGoodsDetail: !0
        });
        if (0 === Object(a.a)(m, "stock_num")) return Promise.reject("该商品已售罄");
        if (w && (f = +w.pre_sale_type || 0, w.pre_sale_start && Date.now() < w.pre_sale_start)) return Promise.reject("该商品未到预售时间");
        1 === f && (R = "presale", g = function(e) {
          var {
            extend: t,
            deposit: n,
            deposit_ratio: r
          } = e, {
            pre_sale_end: a,
            etd_start: i,
            etd_days: o,
            etd_type: s
          } = t, u = Date.now() > a, d = c(a) + " 预售结束";
          return {
            deposit: n,
            depositRatio: r,
            isPresaleOutDate: u,
            presaleShipTimeStr: 1 == +s ? "尾款支付" + o + "天后发货" : c(i) + " 开始发货",
            presaleEndTimeStr: d
          }
        }(m)), "groupOn" === j && (H = !0, L = +Object(a.a)(y, "0.quota", L)), "customerDiscount" === j && (q = !0);
        try {
          ("customerDiscount" === j || "timelimitedDiscount" === j && x) && function(e, t) {
            e.originPrice = e.origin || e.original_price || e.price, e.price = t.show_price;
            var n = t.skus || {};
            e.list.forEach(e => {
              e.originPrice = e.origin || e.price, e.price = n[e.id] && n[e.id].price || e.price
            })
          }(m, k)
        } catch (e) {}(U || +S && !(0 === f) || 1 == +p.hide_shopping_cart) && (B = !1, z = "下一步"), Object(u.b)(m) && (z = "领券购买"), B && 1 != +p.show_buy_btn && (F = !1, M = "确定");
        var {
          noneSku: G,
          messages: W,
          cateringGoodsExtraModel: K,
          list: Y,
          itemDataModel: V,
          price: X,
          collectionId: J
        } = i.a.toCamelCase(m);
        if ((G || Y.length <= 1) && !F && !(null != W && W.length) > 0 && (null == K || null == (o = K.ingredientList) || !o.length) && E <= 1 && (!A || !A.length)) {
          var $, Z, Q = 1 === Y.length ? Y[0].id : J,
            ee = null != Y && null != ($ = Y[0]) && $.sku ? JSON.parse(null == Y || null == (Z = Y[0]) ? void 0 : Z.sku).v : "";
          return Object(d.a)({
            couponId: null,
            goodsId: _,
            messages: [],
            cartMessages: [],
            num: 1,
            price: X,
            skuId: Q,
            kdtId: l.getKdtId(),
            propertyIds: [],
            itemDataModel: V,
            activityType: 0,
            activityId: 0,
            activityAlias: ""
          }, {
            params: {
              num: 1,
              goods_id: _,
              goods_name: O,
              sku_id: Q,
              sku_name: ee ? [ee] : [],
              no_sku: G ? 1 : 0
            }
          }).then(() => {
            if (l.getYouZanYunSdk) {
              var e = getCurrentPages(),
                t = "/" + e[e.length - 1].route;
              l.getYouZanYunSdk().app.trigger("beforeAddCart", {
                skuId: Q,
                title: O,
                id: _,
                selectedNum: 1,
                pageUrl: t
              })
            }
            l.trigger("component:sku:cart", {
              type: "add"
            })
          }).catch(e => {
            var {
              msg: t
            } = e;
            wx.showToast({
              title: t,
              icon: "none"
            })
          }), Promise.reject({
            jumpToGoodsDetail: !1
          })
        }
        L > 0 && C.push("每人限购" + L + "件"), !T && j && (T = h[j]);
        var te = {
          id: _,
          alias: e,
          title: O,
          picture: Object(r.a)(N, "!300x300.jpg"),
          originPicture: N,
          isVirtual: U
        };
        return n && P && Date.now() < 1e3 * P && (F = !1, B = !0), {
          sku: Object(u.a)(m),
          skuGoodsDetail: te,
          type: R,
          quota: L,
          quotaUsed: I,
          quotaText: C.join("，"),
          buyText: z,
          cartText: M,
          showAddCartBtn: B,
          showBuyBtn: F,
          startSaleNum: E,
          itemSalePropList: A,
          hideStock: 1 == +D,
          showGoodsSku: !0,
          extraData: {
            priceTitle: T,
            isGroupon: H,
            isMember: q,
            presaleInfo: g,
            useCustomHeaderPrice: !0
          }
        }
      }).catch(t => {
        var n = !0;
        return t && "string" == typeof t && "不支持会员卡商品" !== t && (n = !1, wx.showToast({
          title: t,
          icon: "none"
        })), "object" == typeof t && !1 === t.jumpToGoodsDetail && (n = !1), n && wx.navigateTo({
          url: "/pages/goods/detail/index?alias=" + e
        }), Promise.reject(t)
      })
    }
  },
  u8kV: function(e, t, n) {
    n.d(t, "a", function() {
      return c
    }), n.d(t, "b", function() {
      return l
    }), n.d(t, "d", function() {
      return p
    });
    var r = n("Fcif"),
      a = n("Qb5n"),
      i = n("AqAW"),
      o = n("UL3R"),
      s = n("svh/");
    Boolean;
    class c {
      constructor() {
        this.props = {}, this.behavior = null, this._init()
      }
      _init() {
        var e = this;
        this.behavior = Behavior({
          created() {
            Object(a.c)(this, {
              props: e.props,
              methods: e.methods
            })
          },
          detached() {
            Object(a.a)(this), this.off(null, null)
          },
          definitionFilter(t) {
            e.props = t.properties || {}, e.methods = t.methods || {}
          },
          methods: Object(r.a)({
            setYZData: a.b
          }, i.a)
        })
      }
      getBehavior() {
        return this.behavior
      }
    }
    var u = ["theme-color", "theme-bg-color", "theme-border-color", "theme-button", "theme-button-plain"],
      d = (t.c = function(e) {
        void 0 === e && (e = {}), e.behaviors = e.behaviors || [];
        var t = new c;
        return e.behaviors.push(t.getBehavior()), e.externalClasses = u.concat(e.externalClasses || []), Component(e)
      }, Behavior({
        created() {
          Object.defineProperty(this, "$dispatch", {
            get() {
              return this.$store.dispatch
            }
          }), Object.defineProperty(this, "$commit", {
            get() {
              return this.$store.commit
            }
          })
        }
      }));

    function l(e) {
      void 0 === e && (e = {}), Object(o.a)(e), e.behaviors = e.behaviors || [];
      var t = new c;
      return e.behaviors.push(t.getBehavior()), e.behaviors.push(d), e.externalClasses = u.concat(e.externalClasses || []), e.mapData = e.mapData || {}, e.getters && (e.mapData = Object(r.a)({}, e.mapData, Object(s.f)(e.getters))), e.state && (e.mapData = Object(r.a)({}, e.mapData, Object(s.h)(e.state))), Object(s.a)(e)
    }

    function p(e) {
      var t = getCurrentPages && getCurrentPages() || [],
        n = t.length > 0 ? t[t.length - 1] : {};
      if (!e) return n;
      for (var r = t.length - 1; r >= 0; r--) {
        var a = t[r];
        if (a && a.__wxWebviewId__ === e.__wxWebviewId__) {
          n = a;
          break
        }
      }
      return n
    }
  },
  uhII: function(e, t, n) {
    n.d(t, "b", function() {
      return r
    });
    var r = {
      general: "#f44",
      "main-bg": "#f44",
      "main-text": "#fff",
      "vice-bg": "#f85",
      "vice-text": "#fff",
      "start-bg": "#FF6060",
      "end-bg": "#FF4444"
    };
    t.a = {
      0: "th0",
      1: "th1",
      2: "th2",
      3: "th3",
      4: "th4",
      5: "th5",
      6: "th6",
      7: "th7",
      8: "th8",
      9: "th9",
      10: "th10",
      11: "th11",
      12: "th12",
      13: "th13",
      14: "th14"
    }
  },
  umDW: function(e, t, n) {
    n.d(t, "b", function() {
      return o
    }), n.d(t, "a", function() {
      return s
    });
    var r = n("Fcif"),
      a = n("2wjL"),
      i = {
        title: "",
        domain: "https://h5.youzan.com",
        webViewPage: "/pages/common/webview-page/index",
        method: "navigateTo"
      };

    function o(e, t) {
      return void 0 === t && (t = i.domain), t && !(e => 0 === e.indexOf("http") || 0 === e.indexOf("//"))(e) ? t + e : (e.startsWith("http://") && (e = e.replace("http://", "https://")), e)
    }

    function s(e, t) {
      e = o(e, (t = Object(r.a)({}, i, t)).domain), t.query && (e = a.a.add(e, t.query, !0));
      var n = {
        src: e,
        title: t.title
      };
      wx[t.method]({
        url: a.a.add(t.webViewPage, n, !0)
      })
    }
  },
  uzJ0: function(e, t, n) {
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.default = void 0;
    var r = function(e) {
      return (parseFloat(e) / 100).toFixed(2)
    };
    t.default = r, e.exports = t.default
  },
  v6dD: function(e, t, n) {
    var r = n("DXqK");
    n.d(t, "a", function() {
      return r.c
    }), n.d(t, "b", function() {
      return r.d
    });
    r.b
  },
  vB9s: function(e, t, n) {
    var r = n("By4c");
    t.a = r.a
  },
  vGYG: function(e, t, n) {
    n.d(t, "a", function() {
      return a
    });
    var r = n("0hwI");

    function a() {
      return r.a.get({
        url: "/wscdeco/jump-logic.json"
      })
    }
  },
  vMVM: function(e, t, n) {
    var r = n("jgJv"),
      a = Object.prototype,
      i = a.hasOwnProperty,
      o = a.toString,
      s = r ? r.toStringTag : void 0;
    e.exports = function(e) {
      var t = i.call(e, s),
        n = e[s];
      try {
        e[s] = void 0;
        var r = !0
      } catch (e) {}
      var a = o.call(e);
      return r && (t ? e[s] = n : delete e[s]), a
    }
  },
  vgDv: function(e, t, n) {
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.default = void 0;
    var r = function(e) {
      var t = {
        "&amp;": "&",
        "&lt;": "<",
        "&gt;": ">",
        "&quot;": "\"",
        "&#x27;": "'"
      };
      return "".concat(e).replace(/(&amp;|&lt;|&gt;|&quot;|&#x27;)/g, function(e) {
        return t[e]
      })
    };
    t.default = r, e.exports = t.default
  },
  vpHN: function(e, t, n) {
    n.d(t, "a", function() {
      return h
    }), n.d(t, "b", function() {
      return f
    });
    n("Fcif");
    var r = n("PKOW"),
      a = "packages",
      i = {
        TRANS: a + "/home/tab/one",
        EXT: a + "/ext-home/tab/one",
        OLD: a + "/old-home/tab/one"
      },
      o = {
        TRANS: a + "/home/tab/two",
        EXT: a + "/ext-home/tab/two",
        OLD: a + "/old-home/tab/two"
      },
      s = {
        TRANS: a + "/home/tab/three",
        EXT: a + "/ext-home/tab/three",
        OLD: a + "/old-home/tab/three"
      },
      c = {
        TRANS: a + "/home/dashboard/index",
        EXT: a + "/ext-home/dashboard/index",
        OLD: a + "/old-home/dashboard/index"
      },
      u = a + "/usercenter/dashboard/index",
      d = "pages/usercenter/dashboard/index",
      l = n("QFll"),
      p = {
        [r.c[r.b.CART].TRANS]: {
          subRoutes: [r.c[r.b.CART].NEW, r.c[r.b.CART].OLD]
        },
        [i.TRANS]: {
          subRoutes: [i.TEE, i.EXT, i.OLD]
        },
        [o.TRANS]: {
          subRoutes: [o.TEE, o.EXT, o.OLD]
        },
        [s.TRANS]: {
          subRoutes: [s.TEE, s.EXT, s.OLD]
        },
        [c.TRANS]: {
          subRoutes: [c.TEE, c.EXT, c.OLD]
        },
        [l.a.OLD]: {
          subRoutes: [l.a.OLD, l.a.NEW]
        },
        [u]: {
          subRoutes: [d]
        }
      };

    function h(e) {
      var t = e;
      if (!p[t])
        for (var n = Object.keys(p), r = 0; r < n.length; r++) {
          var {
            subRoutes: a
          } = p[n[r]];
          if (a && a.length)
            for (var i = 0; i < a.length; i++)
              if (e === a[i]) {
                t = n[r];
                break
              } if (t !== e) break
        }
      return t
    }

    function f(e) {
      var {
        customPage: t,
        pagePath: n
      } = e, r = getApp(), {
        isRetailApp: a
      } = r.globalData, i = t || n.startsWith("pages/home") || n.startsWith("pages/common/webview-page") ? n : n.replace(/^pages(-|\/)/, "packages/");
      return l.b.test(i) && (a && i === l.c.WSC && (i = l.c.RETAIL), a || i !== l.c.RETAIL || (i = l.c.WSC)), i
    }
  },
  vtdp: function(e, t, n) {
    n.d(t, "a", function() {
      return r
    });
    var r = {
      title: String,
      loading: Boolean,
      showToolbar: Boolean,
      cancelButtonText: {
        type: String,
        value: "取消"
      },
      confirmButtonText: {
        type: String,
        value: "确认"
      },
      visibleItemCount: {
        type: Number,
        value: 6
      },
      itemHeight: {
        type: Number,
        value: 44
      }
    }
  },
  vzTj: function(e, t, n) {
    n.d(t, "a", function() {
      return s
    });
    var r = n("sEE4"),
      a = n.n(r),
      i = n("gf3M"),
      o = n.n(i);
    class s {
      constructor(e) {
        this.ctx = e.ctx
      }
    }
    s.widgets = {
      TradeBuyPrivacyBill: a()
    }, s.components = {
      PrivacyBillRulePopup: o()
    }
  },
  w4n3: function(e, t, n) {
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.default = void 0;
    var r = o(n("6UHP")),
      a = o(n("ajWA")),
      i = o(n("s0cO"));

    function o(e) {
      return e && e.__esModule ? e : {
        default: e
      }
    }
    var s = function e(t) {
      var n, o = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
      if ((0, a.default)(t) && t.length > 0) n = [];
      else {
        if (!((0, r.default)(t) && Object.keys(t).length > 0)) return t;
        n = {}
      }
      for (var s = Object.keys(t), c = s.length, u = 0; u < c; u++) {
        var d = s[u],
          l = t[d];
        o && (l = e(l));
        var p = "string" == typeof d ? (0, i.default)(d) : d;
        n[p] = l
      }
      return n
    };
    t.default = s, e.exports = t.default
  },
  w5ta: function(e, t, n) {
    var r = n("PYDc"),
      a = n("XXCu"),
      i = n("DZMJ"),
      o = n("i0JV"),
      s = n("xKNE");

    function c(e) {
      var t = -1,
        n = null == e ? 0 : e.length;
      for (this.clear(); ++t < n;) {
        var r = e[t];
        this.set(r[0], r[1])
      }
    }
    c.prototype.clear = r, c.prototype.delete = a, c.prototype.get = i, c.prototype.has = o, c.prototype.set = s, e.exports = c
  },
  wB7X: function(e, t, n) {
    n.d(t, "f", function() {
      return r
    }), n.d(t, "a", function() {
      return a
    }), n.d(t, "e", function() {
      return i
    }), n.d(t, "b", function() {
      return o
    }), n.d(t, "c", function() {
      return s
    }), n.d(t, "d", function() {
      return c
    });
    var r = "#ee0a24",
      a = "#1989fa",
      i = "#07c160",
      o = "#323233",
      s = "#969799",
      c = "#DCDEE0"
  },
  wGFT: function(e, t, n) {
    n.d(t, "a", function() {
      return a
    });
    var r = n("US/N"),
      a = e => Object(r.default)({
        path: "/wscgoods/poster/card/image-update.json",
        method: "POST",
        withCredentials: !0,
        data: {
          itemId: e
        }
      })
  },
  wSeO: function(e, t, n) {
    n.d(t, "a", function() {
      return s
    }), n.d(t, "b", function() {
      return c
    });
    var r = n("BZkp"),
      a = n("1pB4"),
      [i] = Object(r.l)("vant-tee/relations", {});

    function o(e, t, n) {
      var r = i();
      return r[e] = r[e] || {}, r[e][t] = r[e][t] || {
        parent: null,
        children: [],
        onEffect() {}
      }, r[e][t]
    }

    function s(e, t) {
      return {
        mixin: {
          props: {
            pid: String
          },
          created() {
            if (this.pid) {
              var n = o(e, this.pid, this.$root);
              Object(a.c)(t) && (n.onEffect = t.bind(this)), n.parent = this, Object.defineProperty(this, "children", {
                get: () => n.children || []
              })
            }
          },
          destroyed() {
            var t = o(e, this.pid, this.$root);
            delete t.parent, delete t.onEffect
          }
        }
      }
    }

    function c(e, t) {
      return void 0 === t && (t = !0), {
        mixin: {
          props: {
            pid: String
          },
          created() {
            if (this.pid) {
              var n = o(e, this.pid, this.$root);
              n.children.push(this), Object.defineProperties(this, {
                parent: {
                  get: () => n.parent
                }
              }), t && Object.defineProperties(this, {
                index: {
                  get() {
                    return n.children.indexOf(this)
                  }
                }
              })
            }
          },
          mounted() {
            var t = o(e, this.pid, this.$root);
            Object(a.c)(t.onEffect) && t.onEffect(this)
          },
          destroyed() {
            var t = o(e, this.pid, this.$root);
            t.children = t.children.filter(e => e !== this), setTimeout(() => {
              Object(a.c)(t.onEffect) && t.onEffect(this)
            })
          }
        }
      }
    }
  },
  wYCQ: function(e, t, n) {
    n.d(t, "f", function() {
      return s
    }), n.d(t, "p", function() {
      return c
    }), n.d(t, "r", function() {
      return u
    }), n.d(t, "g", function() {
      return d
    }), n.d(t, "q", function() {
      return l
    }), n.d(t, "a", function() {
      return p
    }), n.d(t, "s", function() {
      return h
    }), n.d(t, "h", function() {
      return f
    }), n.d(t, "b", function() {
      return g
    }), n.d(t, "i", function() {
      return v
    }), n.d(t, "j", function() {
      return m
    }), n.d(t, "e", function() {
      return y
    }), n.d(t, "d", function() {
      return b
    }), n.d(t, "c", function() {
      return _
    }), n.d(t, "n", function() {
      return O
    }), n.d(t, "m", function() {
      return S
    }), n.d(t, "l", function() {
      return w
    }), n.d(t, "o", function() {
      return I
    });
    var r = n("POYE"),
      a = n("2wjL"),
      i = n("SVbq"),
      o = n("/duV");
    n.d(t, "k", function() {
      return i.z
    });
    var s = e => r.a.cacheKdtId[e],
      c = (e, t) => {
        r.a.cacheKdtId[e] = t
      };

    function u(e) {
      r.a.proxyWxJumpPadding = e
    }
    var d = e => r.a[e],
      l = (e, t, n) => {
        n ? r.a[e][t] = n : (n = t, r.a[e] = n)
      },
      p = e => {
        r.a.proxyUpdateEmitFunc.push(e)
      };

    function h(e) {
      var {
        enterConfig: t,
        path: n
      } = e, a = parseInt(Math.random() * Math.random() * 1e7, 10), i = n ? "tab" + n : "";
      return r.a.switchShopRangeCache[i || a] = t, a
    }

    function f(e) {
      var {
        url: t
      } = e, n = r.a.switchShopRangeCache;
      if (!Object.keys(n).length) return {};
      var {
        enterShopId: i
      } = a.a.getAll(t) || {};
      if (i && n[i]) return n[i];
      var o = t.replace(/^\//, "").replace(/\?.*/, ""),
        s = "tab" + o;
      return o && n[s] ? n[s] : {}
    }

    function g() {
      var e = Object.keys(r.a.switchShopRangeCache);
      e.length && (r.a.switchShopRangeCache = e.filter(e => e.startsWith("tab")))
    }

    function v(e) {
      void 0 === e && (e = 0);
      var t = getCurrentPages();
      if (t.length) {
        var n = t[t.length - e - 1],
          r = a.a.add("" + n.route, n.options);
        return {
          query: n.options,
          path: n.route,
          url: r
        }
      }
      return null
    }

    function m(e) {
      var t = getCurrentPages();
      return !!t.length && t.find(t => t.route === e) > -1
    }

    function y() {
      return i.x && Object(i.z)() && r.a.tabbarNavCacheMap[Object(o.e)()] && !r.a.hqHomeToOtherHome
    }

    function b() {
      if (i.x) {
        var {
          path: e
        } = v();
        if (Object(i.y)(e) && r.a.hqHomeToOtherHome) return !0
      }
    }

    function _(e) {
      return new Promise(t => {
        setTimeout(() => {
          t()
        }, e)
      })
    }

    function O() {
      return d("isWxProxyDone")
    }

    function S() {
      return d("isProxyUpdateKdtId")
    }

    function w() {
      return (Object(i.r)(i.a.HOME) || {}).kdtId
    }

    function I() {
      return w() && !d("isWxProxyDone")
    }
  },
  wfgx: function(e, t, n) {
    var r = n("OPDa");
    t.a = r.a
  },
  xKNE: function(e, t, n) {
    var r = n("FEiO");
    e.exports = function(e, t) {
      var n = this.__data__;
      return this.size += this.has(e) ? 0 : 1, n[e] = r && void 0 === t ? "__lodash_hash_undefined__" : t, this
    }
  },
  xPnu: function(e, t, n) {
    var r = n("zcvR");
    e.exports = function(e, t) {
      var n = r(this, e),
        a = n.size;
      return n.set(e, t), this.size += n.size == a ? 0 : 1, this
    }
  },
  xW8c: function(e, t, n) {
    n.d(t, "a", function() {
      return s
    });
    var r = n("Tewj"),
      a = n("b1kB"),
      i = n.n(a),
      o = n("3uds");
    class s {
      constructor(e) {
        this.ctx = e.ctx, this.widget = i.a;
        var t = "currentPageKey" + Math.round(1e3 * Math.random());
        this.ctx.currentPageKey = t
      }
      onPullDownRefresh() {
        r.default.trigger(o.d)
      }
      onReachBottom() {
        r.default.trigger(o.e)
      }
      onPageShow() {
        r.default.trigger("" + o.c + this.ctx.currentPageKey)
      }
      onPageHide() {
        r.default.trigger("" + o.b + this.ctx.currentPageKey)
      }
    }
    s.widgets = {
      ShowcaseContainer: i()
    }
  },
  xkFB: function(e, t, n) {
    var r = n("CzB4"),
      a = n("WjON"),
      i = n("aBIM"),
      o = n("yVxb"),
      s = n("xPnu");

    function c(e) {
      var t = -1,
        n = null == e ? 0 : e.length;
      for (this.clear(); ++t < n;) {
        var r = e[t];
        this.set(r[0], r[1])
      }
    }
    c.prototype.clear = r, c.prototype.delete = a, c.prototype.get = i, c.prototype.has = o, c.prototype.set = s, e.exports = c
  },
  y8O9: function(e, t, n) {
    var r;
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.default = void 0;
    var a = ((r = n("NWgQ")) && r.__esModule ? r : {
      default: r
    }).default;
    t.default = a, e.exports = t.default
  },
  "yDO/": function(e, t, n) {
    n.d(t, "f", function() {
      return r
    }), n.d(t, "c", function() {
      return a
    }), n.d(t, "b", function() {
      return i
    }), n.d(t, "h", function() {
      return o
    }), n.d(t, "i", function() {
      return s
    }), n.d(t, "a", function() {
      return c
    }), n.d(t, "d", function() {
      return u
    }), n.d(t, "g", function() {
      return d
    }), n.d(t, "e", function() {
      return l
    });
    var r = {
        ONE: "one",
        TWO: "two",
        THREE: "three",
        SWIPE: "swipe",
        HYBRID: "hybrid"
      },
      a = {
        UP: "up",
        SWIPE: "swipe"
      },
      i = {
        CARD: "card",
        SHADOW: "shwdow",
        BORDER: "border",
        SIMPLE: "simple",
        PROMOTION: "promotion",
        WATERFALL: "waterfall"
      },
      o = 12,
      s = 2,
      c = {
        manual: "1",
        auto: "0"
      },
      u = {
        manual: 1,
        auto: 0
      },
      d = {
        OFF: "0",
        ON: "1"
      },
      l = {
        NORMAL: 0,
        LUCKY: 1,
        OLD_NEW: 2,
        LADDER: 3
      }
  },
  yVxb: function(e, t, n) {
    var r = n("zcvR");
    e.exports = function(e) {
      return r(this, e).has(e)
    }
  },
  yq5R: function(e, t, n) {
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.default = function() {
      var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
        t = e.scene;
      t && "string" == typeof t && (t = (t = decodeURIComponent(t).split("&")).reduce(function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
          t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
          n = t.split("=");
        return e[n[0]] = n[1], e
      }, {}), e = Object.assign(e, t));
      return e
    }, e.exports = t.default
  },
  z16c: function(e, t, n) {
    n.d(t, "a", function() {
      return s
    });
    var r = n("u8kV"),
      a = n("8B9M"),
      i = n("qako"),
      o = Behavior({
        methods: {
          getYunSdk: () => Object(a.a)().getYouZanYunSdk(),
          onAsync(e, t, n) {
            var r = Object(a.a)();
            n = n || this || {}, i.a.onAsync.apply(r, [e, t, n])
          },
          offAsync(e, t, n) {
            i.a.offAsync.apply(Object(a.a)(), [e, t, n || this || {}])
          },
          triggerAsync() {
            for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
            return i.a.triggerAsync.apply(Object(a.a)(), t)
          }
        }
      });

    function s(e) {
      return void 0 === e && (e = {}), e.behaviors = e.behaviors || [], e.behaviors.push(o), Object(r.b)(e)
    }
  },
  z1RG: function(e, t, n) {
    var r = {
      __stickyControlMap: {},
      __stickySubscribe: [],
      __stickyCheckList: [],
      getHasStickyTop(e) {
        var t = 0,
          {
            __stickyControlMap: n = {}
          } = this;
        for (var r in n) r !== e && (t += +n[r].height);
        return t
      },
      setStickyControlCheckItem(e, t, n) {
        void 0 === t && (t = 0);
        var {
          __stickyCheckList: r = []
        } = this, a = r.findIndex(t => t.key === e);
        a < 0 && (r.push({
          key: e,
          weight: t
        }), this.__stickyCheckList = r), a > -1 && n && (r[a] = {
          key: e,
          weight: t
        }, this.__stickyCheckList = r)
      },
      getFilterStickyCheckList(e, t, n) {
        var r = e.find(e => e.key === t) || {
          weight: 0
        };
        return n ? e.filter(e => e.weight > r.weight) : e.filter(e => e.weight < r.weight)
      },
      checkStickyControlItem(e) {
        var {
          __stickyCheckList: t = []
        } = this;
        return this.getFilterStickyCheckList(t, e, !0).reduce((e, t) => {
          var {
            key: n
          } = t, r = this.hasStickyControlItem(n);
          return e && r
        }, !0)
      },
      clearCheckWeightStickyControlItem(e) {
        var {
          __stickyCheckList: t = [],
          __stickyControlMap: n = {}
        } = this;
        this.getFilterStickyCheckList(t, e, !1).forEach(e => {
          delete n[e.key]
        }), this.__stickyControlMap = n
      },
      hasStickyControlItem(e) {
        var {
          __stickyControlMap: t
        } = this;
        return Object.prototype.hasOwnProperty.call(t, e)
      },
      setStickyControlItemHeight(e, t) {
        this.__stickyControlMap[e].height = t
      },
      setStickyControlItem(e, t, n) {
        this.clearCheckWeightStickyControlItem(e);
        var {
          __stickyControlMap: r = {}
        } = this;
        if (n) {
          var a = {
            height: t,
            positionTop: this.getHasStickyTop(e),
            nextTop: this.getHasStickyTop(e) + t
          };
          this.hasStickyControlItem(e) || (r[e] = a, this.setStickyControlItemSubscribe())
        } else this.hasStickyControlItem(e) && (delete r[e], this.setStickyControlItemSubscribe());
        this.__stickyControlMap = r
      },
      setStickyControlItemSubscribe() {
        var {
          __stickySubscribe: e
        } = this;
        e.forEach(e => {
          e.fn.call(e.ctx, {
            type: "setItem"
          })
        })
      },
      getStickyControlItem(e) {
        return this.__stickyControlMap[e]
      },
      getStickyControlNextTop(e) {
        var {
          __stickyCheckList: t = [],
          __stickyControlMap: n = {}
        } = this;
        return this.getFilterStickyCheckList(t, e, !0).reduce((e, t) => {
          var {
            key: r
          } = t;
          return e + (n[r] || {
            height: 0
          }).height
        }, 0)
      },
      setStickyControlSubscribe(e, t, n) {
        var {
          __stickySubscribe: r = []
        } = this;
        r.findIndex(e => e.type === n) < 0 && (r.push({
          type: n,
          ctx: t,
          fn: e
        }), this.__stickySubscribe = r)
      },
      delStickyControlSubscribe(e) {
        var {
          __stickySubscribe: t = []
        } = this, n = t.findIndex(t => t.type === e);
        n > -1 && (t.splice(n, 1), this.__stickySubscribe = t)
      },
      publicStickyControlSubscribe(e, t, n) {
        var {
          __stickySubscribe: r = [],
          __stickyControlMap: a = {}
        } = this, {
          positionTop: i
        } = a[e];
        r.forEach(r => {
          var {
            type: o
          } = r;
          if (o != e && this.hasStickyControlItem(o)) {
            var {
              positionTop: s
            } = a[o], c = s + (t ? n : 0);
            s >= i && r.fn.call(r.ctx, {
              type: "stickyTop",
              stickyTop: c
            })
          }
        })
      },
      getStickyControl() {
        return {
          __stickyControlMap: this.__stickyControlMap,
          __stickySubscribe: this.__stickySubscribe,
          __stickyCheckList: this.__stickyCheckList
        }
      },
      setStickyControl(e) {
        this.__stickyControlMap = e.__stickyControlMap, this.__stickySubscribe = e.__stickySubscribe, this.__stickyCheckList = e.__stickyCheckList
      },
      releaseStickyControl() {
        this.__stickyControlMap = {}, this.__stickySubscribe = [], this.__stickyCheckList = []
      },
      releaseStickyControlMap() {
        this.__stickyControlMap = {}
      }
    };
    t.a = r
  },
  z24M: function(e, t, n) {
    n.d(t, "a", function() {
      return i
    });
    var r = n("x5Yp"),
      a = {};

    function i(e) {
      try {
        return Object(r.a)(a) && wx.getExtConfigSync && (a = wx.getExtConfigSync()), e ? a[e] : a
      } catch (e) {
        return {}
      }
    }
  },
  z2TJ: function(e, t, n) {
    function r(e, t) {
      try {
        if (e === t || !e || !t) return 0;
        for (var n = e.split("."), r = t.split("."), a = n.length, i = r.length, o = 0, s = Math.min(a, i); o < s; o++) {
          var c = parseInt(n[o], 10),
            u = parseInt(r[o], 10);
          if (isNaN(c) && (c = 0), isNaN(u) && (u = 0), c !== u) return c > u ? 1 : -1
        }
        return a > i ? 1 : a < i ? -1 : 0
      } catch (e) {
        return -1
      }
    }
    n.d(t, "a", function() {
      return r
    })
  },
  zHBu: function(e, t, n) {
    e.exports = function(e, t) {
      if (t = t.split(":")[0], !(e = +e)) return !1;
      switch (t) {
        case "http":
        case "ws":
          return 80 !== e;
        case "https":
        case "wss":
          return 443 !== e;
        case "ftp":
          return 21 !== e;
        case "gopher":
          return 70 !== e;
        case "file":
          return !1;
      }
      return 0 !== e
    }
  },
  zc1V: function(e, t, n) {
    var r, a = n("d6Vr"),
      i = (r = /[^.]+$/.exec(a && a.keys && a.keys.IE_PROTO || "")) ? "Symbol(src)_1." + r : "";
    e.exports = function(e) {
      return !!i && i in e
    }
  },
  zcvR: function(e, t, n) {
    var r = n("7o+A");
    e.exports = function(e, t) {
      var n = e.__data__;
      return r(t) ? n["string" == typeof t ? "string" : "hash"] : n.map
    }
  },
  zjWU: function(e, t, n) {
    n.d(t, "b", function() {
      return a
    });
    n("mK0O");
    var r, a, i = n("Pv5g");
    r = i.a, a = i.b, Object.assign(a, {
      cart_page: "购物车页面渲染流程",
      trade_buy_page: "下单页渲染流程",
      sku_buy: "SKU 立即购买流程",
      sku_cart: "SKU 加购流程"
    });
    var o = r({
      appName: "wsc",
      logIndex: "new_wsc_weapp_log"
    });
    t.a = o
  }
};