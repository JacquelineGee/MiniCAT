var r = require("~/r");
r("ijKI", Object.assign({}, require("~/v.js").modules, require("~/c.js").modules, {
  ijKI: function(e, t, i) {
    i.r(t);
    var r = {
        mixins: [i("bs6A").a],
        props: {
          kdtId: {
            type: Number
          },
          offlineId: {
            type: Number,
            default: 0
          },
          appId: {
            type: String
          },
          _opt: {
            type: Object
          },
          pageScrollKey: {
            type: String,
            default: "showcase-container:page-scroll"
          },
          tabPage: {
            type: Boolean,
            default: !1
          }
        },
        computed: {
          slideType() {
            return this._opt && this._opt.slideType
          }
        },
        created() {},
        methods: {
          onPullDownRefresh() {},
          handleBuyClick(e) {
            this.$emit("button-click", e)
          },
          handleItemClick(e) {
            this.$emit("item-click", e)
          }
        },
        ud: !0
      },
      l = i("9ZMt");
    t.default = l.default.component(r)
  }
}));