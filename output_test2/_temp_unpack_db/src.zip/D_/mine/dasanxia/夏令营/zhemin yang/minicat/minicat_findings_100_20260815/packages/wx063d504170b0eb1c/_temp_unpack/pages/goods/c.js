exports.ids = [2426], exports.modules = {
  "3GJ5": function(e, t) {},
  DxnF: function(e, t, o) {},
  Mmby: function(e, t) {},
  SKHs: function(e, t, o) {
    var s = o("Fcif"),
      a = o("esrA"),
      i = "@ext-tee-wsc-goods/timeline-block~ff66b632",
      n = "@ext-tee-wsc-goods/page-setup-block",
      r = "@assets-tee-extensions/guarantee-detail-bar",
      c = "@wsc-tee-salesman/salesman-cube-block",
      d = "@ext-tee-wsc-goods/recommend-plugin-block",
      u = "@ext-tee-wsc-goods/goods-detail-block",
      l = "@ext-tee-wsc-goods/fix-bottom-block",
      p = "@ext-tee-wsc-goods/trade-submit-block",
      h = "@ext-tee-wsc-goods/recommend-block",
      g = "@ext-tee-wsc-goods/multi-store-block",
      m = "@ext-tee-wsc-goods/goods-review-block",
      b = "@ext-tee-wsc-goods/buyer-show-block",
      f = "@wsc-tee-salesman/salesman-promote-block",
      y = "@ext-tee-wsc-goods/shop-note-block",
      v = "@assets-tee-extensions/guarantee-components",
      S = "@ext-tee-wsc-im/im-message-contact",
      k = "@ext-tee-wsc-goods/goods-ranking-block",
      w = "@wsc-tee-salesman/salesman-recruit-goods-block",
      I = "@assets-tee-extensions/sku-pay-ways",
      B = "@wsc-tee-statcenter/recommend-goods",
      C = "@wsc-tee-statcenter/cps-recommend-goods",
      P = "@ext-tee-wsc-goods/preview-image-block",
      D = "@wsc-tee-trade/order-pay-prompt-popup",
      x = "@ext-tee-wsc-goods/shop-physical-block",
      A = "@ext-tee-wsc-goods/estimated-arrival-time",
      O = "@ext-tee-wsc-goods/shop-evaluation-entry",
      T = "@ext-tee-wsc-goods/trade-records-block",
      M = "@wsc-tee-salesman/salesman-share-block",
      R = "@ext-tee-wsc-goods/trade-buy-ump-block",
      N = "@ext-tee-wsc-goods/goods-explain-video",
      F = Object(a.a)({
        a: {
          p: [{
            routes: ["/pages/goods/detail/index"],
            containers: [{
              contentType: "container",
              contents: [{
                contentType: "module",
                contents: ["b7-36", "b7-51", "b7-2"]
              }]
            }, {
              contentType: "container",
              contents: [{
                blockName: "nav-bar-block",
                contentType: "module",
                contents: ["b7-19"]
              }, {
                blockName: "trade-carousel",
                contentType: "module",
                contents: ["b7-18"]
              }, {
                blockName: "image-block",
                contentType: "module",
                contents: ["b7-4"]
              }, {
                blockName: "base-info-block",
                contentType: "module",
                contents: ["b7-52"]
              }, {
                blockName: "goods-ranking-block",
                contentType: "module",
                contents: ["b7-26"]
              }, {
                blockName: "activity-block",
                contentType: "module",
                contents: ["b7-55"]
              }, {
                blockName: "estimated-arrival-time",
                contentType: "module",
                contents: ["b7-40"]
              }, {
                blockName: "promotion-block",
                contentType: "module",
                contents: ["b7-56"]
              }, {
                blockName: "multi-store-block",
                contentType: "module",
                contents: ["b7-15"]
              }, {
                blockName: "group-block",
                contentType: "module",
                contents: ["b7-53"]
              }, {
                blockName: "goods-extra-block",
                contentType: "module",
                contents: ["b7-54"]
              }, {
                blockName: "trade-records-block",
                contentType: "module",
                contents: ["b7-49"]
              }, {
                blockName: "goods-review-block",
                contentType: "module",
                contents: ["b7-16"]
              }, {
                blockName: "buyer-show-block",
                contentType: "module",
                contents: ["b7-17"]
              }, {
                blockName: "shop-evaluation-entry",
                contentType: "module",
                contents: ["b7-48"]
              }, {
                blockName: "shop-note-block",
                contentType: "module",
                contents: ["b7-21"]
              }, {
                blockName: "shop-block",
                contentType: "module",
                contents: ["b7-7"]
              }, {
                blockName: "sold-out-rec-shop-block",
                contentType: "module",
                contents: []
              }, {
                blockName: "shop-physical-block",
                contentType: "module",
                contents: ["b7-38"]
              }, {
                blockName: "recommend-plugin-block",
                contentType: "module",
                contents: ["b7-8"]
              }, {
                blockName: "goods-detail-block",
                contentType: "module",
                contents: ["b7-9"]
              }, {
                blockName: "cps-goods-recommend",
                contentType: "module",
                contents: ["b7-32"]
              }, {
                blockName: "recommend-block",
                contentType: "module",
                contents: ["b7-14"]
              }, {
                blockName: "fixed-bottom-block",
                contentType: "module",
                contents: ["b7-10"]
              }, {
                contentType: "module",
                contents: ["b7-12"]
              }, {
                contentType: "module",
                contents: ["b7-63"]
              }]
            }, {
              contentType: "container",
              contents: [{
                contentType: "module",
                contents: ["b7-42", "b7-44", "b7-13", "b7-23", "b7-47", "b7-5", "b7-50", "b7-46", "b7-6", "b7-25", "b7-39", "b7-60", "b7-64", "b7-0"]
              }]
            }],
            modules: ["b7-1", "b7-3", "b7-11", "b7-20", "b7-22", "b7-24", "b7-27", "b7-28", "b7-29", "b7-30", "b7-31", "b7-33", i, "b7-35", "b7-37", "b7-41", "b7-43", "b7-45", "b7-57", "b7-58", "b7-59", "b7-61", "b7-62", "b7-65"]
          }]
        },
        m: [
          ["b7-0", "@ext-tee-wsc-decorate/page-style", null, {
            stage: "pre"
          }],
          ["b7-1", n, {
            d: {
              oid: ["@wsc-tee-shop/multi-store~yPFckvJB", "offlineId"]
            },
            e: {
              "page-container:scrollLocked": [
                ["b7-4"],
                ["b7-5"],
                ["b7-49"]
              ]
            }
          }, {
            stage: "pre",
            asyncInit: !0
          }],
          ["b7-2", "@wsc-tee-shop/shop-top-bar", {
            d: {
              kdtId: "@wsc-tee-shop/shop-core~NzurILNk",
              offlineId: "@wsc-tee-shop/multi-store~yPFckvJB"
            }
          }, {
            stage: "pre"
          }],
          ["b7-3", r, null, {
            stage: "pre"
          }],
          ["b7-4", "@ext-tee-wsc-goods/image-block", {
            d: {
              finalBigButtons: ["b7-10", "bigButtons"]
            },
            e: {
              "swipe:update": [
                ["b7-52", "nav:update"]
              ]
            }
          }, {
            stage: "pre"
          }],
          ["b7-5", "@ext-tee-wsc-goods/share-block", {
            d: {
              goods: ["b7-1", "goodsBaseInfo"]
            },
            e: {
              "share:show": [
                ["b7-52"],
                ["b7-10"],
                ["b7-25"],
                ["b7-13"]
              ],
              "share:query": [
                ["b7-50"]
              ],
              "share:optionMenu": [
                ["b7-6"]
              ],
              "share:setPageShareParams": [
                ["b7-5"]
              ]
            },
            w: {
              UserAuthorize: ["@passport-tee/user-authorize~DDdJBmWG", "Main"]
            },
            p: {
              setShareInfo: [
                ["b7-50"]
              ]
            }
          }, {
            stage: "pre"
          }],
          ["b7-6", c, {
            d: {
              shareInfo: ["b7-5", "shareData"]
            },
            w: {
              UserAuthorize: ["@passport-tee/user-authorize~DDdJBmWG", "Main"]
            }
          }, {
            properties: {
              scenes: "goods",
              getShareOpportunity: "goodsData",
              guideBindSourceType: 21,
              needBindRelation: !1
            },
            stage: "normal"
          }],
          ["b7-7", "@ext-tee-wsc-goods/shop-block", {
            d: {
              theme: ["b7-1", "themeColors"]
            },
            w: {
              ShopTags: "b7-7"
            }
          }, {
            stage: "normal"
          }],
          ["b7-8", d, null, {
            stage: "normal"
          }],
          ["b7-9", u, {
            d: {
              offlineId: "@wsc-tee-shop/multi-store~yPFckvJB"
            },
            w: {
              HaitaoNotification: "b7-9",
              PriceIntro: "b7-9",
              DetailTitle: "b7-9"
            }
          }, {
            stage: "normal"
          }],
          ["b7-10", l, {
            d: {
              goodsEstimatePriceData: ["b7-13", "estimatePriceData"],
              limitedEstimate: ["b7-13", "estimatePriceData"]
            },
            e: {
              "trade:finish": [
                ["b7-13"]
              ],
              saleReminderSuccess: [
                ["b7-39"]
              ],
              clickBigButton: [
                ["b7-4"],
                ["b7-33"],
                ["b7-49", "records-sku:show"],
                ["b7-60"]
              ],
              "custom:event": [
                ["b7-13"]
              ],
              "inSourcingFissionCoupon:show": [
                ["b7-13"]
              ]
            },
            w: {
              UmpTips: "b7-10"
            },
            p: {
              checkShowFollow: [
                ["b7-39"]
              ],
              launchFastJoinSDK: [
                ["b7-63"]
              ]
            }
          }, {
            stage: "pre"
          }],
          ["b7-11", "@wsc-tee-shop/shop-rest", null, {
            stage: "normal"
          }],
          ["b7-12", "@wsc-tee-shop/footer", null, {
            stage: "normal"
          }],
          ["b7-13", p, {
            d: {
              explainVideoFullScreen: "b7-60",
              hasOpenExplainVideo: "b7-60"
            },
            e: {
              "sku:show": [
                ["b7-39", "sku:show:to-submit"],
                ["b7-39"],
                ["b7-10"]
              ],
              "submit:act": [
                ["b7-39"],
                ["b7-10"]
              ],
              showNearSku: [
                ["b7-30"],
                ["b7-53", "sku:show"]
              ],
              "sku:hide": [
                ["b7-39"],
                ["b7-29"]
              ],
              "sku:preview-click": [
                ["b7-43", "sku:preview"]
              ],
              "skuSubmit:act": [
                ["b7-43", "submit:act"]
              ]
            },
            w: {
              SkuPayWays: ["b7-29", "Main"],
              SkuPaidCouponIntro: ["b7-54", "CouponIntro"],
              SkuHeader: "b7-13"
            },
            p: {
              setTradePostData: [
                ["b7-28", "setSalesmanTradeData"],
                ["b7-29", "setPayWayData"],
                ["b7-43", "setSkuOrderData"]
              ],
              skuUpdate: [
                ["b7-29", "installment:update"]
              ]
            }
          }, {
            stage: "normal"
          }],
          ["b7-14", h, {
            d: {
              disableGoodsRecommend: ["b7-1", "isGroupOn"]
            },
            w: {
              PersonalRecommend: ["b7-31", "Main"],
              RecommendTitle: "b7-14"
            }
          }, {
            stage: "normal"
          }],
          ["b7-15", g, null, {
            stage: "normal"
          }],
          ["b7-16", m, null, {
            stage: "normal"
          }],
          ["b7-17", b, null, {
            stage: "normal"
          }],
          ["b7-18", "@ext-tee-wsc-goods/trade-carousel", null, {
            stage: "normal"
          }],
          ["b7-19", "@ext-tee-wsc-goods/nav-bar-block", null, {
            stage: "normal"
          }],
          ["b7-20", f, null, {
            stage: "pre"
          }],
          ["b7-21", y, null, {
            stage: "normal"
          }],
          ["b7-22", v, null, {
            stage: "pre"
          }],
          ["b7-23", "@ext-tee-wsc-im/im-sdk-core", null, {
            stage: "normal"
          }],
          ["b7-24", S, {
            d: {
              contact: null
            },
            w: {
              UserAuthorize: ["@passport-tee/user-authorize~DDdJBmWG", "Main"]
            }
          }, {
            stage: "pre"
          }],
          ["b7-25", "@wsc-tee-decorate/floating-nav", {
            e: {
              "submit:act": [
                ["b7-39"]
              ]
            },
            w: {
              LivePopup: ["b7-41", "Main"],
              FloatingNavBg: "b7-25"
            }
          }, {
            stage: "normal"
          }],
          ["b7-26", k, null, {
            stage: "normal"
          }],
          ["b7-27", "@ext-tee-wsc-goods/biz-sku-manage", {
            e: {
              "sku:show": [
                ["b7-61"]
              ]
            }
          }, {
            stage: "normal"
          }],
          ["b7-28", w, null, {
            stage: "normal"
          }],
          ["b7-29", I, {
            d: {
              sku: ["b7-13", "skuData"],
              goods: ["b7-1", "goodsBaseInfo"]
            }
          }, {
            stage: "normal"
          }],
          ["b7-30", "@ext-tee-assets/prior-use-block", {
            d: {
              goods: ["b7-1", "goodsBaseInfo"],
              supportSkuDirectOrder: "b7-13",
              preferredPayChannel: "b7-45"
            },
            e: {
              "payWaysData:update": [
                ["b7-29"]
              ]
            }
          }, {
            stage: "pre"
          }],
          ["b7-31", B, {
            d: {
              title: ["b7-14", "recommendTitle"],
              themeCSS: ["b7-1", "themeVars"]
            }
          }, {
            properties: {
              totalPageNum: 3,
              useLoadMore: !0
            },
            stage: "normal"
          }],
          ["b7-32", C, null, {
            properties: {
              wrapperType: "",
              style: "margin-top: var(--theme-page-ext-margin-top, 8px);display: block;"
            },
            stage: "normal"
          }],
          ["b7-33", P, {
            d: {
              finalBigButtons: ["b7-10", "bigButtons"],
              skuData: "b7-13"
            },
            e: {
              "preview-image": [
                ["b7-13", "sku:preview-click"]
              ]
            },
            w: {
              UserAuthorize: ["@passport-tee/user-authorize~DDdJBmWG", "Main"]
            }
          }, {
            stage: "pre"
          }],
          [i, "@ext-tee-wsc-goods/timeline-block", null, {
            stage: "post"
          }],
          ["b7-35", "@ext-tee-wsc-im/im-layer", null, {
            stage: "normal"
          }],
          ["b7-36", "@wsc-tee-decorate/navigation-bar", {
            d: {
              title: ["b7-1", "navigationText"]
            }
          }, {
            stage: "pre"
          }],
          ["b7-37", D, {
            e: {
              open: [
                ["b7-39", "ORDER_PAY_PROMPT:open"]
              ]
            }
          }, {
            stage: "normal"
          }],
          ["b7-38", x, null, {
            stage: "normal"
          }],
          ["b7-39", "@ext-tee-wsc-goods/popup-container", {
            d: {
              explainVideoFullScreen: "b7-60"
            },
            e: {
              "page-container:scrollLocked": [
                ["b7-4"],
                ["b7-60"]
              ],
              "sku:show": [
                ["b7-13"]
              ],
              "sku:hide-after": [
                ["b7-13", "sku:hide"],
                ["b7-27", "sku:hide"]
              ],
              "btn:click": [
                ["b7-25", "floating:nav:wish:show"]
              ],
              "sku:submit": [
                ["b7-13", "custom:event"]
              ]
            },
            w: {
              UserAuthorizePopup: ["@passport-tee/user-authorize~DDdJBmWG", "Popup"],
              ProtocolPopup: "@passport-tee/protocol~Duv5tmrK",
              PopContent: [
                ["b7-11", "Main"],
                ["b7-27", "Main"],
                ["b7-33", "Main"],
                ["b7-58", "OrderKeep"],
                ["b7-35", "Main"],
                ["b7-37", "Main"],
                ["b7-43", "SkuOrderPopup"]
              ],
              CouponItem: "b7-39",
              CouponList: "b7-39"
            }
          }, {
            stage: "normal"
          }],
          ["b7-40", A, {
            d: {
              theme: ["b7-1", "themeColors"]
            }
          }, {
            stage: "normal"
          }],
          ["b7-41", "@wsc-tee-decorate/live-pop", {
            d: {
              shopInfo: ["b7-1", "shopBaseInfo"]
            }
          }, {
            stage: "normal"
          }],
          ["b7-42", "@wsc-tee-trade/wxvideo-order-core", null, {
            stage: "normal"
          }],
          ["b7-43", "sku-order-block", {
            d: {
              theme: ["b7-1", "themeColors"],
              goods: "b7-43",
              sku: ["b7-13", "skuData"],
              skuGoods: ["b7-13", "goods"]
            },
            e: {
              "sku:hide": [
                ["b7-13"]
              ]
            },
            w: {
              CouponDialog: ["b7-59", "CouponList"],
              Cashier: ["b7-45", "SingleRow"]
            }
          }, {
            stage: "normal"
          }],
          ["b7-44", "@ext-tee-wsc-ump/trade-buy-ump-data", {
            d: {
              state: ["b7-43", "umpDataState"]
            },
            e: {
              setGrouponIsChecked: null
            }
          }, {
            stage: "normal"
          }],
          ["b7-45", "@assets-tee-extensions/cashier-pre", null, {
            stage: "normal"
          }],
          ["b7-46", "@wsc-tee-decorate/subscribe-message", null, {
            stage: "normal"
          }],
          ["b7-47", "@ext-tee-wsc-im/subscription-message", null, {
            stage: "pre"
          }],
          ["b7-48", O, null, {
            stage: "normal"
          }],
          ["b7-49", T, {
            d: {
              recordsBuyButton: ["b7-10", "bigButtons"]
            }
          }, {
            stage: "normal"
          }],
          ["b7-50", M, {
            d: {
              kdtId: "@wsc-tee-shop/shop-core~NzurILNk"
            }
          }, {
            properties: {
              sst: 2
            },
            stage: "pre"
          }],
          ["b7-51", "@ext-tee-shop/shop-cert-notice", null],
          ["b7-52", "@ext-tee-wsc-goods/base-info-block", {
            d: {
              estimatePriceData: "b7-13",
              salesmanShareData: "b7-6"
            },
            w: {
              UmpPromotion: ["b7-56", "GoodsPromotion"],
              GuaranteeBar: ["b7-3", "GuaranteeDetailBar"],
              TitleBar: "b7-52",
              PriceBar: "b7-52",
              ActivityBanner: "b7-52"
            },
            p: {
              launchFastJoinSDK: [
                ["b7-63"]
              ]
            }
          }, {
            stage: "pre"
          }],
          ["b7-53", "@ext-tee-wsc-goods/group-block", {
            e: {
              "sku:selected": [
                ["b7-13"]
              ]
            },
            w: {
              PriorUse: ["b7-30", "Widget"],
              ServiceBar: "b7-53",
              SelectSkuBar: "b7-53"
            }
          }, {
            stage: "pre"
          }],
          ["b7-54", "@ext-tee-wsc-goods/goods-extra-block", {
            e: {
              hideVirtualTicketIntro: null
            },
            w: {
              EcardIntro: "b7-54",
              CouponIntro: "b7-54"
            }
          }],
          ["b7-55", "@ext-tee-wsc-goods/activity-block", {
            d: {
              theme: ["b7-1", "themeColors"]
            },
            w: {
              PresaleProgress: "b7-55"
            }
          }],
          ["b7-56", "@ext-tee-wsc-goods/promotion-block", {
            d: {
              theme: ["b7-1", "themeColors"],
              goodsEstimatePriceData: ["b7-13", "estimatePriceData"]
            },
            e: {
              "promotion:show": [
                ["b7-10"]
              ]
            },
            w: {
              GoodsStock: "b7-56"
            }
          }, {
            stage: "pre"
          }],
          ["b7-57", "@wsc-tee-goods/trade-buy-address-pre", {
            d: {
              goods: "b7-43",
              order: "b7-44",
              isHouseNumberRequired: null,
              isShowForcePoiSelectAddress: null,
              periodBuy: null,
              shop: null,
              themeCSS: null
            },
            l: {
              getUserInfo: null,
              onEventOnce: null
            },
            w: {
              ContactMain: null,
              DeliveryMain: null,
              IdcardMain: null,
              IdcardPopup: null,
              PeriodBuy: null,
              SelfFetch: null,
              TimePicker: null,
              XhsAddress: null
            },
            p: {
              getLocation: null
            }
          }, {
            stage: "normal"
          }],
          ["b7-58", "@wsc-tee-trade/trade-buy-misc-pre", {
            d: {
              goods: "b7-43",
              order: "b7-44",
              shop: null
            },
            e: {
              openOrderKeep: [
                ["b7-13", "ORDER_KEEP:open"]
              ]
            },
            l: {
              hexToRgb: null
            },
            w: {
              OrderKeepDialog: null,
              Price: null
            }
          }, {
            stage: "normal"
          }],
          ["b7-59", R, {
            d: {
              pay: ["b7-43", "orderPayment"],
              goods: "b7-43",
              order: "b7-44",
              shop: null
            },
            e: {
              "postagetool:show": null,
              "submit:act": null
            },
            w: {
              DisplayCard: null,
              FansDialog: null,
              MembershipDialog: null,
              PlusBuyCard: null,
              PostagetoolCard: null
            },
            c: {
              UserAuthorizePopup: null
            }
          }],
          ["b7-60", N, {
            d: {
              themeCSS: ["b7-1", "themeVars"]
            }
          }, {
            stage: "post"
          }],
          ["b7-61", "@wsc-tee-decorate/showcase-container", {
            d: {
              alias: ["b7-9", "featureAlias"],
              shopInfo: ["@wsc-tee-shop/shop-core~NzurILNk", "shop"]
            }
          }],
          ["b7-62", "@wsc-tee-decorate/jump-link", null],
          ["b7-63", "@ext-tee-user/fast-join-sdk", null, {
            stage: "normal"
          }],
          ["b7-64", "@ext-tee-wsc-goods/goods-showcase", null],
          ["b7-65", "trade-buy-privacy-bill", null]
        ],
        e: [
          ["@ext-tee-wsc-decorate/page-style", {
            d: "pageStyleCSS;2;pageStyleConfig;2;themeIcon;4;themeCSS;4;appStyleConfig;4",
            lc: "objectToCSS"
          }],
          [n, {
            d: "kdtId;2;alias;2;offlineId;0;themeVars;2;themeColors;2;pageVars;2;pageParams;2;clientTemplate;2;serverStatus;2;env;2;pageSwitch;2;shopBaseInfo;2;shopConfig;2;shopMpInfo;2;shopMetaInfo;2;multistore;2;userState;2;buyConfig;2;openAppConfig;2;goodsBaseInfo;2;goodsPriceInfo;2;goodsMetaInfo;2;goodsCombineInfo;2;supplier;2;payWays;2;distribution;2;goodsDetail;2;activityInfo;2;goodsSkuData;2;pageFeature;2;marketActivity;2;memberActivity;2;promotionActivity;2;goodsActivity;2;query;2;buyerId;2;cpsConfigKey;2;goodsExtendInfo;2;retail;2;physicalStores;2;navigationText;2;userInfo;2;userGoodsStateParams;0;isHomePage;2;isTabPage;2;multiSkuDecision;2;marketing;0;logisticsTimeliness;2;isSupportSkuDirectOrder;2;platform;2;userStateSupportSkuDirectOrder;2;featureSwitch;2;staticConfig;2;wholesalerModel;2;pointsConfig;0;umpActivity;0;currentActivity;0;isGroupOn;0;isCoupon;0;buttonUmpTimelimitModel;0;activityInfoForPrice;0;seActivity;0;isNotPresent;0;fansBenefit;0;wecomFansBenefit;0;buyLimitGuideInfo;2;cartCount;2;guaranteeData;2;voucherModelList;2;isGuideNeedPkgShareUrl;0;hasFinishLoad;2;oid;4",
            e: "goodsSetupReady;goodsSetupInit",
            el: "page-container:scrollLocked",
            l: "checkFromChannelsOpenFlow;checkFromShowcase;checkIsChannels;checkIsHalfScreen;checkIsNeedSyncOrderScene;checkIsOpenByLiveBag;checkIsOpenByLiveGoodsShare;checkIsWxvideoLive",
            lc: "getPlatform;getUserInfo;hasLogin",
            p: "setShareIcon;updateCartCount;getGoodsDetail",
            pi: "autoEnterShop;updateBtnsUI;beforeRefreshCartCount;updateSupportSkuDirectOrder;tee-api:getLocation",
            li: "beforePageMount;onPullDownRefresh;beforePageCreate;pageDestroyed"
          }, {
            asyncInit: !0
          }],
          ["@wsc-tee-shop/shop-top-bar", {
            d: "showTopBar;2;rootKdtId;4;kdtId;4;offlineId;4;shop;4;needHideTopBar;4",
            e: "fullguide:show",
            w: "Main",
            lc: "getPlatform",
            pi: "enterShopSelect;switchMultiStore"
          }],
          [r, {
            d: "yzGuarantee;2;guarantee;2;shopBaseInfo;4;goodsBaseInfo;4;shopConfig;4;snapShotInfo;4;themeVars;4;buyerId;4;guaranteeData;4",
            e: "guaranteeSetupReady",
            w: "GuaranteeDetailBar",
            cc: "GuaranteePop"
          }],
          ["@ext-tee-wsc-goods/image-block", {
            d: "current;0;danmakuSource;0;isPageVisible;2;goodsBaseInfo;4;goodsPriceInfo;4;shopBaseInfo;4;skuPictures;4;shopConfig;4;finalBigButtons;4;isNoStock;4;shareData;4;isPageVisible;4;isHideDanmaku;4;pageVars;4;themeVars;4",
            e: "PreviewImageBlock:previewImage;trade-carousel:toggle;clickBigButton;page-container:scrollLocked",
            el: "swipe:update",
            w: "Widget;Danmaku",
            wc: "NormalCover",
            lc: "getAuthType;checkIsHalfScreen",
            p: "getNavItemTop;setShowImage;handleInitDanmakuSource;handleInitDanmaku;handleDanmakuPlayChange;handleDanmakuRefresh",
            pi: "beforePreviewMainImage;handleInitDanmakuSource;handleInitDanmaku;handleDanmakuPlayChange;handleDanmakuRefresh",
            c: "GoodsVideo",
            li: "onPageShow;onPageHide"
          }, {
            asyncInit: !0
          }],
          ["@ext-tee-wsc-goods/share-block", {
            d: "shareData;2;goods;4;kdtId;4;offlineId;4;shopMetaInfo;4;goodsPriceInfo;4;env;4;shopConfig;4;currentActivity;4;seActivity;4",
            e: "share:close;page-container:scrollLocked;share:setPageShareParams",
            el: "goodsSetupInit;share:show;share:query;share:item;share:pop;share:optionMenu;share:setPageShareParams",
            w: "Widget;ActionItem;SharePop",
            wc: "UserAuthorize;ActionItem;SharePop",
            lc: "getAuthType;hasLogin",
            pi: "setShareInfo;setShareActions",
            li: "onShareAppMessage;onShareTimeline"
          }],
          [c, {
            d: "salesmanShareData;0;shareInfo;6;goodsPriceInfo;6;currentActivity;4;goodsBaseInfo;4;goodsSkuData;4;shopBaseInfo;4;themeVars;4;customOptionListConfig;4;offlineId;4;isGuideNeedPkgShareUrl;4",
            e: "share:query;share:optionMenu;salesman:popup:close;salesman:popup:show",
            el: "floating:nav:update:position",
            w: "Widget;CubeHeader;CubeTabContainer;CubeTabPoster;CubeTabPromote;AssistantPop;CubeFooter;MainFrame;NewBeginPop;PosterPop;PromoteTip;ShareMask;TaxSignPop",
            wc: "CubeHeader;CubeTabContainer;CubeTabPoster;CubeTabPromote;UserAuthorize",
            lc: "checkIsHalfScreen;getUserInfo",
            p: "setShareInfo",
            pi: "createOrUpdateIndependentIcon;beforeGenerateSalesmanGoodsPosterEvent;getFeatureAlias;getCurrentPageType;getSharePath",
            li: "beforePageMount"
          }],
          ["@ext-tee-wsc-goods/shop-block", {
            d: "multistore;4;shopBaseInfo;4;shopConfig;4;theme;4;themeCSS;4;pageStyleCSS;4;shopMpInfo;4;retail;4;alias;4;physicalStores;4;openAppConfig;4;staticConfig;4;goodsBaseInfo;4",
            e: "follow:show",
            w: "Widget;ShopTags",
            wc: "ShopTags",
            p: "toggleOldShop",
            pi: "toggleOldShop"
          }],
          [d, {
            d: "themeVars;4;multistore;4;shopBaseInfo;4;shopConfig;4;goodsBaseInfo;4;goodsPriceInfo;4;currentActivity;4",
            w: "Widget"
          }],
          [u, {
            d: "featureComponents;2;extraData;2;detailTabs;2;activeType;0;featureAlias;0;goodsPriceInfo;4;goodsBaseInfo;4;shopBaseInfo;4;shopConfig;4;shopMetaInfo;4;env;4;themeColors;4;serverStatus;4;staticConfig;4;currentActivity;4;offlineId;4;buyerId;4;distribution;4",
            e: "featureSku:show",
            el: "goodsSetupReady;components:change",
            w: "GoodsDetail;HaitaoNotification;PriceIntro;DetailTitle",
            wc: "ShowcaseContainer;HaitaoNotification;PriceIntro;DetailTitle",
            lc: "getPlatform;getUserInfo",
            p: "getNavItemTop;hideTabs;setTabs;setActiveTab;setShowDesc",
            pi: "detailTabClick"
          }],
          [l, {
            d: "disabledBigButton;2;bigButtons;2;isNoStock;0;imConfig;0;bottomBtnClicked;2;activityName;2;estimatePrice;2;goodsBaseInfo;6;goodsPriceInfo;6;pageFeature;6;serverStatus;6;goodsActivity;6;activityInfo;4;shopBaseInfo;4;shopConfig;4;themeVars;4;env;4;goodsMetaInfo;6;userState;4;buyConfig;4;currentActivity;4;umpActivity;4;goodsSkuData;6;userStateSupportSkuDirectOrder;4;featureSwitch;4;shopMetaInfo;4;isCoupon;4;goodsEstimatePriceData;4;memberActivity;4;pointsConfig;4;userInfo;4;multistore;4;limitedEstimate;4;marketing;4;buttonUmpTimelimitModel;4;bigButtons;4;isGroupOn;4;seActivity;4;buyButtonPop;4;buyLimitGuideInfo;4;cartCount;4;offlineId;4;bottomBtnClicked;6;estimatePrice;6",
            e: "submitBlockBigBtnClick;submitBlockMiniBtnClick;submitBlockCountdownEnded;sku:show;submit:act;subscribe:show;mini-btn:click;big-btn:click;share:show;addCartCompleted;follow:show;promotion:show",
            el: "trade:finish;saleReminderSuccess;clickBigButton;goodsSetupReady;custom:event;inSourcingFissionCoupon:show;showGoodsBottom;onImClick",
            w: "Widget;UmpTips",
            wc: "UmpTips",
            l: "getAutoShowSkuParams",
            lc: "getUserInfo",
            p: "updateBtnsUI;processBtnData;handleDataReady",
            pi: "setBottomTip;setBottomBtns;checkShowFollow;updateCartCount;showYZIm;launchFastJoinSDK;handleDataReady",
            cc: "MessageContactButton"
          }],
          ["@wsc-tee-shop/shop-rest", {
            d: "kdtId;4;offlineId;4",
            w: "Main"
          }],
          ["@wsc-tee-shop/footer", {
            d: "kdtId;4;buyerId;4;isShowStoreInfo;4;pageBgColor;4;miniprogram;4;pageStyleConfig;4",
            e: "fullguide:show",
            w: "Main"
          }],
          [p, {
            d: "goods;0;skuConfig;0;skuData;0;periodBuy;0;ecard;0;ladderGroupOn;0;couponTips;0;supportSkuDirectOrder;2;skuDirectOrderAbTraceId;2;displayData;2;orderData;2;showCouponTips;0;estimatePriceData;0;sellingPointOpt;0;cloudDesignConfig;4;kdtId;4;goodsActivity;4;goodsBaseInfo;4;goodsPriceInfo;4;goodsMetaInfo;4;goodsSkuData;4;pageFeature;4;shopConfig;4;shopBaseInfo;4;payWays;4;buyConfig;4;distribution;4;multistore;4;bigButtons;4;currentActivity;4;umpActivity;4;isCoupon;4;goodsCombineInfo;4;yzGuarantee;4;pageSwitch;4;featureSwitch;4;shopMetaInfo;4;themeVars;4;userGoodsStateParams;4;marketing;4;pointsConfig;4;multiSkuDecision;4;explainVideoFullScreen;4;hasOpenExplainVideo;4;themeTag;4;pageVars;4;themeColors;4;activityName;4",
            e: "sku:selected;sku:preview-click;sku:show;sku:hide;custom:event;subscribe:show;follow:show;ORDER_KEEP:open;trade:finish;skuBookkey:finish;question:show;share:show;inSourcingFissionCoupon:show;qrcode:show;helpcutErr:show;skuOrder:show;sku:num-change",
            el: "sku:show;submit:act;showNearSku;guaranteeSetupReady;big-btn:click;sku:hide;sku:preview-click;skuOrder:selected;skuSubmit:act;hideVirtualTicketIntro;sku:selected",
            w: "SkuHeader",
            wc: "SkuPayWays;CombineGoodsBlock;CombineGoodsPlaceholder;SubmitNotice;SkuPaidCouponIntro;OptionalGoodsCombo;SkuHeader",
            p: "addCart",
            pi: "setTradePostData;beforeCartSubmit;beforeBuy;afterBuy;navigateToTradeBuy;sku:validate;skuUpdate",
            li: "pageDestroyed"
          }],
          [h, {
            d: "recommendTitle;0;bizName;0;layoutConfig;0;requestExtraParams;0;extraParams;0;themeVars;4;multistore;4;shopBaseInfo;4;shopConfig;4;shopMetaInfo;4;goodsBaseInfo;4;goodsPriceInfo;4;disableGoodsRecommend;4;openAppConfig;4;currentActivity;4",
            el: "goodsSetupReady;loadSuccess",
            w: "Widget;RecommendTitle",
            wc: "PersonalRecommend;RecommendTitle",
            p: "getNavItemTop"
          }],
          [g, {
            d: "themeVars;4;multistore;4;alias;4;themeCSS;4;pageStyleCSS;4",
            w: "Widget"
          }],
          [m, {
            d: "kdtId;4;alias;4;shopConfig;4;staticConfig;4;goodsBaseInfo;4;disabledBigButton;4;memberActivity;4;currentActivity;4;bigButtons;4;pageFeature;4;themeTag;4",
            w: "GoodsReview",
            lc: "getAutoShowSkuParams",
            p: "getNavItemTop",
            c: "Rate;ReviewItemHeader;ReviewTags;ReviewImgList;ReviewItemContent"
          }],
          [b, {
            d: "kdtId;4;alias;4;shopConfig;4;pageStyleCSS;4",
            w: "Widget"
          }],
          ["@ext-tee-wsc-goods/trade-carousel", {
            d: "goodsBaseInfo;6;shopConfig;6;navBarHeight;4;topNavHeight;4;staticConfig;4",
            e: "share:show",
            el: "trade-carousel:toggle",
            w: "Widget"
          }],
          ["@ext-tee-wsc-goods/nav-bar-block", {
            d: "navBarHeight;0;themeVars;4;shopConfig;4;topNavHeight;4",
            w: "Widget",
            pi: "getNavItemTop;setNavTabList",
            li: "onPageScroll"
          }],
          [f, {
            d: "shopBaseInfo;4",
            lc: "checkFromChannelsOpenFlow;checkIsChannels",
            li: "beforePageMount"
          }],
          [y, {
            d: "goodsExtendInfo;4;goodsBaseInfo;4;themeCSS;4;pageStyleCSS;4",
            w: "Main"
          }],
          [v, {
            c: "GuaranteePop"
          }],
          ["@ext-tee-wsc-im/im-sdk-core", {
            p: "getImSocketIns"
          }],
          [S, {
            d: "contact;4",
            w: "MessageContact",
            wc: "UserAuthorize",
            lc: "getUserInfo",
            p: "showYZIm",
            c: "MessageContactButton"
          }],
          ["@wsc-tee-decorate/floating-nav", {
            d: "hasGoodsShowcase;0;openFloatGoods;4;kdtId;4;shopMetaInfo;4;seActivity;4;shopInfo;6;imSourceDetail;6;alias;6;isShowFloatingNav;4;addBaseHeight;6",
            e: "share:show;goods:showcase;floating:nav:update:position;live:popup:show;floating:nav:wish:show;floating:nav:init",
            el: "submit:act;wish:state:change",
            w: "FloatingNavBg;SubItem",
            wc: "LivePopup;FloatingNavBg;SubItem",
            lc: "checkIsHalfScreen;checkIsOpenByLiveBag;jumpToLink",
            p: "createOrUpdateIndependentIcon",
            cc: "MessageContactButton",
            li: "onPullDownRefresh;onPageScroll"
          }],
          [k, {
            d: "kdtId;4;offlineId;4;goodsExtendInfo;4;shopConfig;4;shopMetaInfo;4",
            w: "Main"
          }],
          ["@ext-tee-wsc-goods/biz-sku-manage", {
            d: "goodsAttributes;2;goodsCombineInfoBizSku;0;offlineId;4;themeVars;4;containerStyle;6;multistore;6;kdtId;6;shopConfig;6;pointsConfig;6;themeTag;6",
            e: "sku:preview;sku:hide",
            el: "sku:show;sku:addCart",
            w: "Main",
            p: "sku:selectData",
            pi: "sku:beforeAddCartAsync;sku:beforeBuyAsync;sku:afterBuyAsync;sku:selectData"
          }],
          [w, {
            p: "setSalesmanTradeData",
            li: "beforePageMount;pageDestroyed"
          }],
          [I, {
            d: "payChannels;4;payWaysData;6;kdtId;4;sku;4;goods;4;showCouponTips;4;supportSkuDirectOrder;4",
            e: "sku:hide;payWaysData:update;installment:selected",
            el: "sku:num-change;sku:selected;cashier:change",
            w: "Main;SubmitNotice",
            p: "installment:update;installment:validate;setPayWayData"
          }],
          ["@ext-tee-assets/prior-use-block", {
            d: "payChannels;2;payWaysData;2;env;4;goods;4;goodsPriceInfo;4;shopConfig;4;payWays;4;goodsBaseInfo;4;umpActivity;4;goodsActivity;4;kdtId;4;buyerId;4;supportSkuDirectOrder;4;preferredPayChannel;6;themeVars;4",
            e: "showNearSku;sku:installment",
            el: "goodsSetupReady;payWaysData:update",
            w: "Widget",
            lc: "checkIsNeedSyncOrderScene"
          }],
          [B, {
            d: "title;6;bizName;6;pageSize;6;kdtId;6;requestExtraParams;6;themeColors;4;themeCSS;4;offlineId;4;buyerId;4;layoutConfig;4;extraParams;4;isControlRecommendShow;4;enableShow;4;miniprogram;4;isSkyline;4",
            e: "loadSuccess",
            w: "Main;RecommendGoodsTitle",
            wc: "RecommendGoodsTitle"
          }],
          [C, {
            d: "cpsConfigKey;4;kdtId;4;buyerId;4",
            w: "Main"
          }],
          [P, {
            d: "goodsBaseInfo;4;goodsPriceInfo;4;finalBigButtons;4;skuData;4;isNoStock;4;kdtId;4;pageVars;4",
            e: "clickBigButton;preview-image:updated-current",
            el: "preview-image",
            w: "Main;NormalCover",
            wc: "UserAuthorize"
          }],
          ["@ext-tee-wsc-goods/timeline-block", {
            w: "Main"
          }],
          ["@ext-tee-wsc-im/im-layer", {
            d: "shopBaseInfo;4;goodsBaseInfo;4;multistore;4;topNavHeight;4",
            w: "Main",
            lc: "login",
            pi: "getImSocketIns",
            cc: "MessageContactButton"
          }],
          ["@wsc-tee-decorate/navigation-bar", {
            d: "topNavHeight;2;title;4;kdtId;4;imConfig;4;openCustomNav;4;navigationBarConfigData;4",
            w: "Main;NavigationBar",
            lc: "checkIsHalfScreen;checkFromShowcase",
            cc: "MessageContactButton",
            li: ""
          }],
          [D, {
            d: "kdtId;4;prompt;4;needRequest;4;source;4;themeColors;4",
            e: "stateChange",
            el: "open;close",
            w: "Main"
          }],
          [x, {
            d: "physicalStores;4;themeCSS;4;pageStyleCSS;4",
            w: "Main"
          }],
          ["@ext-tee-wsc-goods/popup-container", {
            d: "openFloatGoods;2;kdtId;4;rootKdtId;4;goodsBaseInfo;4;themeVars;4;marketing;4;offlineId;4;shopBaseInfo;4;shopMpInfo;4;shopConfig;4;goodsMetaInfo;6;goodsActivity;4;serverStatus;4;umpActivity;4;staticConfig;4;pageFeature;4;multistore;4;buyerId;4;shopMetaInfo;4;hasGoodsShowcase;4;currentActivity;4;alias;4;explainVideoFullScreen;4",
            e: "sku:hide;saleReminderSuccess;sku:show;submit:act;wish:change;sku:show:to-submit;ORDER_PAY_PROMPT:open",
            el: "goodsSetupReady;page-container:scrollLocked;addCartCompleted;sku:show;sku:hide-after;follow:show;subscribe:show;floating:nav:update:position;btn:click;sku:submit;goods:showcase;question:show;stateChange;wecomBenefit:show;helpcutErr:show;qrcode:show",
            w: "UmpVisitGift;GiftPop;VisitGift;CouponItem;CouponList",
            wc: "UserAuthorizePopup;ProtocolPopup;PopContent;UmpVisitGift;SubscribePublic;GiftPop;VisitGift;CouponItem;CouponList;GoodsShowcase",
            lc: "getUserInfo",
            p: "checkShowFollow",
            pi: "createOrUpdateIndependentIcon;requestWechatSubscribeMessagePush"
          }],
          [A, {
            d: "kdtId;4;theme;4;distribution;4;pageFeature;4;marketActivity;4;goodsActivity;4;shopBaseInfo;4;goodsBaseInfo;4;multistore;4;logisticsTimeliness;4;userInfo;4;themeTag;4",
            el: "goodsSetupReady",
            pi: "tryLocation"
          }],
          ["@wsc-tee-decorate/live-pop", {
            d: "hasLiving;0;shopInfo;6",
            w: "Main"
          }],
          ["@wsc-tee-trade/wxvideo-order-core", {
            d: "prepareData;0;confirmData;0;orderCreatedData;0;orderData;0;kdtId;4",
            e: "onFetchByBookKeyFailed",
            el: "sku:valid-fail",
            p: "fetchShow;fetchShowByBookKey;createOrder;setOrderInfo;setLastAddressId;clearOrderData",
            pi: "hook:afterCreateOrderError;onSkuBtnPayAfterRisk",
            li: "onPageShow;pageDestroyed;beforePageMount"
          }],
          ["sku-order-block", {
            d: "orderCreation;2;display;2;goods;2;umpDataState;2;orderPayment;2;priorUse;2;goodsAlias;0;goodsType;0;address;2;contact;2;skuPayChannel;2;excludePayTools;2;weappPaySuccessPath;2;lockState;2;order;2;themeVars;4;theme;4;payChannels;4;skuHeight;4;goodsBaseInfo;4;userInfo;4;prepareData;4;confirmData;4;orderCreatedData;4;orderCreation;6;display;6;goods;6;sku;6;skuGoods;6;multiSkuDecision;4;skuConfig;6;pointsConfig;6;couponModel;6;orderPayment;6;priorUse;6;goodsAlias;4;goodsType;4;address;6;contact;6;skuPayChannel;6;excludePayTools;6;weappPaySuccessPath;6;lockState;6;order;6;supportSkuDirectOrder;6;skuDirectOrderAbTraceId;4;orderedChosenCoupons;4;appId;4;sellingPointOpt;4;estimatePriceData;4;themeColors;4",
            e: "onReHeight;sku:hide_order;onShowCouponDialog;onShowActivityList;submit:act;sku:preview;skuOrder:selected",
            el: "skuBookkey:finish;sku:hide;goodsBook:load;showCouponList;onShowCouponDialog;onShowActivityList;goodsSetupReady;onCouponChange;skuOrder:show",
            w: "OrderPopExtra;OrderBlock;SkuOrderContactInfo;SkuOrderPayBtn;SkuOrderInfo;SkuOrderPopup",
            wc: "CouponDialog;CouponCell;ActivityCell;Cashier;AddressList;ContactList;ActivityDialog;OrderPopExtra;OrderBlock;SkuOrderContactInfo;SkuOrderPayBtn;SkuOrderInfo;SkuOrderPopup;TradeBuyPrivacyBill",
            l: "getHashQuery",
            lc: "onEvent;setDb",
            p: "assignCtxData;goToOrderSubPage;goToPaySuccess;goToPayFail;prepareByBookKey;createSkuOrder;startSkuPay;setOrderItemNum;setOrderAddress;setOrderContact;setLockState;prepareInitSkuViewData;setSkuOrderData;onSkuBtnPayAfterRisk",
            pi: "pay;setOrderInfo;createOrder;fetchShow;fetchShowByBookKey;assignCtxData;goToOrderSubPage;goToPaySuccess;goToPayFail;prepareByBookKey;createSkuOrder;startSkuPay;setOrderItemNum;setOrderAddress;setOrderContact;setLockState",
            cc: "PrivacyBillRulePopup"
          }],
          ["@ext-tee-wsc-ump/trade-buy-ump-data", {
            d: "couponModel;0;rewardModel;0;grouponModel;0;order;0;plusBuy;0;goods;0;display;0;postageModel;2;orderedChosenCoupons;0;isInCouponOverWhitelist;0;prepareData;4;confirmData;4;state;4;points;4;expressType;4;dataLoaded;4",
            e: "onCouponChange;postagetool:limitInfo;postagetool:unavailableItem",
            el: "setGrouponIsChecked",
            l: "exchangeCoupon",
            p: "addCouponProcess;setCouponChosenIdProcess;getUmpParamForOrder;fetchUmpPlusBuyProcess;handleExternalCoupon;exchangeCouponPromise;switchPlusBuyGoodsProcess;fetchSkuData;switchGoods;addAllGoods;getAddsOnePageDetail;calcPostage;resetPostageTool;savePostageTool",
            pi: "mutateState;fetchShow;fetchPromotion",
            li: "onPageShow"
          }],
          ["@assets-tee-extensions/cashier-pre", {
            d: "preferredPayChannel;2;amount;4;biz;4;mobile;4;traceId;4;themeColors;4;excludePayChannels;4;bizExt;4;viewportMargins;4",
            e: "cashier:change;cashier:pay:success;cashier:pay:fail;cashier:viewport:in;cashier:viewport:out;cashier:ready",
            w: "SingleRow;CellGroup",
            p: "pay;requestOrderPayment",
            pi: "onPaySuccessSync;getIsSyncOrder;onPayItemClick"
          }],
          ["@wsc-tee-decorate/subscribe-message", {
            d: "subscribeData;0;subscribeData;4",
            p: "requestWechatSubscribeMessagePush",
            pi: "requestSubscribeMessagePush",
            cc: "SubscribeGuide"
          }],
          ["@ext-tee-wsc-im/subscription-message", {
            p: "queryWechatSubscribeResult;requestSubscribeMessagePush;getTemplateByScene",
            c: "SubscribeGuide"
          }],
          [O, {
            d: "kdtId;4;goodsBaseInfo;4;shopMetaInfo;4",
            cc: "ReviewTags"
          }],
          [T, {
            d: "goodsBaseInfo;4;shopBaseInfo;4;shopConfig;4;recordsBuyButton;6;featureSwitch;4;currentActivity;4;themeCSS;4;pageStyleCSS;4",
            e: "trade-records-block:show;page-container:scrollLocked;records-sku:show",
            li: "onPageShow;onPageHide"
          }],
          [M, {
            d: "kdtId;4",
            e: "share:query",
            p: "setShareInfo"
          }],
          ["@ext-tee-shop/shop-cert-notice", {
            d: "shopCertConfig;0;isWsc;0",
            w: "Main"
          }],
          ["@ext-tee-wsc-goods/base-info-block", {
            d: "skuPictures;0;isNewcomerCoupon;2;buyButtonPop;2;goodsBaseInfo;6;goodsPriceInfo;6;pageVars;4;themeVars;4;goodsActivity;4;env;4;retail;4;current;4;goodsSkuData;4;isNewcomerCoupon;4;memberActivity;4;userInfo;4;shopBaseInfo;4;fansBenefit;4;wecomFansBenefit;4;kdtId;4;alias;4;umpActivity;4;themeColors;4;buyButtonPop;4;currentActivity;4;estimatePriceData;4;salesmanShareData;4;themeTag;4",
            e: "share:show;nav:update;follow:show;wecomBenefit:show",
            el: "goodsSetupReady",
            w: "Main;TitleBar;GuaranteeBar;PriceBar;ActivityBanner",
            wc: "UmpPromotion;GuaranteeBar;GuaranteeDetailBar;TitleBar;PriceBar;ActivityBanner",
            p: "setShowGuaranteeBar;showShareIcon;showActivityBanner;showPriceBlock",
            pi: "setShareIcon;launchFastJoinSDK;showPriceBlock;showShareIcon"
          }],
          ["@ext-tee-wsc-goods/group-block", {
            d: "serviceDescList;0;env;4;shopConfig;4;payWays;4;goodsMetaInfo;4;goodsBaseInfo;4;goodsActivity;4;distribution;4;staticConfig;4;goodsSkuData;4;pageFeature;4;kdtId;4",
            e: "sku:show",
            el: "sku:selected",
            w: "ServiceBar;SelectSkuBar",
            wc: "PriorUse;ServiceBar;SelectSkuBar",
            p: "setShowServiceBar;setServiceDescList"
          }],
          ["@ext-tee-wsc-goods/goods-extra-block", {
            d: "couponIntroDetail;0;goodsBaseInfo;4;goodsActivity;4;goodsSkuData;4;goodsMetaInfo;4",
            el: "hideVirtualTicketIntro",
            w: "EcardIntro;CouponIntro",
            wc: "EcardIntro;CouponIntro"
          }],
          ["@ext-tee-wsc-goods/activity-block", {
            d: "goodsActivity;4;goodsPriceInfo;4;currentActivity;4;goodsBaseInfo;4;shopBaseInfo;4;theme;4;umpActivity;4;env;4",
            w: "PresaleProgress",
            wc: "PresaleProgress",
            p: "showDepositPresalInfo"
          }],
          ["@ext-tee-wsc-goods/promotion-block", {
            d: "goodsSpe;0;umpCouponList;2;topCouponLabelList;0;showGoodsPromotion;0;goodsBaseInfo;4;distribution;4;shopConfig;4;multistore;4;goodsPriceInfo;4;themeVars;4;promotionActivity;4;kdtId;4;alias;4;theme;4;umpActivity;4;pageFeature;4;shopBaseInfo;4;currentActivity;4;goodsSkuData;4;goodsEstimatePriceData;4;isCoupon;4;voucherModelList;4;themeTag;4;marketing;4",
            el: "promotion:show",
            w: "GoodsPromotion;GoodsStock;GoodsPackageBuy",
            wc: "GoodsPromotion;GoodsStock;GoodsPackageBuy",
            p: "showPackageBuy;setShowGoodsPromotion",
            pi: "requestSubscribeMessagePush;queryWechatSubscribeResult;getTemplateByScene;setShowGoodsPromotion",
            cc: "SubscribeGuide"
          }],
          ["@wsc-tee-goods/trade-buy-address-pre", {
            d: "contactEditing;2;isShowForcePoiSelectAddress;2;isHouseNumberRequired;2;cloudDelivery;0;cloudData;0;pageStyleConfig;4;themeTag;4;address;4;display;4;currentAddress;4;postage;4;delivery;4;goods;4;tradeTag;4;groupon;4;themeColors;4;expressType;4;showPoiPrompt;4;forcePoiSelect;4;addressEditable;4;kdtId;4;receiveByGroupHeader;4;isShowRetailDeliveryAddress;4;appShop;4;retailHouseNumberRequired;4;extra;4;storeGiftsInfo;4;env;4;selfFetch;4;isScanCodeBuy;4;themeVars;4;contact;4;themeCSS;4;isRetailOrderScene;4;retailSelfFetchContact;4;periodBuy;4;order;4;shop;4;state;4;tradeAddressVisible;4;idcard;4;ignoreIdBinding;4;orderCreated;4;hasHaitaoGoods;4;grouponModel;4;isShowForcePoiSelectAddress;4;isHouseNumberRequired;4;dataLoaded;4;processData;4;isRetailWeappScene;4;cloudData;4;currentContact;4;selfFetchTime;4;showRetailPickUpWayErrorToast;6;retailPickUpWayValue;4",
            e: "onSelectAddress;onSelectExpressType;setGrouponIsChecked",
            el: "onDeliveryAddressCardClick",
            w: "DeliveryMain;AddressList;AddressListItem;AddressCard;LocalDeliveryTimeCell;SelfFetch;TimePicker;ContactMain;ContactList;WechatAddress;WxAddress;AliAddress;XhsAddress;IdcardPopup;IdcardMain;PeriodBuy;DeliveryBlock",
            wc: "AddressListItem;AddressList;WechatAddress;WxAddress;AliAddress;XhsAddress;LocalDeliveryTimeCell;TimePicker;ContactList;PickUpWay;OrderActionSheet;SelfFetchShopSecondConfirmDialog;GetPhoneButton;IdcardPopup;PeriodBuy;ContactMain;DeliveryMain;SelfFetch;IdcardMain;WaitingProcess;DeliveryBlock",
            lc: "onEvent;setDb;triggerEvent;onEventOnce;amap;getUserInfo;h5CompressUpload",
            p: "validateLocalDelivery;validateSelfFetch;pickDefaultSelfFetch;changeSelfFetchShop;saveContact;saveContactBeforeBilling;validateContact;validateAddress;handleCreateOrderError;validateIdCardAndPrompt;popIdcardBindingDialog;switchDeliveryTab;setLocalDeliveryTime;setSelfFetchTime;selectDelivery;setExpressWayWords;onExpressChanged",
            pi: "setSelfFetchTime;setLocalDeliveryTime;selectAddress;addAddress;deleteAddress;selectExpressType;fetchShow;mutateState;updateAddressState;switchAddressTab;setSelfFetch;selectContact;getLocation;hook:beforeGetDefaultSelfFetch;selectRetailContact;saveContact;setNewContact;setVerifyFail;updateAddress;setIdcard;setPeriodBuyChosenIndex;selectDelivery;pickDefaultSelfFetch;setExpressWayWords;onExpressChanged;confirmOrder"
          }, {
            asyncInit: !0
          }],
          ["@wsc-tee-trade/trade-buy-misc-pre", {
            d: "displayData;4;orderData;4;themeColors;4;orderFinalPrice;4;shopConfig;4;goods;4;pointDeduction;4;coupon;4;shop;4;pay;4;order;4;orderKeepApply;4;display;4;orderPaid;4;titleText;4;isRetailWeappScene;4",
            el: "openOrderKeep;closeOrderKeep",
            w: "PresentGoods;Price;OrderKeepDialog;OrderKeepNavigator;OrderKeep",
            wc: "Price;OrderKeepDialog",
            l: "getTradeBuyPageData;getTradeBuyPreFetchQuery",
            lc: "hexToRgb",
            p: "navigateToTradeBuy",
            pi: "navigateToTradeBuy",
            li: "pageDestroyed"
          }],
          [R, {
            d: "valueCard;4;display;4;pay;4;tradeTag;4;orderFinalPrice;4;prepayCardTotalAmount;4;prepayCardDecrease;4;prepayCardAvailable;4;prepayCardAvailableExclusion;4;themeColors;4;kdtId;4;payAssetActivityTagDesc;4;shopStoredDiscountInfo;4;useStoredCustomerDiscount;4;recommendDetaid;4;goods;4;shop;4;pointDeduction;4;pointsName;4;orderCreated;4;points;4;fansBenefit;4;themeCSS;4;customerCards;4;unavailableCustomerCards;4;displayCard;4;currentAddress;4;displayFreeCard;4;plusBuy;4;order;4;orderCreation;4;couponModel;4;isInCouponOverWhitelist;4;offlineId;4;state;4;postageModel;4",
            e: "sku:show;sku:hide;showCouponList;postagetool:show",
            el: "submit:act;showCouponList;postagetool:show;postagetool:limitInfo;postagetool:unavailableItem",
            w: "PrepayCardCell;PointDeductionCell;PointCell;FansCell;ActivityCell;ActivityDialog;DisplayCard;MembershipDialog;MembershipCell;PlusBuy;PlusBuyCard;CouponCell;CouponList;Postagetool;PostagetoolTip;PostagetoolCard;FansDialog",
            wc: "PrepaidRecommend;ActivityDialog;UserAuthorize;DisplayCard;MembershipDialog;Price;PlusBuyCard;PostagetoolCard;FansDialog;UserAuthorizePopup",
            lc: "queryAbTest",
            p: "showPrePayCardRecharge",
            pi: "setPrepayCardCheckStatus;fetchShow;setOrderForbidCoupon;setOrderForbidPreference;setDisableStoredDiscount;setPointDeductionUsed;setCustomCard;setDisplayCard;setPeriodBuyChosenIndex;switchPlusBuyGoodsProcess;switchGoods;fetchSkuData;addCouponProcess;setCouponChosenIdProcess;exchangeCouponPromise;getAddsOnePageDetail;calcPostage;modifyCacheOrder;fetchShowByBookKey;resetPostageTool;savePostageTool"
          }],
          [N, {
            d: "hasOpenExplainVideo;0;explainVideoFullScreen;0;themeCSS;4;hasLiving;4;goodsBaseInfo;4;goodsPriceInfo;4;umpCouponList;4;goodsActivity;4;currentActivity;4;pageFeature;4;shopConfig;4;bigButtons;4;danmakuSource;4;topCouponLabelList;4;showGoodsPromotion;4;supportSkuDirectOrder;4",
            e: "clickBigButton;page-container:scrollLocked",
            el: "goodsSetupReady",
            cc: "GoodsVideo"
          }],
          ["@wsc-tee-decorate/showcase-container", {
            d: "containerStyle;2;pointsConfig;2;rootKdtId;6;kdtId;6;featureComponents;6;extraData;4;imSourceDetail;6;alias;6;shopInfo;6;buyerId;6;shopConfig;6;themeColors;6;isTabPage;6;isHomePage;6;appId;6;isMultiStore;6;featureHotUpdate;6;renderMode;6;soldOutGoodsFlag;6;isUserCenter;6",
            e: "sku:show",
            w: "ShowcaseContainer",
            wc: "RetailShelfBanner;RetailShelfEntry;RetailShelfOrderPool;RetailShelfMemberCard;RetailShelfCustomerAsset;RetailShelfStoreCard;DecorateComponent",
            lc: "getUserInfo;jumpToLink",
            pi: "requestWechatSubscribeMessagePush",
            cc: "MessageContactButton",
            li: "onPullDownRefresh;onReachBottom;onPageShow;onPageHide"
          }],
          ["@wsc-tee-decorate/jump-link", {
            l: "jumpToLink",
            p: "jumpToLink"
          }],
          ["@ext-tee-user/fast-join-sdk", {
            d: "fastJoinHeaderInfo;2;kdtId;4;userInfo;4;shopInfo;4",
            w: "FastJoinHeader",
            wc: "FastJoinHeader",
            p: "launchFastJoinSDK"
          }],
          ["@ext-tee-wsc-goods/goods-showcase", {
            d: "openFloatGoods;2;kdtId;4;themeVars;4;offlineId;4;buyerId;4;shopMetaInfo;4;hasGoodsShowcase;4;goodsShocase;4",
            el: "goods:showcase"
          }],
          ["trade-buy-privacy-bill", {
            d: "privacyWaybill;4;display;4;tradeTag;4",
            w: "TradeBuyPrivacyBill",
            pi: "setOrderPrivacyBill",
            c: "PrivacyBillRulePopup",
            cc: "PrivacyBillRulePopup"
          }]
        ]
      }),
      E = o("9ZMt"),
      U = o("rLrQ"),
      G = o("xgC2"),
      L = o("2CfL"),
      _ = o("UzbL"),
      j = o.n(_);
    class W extends L.a {}
    W.widgets = {
      Main: j.a
    };
    var V = W,
      q = o("OxQY"),
      H = o.n(q);
    class K {
      constructor(e) {
        this.ctx = e.ctx
      }
    }
    K.widgets = {
      GuaranteeDetailBar: H.a
    };
    var z = o("jCRx"),
      Y = o.n(z),
      J = o("p1RP"),
      X = o.n(J),
      Q = o("8Cq2"),
      Z = o.n(Q);
    class $ {
      constructor(e) {
        this.ctx = e.ctx
      }
      onPageShow() {
        this.ctx.data.isPageVisible = !0
      }
      onPageHide() {
        this.ctx.data.isPageVisible = !1
      }
    }
    $.widgets = {
      Widget: Y.a,
      Danmaku: X.a
    }, $.components = {
      GoodsVideo: Z.a
    };
    var ee = o("YW/I"),
      te = o("NV8i"),
      oe = o("LY43"),
      se = o.n(oe),
      ae = o("Kkvk"),
      ie = o.n(ae);
    class ne {
      constructor(e) {
        this.ctx = e.ctx
      }
    }
    ne.widgets = {
      Widget: se.a,
      ShopTags: ie.a
    };
    var re = o("Z63Q"),
      ce = o.n(re);
    class de {}
    de.widgets = {
      Widget: ce.a
    };
    var ue = o("DR7t"),
      le = o.n(ue),
      pe = o("s3lA"),
      he = o.n(pe),
      ge = o("dhKv"),
      me = o.n(ge),
      be = o("Uv3o"),
      fe = o.n(be);
    class ye {
      constructor(e) {
        this.ctx = e.ctx, this.initCloudData()
      }
      initCloudData() {}
    }
    ye.widgets = {
      GoodsDetail: le.a,
      HaitaoNotification: he.a,
      PriceIntro: fe.a,
      DetailTitle: me.a
    };
    var ve = o("9mFz"),
      Se = o("VT8o"),
      ke = o.n(Se),
      we = o("Ffv9"),
      Ie = o.n(we),
      Be = o("tS13"),
      Ce = o("YxhU"),
      Pe = (e, t) => {
        var o = (e => {
            var t = e.find(e => e.skuScene === Be.c.ADD_CART),
              o = e.find(e => e.skuScene === Be.c.BUY);
            return t ? o ? Be.c.SEL_SKU : Be.c.ADD_CART : o ? Be.c.BUY : null
          })(e),
          a = e.filter(e => e.activityName === Ce.a.POINTS && e.btnActive === Be.a.OPEN_SKU).pop();
        a || (a = e.filter(e => e.primary && e.btnActive === Be.a.OPEN_SKU).pop());
        var {
          directOrder: i,
          directAddCart: n
        } = a || {}, r = o === Be.c.BUY && i, c = o === Be.c.ADD_CART && n;
        return {
          canAutoShow: !t && a && !(i || n),
          btn: Object(s.a)({}, a || {}, {
            skuScene: o,
            directOrder: r,
            directAddCart: c
          })
        }
      },
      De = o("Shdd");
    var xe = () => ({
        updateQuery(e) {
          this.query = e
        }
      }),
      Ae = o("US/N"),
      Oe = o("NHEX"),
      Te = o.n(Oe),
      Me = o("YehF"),
      Re = o("ONqW"),
      Ne = o("gBZH"),
      Fe = o("w2Y9"),
      Ee = o.n(Fe),
      Ue = o("lCVF"),
      Ge = o.n(Ue),
      Le = o("+I+c"),
      _e = o("Nvad"),
      je = ["spm"],
      We = e => {
        var {
          kdtId: t,
          env: o,
          query: s = {},
          spm: a
        } = e;
        return s.kdt_id = t, s
      },
      Ve = e => Object(Le.a)(e, je),
      qe = e => {
        if (Array.isArray(e))
          for (var t of e)
            if (Array.isArray(t.main))
              for (var o of t.main) o.text = Object(_e.b)(o.text);
        return e
      },
      He = e => {
        var {
          shopBaseInfo: t,
          goodsBaseInfo: o,
          goodsPriceInfo: s,
          offlineId: a
        } = e, {
          kdtId: i,
          name: n
        } = t, {
          pictures: r = [],
          alias: c,
          title: d,
          path: u
        } = o, {
          price: l
        } = s, p = r.map(e => e.url).slice(0, 3), h = {
          kdt_id: i,
          source: "goods",
          endpoint: "h5",
          detail: JSON.stringify({
            name: d,
            alias: c,
            price: l,
            imgs: p
          }),
          shopName: n,
          price: l
        };
        a && (h.site_id = a);
        h.endpoint = "mmp";
        var g = Ee.a.add(u, {
          imFrom: "GOODS",
          alias: c,
          price: l
        });
        return {
          sourceParam: JSON.stringify(h),
          title: d,
          picture: p[0],
          path: g
        }
      },
      Ke = e => {
        var {
          showDefaultCartText: t,
          cartText: o
        } = e;
        return t ? "购物车" : o
      },
      ze = e => {
        var {
          shopBaseInfo: t,
          shopConfig: o,
          goodsPriceInfo: s,
          goodsBaseInfo: a,
          env: i,
          cartCount: n = 0,
          query: r = {},
          spm: c = "",
          offlineId: d
        } = e, {
          pointsName: u = "积分"
        } = s, {
          kdtId: l
        } = t, p = function(e) {
          void 0 === e && (e = {});
          var {
            webImInGoodsConfig: t
          } = e;
          return t && JSON.parse(t).label || "客服"
        }(o), h = He({
          shopBaseInfo: t,
          goodsBaseInfo: a,
          goodsPriceInfo: s,
          offlineId: d
        }), g = Ke(o);
        return {
          im: {
            text: p,
            icon: "chat-o",
            type: "im",
            imConfig: h
          },
          shop: {
            text: "店铺",
            icon: "shop-o",
            type: "shop",
            link: {
              pageName: "Home",
              query: Ve({
                kdt_id: l,
                spm: c
              }),
              type: "switchTab"
            }
          },
          share: {
            text: "推广",
            icon: "share",
            type: "share"
          },
          cart: {
            text: g,
            icon: "cart-o",
            type: "cart",
            info: "" + (n || ""),
            link: {
              pageName: "Cart",
              query: We({
                kdtId: l,
                env: i,
                query: r,
                spm: c
              }),
              type: "navigate"
            }
          },
          gift: {
            text: "送人",
            icon: "gift-o",
            type: "gift"
          },
          point: {
            text: u,
            icon: "points",
            type: "point"
          },
          more: {
            text: "更多",
            icon: "more-o",
            type: "more"
          },
          activity: {
            text: "进活动",
            icon: "point-gift-o",
            type: "activity"
          },
          wholesale: {
            text: "进货单",
            icon: "shopping-cart-o",
            type: "wholesale",
            info: "" + (n || ""),
            link: {
              pageName: "WholesalePurchaseOrder",
              query: {},
              type: "navigate"
            }
          }
        }
      },
      Ye = "立即购买",
      Je = e => {
        var {
          pageFeature: t = {},
          shopConfig: o = {},
          goodsBaseInfo: a = {},
          goodsActivity: i = {},
          goodsPriceInfo: n = {}
        } = e, {
          showCartBtn: r,
          showBuyBtn: c,
          showPointsBtn: d
        } = t, {
          isShowBuyBtn: u,
          hideShoppingCart: l
        } = o, {
          presale: p
        } = i, {
          isVirtual: h
        } = a, g = Ke(o), m = function(e) {
          void 0 === e && (e = {});
          var {
            pageFeature: t = {},
            goodsBaseInfo: {
              isPrescriptionCategory: o = !1
            }
          } = e, {
            showDefaultBuyButtonText: s,
            buyButtonText: a = Ye
          } = t;
          return s ? o ? "立即预约" : Ye : a
        }({
          pageFeature: t,
          goodsBaseInfo: a
        }), b = [], f = {
          btnActive: Be.a.OPEN_SKU,
          skuScene: Be.c.BUY,
          activityName: "goods",
          accountUnionScene: Ne.a.NORMAL_BUY,
          submitAction: Be.d.TRADE_SUBMIT
        };
        if (r && b.push(Object(s.a)({}, f, {
            name: "add-cart",
            main: [{
              text: "加入" + g
            }],
            skuScene: Be.c.ADD_CART,
            accountUnionScene: Ne.a.ADD_CART
          })), c && u) {
          var y = Be.c.BUY;
          r || h || l || p || (y = Be.c.SEL_SKU), b.push(Object(s.a)({}, f, {
            name: "act-buy",
            main: [{
              text: m
            }],
            skuScene: y,
            primary: !0
          }))
        }
        if (p && (0 !== p.preSaleType || !r)) {
          var {
            price: v,
            minPrice: S,
            maxPrice: k
          } = n, {
            isDeposit: w,
            shipTimeStr: I,
            endTimeStr: B
          } = p, C = [{
            text: I
          }], P = [{
            text: m
          }], D = v, x = "";
          S && k && S !== k && (D = Ge()(S) + "起"), B && C.unshift({
            text: B
          }), w && (P = [{
            text: "支付定金"
          }, {
            text: "￥" + D
          }], x = Ye), 0 === b.length ? b.push(Object(s.a)({}, f, {
            name: "act-buy",
            main: P,
            sub: C,
            primary: !0,
            explainVideoBtnText: x
          })) : 1 === b.length && Object.assign(b[0], {
            main: P,
            sub: C,
            explainVideoBtnText: x
          }), d && Object.assign(b[0], {
            sub: []
          })
        }
        return 0 === b.length && b.push(Object(s.a)({}, f, {
          name: "act-buy",
          main: [{
            text: m
          }],
          primary: !0
        })), b
      },
      Xe = o("hkcG"),
      Qe = (e, t) => e && +e.startSoldTime - t.serverTimestamp,
      Ze = function(e, t) {
        if (void 0 === t && (t = {}), e && e[1]) {
          var {
            text: o
          } = e[1], {
            minPrice: s = 0,
            maxPrice: a = 0
          } = t, i = s === a, n = /到手¥([\d.]+)/.exec(o);
          n && n[1] && o.length > 10 && (e[1].text = o.slice(e[1].text.indexOf("到手"))), i && (e[1].text = o.replace("起", ""));
          var r = o.indexOf("起") > -1,
            c = o.indexOf("会员") > -1,
            d = o.indexOf("限时") > -1;
          n && n[1] && Object(Re.a)().log({
            et: "view",
            ei: "show_handprice_button",
            en: "展示到手价（立即购买按钮上）",
            params: {
              isshow_qi: r ? 0 : 1,
              is_activity: c ? 1 : d ? 0 : "",
              component: "estimated_price"
            }
          })
        }
        return e
      },
      $e = e => {
        var {
          goodsBaseInfo: t,
          goodsActivity: o,
          goodsPriceInfo: s,
          shopConfig: a,
          pageFeature: i,
          showSaleReminder: n,
          saleReminderStatus: r,
          isProductLaunch: c
        } = e, d = function(e) {
          void 0 === e && (e = {});
          var {
            goodsActivity: t,
            shopConfig: o,
            pageFeature: s,
            showSaleReminder: a,
            saleReminderStatus: i,
            isProductLaunch: n
          } = e, {
            waitToSold: r
          } = t, {
            showCartBtn: c
          } = s, d = Ke(o), u = [];
          if (r && (c && u.push({
              name: "add-cart",
              main: [{
                text: "加入" + d
              }],
              btnActive: Be.a.OPEN_SKU,
              skuScene: Be.c.ADD_CART,
              activityName: "goods",
              accountUnionScene: Ne.a.ADD_CART,
              submitAction: Be.d.TRADE_SUBMIT,
              waitToSold: !0
            }), a)) {
            var l = i,
              p = n ? "立即预约" : l ? "已设置提醒" : "开售提醒我";
            u.push({
              name: "wait-sold-eminder",
              primary: !0,
              skuScene: Be.c.SUBSCRIBE,
              subscribeStatus: l,
              disabled: l,
              main: [{
                text: p
              }],
              btnActive: Be.a.WX_SUBSCRIBE,
              subscribeSceneV2: Be.e.SALE_REMINDER,
              startSoldTime: r.startSoldTime,
              submitAction: Be.d.TRADE_SUBMIT,
              waitToSold: !0
            })
          }
          return u
        }({
          goodsActivity: o,
          shopConfig: a,
          pageFeature: i,
          showSaleReminder: n,
          saleReminderStatus: r,
          isProductLaunch: c
        }), u = Je({
          pageFeature: i,
          shopConfig: a,
          goodsBaseInfo: t,
          goodsActivity: o,
          goodsPriceInfo: s
        }), l = d.length > 0 ? [...d] : [...u];
        return 1 === l.length && (l[0].primary = !0), l
      },
      et = e => {
        var {
          pageFeature: t,
          goodsBaseInfo: o,
          bigButtons: s = []
        } = e, a = function(e) {
          void 0 === e && (e = {});
          var {
            pageFeature: t = {},
            goodsBaseInfo: {
              isOutlink: o
            }
          } = e;
          if (o) return [];
          var {
            showGiftBtn: s,
            showMiniShopBtn: a,
            showMiniCartBtn: i,
            showMiniPointsBtn: n,
            showShareBtn: r,
            showImBtn: c,
            showForbidBuyBtn: d,
            showMiniActivityButton: u
          } = t, l = {
            im: c,
            shop: a,
            cart: i,
            share: r && !d,
            gift: s && !d,
            point: n && !d,
            activity: u
          };
          return Object.keys(l).filter(e => l[e])
        }({
          pageFeature: t,
          goodsBaseInfo: o
        }), {
          showMoreBtn: i,
          maxMiniCount: n
        } = (e => {
          var {
            totalMiniButtons: t,
            bigButtons: o = []
          } = e, s = o.length, a = t.length;
          return 2 === s && a > 3 ? {
            maxMiniCount: 3,
            showMoreBtn: !0
          } : 1 === s && a > 4 ? {
            maxMiniCount: 4,
            showMoreBtn: !0
          } : {
            maxMiniCount: 8,
            showMoreBtn: !1
          }
        })({
          totalMiniButtons: a,
          bigButtons: s
        });
        if (i) {
          var r = a.slice(0, n - 1);
          return r.push("more"), {
            miniButtons: r,
            plusButtons: a.slice(n - 1)
          }
        }
        return {
          miniButtons: a,
          plusButtons: []
        }
      },
      tt = (e, t) => {
        var {
          goodsPriceInfo: o,
          buyConfig: a,
          userStateSupportSkuDirectOrder: i = !1,
          goodsBaseInfo: n
        } = t;
        if (e && e.length) {
          var r = e.slice(-2);
          return r.map((e, c) => {
            var {
              allowDeny: d
            } = e, u = n.isHaitao && e.skuScene !== Be.c.ADD_CART, l = ((e, t, o, s) => {
              var a = "buy" === e.skuScene && ["points"].indexOf(e.activityName) < 0 && ["soldout-reminder"].indexOf(e.name) < 0;
              if (!o || !a || t) return !1;
              var {
                goodsMetaInfo: i,
                goodsSkuData: n
              } = s, r = n[e.activityName], {
                noneSku: c,
                stockNum: d,
                list: u
              } = r || {};
              return !(i.showStockLackReminder && (c ? !d : null == u ? void 0 : u.some(e => !e.stockNum)))
            })(e, 1 === (null == a ? void 0 : a.buyLimitType), i, t), {
              directAddCart: p,
              directOrder: h
            } = ((e, t) => {
              var o, {
                  goodsMetaInfo: s,
                  featureSwitch: a,
                  goodsSkuData: i,
                  goodsActivity: n,
                  goodsBaseInfo: r,
                  shopBaseInfo: c
                } = e,
                d = Te()(s, "supportItemProps", !0) ? r.itemSalePropList : [],
                {
                  periodbuy: u,
                  virtualTicket: l
                } = n,
                p = Number(null == d ? void 0 : d.length) > 0,
                {
                  skuScene: h,
                  activityName: g,
                  name: m
                } = t,
                b = i[g],
                {
                  messages: f = [],
                  noneSku: y,
                  limit: v = {}
                } = b || {},
                S = Object(Me.e)(c),
                k = null != (o = v.startSaleNum) ? o : 1,
                w = !S && y && !f.length && !p,
                I = h === Be.c.BUY && [Xe.ActivityName.GOODS, Xe.ActivityName.GROUPON, Xe.ActivityName.AUCTION, Xe.ActivityName.TUAN, Xe.ActivityName.F_CODE, Xe.ActivityName.DISCOUNT, Xe.ActivityName.TIMELIMITED_DISCOUNT, Xe.ActivityName.PRESENT].indexOf(g) > -1 && ["addWish", "soldout-reminder"].indexOf(m) < 0;
              return {
                directAddCart: h === Be.c.ADD_CART && 1 === k && w,
                directOrder: !!a.isNoneSkuDirectOrder && w && !u && !l && !r.isCatering && I
              }
            })(t, e);
            return Object(s.a)({}, e, {
              key: "" + e.name + c,
              index: c,
              main: Ze(e.main, o),
              isFirst: 0 === c,
              isLast: c === r.length - 1,
              needSkuPop: !(p || h),
              isSkuDirectOrder: l,
              allowDeny: null != d ? d : !u,
              directAddCart: p,
              directOrder: h
            })
          })
        }
        return []
      },
      ot = {
        isProductLaunch: !1,
        showSaleReminder: !1,
        saleReminderStatus: !1
      },
      st = () => ({
        updateProductLaunch(e) {
          var t = "weapp" === E.default.getEnv(),
            o = Object.keys(e);
          this.isProductLaunch = t && o.some(e => "productLaunch" === e)
        },
        checkSaleReminder(e) {
          var {
            shopConfig: t,
            goodsActivity: o,
            serverStatus: s
          } = e, a = E.default.getEnv(), {
            platform: i
          } = this.env || {};
          if ("weapp" === a || "web" === a && "weixin" === i) {
            var n = (e => {
              var {
                shopConfig: t,
                goodsActivity: o,
                serverStatus: s
              } = e, {
                goodsSalesReminder: a
              } = t, {
                waitToSold: i
              } = o, n = Qe(i, s);
              return !!(+a && i && n > 3e5 && n < 31536e7)
            })({
              shopConfig: t,
              goodsActivity: o,
              serverStatus: s
            });
            if (this.showSaleReminder = n, n) return this.getSubscribeStatus()
          }
          return Promise.resolve()
        },
        getSubscribeStatus() {
          var {
            id: e
          } = this.goodsBaseInfo;
          return e && e !== this.goodsId ? (this.goodsId = e, Object(Ae.default)({
            path: "/wscgoods/hasSaleReminder.json",
            data: {
              itemId: e
            },
            withCredentials: !0
          }).then(e => (this.saleReminderStatus = !!e, Promise.resolve())).catch(() => Promise.resolve())) : Promise.resolve()
        },
        updateSaleReminderStatus(e) {
          this.saleReminderStatus = e, this.productLaunchReminderSuccess(e)
        }
      }),
      at = o("2xJD");

    function it(e, t) {
      return void 0 !== t && e.forEach(e => {
        var {
          allowDeny: o,
          accountUnionScene: s
        } = e, a = [Ne.a.ADD_CART, Ne.a.NORMAL_BUY].includes(s);
        e.allowDeny = a ? t : o
      }), e
    }
    var nt = () => ({
        getEduInfo() {
          if (this.isEduShop = Object(at.c)(this.shopMetaInfo), !this.authorizationPromise && this.isEduShop) {
            var {
              isPhysical: e
            } = this.goodsBaseInfo;
            this.authorizationPromise = function(e, t) {
              return Object(Ae.default)({
                path: "/wscgoods/xgj-api/authorization.json",
                method: "GET",
                query: {
                  kdtId: e
                }
              }).then(e => {
                var {
                  mandatoryAuthorization: o,
                  xgjAvailable: s
                } = e, a = E.default.getEnv();
                return "weapp" === a ? !(o && s && t) : "web" === a ? !s : void 0
              }).catch(() => {})
            }(this.shopBaseInfo.kdtId, e).then(e => {
              this.eduAllowDeny = e
            })
          }
        },
        setEduButtoms(e) {
          var {
            bigButtons: t = []
          } = e;
          return new Promise(o => {
            this.isEduShop ? void 0 !== this.eduAllowDeny ? o(Object(s.a)({}, e, {
              bigButtons: it(t, this.eduAllowDeny)
            })) : this.authorizationPromise && this.authorizationPromise.then(() => {
              o(Object(s.a)({}, e, {
                bigButtons: it(t, this.eduAllowDeny)
              }))
            }) : o(e)
          })
        }
      }),
      rt = o("AGZf");
    var ct = o("zjWU");

    function dt(e, t) {
      ct.a.end({
        name: "addCart" === e.skuScene ? ct.b.add_cart : ct.b.buy_now,
        type: "finish",
        extra: {
          message: t
        }
      })
    }

    function ut(e, t, o) {
      var {
        btnActive: a = Be.a.DEFAULT,
        name: i,
        allowDeny: n
      } = t;
      if (a === Be.a.WX_SUBSCRIBE) return e.event.emit("subscribe:show", Object(s.a)({}, t, {
        itemId: o
      })), void dt(t, "需要先订阅公众号消息");
      if (!t.disabled)
        if (a === Be.a.OPEN_SKU) {
          if (!e.data.bottomBtnClicked) {
            e.data.bottomBtnClicked = !0;
            try {
              e.hummer.mark.start("goods-detail-sku-popup"), e.hummer.mark.start("goods-sku-order-popup")
            } catch (e) {}
          }
          e.event.emit("sku:show", Object(s.a)({}, t, {
            authAllowDeny: n
          })), e.event.emit("big-btn:click", t)
        } else if (a === Be.a.SUBMIT) e.event.emit("submit:act", t);
      else if ("outlink" === i) {
        var {
          pageName: r,
          query: c
        } = t.link;
        dt(t, "跳转外部链接"), e.dmc.createUrl(r, c).then(e => {
          Object(Re.a)().log({
            et: "click",
            ei: "go_external_buy",
            en: "点击外链购买按钮",
            params: {
              url: e
            }
          })
        })
      }
    }

    function lt(e, t) {
      var o = E.default.getGlobal("GOODS_DATA") || {};
      return t.reduce((t, s) => {
        var a;
        return t[s] = null != (a = e[s]) ? a : o[s], t
      }, {})
    }
    var pt = function(e) {
        return {
          resolveBtnProcess: t => e.process.invokePipe("setBottomBtns", t),
          updateBtnsUI() {
            var {
              goodsBaseInfo: t = {},
              goodsActivity: o = {},
              goodsPriceInfo: a = {},
              shopConfig: i = {},
              pageFeature: n = {},
              shopBaseInfo: r = {},
              buyConfig: c = {},
              serverStatus: d = {},
              umpActivity: u = {}
            } = lt(e.data, ["goodsBaseInfo", "goodsActivity", "goodsPriceInfo", "shopConfig", "pageFeature", "shopBaseInfo", "buyConfig", "serverStatus", "umpActivity"]);
            this.checkSaleReminder({
              shopConfig: i,
              goodsActivity: o,
              serverStatus: d
            }).then(() => {
              var {
                showSaleReminder: l,
                saleReminderStatus: p,
                isProductLaunch: h
              } = this;
              this.updateProductLaunch(u);
              var g = $e({
                  goodsBaseInfo: t,
                  goodsActivity: o,
                  goodsPriceInfo: a,
                  shopConfig: i,
                  pageFeature: n,
                  showSaleReminder: l,
                  saleReminderStatus: p,
                  isProductLaunch: h
                }),
                m = et({
                  pageFeature: n,
                  goodsBaseInfo: t,
                  bigButtons: g
                }),
                {
                  goodsMetaInfo: b = {}
                } = this,
                f = function(e) {
                  void 0 === e && (e = {});
                  var {
                    goodsBaseInfo: t = {},
                    goodsActivity: o = {},
                    goodsPriceInfo: a = {},
                    goodsMetaInfo: i = {},
                    shopBaseInfo: n = {},
                    pageFeature: r = {},
                    buyConfig: c = {},
                    serverStatus: d = {},
                    showSaleReminder: u = !1
                  } = e, {
                    isOutlink: l,
                    isDisplay: p
                  } = t, {
                    waitToSold: h
                  } = o, {
                    showStockLackReminder: g,
                    stockRemindStatus: m = {}
                  } = i, {
                    stockNum: b
                  } = a, {
                    kdtId: f
                  } = n, {
                    showForbidBuyBtn: y,
                    showCartBtn: v
                  } = r, {
                    buyLimitType: S
                  } = c, k = Qe(h, d), w = null, I = {
                    btnActive: Be.a.SUBMIT,
                    submitAction: Be.d.JUMP_LINK,
                    link: {
                      pageName: "Home",
                      query: {
                        kdt_id: f
                      },
                      type: "switchTab"
                    },
                    forbid: !0
                  };
                  if (!d.fetchSuccess && b > 0) w = {
                    name: "preview-buy",
                    main: [{
                      text: "立即抢购"
                    }],
                    primary: !0,
                    btnActive: Be.a.OPEN_SKU,
                    skuScene: Be.c.PREVIEW_SKU
                  };
                  else if (y) {
                    w = [Object(s.a)({
                      name: "homepage",
                      main: [{
                        text: g ? "查看其他商品" : "查看店铺其他商品"
                      }],
                      primary: !g
                    }, I)];
                    var {
                      hasRemindSpuStock: B
                    } = m, C = void 0 === B;
                    if (g && b <= 0) {
                      var P = {
                        name: "soldout-reminder",
                        main: [{
                          text: B ? "已提醒补货" : "提醒商家补货"
                        }],
                        btnActive: C ? Be.a.OPEN_SKU : Be.a.WX_SUBSCRIBE,
                        skuScene: Be.c.BUY,
                        activityName: Xe.ActivityName.GOODS,
                        primary: !0,
                        accountUnionScene: Ne.a.NORMAL_BUY,
                        subscribeSceneV2: Be.e.STOCK_REMINDER,
                        submitAction: Be.d.TRADE_SUBMIT
                      };
                      C || (P.subscribeStatus = B, P.disabled = B), w.push(P)
                    }
                  } else if (1 !== p) w = Object(s.a)({
                    name: "not-display",
                    main: [{
                      text: "下架啦，看看其他商品吧！"
                    }]
                  }, I, {
                    primary: !0
                  });
                  else if (l) w = Object(s.a)({
                    name: "outlink",
                    main: [{
                      text: "商品已下架，去看看其他商品吧"
                    }]
                  }, I, {
                    primary: !0,
                    disabled: !0
                  });
                  else if ([2, 3].indexOf(S) > -1) {
                    w = {
                      name: "limit-buy",
                      main: [{
                        text: 2 === S ? "仅限特定会员购买" : "已达最大限购数量"
                      }],
                      btnActive: Be.a.BREAK_OFF,
                      disabled: !0,
                      forbid: !0
                    }
                  } else b <= 0 ? w = Object(s.a)({
                    name: "soldout",
                    main: [{
                      text: "已售罄，看看其他商品吧"
                    }]
                  }, I, {
                    primary: !0
                  }) : h && k > 0 && !v && !u && (w = {
                    name: "wait-sold",
                    main: [{
                      text: "即将开售"
                    }],
                    btnActive: Be.a.BREAK_OFF,
                    disabled: !0
                  });
                  return !w || w instanceof Array ? w : [w]
                }({
                  goodsBaseInfo: t,
                  goodsActivity: o,
                  goodsPriceInfo: a,
                  goodsMetaInfo: b,
                  shopBaseInfo: r,
                  pageFeature: n,
                  buyConfig: c,
                  serverStatus: d,
                  showSaleReminder: l
                });
              return this.isFirstRender && (this.bigButtons = g, this.miniButtons = m.miniButtons, this.plusButtons = m.plusButtons, this.disabledBigButton = f, this.processBtnData(), this.isFirstRender = !1), Object(De.a)(this, [this.resolveMemberBtns, this.setUmpBottomBtns, this.resolveBtnProcess, this.setEduButtoms], {
                tips: {},
                bigButtons: g,
                miniButtons: m.miniButtons || [],
                plusButtons: m.plusButtons || [],
                disabledBigButton: f,
                extra: Object(s.a)({}, e.data.pageFeature)
              }).then(t => {
                this.hasResolveProcess = !0, t && (this.bigButtons = t.bigButtons || this.bigButtons, this.miniButtons = t.miniButtons || this.miniButtons, this.plusButtons = t.plusButtons || this.plusButtons, this.disabledBigButton = t.disabledBigButton, this.processBtnData()), e.process.invoke("handleDataReady"), e.hummer && e.hummer.markRendered("bottom-btns:loaded"), this.doLogger()
              }).catch(e => {
                ! function(e) {
                  void 0 === e && (e = {});
                  var {
                    message: t = "",
                    stack: o = ""
                  } = e, s = JSON.stringify({
                    title: "ext-tee-wsc-goods::bottom-btn:error",
                    extra: {
                      message: t,
                      stack: o,
                      info: e
                    }
                  });
                  Object(Ae.default)({
                    path: "/wscgoods/log",
                    method: "GET",
                    data: {
                      logtype: E.default.getEnv(),
                      msg: s,
                      timestamp: +new Date
                    }
                  })
                }(e)
              })
            }), this.processRefreshCartCount()
          },
          processBtnData() {
            var {
              goodsPriceInfo: t = {},
              buyConfig: o = {},
              goodsSkuData: s = {},
              userStateSupportSkuDirectOrder: a = !1,
              goodsActivity: i = {},
              featureSwitch: n = {},
              goodsBaseInfo: r = {},
              goodsMetaInfo: c = {},
              shopBaseInfo: d = {}
            } = lt(e.data, ["goodsPriceInfo", "buyConfig", "goodsSkuData", "userStateSupportSkuDirectOrder", "goodsActivity", "featureSwitch", "goodsBaseInfo", "goodsMetaInfo", "shopBaseInfo"]), {
              disabledBigButton: u,
              bigButtons: l
            } = this, p = tt(u || l, {
              goodsSkuData: s,
              goodsPriceInfo: t,
              buyConfig: o,
              userStateSupportSkuDirectOrder: a,
              goodsActivity: i,
              featureSwitch: n,
              goodsBaseInfo: r,
              goodsMetaInfo: c,
              shopBaseInfo: d
            });
            this.bigButtons = p, e.data.bigButtons = p, e.data.disabledBigButton = u, this.processAutoOpenSku(), this.processMiniBtnData(), this.btnLoaded = !0
          },
          processAutoOpenSku() {
            var {
              env: {
                isMobile: t = !1,
                showSku: o = !1
              } = {},
              userState: {
                isAdmin: s = !1
              } = {},
              pageFeature: {
                showForbidBuyBtn: a = !1
              } = {}
            } = lt(e.data, ["env", "userState", "pageFeature"]), {
              bigButtons: i
            } = this, {
              canAutoShow: n,
              btn: r
            } = Pe(i, a);
            o && (!s || t) && n && e.event.emit("sku:show", r)
          },
          processMiniBtnData() {
            var t, {
                env: o = {},
                goodsPriceInfo: s = {},
                goodsBaseInfo: a = {},
                shopBaseInfo: i = {},
                shopConfig: n = {},
                cartCount: r,
                offlineId: c
              } = lt(e.data, ["env", "goodsPriceInfo", "goodsBaseInfo", "shopBaseInfo", "shopConfig", "cartCount", "offlineId"]),
              {
                miniButtons: d,
                plusButtons: u,
                query: l
              } = this,
              p = ze({
                shopBaseInfo: i,
                shopConfig: n,
                goodsPriceInfo: s,
                goodsBaseInfo: a,
                cartCount: r,
                env: o,
                query: l,
                spm: null == (t = e.logger) ? void 0 : t.getSpm(),
                offlineId: c
              });
            this.miniButtonsData = d.map(e => p[e]), this.plusButtonsData = u.map(e => p[e])
          },
          processCheckShowFollow(t) {
            var {
              umpActivityData: {
                currentActivity: o = {}
              } = {}
            } = lt(e.data, ["umpActivityData"]);
            ! function(e, t) {
              var {
                btn: o,
                currentActivity: s,
                query: a,
                itemId: i
              } = t, {
                type: n,
                followWays: r,
                useFollow: c,
                threshold: d,
                supportFans: u
              } = s;
              if (u) {
                var {
                  ump_alias: l,
                  umpAlias: p
                } = a || {};
                e.process.invokePipe("checkShowFollow", {
                  activityType: n,
                  activityKey: l || p,
                  followWays: r,
                  useFollow: c,
                  threshold: d
                }).then(t => {
                  var {
                    extraData: s,
                    needFollow: a
                  } = t;
                  a ? (e.event.emit("follow:show", {
                    extraData: s
                  }), dt(o, "需要先关注店铺公众号")) : ut(e, o, i)
                })
              } else ut(e, o, i)
            }(e, {
              btn: t,
              currentActivity: o,
              query: this.query,
              itemId: this.goodsBaseInfo.id
            })
          },
          handleImClick(e) {
            var t = e,
              {
                miniBtns: o = []
              } = this.btnsOpt,
              s = o.filter(e => "im" === e.type);
            if (s[0]) {
              var {
                imConfig: a = {}
              } = s[0], {
                sourceParam: i = {}
              } = a;
              t = "string" == typeof i ? JSON.parse(i) : i
            }
            this.ctx.process.invokePipe("showYZIm", t)
          },
          processRefreshCartCount() {
            e.process.invokePipe("updateCartCount")
          },
          handleBigBtnClick(e) {
            var t, o, {
              currentActivity: s = {},
              shopBaseInfo: a,
              goodsBaseInfo: i,
              serverStatus: n,
              goodsSkuData: r
            } = this;
            3 === s.buttonType && Object(Re.a)().log({
              et: "click",
              ei: "click_share",
              en: "和好友拼点击"
            }), e.btnActive !== Be.a.SUBMIT && e.btnActive !== Be.a.OPEN_SKU || ct.a.start({
              name: "addCart" === e.skuScene ? ct.b.add_cart : ct.b.buy_now
            }), "points-exchange" === e.name && (t = i, o = r, Object(Re.a)().log({
              et: "click",
              ei: "click_exchange_goods_by_score_button",
              en: "点击积分兑换商品按钮",
              params: {
                goods_id: t.id,
                goods_name: t.title,
                sku_id: o.goods.skuId
              }
            })), this.triggerUmpBigBtnLog(e);
            var c = function(e) {
              void 0 === e && (e = {});
              var {
                shopBaseInfo: t,
                goodsBaseInfo: o,
                serverStatus: s
              } = e, {
                isHqShopPreview: a = !1
              } = t, {
                stockNum: i
              } = o, {
                fetchSuccess: n
              } = s;
              return !n && i > 0 ? {
                message: "抢购人数太多\n请等待",
                autoReload: 5
              } : a ? {
                message: "总店预览商品不支持下单购买",
                autoReload: 0
              } : null
            }({
              shopBaseInfo: a,
              goodsBaseInfo: i,
              serverStatus: n
            });
            if (c) return ct.a.end({
                name: "addCart" === e.skuScene ? ct.b.add_cart : ct.b.buy_now,
                type: "finish",
                extra: {
                  message: c.message || ""
                }
              }),
              function(e) {
                if (e) {
                  var {
                    message: t = "",
                    autoReload: o = 0
                  } = e;
                  if (t) {
                    var s = rt.a.loading({
                      message: t,
                      duration: 1e3 * (o || 2),
                      forbidClick: !!o,
                      position: "bottom"
                    });
                    if (o) {
                      var a = o,
                        i = () => {
                          a--, s.message = t + "(" + a + "s)", a > 0 ? setTimeout(i, 1e3) : E.default.$native.startPullDownRefresh()
                        };
                      i()
                    }
                  }
                }
              }(c);
            this.processCheckShowFollow(e)
          },
          doLogger() {},
          setGoodsBottomShow(e) {
            this.showBottomBtns = e
          },
          setOfflineId(e) {
            this.offlineId = e
          }
        }
      },
      ht = {
        imConfig() {
          var {
            shopBaseInfo: e,
            goodsBaseInfo: t,
            goodsPriceInfo: o,
            offlineId: s
          } = this;
          return He({
            shopBaseInfo: e,
            goodsBaseInfo: t,
            goodsPriceInfo: o,
            offlineId: s
          })
        },
        contactSlot() {
          return this.plusButtonsData.some(e => "im" === e.type) ? "plusIm" : "im"
        },
        btnsOpt() {
          var {
            alias: e,
            id: t,
            title: o,
            picture: s
          } = this.goodsBaseInfo, {
            minPrice: a,
            price: i
          } = this.goodsPriceInfo;
          return {
            alias: e,
            goodsId: t,
            title: o,
            picture: s,
            minPrice: a,
            price: i,
            miniBtns: this.miniButtonsData,
            plusMiniBtns: this.plusButtonsData,
            bigButtons: qe(this.bigButtons),
            contactSlot: this.contactSlot,
            kdtId: this.shopBaseInfo.kdtId,
            fetchSuccess: this.serverStatus.fetchSuccess,
            hasResolveProcess: this.hasResolveProcess
          }
        }
      },
      gt = {
        state: Object(s.a)({}, ot, {
          showBottomBtns: !0,
          hasResolveProcess: !1,
          disabledBigButton: null,
          goodsId: 0,
          offlineId: 0,
          isFirstRender: !0,
          bigButtons: [],
          miniButtons: [],
          plusButtons: [],
          bigButtonsData: [],
          miniButtonsData: [],
          plusButtonsData: [],
          hasInvokeHook: !1
        }),
        getters: ht,
        getActions: e => Object(s.a)({}, st(), nt(), pt(e))
      },
      mt = {
        state: {
          disabledTip: {}
        },
        getters: {
          goodsDisabledTip() {
            var {
              pageFeature: e = {},
              goodsBaseInfo: t,
              goodsPriceInfo: o
            } = this, {
              forbidBuyReason: s = ""
            } = e, {
              isDisplay: a = 1
            } = t, {
              stockNum: i = 0
            } = o;
            return 1 !== a ? {
              text: "商品下架啦"
            } : i ? {
              text: s
            } : {
              text: ""
            }
          },
          fixBottomOpt() {
            var {
              waitToSold: e
            } = this.goodsActivity, {
              risk: t,
              verifyStatus: o
            } = this.goodsBaseInfo;
            return {
              show: !this.shopConfig.isCloseBusiness && !this.env.hideGoodsBottom && 2 === o,
              disabledTip: this.disabledTip,
              risk: t || {
                match: !1,
                note: ""
              },
              serverStatus: this.serverStatus,
              waitToSold: e
            }
          }
        },
        getActions: e => ({
          setBottomTipProcess: t => e.process.invokePipe("setBottomTip", t),
          setDisabledTip() {
            var e = this;
            this.disabledTip = this.goodsDisabledTip, Object(De.a)(this, [this.setUmpBottomTip, this.setBottomTipProcess], this.disabledTip).then(function(t) {
              void 0 === t && (t = {}), e.disabledTip = t
            })
          }
        })
      },
      bt = o("sXPE"),
      ft = o("YeA1"),
      yt = ["tips", "extra", "disabledBigButton"];

    function vt(e, t) {
      var {
        buyLimitGuideInfo: o,
        shopBaseInfo: a,
        memberActivity: i,
        pointsConfig: n,
        goodsEstimatePriceData: r = {},
        isCoupon: c,
        env: d
      } = t, {
        tips: u,
        extra: l = {},
        disabledBigButton: p
      } = e, h = Object(Le.a)(e, yt), {
        bigButtons: g = []
      } = e, m = (p || [])[0] || {};
      if ("limit-buy" === m.name) {
        if (o && o.needGuide) return m = function(e) {
          var {
            buyLimitGuideInfo: t,
            shopBaseInfo: o,
            env: a
          } = e, {
            kdtId: i
          } = o, {
            guideType: n,
            guideTargetAlias: r
          } = t, {
            route: c,
            getQuery: d
          } = a, u = Ee.a.add(c, d()), l = {
            pageName: "UserMemberCard",
            query: Object(s.a)({
              kdt_id: i,
              shopAutoEnter: 1,
              guideType: "goods",
              redirectUrl: u
            }, "web" === E.default.getEnv() ? {
              card_alias: r
            } : {
              alias: r
            })
          }, p = "", h = "", g = "", m = {}, b = "商详页_限购按钮曝光";
          switch (n) {
            case bt.d.FREE_MEMBER:
              m = {
                pageName: "FreeMemberRegister",
                query: {
                  kdt_id: i,
                  alias: r,
                  guideType: "goods",
                  redirectUrl: u
                }
              }, p = "仅限会员购买，一键注册", h = "view_button_free", g = b + "_免费会员";
              break;
            case bt.d.PAY_MEMBER:
              m = {
                pageName: "PayMemberRegister",
                query: {
                  kdt_id: i,
                  alias: r,
                  guideType: "goods",
                  redirectUrl: u
                }
              }, p = "仅限会员购买，点击办理", h = "view_button_pay", g = b + "_付费会员";
              break;
            case bt.d.FREE_BENEFIT_CARD:
              m = l, p = "限持卡客户购买，一键领卡", h = "view_button_card", g = b + "_权益卡";
              break;
            case bt.d.PAY_BENEFIT_CARD:
              m = l, p = "限持卡客户购买，立即开卡", h = "view_button_card", g = b + "_权益卡";
          }
          return Object(Re.a)().log({
            et: "view",
            ei: h,
            en: g
          }), {
            name: "limit-buy",
            main: [{
              text: p
            }],
            accountUnionScene: "",
            authTypeList: ["mobile"],
            link: m,
            btnActive: Be.a.SUBMIT,
            submitAction: bt.h.LIMIT_BUY_GUIDE,
            primary: !0
          }
        }({
          buyLimitGuideInfo: o,
          shopBaseInfo: a,
          env: d
        }), Object(s.a)({}, e, {
          disabledBigButton: [m]
        })
      }
      if (i && i[bt.a.DISCOUNT]) {
        var {
          type: b
        } = i[bt.a.DISCOUNT];
        g.forEach(e => {
          e.activityName = bt.f.DISCOUNT, e.primary && b === bt.a.GOODS_SCAN && (e.memberActType = b)
        })
      }
      if (r && r.umpType === bt.a.CUSTOMER_DISCOUNT && !c) {
        var f, y, {
            buttonUmpText: v = {}
          } = r,
          {
            umpTag: S = ""
          } = v;
        null == (f = g.find(e => e.primary)) || null == (y = f.main) || y.push({
          text: S
        })
      }
      var k = !!Te()(i, bt.f.POINTS, null),
        w = Te()(n, "name", "积分"),
        {
          showPointsBtn: I,
          showPointsButtonStatus: B
        } = l || {},
        C = 1 === B,
        P = Te()(i, bt.f.POINTS + ".buyLimit") === bt.c.ALLOW;
      if (I && k) {
        P || (g = g.filter(e => e.skuScene !== Be.c.BUY));
        var D = "points-exchange";
        g.unshift({
          name: D,
          main: [{
            text: w + "兑换"
          }],
          disable: C,
          skuScene: C ? Be.c.DISABLE : Be.c.BUY,
          accountUnionScene: D,
          submitAction: Be.d.TRADE_SUBMIT,
          btnActive: C ? "breakOff" : "openSku",
          activityName: bt.f.POINTS,
          primary: !g.length
        })
      }
      return Object(s.a)({}, h, {
        tips: u,
        bigButtons: g,
        extra: l,
        disabledBigButton: p
      })
    }
    var St = {
      [bt.h.LIMIT_BUY_GUIDE]: e => {
        var {
          data: t,
          extra: o
        } = e, {
          userInfo: s,
          buyLimitGuideInfo: a,
          launchFastJoin: i
        } = o || {};
        if (s && s.mobile) {
          var {
            guideType: n
          } = a || {}, r = "", c = "", d = "商详页_限购按钮点击";
          switch (n) {
            case bt.d.FREE_MEMBER:
              r = "click_button_free", c = d + "_免费会员";
              break;
            case bt.d.PAY_MEMBER:
              r = "click_button_pay", c = d + "_付费会员";
              break;
            case bt.d.FREE_BENEFIT_CARD:
            case bt.d.PAY_BENEFIT_CARD:
              r = "click_button_card", c = d + "_权益卡";
          }
          Object(Re.a)().log({
            et: "click",
            ei: r,
            en: c
          });
          var {
            pageName: u,
            query: l
          } = t.link;
          if (n === bt.d.FREE_MEMBER) return l.alias && delete l.alias, void(i && i(l));
          Object(ft.a)().dmc.navigate(u, l)
        } else setTimeout(() => {
          E.default.$native.startPullDownRefresh()
        }, 1e3)
      }
    };
    var kt = {
        state: {
          memberActivity: {},
          pointsConfig: {},
          isCoupon: !1,
          userInfo: {},
          buyLimitGuideInfo: {}
        },
        getActions: e => ({
          onMiniPointBtnClick(t) {
            if ("point" === t.type) {
              var o = "points-exchange";
              e.event.emit("sku:show", {
                name: o,
                skuScene: Be.c.BUY,
                accountUnionScene: o,
                submitAction: Be.d.TRADE_SUBMIT,
                btnActive: "openSku",
                activityName: bt.f.POINTS
              })
            }
          },
          resolveMemberBtns(t) {
            var {
              memberActivity: o,
              pointsConfig: s,
              goodsEstimatePriceData: a = {},
              isCoupon: i,
              buyLimitGuideInfo: n,
              shopBaseInfo: r
            } = this;
            return vt(t, {
              buyLimitGuideInfo: n,
              shopBaseInfo: r,
              memberActivity: o,
              pointsConfig: s,
              goodsEstimatePriceData: a,
              isCoupon: i,
              env: e.env
            })
          },
          onMemberCustomEvent(t) {
            ! function(e) {
              var {
                type: t,
                data: o,
                extra: s
              } = e, a = St[t];
              a && a({
                type: t,
                data: o,
                extra: s
              })
            }(Object(s.a)({}, t, {
              extra: {
                userInfo: this.userInfo,
                buyLimitGuideInfo: this.buyLimitGuideInfo,
                launchFastJoin: t => {
                  e.process.invoke("launchFastJoinSDK", Object(s.a)({}, t, {
                    successCallback: () => {
                      E.default.$native.startPullDownRefresh()
                    }
                  }))
                }
              }
            }))
          }
        })
      },
      wt = {
        getters: {
          isSupportFCodeBuy() {
            var {
              isSupportFCode: e
            } = this.goodsMetaInfo, {
              showForbidBuyBtn: t
            } = this.pageFeature;
            return e && t
          },
          soldOutRecOpt() {
            var {
              showSoldOutButtonType: e,
              showForbidBuyBtn: t
            } = this.pageFeature, {
              id: o,
              alias: s,
              isDisplay: a,
              isOutlink: i
            } = this.goodsBaseInfo, {
              salableStores: n,
              id: r
            } = this.multistore || {};
            return {
              show: !!(1 === a && !i && this.goodsPriceInfo && this.goodsPriceInfo.stockNum <= 0 && !(n && n.length) && !this.isSupportFCodeBuy) && this.btnLoaded,
              multistoreId: r,
              kdtId: this.shopBaseInfo.kdtId,
              showSoldOutButtonType: e,
              showForbidBuyBtn: t,
              goodsId: o,
              alias: s
            }
          }
        },
        getActions: e => ({
          setIsNoStock() {
            e.data.isNoStock = this.soldOutRecOpt.show
          }
        })
      },
      It = {
        getters: {
          multiStoreRecOpt() {
            var {
              salableStores: e = []
            } = this.multistore || {};
            return {
              show: e.length && this.btnLoaded,
              salableStores: e,
              alias: this.goodsBaseInfo.alias
            }
          }
        }
      },
      Bt = o("lgMb"),
      Ct = o("+66q"),
      Pt = o("sIkL"),
      Dt = (e, t) => {
        Object(ft.a)().dmc.navigate(e, t)
      };
    var xt = {
        state: {
          buttonUmpTimelimitModel: void 0,
          isGroupOn: !1,
          seActivity: {},
          buyButtonPop: {},
          showSharePop: !1
        },
        getters: {
          umpTipsOpt() {
            var e = this.goodsSkuData[Ct.a.INSOURCING_FISSION];
            return {
              show: this.btnLoaded,
              kdtId: this.shopBaseInfo.kdtId,
              seActivity: this.seActivity,
              buyButtonPop: this.buyButtonPop,
              currentActivity: this.currentActivity,
              fissionSku: e,
              buttonUmpTimelimitModel: this.buttonUmpTimelimitModel,
              isGroupOn: this.isGroupOn,
              query: this.query,
              stockNum: this.goodsPriceInfo.stockNum,
              showSharePop: this.showSharePop
            }
          }
        },
        getActions: e => ({
          triggerUmpBigBtnLog(e) {
            var t, {
                currentActivity: o
              } = this,
              s = e.main.slice(-1),
              a = {
                activityId: o.activityId,
                type: o.type,
                activityName: o.activityName,
                btn_name: s && s[0].text
              };
            if (Object(Re.a)().log({
                et: "click",
                ei: "ump_bottom_click",
                en: "ump底部按钮点击",
                params: a
              }), "groupOn" === e.activityName && Object(Re.a)().log({
                et: "click",
                ei: "open_group",
                en: "\b开团"
              }), null != (t = this.goodsEstimatePriceData) && t.num) {
              var {
                num: i
              } = this.goodsEstimatePriceData;
              Object(Re.a)().log({
                et: "view",
                ei: i > 1 ? "show_unit_price" : "show_handprice",
                en: i > 1 ? "展示预估单价" : "展示到手价",
                params: {
                  component: "sku",
                  num: i
                }
              })
            }
          },
          setUmpBottomBtns(t) {
            try {
              return function(e, t, o) {
                var {
                  currentActivity: a = {},
                  umpActivity: i = {},
                  goodsSkuData: n,
                  goodsPriceInfo: r,
                  limitedEstimate: c = {},
                  query: d = {},
                  goodsActivity: u,
                  kdtId: l,
                  alias: p,
                  marketing: h
                } = t, {
                  type: g
                } = a;
                if (!g && i[Ct.a.COUPON] && (g = [Ct.a.COUPON]), u.periodbuy) {
                  var m = [...e.bigButtons];
                  m[0].skuScene = Be.c.BUY, e = Object(s.a)({
                    bigButtons: m
                  }, e)
                }
                c && c.buttonUmpText && "timelimitedDiscount" !== g && (g = "estimatePrice");
                var b = Pt.a.buttonFormaterFactory(g, e, {
                  currentActivity: a,
                  umpActivity: i,
                  sku: n,
                  alias: p,
                  kdtId: l,
                  priceInfo: r,
                  goodsActivity: u,
                  marketing: (o && h.buttonUmpTextModel && (h.buttonUmpTextModel.umpTag = h.buttonUmpTextModel.umpTag.replace(/\d+(\.\d+)?/, o)), h),
                  query: d,
                  limitedEstimate: c
                });
                return "gift" === d.type && (b.bigButtons = [b.bigButtons.find(e => e.primary)], b.bigButtons[0] = Object(s.a)({}, b.bigButtons[0], {
                  main: [{
                    text: "我要送礼"
                  }],
                  activityName: "gift",
                  skuScene: Be.c.ADD_CART,
                  btnActive: Be.a.OPEN_SKU,
                  submitAction: Be.d.TRADE_SUBMIT
                })), b
              }(t, {
                currentActivity: this.currentActivity,
                umpActivity: this.umpActivity,
                goodsSkuData: this.goodsSkuData,
                goodsPriceInfo: this.goodsPriceInfo,
                limitedEstimate: this.limitedEstimate,
                query: this.query,
                goodsActivity: this.goodsActivity,
                kdtId: this.shopBaseInfo.kdtId,
                alias: this.goodsBaseInfo.alias,
                marketing: this.marketing
              }, e.data.estimatePrice)
            } catch (t) {
              throw t.message = (o = "处理商详页底部按钮异常", a = "buttonFormaterFactory", i = t.message, "goods-detail_ump_fix-bottom: " + o + ", " + a + ", " + i.toString()), e.hummer && e.hummer.capture(t), t
            }
            var o, a, i
          },
          setUmpBottomTip(e) {
            if (!this.currentActivity || "{}" === JSON.stringify(this.currentActivity)) return e;
            var {
              type: t
            } = this.currentActivity;
            return Pt.a.tipsFormaterFactory(t, e, {
              currentActivity: this.currentActivity,
              umpActivity: this.umpActivity,
              sku: this.goodsSkuData,
              alias: this.goodsBaseInfo.alias,
              kdtId: this.shopBaseInfo.kdtId,
              priceInfo: this.goodsPriceInfo
            }, "GET_TIPS")
          },
          onUmpMiniBtnClick(t) {
            switch (t.type) {
              case "activity":
                ! function(e) {
                  var {
                    currentActivity: t,
                    query: o,
                    kdtId: s
                  } = e, {
                    type: a,
                    activityId: i,
                    voucherAlias: n,
                    alias: r
                  } = t;
                  switch (a) {
                    case Ct.a.INSOURCING_FISSION:
                      Dt("InSourcingFission", {
                        umpAlias: r,
                        umpActivityId: i,
                        kdtId: s,
                        activityId: i,
                        inviterVoucherAlias: n
                      });
                      break;
                    case Ct.a.LUCKYDRAW_GROUP:
                      var {
                        ownGroup: c
                      } = t, d = {
                        kdt_id: s,
                        activity_id: i
                      };
                      if (c) {
                        var {
                          alias: u,
                          orderNo: l
                        } = c;
                        u && (d.group_alias = u), l && (d.order_no = l)
                      }
                      Dt("BargainPurchase", d);
                      break;
                    case Ct.a.HELPCUT:
                      var {
                        sponsorId: p
                      } = t;
                      Dt("BargainPurchase", {
                        umpAlias: o.umpAlias,
                        sponsorId: p,
                        umpActivityId: i,
                        kdtId: s
                      });
                      break;
                    default:
                      Object(rt.a)("营销活动获取失败，请联系商家处理");
                  }
                }({
                  currentActivity: this.currentActivity,
                  query: this.query,
                  kdtId: this.shopBaseInfo.kdtId
                });
                break;
              case "gift":
                e.event.emit("sku:show", {
                  skuScene: Be.c.BUY,
                  activityName: "gift"
                });
            }
          },
          productLaunchReminderSuccess() {
            var {
              type: t,
              activityAlias: o,
              activityId: s
            } = this.currentActivity;
            "productLaunch" === t && function(e) {
              var {
                goodsId: t,
                activityAlias: o
              } = e;
              return Object(Ae.requestV2)({
                path: "/wscgoods/activity-api/product-launch/reservation.json",
                data: {
                  goodsId: t,
                  alias: o
                },
                method: "POST"
              })
            }({
              goodsId: this.goodsBaseInfo.id,
              activityAlias: o
            }).then(() => {
              e.dmc.navigate("ProductLaunch", {
                activityId: s,
                kdt_id: this.shopBaseInfo.kdtId
              })
            }).catch(function(e) {
              void 0 === e && (e = {}), Object(Bt.b)(e, {
                message: "新品发售预约失败，请稍后重试"
              })
            })
          },
          onUmpFissionCouponShow() {
            this.showSharePop = !0
          }
        })
      },
      At = o("VmHG"),
      Ot = [gt, mt, kt, wt, It, xt].reduce((e, t) => Object(De.c)(e, t), {});

    function Tt(e) {
      return Object(At.a)({
        state: () => Object(s.a)({}, function() {
          var {
            themeVars: e = "",
            goodsBaseInfo: t = {},
            goodsPriceInfo: o = {},
            shopBaseInfo: s = {},
            shopMetaInfo: a = {},
            shopConfig: i = {},
            multistore: n = {},
            serverStatus: r = {},
            pageSwitch: c = {},
            goodsActivity: d = {},
            goodsSkuData: u = {},
            goodsMetaInfo: l = {},
            featureSwitch: p = {},
            pageFeature: h = {},
            userState: g = {},
            buyConfig: m = {},
            marketing: b = {},
            env: f = {},
            cartCount: y = 0,
            umpActivityData: {
              currentActivity: v = {},
              umpActivity: S = {}
            } = {}
          } = E.default.getGlobal("GOODS_DATA") || {};
          return {
            themeVars: e,
            goodsBaseInfo: t,
            shopBaseInfo: s,
            serverStatus: r,
            pageSwitch: c,
            shopConfig: i,
            goodsActivity: d,
            currentActivity: v,
            goodsSkuData: u,
            featureSwitch: p,
            goodsPriceInfo: o,
            pageFeature: h,
            goodsMetaInfo: l,
            userState: g,
            buyConfig: m,
            umpActivity: S,
            shopMetaInfo: a,
            multistore: n,
            marketing: b,
            env: f,
            query: {},
            activityInfo: {},
            limitedEstimate: {},
            goodsEstimatePriceData: {},
            userStateSupportSkuDirectOrder: !1,
            btnLoaded: !1,
            cartCount: y
          }
        }(), Ot.state),
        getters: Object(s.a)({}, Ot.getters),
        actions: Object(s.a)({}, xe(), Ot.getActions(e))
      })
    }
    class Mt {
      constructor(e) {
        this.ctx = e.ctx, this.store = Tt(this.ctx), Object(At.c)(this, ["goodsBaseInfo", "goodsPriceInfo", "shopBaseInfo", "serverStatus", "shopConfig", "goodsActivity", "env", "currentActivity", "goodsSkuData", "featureSwitch", "pageFeature", "activityInfo", "goodsMetaInfo", "userState", "buyConfig", "umpActivity", "userStateSupportSkuDirectOrder", "shopMetaInfo", "memberActivity", "pointsConfig", "userInfo", "multistore", "limitedEstimate", "marketing", "seActivity", "isGroupOn", "buyButtonPop", "buyLimitGuideInfo", "buttonUmpTimelimitModel", "themeVars"]), Object(ve.e)(this, {
          updateBtnsUI: this.store.updateBtnsUI,
          processBtnData: this.store.processBtnData
        }), Object(ve.d)(this, {
          saleReminderSuccess: e => {
            this.store.updateSaleReminderStatus(e)
          },
          "trade:finish": e => {
            e && e.skuScene === Be.c.ADD_CART && (this.store.processRefreshCartCount(), this.ctx.event.emit("addCartCompleted", e))
          },
          clickBigButton: this.store.handleBigBtnClick,
          goodsSetupReady: this.store.setDisabledTip,
          "custom:event": this.store.onMemberCustomEvent,
          "inSourcingFissionCoupon:show": this.store.onUmpFissionCouponShow,
          showGoodsBottom: this.store.setGoodsBottomShow,
          onImClick: this.store.handleImClick
        }), Object(ve.b)(this, {
          cartCount: () => {
            this.store.processMiniBtnData()
          },
          offlineId: e => {
            this.store.setOfflineId(e)
          }
        }), Object(ve.c)(this, ["shopMetaInfo", "goodsBaseInfo"], {
          callback: () => this.store.getEduInfo()
        }), Object(ve.c)(this, ["goodsBaseInfo", "goodsActivity", "goodsPriceInfo", "shopConfig", "pageFeature", "shopBaseInfo", "buyConfig", "serverStatus", "umpActivity"], {
          callback: () => {
            this.store.updateBtnsUI()
          }
        }), this.initCloudData()
      }
      initCloudData() {}
    }
    Mt.widgets = {
      Widget: ke.a,
      UmpTips: Ie.a
    }, Mt.lambdas = {
      getAutoShowSkuParams: Pe
    };
    var Rt = o("iIKO"),
      Nt = o("qnge"),
      Ft = o("VAno"),
      Et = o.n(Ft),
      Ut = o("lrt9"),
      Gt = o.n(Ut);
    class Lt {
      constructor(e) {
        this.ctx = e.ctx, this.initCloudData()
      }
      initCloudData() {}
    }
    Lt.widgets = {
      Main: Et.a,
      SkuHeader: Gt.a
    };
    var _t = o("/n46"),
      jt = o.n(_t),
      Wt = o("0D0K"),
      Vt = o.n(Wt);
    class qt {}
    qt.widgets = {
      Widget: jt.a,
      RecommendTitle: Vt.a
    };
    var Ht = o("YtP4"),
      Kt = o.n(Ht);
    class zt {}
    zt.widgets = {
      Widget: Kt.a
    };
    var Yt = o("FsgN"),
      Jt = o.n(Yt),
      Xt = o("hRw3"),
      Qt = o.n(Xt),
      Zt = o("yd+z"),
      $t = o.n(Zt),
      eo = o("53GB"),
      to = o.n(eo),
      oo = o("CCwj"),
      so = o.n(oo),
      ao = o("flvQ"),
      io = o.n(ao);
    class no {}
    no.widgets = {
      GoodsReview: Jt.a
    }, no.components = {
      Rate: Qt.a,
      ReviewTags: $t.a,
      ReviewItemHeader: to.a,
      ReviewItemContent: so.a,
      ReviewImgList: io.a
    };
    var ro = o("IPo+"),
      co = o.n(ro);
    class uo {}
    uo.widgets = {
      Widget: co.a
    };
    var lo = o("8aq0"),
      po = o.n(lo);
    class ho {}
    ho.widgets = {
      Widget: po.a
    };
    var go = o("rrZC"),
      mo = o.n(go),
      bo = o("Tewj");
    class fo {
      onPageScroll(e) {
        bo.default.trigger("onPageScroll", e)
      }
    }
    fo.widgets = {
      Widget: mo.a
    };
    var yo = o("GFyo");
    var vo = o("J0aM"),
      So = o.n(vo);
    class ko {}
    ko.widgets = {
      Main: So.a
    };
    var wo = o("nqUG"),
      Io = o.n(wo);
    class Bo {
      constructor(e) {
        this.ctx = e.ctx
      }
    }
    Bo.components = {
      GuaranteePop: Io.a
    };
    var Co = o("QNh1"),
      Po = o("2Pst"),
      Do = o("WlwD"),
      xo = o("slkn"),
      Ao = o.n(xo);
    class Oo {}
    Oo.widgets = {
      Main: Ao.a
    };
    var To = o("ygrD"),
      Mo = o("BaeO"),
      Ro = o("W3qh"),
      No = o("caDb"),
      Fo = o("hDMN"),
      Eo = o("7ayS"),
      Uo = o("kqRw"),
      Go = o("cTa+"),
      Lo = o.n(Go);
    class _o {}
    _o.widgets = {
      Main: Lo.a
    };
    var jo = o("EW05"),
      Wo = o.n(jo);
    class Vo {
      constructor(e) {
        this.ctx = e.ctx
      }
    }
    Vo.widgets = {
      Main: Wo.a
    };
    var qo = o("Y0JT"),
      Ho = o("iT+G"),
      Ko = o.n(Ho);
    class zo {
      constructor(e) {
        this.ctx = e.ctx
      }
    }
    zo.widgets = {
      Main: Ko.a
    };
    var Yo = o("OU5B"),
      Jo = o.n(Yo);
    class Xo {}
    Xo.widgets = {
      Main: Jo.a
    };
    var Qo = o("mjlp"),
      Zo = o("ucz/"),
      $o = o.n(Zo);
    class es {
      constructor(e) {
        this.ctx = e.ctx
      }
    }
    es.widgets = {
      Main: $o.a
    };
    var ts = o("jYdQ"),
      os = o.n(ts);
    class ss {
      constructor(e) {
        this.ctx = e.ctx
      }
    }
    ss.widgets = {
      Main: os.a
    };
    var as = o("vVPF"),
      is = o("9NdL"),
      ns = o("DvSL"),
      rs = o.n(ns),
      cs = o("rIfD");
    class ds {
      constructor(e) {
        this.ctx = e.ctx
      }
    }
    ds.lambdas = {
      exchangeCoupon: cs.a
    }, ds.widgets = {
      Widget: rs.a
    };
    var us = o("flx1"),
      ls = o.n(us),
      ps = o("HwgD"),
      hs = o.n(ps);
    class gs {
      constructor(e) {
        this.ctx = e.ctx, this.ctx.data.preferredPayChannel = ""
      }
    }
    gs.widgets = {
      SingleRow: ls.a,
      CellGroup: hs.a
    };
    var ms = o("F6Qw"),
      bs = o("bIWf"),
      fs = o("1JO1"),
      ys = o.n(fs);
    class vs {
      constructor(e) {
        this.ctx = e.ctx
      }
    }
    vs.widgets = {
      Main: ys.a
    };
    var Ss = o("h9FP"),
      ks = o.n(Ss);
    class ws {
      constructor(e) {
        this.ctx = e.ctx
      }
      onPageShow() {
        this.isRecordsPageVisible = !0
      }
      onPageHide() {
        this.isRecordsPageVisible = !1
      }
    }
    ws.widgets = {
      Main: ks.a
    };
    var Is = o("bSoS"),
      Bs = o("fNGs"),
      Cs = o("sglO"),
      Ps = o.n(Cs),
      Ds = o("RNop"),
      xs = o.n(Ds),
      As = o("ceIk"),
      Os = o.n(As),
      Ts = o("fSch"),
      Ms = o.n(Ts),
      Rs = o("ythx"),
      Ns = o.n(Rs);
    class Fs {
      constructor(e) {
        this.ctx = e.ctx
      }
    }
    Fs.widgets = {
      Main: Ps.a,
      TitleBar: xs.a,
      PriceBar: Os.a,
      ActivityBanner: Ms.a,
      GuaranteeBar: Ns.a
    };
    var Es = o("jWfv"),
      Us = o.n(Es),
      Gs = o("2pjk"),
      Ls = o.n(Gs),
      _s = o("USra"),
      js = o.n(_s);
    class Ws {
      constructor(e) {
        this.ctx = e.ctx
      }
    }
    Ws.widgets = {
      Main: Us.a,
      ServiceBar: Ls.a,
      SelectSkuBar: js.a
    };
    var Vs = o("DXyM"),
      qs = o("4lf9"),
      Hs = o.n(qs),
      Ks = o("IiIR"),
      zs = o.n(Ks);
    class Ys {
      constructor(e) {
        this.ctx = e.ctx
      }
    }
    Ys.widgets = {
      Main: Hs.a,
      PresaleProgress: zs.a
    };
    var Js = o("1gXJ"),
      Xs = o.n(Js),
      Qs = o("zdHw"),
      Zs = o.n(Qs),
      $s = o("kMQg"),
      ea = o.n($s),
      ta = o("kh7f"),
      oa = o.n(ta);
    class sa {
      constructor(e) {
        this.ctx = e.ctx
      }
    }
    sa.widgets = {
      Main: Xs.a,
      GoodsPromotion: Zs.a,
      GoodsStock: ea.a,
      GoodsPackageBuy: oa.a
    };
    var aa = o("eijD"),
      ia = 2;

    function na(e, t) {
      var o, {
        blindBoxDistTypes: s = [],
        blindBoxSelfFetchKdtIds: a = []
      } = (null == t || null == (o = t.order) ? void 0 : o.config) || {};
      return null != s && s.includes(ia) && (null == a ? void 0 : a.length) > 0 ? e.filter(e => a.includes(null == e ? void 0 : e.kdtId)) : e
    }
    class ra {
      constructor(e) {
        this.ctx = e.ctx, this.handleScanCodeBuy()
      }
      handleScanCodeBuy() {
        this.scanCodeBuyHandled = !1, Object(ft.b)(this, ["isScanCodeBuy", "expressType", "selfFetch", "contact"], {
          callback: () => {
            if (!this.scanCodeBuyHandled) {
              var e, {
                isScanCodeBuy: t,
                expressType: o,
                selfFetch: s = {},
                contact: a,
                shop: i = {}
              } = this.ctx.data;
              if (t && "self-fetch" === o && s.isAllow && a && (this.scanCodeBuyHandled = !0, (e = i.kdtId, Object(Ae.default)({
                  origin: "h5",
                  method: "GET",
                  path: "/wsctrade/scancodebuy/address/get-mock-self-fetch.json",
                  data: {
                    kdtId: e
                  }
                }).then(e => e || {}).catch(() => ({}))).then(e => {
                  this.ctx.process.invoke("setSelfFetch", {
                    shop: e
                  })
                }), !a.id)) {
                var n = getApp(),
                  {
                    nickname: r,
                    mobile: c
                  } = n.getUserInfoSync();
                if (r && c) return this.ctx.process.invoke("saveContact", {
                  userName: r,
                  telephone: c
                })
              }
            }
          }
        })
      }
    }
    class ca {
      constructor(e) {
        this.saveContactBeforeBilling = () => {
          var e, t, o = (null == (e = this.ctx) || null == (t = e.data) ? void 0 : t.contact) || {};
          return o.required && !o.id ? this.saveContactAndMutate({
            userName: o.userName,
            telephone: o.telephone
          }) : Promise.resolve(!0)
        }, this.saveContactAndMutate = e => {
          var t = e.id ? "update" : "add";
          return this.saveContactService(e, t).then(o => {
            var {
              list: a = []
            } = e, i = o.value || o, n = a.slice(), r = Object(s.a)({}, e, {
              id: i
            }), c = a.map(e => e.id).indexOf(e.id);
            return "add" === t ? n.push(r) : n.splice(c, 1, r), e.isDefault && n.filter(e => e.id !== i && e.isDefault).forEach(e => {
              e.isDefault = !1
            }), this.ctx.process.invoke("mutateState", t => {
              t.contact.id = i, t.contact.userName = e.userName, t.contact.telephone = e.telephone, t.contact.list = n
            }), this.ctx.process.invoke("onExpressChanged"), Object(rt.a)("add" === t ? "联系人添加成功" : "联系人编辑成功"), i
          }).catch(e => {
            var t, o;
            throw e.code = e.code || (null == (t = e.data) ? void 0 : t.code), e.msg = e.msg || (null == (o = e.data) ? void 0 : o.msg), Object(Bt.b)(e, {
              message: "联系人保存失败，请稍后重试"
            }), e
          })
        }, this.ctx = e.ctx, this.ctx.process.define("saveContact", this.saveContactAndMutate), this.ctx.process.define("saveContactBeforeBilling", this.saveContactBeforeBilling.bind(this))
      }
      saveContactService(e, t) {
        var {
          userName: o,
          telephone: s,
          id: a
        } = e;
        return ("add" !== t || o && s) && ("update" !== t || a) ? Object(Ae.requestV2)({
          origin: "cashier",
          method: "POST",
          path: "/wsctrade/uic/contact/" + t + "Contact.json",
          data: e
        }) : Promise.reject("参数缺失")
      }
    }
    var da = o("jPXZ"),
      ua = o.n(da),
      la = o("+3Fe"),
      pa = o.n(la),
      ha = o("EsfN"),
      ga = o.n(ha),
      ma = o("9CdD"),
      ba = o.n(ma),
      fa = o("D6vh"),
      ya = o.n(fa),
      va = o("bHr6"),
      Sa = o.n(va),
      ka = o("y9px"),
      wa = o.n(ka),
      Ia = o("0Hvf"),
      Ba = o.n(Ia),
      Ca = o("0glB"),
      Pa = o.n(Ca),
      Da = o("XWEF"),
      xa = o.n(Da),
      Aa = o("EZpN"),
      Oa = o.n(Aa),
      Ta = o("dvJh"),
      Ma = o.n(Ta),
      Ra = o("dIXK"),
      Na = o.n(Ra),
      Fa = o("IgI9"),
      Ea = o.n(Fa),
      Ua = o("jPV2"),
      Ga = o.n(Ua),
      La = o("1m8I"),
      _a = o.n(La),
      ja = o("Ah+4"),
      Wa = o.n(ja),
      Va = o("kR5P"),
      qa = o.n(Va);
    class Ha {
      constructor(e) {
        var t = this;
        this.getSelfFetchShopList = function() {
          var e = Object(aa.a)(function*(e) {
            void 0 === e && (e = {});
            var {
              state: o
            } = t.ctx.data, {
              goods: a,
              selfFetch: i,
              location: n,
              shop: r
            } = o, {
              cityCode: c,
              list: d = [],
              page: u
            } = i, {
              lat: l,
              lng: p
            } = n, h = [].concat(a.list, a.unavailable), {
              keyword: g = "",
              pageSize: m = 10,
              getAll: b = !1
            } = e, f = {
              kdtId: r.kdtId,
              keyword: g,
              page: u,
              pageSize: m,
              items: h.map(e => ({
                goodsId: e.goodsId,
                skuId: e.skuId,
                num: e.num
              }))
            }, y = [];
            c && (f.cityCode = c), l && p && (f.lat = l, f.lng = p);
            var v = y.filter(e => f.keyword === e.keyword && f.cityCode === e.cityCode && f.page === e.page)[0];
            if (v) {
              var S = !1;
              return v.list.length < m && (S = !0), void(yield t.ctx.process.invokePipe("setSelfFetch", {
                page: u + 1,
                finished: S,
                list: v.list
              }))
            }
            return Object(Ae.default)({
              origin: "cashier",
              path: "/pay/wsctrade/order/buy/v3/getSelfFetchList.json",
              method: "POST",
              data: f
            }).then(function() {
              var a = Object(aa.a)(function*(a) {
                var {
                  list: i
                } = a;
                i = function(e, t) {
                  return na(e, t)
                }(i = i || [], o), y.push(Object(s.a)({}, f, {
                  list: i
                }));
                var n = !1;
                return i.length < m && (n = !0), yield t.ctx.process.invokePipe("setSelfFetch", {
                  page: u + 1,
                  finished: n,
                  list: [...d, ...i]
                }), b && !n ? t.getSelfFetchShopList(e) : b && n ? [...d, ...i] : void 0
              });
              return function(e) {
                return a.apply(this, arguments)
              }
            }()).catch(() => {
              t.ctx.process.invokePipe("setSelfFetch", {
                finished: !0
              })
            })
          });
          return function(t) {
            return e.apply(this, arguments)
          }
        }(), this.ctx = e.ctx, new ra(e), new ca(e), this.ctx.data.cloudData = {
          displayConfig: {
            isShowWechatAddress: !0
          }
        }, this.initProcess(), this.initCloudData()
      }
      initProcess() {
        this.ctx.process.define("onExpressChanged", () => {
          this.ctx.cloud.emit("onExpressChanged", this.deliveryV1)
        })
      }
      initCloudData() {}
    }
    Ha.widgets = {
      Main: ua.a,
      DeliveryMain: pa.a,
      AddressList: ga.a,
      AddressListItem: ba.a,
      LocalDeliveryTimeCell: ya.a,
      SelfFetch: Sa.a,
      TimePicker: wa.a,
      ContactMain: Ba.a,
      ContactList: Pa.a,
      WechatAddress: xa.a,
      WxAddress: Oa.a,
      AliAddress: Ma.a,
      XhsAddress: Na.a,
      IdcardMain: Ea.a,
      IdcardPopup: Ga.a,
      PeriodBuy: _a.a,
      AddressCard: Wa.a,
      DeliveryBlock: qa.a
    };
    var Ka = o("aN2w"),
      za = o.n(Ka),
      Ya = o("9U4V"),
      Ja = o.n(Ya),
      Xa = o("LsN0"),
      Qa = o.n(Xa),
      Za = o("XWk2"),
      $a = o.n(Za),
      ei = o("XM9b"),
      ti = o.n(ei),
      oi = o("D2e6"),
      si = o.n(oi),
      ai = o("PKOW"),
      ii = o("tmLU"),
      ni = getApp();

    function ri(e) {
      var t = Object(s.a)({
        useVersion2: !0,
        defaultPointDeductEffect: !0,
        useNewCoupon: !0,
        isSupportDefaultSelfFetch: !0,
        useOrderKeep: !0,
        isOptimalSolution: !0,
        isOverlyingCoupon: !0,
        isNewMemberFlow: !0
      }, e);
      return ni.getShopInfo().then(e => (Object(Me.e)(e.shopMetaInfo) && Object.assign(t, {
        isSupportSpecialPeriodCost: !0
      }), Object(Ae.default)({
        origin: "cashier",
        withCredentials: !0,
        path: "/pay/wsctrade/order/buy/prepare-by-book-key.json",
        data: t
      })))
    }

    function ci() {
      return (ci = Object(aa.a)(function*(e) {
        var {
          prefetchKey: t,
          params: o
        } = e;
        return Object(ii.b)({
          prefetchKey: t,
          normalFetchCb: () => ri(o)
        })
      })).apply(this, arguments)
    }
    class di {
      constructor(e) {
        this.ctx = e.ctx, this.ctx.process.define("navigateToTradeBuy", this.navigateToTradeBuy.bind(this))
      }
      navigateToTradeBuy(e) {
        var {
          navigateParams: t,
          requestParams: o = {}
        } = e;
        Object(ai.e)().then(e => {
          var {
            bookKey: a = ""
          } = t, i = Object(s.a)({
            bookKey: a
          }, o), n = Object(s.a)({}, t);
          Object(ii.c)({
            navigatePath: "trade-buy",
            navigateCb: t => {
              e.order && (n.prefetchKey = t), Object(ai.f)({
                pageType: ai.b.ORDER,
                query: n
              })
            },
            prefetchCb: () => ri(i)
          })
        })
      }
    }
    di.lambdas = {
      getTradeBuyPreFetchQuery: function() {
        var e = ni.tradeBuyPreFetchQuery ? Object(s.a)({}, ni.tradeBuyPreFetchQuery) : null;
        return ni.tradeBuyPreFetchQuery = null, e
      },
      getTradeBuyPageData: function(e) {
        return ci.apply(this, arguments)
      }
    };
    class ui {
      constructor(e) {
        this.ctx = e.ctx, new di(e)
      }
    }
    ui.lambdas = Object(s.a)({}, di.lambdas), ui.widgets = {
      Main: za.a,
      PresentGoods: Qa.a,
      Price: Ja.a,
      OrderKeepDialog: si.a,
      OrderKeepNavigator: $a.a,
      OrderKeep: ti.a
    };
    var li = o("axMY"),
      pi = o.n(li),
      hi = o("Tk54"),
      gi = o.n(hi),
      mi = o("DIbs"),
      bi = o.n(mi),
      fi = o("1DqH"),
      yi = o.n(fi),
      vi = o("cY/0"),
      Si = o.n(vi),
      ki = o("vOVc"),
      wi = o.n(ki),
      Ii = o("iJeB"),
      Bi = o.n(Ii),
      Ci = o("R0f8"),
      Pi = o.n(Ci),
      Di = o("8p7p"),
      xi = o.n(Di),
      Ai = o("izeG"),
      Oi = o.n(Ai),
      Ti = o("P5cb"),
      Mi = o.n(Ti),
      Ri = o("scXe"),
      Ni = o.n(Ri),
      Fi = o("HyEJ"),
      Ei = o.n(Fi),
      Ui = o("pR+k"),
      Gi = o.n(Ui),
      Li = o("MbRR"),
      _i = o.n(Li),
      ji = o("PE14"),
      Wi = o.n(ji),
      Vi = o("9Gof"),
      qi = o.n(Vi),
      Hi = o("rQPx"),
      Ki = o.n(Hi);
    class zi {
      constructor(e) {
        this.ctx = e.ctx
      }
    }
    zi.widgets = {
      Main: pi.a,
      PrepayCardCell: gi.a,
      PointDeductionCell: bi.a,
      PointCell: yi.a,
      FansCell: Si.a,
      ActivityCell: wi.a,
      ActivityDialog: Bi.a,
      MembershipCell: Pi.a,
      DisplayCard: xi.a,
      MembershipDialog: Oi.a,
      PlusBuy: Mi.a,
      PlusBuyCard: Ni.a,
      CouponCell: Ei.a,
      CouponList: Gi.a,
      Postagetool: _i.a,
      PostagetoolTip: Wi.a,
      PostagetoolCard: qi.a,
      FansDialog: Ki.a
    };
    var Yi = o("L63X"),
      Ji = o.n(Yi);
    class Xi {
      constructor(e) {
        this.ctx = e.ctx
      }
    }
    Xi.widgets = {
      Main: Ji.a
    };
    var Qi = o("xW8c"),
      Zi = o("/pw/"),
      $i = o("dLoJ"),
      en = o.n($i),
      tn = o("O/Fb"),
      on = o.n(tn);
    class sn {
      constructor(e) {
        this.ctx = e.ctx
      }
    }
    sn.widgets = {
      Main: en.a,
      FastJoinHeader: on.a
    };
    var an = o("5mDF"),
      nn = o("vzTj"),
      rn = {
        "@ext-tee-wsc-decorate/page-style": U.a,
        "@ext-tee-wsc-goods/page-setup-block": G.a,
        "@wsc-tee-shop/shop-top-bar": V,
        "@assets-tee-extensions/guarantee-detail-bar": K,
        "@ext-tee-wsc-goods/image-block": $,
        "@ext-tee-wsc-goods/share-block": ee.a,
        "@wsc-tee-salesman/salesman-cube-block": te.a,
        "@ext-tee-wsc-goods/shop-block": ne,
        "@ext-tee-wsc-goods/recommend-plugin-block": de,
        "@ext-tee-wsc-goods/goods-detail-block": ye,
        "@ext-tee-wsc-goods/fix-bottom-block": Mt,
        "@wsc-tee-shop/shop-rest": Rt.a,
        "@wsc-tee-shop/footer": Nt.a,
        "@ext-tee-wsc-goods/trade-submit-block": Lt,
        "@ext-tee-wsc-goods/recommend-block": qt,
        "@ext-tee-wsc-goods/multi-store-block": zt,
        "@ext-tee-wsc-goods/goods-review-block": no,
        "@ext-tee-wsc-goods/buyer-show-block": uo,
        "@ext-tee-wsc-goods/trade-carousel": ho,
        "@ext-tee-wsc-goods/nav-bar-block": fo,
        "@wsc-tee-salesman/salesman-promote-block": class {
          constructor(e) {
            this.ctx = e.ctx
          }
          beforePageMount(e) {
            var t, o, s, a, {
              query: i
            } = e;
            this.query = i;
            var {
              TRADE_MODULE_ORDER: n,
              alias: r,
              fromType: c,
              sl: d
            } = this.query || {}, u = (null == (t = this.ctx) || null == (o = t.lambdas) || null == o.checkFromChannelsOpenFlow ? void 0 : o.checkFromChannelsOpenFlow()) && "TRUE" === n, l = null == (s = this.ctx) || null == (a = s.lambdas) || null == a.checkIsChannels ? void 0 : a.checkIsChannels(), p = "salesPromote-" + r;
            Object(yo.c)(p).then(e => {
              var t = !0;
              e && e.data && (t = e.data.supportDirect);
              var o = "sp" !== c && !d && !u && !l && t;
              try {
                Object(yo.e)(p)
              } catch (e) {}
              o && this.salesGoodsRecommend()
            })
          }
          salesGoodsRecommend() {
            Object(Ae.default)({
              path: "/wscsalesman/promotion/promote/goodsDMC.json",
              query: this.query,
              method: "GET"
            }).then(e => {
              var {
                supportDirect: t,
                promoteQuery: o,
                promotePath: s
              } = e || {};
              t && E.default.navigate({
                url: Ee.a.add(s, o),
                type: "redirectTo"
              })
            })
          }
        },
        "@ext-tee-wsc-goods/shop-note-block": ko,
        "@assets-tee-extensions/guarantee-components": Bo,
        "@ext-tee-wsc-im/im-sdk-core": Co.a,
        "@ext-tee-wsc-im/im-message-contact": Po.a,
        "@wsc-tee-decorate/floating-nav": Do.a,
        "@ext-tee-wsc-goods/goods-ranking-block": Oo,
        "@ext-tee-wsc-goods/biz-sku-manage": To.a,
        "@wsc-tee-salesman/salesman-recruit-goods-block": Mo.a,
        "@assets-tee-extensions/sku-pay-ways": Ro.a,
        "@ext-tee-assets/prior-use-block": No.a,
        "@wsc-tee-statcenter/recommend-goods": Fo.a,
        "@wsc-tee-statcenter/cps-recommend-goods": Eo.a,
        "@ext-tee-wsc-goods/preview-image-block": Uo.a,
        "@ext-tee-wsc-goods/timeline-block": _o,
        "@ext-tee-wsc-im/im-layer": Vo,
        "@wsc-tee-decorate/navigation-bar": qo.a,
        "@wsc-tee-trade/order-pay-prompt-popup": zo,
        "@ext-tee-wsc-goods/shop-physical-block": Xo,
        "@ext-tee-wsc-goods/popup-container": Qo.a,
        "@ext-tee-wsc-goods/estimated-arrival-time": es,
        "@wsc-tee-decorate/live-pop": ss,
        "@wsc-tee-trade/wxvideo-order-core": as.a,
        "sku-order-block": is.a,
        "@ext-tee-wsc-ump/trade-buy-ump-data": ds,
        "@assets-tee-extensions/cashier-pre": gs,
        "@wsc-tee-decorate/subscribe-message": ms.a,
        "@ext-tee-wsc-im/subscription-message": bs.a,
        "@ext-tee-wsc-goods/shop-evaluation-entry": vs,
        "@ext-tee-wsc-goods/trade-records-block": ws,
        "@wsc-tee-salesman/salesman-share-block": Is.a,
        "@ext-tee-shop/shop-cert-notice": Bs.a,
        "@ext-tee-wsc-goods/base-info-block": Fs,
        "@ext-tee-wsc-goods/group-block": Ws,
        "@ext-tee-wsc-goods/goods-extra-block": Vs.a,
        "@ext-tee-wsc-goods/activity-block": Ys,
        "@ext-tee-wsc-goods/promotion-block": sa,
        "@wsc-tee-goods/trade-buy-address-pre": Ha,
        "@wsc-tee-trade/trade-buy-misc-pre": ui,
        "@ext-tee-wsc-goods/trade-buy-ump-block": zi,
        "@ext-tee-wsc-goods/goods-explain-video": Xi,
        "@wsc-tee-decorate/showcase-container": Qi.a,
        "@wsc-tee-decorate/jump-link": Zi.a,
        "@ext-tee-user/fast-join-sdk": sn,
        "@ext-tee-wsc-goods/goods-showcase": an.a,
        "trade-buy-privacy-bill": nn.a
      },
      {
        scene: cn
      } = E.default.getAppOptions(),
      dn = 1154 === cn;
    F.modules = F.modules.filter(e => -1 !== e.moduleId.indexOf("@ext-tee-wsc-goods/timeline-block") === dn), F.app.pages.forEach(e => {
      dn && (e.containers = []), e.modules && (e.modules = e.modules.filter(e => -1 !== e.indexOf("@ext-tee-wsc-goods/timeline-block") === dn))
    });
    var un = {
        config: F,
        builtinBundle: rn
      },
      ln = E.default.getGlobal("ranta-app-runtime"),
      pn = ln.getPageOptions({
        rantaOptions: Object(s.a)({
          page: "/pages/goods/detail/index"
        }, un),
        pageRuntimeName: "MNQXvtPXxgBH",
        frameworkAppRuntime: ln,
        tee: E.default,
        usedLifecycles: ["onPageShow", "onPageHide", "beforePageMount", "onPullDownRefresh", "beforePageCreate", "pageDestroyed", "onReachBottom", "onPageScroll", "onShareAppMessage", "onShareTimeline"]
      });
    E.default.page({
      mixins: [pn, {
        data: () => ({
          _pageStyle: ""
        }),
        created() {
          this.$root.setPageStyle = this._setPageStyle
        },
        methods: {
          _setPageStyle(e) {
            var t = "";
            this._pageStyle.endsWith(";") || (t = ";"), this._pageStyle = this._pageStyle + t + e
          }
        }
      }],
      data: () => ({
        showTimeline: dn
      })
    })
  },
  YxhU: function(e, t, o) {
    var s;
    o.d(t, "a", function() {
        return s
      }),
      function(e) {
        e.GOODS = "goods", e.DISCOUNT = "discount", e.POINTS = "points", e.GROUPON = "groupOn", e.LADDER_GROUPON = "ladderGroupOn", e.AUCTION = "auction", e.TUAN = "tuan", e.F_CODE = "fCode", e.TIMELIMITED_DISCOUNT = "timelimitedDiscount", e.PRESENT = "presentExchange", e.SECKILL = "seckill", e.DEPOSIT_EXPANSION = "depositExpansion", e.HELP_DEPOSIT_EXPANSION = "helpDepositExpansion", e.HELPCUT = "helpcut", e.IN_SOURCING_FISSION = "inSourcingFission", e.LIMITED_SECKILL = "limitedSeckill", e.GIFT = "gift"
      }(s || (s = {}))
  },
  hkcG: function(e, t, o) {
    var s = o("YxhU");
    o.d(t, "ActivityName", function() {
      return s.a
    });
    o("3GJ5"), o("DxnF"), o("Mmby")
  },
  m2V3: function(e, t, o) {}
};