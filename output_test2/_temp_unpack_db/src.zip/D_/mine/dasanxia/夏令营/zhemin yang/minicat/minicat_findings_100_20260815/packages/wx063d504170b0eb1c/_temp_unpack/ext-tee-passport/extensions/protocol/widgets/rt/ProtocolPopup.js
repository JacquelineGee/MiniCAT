var r = require("~/r");
r("g5bd", Object.assign({}, require("~/v.js").modules, require("~/c.js").modules, {
  g5bd: function(t, o, e) {
    e.r(o);
    e("Tewj"), e("Pv1N");
    var s = e("QxN7"),
      {
        protocolHook: r
      } = s.hooks,
      i = Symbol("offList"),
      n = {
        data() {
          var {
            cloudDesignConfig: t
          } = this.ctx.data, o = !!t && t.replacedSlots.includes("account-protocol-content");
          return {
            source: "@ext/protocol/popup_" + Date.now(),
            visible: !1,
            isCloudSlot: o
          }
        },
        mounted() {
          this.initProtocol()
        },
        destroyed() {
          this.runOff()
        },
        methods: {
          addOff(t) {
            this[i] = (this[i] || []).concat(t)
          },
          runOff() {
            this[i] && (this[i].forEach(t => t()), this[i] = null)
          },
          initProtocol() {
            this.getProtocol().then(t => {
              var {
                instance: o
              } = t;
              o.on(s.InvokeProtocolEvent.SHOW, () => this.show()), o.on(s.InvokeProtocolEvent.CLOSE, () => this.hide()), o.init()
            }).catch(t => {
              throw s.platform.authLogger.logAll({
                errTitle: "[protocol] init error",
                errInfo: {
                  source: this.source,
                  msg: Object(s.getErrorMsg)(t),
                  stack: t && t.stack
                }
              }), t
            })
          },
          getProtocol() {
            return this.$_protocolPs || (this.$_protocolPs = e.e("packages/async-main/chunk").then(e.t.bind(null, "HsSF", 7)).then(t => ({
              instance: new t.InvokeProtocol({
                source: this.source
              })
            })).catch(t => {
              throw this.$_protocolPs = null, t
            })), this.$_protocolPs
          },
          handleAgree() {
            e.e("packages/async-tee/chunk").then(e.bind(null, "JvWB")).then(t => t.default).then(t => {
              t.refreshUserAuthData().finally(() => {
                Object(s.emitUserAuthSuccess)({
                  authTypeList: [s.AuthType.PROTOCOL],
                  authPopTypeList: [s.AuthPopType.PROTOCOL]
                })
              }), this.hide()
            })
          },
          handleDisagree() {
            this.hide()
          },
          show() {
            this.visible = !0
          },
          hide() {
            this.visible = !1
          }
        }
      },
      c = e("9ZMt");
    o.default = c.default.component(n)
  }
}));