var r = require("~/r");
r("eqXS", Object.assign({}, require("~/v.js").modules, {
  eqXS: function(t, e, i) {
    i.r(e);
    var s = i("9ZMt"),
      a = i("lgMb"),
      o = i("AGZf"),
      n = i("Fcif"),
      h = i("US/N"),
      p = t => {
        return e = {
          path: "/wscshop/ump/coupon/takeCouponByAlias.json",
          method: "POST",
          data: t
        }, Object(h.requestV2)(Object(n.a)({}, e, {
          config: {}
        }));
        var e
      },
      c = {
        externalClasses: ["custom-class"],
        props: {
          customStyle: {
            type: String,
            default: ""
          },
          item: {
            type: Object,
            default: () => ({})
          },
          extra: {
            type: Object,
            default: () => ({})
          },
          needSubscribeMessage: {
            type: Boolean,
            default: !1
          },
          kdtId: Number,
          _opt: {
            type: Object,
            default: () => ({})
          }
        },
        logicData: () => ({
          isAuthPopShow: !1
        }),
        computed: {
          isOtherWeappLink() {
            var {
              item: t
            } = this;
            return "weapplink" === t.linkType && t.extraData && "2" === t.extraData.linkType
          }
        },
        methods: {
          handleAuthPopShow() {
            this.isAuthPopShow = !0
          },
          handleTap(t) {
            var {
              linkType: e,
              alias: i
            } = this.item || {};
            "coupon" === e && i ? this.needSubscribeMessage && !this.isAuthPopShow ? this.$emit("handleCouponClick", {
              windowType: "micro_dc_link_coupon",
              subscribeType: "优惠券跳链",
              next: () => {
                this.getCoupon(i)
              }
            }) : (this.getCoupon(i), this.isAuthPopShow = !1) : !this.needSubscribeMessage || this.isAuthPopShow || "platform_coupon" !== e ? (this.isAuthPopShow = !1, this.$emit("jumpToLink", t)) : this.$emit("handleCouponClick", {
              windowType: "micro_dc_link_coupon",
              subscribeType: "优惠券跳链",
              next: () => {
                this.$emit("jumpToLink", t)
              }
            })
          },
          getCoupon(t) {
            if (!this.loading) {
              this.loading = !0;
              var {
                _opt: e = {}
              } = this;
              return p({
                alias: t,
                source: "wap_showcase",
                pageAlias: e.risk_alias,
                pageType: e.risk_type
              }).then(() => {
                this.loading = !1, o.a.success("领取成功")
              }).catch(t => {
                this.loading = !1, Object(a.b)(t, {
                  message: "店铺太火爆啦，请稍后重试"
                })
              })
            }
          },
          handleClickContactBack() {
            var t = this.extra && this.extra.sourceParam;
            if ("string" == typeof t) try {
              t = JSON.parse(this.extra.sourceParam)
            } catch (t) {}
            t && this.$emit("contact", this.item, t)
          },
          handleContactBack(t) {
            this.$emit("contact", t)
          }
        },
        ud: !0
      };
    e.default = s.default.component(c)
  }
}));