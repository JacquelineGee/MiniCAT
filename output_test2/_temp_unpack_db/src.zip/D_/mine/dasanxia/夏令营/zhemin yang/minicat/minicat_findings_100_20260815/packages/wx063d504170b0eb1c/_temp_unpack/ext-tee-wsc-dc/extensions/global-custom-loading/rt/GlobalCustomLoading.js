var r = require("~/r");
r("O0BT", Object.assign({}, require("~/v.js").modules, {
  O0BT: function(o, t, a) {
    a.r(t);
    var e = a("9ZMt"),
      s = e.default.getApp(),
      d = {
        props: {
          show: {
            type: Boolean,
            default: !1
          }
        },
        data: () => ({
          globalCustomLoading: ""
        }),
        created() {
          this.setCustomLoading(), s.on("app:loading:change", this.setCustomLoading)
        },
        beforeDestroy() {
          s.off("app:loading:change", this.setCustomLoading)
        },
        methods: {
          setCustomLoading() {
            this.globalCustomLoading = s.globalData.globalCustomLoading
          }
        },
        ud: !0
      };
    t.default = e.default.component(d)
  }
}));