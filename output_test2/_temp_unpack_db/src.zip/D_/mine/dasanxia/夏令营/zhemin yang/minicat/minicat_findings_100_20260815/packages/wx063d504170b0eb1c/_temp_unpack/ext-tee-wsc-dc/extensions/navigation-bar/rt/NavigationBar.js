var r = require("~/r");
r("UaIZ", Object.assign({}, require("~/v.js").modules, {
  UaIZ: function(t, a, e) {
    e.r(a);
    var i = e("YeA1"),
      o = {
        data: () => ({
          title: "",
          openCustomNav: !0,
          navigationBarConfigData: {}
        }),
        created() {
          Object(i.b)(this, ["title", "openCustomNav", "navigationBarConfigData"])
        },
        methods: {
          getHeight(t) {
            this.ctx && this.ctx.data && (this.ctx.data.topNavHeight = t.detail)
          }
        },
        ud: !0
      },
      r = e("9ZMt");
    a.default = r.default.component(o)
  }
}));