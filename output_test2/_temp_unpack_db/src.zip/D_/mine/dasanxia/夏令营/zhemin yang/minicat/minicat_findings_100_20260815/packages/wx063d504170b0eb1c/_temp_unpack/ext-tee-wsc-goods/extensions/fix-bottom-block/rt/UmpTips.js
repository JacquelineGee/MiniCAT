var r = require("~/r");
r("1ozL", Object.assign({}, require("~/v.js").modules, {
  "1ozL": function(e, t, r) {
    r.r(t);
    var s = {
        name: "ump-tips",
        props: {
          opt: Object,
          baseInfo: Object,
          priceInfo: Object,
          hideGroupBargin: Boolean,
          cloudConfig: {
            type: Object,
            default: () => ({})
          }
        },
        data: () => ({
          user: {}
        }),
        created() {
          this.ctx.lambdas.getUserInfo && this.ctx.lambdas.getUserInfo().then(e => {
            this.user = e
          })
        },
        methods: {
          umpClick() {
            this.$emit("ump-click")
          }
        },
        ud: !0
      },
      o = r("9ZMt");
    t.default = o.default.component(s)
  }
}));