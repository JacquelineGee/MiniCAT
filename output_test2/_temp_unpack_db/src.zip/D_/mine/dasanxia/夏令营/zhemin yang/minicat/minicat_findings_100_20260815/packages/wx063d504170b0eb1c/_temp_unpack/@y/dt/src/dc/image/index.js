var r = require("~/r");
r("AaYt", Object.assign({}, require("~/v.js").modules, require("~/c.js").modules, {
  AaYt: function(t, e, i) {
    i.r(e);
    var a = i("Fcif"),
      r = i("9ZMt"),
      s = i("mztD"),
      h = i("EqB2"),
      o = i("/XVY"),
      l = Object(o.a)({
        tpl: {
          default: 1
        },
        isHighQualityImage: {
          default: !1
        },
        count: {
          default: 1
        },
        imgs: {
          default: () => []
        },
        style: {
          default: 1
        },
        size: {
          default: 0
        },
        radius: {
          default: 0
        },
        pageMargin: {
          default: 0
        },
        imgMargin: {
          default: 0
        },
        fill: {
          default: "cover"
        },
        indicator: {
          default: 1
        },
        slide: {
          default: 0
        },
        bgColor: {
          default: "transparent"
        },
        color: {
          default: "#000"
        },
        overlapHeight: {
          default: 0
        },
        swipeTime: {
          default: 5e3
        }
      }),
      g = i("2Dtx"),
      n = i("MLLI"),
      d = i("K3Aj"),
      p = i("w2Y9"),
      m = i.n(p),
      c = i("VdoR"),
      {
        useTpx: u
      } = r.default.style,
      v = {
        mixins: [Object(h.a)({
          optDesc: l
        })],
        props: {
          needSubscribeMessage: {
            type: Boolean,
            default: !1
          },
          extra: {
            type: Object,
            default: () => ({})
          },
          isWebview: {
            type: Boolean,
            default: !1
          },
          needPreLoad: {
            type: Boolean,
            default: !1
          },
          kdtId: Number,
          _opt: {
            type: Object,
            default: () => ({})
          }
        },
        data: () => ({
          current: 0,
          vanSwiperKey: "" + Math.random()
        }),
        logicData: () => ({
          loadErrorImagesMap: {}
        }),
        computed: {
          showImages() {
            var t = "!" + (this.opt.isHighQualityImage ? 876 : 730) + "x0.jpg",
              e = (this.opt.imgs || []).length || 0;
            if (4 === this.opt.tpl && !this.opt.isHighQualityImage) {
              var i = Math.ceil(750 / (0 === this.opt.slide ? e : Math.min(3, e)) * 4);
              i > 750 && (i = 750), t = "!" + i + "x0.jpg"
            }
            return 3 !== this.opt.tpl || this.opt.isHighQualityImage || (t = 0 === this.opt.size ? "!" + (this.opt.isHighQualityImage ? 876 : 730) + "x0.jpg" : 1 === this.opt.size ? "!" + Math.ceil(300) + "x0.jpg" : "!" + Math.ceil(750 / Math.min(3, this.opt.count - 1)) + "x0.jpg"), (this.opt.imgs || []).map((e, i) => {
              var {
                imageUrl: r
              } = e || {};
              if (r) {
                var h = this.loadErrorImagesMap["imgErr" + i] && this.loadErrorImagesMap["imgErr" + i] <= 3;
                r = Object(s.a)(e.imageUrl, t, {
                  disableWebpInIOS: !0
                }), h && (r = m.a.add(e.imageUrl, {
                  _: +new Date
                }))
              }
              return Object(a.a)({}, e, {
                imageUrl: r
              })
            })
          },
          style() {
            var {
              pageMargin: t,
              bgColor: e,
              tpl: i
            } = this.opt, r = {
              "background-color": e,
              "margin-bottom": "-" + u(this.computedOverlapHeight)
            };
            return 1 === i && (r = Object(a.a)({}, r, {
              "padding-left": "" + u(t),
              "padding-right": "" + u(t)
            })), Object(g.a)(r)
          },
          mode() {
            var {
              fill: t
            } = this.opt;
            return "cover" === t ? "aspectFill" : "aspectFit"
          },
          commonPicData() {
            var {
              clientWidth: t,
              opt: e
            } = this, {
              pageMargin: i
            } = e, a = this.showImages, r = t - 2 * i, s = a.length;
            return a.map((t, e) => {
              var i = r / t.imageWidth,
                a = Math.floor(i * t.imageHeight);
              t.showHeight = a, "hotarea" === t.linkType && (t.hotAreas = t.hotAreas || [], t.hotAreas.map(t => (t.top = Math.max(0, Math.floor(t.startY * i)), t.left = Math.floor(t.startX * i), t.width = Math.floor((t.endX - t.startX) * i), t.height = Math.min(a, Math.floor((t.endY - t.startY) * i)), t.style = this.getHotAreaStyle(t), t)));
              var h = e === s - 1;
              return t.style = this.top2endStyle(e, h), t
            })
          },
          clientWidth: () => Object(d.a)(),
          swipeWidth() {
            return this.clientWidth - 2 * +this.opt.pageMargin
          },
          firstImageWidth() {
            var {
              imageWidth: t = 320
            } = this.opt.imgs[0] || {};
            return t
          },
          firstImageHeight() {
            var {
              imageHeight: t = 240
            } = this.opt.imgs[0] || {};
            return t
          },
          swipeHeight() {
            return Math.ceil(this.swipeWidth * (this.firstImageHeight / this.firstImageWidth))
          },
          swipeStyle() {
            var {
              swipeHeight: t,
              showImages: e
            } = this;
            return {
              swipe: "height: " + (e.length ? u(t) : 0)
            }
          },
          swipeBgStyle() {
            return Object(g.a)({
              width: "calc(100% - " + u(2 * this.opt.pageMargin) + ")",
              margin: "0 " + u(this.opt.pageMargin)
            }) + this.swipeStyle.swipe
          },
          swipeItemStyle() {
            var {
              swipeHeight: t,
              swipeWidth: e
            } = this;
            return Object(g.a)({
              height: u(t),
              width: u(e),
              margin: "0 " + u(this.opt.pageMargin)
            })
          },
          setImageHeight() {
            var {
              swipeHeight: t
            } = this;
            return Object(g.a)({
              height: u(t)
            })
          },
          slideShowHeight() {
            var {
              firstImageWidth: t,
              firstImageHeight: e,
              clientWidth: i
            } = this, {
              count: a,
              size: r
            } = this.opt;
            return (0 === r ? Math.ceil(.88 * i * e / t) : 1 === r ? Math.ceil(.4 * i * e / t) : Math.floor((i - 2 * (a - 1)) / (a - .8) * (e / t))) || 0
          },
          slidePics() {
            var {
              slideShowHeight: t
            } = this, {
              tpl: e
            } = this.opt, i = this.showImages, a = i.length;
            return 3 === e ? i.map((e, i) => {
              var r = Math.floor(t / e.imageHeight * e.imageWidth),
                s = i === a - 1;
              return e.style = this.getLinkStyle(r, t, s), e.imgStyle = e.style, e.mode = "aspectFill", e
            }) : this.getNavData()
          },
          slidePadding() {
            return "width: " + u(this.opt.pageMargin) + "; height: 1px; flex-shrink: 0"
          },
          computedOverlapHeight() {
            var {
              overlapHeight: t
            } = this.opt;
            return this.clientWidth / 375 * t
          }
        },
        created() {
          var t, e;
          if (null != (t = this.showImages) && t.length && 5 !== (null == (e = this.opt) ? void 0 : e.tpl) && this.$nextTick(() => {
              this.observeImagePosition()
            }), this.needPreLoad) {
            var {
              opt: {
                style: i,
                tpl: a,
                radius: r,
                swipeTime: s
              },
              style: h,
              commonPicData: o,
              swipeStyle: l,
              slidePics: g,
              showImages: n
            } = this;
            this.setData({
              opt: {
                style: i,
                tpl: a,
                radius: r,
                swipeTime: s
              },
              style: h,
              commonPicData: o,
              swipeStyle: l,
              slidePics: g,
              showImages: n
            }, {
              immediate: !0
            })
          }
        },
        destroyed() {
          this.observer && this.observer.disconnect()
        },
        methods: {
          observeImagePosition() {
            var t = this.createIntersectionObserver(),
              {
                windowHeight: e
              } = Object(n.b)();
            this.observer = t, t.relativeToViewport({
              bottom: .93 * e
            }).observe(".dc-image", e => {
              e.intersectionRatio > 0 && !this.isWebview && (c.a.start({
                name: "图片广告组件渲染"
              }), this.hasLogStart = !0, this.logEndTrigger && !this.hasLogEnd && this.logEnd(), t.disconnect())
            })
          },
          logEnd() {
            this.logEndTrigger = !0, this.hasLogStart && (c.a.end({
              name: "图片广告组件渲染",
              type: "finish"
            }), this.hasLogEnd = !0)
          },
          onImageLoadError(t, e) {
            this.loadErrorImagesMap["imgErr" + t] > 3 ? c.a.end({
              name: "图片广告组件渲染",
              type: "error",
              detail: {
                err: e
              }
            }) : this.loadErrorImagesMap = Object(a.a)({}, this.loadErrorImagesMap, {
              ["imgErr" + t]: this.loadErrorImagesMap["imgErr" + t] ? this.loadErrorImagesMap["imgErr" + t] + 1 : 1
            })
          },
          getNavData() {
            var {
              opt: t,
              firstImageWidth: e,
              firstImageHeight: i,
              clientWidth: a
            } = this, {
              count: r
            } = t, {
              slide: s,
              tpl: h,
              color: o
            } = t, l = this.showImages, n = 0;
            1 === s ? n = .8 : r = l.length;
            var d = 0,
              p = 0,
              m = 0;
            return 4 === h ? (d = Math.ceil(a / (r - n)), p = Math.floor(d * (i / e)), d * r - a > 0 && 0 === this.opt.slide && (m = d * r - a)) : (p = 35, d = Math.ceil(a / (r - n))), l.map((t, e) => {
              var i = d;
              m && r - e <= m && (i -= 1), t.imgStyle = Object(g.a)({
                width: u(i),
                height: u(p)
              }), t.mode = "aspectFill";
              var a = {
                width: u(i),
                color: o
              };
              return 5 === h && e === l.length - 1 && (a["border-right"] = "none"), t.titleStyle = Object(g.a)(a), t
            })
          },
          getHotAreaStyle: t => Object(g.a)({
            top: u(t.top),
            left: u(t.left),
            width: u(t.width),
            height: u(t.height)
          }),
          top2endStyle(t, e) {
            var {
              imgMargin: i
            } = this.opt;
            return "margin-bottom: " + u(e ? 0 : i) + ";"
          },
          getLinkStyle(t, e, i) {
            var {
              imgMargin: a
            } = this.opt, r = i ? 0 : u(a);
            return Object(g.a)({
              width: u(t),
              height: u(e),
              "margin-right": r
            })
          },
          onChange(t) {
            var e, i = null == t || null == (e = t.detail) ? void 0 : e.current;
            this.current = i, this.$emit("indexChange", {
              _index: i
            })
          },
          handleClick(t, e) {
            var i, r, s = Object(a.a)({}, t || {}, {
              _index: e,
              imageUrl: t.imageUrl || (null == (i = this.showImages) || null == (r = i[e]) ? void 0 : r.imageUrl),
              components_style_is_hotarea: +(this.showImages || []).some(t => "hotarea" === t.linkType)
            });
            this.$emit("jumpToLink", s)
          },
          handleCouponClick(t, e, i) {
            var r = Object(a.a)({}, t || {}, {
                _index: e
              }),
              s = (null == i ? void 0 : i.detail) || {};
            this.$emit("handleCouponClick", Object(a.a)({}, s, {
              clickParams: r
            }))
          },
          handleContactBack(t, e) {
            this.$emit("jumpToLink", t, e)
          },
          imageLoad(t) {
            this.logEnd(), 0 === t && this.$emit("component-loaded")
          }
        },
        ud: !0
      };
    e.default = r.default.component(v)
  }
}));