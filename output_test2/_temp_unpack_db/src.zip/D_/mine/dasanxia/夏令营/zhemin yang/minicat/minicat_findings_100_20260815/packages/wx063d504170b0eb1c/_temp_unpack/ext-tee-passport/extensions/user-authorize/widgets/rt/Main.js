var r = require("~/r");
r("jKn0", Object.assign({}, require("~/v.js").modules, {
  jKn0: function(t, e, a) {
    a.r(e);
    var o = a("YeA1"),
      i = a("qo/7"),
      u = {
        mixins: [Object(i.a)("main")],
        props: {
          customStyle: String,
          scene: String,
          authTypeList: {
            type: Array,
            value: []
          },
          kdtId: {
            type: [Number, String],
            required: !0
          },
          needUpdateNicknameAndAvatar: {
            type: Boolean,
            default: !1
          },
          needGetUnionId: Boolean,
          type: String,
          zIndex: {
            type: Number,
            default: 1e4
          },
          privacyProtocol: {
            type: Object,
            default: () => ({
              text: "《隐私政策》",
              url: "https://www.youzan.com/intro/rule/detail?alias=132atyi19&pageType=rules"
            })
          },
          userProtocol: {
            type: Object,
            default: () => ({
              text: "《用户协议》",
              url: "https://www.youzan.com/intro/rule/detail?alias=4f234e2f&pageType=rules"
            })
          },
          popupCustomStyle: String,
          allowDeny: Boolean
        },
        data() {
          return {
            bindKdtId: this.ctx.data.kdtId
          }
        },
        computed: {
          authKdtId() {
            return this.kdtId || this.bindKdtId
          }
        },
        created() {
          Object(o.b)(this, {
            kdtId: t => {
              this.bindKdtId = t
            }
          })
        },
        methods: {
          handleStatusChange(t) {
            this.$emit("status-change", t)
          },
          handleNext(t) {
            if (this.ctx) {
              var {
                logger: e
              } = this.ctx;
              e && t.mobile && e.setUser({
                li: t.userId,
                m: t.mobile
              })
            }
            this.$emit("next", t)
          },
          handleFail(t) {
            this.$emit("fail", t)
          },
          handleAuthPopupShow(t) {
            this.$emit("auth-popup-show", t)
          },
          handleAuthPopupAllow(t) {
            this.$emit("auth-popup-allow", t)
          },
          handleAuthPopupRefuse(t) {
            this.$emit("auth-popup-refuse", t)
          }
        }
      },
      n = a("9ZMt");
    e.default = n.default.component(u)
  },
  "qo/7": function(t, e, a) {
    function o(t) {
      return {
        data() {
          var {
            cloudDesignConfig: e
          } = this.ctx.data;
          return {
            protocolIsCloudSlot: !!e && e.replacedSlots.includes("account-protocol-content"),
            protocolSource: "@ext/authorize/" + t + "_" + Date.now()
          }
        }
      }
    }
    a.d(e, "a", function() {
      return o
    })
  }
}));