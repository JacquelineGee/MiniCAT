var r = require("~/r");
r("vaT5", Object.assign({}, require("~/v.js").modules, {
  vaT5: function(e, t, o) {
    o.r(t);
    var a = o("Fcif"),
      s = o("ONqW"),
      i = o("YeA1"),
      r = {
        props: {
          opt: Object
        },
        data: () => ({
          showPopup: !1
        }),
        watch: {
          showPopup(e) {
            if (e) {
              var t = this.opt.serviceDescList.map(e => e.tag);
              this.logger({
                en: "服务标签-详情-曝光",
                ei: "service_tag_pop_view"
              }, t)
            }
          }
        },
        mounted() {
          var e = this.opt.serviceBarList.map(e => e.tag);
          this.logger({
            en: "服务标签-曝光",
            ei: "service_tag_view"
          }, e)
        },
        methods: {
          logger(e, t) {
            Object(s.a)().log(Object(a.a)({}, e, {
              et: "view",
              params: {
                component: "service_tab_bar",
                goodsId: this.opt.goodsBaseInfo.id,
                tags: t
              }
            }))
          },
          handleChangeShowPopup(e) {
            this.showPopup = e
          },
          onClickItem(e) {
            e.url && Object(i.a)().dmc.navigate("CommonWebview", {
              src: e.url
            })
          }
        },
        ud: !0
      },
      p = o("9ZMt");
    t.default = p.default.component(r)
  }
}));