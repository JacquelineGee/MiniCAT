var r = require("~/r");
r("Keyw", Object.assign({}, require("~/v.js").modules, require("~/c.js").modules, {
  Keyw: function(t, e, i) {
    i.r(e);
    var o = i("Fcif"),
      s = i("9ZMt"),
      r = i("zMoS"),
      a = i("0hwI"),
      n = i("/XVY"),
      h = Object(n.a)({
        type: {
          default: ""
        },
        itemIds: {
          default: () => []
        },
        queryExtra: {
          default: () => ({})
        },
        loadMore: {
          default: "0"
        },
        pageType: {},
        showMoreButton: {
          default: !1
        },
        items: {},
        isSync: {
          default: !1
        },
        loading: {
          default: !1
        }
      }),
      p = i("R7Zb"),
      l = 0,
      u = 2,
      d = 5,
      g = 6,
      c = {
        methods: {
          getSkeletonNumber: t => +t === d || +t === u || +t === g ? 3 : +t === l ? 1 : 2
        }
      },
      m = i("/3Ts"),
      y = i("bs6A"),
      L = i("yDO/"),
      O = i("2Dtx"),
      {
        useTpx: v
      } = s.default.style,
      f = {
        computed: {
          capLayoutStyle() {
            var {
              layoutMargin: t,
              itemMargin: e
            } = this.capLayoutOpt, i = v(-e / 2), o = v(t);
            return Object(O.a)({
              padding: "0 " + o,
              margin: "0 " + i
            })
          }
        }
      },
      w = i("pF6A"),
      S = i("MLLI"),
      b = i("VdoR"),
      k = s.default.getApp(),
      I = {
        mixins: [Object(p.a)({
          optDesc: h
        }), y.a, c, f, w.a],
        props: {
          kdtId: Number,
          uuid: {
            type: String,
            default: ""
          },
          cloudLoggerField: {
            type: Array,
            default: () => []
          }
        },
        data: () => ({
          curList: [],
          loading: !1,
          finished: !1,
          outCountdownOpt: null,
          showLoadMore: !1,
          heightStyle: "",
          direction: "",
          preListLength: 0
        }),
        logicData: () => ({
          page: 1,
          moreLinkOpt: null,
          showSwipeLoadMore: !1,
          isTagsShow: !1,
          hasShowAll: !1,
          slg: ""
        }),
        computed: {
          dcGoodsStyle() {
            var t, e, {
                opt: i
              } = this,
              {
                itemCardOpt: o,
                layoutOpt: s
              } = this.opt,
              {
                type: r,
                layout: a
              } = o,
              {
                type: n,
                itemMargin: h
              } = s,
              p = Number(12 - h / 2),
              l = null != (t = i.goodsComponentOpt) && t.style ? i.goodsComponentOpt.style : "";
            "card" !== r && "border" !== r || "horizontal" !== a || "one" !== n || (l = "background: #fff;padding: " + (null != (e = this.waterfallListParts) && e.length ? p : 0) + "px 0;" + l);
            return l
          },
          isUmpGoods() {
            var {
              type: t
            } = this.opt;
            return "ump_limitdiscount" === t || "ump_seckill" === t || "member_goods" === t || "groupon" === t || "points_goods" === t || "period_buy" === t || "bargain" === t
          },
          shouldTagsShow() {
            var t, e;
            return this.currentIsPreLoadShow ? !(null == (t = this.opt) || null == (e = t.itemCardOpt) || !e.tagsOpt) : this.isTagsShow
          },
          shouldShowVanListLoading() {
            return (!this.opt.preLoadGoodsInfoOpt || !this.opt.preLoadGoodsInfoOpt.length) && this.loading
          },
          capLayoutOpt() {
            var {
              layoutOpt: t,
              queryExtra: {
                layout: e = 0
              }
            } = this.opt;
            return t && "swipe" === t.type && (t.canUseScrollView = !1), Object(o.a)({
              layout: e
            }, t)
          },
          isLimitdDiscount() {
            return "ump_limitdiscount" === this.opt.type
          },
          isGroupon() {
            return "groupon" === this.opt.type
          },
          isLimitdDiscountOrGroupon() {
            return this.isLimitdDiscount || this.isGroupon
          },
          isWaterfall() {
            var {
              itemCardOpt: {
                type: t
              }
            } = this.opt;
            return t === L.b.WATERFALL
          },
          isSwipeMoreBtnShow() {
            return "ump_limitdiscount" !== this.opt.type && (this.hasShowAll ? this.hasShowAll : this.showSwipeLoadMore)
          },
          isMoreBtnShow() {
            return "groupon" !== this.opt.type && "points_goods" !== this.opt.type || this.opt.showMoreButton
          },
          waterfallListParts() {
            return this.addSkeletonList.reduce((t, e, i) => {
              var s = i % L.i;
              return t[s] ? t[s].push(Object(o.a)({}, e, {
                itemIndex: s
              })) : t[s] = [Object(o.a)({}, e, {
                itemIndex: s
              })], t
            }, [])
          },
          isSwipeLayout() {
            var {
              layoutOpt: {
                type: t
              }
            } = this.opt;
            return t === L.f.SWIPE
          },
          isSwipeGoodsOptional() {
            var {
              type: t,
              itemIds: e
            } = this.opt;
            return !!("goods" === t && e && e.length && this.isSwipeLayout)
          },
          moreButtonOpt() {
            var {
              layoutOpt: {
                itemMargin: t
              },
              itemCardOpt: {
                corner: e
              }
            } = this.opt;
            return {
              corner: e,
              text: this.isSwipeGoodsOptional || this.hasShowAll ? "查看全部" : "查看更多",
              loading: this.loading,
              margin: t / 2,
              isSwipe: this.isSwipeLayout
            }
          },
          useLoadMore() {
            return this.opt.loadMore === L.g.ON
          },
          isAutoFetch() {
            var {
              activitySource: t,
              goodsSource: e
            } = this.opt.queryExtra || {};
            switch (!0) {
              case this.isLimitdDiscount:
                return t === L.a.auto;
              case this.isGroupon:
                return e === L.d.auto;
              default:
                return !1;
            }
          },
          currentIsPreLoadShow() {
            return !this.curList.length && this.opt.preLoadGoodsInfoOpt && this.opt.preLoadGoodsInfoOpt.length
          },
          addSkeletonList() {
            var t, e = {
              isTagsShow: this.shouldTagsShow,
              useSkeleton: !0,
              compType: this.opt.type,
              layoutOpt: this.opt.layoutOpt,
              queryExtra: this.opt.queryExtra
            };
            if (this.currentIsPreLoadShow) return this.opt.preLoadGoodsInfoOpt.map((t, i) => Object(o.a)({}, t, e, {
              itemIndex: i,
              layoutItemWrapStyle: this.getCapLayoutItemWrapStyle(i)
            }));
            var {
              skeletonOpt: i
            } = this.opt, s = (t, e, i) => Object(o.a)({}, t[e], {
              textAreaOpt: Object(o.a)({}, t[e].textAreaOpt, {
                textAreaStyle: "height: auto;"
              })
            }), r = [];
            if ((this.loading || this.opt.loading) && i) {
              (this.curList || []).length && this.curList[this.curList.length - 1];
              if (i.default) r.push(i.default);
              else if (i.two)(this.curList || []).length % 2 == 0 ? (r.push(i.two), r.push(i.two)) : r.push(s(i, "two"));
              else if (i.three) {
                var a = (this.curList || []).length % 3;
                if (0 === a) r.push(i.three), r.push(i.three), r.push(i.three);
                else {
                  var n = s(i, "three");
                  2 === a ? r.push(n) : r.push(n, n)
                }
              } else if (i.hybrid) {
                var h = (this.curList || []).length % 3;
                if (0 === h) r.push(i.hybrid.one);
                else {
                  var p = s(i.hybrid, "two");
                  2 === h ? r.push(p) : r.push(p, p)
                }
              }
            }
            var l = [...this.curList, ...r].map((t, i) => {
              var s = !1;
              return "soldout" === t.imgOpt.mask && "2" === e.queryExtra.showSoltOutDisplay && (s = !0), Object(o.a)({}, t, e, {
                itemIndex: i,
                layoutItemWrapStyle: this.getCapLayoutItemWrapStyle(i),
                isShowOutGoods: s,
                preventBuyClickItem: this._opt.preventBuyClickItem || !1
              })
            });
            if ((null == (t = this.opt.layoutOpt) ? void 0 : t.type) === L.f.HYBRID) {
              for (var u = [], d = 0; d < l.length; d++) d % 3 == 0 ? u.push(l[d]) : d % 3 == 1 && (u.push({
                type: "hybrid-line",
                items: [Object(o.a)({}, l[d], {
                  hybridSmall: !0
                }), Object(o.a)({}, l[d + 1], {
                  hybridSmall: !0
                })].filter(t => t.type)
              }), d++);
              l = u
            }
            return l
          },
          isShowGoodsAddNumber() {
            var t;
            return (null == (t = this._opt) ? void 0 : t.isShowGoodsAddNumber) || !1
          }
        },
        watch: {
          opt() {
            this.init()
          },
          kdtId() {
            this.init()
          }
        },
        created() {
          var t, e, i;
          (null == (t = this.opt) || !t.isSync || null != (e = this.opt) && null != (i = e.items) && i.length) && (this.hasLogMonitor = !0, b.a.start({
            name: "商品组件渲染"
          }));
          var o = this.isSwipeLayout ? L.c.SWIPE : L.c.UP;
          if (this.direction = o, this.opt.preLoadGoodsInfoOpt && this.opt.preLoadGoodsInfoOpt.length) {
            var {
              capLayoutOpt: s,
              isWaterfall: r,
              addSkeletonList: a,
              capLayoutStyle: n,
              capLayoutItemStyle: h,
              opt: p
            } = this;
            this.setData({
              opt: {
                layoutOpt: {
                  type: p.layoutOpt.type
                }
              },
              direction: o,
              isWaterfall: r,
              capLayoutOpt: s,
              addSkeletonList: a,
              capLayoutStyle: n,
              capLayoutItemStyle: h
            }, {
              immediate: !0
            }), Promise.resolve().then(() => this.$emit("component-loaded"))
          }
          this._opt.triggerCreateInit && this.getListData();
          var l = this.fetchList();
          Promise.resolve(l).then(() => {
            this.$nextTick(() => {
              this.$emit("component-loaded")
            })
          })
        },
        methods: {
          init() {
            var t, e, i, o;
            this.preListLength = null == (t = this.curList) ? void 0 : t.length, this.curList = [], this.page = 1, this.loading = !1, this.finished = !1, this.moreLinkOpt = null, this.outCountdownOpt = null, this.showLoadMore = !1, this.showSwipeLoadMore = !1, this.hasShowAll = !1, this.randomKey = Math.random(), this.getListData(), null != (e = this.opt) && e.isSync && null != (i = this.opt) && null != (o = i.items) && o.length && !this.hasLogMonitor && (this.hasLogMonitor = !0, b.a.start({
              name: "商品组件渲染"
            }))
          },
          onPullDownRefresh() {
            this.opt.isSync || this.init()
          },
          formatListData(t) {
            var e, i, o, s, r = (null == (e = this.opt) || null == (i = e.layoutOpt) ? void 0 : i.type) || "";
            return this.slg = null == (o = t[0]) || null == (s = o.extraInfo) ? void 0 : s.slg, t.map((t, e) => {
              var i = Object(m.a)(this.opt.itemCardOpt, t);
              return i.countdownOpt && this.isLimitdDiscount && (r !== L.f.THREE && r !== L.f.SWIPE || (0 === e && (i.countdownOpt.layout = "out", this.outCountdownOpt = i.countdownOpt), delete i.countdownOpt)), i
            })
          },
          getListData() {
            if (this.opt.isSync) {
              var {
                items: t
              } = this.opt;
              return this.finished = !0, this.curList = this.formatListData(t), void this.$nextTick(() => {
                this.initCardHeight()
              })
            }
            this.fetchList()
          },
          fetchList() {
            var {
              itemIds: t = [],
              queryExtra: e,
              isSync: i
            } = this.opt;
            if (!i)
              if ("ump_limitdiscount" === e.type && "0" !== e.activitySource && t && 0 === t.length) this.finished = !0;
              else if (!this.hasShowAll && !this.loading) {
              this.loading = !0;
              var {
                pageSize: s = L.h
              } = e;
              "tag_list_top" !== e.type || e.isShowAll || 6 !== e.layout || (s = e.goodsNumber < 10 ? e.goodsNumber : e.goodsNumber > 10 * this.page ? 10 : e.goodsNumber - 10 * (this.page - 1)), "member_goods" === e.type && 0 == +e.goodsFrom && (s = t && t.length || 30);
              var r = Object(o.a)({}, e, {
                page: this.page,
                pageSize: s,
                requestId: k.globalData.wscHomeRequestId || "",
                supportCombo: !0
              });
              if (t && t.length > 0) {
                var n = (this.page - 1) * s,
                  h = t.slice(n, n + s).join(",");
                if (r.itemIds = h, 0 === h.length) return this.loading = !1, void(this.finished = !0)
              }
              var p, {
                randomKey: l
              } = this;
              return (p = r, a.a.get({
                url: "/wscdeco/tee/goods.json",
                data: p
              })).then(i => {
                var {
                  list: o = [],
                  hasMore: a,
                  extra: n = {},
                  hasSwipeMoreBtn: h = !1
                } = i;
                if (1 == +r.page && 0 === o.length && b.a.end({
                    type: "finish",
                    name: "商品组件渲染"
                  }), this.randomKey === l) {
                  var {
                    moreLinkOpt: p
                  } = n;
                  this.moreLinkOpt = p, this.isSwipeGoodsOptional && (this.moreLinkOpt = {
                    type: "allgoods"
                  }), this.curList = this.curList.concat(this.formatListData(o)), this.$nextTick(() => {
                    this.initCardHeight(), this.goodsViewLogger(o)
                  }), this.finished = this.isGroupon && !this.isAutoFetch ? +s * this.page >= t.length : !a, "tag_list_top" === e.type && this.curList.length >= e.goodsNumber && (this.finished = !0, this.curList = this.curList.slice(0, e.goodsNumber)), this.page++, this.loading = !1, this.page > 2 && a && this.isSwipeLayout && "ump_limitdiscount" !== this.opt.type && "goods" !== this.opt.type && (this.hasShowAll = !0), this.finished && this.moreLinkOpt && setTimeout(() => {
                    this.showLoadMore = !0
                  }, 1e3), this.isSwipeLayout && ("goods" === this.opt.type ? this.showSwipeLoadMore = h : this.showSwipeLoadMore = this.curList.length && !this.finished), a && !this.isSwipeLayout && this.$nextTick(() => {
                    var {
                      windowHeight: t
                    } = Object(S.b)();
                    this.createSelectorQuery().select(".dc-goods").boundingClientRect(e => {
                      e && e.bottom >= 0 && e.bottom <= t - 100 && this.fetchList()
                    }).exec()
                  })
                }
              }).catch(t => {
                this.finished = !0, this.loading = !1, b.a.end({
                  name: "商品组件渲染",
                  type: "error",
                  detail: {
                    err: t
                  }
                })
              })
            }
          },
          goodsViewLogger(t) {
            if (this.isLimitdDiscountOrGroupon || "goods" === this.opt.type) {
              var e = t.map(t => {
                var e, i, s, r = (this.cloudLoggerField || []).reduce((e, i) => {
                    var s, r = {};
                    "img_url" === i && (r.img_url = null == t || null == (s = t.imgOpt) ? void 0 : s.src);
                    if ("page_url" === i) {
                      var a, n = getCurrentPages();
                      r.page_url = null == (a = n[n.length - 1]) ? void 0 : a.route
                    }
                    return Object(o.a)({}, e, r)
                  }, {}),
                  a = null == t || null == (e = t.actionOpt) ? void 0 : e.id;
                return Object(o.a)({
                  goods_id: a,
                  item_id: a,
                  item_type: (null == t || null == (i = t.itemType) ? void 0 : i.type) || "goods",
                  banner_id: this.getBannerId(),
                  component: this.getLoggerComponentName(),
                  ump_params: this.getMarketingActivity(t),
                  good_title: null == t || null == (s = t.titleOpt) ? void 0 : s.title
                }, r)
              });
              this.sendComponentLogger("logger", {
                et: "view",
                ei: "view",
                en: "商品曝光",
                params: {
                  view_objs: e
                }
              })
            }
          },
          getMarketingActivity(t) {
            var {
              tagsOpt: e
            } = t;
            return ((null == e ? void 0 : e.list) || []).map(t => ({
              activity_type: t.labelType
            }))
          },
          getItemClickOpt(t) {
            var e, {
                type: i,
                queryExtra: s
              } = this.opt,
              a = Object(r.a)(s, "grouponType");
            "groupon" === i && a === L.e.LUCKY && t && t.link && (t.link.query = {
              type: "luckyDrawGroup",
              activityId: t.id
            });
            var {
              umpType: n,
              activityId: h
            } = t.link || {}, p = {};
            return n && h && (p = {
              activityId: h,
              umpType: n
            }), Object(o.a)({}, t, {
              link: Object(o.a)({}, t.link || {}, {
                query: Object(o.a)({}, (null == (e = t.link) ? void 0 : e.query) || {}, p, {
                  bannerId: this.getBannerId(),
                  slg: this.slg
                }, this.getComponentLoggerExtraParams())
              })
            })
          },
          handleBuyClick(t) {
            this.clickBuyButtonLogger(t);
            var {
              isVirtual: e
            } = t;
            this.isUmpGoods || 3 == +e || 31 === (null == t ? void 0 : t.goodsType) ? this.$emit("item-click", this.getItemClickOpt(t)) : this.$emit("button-click", t)
          },
          clickBuyButtonLogger(t) {
            try {
              var e = this.getLoggerComponentName();
              if (!["limitdiscount", "groupon", "goods", "tag_list_top"].includes(e)) return;
              this.sendComponentLogger("logger", {
                et: "click",
                ei: "click_buy",
                en: "点击购买",
                params: {
                  component: e,
                  banner_id: this.getBannerId(),
                  ump_params: this.getMarketingActivity(t),
                  slg: this.slg
                }
              })
            } catch (t) {}
          },
          handleItemClick(t) {
            this.openDetailLogger(t), this.$emit("item-click", this.getItemClickOpt(t))
          },
          openDetailLogger(t) {
            try {
              var e = this.getLoggerComponentName();
              if (!["limitdiscount", "groupon", "goods", "tag_list_top"].includes(e)) return;
              var {
                itemId: i,
                id: o,
                title: s = ""
              } = t;
              if (!i && !o) return;
              this.sendComponentLogger("logger", {
                et: "click",
                ei: "open_goods",
                en: "打开商品详情",
                params: {
                  component: e,
                  goods_id: i || o,
                  goods_name: s,
                  banner_id: this.getBannerId(),
                  ump_params: this.getMarketingActivity(t),
                  slg: this.slg
                }
              })
            } catch (t) {}
          },
          handleMoreClick() {
            this.moreLinkOpt && this.$emit("item-click", {
              link: this.moreLinkOpt
            })
          },
          initCardHeight() {
            var {
              type: t,
              layoutOpt: e,
              itemCardOpt: i
            } = this.opt;
            if (t !== L.b.WATERFALL && e && e.type === L.f.TWO) {
              var o = 0;
              i.type === L.b.BORDER && e.type === L.f.TWO && (o = 2), setTimeout(() => {
                var t = "web" === s.default.getEnv() ? ".dc-goods .cap-item-card" : ".dc-goods >>> .cap-item-card";
                this.createSelectorQuery().select(t).boundingClientRect(t => {
                  t && t.height > 0 && (this.heightStyle = "height: " + s.default.style.useTpx(t.height - o) + ";")
                }).exec()
              }, 500)
            }
          },
          handleLoadMore() {
            this.useLoadMore ? this.loading = !1 : this.fetchList()
          },
          handleClickLoadNextPage() {
            this.fetchList(), this.clickLoadNextPageLogger()
          },
          clickLoadNextPageLogger() {
            var t = "";
            this.isLimitdDiscount && (t = "limitdiscount"), this.isGroupon && (t = "groupon"), this.sendComponentLogger("logger", {
              et: "click",
              ei: "viewmore_click",
              en: "点击查看更多",
              params: {
                component: t,
                banner_id: this.getBannerId()
              }
            })
          },
          onItemImageLoaded(t, e) {
            this.$emit("on-item-image-loaded", {
              index: t,
              parentIndex: e
            })
          }
        },
        ud: !0
      };
    e.default = s.default.component(I)
  }
}));