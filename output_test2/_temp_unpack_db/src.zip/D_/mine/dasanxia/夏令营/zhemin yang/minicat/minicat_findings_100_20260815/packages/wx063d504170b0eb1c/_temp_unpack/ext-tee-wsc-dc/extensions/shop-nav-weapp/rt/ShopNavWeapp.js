var r = require("~/r");
r("WBiS", Object.assign({}, require("~/v.js").modules, require("~/c.js").modules, {
  WBiS: function(e, t, a) {
    a.r(t);
    var i = a("Fcif"),
      r = a("eijD"),
      s = a("a1Mm"),
      n = a("SVbq"),
      o = a("/duV"),
      c = a("taYb"),
      d = a("f9/1"),
      l = a("w2Y9"),
      h = a.n(l),
      g = a("9DLJ"),
      b = a("US/N"),
      u = {},
      p = (a("WMGV"), a("AGZf")),
      v = a("xih6");

    function f(e) {
      return Object(v.a)().some(t => e.startsWith(t))
    }

    function T() {
      var e = getCurrentPages() || [];
      return f("/" + (e[e.length - 1] || {}).route)
    }
    var O = a("9ZMt"),
      m = getApp();

    function C(e) {
      void 0 === e && (e = {}), wx.redirectTo(e)
    }
    var I = a("PKOW"),
      j = {
        [I.c[I.b.CART].TRANS]: {
          subRoutes: [I.c[I.b.CART].NEW, I.c[I.b.CART].OLD]
        },
        [g.e.TRANS]: {
          subRoutes: [g.e.TEE, g.e.EXT, g.e.OLD]
        },
        [g.g.TRANS]: {
          subRoutes: [g.g.TEE, g.g.EXT, g.g.OLD]
        },
        [g.f.TRANS]: {
          subRoutes: [g.f.TEE, g.f.EXT, g.f.OLD]
        },
        [g.d.TRANS]: {
          subRoutes: [g.d.TEE, g.d.EXT, g.d.OLD]
        },
        [g.a.OLD]: {
          subRoutes: [g.a.OLD, g.a.NEW]
        },
        [g.l.TRANS]: {
          subRoutes: [g.l.PAGE]
        }
      };

    function S(e) {
      var t = e;
      if (!j[t])
        for (var a = Object.keys(j), i = 0; i < a.length; i++) {
          var {
            subRoutes: r
          } = j[a[i]];
          if (r && r.length)
            for (var s = 0; s < r.length; s++)
              if (e === r[s]) {
                t = a[i];
                break
              } if (t !== e) break
        }
      return t
    }
    var x = a("DXKY"),
      y = a("tmLU"),
      w = a("U0uK"),
      k = a("Sipi"),
      P = a("YeA1"),
      A = a("4jn8"),
      N = a("xRet"),
      {
        dmc: R
      } = Object(P.a)(),
      _ = getApp(),
      D = Object(w.a)().kdtId,
      L = {},
      E = (e, t) => {
        L[e] = t, Object(d.setEnterCacheConfig)("tabbarNavCacheMap", e, t)
      },
      K = "跳转其他小程序失败,可联系商家处理",
      M = {},
      q = {},
      W = e => /^http/.test(e),
      U = {
        props: {
          isNewIphone: Boolean,
          onlyColorText: Boolean,
          activePath: String,
          forceShow: Boolean,
          nativeSelectedIndex: Number,
          cloudConfig: {
            type: Object,
            default: () => ({})
          }
        },
        data: () => ({
          navList: [],
          navStyleMap: g.i,
          selectedColor: "",
          color: "",
          navStyle: 1,
          customBackground: "",
          deviceType: _.deviceType || "",
          isTabPage: !1,
          cacheKdtId: "",
          selectedIndex: 0,
          brandNavStyle: 1,
          notCoexist: !1
        }),
        computed: {
          isCart() {
            var {
              selectedIndex: e
            } = this, t = this.navList[e] || {};
            if (!t) return !1;
            var {
              pagePath: a = ""
            } = t;
            return Object(I.d)(a.split("?")[0], I.b.CART)
          },
          classes() {
            var {
              navStyle: e,
              deviceType: t
            } = this, a = "tab-bar";
            return [a, a + (3 === e ? "-float" : "-legacy"), t]
          },
          brandStyle() {
            return " background: " + this.customBackground
          },
          commonStyle() {
            var e = this.customBackground || "#fcfcfc";
            return this.navStyle === g.i.MAIN_ICON || this.navStyle === g.i.XUAN_FU || this.navStyle === g.i.DEFAULT && 1 === this.brandNavStyle ? " background:" + e : ""
          },
          rudderStyle() {
            return this.navStyle === g.i.MAIN_ICON_STYLE_TWO ? "border: 0px;bottom: 19px" : " "
          }
        },
        watch: {
          nativeSelectedIndex(e) {
            setTimeout(() => {
              this.selectedIndex = e
            }, 0)
          },
          navStyle(e) {
            3 === e && this.ctx && (this.ctx.data.navHeight = this.deviceType ? 56 : 66)
          }
        },
        created() {
          this.weappNavInit()
        },
        methods: {
          changeTheme(e) {
            var t = this;
            return Object(r.a)(function*() {
              var {
                color_mode: a,
                color: r,
                selected_color: s,
                custom_background: n
              } = _.getNavConfig(), o = a === g.b.SHOP, c = yield _.getShopTheme(), d = {
                color: o ? g.c.UNACTIVATED : r,
                selectedColor: o ? c.colors["main-bg"] : s,
                customBackground: n
              }, l = L[e];
              E(e, Object(i.a)({}, l, d)), t.getCacheMap(e)
            })()
          },
          chainStoreAction() {
            var e = this;
            return Object(r.a)(function*() {
              if (_.forceUseHqTabbar()) return yield e.changeTheme(Object(o.e)()), !0
            })()
          },
          weappNavInit() {
            var e = this;
            return Object(r.a)(function*() {
              var t = _.getKdtId() || D;
              e.initEvents(), (yield e.chainStoreAction()) || (L[t] ? e.getCacheMap(t) : e.initNavData(t))
            })()
          },
          initEvents() {
            x.a.off("shop:theme:resolved", this.kdtIdChange.bind(this)), x.a.on("shop:theme:resolved", this.kdtIdChange.bind(this))
          },
          kdtIdChange() {
            var e = this;
            return Object(r.a)(function*() {
              var t = +_.getKdtId();
              if (e.data.cacheKdtId !== t) {
                if (e.cacheKdtId = t, yield e.chainStoreAction()) return;
                if (L[t]) return void e.getCacheMap(t);
                e.initNavData(t)
              }
            })()
          },
          navCommonClick(e) {
            this.wxSwitchTab(e)
          },
          spliceKdtIdAndKey: e => Object(n.z)() && !Object(d.getEnterCacheConfig)("hqHomeToOtherHome") ? "" + Object(o.e)() + e : "" + (_.getKdtId() || D) + e,
          getCurrentPage() {
            var e = getCurrentPages() || [];
            return e[e.length - 1] || {}
          },
          getCacheMap(e) {
            var t = this.getCurrentPage();
            if (!_.forceUseHqTabbar() && t.options && t.options.showcaseTplfromRoute) this.initNavData(e);
            else {
              var a = S(t.route),
                r = M[this.spliceKdtIdAndKey(a)] || {
                  isTabPage: !1,
                  selectedIndex: this.nativeSelectedIndex || ""
                },
                s = Object(i.a)({}, L[e], r);
              q[e] && (_.globalData.tabbarOriginList = q[e]), Object.assign(this.data, s), setTimeout(() => {
                this.setSelectedIndex(t, r.selectedIndex)
              }, 0)
            }
          },
          initNavData(e, t) {
            void 0 === t && (t = {});
            var {
              count: a = 1,
              refresh: r = !1
            } = t;
            ((e, t) => (u[e] && !t || (u[e] = Object(b.default)({
              path: "/wscshop/weapp/custom_nav.json",
              data: {
                kdt_id: e,
                useOmniChannel: !0
              }
            })), u[e]))(e, r).then(t => {
              var a = t.data || {},
                {
                  list: r,
                  colorMode: s = g.b.CUSTOM,
                  navStyle: n = 1,
                  color: d,
                  selectedColor: l,
                  customBackground: h,
                  brandNavStyle: b = 1,
                  notCoexist: u
                } = a,
                p = 2 !== n && u;
              this.brandNavStyle = b;
              var v = r;
              _.trigger(N.b, v);
              var f = this.processNavList(v),
                T = Object(i.a)({}, f, {
                  navStyle: n,
                  notCoexist: p
                });
              q[e] = v, _.globalData.tabbarPageList = (null == f ? void 0 : f.navList) || [], _.globalData.tabbarOriginList = v, _.isChainStoreSync && +e === Object(o.e)() && (_.globalData.tabbarHqOriginList = c.a.toSnakeCase(v)), -1 === T.selectedIndex && (T.selectedIndex = this.data.selectedIndex), _.getShopTheme().then(t => {
                var a = _.getShopInfoSync(),
                  r = s === g.b.SHOP,
                  n = {
                    color: r ? g.c.UNACTIVATED : d,
                    selectedColor: r ? t.colors["main-bg"] : l,
                    customBackground: h
                  };
                r && delete T.selectedIndex, E(e, Object(i.a)({}, T, n, {
                  isDecorateFollowHq: a.isDecorateFollowHq
                })), Object.assign(this.data, L[e])
              })
            }).catch(() => {
              a > 3 || this.initNavData(e, {
                count: a + 1,
                refresh: !0
              })
            })
          },
          processNavList(e) {
            var t, a = !1,
              r = -1,
              n = this.getCurrentPage();
            if (n.options && n.options.showcaseTplfromRoute) {
              var o = decodeURIComponent(n.options.showcaseTplfromRoute);
              t = S(o)
            } else t = S(n.route);
            var c = e.map((e, n) => {
              var o = Object(i.a)({}, e),
                {
                  iconPath: c,
                  selectedIconPath: d,
                  customPage: l,
                  pagePath: h
                } = o;
              W(c) && (o.iconPath = Object(s.a)(c, "!80x80.jpg")), W(d) && (o.selectedIconPath = Object(s.a)(d, "!80x80.jpg"));
              var b = function(e) {
                  var {
                    customPage: t,
                    pagePath: a
                  } = e, i = getApp(), {
                    isRetailApp: r
                  } = i.globalData, s = t || a.startsWith("pages/home") || a.startsWith("pages/common/webview-page") || r && "pages-retail/usercenter/dashboard-v2/index" === a ? a : a.replace(/^pages(-|\/)/, "packages/");
                  return g.j.test(s) && (r && s === g.k.WSC && (s = g.k.RETAIL), r || s !== g.k.RETAIL || (s = g.k.WSC)), s
                }({
                  customPage: l,
                  pagePath: h
                }),
                u = "";
              b && (b.startsWith("pages/home/tab") || b.startsWith("pages/home/dashboard")) && (u = this.spliceKdtIdAndKey(b.replace(/^pages(-|\/)/, "packages/"))), o.pagePath = "/" + b + "?navIndex=" + n, b === t && (a = !0, r = n);
              var p = this.spliceKdtIdAndKey(b);
              return M[p] || (M[p] = {
                isTabPage: !0,
                selectedIndex: n
              }), u && !M[u] && (M[u] = {
                isTabPage: !0,
                selectedIndex: n
              }), o
            });
            return {
              isTabPage: a,
              selectedIndex: r,
              navList: c
            }
          },
          setSelectedIndex(e, t) {
            var {
              navIndex: a
            } = e.options || {};
            isNaN(+a) && isNaN(+t) || (this.selectedIndex = +(a || t))
          },
          wxSwitchTab(e) {
            var t, a = this.navList[e],
              {
                extraData: r,
                pagePath: s
              } = a,
              n = e,
              {
                tabbarOriginList: o
              } = _.globalData,
              c = s.split("?")[0];
            if (Object(I.d)(c, I.b.CART)) return this.switchToCart(s);
            if (function(e) {
                return "/packages/retail-shelf/shelf/index" === e
              }(c)) this.switchToRetailShelf(o, n);
            else {
              var d = o.find((e, t) => t === n);
              if ("chat" !== (null == d || null == (t = d.linkInfo) ? void 0 : t.linkType)) {
                if (r && "2" === r.link_type) return 1 == +r.use_short_link ? wx.navigateToMiniProgram({
                  shortLink: r.short_link,
                  fail() {
                    Object(p.a)(K)
                  }
                }) : wx.navigateToMiniProgram({
                  appId: r.other_weapp_appid,
                  path: r.other_weapp_link,
                  fail() {
                    Object(p.a)(K)
                  }
                });
                var l = {};
                "feature" === (null == d ? void 0 : d.attachedId) && null != d && d.alias && (l.alias = d.alias), Object(A.b)(o, {
                  tabBarIndex: n,
                  query: Object(i.a)({
                    navIndex: n
                  }, l),
                  fail: () => {
                    this.switchTab(e)
                  }
                })
              }
            }
          },
          switchTab(e) {
            var t = this.navList[e],
              {
                active: a,
                extra: i,
                pagePath: r
              } = t;
            if (!a) {
              ! function(e) {
                var {
                  path: t
                } = e;
                m.logger && m.logger.log({
                  et: "click",
                  ei: "custom_tab_bar_before_navigate",
                  en: "自定义导航点击跳转",
                  params: {
                    kdt_id: m.getKdtId(),
                    version: m.getVersion(),
                    navigateUrl: t
                  }
                })
              }({
                path: r
              }), this.setRetailGlobalData(r);
              var s = getCurrentPages() || [],
                n = r.split("?")[0],
                o = g.h[n];
              if (o) {
                var c = h.a.getAll(r),
                  d = s.length > 1 ? "reLaunch" : "redirectTo";
                R[d](o, c)
              } else {
                if (s.length > 1) return (getCurrentPages() || []).some(e => {
                  var {
                    route: t
                  } = e;
                  return Object(v.a)().indexOf("/" + t) > -1
                }) ? f(r) ? R.switchTab(r) : C({
                  url: r
                }) : wx.reLaunch({
                  url: r
                });
                Object(I.d)(n, I.b.CART) ? this.switchToCart(r) : i && "2" === i.link_type ? 1 == +i.use_short_link ? wx.navigateToMiniProgram({
                  shortLink: i.short_link,
                  fail() {
                    Object(p.a)(K)
                  }
                }) : wx.navigateToMiniProgram({
                  appId: i.other_weapp_appid,
                  path: i.other_weapp_link,
                  fail() {
                    Object(p.a)(K)
                  }
                }) : f(r) ? R.switchTab(r) : T() ? function(e) {
                  void 0 === e && (e = {}), (getCurrentPages() || []).length >= 10 ? this.redirect(e) : wx.navigateTo(e)
                }({
                  url: r
                }) : C({
                  url: r
                })
              }
            }
          },
          switchToCart(e) {
            var t = e.split("?")[0],
              a = {
                store_id: _.getOfflineId() || 0,
                supportReviveGroup: !0,
                supportCombo: !0
              };
            a.excludedComboSubType = JSON.stringify([""]), Object(y.c)({
              navigatePath: t,
              navigateCb: t => {
                Object(I.f)({
                  url: e,
                  type: T() ? I.a.NAVIGATE : I.a.REDIRECT,
                  pageType: I.b.CART,
                  query: {
                    prefetchKey: t
                  }
                })
              },
              prefetchCb: () => Object(n.z)() ? Promise.reject("进总部不走预请求") : new Promise((e, t) => {
                Object(b.default)({
                  data: a,
                  path: "/wsctrade/cartGoodstList.json",
                  method: "GET"
                }).then(t => {
                  e(t)
                }).catch(e => {
                  t(e)
                })
              })
            });
            var i = "trade-cart-addon-prefetchkey_" + Date.now();
            Object(k.d)("trade-cart-addon-prefetchkey", i), Object(y.a)({
              prefetchKey: i,
              prefetchCb: () => Object(n.z)() ? Promise.reject("进总部不走预请求") : _.request({
                path: "/wsctrade/cart/getCouponAddOnInfo.json",
                method: "GET",
                data: {
                  kdt_id: _.getKdtId() || 0,
                  store_id: _.getOfflineId() || 0
                },
                withCredentials: !0
              })
            })
          },
          setRetailGlobalData(e) {
            var t = e.match(/mode=(\d*)/);
            t && t[1] && (_.globalData.shelfParams = {
              mode: t[1]
            })
          },
          switchToRetailShelf(e, t) {
            var {
              pagePath: a,
              extra: r
            } = e[t];
            return x.a.trigger("retail-shelf:switch-tab", Object(i.a)({}, r, {
              switchType: "tab-click"
            })), Object(A.b)(e, {
              path: a,
              query: r,
              fail: () => {
                this.switchTab(t)
              }
            })
          }
        },
        ud: !0
      };
    t.default = O.default.component(U)
  }
}));