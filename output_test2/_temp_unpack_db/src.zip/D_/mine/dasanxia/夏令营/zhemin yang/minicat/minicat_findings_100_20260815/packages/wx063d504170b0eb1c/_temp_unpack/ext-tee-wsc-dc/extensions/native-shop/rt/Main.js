var r = require("~/r");
r("TS5w", Object.assign({}, require("~/v.js").modules, {
  TS5w: function(a, t, e) {
    e.r(t);
    var i = e("YeA1"),
      s = getApp(),
      {
        isRetailApp: r
      } = s.globalData,
      o = {
        data: () => ({
          navigationBarConfigData: void 0,
          alias: "",
          isRetailApp: r,
          buyerAddress: "",
          showShopBar: !1
        }),
        created() {
          Object(i.b)(this, ["navigationBarConfigData", "alias"]), Object(i.b)(this, ["shopConfig"], {
            callback: (a, t) => {
              Object.keys(t).length > 1 && (this.showShopBar = !0)
            }
          })
        },
        mounted() {
          this.buyerAddress = s.getUserInfoSync("poi.title") || ""
        },
        ud: !0
      },
      n = e("9ZMt");
    t.default = n.default.component(o)
  }
}));