var r = require("~/r");
r("2TFr", Object.assign({}, require("../c.js").modules, require("~/v.js").modules, require("~/c.js").modules, {
  "+3Fe": function(t, e) {},
  "+Y/m": function(t, e) {},
  "/n46": function(t, e) {},
  "/vm6": function(t, e) {},
  "0D0K": function(t, e) {},
  "0Hvf": function(t, e) {},
  "0glB": function(t, e) {},
  "0guW": function(t, e) {},
  "1DqH": function(t, e) {},
  "1JO1": function(t, e) {},
  "1gXJ": function(t, e) {},
  "1m8I": function(t, e) {},
  "2TFr": function(t, e, a) {
    a.r(e);
    a("SKHs"), a("m2V3")
  },
  "2m3T": function(t, e) {},
  "2pjk": function(t, e) {},
  "3lAQ": function(t, e) {},
  "3v4F": function(t, e) {},
  "4KEG": function(t, e) {},
  "4lf9": function(t, e) {},
  "4oC7": function(t, e) {},
  "53GB": function(t, e) {},
  "54i4": function(t, e) {},
  "6U3b": function(t, e) {},
  "6UPt": function(t, e) {},
  "6iAT": function(t, e) {},
  "72JW": function(t, e) {},
  "87nt": function(t, e) {},
  "8Cq2": function(t, e) {},
  "8S+i": function(t, e) {},
  "8aq0": function(t, e) {},
  "8p7p": function(t, e) {},
  "9CdD": function(t, e) {},
  "9Gof": function(t, e) {},
  "9ME7": function(t, e) {},
  "9NdL": function(t, e, a) {
    a.d(e, "a", function() {
      return p
    });
    var o = a("54i4"),
      n = a.n(o),
      s = a("cSsH"),
      i = a.n(s),
      c = a("6UPt"),
      r = a.n(c),
      u = a("Rb7n"),
      d = a.n(u),
      h = a("72JW"),
      f = a.n(h),
      l = a("zhN1"),
      g = a.n(l);
    class p {
      constructor(t) {
        this.ctx = t.ctx
      }
    }
    p.widgets = {
      OrderPopExtra: n.a,
      OrderBlock: i.a,
      SkuOrderContactInfo: r.a,
      SkuOrderPayBtn: d.a,
      SkuOrderInfo: f.a,
      SkuOrderPopup: g.a
    }, p.lambdas = {
      getHashQuery: () => {}
    }
  },
  "9U4V": function(t, e) {},
  ABDU: function(t, e) {},
  AYC7: function(t, e) {},
  "Ah+4": function(t, e) {},
  BfBv: function(t, e) {},
  CCwj: function(t, e) {},
  COAg: function(t, e) {},
  D2e6: function(t, e) {},
  D6vh: function(t, e) {},
  DBeL: function(t, e) {},
  DIbs: function(t, e) {},
  DLGB: function(t, e) {},
  DR7t: function(t, e) {},
  DvSL: function(t, e) {},
  EW05: function(t, e) {},
  EYwr: function(t, e) {},
  EZpN: function(t, e) {},
  EsfN: function(t, e) {},
  F0jR: function(t, e) {},
  Ffv9: function(t, e) {},
  FsgN: function(t, e) {},
  GZxp: function(t, e) {},
  HwgD: function(t, e) {},
  HyEJ: function(t, e) {},
  I6uD: function(t, e) {},
  I7xJ: function(t, e) {},
  "IPo+": function(t, e) {},
  IgI9: function(t, e) {},
  IiIR: function(t, e) {},
  J0aM: function(t, e) {},
  "K0L/": function(t, e) {},
  Kkvk: function(t, e) {},
  L63X: function(t, e) {},
  LY43: function(t, e) {},
  LniI: function(t, e) {},
  LsN0: function(t, e) {},
  ML4D: function(t, e) {},
  MbRR: function(t, e) {},
  MytQ: function(t, e) {},
  "O/Fb": function(t, e) {},
  OU5B: function(t, e) {},
  OhE7: function(t, e) {},
  OxQY: function(t, e) {},
  P5cb: function(t, e) {},
  PE14: function(t, e) {},
  Qcor: function(t, e) {},
  Qqcz: function(t, e) {},
  R0f8: function(t, e) {},
  RL9e: function(t, e) {},
  RNop: function(t, e) {},
  Rb7n: function(t, e) {},
  RmQ0: function(t, e) {},
  SlE4: function(t, e) {},
  Tk54: function(t, e) {},
  "U3++": function(t, e) {},
  USra: function(t, e) {},
  Uv3o: function(t, e) {},
  UzbL: function(t, e) {},
  VAno: function(t, e) {},
  VT8o: function(t, e) {},
  XALw: function(t, e) {},
  XKO5: function(t, e, a) {
    function o(t) {
      return /^\d+$/.test("" + t)
    }

    function n(t) {
      var e, {
          share_from: a,
          card_type: n,
          img_ps: s
        } = t || {},
        [i, c] = (e = decodeURIComponent(s || "")) && "string" == typeof e ? e.split("|").map(t => t.split(",").filter(t => o(t)).map(t => +t)) : [];
      return {
        share_from: a,
        card_type: o(n) ? +n : void 0,
        img_process_types: i,
        img_process_sub_types: c
      }
    }
    a.d(e, "b", function() {
      return o
    }), a.d(e, "a", function() {
      return n
    })
  },
  XM9b: function(t, e) {},
  XWEF: function(t, e) {},
  XWk2: function(t, e) {},
  "YW/I": function(t, e, a) {
    a.d(e, "a", function() {
      return b
    });
    var o = a("Fcif"),
      n = a("w2Y9"),
      s = a.n(n),
      i = a("mQXz"),
      c = a.n(i),
      r = a("KDJo"),
      u = a("2m3T"),
      d = a.n(u),
      h = a("4KEG"),
      f = a.n(h),
      l = a("U3++"),
      g = a.n(l),
      p = a("XKO5"),
      m = a("wGFT");
    class b {
      constructor(t) {
        this.ctx = t.ctx
      }
      onShareAppMessage() {
        var {
          shareData: t,
          shopMetaInfo: e
        } = this.ctx.data, {
          id: a
        } = this.ctx.data.goods || {}, n = t.path, i = n;
        if (n.startsWith("/pages/common/blank-page")) i = s.a.get("weappSharePath", n);
        else if (n.startsWith("undefined")) {
          var {
            getQuery: u,
            route: d
          } = this.ctx.env, h = n.replace("undefined", d), f = u();
          this.ctx.data.shareData.path = s.a.add(h, c()(f, ["access_token", "app_id", "prefetchKey"]))
        } else this.ctx.data.shareData.path = n;
        this.ctx.logger.log({
          et: "click",
          ei: "goods_share_result",
          en: "分享结果回调",
          si: "",
          params: {
            pagePath: i,
            sharePath: this.ctx.data.shareData.path
          }
        });
        var l = s.a.getAll(i);
        return this.ctx.logger.log({
          et: "view",
          ei: "goods_share_trigger_view",
          en: "商品详情分享触发",
          pt: "g",
          pi: a,
          params: Object(o.a)({}, Object(p.a)(l), {
            goods_id: a
          })
        }), Object(r.c)(e) && Object(m.a)(a), this.ctx.data.shareData
      }
      onShareTimeline() {
        var {
          shareData: t
        } = this.ctx.data, e = t.path.slice(t.path.indexOf("?") + 1);
        return Object(o.a)({}, t, {
          query: e
        })
      }
    }
    b.widgets = {
      SharePop: f(),
      ActionItem: g(),
      Widget: d()
    }
  },
  YtP4: function(t, e) {},
  Z63Q: function(t, e) {},
  aN2w: function(t, e) {},
  axMY: function(t, e) {},
  b1kB: function(t, e) {},
  bHr6: function(t, e) {},
  byaO: function(t, e) {},
  cSsH: function(t, e) {},
  "cTa+": function(t, e) {},
  "cY/0": function(t, e) {},
  ceIk: function(t, e) {},
  cxMM: function(t, e) {},
  dIXK: function(t, e) {},
  dLoJ: function(t, e) {},
  dhKv: function(t, e) {},
  dvJh: function(t, e) {},
  fSch: function(t, e) {},
  flvQ: function(t, e) {},
  flx1: function(t, e) {},
  gKWa: function(t, e) {},
  gf3M: function(t, e) {},
  h9FP: function(t, e) {},
  hRw3: function(t, e) {},
  iJeB: function(t, e) {},
  iNgw: function(t, e) {},
  "iT+G": function(t, e) {},
  izeG: function(t, e) {},
  jCRx: function(t, e) {},
  jPV2: function(t, e) {},
  jPXZ: function(t, e) {},
  jS7c: function(t, e) {},
  jWfv: function(t, e) {},
  jYdQ: function(t, e) {},
  kMQg: function(t, e) {},
  kR5P: function(t, e) {},
  kh7f: function(t, e) {},
  lOCs: function(t, e) {},
  lrt9: function(t, e) {},
  n0bX: function(t, e) {},
  "nSh/": function(t, e) {},
  nqUG: function(t, e) {},
  oWIT: function(t, e) {},
  p1RP: function(t, e) {},
  "pR+k": function(t, e) {},
  rPml: function(t, e) {},
  rQPx: function(t, e) {},
  rrZC: function(t, e) {},
  s3lA: function(t, e) {},
  sEE4: function(t, e) {},
  scXe: function(t, e) {},
  sglO: function(t, e) {},
  slkn: function(t, e) {},
  ubH4: function(t, e) {},
  ucHI: function(t, e) {},
  "ucz/": function(t, e) {},
  vMjE: function(t, e) {},
  vOVc: function(t, e) {},
  vVPF: function(t, e, a) {
    a.d(e, "a", function() {
      return s
    });
    var o = a("I7xJ"),
      n = a.n(o);
    class s {
      constructor(t) {
        this.ctx = t.ctx
      }
    }
    s.widgets = {
      Main: n()
    }
  },
  vXaX: function(t, e) {},
  vmqh: function(t, e) {},
  wHg8: function(t, e) {},
  xgC2: function(t, e, a) {
    a.d(e, "a", function() {
      return W
    });
    var o = a("Fcif"),
      n = a("+I+c"),
      s = a("VmCB"),
      i = a("dsC0"),
      c = a("X3j9"),
      r = a("gKCo"),
      u = a("KhBQ"),
      d = a("GUWE"),
      h = a("NHEX"),
      f = a.n(h),
      l = a("9ZMt"),
      g = a("US/N"),
      p = a("lgMb"),
      m = a("YeA1"),
      b = a("882d"),
      O = a("TO+A"),
      v = a("BwoW"),
      D = a("BrFj"),
      S = a("DLzb"),
      I = a("noo5"),
      j = a("Zf9w"),
      C = a("Shdd"),
      _ = a("VmHG"),
      x = t => ({
        setUnInit(t) {
          this.unInit = t
        },
        initStaticPage() {
          this.setPointsConfig()
        },
        setUserInfo() {
          t.lambdas.getUserInfo && t.lambdas.getUserInfo().then(t => {
            this.setCtxData({
              userInfo: t,
              buyerId: t.buyerId
            })
          })
        },
        setCtxData(e, a) {
          var o = this.unInit ? this.ctxDataObj : t.data;
          a ? o[a] = e : Object.assign(o, e)
        },
        getCtxData(e) {
          var a = this.unInit ? this.ctxDataObj : t.data;
          return e ? a[e] : a
        }
      }),
      y = a("RSyW"),
      P = a("31OO"),
      k = [y.a, P.a].reduce((t, e) => Object(C.c)(t, e), {}),
      G = {
        unInit: !1,
        ctxDataObj: {}
      };
    var w = a("Q4pQ"),
      R = a("1nOt"),
      E = a("qTUJ"),
      T = a("zjWU"),
      M = ["unHandleError"],
      L = null,
      A = getApp(),
      {
        prefetchCache: B = {}
      } = A || {},
      U = Object.values(B),
      N = Object.keys(B) || "",
      F = U.length;
    if (F && 1 === F && N.includes("GoodsDetail")) {
      var Q = U[0];
      try {
        Q.value.then(t => {
          t && t.goodsData && (L = t)
        })
      } catch (t) {}
    }
    class W {
      constructor(t) {
        var e;
        this.ctx = t.ctx, this.store = (e = this.ctx, Object(_.a)({
          state: () => Object(o.a)({}, G, k.state),
          getters: Object(o.a)({}, k.getters),
          actions: Object(o.a)({}, x(e), k.getActions(e))
        })), this.store.setUnInit(t.unInit), this.init(t.unInit), this.initCloudData()
      }
      onPageHide() {
        setTimeout(() => {
          T.a.end({
            isPageHide: !0
          })
        })
      }
      beforePageCreate() {
        var {
          ctx: t
        } = this;
        t.logger.setPageAsyncLog(), this.getQuery().then(e => {
          var {
            wecom_chat_id: a
          } = e;
          a && t.logger.setContext({
            wecom_chat_id: a
          });
          var {
            slg: o = ""
          } = e;
          Object(S.a)(t, o)
        })
      }
      pageDestroyed() {
        this.clearGlobal()
      }
      setCtxData(t, e) {
        return this.store.setCtxData(t, e)
      }
      getCtxData(t) {
        return this.store.getCtxData(t)
      }
      initOid() {
        Object(m.b)(this, {
          oid: (t => {
            var e = t;
            return t => {
              var a = +t;
              a && a !== e && this.load({
                oid: a
              }), e = a
            }
          })(this.getOfflineId())
        })
      }
      init(t) {
        if (void 0 === t && (t = !1), this._state = {
            query: {},
            oid: 0,
            staticData: {},
            asyncGoodsData: {},
            goodsSkuData: {
              goods: null
            },
            goodsData: {},
            userGoodsStateParams: {},
            isPageScrolled: !1
          }, l.default.setGlobal("GOODS_BIZ_COMPONENTS", null), Object(b.a)(), this.initOid(), Object(_.c)(this, ["shopConfig", "alias", "kdtId", "query", "goodsBaseInfo"]), Object(m.e)(this, {
            getGoodsDetail: t => {
              var {
                unHandleError: e
              } = t, a = Object(n.a)(t, M);
              return this.getGoodsDetail(a, e).then(() => this.getCtxData())
            }
          }), !t) {
          Object(u.c)() || T.a.start({
            name: T.b.goods_detail,
            timeout: 10
          });
          try {
            L && (this.setInitGoodsData(L), L = null)
          } catch (t) {
            var e = t || {},
              a = e.message || e.msg || "商品数据处理异常";
            T.a.end({
              name: T.b.goods_detail,
              level: "error",
              extra: {
                message: a
              }
            })
          }
          Object(m.d)(this, {
            "page-container:scrollLocked": t => {
              this._state.isPageScrolled = !!t
            }
          }), Object(m.e)(this, {
            setShareIcon: t => this.store.setUmpShareIcon(t),
            updateCartCount: () => this.updateCartCount()
          }), this.load().then(t => {
            this.__isPrefetched && !this.__isPrefetchReloaded && (this.__isPrefetchReloaded = !0, this.load()), this.ctx.event.emit("goodsSetupInit", t)
          }).catch(t => {
            var e = "";
            if ("string" == typeof t) e = t;
            else {
              var {
                message: a,
                msg: o,
                data: n = {}
              } = t || {};
              e = a || o || n.msg || "获取商品数据接口失败"
            }
            T.a.end({
              name: T.b.goods_detail,
              level: "error",
              extra: {
                message: e
              }
            })
          })
        }
      }
      setInitGoodsData(t) {
        this._state.staticData = t;
        var e = Object(s.a)(this._state, t.shopConfig);
        this._state.goodsSkuData = e;
        var a = Object(r.a)(t, e),
          {
            title: n,
            pictures: i = []
          } = a.goodsBaseInfo;
        return this.setCtxData(Object(o.a)({}, a, {
          navigationText: n,
          cpsConfigKey: "cps_goods_recommend_goods_detail"
        })), Object(R.a)(a.shopConfig), 0 !== i.length && i || T.a.end({
          name: T.b.goods_detail,
          type: "finish",
          extra: {
            message: "商品主图为空"
          }
        }), this.setGlobal(a), t
      }
      getQuery() {
        return this.__getQueryPromise || (this.__getQueryPromise = this.ctx.env.getQueryAsync().then(t => (t = Object(E.a)(t), this._state.query = t, this.setCtxData(t, "query"), t))), Promise.resolve(this.__getQueryPromise)
      }
      setGlobal(t, e) {
        void 0 === e && (e = "GOODS_DATA"), l.default.setGlobal(e, Object(o.a)({}, l.default.getGlobal(e), t))
      }
      clearGlobal(t) {
        void 0 === t && (t = "GOODS_DATA"), l.default.setGlobal(t, null)
      }
      load(t) {
        this.store.setUserInfo();
        var {
          oid: e = this.getOfflineId()
        } = t || {};
        return this.getQuery().then(t => Object(o.a)({}, t, {
          oid: e
        })).then(t => this.getGoodsDetail(t).then(t => (this.updateCartCount(), this.prefetchDetailComponents(this.getCtxData()), t))).catch(t => {
          throw "string" == typeof t && wx.showToast({
            title: t,
            icon: "none"
          }), t
        })
      }
      getGoodsDetail(t, e) {
        void 0 === e && (e = !1);
        var {
          ctx: a
        } = this, n = Object(o.a)({}, t);
        "helpcut" === n.type && (n.activityType = "helpCut");
        var {
          alias: s
        } = t;
        if (!s || "undefined" === s || "null" === s) return Promise.reject("商品不存在");
        var {
          scene: i
        } = l.default.getAppOptions();
        return 1154 === i && this.setCtxData(s, "alias"), n.scene = i, Object(u.b)(a, s), Promise.all([Object(d.a)(a, t), Object(u.a)(a, n)]).then(t => {
          var [e, a] = t;
          this.__isPrefetched = a.__isPrefetched, this.clearGlobal();
          var o = a;
          return o = this.formatWeappStaticParams(o, e)
        }).then(t => {
          t = this.setInitGoodsData(t), a.inited(), this.store.initStaticPage();
          var {
            shopMetaInfo: {
              isChainStore: e
            },
            pageFeature: o,
            marketing: n
          } = t;
          return e ? Object(d.c)(a, t) : t
        }).then(t => {
          try {
            return this.processUserGoodsStateData(t)
          } catch (t) {
            throw t.message = "[商详页初始化-processUserGoodsStateData] " + t.message, t.isClientError = !0, a.hummer && a.hummer.capture(t), t
          }
        }).then(e => (this.setGlobal(e), this.updateLocationAsync(e), a.event.emit("goodsSetupReady"), A.trigger("goods-detail:page-skeleton:visible", !1), a.hummer && a.hummer.markRendered("goods-page-setup:ready"), Object(w.a)(t), e)).catch(a => e ? Promise.reject(a) : Object(v.a)(a, t, () => {
          this.getGoodsDetail(t)
        })).then(t => (this.parseWeappDataAfter(t), this.getStockRemindStatus(t), this.getRetailInfo(t), this.fetchSkuDirectOrder(t, n), this.setGlobal(t), t)).catch(a => e ? Promise.reject(a) : (a.data = a.data || {}, a.data.showError = !1, Object(v.a)(a, t, () => {
          this.getGoodsDetail(t)
        })))
      }
      processUserGoodsStateData(t) {
        void 0 === t && (t = {}), this._state.userGoodsStateParams = t.userGoodsStateParams, this._state.asyncGoodsData = t, this._state.serverStatus = this.getServerStatus(t);
        var e = Object(r.b)(this._state),
          {
            buyConfig: a,
            goodsActivity: n,
            goodsSkuData: s,
            goodsPriceInfo: c,
            serverStatus: d,
            pageFeature: h
          } = e,
          f = Object(o.a)({}, this.getCtxData("goodsMetaInfo"), e.goodsMetaInfo),
          {
            supportItemProps: l,
            showStockLackReminder: g
          } = f;
        g && s && s.goods && (s.goods.disableSoldoutSku = !1);
        var p = Object(o.a)({}, t, e),
          {
            userGoodsStateParams: m,
            ump: b,
            marketing: O
          } = t,
          v = {
            marketing: O,
            activity: n,
            sku: s,
            priceInfo: c,
            buyConfig: a,
            serverStatus: d,
            pageFeature: h,
            supportItemProps: l,
            buyLimitGuideInfo: t.buyLimitGuideInfo,
            userGoodsStateParams: m,
            ump: b
          },
          D = this.store.parseMemeberActivies(v),
          S = this.store.parseUmpActivies(D);
        f.showStockLackReminder && S.sku && S.sku.goods && (S.sku.goods.disableSoldoutSku = !1);
        var I = (t.itemExtendInfo || {}).SKU_DECISION,
          j = Object(o.a)({}, e, {
            goodsSkuData: S.sku,
            goodsPriceInfo: S.priceInfo,
            goodsMetaInfo: Object(o.a)({}, f, this.getCtxData("goodsMetaInfo"), {
              supportItemProps: S.supportItemProps
            }),
            multiSkuDecision: !I || I.ignoreItem ? {} : I,
            goodsCombineInfo: Object(i.f)(t.goodsData),
            wholesalerModel: p.wholesalerModel,
            voucherModelList: (t.goodsData || {}).voucherModelList || [],
            userGoodsStateParams: m,
            pageParams: p.pageParams
          });
        return this.setGlobal(Object(o.a)({}, D, S)), this.setCtxData(j), this.ctx.data.hasFinishLoad = !this.__isPrefetched || this.__isPrefetchReloaded, Object(u.c)() || setTimeout(() => Object(u.d)(this.getCtxData()), 5e3), Promise.resolve(p)
      }
      updateCartCount() {
        var {
          shopConfig: t = {},
          pageSwitch: e = {}
        } = this.getCtxData();
        return +t.hideShoppingCart || !e["cart-count"] ? Promise.reject() : (this.__updateCartCount || (this.__updateCartCount = this.ctx.process.invokePipe("beforeRefreshCartCount").then(t => void 0 !== t ? t : Object(D.b)()).then(t => (this.setGlobal({
          cartCount: t
        }), this.ctx.data.cartCount = t, this.__updateCartCount = null, t)).catch(t => {
          throw this.__updateCartCount = null, t
        })), this.__updateCartCount)
      }
      updateLocationAsync(t) {
        var {
          offlineData: e,
          pageFeature: a,
          goodsData: n,
          physicalStores: s
        } = t;
        if (e.id) e.needGetLocation = !0, Object(d.a)(this.ctx, e).then(t => {
          var {
            lat: o,
            lng: s
          } = t, {
            lng: i,
            lat: r
          } = e.address || {}, u = {
            distance: Object(I.calculateDistance)(r, i, o, s),
            lng: s,
            lat: o
          };
          (a.showMultiStoreRecommend ? Object(D.h)({
            currentStoreId: e.id,
            lng: s,
            lat: o,
            goodsId: n.goods.id,
            kdtId: +n.kdtId
          }) : Promise.resolve([])).then(t => {
            var a = this.getCtxData("multistore") || {};
            Object.assign(a, Object(c.a)(e, {
              geoLocationData: u,
              salableStores: t
            }), {
              asyncGetLocationFinished: !0
            }), this.setCtxData(a, "multistore")
          })
        });
        else if (s && s.shopCount > 0) {
          e.needGetLocation = !0;
          Object(d.a)(this.ctx, e).then(t => {
            var {
              lat: e,
              lng: a
            } = t;
            return new Promise(t => {
              var n;
              Object(D.a)().then(s => {
                n = s ? s.isNewTemplate ? s : JSON.parse(s.components)[0] || JSON.parse(s.components) : {
                  showType: 0
                }, t(Object(o.a)({
                  lat: e,
                  lng: a
                }, n))
              }).catch(s => {
                n = {
                  showType: 1
                }, t(Object(o.a)({
                  lat: e,
                  lng: a
                }, n))
              })
            })
          }).then(t => {
            var {
              lat: e,
              lng: a,
              showType: n
            } = t;
            Object(D.g)({
              showType: n,
              lon: a,
              lat: e,
              storeName: "",
              toBd: !0
            }).then(t => {
              var {
                items: e
              } = t, a = e[0] || {}, n = this.getCtxData("physicalStores");
              n.physicalStoreBasicInfoModels.length && (Object.assign(n.physicalStoreBasicInfoModels[0], {
                physicalStoreName: a.storeName,
                physicalStoreAddress: a.storeAddress,
                distance: a.distance
              }), this.setCtxData({
                physicalStores: Object(o.a)({}, n)
              }))
            })
          })
        }
      }
      fetchSkuDirectOrder(t, e) {
        var {
          goodsExtendInfo: a
        } = t;
        if (Object.values(a).some(t => "SKU_DIRECT_ORDER" === t.type && t.baseSupportSkuDirectOrder)) {
          var o = f()(t, "goodsData.goods.alias"),
            {
              isGoodsWeappNative: n,
              scene: s,
              TRADE_MODULE_ORDER: i,
              from_source: c
            } = e,
            r = {
              alias: o,
              isGoodsWeappNative: n,
              scene: s,
              from_source: c,
              TRADE_MODULE_ORDER: i
            };
          Object(D.f)(r).then(t => {
            var {
              userStateSupportSkuDirectOrder: e = !1
            } = t;
            this.setCtxData(e, "userStateSupportSkuDirectOrder"), this.ctx.process.invokePipe("updateSupportSkuDirectOrder", {
              alias: o,
              isSkuDirectOrder: e
            }), e && this.ctx.process.invokePipe("updateBtnsUI")
          })
        } else this.setCtxData(!1, "userStateSupportSkuDirectOrder")
      }
      getOfflineId() {
        var t = this.getCtxData("oid") || 0,
          {
            query: e = {}
          } = this._state;
        return +t || +e.oid || 0
      }
      getServerStatus(t) {
        var e = +new Date,
          {
            serverTimestamp: a = e
          } = t;
        return {
          fetchSuccess: !0,
          serverDeltaTime: a - e,
          clientTimestamp: e,
          serverTimestamp: a
        }
      }
      getStockRemindStatus(t) {
        var {
          goods: {
            id: e
          },
          skuInfo: {
            skuStocks: a
          }
        } = t.goodsData, {
          showStockLackReminder: n
        } = this.getCtxData("goodsMetaInfo");
        if (n) {
          var s = {
              itemId: e,
              remindTypeEnum: "ITEM_STOCK_REMIND"
            },
            i = [];
          a && a.length > 0 && (i = a.filter(t => 0 === t.stockNum).map(t => t.skuId), s.skuIds = i.join(",")), Object(g.requestV2)({
            method: "POST",
            path: "/wscgoods/hasSaleReminderByBatch.json",
            data: s,
            withCredentials: !0
          }).then(t => {
            var e = {};
            a && a.length > 0 ? i.length > 0 && t.forEach((t, a) => {
              e[i[a]] = t
            }) : e.hasRemindSpuStock = t, this.setCtxData(Object(o.a)({}, this.getCtxData("goodsMetaInfo"), {
              stockRemindStatus: e
            }), "goodsMetaInfo"), this.ctx.process.invokePipe("updateBtnsUI")
          }).catch(t => {
            Object(p.b)(t, {
              message: "获取补货提醒状态失败，请稍后重试"
            })
          })
        }
      }
      prefetchDetailComponents(t) {
        var {
          goodsBaseInfo: e,
          shopBaseInfo: a,
          env: o
        } = t, {
          platform: n,
          isDangerous: s
        } = o;
        if (a.kdtId && e.alias && void 0 !== n) {
          var i = {
              alias: e.alias,
              isFastBuy: f()(e, "fastbuyFeature.isFastBuy", void 0),
              platform: n,
              danger: Number(s),
              bizName: "itemDetail",
              queryKeys: "alias,platform",
              stage: 100,
              teeEnv: l.default.getEnv()
            },
            c = Object(D.c)(i);
          l.default.setGlobal("GOODS_BIZ_COMPONENTS", c)
        }
      }
      onPullDownRefresh() {
        this._state.isPageScrolled || this.load().then(() => {
          Object(O.b)()
        }).catch(() => {
          Object(O.b)()
        })
      }
      getRetailInfo(t) {
        var e = f()(t, "goodsData.goods.alias");
        7 === f()(t, "goodsData.shop.shopType") && Object(D.e)(e).then(t => {
          if (t.length > 0) {
            var e = t[0];
            this.setCtxData({
              show: e.stock_num > 0,
              address: e.address
            }, "retail")
          }
        })
      }
      getPlatform(t) {
        this.ctx.lambdas.getPlatform && this.ctx.lambdas.getPlatform().then(e => {
          t.platform = e
        })
      }
      formatWeappStaticParams(t, e) {
        var {
          lng: a,
          lat: o
        } = e;
        this.getPlatform(t);
        var {
          lng: n,
          lat: s
        } = t.offlineAddress || {}, i = Object(I.calculateDistance)(s, n, o, a);
        return t.geoLocationData = {
          distance: i,
          lng: a,
          lat: o
        }, t.userGoodsStateParams = Object(d.b)(t, {
          lng: a,
          lat: o
        }), t
      }
      parseWeappDataAfter(t) {
        var e = f()(t, "goodsData.goods.id"),
          a = f()(t, "goodsData.goods.title"),
          n = f()(t, "goodsEnterPageParams", {});
        Object(u.c)() || this.ctx.logger.setPageInitConfig({
          pageType: "g",
          pageId: e,
          title: a,
          eventParams: Object(o.a)({}, n, {
            goods_id: e
          })
        }), setTimeout(() => this.logLive(t), 2e3)
      }
      logLive(t) {
        var {
          room_id: e,
          roomId: a
        } = this._state.query, {
          goodsData: o = {},
          shopMetaInfo: n = {}
        } = t, {
          alias: s
        } = o, {
          isChainStore: i,
          kdtId: c,
          rootKdtId: r
        } = n, u = e || a;
        if (u && s) return Object(g.default)({
          path: "/wscshop/mplive/collect.json",
          withCredentials: !0,
          data: {
            alias: s,
            kdtId: i ? r : c,
            roomId: u
          }
        })
      }
      initCloudData() {}
    }
    W.lambdas = {
      checkFromChannelsOpenFlow: j.c,
      checkFromShowcase: j.d,
      checkIsChannels: j.e,
      checkIsHalfScreen: j.g,
      checkIsNeedSyncOrderScene: j.h,
      checkIsOpenByLiveBag: j.i,
      checkIsOpenByLiveGoodsShare: j.j,
      checkIsWxvideoLive: j.l
    }
  },
  y9px: function(t, e) {},
  "yd+z": function(t, e) {},
  ygrD: function(t, e, a) {
    a.d(e, "a", function() {
      return s
    });
    var o = a("K0L/"),
      n = a.n(o);
    class s {
      constructor(t) {
        this.ctx = t.ctx, this.initCloudData()
      }
      initCloudData() {}
    }
    s.widgets = {
      Main: n()
    }
  },
  ythx: function(t, e) {},
  zdHw: function(t, e) {},
  zhN1: function(t, e) {}
}));