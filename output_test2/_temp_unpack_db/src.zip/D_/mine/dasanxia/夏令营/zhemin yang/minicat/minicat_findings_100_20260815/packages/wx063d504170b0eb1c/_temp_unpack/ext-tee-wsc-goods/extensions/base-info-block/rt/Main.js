var r = require("~/r");
r("o5Ko", Object.assign({}, require("~/v.js").modules, require("~/c.js").modules, {
  o5Ko: function(e, t, i) {
    i.r(t);
    var o = i("Fcif"),
      s = i("YeA1"),
      r = i("VmHG"),
      n = i("9ZMt"),
      a = i("KEq0"),
      c = i.n(a),
      u = i("ONqW"),
      d = i("Zf9w"),
      h = i("+66q"),
      p = i("lCVF"),
      m = i.n(p),
      l = 0,
      g = 1;
    var v = "benefitcard",
      f = "discount",
      y = {
        getters: {
          recommendedPriceModel() {
            var {
              discountInvite: e,
              discount: t
            } = this.memberActivity;
            return e ? e.recommendedPriceModel || {} : t && t.recommendedPriceModel || {}
          },
          discountOpt() {
            var {
              discountInvite: e,
              discount: t,
              goods: i
            } = this.goodsSkuData, {
              isHqShopPreview: o = !1,
              kdtId: s
            } = this.shopBaseInfo, r = !!this.memberActivity.scrmCarrier, {
              recommendedPriceModel: n
            } = this, a = function(e) {
              var {
                recommendedPriceModel: t,
                recommendedActivity: i
              } = e, {
                recommendedBenefitNum: o,
                recommendedMax: s,
                recommendedMin: r,
                cardName: n,
                cardType: a,
                cardSubType: c,
                cardCouponType: u,
                cardDenominationsCouponTotalAmount: d
              } = t, {
                isAllVipPriceAdvantage: h,
                maxVipSavedPrice: p,
                noneSku: v,
                price: f,
                oldPrice: y
              } = i || {};
              if (void 0 === o) return {
                mainText: "会员价: ￥" + m()({
                  min: r,
                  max: s
                }, " - "),
                actionText: "加入会员"
              };
              var w = 2 === a && 1001 === c,
                I = w ? "加入会员" : "立即省钱",
                P = w ? "加入会员" : "立即尊享",
                A = v && r === s && r < f,
                O = {
                  mainText: "加入会员后，可享" + m()(y - r) + "元优惠",
                  actionText: I
                },
                b = {
                  mainText: "加入会员后，最多享" + m()(p) + "元优惠",
                  actionText: I
                };
              if (A) return O;
              if (h) return b;
              if (u !== l) {
                var B = "入会送优惠券";
                return u === g && (B = "入会立得" + m()(d) + "元优惠券"), {
                  mainText: B,
                  actionText: "加入会员"
                }
              }
              var S = n || "会员";
              return 0 == +o ? {
                mainText: S + "尊享专属权益",
                actionText: P
              } : {
                mainText: S + "可享" + (o || "几") + "大权益",
                actionText: P
              }
            }({
              recommendedPriceModel: n,
              recommendedActivity: e || t || i
            }), c = !(!n.recommendedStatus || o || this.isNewcomerCoupon || r || !a), {
              mainText: u = "",
              actionText: d = ""
            } = a, h = {
              supportFastJoin: 1001 === n.cardSubType,
              fastJoin: this.launchFastJoin
            };
            return {
              show: c,
              kdtId: s,
              recommendedPriceModel: n,
              mobile: this.userInfo.mobile,
              mainText: u,
              extraAction: h,
              actionText: d,
              type: f
            }
          },
          benefitcardOpt() {
            var {
              scrmCarrier: e = {}
            } = this.memberActivity, {
              cardAlias: t = "",
              cardName: i = "",
              benefitDesc: o = ""
            } = e;
            return {
              show: !!t,
              kdtId: this.shopBaseInfo.kdtId,
              mainText: o,
              actionText: "立即激活",
              cardAlias: t,
              cardName: i,
              type: v
            }
          },
          customerCardOpt() {
            var {
              show: e
            } = this.benefitcardOpt;
            return e ? this.benefitcardOpt : this.discountOpt
          }
        }
      },
      w = i("US/N"),
      I = i("X9+V"),
      P = i("3tyi"),
      A = {
        timelimitedDiscount: {
          pending: !1,
          doing: !1
        },
        seckill: {
          pending: !1,
          doing: !0
        },
        groupOn: {
          pending: !1,
          doing: !1
        },
        ladderGroupOn: {
          pending: !1,
          doing: !1
        },
        depositExpansion: {
          pending: !1,
          doing: !1
        },
        helpDepositExpansion: {
          pending: !1,
          doing: !1
        },
        helpCut: {
          pending: !1,
          doing: !1
        },
        tuan: {
          pending: !1,
          doing: !1
        },
        luckyDrawGroup: {
          pending: !1,
          doing: !1
        },
        auction: {
          pending: !0,
          doing: !0
        },
        inSourcingFission: {
          pending: !1,
          doing: !1
        },
        presale: {
          pending: !1,
          doing: !1
        }
      },
      O = i("Nvad"),
      b = e => {
        var {
          umpPriceInfo: t,
          currentActivity: i,
          isDeposit: o,
          isAuction: s
        } = e, {
          minPrice: r = 0,
          maxPrice: n = 0,
          tags: a = [],
          originMinPrice: c = 0,
          originMaxPrice: u = 0,
          oldMinPrice: d = 0,
          oldMaxPrice: p = 0
        } = t, {
          originPrice: m = ""
        } = t, {
          startPrice: l
        } = t, g = a[0] || {}; - 1 !== m.indexOf("-") && (m = m.split("-")[0] + " 起");
        var v = Object(O.b)(Object(I.a)(r)).split("."),
          f = r !== n;
        if (o) {
          var y = c || d,
            w = u || p;
          v = Object(O.b)(Object(I.a)(y)).split("."), f = y !== w
        }
        if ((i || {}).type === h.a.PRESALE && (g = {}), g.text && g.preText) {
          g.text = Object(O.b)(g.text);
          var P = (v[0] || "").length;
          P <= 2 ? (g.tagPreCls = "tag_pre-normal", g.tagCls = "tag_normal") : 3 === P ? (g.tagPreCls = "tag_pre-small", g.tagCls = "tag_normal") : 4 === P ? (g.tagPreCls = "tag_pre-small", g.tagCls = "tag_small") : P >= 5 && (g.tagPreCls = "tag_pre-small", g.tagCls = "tag_mini"), g.tagCls += " tag_price_font"
        }
        return {
          priceTag: g,
          isRange: f,
          preText: "价格",
          showPrice: v,
          originPrice: Object(O.b)(s ? Object(I.a)(l) : m)
        }
      },
      B = e => {
        var {
          isDeposit: t,
          currentActivity: i,
          price: o,
          minPrice: s
        } = e;
        if (!t) return "";
        var r = (null == i ? void 0 : i.type) || "",
          n = "定金 ￥" + o + " 可抵",
          a = "定金 ￥" + o + " 最多可抵";
        if (r === h.a.PRESALE) {
          var {
            showDepositRange: c = !0
          } = i || {};
          return "定金 ￥" + (c ? o : Object(I.a)(s))
        }
        if (r === h.a.HELP_DEPOSIT_EXPANSION) return a + " ￥" + i.maxOfferWithoutSku / 100;
        var {
          spuPrice: u = {},
          skuPrices: d = []
        } = i;
        if (d.length > 0) {
          var p = -1 / 0,
            m = 1 / 0;
          d.forEach(e => {
            p = Math.max(p, e.depositOffer), m = Math.min(m, e.depositOffer)
          });
          var l = "￥" + p / 100;
          return p === m ? n + " " + l : a + " " + l
        }
        var {
          depositOffer: g
        } = u;
        return n + " ￥" + g / 100
      },
      S = {
        getState: () => {
          var {
            kdtId: e,
            alias: t,
            goodsBaseInfo: i = {},
            umpActivityData: {
              umpActivity: o = {},
              currentActivity: s = {}
            } = {}
          } = n.default.getGlobal("GOODS_DATA") || {};
          return {
            kdtId: e,
            alias: t,
            goodsBaseInfo: i,
            currentActivity: s,
            umpActivity: o,
            fansBenefit: null,
            wecomFansBenefit: null,
            buyButtonPop: {},
            isNewcomerCoupon: !1,
            showOriginPrice: !0,
            showCountDownTime: !0,
            hasReady: !1,
            couponValue: "",
            couponUnit: "元",
            couponId: 0,
            couponAlias: ""
          }
        },
        getters: {
          goodsFansBenefitOpt() {
            var {
              alias: e
            } = this.goodsBaseInfo;
            return {
              show: !(!this.fansBenefit && !this.wecomFansBenefit || this.isNewcomerCoupon),
              fansBenefit: this.fansBenefit,
              wecomFansBenefit: this.wecomFansBenefit,
              kdtId: this.kdtId,
              alias: e,
              isNewcomerCoupon: this.isNewcomerCoupon
            }
          },
          goodsNewCustomerCouponOpt() {
            return {
              show: this.isNewcomerCoupon && "" !== this.couponValue,
              showPriceBlock: this.priceInfo.showPriceBlock,
              kdtId: this.kdtId,
              value: this.couponValue,
              unit: this.couponUnit,
              couponId: this.couponId,
              couponAlias: this.couponAlias
            }
          },
          umpBannerOpt() {
            var e, t, {
                subType: i,
                type: o
              } = this.currentActivity,
              s = i || o,
              {
                showPriceBlock: r = !0
              } = this.priceInfo,
              {
                price: n,
                minPrice: a
              } = this.goodsPriceInfo,
              c = this.hasReady && !r,
              u = c ? this.currentActivity : this.depositBanner,
              d = u.isStart ? "doing" : "pending",
              p = [h.a.PRESALE, h.a.DEPOSIT_EXPANSION, h.a.HELP_DEPOSIT_EXPANSION].includes(u.type);
            return {
              isDeposit: p,
              currentActivity: u,
              price: n,
              show: c || this.depositBanner.show,
              alias: this.goodsBaseInfo.alias,
              showOriginPrice: this.showOriginPrice,
              showCountDownTime: this.showCountDownTime,
              showStockCountDown: !(null == (e = A[u.type]) || !e[d]),
              umpPriceInfo: this.priceInfo,
              skuData: this.goodsSkuData[s] || {},
              isEstimatePrice: !(null == (t = this.estimatePriceData) || !t.num),
              isCoupon: Object(I.b)({
                umpActivity: this.umpActivity
              }),
              goodsActivity: Object(P.a)(this.goodsActivity, ["presale", "waitToSold"]),
              activityPrice: b({
                umpPriceInfo: this.priceInfo,
                currentActivity: u,
                isDeposit: p,
                isAuction: this.isAuction
              }),
              depositPriceText: B({
                isDeposit: p,
                currentActivity: u,
                price: n,
                minPrice: a
              })
            }
          }
        },
        getActions: e => ({
          setIsNewcomerCoupon(t) {
            void 0 === t && (t = !1), this.isNewcomerCoupon = t, e.data.isNewcomerCoupon = t
          },
          setBuyButtonPop(t) {
            void 0 === t && (t = {}), e.data.buyButtonPop = t
          },
          fetchNewerCoupon(e) {
            var t, {
              umpActivity: i,
              goodsBaseInfo: o
            } = e;
            this.umpActivity = i;
            var {
              coupon: s = {}
            } = i, {
              couponPreferenceModels: r = []
            } = s, n = o.id;
            if (r.length || null != (t = r[0]) && t.isNewcomerVoucher) {
              var {
                isNewcomerVoucher: a,
                valueCopywriting: c,
                unitCopywriting: u,
                id: d,
                alias: h
              } = r[0], p = a && c;
              this.couponValue = c, this.couponUnit = u, this.couponId = d, this.couponAlias = h, this.setIsNewcomerCoupon(p)
            } else this.setUsingNewCustomerCoupon(n)
          },
          setUsingNewCustomerCoupon(t) {
            void 0 === t && (t = this.goodsBaseInfo.id), t && Object(w.default)({
              path: "/wscump/new-customer/optimal-newcomer-voucher.json",
              data: {
                goodsId: t
              }
            }).then(function(t) {
              void 0 === t && (t = {}), t.valueCopywriting && t.unitCopywriting && (e.data.buyButtonPop = t)
            })
          },
          setUmpBannerInfo(e) {
            var {
              currentActivity: t,
              goodsActivity: i
            } = e;
            t.type && (this.hasReady = !0, "productLaunch" === t.type && (this.showOriginPrice = !1, i.waitToSold || (this.showCountDownTime = !1)))
          },
          launchFastJoin(t) {
            e.process.invoke("launchFastJoinSDK", Object(o.a)({}, t, {
              successCallback: () => {
                n.default.$native.startPullDownRefresh()
              }
            }))
          }
        })
      },
      C = ["fullPresale", "deposit"],
      D = {
        priceInfo() {
          var {
            tags: e
          } = this.goodsPriceInfo, {
            type: t,
            isStart: i
          } = this.currentActivity || {}, {
            num: s,
            timeLimitDiscountPromotion: r,
            customDiscountPromotion: n
          } = this.estimatePriceData || {}, a = t === h.k.TIMELIMITED_DISCOUNT && i;
          if (1 === s && !a) {
            e = [this.estimatePriceData.tag];
            var c = !!r,
              d = !!n;
            !this.hasLogger && Object(u.a)().log({
              et: "view",
              ei: "show_hand_price",
              en: "展示到手价",
              params: {
                isshow_qi: e[0].sufText ? 1 : 0,
                is_activity: c ? 0 : d ? 1 : "",
                component: "estimated_price"
              }
            }), this.hasLogger = !0
          }
          return Object(o.a)({}, this.goodsBaseInfo.firstRenderPriceInfo || {}, this.goodsPriceInfo, {
            tags: e
          })
        },
        priceOpt() {
          var {
            origin: e,
            alias: t
          } = this.goodsBaseInfo, {
            presale: i
          } = this.goodsActivity, s = Object(o.a)({}, this.priceInfo, {
            origin: e
          }), r = (e => {
            var {
              tags: t = []
            } = e;
            return t.filter(e => !("coupon" !== e.umpType && C.indexOf(e.type) > -1))
          })(s), n = (e => {
            var {
              origin: t,
              price: i,
              oldPrice: o
            } = e;
            return o && o !== i ? {
              label: "价格",
              price: "￥" + o
            } : /^\s*\d+(\.\d{1,2})?\s*$/.test(t) ? {
              label: "价格",
              price: "￥" + t.trim()
            } : {
              label: "",
              price: t
            }
          })(s);
          return {
            show: s.showPriceBlock && !s.showBanner,
            priceInfo: s,
            alias: t,
            isDeposit: null == i ? void 0 : i.isDeposit,
            priceTags: r,
            originPriceObj: n
          }
        },
        presaleOpt() {
          var {
            presale: e
          } = this.goodsActivity;
          return {
            show: !!e,
            presale: e
          }
        },
        titleOpt() {
          var e, t, i, {
              id: s,
              alias: r,
              title: n,
              isHaitao: a,
              isMedicine: c,
              isPrescriptionCategory: u,
              sellPoint: d,
              brandInfoModel: h
            } = this.goodsBaseInfo,
            {
              haitao: p,
              periodbuy: m,
              enjoyBuy: l
            } = this.goodsActivity;
          return {
            goodsId: s,
            alias: r,
            title: n,
            isHaitao: a,
            isMedicine: c,
            isPrescriptionCategory: u,
            sellPoint: d,
            brandInfoModel: h,
            retailShow: null == (e = this.retail) ? void 0 : e.show,
            goodsActivity: {
              haitao: p,
              periodbuy: m,
              enjoyBuy: l
            },
            shareIcon: Object(o.a)({}, this.shareIcon, {
              show: !(null != (t = this.env) && t.hideShareIcon) && (null == (i = this.shareIcon) ? void 0 : i.show)
            })
          }
        },
        depositBanner() {
          var {
            showPriceBlock: e,
            showBanner: t
          } = this.goodsPriceInfo, {
            isEnd: i,
            preSaleEnd: o,
            preSaleStart: s
          } = this.goodsActivity.presale || {}, r = s - Date.now() <= 0;
          return {
            show: e && t,
            startTimeAt: s,
            endTimeAt: r ? o : s,
            isEnd: i,
            isStart: r,
            type: "presale",
            countDownDesc: i ? "活动已结束" : r ? "距结束仅剩" : "距开始仅剩",
            showDepositRange: !1
          }
        },
        skuPictures() {
          var {
            tree: e = []
          } = this.goodsSkuData.goods || {}, {
            picture: t
          } = this.goodsBaseInfo, i = [];
          return e.forEach(e => {
            e.v && i.push(...e.v.filter(e => !!e.imgUrl).map(i => Object(o.a)({}, i, {
              url: i.defaultSkuImg ? t : i.imgUrl,
              ks: e.kS,
              kId: e.kId
            })))
          }), i
        },
        skuNavOpt() {
          var {
            isDisplaySkuPicture: e,
            pictures: t,
            video: i
          } = this.goodsBaseInfo, o = t || [], {
            videoUrl: s,
            coverUrl: r
          } = i || {}, n = s ? r : (o[0] || {}).url, a = s ? 1 : 0, u = c()(n, "small"), d = a + o.length;
          return {
            show: e,
            skuPictures: this.skuPictures,
            pictureLength: d,
            goodsPic: u,
            current: e ? this.current : 1
          }
        }
      },
      k = e => ({
        getShareIcon() {
          e.process.invokePipe("setShareIcon", this.shareIcon).then(e => {
            this.shareIcon = function(e) {
              if (Object(d.g)()) return Object(o.a)({}, e, {
                show: !1
              });
              return e
            }(e)
          })
        },
        setShareIconShow(e) {
          this.shareIcon.show = e
        }
      });

    function T(e) {
      return Object(r.a)({
        state: () => Object(o.a)({}, (() => {
          var {
            themeVars: e = "",
            themeColors: t = {},
            goodsActivity: i = {},
            goodsBaseInfo: o = {},
            goodsPriceInfo: s = {},
            goodsSkuData: r = {},
            shopBaseInfo: a = {},
            memberActivity: c = {},
            themeTag: u = {},
            env: d = {},
            retail: h = {},
            umpActivityData: {
              currentActivity: p = {},
              umpActivity: m = {}
            } = {}
          } = n.default.getGlobal("GOODS_DATA") || {};
          return {
            themeVars: e,
            themeColors: t,
            pageVars: "",
            themeTag: u,
            current: 0,
            goodsActivity: i,
            goodsBaseInfo: o,
            goodsPriceInfo: s,
            retail: h,
            env: d,
            goodsSkuData: r,
            isNewcomerCoupon: !1,
            memberActivity: c,
            currentActivity: p,
            umpActivity: m,
            userInfo: {},
            shopBaseInfo: a,
            shareIcon: {
              show: !0,
              icon: "share",
              color: "#323233",
              size: "20px",
              word: "分享"
            },
            estimatePriceData: null
          }
        })(), S.getState()),
        getters: Object(o.a)({}, D, y.getters, S.getters),
        actions: Object(o.a)({}, k(e), S.getActions(e))
      })
    }
    var x = {
      data() {
        return this.store = T(this.ctx), Object(r.c)(this, ["current", "env", "goodsBaseInfo", "themeTag", "pageVars", "themeVars", "retail", "goodsActivity", "goodsSkuData", "goodsPriceInfo", "memberActivity", "isNewcomerCoupon", "userInfo", "shopBaseInfo", "fansBenefit", "wecomFansBenefit", "kdtId", "alias", "themeColors", "buyButtonPop", "currentActivity", "umpActivity", "estimatePriceData"]), Object(o.a)({
          profit: 0,
          showGuaranteeBar: !0,
          youzanyunBanner: !0,
          youzanyunPrice: !0
        }, Object(r.d)(this, ["skuNavOpt", "priceOpt", "presaleOpt", "titleOpt", "pageVars", "themeVars", "customerCardOpt", "goodsFansBenefitOpt", "goodsNewCustomerCouponOpt", "umpBannerOpt", "themeTag"]))
      },
      logicData() {
        return Object(o.a)({}, Object(r.d)(this, ["skuPictures", "currentActivity", "umpActivity", "goodsBaseInfo"]))
      },
      computed: {
        theme() {
          return this.pageVars + this.themeVars
        }
      },
      watch: {
        skuPictures: {
          handler() {
            this.ctx.data.skuPictures = this.skuPictures
          },
          immediate: !0
        }
      },
      created() {
        Object(r.b)(this, ["getShareIcon", "setIsNewcomerCoupon", "setBuyButtonPop", "fetchNewerCoupon"]), Object(s.d)(this, {
          goodsSetupReady: () => this.getShareIcon()
        }), Object(s.e)(this, {
          setShowGuaranteeBar: e => {
            this.showGuaranteeBar = !!e
          },
          showActivityBanner: e => {
            this.youzanyunBanner = !!e
          },
          showPriceBlock: e => {
            this.youzanyunPrice = !!e
          },
          showShareIcon: e => {
            this.store.setShareIconShow(!!e)
          }
        }), Object(s.c)(this, ["currentActivity", "goodsActivity"], {
          callback: e => this.store.setUmpBannerInfo(e)
        }), Object(s.c)(this, ["umpActivity", "goodsBaseInfo"], {
          callback: e => {
            var {
              umpActivity: t,
              goodsBaseInfo: i
            } = e;
            this.fetchNewerCoupon({
              umpActivity: t,
              goodsBaseInfo: i
            })
          }
        }), Object(s.c)(this, ["salesmanShareData", "goodsBaseInfo", "goodsPriceInfo"], {
          callback: e => {
            var {
              salesmanShareData: t = {},
              goodsBaseInfo: i,
              goodsPriceInfo: o
            } = e, {
              isShoppingGuide: s = !1
            } = t, {
              id: r
            } = i, {
              minPrice: n = 0
            } = o;
            s && r && (e => Object(w.default)({
              path: "/guide/goods/batchBudgetCommission.json",
              method: "POST",
              data: e
            }))({
              budgetGoods: [{
                goodsId: r,
                minPrice: n
              }]
            }).then(e => {
              this.profit = e && m()(e)
            })
          }
        }), this.store.setUmpBannerInfo({
          currentActivity: this.currentActivity,
          goodsActivity: this.goodsActivity
        }), this.fetchNewerCoupon({
          umpActivity: this.umpActivity,
          goodsBaseInfo: this.goodsBaseInfo
        }), this.setBuyButtonPop(), this.setIsNewcomerCoupon()
      },
      methods: {
        onNavUpdate(e) {
          this.ctx.event.emit("nav:update", e)
        },
        setShareShow() {
          this.ctx.event.emit("share:show")
        },
        setFollowShow(e) {
          this.ctx.event.emit("follow:show", e)
        },
        setWecomBenefitShow(e) {
          this.ctx.event.emit("wecomBenefit:show", e)
        }
      }
    };
    t.default = n.default.component(x)
  }
}));