Page({
  data: {
    isPool: !1,
    isShowPool: !1,
    sex: 1,
    sexs: ["是", "否"],
    imgs: []
  },
  bindSexChange: function(e) {
    this.setData({
      sex: e.detail.value
    })
  },
  chooseImg: function(e) {
    var t = this;
    this.data.imgs;
    wx.chooseImage({
      count: 3,
      sizeType: ["original", "compressed"],
      sourceType: ["album", "camera"],
      success: function(e) {
        for (var a = e.tempFilePaths, n = t.data.imgs, s = 0; s < a.length; s++) {
          if (n.length >= 3) return t.setData({
            imgs: n
          }), !1;
          n.push(a[s])
        }
        t.setData({
          imgs: n
        })
      }
    })
  },
  deleteImg: function(e) {
    var t = this.data.imgs,
      a = e.currentTarget.dataset.index;
    t.splice(a, 1), this.setData({
      imgs: t
    })
  },
  previewImg: function(e) {
    var t = e.currentTarget.dataset.index,
      a = this.data.imgs;
    wx.previewImage({
      current: a[t],
      urls: a
    })
  },
  onLoad: function(e) {
    1 == wx.getStorageSync("resumeInfo").basic.archivHouse && this.setData({
      isPool: !1
    })
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {}
});