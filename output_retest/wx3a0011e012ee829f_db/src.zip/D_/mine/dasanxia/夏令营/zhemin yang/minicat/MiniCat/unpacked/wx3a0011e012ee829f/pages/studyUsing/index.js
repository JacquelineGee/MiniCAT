Page({
  data: {
    title: "",
    tec: "",
    help: "",
    weiquan: ""
  },
  onLoad: function(t) {
    "技术支持" == t.title ? this.setData({
      tec: !0,
      title: t.title
    }) : "使用教程" == t.title ? this.setData({
      help: !0,
      title: t.title
    }) : "咨询维权" == t.title && this.setData({
      weiquan: !0,
      title: t.title
    }), wx.setNavigationBarTitle({
      title: this.data.title
    })
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {},
  back_index: function() {
    wx.switchTab({
      url: "../index/index"
    })
  }
});