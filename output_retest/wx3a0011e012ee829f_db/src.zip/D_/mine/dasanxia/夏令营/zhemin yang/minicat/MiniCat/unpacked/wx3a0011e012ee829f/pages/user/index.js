var e = require("../../@babel/runtime/helpers/defineProperty"),
  t = getApp();
Page({
  data: {
    hasUserInfo: !1,
    userInfo: {
      realName: "",
      head: "",
      age: "",
      bgEdu: "",
      seniority: ""
    },
    headicon: "",
    isShow: !1,
    canIUse: wx.canIUse("button.open-type.getUserInfo"),
    show: !1,
    buttons: [{
      type: "default",
      className: "",
      text: "取消",
      value: 0
    }, {
      type: "primary",
      className: "",
      text: "允许",
      value: 1
    }],
    choosebtn: "",
    statusHeight: 0,
    shareMask: !1,
    cardInfo: {},
    tempFilePath: "",
    pointInfo: {},
    showBtn: !1,
    scrollTop: 0,
    phoneInfo: {},
    mobel: ""
  },
  onLoad: function(e) {
    var t = wx.getSystemInfoSync().statusBarHeight;
    this.setData({
      statusHeight: t
    }), wx.showShareMenu({
      withShareTicket: !0,
      menus: ["shareAppMessage", "shareTimeline"]
    })
  },
  loginout: function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1;
    try {
      wx.removeStorageSync("openid"), wx.removeStorageSync("session_key"), wx.removeStorageSync("userInfo"), wx.removeStorageSync("resumeInfo"), wx.clearStorageSync();
      var t = "退出";
      2 == e && (t = "清除缓存"), wx.showToast({
        title: t + "成功!",
        icon: "success",
        duration: 2e3
      }), wx.reLaunch({
        url: "/pages/index/index"
      })
    } catch (e) {
      wx.showToast({
        title: tips_txt + "失败，请稍后重试!",
        icon: "none",
        duration: 2e3
      })
    }
  },
  onReady: function() {},
  onShow: function() {
    var o = this,
      a = wx.getStorageSync("openid"),
      n = this;
    a && (t.yzapi.getUserInfo(a).then((function(e) {
      200 == e.code ? (wx.setStorageSync("resumeInfo", e.data), o.setData({
        isShow: !0
      })) : wx.setStorageSync("resumeInfo", {})
    })), t.yzapi.getMineInfo(a).then((function(t) {
      if (200 == t.code) o.setData({
        hasUserInfo: !0,
        userInfo: t.data
      });
      else {
        var a, i = wx.getStorageSync("userInfo");
        if (i) n.setData((e(a = {
          hasUserInfo: !0
        }, "userInfo.realName", i.nickName), e(a, "userInfo.head", i.avatarUrl), e(a, "userInfo.gender", i.gender), a))
      }
    }))), wx.getStorage({
      key: "openid",
      success: function(e) {
        e.data && wx.getStorage({
          key: "userInfo",
          success: function(e) {
            n.data.headicon = e.data.avatarUrl, n.setData({
              headicon: n.data.headicon
            })
          }
        })
      }
    }), t.yzapi.getMyPoint().then((function(e) {
      o.setData({
        pointInfo: e.data
      })
    }));
    var i = wx.getStorageSync("scene"),
      s = "";
    t.yzapi.getCard(i).then((function(e) {
      s = e.data, o.setData({
        cardInfo: s
      })
    }))
  },
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function(e) {
    if ("button" === e.from) return console.log(e.target, e), {
      title: "青年赣州小程序",
      imageUrl: this.data.tempFilePath
    }
  },
  open: function() {
    this.testLogin();
    var e = this;
    wx.getUserProfile({
      desc: "申请获取信息",
      success: function(t) {
        var o = t.userInfo;
        wx.showLoading({
          title: "登录中..."
        }), o ? (wx.setStorageSync("userInfo", o), e.setData({
          hasUserInfo: !0,
          userInfo: o
        }), wx.hideLoading(), wx.showToast({
          title: "登录成功!",
          icon: "success",
          duration: 2e3
        }), e.onShow()) : wx.showToast({
          title: "用户未授权登录!",
          icon: "none",
          duration: 2e3
        })
      },
      fail: function(e) {
        console.log("获取失败: ", e)
      }
    })
  },
  preventTouchMove: function() {},
  out: function() {
    this.setData({
      shareMask: !1
    })
  },
  openShare: function() {
    wx.getStorageSync("openid") ? (this.setData({
      shareMask: !0
    }), this.initCanvas()) : wx.showToast({
      title: "请先登录",
      icon: "none"
    })
  },
  initCanvas: function() {
    var e = this,
      t = wx.getStorageSync("resumeInfo"),
      o = this.data.userInfo,
      a = {},
      n = {};
    this.data.cardInfo ? a = this.data.cardInfo : (a.totalServiceTime = 1, a.totalPoints = 0, a.shareCode = "../../images/QR.jpg"), null != t && "" != t && null != t ? (n.head = t.basic.head, n.name = t.basic.realName) : (n.head = o.avatarUrl, n.name = o.nickName), wx.createSelectorQuery().select("#myCanvas").fields({
      node: !0,
      size: !0
    }).exec((function(t) {
      var i = t[0].node,
        s = i.getContext("2d"),
        c = wx.getSystemInfoSync().pixelRatio;
      i.width = t[0].width * c, i.height = t[0].height * c;
      var r = i.createImage();
      r.src = "https://flyplan.obs.cn-north-4.myhuaweicloud.com/wechat/static/images/user_pop1.png", r.onload = function() {
        s.drawImage(r, 0, 0, i.width, i.height);
        var t = i.createImage();
        t.src = n.head, t.onload = function() {
          e.circle(s, t, .063 * i.width, .136 * i.width, .063 * i.width);
          var c = i.createImage();
          c.src = "../../images/user/grade_icon.png", c.onload = function() {
            s.drawImage(c, .13 * i.width, .2 * i.width, .08 * i.width, .08 * i.width), s.font = "".concat(.047 * i.width, "px Arail"), s.fillStyle = "#fff", s.fillText(n.name, .207 * i.width, .22 * i.width), s.fillText(o.level, .185 * i.width, .27 * i.width);
            var t = i.createImage();
            t.src = a.shareCode, t.onload = function() {
              s.font = "".concat(.063 * i.width, "px Arail"), s.fillText((a.totalServiceTime ? a.totalServiceTime : 0) + "h", .257 * i.width, .378 * i.width), s.fillText(a.totalPoints ? a.totalPoints : 0, .657 * i.width, .378 * i.width), s.drawImage(t, .063 * i.width, .648 * i.width, .158 * i.width, .158 * i.width), wx.canvasToTempFilePath({
                canvas: i,
                success: function(t) {
                  e.setData({
                    tempFilePath: t.tempFilePath,
                    showBtn: !0
                  })
                },
                fail: function(e) {
                  console.log(e)
                }
              })
            }
          }
        }
      }
    }))
  },
  circle: function(e, t, o, a, n) {
    e.save();
    var i = 2 * n,
      s = o + n,
      c = a + n;
    e.arc(s, c, n, 0, 2 * Math.PI), e.clip(), e.drawImage(t, o, a, i, i), e.restore()
  },
  shareSave: function() {
    "" != this.data.tempFilePath && wx.saveImageToPhotosAlbum({
      filePath: this.data.tempFilePath,
      success: function(e) {
        wx.showModal({
          content: "图片已保存到相册，赶紧晒一下吧~",
          showCancel: !1,
          confirmText: "好的",
          confirmColor: "#333",
          success: function(e) {
            e.confirm && console.log("用户点击确定")
          },
          fail: function(e) {
            console.log(11111)
          }
        })
      }
    })
  },
  onPageScroll: function(e) {
    var t = e.scrollTop;
    t >= 65 ? this.setData({
      scrollTop: t - 65
    }) : this.setData({
      scrollTop: 0
    })
  },
  getWetchatMobile: function() {
    var e = this,
      o = wx.getStorageSync("phoneInfo"),
      a = wx.getStorageSync("openid"),
      n = wx.getStorageSync("session_key");
    wx.checkSession({
      success: function(e) {
        console.log(e)
      }
    }), t.yzapi.getWetchatMobile(n, o.encryptedData, o.iv, a).then((function(t) {
      200 == t.code && (wx.setStorageSync("phoneNumber", t.data.phoneNumber), e.onShow())
    }))
  },
  testLogin: function() {
    wx.login({
      success: function(e) {
        t.yzapi.getOpenId(e.code).then((function(e) {
          wx.setStorageSync("openid", e.data.openid), wx.setStorageSync("session_key", e.data.session_key), console.log(e)
        }))
      }
    })
  },
  getPhoneNumber1: function(e) {
    var o = this,
      a = {
        encryptedData: e.detail.encryptedData,
        iv: e.detail.iv
      };
    wx.setStorageSync("phoneInfo", a);
    var n = wx.getStorageSync("openid"),
      i = wx.getStorageSync("session_key");
    this.getWetchatMobile(), console.log(a), t.yzapi.getWetchatMobile(i, a.encryptedData, a.iv, n).then((function(e) {
      200 == e.code ? wx.setStorageSync("phoneNumber", e.data.phoneNumber) : o.onShow()
    }))
  }
});