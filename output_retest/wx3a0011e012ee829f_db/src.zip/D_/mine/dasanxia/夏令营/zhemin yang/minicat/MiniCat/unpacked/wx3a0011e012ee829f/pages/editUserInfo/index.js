var e = require("../../@babel/runtime/helpers/defineProperty"),
  t = getApp();
Page({
  data: {
    userinfo: {
      realName: "",
      gender: "",
      school: "",
      mobile: "",
      email: "",
      habitation: "赣州",
      birth: "",
      startWorkTime: "",
      head: ""
    },
    eduType: "初中",
    eduTypeCode: 1,
    eduTypes: [],
    sex: 1,
    sexs: ["男", "女"],
    citys: ["1", "2", "3", "4", "5", "6"],
    city: 1,
    date: "2020-06"
  },
  bindname: function(t) {
    this.setData(e({}, "userinfo.realName", t.detail.value))
  },
  bindSexChange: function(t) {
    var a;
    this.setData((e(a = {}, "userinfo.gender", this.data.sexs[t.detail.value]), e(a, "sex", parseInt(t.detail.value) + 1), a))
  },
  bindDateChange: function(t) {
    this.setData(e({}, "userinfo.birth", t.detail.value))
  },
  bindWorkChange: function(t) {
    this.setData(e({}, "userinfo.startWorkTime", t.detail.value))
  },
  bindschool: function(t) {
    this.setData(e({}, "userinfo.school", t.detail.value))
  },
  bindTypeChange: function(e) {
    this.setData({
      eduType: this.data.eduTypes[e.detail.value].value,
      eduTypeCode: this.data.eduTypes[e.detail.value].field
    })
  },
  bindphone: function(t) {
    this.setData(e({}, "userinfo.mobile", t.detail.value))
  },
  bindemail: function(t) {
    this.setData(e({}, "userinfo.email", t.detail.value))
  },
  bindcity: function(t) {
    this.setData(e({}, "userinfo.habitation", t.detail.value))
  },
  onLoad: function(a) {
    var i = this,
      n = new Date,
      o = n.getFullYear(),
      s = n.getMonth() + 1,
      r = o + "-" + (s = 1 == s.toString().length ? "0" + s : s.toString());
    this.setData({
      date: r
    });
    var u = wx.getStorageSync("openid");
    u && t.yzapi.getEduOptions(u).then((function(e) {
      200 == e.code ? i.setData({
        eduTypes: e.data
      }) : wx.showToast({
        title: e.msg,
        icon: "none",
        duration: 2e3
      })
    }));
    var d = wx.getStorageSync("userInfo");
    if (d) {
      var h;
      1 == d.gender ? d.sex = "男" : 2 == d.gender ? d.sex = "女" : d.sex = "未知", this.setData((h = {
        sex: d.gender
      }, e(h, "userinfo.realName", this.data.userinfo.realName), e(h, "userinfo.gender", d.sex), e(h, "userinfo.head", d.avatarUrl), h));
      var l = wx.getStorageSync("resumeInfo");
      if (!t.isEmpty(l)) {
        var f = 1;
        f = "男" == l.basic.gender ? 1 : "女" == l.basic.gender ? 2 : 0;
        for (var c = 1, g = 0; g < this.data.eduTypes.length; g++) this.data.eduTypes[g].value == l.basic.bgEdu && (c = this.data.eduTypes[g].field);
        this.setData({
          sex: f,
          userinfo: l.basic,
          eduType: l.basic.bgEdu,
          eduTypeCode: c
        })
      }
    }
  },
  submitdata: function() {
    if ("" == this.data.userinfo.realName) return wx.showToast({
      title: "请填写真实姓名!",
      icon: "none",
      duration: 2e3
    }), !1;
    if ("" == this.data.userinfo.school) return wx.showToast({
      title: "请填写学校名称!",
      icon: "none",
      duration: 2e3
    }), !1;
    if ("" == this.data.userinfo.birth) return wx.showToast({
      title: "请填写出生年月!",
      icon: "none",
      duration: 2e3
    }), !1;
    if ("" == this.data.userinfo.mobile) return wx.showToast({
      title: "请填写手机号码!",
      icon: "none",
      duration: 2e3
    }), !1;
    if ("" == this.data.userinfo.email) return wx.showToast({
      title: "请填写邮箱!",
      icon: "none",
      duration: 2e3
    }), !1;
    if ("" == this.data.userinfo.habitation) return wx.showToast({
      title: "请填写现居住城市!",
      icon: "none",
      duration: 2e3
    }), !1;
    var e = wx.getStorageSync("openid"),
      a = wx.getStorageSync("userInfo").avatarUrl,
      i = wx.getStorageSync("userInfo").nickName;
    if (!e) return wx.showToast({
      title: "请登录!",
      icon: "none",
      duration: 2e3
    }), !1;
    var n = {
      wechatOpenid: e,
      realName: this.data.userinfo.realName,
      head: a,
      gender: this.data.sex,
      birth: this.data.userinfo.birth,
      startWorkTime: this.data.userinfo.startWorkTime,
      mobile: this.data.userinfo.mobile,
      email: this.data.userinfo.email,
      habitation: this.data.userinfo.habitation,
      school: this.data.userinfo.school,
      bgEducation: this.data.eduTypeCode,
      nickName: i
    };
    t.yzapi.getMyInfo(e, n).then((function(e) {
      if (200 != e.code) return wx.showToast({
        title: e.msg,
        icon: "none",
        duration: 2e3
      }), !1;
      wx.showToast({
        title: "修改成功!",
        icon: "success",
        duration: 2e3
      }), setTimeout((function() {
        wx.navigateBack({
          url: "/pages/resume/index"
        })
      }), 1e3)
    }))
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {}
});