Page({
  data: {
    traget: 2,
    statusBarHeight: 0,
    title: 0
  },
  onLoad: function(t) {
    console.log(t), this.getSysInfo(), this.setData({
      traget: t.target,
      title: t.title ? t.title : 0
    })
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {},
  getSysInfo: function() {
    var t = this;
    wx.getSystemInfo({
      success: function(n) {
        t.setData({
          statusBarHeight: n.statusBarHeight
        })
      }
    })
  },
  navBack: function() {
    wx.navigateBack({
      delta: 0,
      fail: function() {
        wx.reLaunch({
          url: "/pages/index/index"
        })
      }
    })
  },
  navTarget: function() {
    wx.reLaunch({
      url: "/pages/youthJob/index"
    })
  }
});