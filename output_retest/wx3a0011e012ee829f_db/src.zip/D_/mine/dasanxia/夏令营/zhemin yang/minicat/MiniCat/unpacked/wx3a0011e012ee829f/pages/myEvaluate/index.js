var t = require("../../@babel/runtime/helpers/defineProperty"),
  a = getApp();
Page({
  data: {
    currentTab: 0,
    query: {
      currentPage: 1,
      pageSize: 1e3
    },
    query2: {
      currentPage: 1,
      pageSize: 1e3
    },
    reachBottom: {
      loadIs: !1,
      loadMore: !1,
      loadAll: !1
    },
    list: [],
    list2: [],
    content: ""
  },
  clickTab: function(t) {
    t.target.dataset.current;
    if (this.data.currentTab === t.target.dataset.current) return !1;
    this.setData({
      currentTab: t.target.dataset.current
    })
  },
  bindEval: function(t) {
    this.setData({
      content: t.detail.value
    })
  },
  onLoad: function(t) {},
  onReady: function() {},
  onShow: function() {
    this.setData({
      list: [],
      list2: []
    }), this.getMyEvaluationList(), this.getWaitEvaluationList()
  },
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {
    var t = this;
    t.data.reachBottom.loadMore || (t.setData({
      "reachBottom.loadIs": !0,
      "reachBottom.loadMore": !0,
      "reachBottom.loadAll": !1
    }), setTimeout((function() {
      t.onShow()
    }), 2e3))
  },
  onShareAppMessage: function() {},
  submitEvaluate: function(a) {
    var e = a.currentTarget.dataset.index;
    this.setData(t({}, "list2[" + e + "].isShow", !0))
  },
  getMyEvaluationList: function() {
    var t = this,
      e = this;
    1 == this.data.query.currentPage && e.setData({
      "reachBottom.loadMore": !0,
      "reachBottom.loadAll": !1
    });
    var o = e.data.query.currentPage + 1;
    a.yzapi.getMyEvaluationList(this.data.query.currentPage, this.data.query.pageSize).then((function(a) {
      if (200 == a.code) {
        var r = a.data;
        if (r && r.length > 0) {
          var n = e.data.list.concat(r);
          e.setData({
            "query.currentPage": o,
            list: n,
            "reachBottom.loadMore": !1
          }), r.length < t.data.query.pageSize && e.setData({
            "reachBottom.loadMore": !1,
            "reachBottom.loadAll": !0
          })
        } else r && 0 == r.length ? e.setData({
          "reachBottom.loadMore": !1,
          "reachBottom.loadAll": !0
        }) : e.setData({
          "reachBottom.loadMore": !0,
          "reachBottom.loadAll": !1
        })
      } else e.setData({
        "reachBottom.loadMore": !1,
        "reachBottom.loadAll": !1
      })
    }))
  },
  getWaitEvaluationList: function() {
    var t = this,
      e = this.data.query2;
    1 == e.currentPage && t.setData({
      "reachBottom.loadMore": !0,
      "reachBottom.loadAll": !1
    });
    var o = e.currentPage + 1;
    a.yzapi.getWaitEvaluationList(e.currentPage, e.pageSize).then((function(a) {
      if (200 == a.code) {
        var r = a.data;
        if (r && r.length > 0) {
          for (var n = t.data.list2.concat(r), i = 0; i < t.data.list2.length; i++) t.data.list2[i].isShow = !1;
          t.setData({
            "query2.currentPage": o,
            list2: n,
            "reachBottom.loadMore": !1
          }), r.length < e.pageSize && t.setData({
            "reachBottom.loadMore": !1,
            "reachBottom.loadAll": !0
          })
        } else r && 0 == r.length ? t.setData({
          "reachBottom.loadMore": !1,
          "reachBottom.loadAll": !0
        }) : t.setData({
          "reachBottom.loadMore": !0,
          "reachBottom.loadAll": !1
        })
      } else t.setData({
        "reachBottom.loadMore": !1,
        "reachBottom.loadAll": !1
      })
    }))
  },
  toEvaluation: function(t) {
    var e = this,
      o = t.currentTarget.dataset.index,
      r = this.data.list2[o].applyId,
      n = this.data.content;
    "" == n ? wx.showToast({
      title: "评价内容不能为空!",
      icon: "none",
      duration: 2e3
    }) : a.yzapi.toEvaluation(r, n).then((function(t) {
      200 == t.code ? (wx.showToast({
        title: "评价已提交",
        icon: "success",
        duration: 2e3
      }), e.onShow()) : wx.showToast({
        title: t.msg,
        icon: "none",
        duration: 2e3
      })
    }))
  }
});