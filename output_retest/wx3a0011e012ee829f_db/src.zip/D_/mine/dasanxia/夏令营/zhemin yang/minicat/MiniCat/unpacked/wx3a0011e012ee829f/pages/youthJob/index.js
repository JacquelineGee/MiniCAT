var t = require("../../@babel/runtime/helpers/objectSpread2"),
  a = getApp();
Page({
  data: {
    statusBarHeight: 0,
    topSelect: 1,
    addressShow: !1,
    priceShow: !1,
    eduShow: !1,
    maskShow: !1,
    slist: [],
    currentPage: 1,
    pageSize: 10,
    postType: 1,
    area: "",
    jobList: [],
    listLoading: !1,
    listNoMore: !1,
    companyImageList: ["https://flyplan.obs.cn-north-4.myhuaweicloud.com/static/qngz/company/-s-a1.png", "https://flyplan.obs.cn-north-4.myhuaweicloud.com/static/qngz/company/-s-a2.png", "https://flyplan.obs.cn-north-4.myhuaweicloud.com/static/qngz/company/-s-a3.png", "https://flyplan.obs.cn-north-4.myhuaweicloud.com/static/qngz/company/-s-a4.png", "https://flyplan.obs.cn-north-4.myhuaweicloud.com/static/qngz/company/-s-a5.png", "https://flyplan.obs.cn-north-4.myhuaweicloud.com/static/qngz/company/-s-a6.png", "https://flyplan.obs.cn-north-4.myhuaweicloud.com/static/qngz/company/-s-a7.png", "https://flyplan.obs.cn-north-4.myhuaweicloud.com/static/qngz/company/-s-a8.png", "https://flyplan.obs.cn-north-4.myhuaweicloud.com/static/qngz/company/-s-a9.png", "https://flyplan.obs.cn-north-4.myhuaweicloud.com/static/qngz/company/-s-a10.png", "https://flyplan.obs.cn-north-4.myhuaweicloud.com/static/qngz/company/-s-a11.png", "https://flyplan.obs.cn-north-4.myhuaweicloud.com/static/qngz/company/-s-a12.png", "https://flyplan.obs.cn-north-4.myhuaweicloud.com/static/qngz/company/-s-a13.png", "https://flyplan.obs.cn-north-4.myhuaweicloud.com/static/qngz/company/-s-a14.png", "https://flyplan.obs.cn-north-4.myhuaweicloud.com/static/qngz/company/-s-a15.png"]
  },
  onLoad: function(t) {
    this.getsysInfo(), this.getRegion(), this.getRecommendList2()
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {
    this.data.listNoMore || this.getRecommendList2()
  },
  onShareAppMessage: function() {},
  getsysInfo: function() {
    var t = this;
    wx.getSystemInfo({
      success: function(a) {
        t.setData({
          statusBarHeight: a.statusBarHeight
        })
      }
    })
  },
  handleTopSelect: function(t) {
    var a = t.currentTarget.dataset.index;
    this.data.topSelect != a && (this.setData({
      topSelect: a,
      currentPage: 1,
      jobList: [],
      area: "",
      listNoMore: !1
    }), this.getRecommendList2(), this.handleCancleMask())
  },
  selectAddress: function() {
    this.setData({
      addressShow: !this.data.addressShow,
      maskShow: !this.data.addressShow,
      eduShow: !1,
      priceShow: !1
    })
  },
  handleDefault: function() {},
  handleCancleMask: function() {
    this.setData({
      maskShow: !1,
      addressShow: !1,
      eduShow: !1,
      priceShow: !1
    })
  },
  handleSelect: function(t) {
    var a = t.currentTarget.dataset.index;
    2 == a ? this.setData({
      priceShow: !this.data.priceShow,
      eduShow: !1,
      maskShow: !this.data.priceShow,
      addressShow: !1
    }) : 3 == a && this.setData({
      priceShow: !1,
      eduShow: !this.data.eduShow,
      maskShow: !this.data.eduShow,
      addressShow: !1
    })
  },
  navBack: function() {
    wx.navigateBack({
      delta: 0,
      fail: function() {
        wx.reLaunch({
          url: "/pages/index/index"
        })
      }
    })
  },
  getRegion: function() {
    var t = this;
    a.yzapi.getCommonJobOptions().then((function(a) {
      200 == a.code && t.setData({
        slist: a.data.region
      })
    }))
  },
  handleItem: function(t) {
    var a = t.currentTarget.dataset.name;
    this.setData({
      area: a,
      currentPage: 1,
      jobList: [],
      listNoMore: !1
    }), this.getRecommendList2(), this.handleCancleMask()
  },
  getRecommendList2: function() {
    var o = this,
      e = this;
    1 == this.data.currentPage && e.setData({
      "reachBottom.loadMore": !0,
      "reachBottom.loadAll": !1
    }), this.setData({
      listLoading: !0
    });
    var n = e.data.currentPage + 1,
      s = {
        currentPage: this.data.currentPage,
        pageSize: this.data.pageSize,
        area: this.data.area,
        postType: this.data.topSelect
      };
    a.yzapi.getRecommendList2(s).then((function(a) {
      if (200 == a.code) {
        var s = a.data.data.map((function(a) {
          return t(t({}, a), {}, {
            images: [o.data.companyImageList[parseInt(15 * Math.random() + 0)], o.data.companyImageList[parseInt(15 * Math.random() + 0)], o.data.companyImageList[parseInt(15 * Math.random() + 0)]]
          })
        }));
        if (s && s.length > 0) {
          var c = e.data.jobList.concat(s);
          e.setData({
            currentPage: n,
            jobList: c,
            "reachBottom.loadMore": !1
          }), s.length < o.data.pageSize && e.setData({
            "reachBottom.loadMore": !1,
            "reachBottom.loadAll": !0
          })
        } else s && 0 == s.length ? e.setData({
          "reachBottom.loadMore": !1,
          "reachBottom.loadAll": !0
        }) : e.setData({
          "reachBottom.loadMore": !0,
          "reachBottom.loadAll": !1
        });
        e.data.jobList.length >= a.data.page.totalCounts && e.setData({
          listNoMore: !0
        })
      } else e.setData({
        "reachBottom.loadMore": !1,
        "reachBottom.loadAll": !1
      }), e.setData({
        listNoMore: !0
      });
      o.setData({
        listLoading: !1
      })
    }))
  }
});