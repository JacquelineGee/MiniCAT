Page({
  data: {
    statusBarHeight: 0,
    select: 1,
    topSelect: 1
  },
  onLoad: function(t) {
    this.getSysInfo()
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {},
  navBack: function() {
    wx.navigateBack({
      delta: 0,
      fail: function() {
        wx.reLaunch({
          url: "/pages/index/index"
        })
      }
    })
  },
  getSysInfo: function() {
    var t = this;
    wx.getSystemInfo({
      success: function(n) {
        t.setData({
          statusBarHeight: n.statusBarHeight
        })
      }
    })
  },
  handleSelect: function(t) {
    var n = t.currentTarget.dataset.index;
    this.setData({
      select: n
    })
  },
  handleTopSelect: function(t) {
    var n = t.currentTarget.dataset.index;
    this.setData({
      topSelect: n
    })
  }
});