var e, t = require("../../../../@babel/runtime/helpers/defineProperty"),
  a = getApp(),
  i = require("../../../../utils/dateTimePicker");
Page((t(e = {
  data: {
    deliveryitem: {},
    isDeliveryShow: !1,
    status: "",
    startTime: "",
    endDate: "",
    date: "2018-10-01",
    time: "12:00",
    dateTimeArray: null,
    dateTime: null,
    dateTimeArray1: null,
    dateTime1: null,
    startYear: (new Date).getFullYear(),
    endYear: 2050,
    idCard: ""
  },
  onLoad: function(e) {
    var t = this;
    this.getData(), this.gettime(), null != e.status && this.setData({
      isDeliveryShow: !0,
      status: e.status
    });
    var i = e.name,
      n = e.id;
    a.yzapi.getOfferDetail(n).then((function(e) {
      console.log(e), t.setData({
        deliveryitem: e.data
      })
    }));
    wx.getStorageSync("openid");
    wx.setNavigationBarTitle({
      title: i
    })
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {},
  bindDateChange: function(e) {
    console.log(11), console.log(e.detail.value), this.setData({
      startTime: e.detail.value
    })
  },
  clickDeliveryShow: function() {
    this.setData({
      isDeliveryShow: !0
    })
  },
  clickDeliveryNone: function() {
    this.setData({
      isDeliveryShow: !1
    })
  },
  getData: function() {
    var e = Date.parse(new Date);
    e /= 1e3;
    var t = new Date(1e3 * e),
      a = t.getFullYear(),
      i = t.getMonth() + 1 < 10 ? "0" + (t.getMonth() + 1) : t.getMonth() + 1;
    t.getDate(), t.getDate(), t.getHours(), t.getMinutes(), t.getSeconds();
    this.setData({
      endDate: a + "-" + i
    })
  },
  gettime: function() {
    var e = i.dateTimePicker(this.data.startYear, this.data.endYear),
      t = i.dateTimePicker(this.data.startYear, this.data.endYear);
    t.dateTimeArray.pop(), t.dateTimeArray.pop(), t.dateTimeArray.pop();
    t.dateTime.pop();
    this.setData({
      dateTime: e.dateTime,
      dateTimeArray: e.dateTimeArray,
      dateTimeArray1: t.dateTimeArray,
      dateTime1: t.dateTime
    })
  },
  changeDate: function(e) {
    this.setData({
      date: e.detail.value
    })
  },
  changeTime: function(e) {
    this.setData({
      time: e.detail.value
    })
  },
  changeDateTime: function(e) {
    this.setData({
      dateTime: e.detail.value
    })
  },
  changeDateTime1: function(e) {
    console.log(22), console.log(e.detail.value), this.setData({
      startTime: e.detail.value
    })
  }
}, "bindDateChange", (function(e) {
  this.setData({
    startTime: e.detail.value
  })
})), t(e, "changeDateTimeColumn", (function(e) {
  var t = this.data.dateTime,
    a = this.data.dateTimeArray;
  t[e.detail.column] = e.detail.value, a[2] = i.getMonthDay(a[0][t[0]], a[1][t[1]]), this.setData({
    dateTimeArray: a,
    dateTime: t
  })
})), t(e, "changeDateTimeColumn1", (function(e) {
  var t = this.data.dateTime1,
    a = this.data.dateTimeArray1;
  t[e.detail.column] = e.detail.value, a[2] = i.getMonthDay(a[0][t[0]], a[1][t[1]]), this.setData({
    dateTimeArray1: a,
    dateTime1: t
  })
})), t(e, "unaccept", (function() {
  var e = this,
    t = {
      applyId: this.data.deliveryitem.offer.applyId,
      state: 8,
      idCard: "",
      arrivalTime: ""
    };
  a.yzapi.acceptStatus(t.applyId, t.state, t.idCard, t.arrivalTime).then((function(t) {
    200 == t.code ? (e.setData({
      isDeliveryShow: !1
    }), wx.navigateTo({
      url: "../myoffer",
      success: function(e) {},
      fail: function(e) {},
      complete: function(e) {}
    })) : wx.showToast({
      title: t.msg,
      icon: "none",
      duration: 2e3
    })
  }))
})), t(e, "accept", (function() {
  var e = this,
    t = {
      applyId: this.data.deliveryitem.offer.applyId,
      state: 6,
      idCard: this.data.idCard,
      arrivalTime: this.data.startTime
    };
  console.log(this.data.startTime), a.yzapi.acceptStatus(t.applyId, t.state, t.idCard, t.arrivalTime).then((function(t) {
    200 == t.code ? (e.setData({
      isDeliveryShow: !1
    }), wx.navigateTo({
      url: "../myoffer",
      success: function(e) {},
      fail: function(e) {},
      complete: function(e) {}
    })) : wx.showToast({
      title: t.msg,
      icon: "none",
      duration: 2e3
    })
  }))
})), t(e, "addcard", (function(e) {
  console.log(e.detail.value), this.setData({
    idCard: e.detail.value
  })
})), t(e, "acceptoffer", (function() {
  this.setData({
    isDeliveryShow: !0
  })
})), t(e, "unacceptoffer", (function() {
  this.setData({
    status: 2,
    isDeliveryShow: !0
  })
})), e));