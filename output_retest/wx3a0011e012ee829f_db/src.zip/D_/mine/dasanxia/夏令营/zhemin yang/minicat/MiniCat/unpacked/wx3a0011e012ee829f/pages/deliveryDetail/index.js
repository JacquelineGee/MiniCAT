var n = getApp();
Page({
  data: {
    deliveryitem: {}
  },
  onLoad: function(o) {
    var t = this,
      e = o.id,
      a = wx.getStorageSync("openid");
    e && a ? n.yzapi.getDeliveryDetail(a, e).then((function(n) {
      200 == n.code ? (n.data.applyJob.wage = n.data.applyJob.minWage.toString() + "-" + n.data.applyJob.minWage.toString() + "k", t.setData({
        deliveryitem: n.data
      })) : wx.showToast({
        title: "获取失败，请稍后重试!",
        icon: "none",
        duration: 2e3
      })
    })) : wx.showToast({
      title: "网络错误，请稍后重试!",
      icon: "none",
      duration: 2e3
    })
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {}
});