var t = require("../../@babel/runtime/helpers/objectSpread2"),
  a = getApp();
Page({
  data: {
    imgUrls: ["https://flyplan.obs.myhuaweicloud.com/wechat/static/images/index_banner.png", "../../images/banner_sy.png"],
    indicatorDots: !0,
    vertical: !1,
    autoplay: !0,
    circular: !0,
    interval: 2e3,
    duration: 500,
    clearShow: !1,
    searchContent: "",
    focusSearch: !1,
    maskShow: !1,
    jobList: [],
    currentPage: 1,
    pageSize: 6,
    reachBottom: {
      loadIs: !1,
      loadMore: !1,
      loadAll: !1
    },
    pdfloading: 1e5,
    statusBarHeight: 0,
    hasResme: !1,
    companyImageList: ["https://flyplan.obs.cn-north-4.myhuaweicloud.com/static/qngz/company/-s-a1.png", "https://flyplan.obs.cn-north-4.myhuaweicloud.com/static/qngz/company/-s-a2.png", "https://flyplan.obs.cn-north-4.myhuaweicloud.com/static/qngz/company/-s-a3.png", "https://flyplan.obs.cn-north-4.myhuaweicloud.com/static/qngz/company/-s-a4.png", "https://flyplan.obs.cn-north-4.myhuaweicloud.com/static/qngz/company/-s-a5.png", "https://flyplan.obs.cn-north-4.myhuaweicloud.com/static/qngz/company/-s-a6.png", "https://flyplan.obs.cn-north-4.myhuaweicloud.com/static/qngz/company/-s-a7.png", "https://flyplan.obs.cn-north-4.myhuaweicloud.com/static/qngz/company/-s-a8.png", "https://flyplan.obs.cn-north-4.myhuaweicloud.com/static/qngz/company/-s-a9.png", "https://flyplan.obs.cn-north-4.myhuaweicloud.com/static/qngz/company/-s-a10.png", "https://flyplan.obs.cn-north-4.myhuaweicloud.com/static/qngz/company/-s-a11.png", "https://flyplan.obs.cn-north-4.myhuaweicloud.com/static/qngz/company/-s-a12.png", "https://flyplan.obs.cn-north-4.myhuaweicloud.com/static/qngz/company/-s-a13.png", "https://flyplan.obs.cn-north-4.myhuaweicloud.com/static/qngz/company/-s-a14.png", "https://flyplan.obs.cn-north-4.myhuaweicloud.com/static/qngz/company/-s-a15.png"]
  },
  onLoad: function() {
    this.getSysInfo()
  },
  search: function(t) {
    var a = t.detail.value;
    a.length > 0 ? this.setData({
      clearShow: !0
    }) : 0 == a.length && this.setData({
      clearShow: !1
    }), this.setData({
      searchContent: a,
      currentPage: 1,
      jobList: []
    }), this.onShow()
  },
  clearSearch: function() {
    this.setData({
      clearShow: !1,
      searchContent: "",
      maskShow: !1,
      issearch: !0
    }), this.onShow()
  },
  focusInput: function() {
    this.setData({
      maskShow: !0
    })
  },
  blurInput: function() {
    this.setData({
      maskShow: !1
    })
  },
  changeIndicatorDots: function() {
    this.setData({
      indicatorDots: !this.data.indicatorDots
    })
  },
  changeAutoplay: function() {
    this.setData({
      autoplay: !this.data.autoplay
    })
  },
  intervalChange: function(t) {
    this.setData({
      interval: t.detail.value
    })
  },
  durationChange: function(t) {
    this.setData({
      duration: t.detail.value
    })
  },
  getJobList: function() {
    var t = this,
      o = this;
    1 == this.data.currentPage && o.setData({
      "reachBottom.loadMore": !0,
      "reachBottom.loadAll": !1
    });
    var e = o.data.currentPage + 1;
    a.yzapi.getJobList(this.data.currentPage, this.data.pageSize, this.data.searchContent).then((function(a) {
      if (200 == a.code) {
        var n = a.data.data;
        if (n && n.length > 0) {
          var s = o.data.jobList.concat(n);
          o.setData({
            currentPage: e,
            jobList: s,
            "reachBottom.loadMore": !1
          }), n.length < t.data.pageSize && o.setData({
            "reachBottom.loadMore": !1,
            "reachBottom.loadAll": !0
          })
        } else n && 0 == n.length ? o.setData({
          "reachBottom.loadMore": !1,
          "reachBottom.loadAll": !0
        }) : o.setData({
          "reachBottom.loadMore": !0,
          "reachBottom.loadAll": !1
        })
      } else o.setData({
        "reachBottom.loadMore": !1,
        "reachBottom.loadAll": !1
      })
    }))
  },
  onShow: function() {
    this.getRecommendList2(), wx.getStorageSync("resumeInfo") && this.setData({
      hasResme: !0
    })
  },
  onPullDownRefresh: function() {},
  onReachBottom: function() {
    var t = this;
    t.data.reachBottom.loadMore || (t.setData({
      "reachBottom.loadIs": !0,
      "reachBottom.loadMore": !0,
      "reachBottom.loadAll": !1
    }), setTimeout((function() {
      t.getRecommendList2()
    }), 2e3))
  },
  handlebanner: function(t) {
    var a = t.currentTarget.dataset.index;
    console.log(t.currentTarget.dataset.index), 1 == a && wx.navigateTo({
      url: "./pdfpage/index",
      success: function(t) {},
      fail: function(t) {},
      complete: function(t) {}
    })
  },
  commit: function(t) {
    var a = t.detail.value;
    a.length > 0 && wx.navigateTo({
      url: "./search_info/index?value=" + a,
      success: function(t) {},
      fail: function(t) {},
      complete: function(t) {}
    }), this.setData({
      searchContent: ""
    })
  },
  getSysInfo: function() {
    var t = this;
    wx.getSystemInfo({
      success: function(a) {
        t.setData({
          statusBarHeight: a.statusBarHeight
        })
      }
    })
  },
  getRecommendList2: function() {
    var o = this,
      e = this;
    1 == this.data.currentPage && e.setData({
      "reachBottom.loadMore": !0,
      "reachBottom.loadAll": !1
    });
    var n = e.data.currentPage + 1,
      s = {
        currentPage: this.data.currentPage,
        pageSize: this.data.pageSize
      };
    a.yzapi.getRecommendList2(s).then((function(a) {
      if (200 == a.code) {
        var s = a.data.data.map((function(a) {
          return t(t({}, a), {}, {
            images: [o.data.companyImageList[parseInt(15 * Math.random() + 0)], o.data.companyImageList[parseInt(15 * Math.random() + 0)], o.data.companyImageList[parseInt(15 * Math.random() + 0)]]
          })
        }));
        if (s && s.length > 0) {
          var c = e.data.jobList.concat(s);
          e.setData({
            currentPage: n,
            jobList: c,
            "reachBottom.loadMore": !1
          }), s.length < o.data.pageSize && e.setData({
            "reachBottom.loadMore": !1,
            "reachBottom.loadAll": !0
          })
        } else s && 0 == s.length ? e.setData({
          "reachBottom.loadMore": !1,
          "reachBottom.loadAll": !0
        }) : e.setData({
          "reachBottom.loadMore": !0,
          "reachBottom.loadAll": !1
        })
      } else e.setData({
        "reachBottom.loadMore": !1,
        "reachBottom.loadAll": !1
      })
    }))
  },
  resumeNav: function() {
    wx.getStorageSync("openid") ? wx.navigateTo({
      url: "/pages/resume/index"
    }) : wx.navigateTo({
      url: "/pages/login/index"
    })
  }
});