var t = getApp();
Page({
  data: {
    query: {
      type: 2,
      currentPage: 1,
      pageSize: 1e4
    },
    dataList: [],
    page: {},
    showModal: !1,
    rejectReason: "",
    impId: "",
    reachBottom: {
      loadIs: !1,
      loadMore: !1,
      loadAll: !1
    }
  },
  onLoad: function(t) {},
  onReady: function() {},
  onShow: function() {
    this.getImpressionList()
  },
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {},
  getImpressionList: function() {
    var e = this,
      a = this,
      o = this.data.query,
      n = o.type,
      i = o.currentPage,
      r = o.pageSize;
    1 == this.data.currentPage && a.setData({
      "reachBottom.loadMore": !0,
      "reachBottom.loadAll": !1
    }), t.yzapi.getImpressionList(n, i, r, "").then((function(t) {
      if (200 == t.code) {
        var o = t.data.data;
        if (o && o.length > 0) {
          a.data.dataList.concat(o);
          a.setData({
            query: e.data.query,
            dataList: o,
            "reachBottom.loadMore": !1,
            page: t.data.page
          }), o.length < e.data.pageSize && a.setData({
            "reachBottom.loadMore": !1,
            "reachBottom.loadAll": !0
          })
        } else o && 0 == o.length ? a.setData({
          "reachBottom.loadMore": !1,
          "reachBottom.loadAll": !0
        }) : a.setData({
          "reachBottom.loadMore": !0,
          "reachBottom.loadAll": !1
        })
      } else a.setData({
        "reachBottom.loadMore": !1,
        "reachBottom.loadAll": !1
      })
    }))
  },
  willLike: function() {
    wx.showToast({
      title: "当前审核状态无法点赞哦!",
      icon: "none",
      duration: 1500
    })
  },
  liked: function(e) {
    var a = this,
      o = 1,
      n = e.currentTarget.dataset.impid;
    1 == e.currentTarget.dataset.selflikecount && (o = 2), t.yzapi.getImpressionPraise(o, n).then((function(t) {
      200 == t.code ? a.onShow() : wx.showToast({
        title: t.msg,
        icon: "none",
        duration: 1500
      })
    }))
  },
  navMessage: function(t) {
    var e = t.currentTarget.dataset.index;
    1 == t.currentTarget.dataset.state ? wx.navigateTo({
      url: "../InternshipExperience_message/index?impId=" + e
    }) : wx.showToast({
      title: "当前审核状态无法评论哦!",
      icon: "none",
      duration: 1500
    })
  },
  rejectreson: function(t) {
    this.setData({
      rejectReason: t.currentTarget.dataset.str,
      showModal: !0,
      impId: t.currentTarget.dataset.impid
    })
  },
  close_model: function() {
    this.setData({
      showModal: !1,
      rejectReason: "",
      impId: ""
    })
  },
  navAdd: function() {
    wx.navigateTo({
      url: "../AddInternshipExperience/index?impId=" + this.data.impId
    }), this.setData({
      showModal: !1,
      rejectReason: "",
      impId: ""
    })
  }
});