Page({
  data: {
    maxWordsNumbers: 50,
    currentWords: 0,
    information: ""
  },
  getDataBindTap: function(n) {
    var o = n.detail.value,
      t = parseInt(o.length);
    this.setData({
      currentWords: t
    })
  },
  onLoad: function(n) {},
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {}
});