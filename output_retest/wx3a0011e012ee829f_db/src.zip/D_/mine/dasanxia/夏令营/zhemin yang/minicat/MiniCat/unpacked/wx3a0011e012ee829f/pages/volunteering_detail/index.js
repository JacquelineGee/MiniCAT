var e = getApp();
Page({
  data: {
    title_active: 1,
    showModal: !1,
    activedetail: [],
    errMsg: [],
    getPhoneNumber: !1,
    options: {
      id: ""
    },
    timeset: 0,
    contentfix: "",
    shareCard: !1,
    tempFilePath: "",
    QRurl: "",
    btnShow: !1,
    isLogin: !0,
    openid: "",
    loginHasdone: !1
  },
  onLoad: function(e) {
    if (this.setData({
        options: e
      }), e.scene) {
      var t = decodeURIComponent(e.scene);
      this.setData({
        "options.id": t
      })
    }
    var n = wx.getStorageSync("phoneNumber"),
      a = wx.getStorageSync("resumeInfo");
    (n || "" != a && null != a && null != a) && this.setData({
      getPhoneNumber: !0
    }), wx.getStorageSync("openid") || this.setData({
      isLogin: !1
    })
  },
  onReady: function() {},
  onShow: function() {
    wx.showShareMenu({
      withShareTicket: !0,
      menus: ["shareAppMessage", "shareTimeline"]
    }), this.getVolunteeringDetail();
    var e = wx.getStorageSync("openid");
    "" != e && null != e && null != e && this.setData({
      loginHasdone: !0
    })
  },
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function(e) {
    var t = this.data.activedetail.title;
    return "button" === e.from ? (console.log(e.target, e), {
      title: t,
      imageUrl: this.data.tempFilePath
    }) : {
      title: t
    }
  },
  onShareTimeline: function() {
    var e = this.data.activedetail.title,
      t = this.data.activedetail.poster;
    return {
      title: "点击加入青年赣州".concat(e),
      imageUrl: t
    }
  },
  handlenav: function(e) {
    var t = e.currentTarget.dataset.index;
    this.setData({
      title_active: t
    })
  },
  submit: function() {
    this.setData({
      showModal: !0
    })
  },
  preventTouchMove: function() {},
  close_mask: function() {
    this.setData({
      showModal: !1
    })
  },
  getPhoneNumber: function(t) {
    var n = this,
      a = t.detail,
      i = a.iv,
      o = a.encryptedData,
      s = wx.getStorageSync("openid"),
      c = wx.getStorageSync("session_key"),
      r = wx.getStorageSync("resumeInfo"),
      l = "";
    l = "" != r && null != r && null != r ? r.basic.mobile : wx.getStorageSync("phoneNumber");
    var d = this.data.activedetail.id,
      h = this,
      g = wx.getStorageSync("userInfo"),
      u = g.avatarUrl,
      f = g.nickName;
    if (l) {
      var w = wx.getStorageSync("address");
      if (w && Date.now() < h.data.timeset) {
        var m = w.longitude,
          v = w.latitude;
        e.yzapi.getVolunteeringSigning(d, 1, m, v).then((function(e) {
          if (console.log(e), 200 == e.code) wx.showToast({
            title: "签到成功！",
            icon: "success",
            duration: 1500
          }), h.onShow();
          else if (500603 == e.code) {
            console.log(e.msg);
            var t = e.msg.split(",");
            h.setData({
              errMsg: t,
              showModal: !0
            })
          } else if (500606 == e.code) wx.showToast({
            title: e.msg,
            icon: "none",
            duration: 1500
          });
          else if (500609 == e.code) {
            var n = e.msg.split("，");
            h.setData({
              errMsg: n,
              showModal: !0
            })
          } else wx.showToast({
            title: e.msg,
            icon: "none",
            duration: 1500
          })
        }))
      }
    } else e.yzapi.getWetchatMobile(c, o, i, s, f, u).then((function(t) {
      if (200 == t.code) {
        var a = t.data.phoneNumber;
        wx.setStorageSync("phoneNumber", a), n.setData({
          getPhoneNumber: !0
        })
      } else 500100 == t.code ? wx.login({
        success: function(t) {
          var n = t.code;
          e.yzapi.getOpenId(n).then((function(e) {
            if (console.log(e), 200 == e.code) {
              var t = e.data,
                n = t.openid,
                a = t.session_key;
              wx.setStorageSync("openid", n), wx.setStorageSync("session_key", a), h.getPhoneNumber()
            }
          }))
        }
      }) : wx.showToast({
        title: t.msg,
        icon: "none",
        duration: 1500
      })
    }))
  },
  getuserinfo: function() {
    console.log(1)
  },
  checkLogin: function() {
    wx.showToast({
      title: "请先登录",
      icon: "none"
    })
  },
  volunteerFinish: function() {
    this.data.activedetail.id
  },
  shareCard: function() {
    wx.getStorageSync("openid") ? (this.setData({
      shareCard: !0
    }), this.initCanvas()) : wx.showToast({
      title: "请先登录",
      icon: "none"
    })
  },
  shareSave: function() {
    wx.saveImageToPhotosAlbum({
      filePath: this.data.tempFilePath,
      success: function(e) {
        wx.showModal({
          content: "图片已保存到相册，赶紧晒一下吧~",
          showCancel: !1,
          confirmText: "好的",
          confirmColor: "#333",
          success: function(e) {
            e.confirm && console.log("用户点击确定")
          },
          fail: function(e) {
            console.log(11111)
          }
        })
      }
    })
  },
  initCanvas: function() {
    var e = this,
      t = wx.getStorageSync("userInfo"),
      n = wx.getStorageSync("resumeInfo"),
      a = {};
    null != n && "" != n && null != n ? (a.head = n.basic.head, a.name = n.basic.realName) : (a.head = t.avatarUrl, a.name = t.nickName), wx.createSelectorQuery().select("#myCanvas").fields({
      node: !0,
      size: !0
    }).exec((function(t) {
      var n = t[0].node,
        i = n.getContext("2d"),
        o = wx.getSystemInfoSync().pixelRatio;
      n.width = t[0].width * o, n.height = t[0].height * o;
      var s = n.createImage();
      s.src = "../../images/Cbg.png", s.onload = function() {
        i.drawImage(s, 0, 0, n.width, n.height);
        var t = n.createImage();
        t.src = a.head, t.onload = function() {
          e.circle(i, t, .065 * n.width, .41 * n.width, .063 * n.width)
        }, i.font = "".concat(.038 * n.width, "px Arail"), i.fillStyle = "#666", i.fillText("我是", .065 * n.width, .58 * n.width), i.font = "".concat(.038 * n.width, "px Arail"), i.fillStyle = "#333", i.fillText(a.name, .18 * n.width, .581 * n.width);
        var o = n.createImage();
        o.src = e.data.activedetail.shareCode, o.onload = function() {
          i.drawImage(o, .766 * n.width, n.width, .158 * n.width, .158 * n.width), wx.canvasToTempFilePath({
            canvas: n,
            success: function(t) {
              e.setData({
                tempFilePath: t.tempFilePath,
                btnShow: !0
              })
            },
            fail: function(e) {
              console.log(e)
            }
          })
        }
      }, setTimeout((function() {}), 500)
    }))
  },
  circle: function(e, t, n, a, i) {
    e.save();
    var o = 2 * i,
      s = n + i,
      c = a + i;
    e.arc(s, c, i, 0, 2 * Math.PI), e.clip(), e.drawImage(t, n, a, o, o), e.restore()
  },
  out: function() {
    this.setData({
      shareCard: !1
    })
  },
  getVolunteeringDetail: function() {
    var t = this,
      n = this,
      a = this.data.options.id,
      i = wx.getStorageSync("openid");
    i ? e.yzapi.getVolunteeringDetail(a, i).then((function(e) {
      var n = e.data.content.replace(/<img/gi, "<img class='richImg'");
      t.setData({
        activedetail: e.data,
        contentfix: n
      })
    })) : (wx.login({
      success: function(t) {
        var i = t.code;
        e.yzapi.getOpenId(i).then((function(t) {
          if (200 == t.code) {
            var i = t.data,
              o = i.openid,
              s = i.session_key;
            wx.setStorageSync("session_key", s), e.yzapi.getVolunteeringDetail(a, o).then((function(e) {
              n.setData({
                activedetail: e.data
              })
            }))
          }
        }))
      }
    }), n.setData({
      isLogin: !1
    }))
  },
  skipBtn: function(e) {
    var t = e.target.dataset.index;
    1 == t ? this.setData({
      isLogin: !0
    }) : 2 == t && wx.reLaunch({
      url: "../user/index"
    })
  }
});