var t = getApp();
Page({
  data: {
    pointInfor: {},
    goodsInfo: {},
    isEnough: !0,
    backInfo: {},
    resStatus: 0,
    isconversion: !1,
    errMsg: "",
    detail: {}
  },
  onLoad: function(t) {
    t.name = decodeURI(t.name), this.setData({
      goodsInfo: t
    })
  },
  onReady: function() {},
  onShow: function() {
    this.getMyPoint(), this.getMallCardDetail()
  },
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {},
  getMyPoint: function() {
    var n = this,
      o = this;
    t.yzapi.getMyPoint().then((function(t) {
      var a = t.data.totalPoints,
        i = o.data.goodsInfo.points;
      n.setData({
        pointInfor: t.data,
        isEnough: a >= i
      })
    }))
  },
  getCardChange: function() {
    var n = this,
      o = n.data.goodsInfo.crdId;
    wx.showToast({
      title: "兑换中...",
      icon: "loading",
      duration: 15e3
    }), t.yzapi.getCardChange(o).then((function(t) {
      console.log(t), 200 == t.code ? (n.setData({
        backInfo: t.data,
        isconversion: !0,
        resStatus: 1
      }), wx.hideToast({
        success: function(t) {}
      })) : (n.setData({
        errMsg: t.msg,
        isconversion: !0,
        resStatus: 2
      }), wx.hideToast({
        success: function(t) {}
      }))
    }))
  },
  backMall: function() {
    wx.navigateBack({
      delta: 0,
      fail: function() {
        wx.reLaunch({
          url: "/pages/MyIntegral/index",
          fail: function(t) {
            wx.showToast({
              title: t,
              icon: "none",
              duration: 1500
            })
          }
        })
      }
    })
  },
  getMallCardDetail: function() {
    var n = this,
      o = this.data.goodsInfo.crdId;
    t.yzapi.getMallCardDetail(o).then((function(t) {
      n.setData({
        detail: t.data
      })
    }))
  }
});