var e = require("../../@babel/runtime/helpers/defineProperty"),
  t = getApp();
Page({
  data: {
    winitem: {
      certId: "",
      certName: "",
      getTime: "",
      certPath: ""
    },
    endDate: "2020-06",
    isEdit: !1,
    tempcertPath: ""
  },
  binWinName: function(t) {
    this.setData(e({}, "winitem.certName", t.detail.value))
  },
  bindDateChange: function(t) {
    this.setData(e({}, "winitem.getTime", t.detail.value))
  },
  chooseImg: function(t) {
    var i = this;
    wx.chooseImage({
      count: 1,
      sizeType: ["original", "compressed"],
      sourceType: ["album", "camera"],
      success: function(t) {
        var a = t.tempFilePaths;
        i.data.imgs;
        i.setData(e({}, "winitem.certPath", a[0]))
      }
    })
  },
  deleteImg: function(t) {
    this.setData(e({}, "winitem.certPath", ""))
  },
  previewImg: function(e) {
    var t = [this.data.winitem.certPath];
    wx.previewImage({
      current: this.data.winitem.certPath,
      urls: t
    })
  },
  editcert1: function() {
    if ("" == this.data.winitem.certName) return wx.showToast({
      title: "请填写证书名称!",
      icon: "none",
      duration: 2e3
    }), !1;
    if ("" == this.data.winitem.getTime) return wx.showToast({
      title: "请填写获奖时间!",
      icon: "none",
      duration: 2e3
    }), !1;
    if ("" == this.data.winitem.certPath) return wx.showToast({
      title: "请上传证书图片!",
      icon: "none",
      duration: 2e3
    }), !1;
    wx.showLoading({
      title: "提交中..."
    });
    var e = {
        certId: this.data.winitem.certId,
        certName: this.data.winitem.certName,
        getTime: this.data.winitem.getTime,
        certFiles: this.data.winitem.certPath
      },
      i = wx.getStorageSync("openid");
    if (i) {
      var a = {
        Authorization: i
      };
      wx.uploadFile({
        url: t.yzapi._baseUrl + "/wechat/mine/resume/addCert",
        filePath: e.certFiles,
        name: "certFiles",
        header: a,
        formData: e,
        success: function(e) {
          var t = JSON.parse(e.data);
          console.log(t), 200 == t.code ? (wx.hideLoading(), wx.showToast({
            title: "修改成功!",
            icon: "success",
            duration: 2e3
          }), setTimeout((function() {
            wx.navigateBack({
              url: "/pages/resume/index"
            })
          }), 1e3)) : wx.showToast({
            title: t.msg,
            icon: "none",
            duration: 2e3
          })
        },
        fail: function(e) {
          console.log(e), wx.showToast({
            title: "修改失败!",
            icon: "none",
            duration: 2e3
          })
        }
      })
    } else wx.showToast({
      title: "修改失败!",
      icon: "none",
      duration: 2e3
    })
  },
  onLoad: function(t) {
    var i = new Date,
      a = i.getFullYear(),
      n = i.getMonth() + 1,
      o = a + "-" + (n = 1 == n.toString().length ? "0" + n : n.toString());
    this.setData({
      endDate: o
    });
    var r, c = t.queryBean;
    c && (c = JSON.parse(c), this.setData((e(r = {}, "winitem.certId", c.certId), e(r, "winitem.certName", c.certName), e(r, "winitem.getTime", c.getTime), e(r, "winitem.certPath", c.certPath), e(r, "isEdit", !0), e(r, "tempcertPath", c.certPath), r)))
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {},
  certdelete: function() {
    var e = this.data.winitem.certId;
    wx.showModal({
      title: "确认删除",
      content: "您确认删除该获奖证书吗",
      success: function(i) {
        i.confirm ? t.yzapi.certDelete(e).then((function(e) {
          console.log(e), 200 == e.code ? wx.showToast({
            title: "删除成功",
            success: function() {
              setTimeout((function() {
                wx.navigateBack()
              }), 1e3)
            }
          }) : wx.showToast({
            title: e.msg,
            icon: "none",
            duration: 2e3
          })
        })) : i.cancel
      }
    })
  },
  addCard: function() {
    var e = this;
    if ("" == this.data.winitem.certName) return wx.showToast({
      title: "请填写证书名称!",
      icon: "none",
      duration: 2e3
    }), !1;
    if ("" == this.data.winitem.getTime) return wx.showToast({
      title: "请填写获奖时间!",
      icon: "none",
      duration: 2e3
    }), !1;
    if ("" == this.data.winitem.certPath) return wx.showToast({
      title: "请上传证书图片!",
      icon: "none",
      duration: 2e3
    }), !1;
    wx.showLoading({
      title: "提交中..."
    });
    var i = {
        certFiles: this.data.winitem.certPath
      },
      a = wx.getStorageSync("openid");
    if (a) {
      var n = {
        Authorization: a
      };
      wx.uploadFile({
        url: t.yzapi._baseUrl + "/wechat/mine/resume/cert/upload",
        name: "certFile",
        filePath: i.certFiles,
        header: n,
        formData: i,
        success: function(i) {
          var a = JSON.parse(i.data);
          if (200 == a.code) {
            var n = {
              certId: e.data.winitem.certId,
              certName: e.data.winitem.certName,
              getTime: e.data.winitem.getTime,
              certFileUrl: a.data
            };
            t.yzapi.addCard(n.certId, n.certName, n.getTime, n.certFileUrl).then((function(e) {
              console.log(e), 200 == e.code ? (wx.hideLoading(), wx.showToast({
                title: "提交成功!",
                icon: "success",
                duration: 2e3
              }), setTimeout((function() {
                wx.navigateBack({
                  url: "/pages/resume/index"
                })
              }), 1e3)) : wx.showToast({
                title: e.msg,
                icon: "none",
                duration: 2e3
              })
            }))
          } else wx.showModal({
            cancelColor: i.msg
          })
        }
      })
    }
  },
  editcert: function() {
    var e = this;
    if ("" == this.data.winitem.certName) return wx.showToast({
      title: "请填写证书名称!",
      icon: "none",
      duration: 2e3
    }), !1;
    if ("" == this.data.winitem.getTime) return wx.showToast({
      title: "请填写获奖时间!",
      icon: "none",
      duration: 2e3
    }), !1;
    if ("" == this.data.winitem.certPath) return wx.showToast({
      title: "请上传证书图片!",
      icon: "none",
      duration: 2e3
    }), !1;
    if (wx.showLoading({
        title: "提交中..."
      }), e.data.tempcertPath == e.data.winitem.certPath) {
      var i = {
        certId: e.data.winitem.certId,
        certName: e.data.winitem.certName,
        getTime: e.data.winitem.getTime,
        certFileUrl: e.data.winitem.certPath
      };
      t.yzapi.addCard(i.certId, i.certName, i.getTime, i.certFileUrl).then((function(e) {
        console.log(e), 200 == e.code ? (wx.hideLoading(), wx.showToast({
          title: "提交成功!",
          icon: "success",
          duration: 2e3
        }), setTimeout((function() {
          wx.navigateBack({
            url: "/pages/resume/index"
          })
        }), 1e3)) : wx.showToast({
          title: e.msg,
          icon: "none",
          duration: 2e3
        })
      }))
    } else {
      var a = {
          certFiles: this.data.winitem.certPath
        },
        n = wx.getStorageSync("openid");
      if (n) {
        var o = {
          Authorization: n
        };
        wx.uploadFile({
          url: t.yzapi._baseUrl + "/wechat/mine/resume/cert/upload",
          name: "certFile",
          filePath: a.certFiles,
          header: o,
          formData: a,
          success: function(i) {
            var a = JSON.parse(i.data);
            if (200 == a.code) {
              var n = {
                certId: e.data.winitem.certId,
                certName: e.data.winitem.certName,
                getTime: e.data.winitem.getTime,
                certFileUrl: a.data
              };
              t.yzapi.addCard(n.certId, n.certName, n.getTime, n.certFileUrl).then((function(e) {
                console.log(e), 200 == e.code ? (wx.hideLoading(), wx.showToast({
                  title: "提交成功!",
                  icon: "success",
                  duration: 2e3
                }), setTimeout((function() {
                  wx.navigateBack({
                    url: "/pages/resume/index"
                  })
                }), 1e3)) : wx.showToast({
                  title: e.msg,
                  icon: "none",
                  duration: 2e3
                })
              }))
            } else wx.showModal({
              cancelColor: i.msg
            })
          }
        })
      }
    }
  }
});