var t = getApp();
Page({
  data: {
    statusBarHeight: 0,
    select: 1,
    name: "",
    province: "",
    city: "",
    district: "",
    price: "",
    addressInfo: "",
    phone: "",
    loanPurpose: "",
    loanPurposeText: "",
    industry: "",
    industryText: "",
    industryList: [],
    loanPurposeList: [],
    loanPurposeShow: !1,
    industryShow: !1,
    region: "",
    actShow: !1
  },
  onLoad: function(t) {
    this.getSysInfo(), this.getIndustry(), this.getLoanPurpose(), this.checkLogin()
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {},
  getSysInfo: function() {
    var t = this;
    wx.getSystemInfo({
      success: function(n) {
        t.setData({
          statusBarHeight: n.statusBarHeight
        })
      }
    })
  },
  handleSelect: function(t) {
    var n = t.currentTarget.dataset.index;
    n != this.data.select && this.setData({
      select: n
    })
  },
  handleSubmit: function() {
    var n = {
      name: this.data.name,
      province: this.data.province,
      city: this.data.city,
      district: this.data.district,
      price: this.data.price,
      addressInfo: this.data.region + this.data.addressInfo,
      phone: this.data.phone,
      loanPurpose: this.data.loanPurpose,
      industry: this.data.industry
    };
    t.yzapi.postApplyLoan(n).then((function(t) {
      console.log(t), 200 == t.code ? wx.showToast({
        title: "提交成功",
        icon: "success"
      }) : 500105 == t.code ? wx.showToast({
        title: "请先完成资料填写",
        icon: "none"
      }) : wx.showToast({
        title: t.msg,
        icon: "none"
      })
    }))
  },
  getIndustry: function() {
    var n = this;
    t.yzapi.getIndustry().then((function(t) {
      200 == t.code && n.setData({
        industryList: t.data.map((function(t) {
          return {
            text: t.value,
            value: t.field
          }
        }))
      })
    }))
  },
  getLoanPurpose: function() {
    var n = this;
    t.yzapi.getLoanPurpose().then((function(t) {
      200 == t.code && n.setData({
        loanPurposeList: t.data.map((function(t) {
          return {
            text: t.value,
            value: t.field
          }
        }))
      })
    }))
  },
  openMask: function(t) {
    var n = t.currentTarget.dataset.index;
    1 == n ? this.setData({
      loanPurposeShow: !0
    }) : 2 == n && this.setData({
      industryShow: !0
    })
  },
  btnLoanPurposeClick: function(t) {
    var n = t.detail;
    console.log(n), this.setData({
      loanPurposeText: this.data.loanPurposeList[n.index].text,
      loanPurpose: n.value,
      loanPurposeShow: !1
    })
  },
  btnIndustryClick: function(t) {
    var n = t.detail;
    console.log(t), this.setData({
      industry: n.value,
      industryText: this.data.industryList[n.index].text,
      industryShow: !1
    })
  },
  bindRegionChange: function(t) {
    var n = t.detail.value;
    this.setData({
      province: n[0],
      city: n[1],
      district: n[2],
      region: n[0] + n[1] + n[2]
    })
  },
  navBack: function() {
    wx.navigateBack({
      delta: 0,
      fail: function() {
        wx.reLaunch({
          url: "/pages/index/index"
        })
      }
    })
  },
  checkLogin: function() {
    wx.getStorageSync("openid") || wx.navigateTo({
      url: "/pages/login/index"
    })
  }
});