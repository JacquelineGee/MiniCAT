var t = getApp();
Page({
  data: {
    offerlist: []
  },
  onLoad: function(n) {
    var a = this;
    t.yzapi.getOfferDetails().then((function(t) {
      console.log(t.data.data), a.setData({
        offerlist: t.data.data
      })
    }))
  },
  onReady: function() {},
  onShow: function() {
    t.checkLogin()
  },
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {},
  accept: function(t) {
    console.log(t);
    var n = t.currentTarget.dataset.id,
      a = t.currentTarget.dataset.name;
    wx.navigateTo({
      url: "./offerdetail/offdetail?id=" + n + "&name=" + a + "&status=1",
      success: function(t) {},
      fail: function(t) {},
      complete: function(t) {}
    })
  },
  unaccept: function(t) {
    console.log(t);
    var n = t.currentTarget.dataset.id,
      a = t.currentTarget.dataset.name;
    wx.navigateTo({
      url: "./offerdetail/offdetail?id=" + n + "&name=" + a + "&status=2",
      success: function(t) {},
      fail: function(t) {},
      complete: function(t) {}
    })
  }
});