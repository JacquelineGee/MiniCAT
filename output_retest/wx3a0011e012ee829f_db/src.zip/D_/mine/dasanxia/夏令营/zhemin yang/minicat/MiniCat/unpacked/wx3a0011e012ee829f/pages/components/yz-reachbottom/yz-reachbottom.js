var a = getApp();
Component({
  options: {
    addGlobalClass: !0
  },
  properties: {
    loadIs: {
      type: Boolean,
      value: !1
    },
    loadMore: {
      type: Boolean,
      value: !1
    },
    loadAll: {
      type: Boolean,
      value: !1
    }
  },
  data: {},
  lifetimes: {
    attached: function() {
      this.setData({
        navH: a.globalData.navHeight
      })
    }
  },
  methods: {
    navBack: function() {
      wx.navigateBack({
        delta: 1
      })
    },
    toIndex: function() {
      wx.navigateTo({
        url: "/pages/admin/home/index/index"
      })
    }
  }
});