var n = getApp();
Page({
  data: {
    isOldUser: !0,
    phoneInfo: {},
    userInfo: {},
    isLoing: !0
  },
  onLoad: function(n) {},
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {},
  getSesson: function() {
    var e = this;
    wx.login({
      success: function(o) {
        console.log(o), n.yzapi.getOpenId(o.code).then((function(n) {
          console.log(n), wx.setStorageSync("openid", n.data.openid), wx.setStorageSync("session_key", n.data.session_key), e.data.isOldUser = null == n.data.userInfo
        }))
      }
    })
  },
  backHandle: function() {
    wx.navigateBack({
      delta: 0,
      fail: function() {
        wx.reLaunch({
          url: "/pages/start/start"
        })
      }
    })
  },
  open: function() {
    var n = this;
    wx.showLoading({
      title: "登录中..."
    }), this.getSesson(), wx.getUserProfile({
      desc: "申请获取您的信息",
      success: function(e) {
        var o = e.userInfo;
        if (console.log(o), n.setData({
            isOldUser: n.data.isOldUser,
            userInfo: o
          }), n.data.isOldUser) n.setData({
          isLoing: !1
        }), wx.hideLoading({
          success: function(n) {}
        });
        else {
          var t = getCurrentPages(),
            a = t[t.length - 2];
          null != a ? (wx.showToast({
            title: "登录成功"
          }), a.setData({
            userInfo: o,
            hasUserInfo: !0
          })) : wx.showToast({
            title: "该页面已过期，请重新打开",
            icon: "none",
            duration: 1500
          }), a.onShow(), wx.navigateBack({
            delta: 0
          })
        }
      },
      fail: function() {
        wx.hideLoading({
          success: function(n) {}
        })
      }
    })
  },
  getphonenumber: function(n) {
    var e = n.detail;
    console.log(n), wx.setStorageSync("phoneInfo", e), this.getPhoneNumber()
  },
  getPhoneNumber: function() {
    var e = this,
      o = wx.getStorageSync("phoneInfo"),
      t = wx.getStorageSync("openid"),
      a = wx.getStorageSync("session_key");
    n.yzapi.getWetchatMobile(a, o.encryptedData, o.iv, t).then((function(n) {
      if (200 == n.code) {
        wx.setStorageSync("phoneNumber", n.data.phoneNumber);
        var o = getCurrentPages(),
          t = o[o.length - 2];
        null != t ? (t.setData({
          userInfo: e.data.userInfo,
          hasUserInfo: !0
        }), t.onShow(), wx.navigateBack({
          delta: 0
        })) : wx.showToast({
          title: "该页面已过期，请重新打开",
          icon: "none",
          duration: 1500
        })
      }
    }))
  }
});