var n = getApp();
Page({
  data: {
    maxWordsNumbers: 50,
    currentWords: 0,
    information: ""
  },
  getDataBindTap: function(n) {
    var t = n.detail.value,
      o = parseInt(t.length);
    this.setData({
      currentWords: o,
      information: t
    })
  },
  onLoad: function(n) {
    "null" == n.content && (n.content = "");
    var t = parseInt(n.content.length);
    this.setData({
      information: n.content,
      currentWords: t
    })
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {},
  editSelfDescribe: function(t) {
    var o = wx.getStorageSync("openid");
    this.data.information.length >= 8 ? o ? n.yzapi.editSelfDescribe(o, this.data.information).then((function(n) {
      console.log(n), 200 == n.code ? (wx.showToast({
        title: "修改成功!",
        icon: "success",
        duration: 2e3
      }), setTimeout((function() {
        wx.navigateBack({
          url: "/pages/resume/index"
        })
      }), 1e3)) : wx.showToast({
        title: n.msg,
        icon: "none",
        duration: 2e3
      })
    })) : wx.showToast({
      title: "未登录，请先登录!",
      icon: "none",
      duration: 2e3
    }) : wx.showToast({
      title: "自我描述不能少于8个字!",
      icon: "none",
      duration: 2e3
    })
  }
});