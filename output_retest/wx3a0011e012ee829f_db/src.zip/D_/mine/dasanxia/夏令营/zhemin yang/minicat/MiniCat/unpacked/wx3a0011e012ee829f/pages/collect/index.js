var t = getApp();
Page({
  data: {
    query: {
      currentPage: 1,
      pageSize: 1e3
    },
    reachBottom: {
      loadIs: !1,
      loadMore: !1,
      loadAll: !1
    },
    list: [],
    slideButtons: [{}, {
      type: "warn",
      text: "取消收藏",
      extClass: "test"
    }]
  },
  onLoad: function(t) {
    this.getFavoriteRecordList(), console.log(this.data.list)
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {},
  getFavoriteRecordList: function() {
    var a = this,
      e = this.data.query;
    1 == e.currentPage && a.setData({
      "reachBottom.loadMore": !0,
      "reachBottom.loadAll": !1
    });
    var o = e.currentPage + 1;
    t.yzapi.getFavoriteRecordList(e.currentPage, e.pageSize).then((function(t) {
      if (200 == t.code) {
        var r = t.data;
        if (r && r.length > 0) {
          var n = a.data.list.concat(r);
          a.setData({
            "query.currentPage": o,
            list: n,
            "reachBottom.loadMore": !1
          }), r.length < e.pageSize && a.setData({
            "reachBottom.loadMore": !1,
            "reachBottom.loadAll": !0
          })
        } else r && 0 == r.length ? a.setData({
          "reachBottom.loadMore": !1,
          "reachBottom.loadAll": !0
        }) : a.setData({
          "reachBottom.loadMore": !0,
          "reachBottom.loadAll": !1
        })
      } else a.setData({
        "reachBottom.loadMore": !1,
        "reachBottom.loadAll": !1
      })
    }))
  },
  slideButtonTap: function(a) {
    var e = this,
      o = a.currentTarget.dataset.index,
      r = this.data.list[o].posId;
    t.yzapi.cacelFavorite(r).then((function(t) {
      200 == t.code && (e.data.list.splice(o, 1), e.setData({
        list: e.data.list
      }))
    }))
  }
});