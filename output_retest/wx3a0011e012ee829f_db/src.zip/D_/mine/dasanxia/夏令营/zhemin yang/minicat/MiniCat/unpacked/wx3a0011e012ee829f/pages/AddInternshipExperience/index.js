var t = getApp();
Page({
  data: {
    showMask: !1,
    fail: !1,
    done: !1,
    dataInfo: {},
    content: "",
    impId: "",
    type: 1,
    lenght: -1
  },
  onLoad: function(n) {
    var e = this;
    if (null != n.impId) {
      this.setData({
        impId: n.impId,
        type: 2
      });
      var a = {
          type: 2,
          currentPage: 1,
          pageSize: 10,
          impId: this.data.impId
        },
        o = a.type,
        i = a.currentPage,
        s = a.pageSize,
        c = a.impId;
      t.yzapi.getImpressionList(o, i, s, c).then((function(t) {
        200 == t.code && e.setData({
          content: t.data.data[0].content
        })
      }))
    }
  },
  onReady: function() {},
  onShow: function() {
    var n = this;
    t.yzapi.getExperience().then((function(t) {
      200 == t.code ? n.setData({
        dataInfo: t.data
      }) : wx.showToast({
        title: t.msg,
        icon: "none",
        duration: 1500
      })
    }))
  },
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {},
  submit: function() {
    var n = this,
      e = this.data,
      a = e.content,
      o = {
        type: e.type,
        impId: e.impId,
        content: a
      };
    t.yzapi.postImpressionPublish(o).then((function(t) {
      200 == t.code ? n.setData({
        showMask: !0,
        done: !0
      }) : 500702 == t.code ? n.setData({
        showMask: !0,
        fail: !0
      }) : wx.showToast({
        title: t.msg,
        icon: "none",
        duration: 1500
      })
    }))
  },
  save: function() {},
  closeMask: function() {
    this.setData({
      showMask: !1
    }), this.data.done && wx.reLaunch({
      url: "/pages/MyInternshipExperience/index"
    })
  },
  enterInput: function(t) {
    var n = t.detail.value;
    this.setData({
      content: n
    })
  }
});