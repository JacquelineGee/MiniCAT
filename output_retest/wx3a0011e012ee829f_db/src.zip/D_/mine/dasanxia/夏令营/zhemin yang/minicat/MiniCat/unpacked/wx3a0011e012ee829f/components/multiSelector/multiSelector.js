Component({
  properties: {
    items: Array,
    placeholder: {
      type: String,
      value: ""
    },
    placeholderClass: {
      type: String,
      value: "input-placeholder"
    },
    placeholderStyle: String,
    disabled: {
      type: Boolean,
      value: !1
    },
    value: Array,
    showValue: {
      type: Boolean,
      value: !0
    },
    closeOnClickModal: {
      type: Boolean,
      value: !0
    },
    cancelButtonText: {
      type: String,
      value: "取消"
    },
    confirmButtonText: {
      type: String,
      value: "确定"
    }
  },
  data: {
    modalOpen: !1,
    opacityAnimation: {},
    popAnimation: {},
    selected: [],
    tempValue: [],
    tempSelected: [],
    changed: !1
  },
  attached: function() {
    for (var e = this.data.value, t = this.data.items, a = [], i = 0; i < e.length; i++)
      for (var n = 0; n < t.length; n++)
        if (e[i] === t[n].name) {
          a.push(t[n].fieldId), t[n].checked = !0;
          break
        } this.setData({
      items: t,
      selected: a
    })
  },
  methods: {
    bindCheckboxChange: function(e) {
      var t = e.detail.value,
        a = this.data.items;
      a.forEach((function(e) {
        e.checked = !1
      }));
      for (var i = [], n = 0; n < t.length; n++)
        for (var l = 0; l < a.length; l++)
          if (t[n] === a[l].name) {
            a[l].checked = !0, i.push(a[l].fieldId);
            break
          } this.setData({
        changed: !0,
        items: a,
        tempValue: t,
        tempSelected: i
      })
    },
    showModal: function(e) {
      this.triggerEvent("modalopen");
      var t = this.data.value,
        a = this.data.items;
      a.forEach((function(e) {
        e.checked = !1
      }));
      for (var i = 0; i < t.length; i++)
        for (var n = 0; n < a.length; n++)
          if (t[i] === a[n].name) {
            a[n].checked = !0;
            break
          } wx.createAnimation({
        duration: 200,
        timingFunction: '"linear"',
        delay: 0
      }).opacity(1).step(), this.setData({
        changed: !1,
        items: a,
        modalOpen: !0
      })
    },
    hideModal: function(e) {
      this.triggerEvent("modalclose");
      var t = e.currentTarget.dataset.action || "cancel";
      wx.createAnimation({
        duration: 200,
        timingFunction: "linear",
        delay: 0
      }).opacity(0).step(), "cancel" !== t && this.data.changed ? (this.setData({
        value: this.data.tempValue,
        selected: this.data.tempSelected,
        modalOpen: !1
      }), this.triggerEvent("change", {
        value: this.data.selected,
        name: this.data.value
      })) : this.setData({
        tempValue: [],
        tempSelected: [],
        modalOpen: !1
      })
    }
  }
});