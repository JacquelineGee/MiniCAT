var t = getApp();
Component({
  options: {
    addGlobalClass: !0
  },
  properties: {
    query: {
      type: Object,
      value: []
    },
    from: {
      type: String,
      value: ""
    }
  },
  data: {
    tabsList: [{
      key: "region",
      selectCode: 0,
      name: "地区",
      show: !0,
      list: []
    }, {
      key: "unitType",
      selectCode: 0,
      name: "单位类型",
      show: !0,
      list: []
    }, {
      key: "wage",
      selectCode: 0,
      name: "薪资",
      show: !0,
      list: []
    }, {
      key: "paixu",
      name: "排序",
      show: !1,
      list: []
    }],
    tabsSelect: {
      key: "",
      selectCode: 0,
      list: []
    },
    chooseTab: -1,
    maskShow: !1,
    commonJobOptions: [],
    list: [],
    curPage: ""
  },
  attached: function() {
    this.setTabsList(), this.getCommonJobOptions()
  },
  methods: {
    clickMask: function() {
      this.setData({
        maskShow: !1
      })
    },
    setTabsList: function() {
      var t = this,
        e = this.data.tabsList;
      e.forEach((function(a, s) {
        t.data.query.hasOwnProperty(a.key) ? e[s].show = !0 : e[s].show = !1
      })), this.setData({
        tabsList: e
      })
    },
    clickTab: function(t) {
      var e = t.currentTarget.dataset.index,
        a = t.currentTarget.dataset.itemdata,
        s = a.key,
        o = a.selectCode,
        i = a.list,
        n = getCurrentPages(),
        c = n[n.length - 1].route,
        r = {
          key: s,
          selectCode: o,
          list: i
        };
      this.setData({
        tabsSelect: r,
        maskShow: !this.data.maskShow,
        chooseTab: e,
        curPage: c
      }), console.log(c)
    },
    clickType: function(t) {
      var e = t.currentTarget.dataset.selectitem,
        a = t.currentTarget.dataset.selectdata,
        s = (t.currentTarget.dataset.index, a.key),
        o = e.code,
        i = this.data.query;
      i.hasOwnProperty(s) && (i[s] = e.code, i.currentPage = 1), this.setData({
        typeCurrent: t.currentTarget.dataset.index,
        maskShow: !this.data.maskShow
      }), this.selectTabType(s, o);
      var n = {
        query: this.data.query,
        list: this.data.list
      };
      this.triggerEvent("receiveData", n), this.triggerEvent("callSomeFun")
    },
    selectTabType: function(t, e) {
      var a = this.data.tabsList;
      a.forEach((function(s, o) {
        s.key == t && (a[o].selectCode = e)
      })), this.setData({
        tabsList: a
      })
    },
    getCommonJobOptions: function() {
      var e = this;
      t.yzapi.getCommonJobOptions().then((function(t) {
        200 == t.code && (e.setData({
          commonJobOptions: t.data
        }), e.data.commonJobOptions = e.handleWageData(e.data.commonJobOptions), e.assignTabsList(e.data.commonJobOptions, e.data.tabsList))
      }))
    },
    handleWageData: function(t) {
      var e = t;
      if ("workType3" == this.data.from) {
        e.wage = [{
          code: "",
          name: "不限"
        }, {
          code: 60,
          name: "60元/小时"
        }, {
          code: 100,
          name: "100元/小时"
        }, {
          code: 150,
          name: "150元/小时"
        }]
      }
      return e
    },
    assignTabsList: function(e, a) {
      a = t.yzapi.getAssignTabsList(e, a), this.setData({
        tabsList: a
      })
    }
  }
});