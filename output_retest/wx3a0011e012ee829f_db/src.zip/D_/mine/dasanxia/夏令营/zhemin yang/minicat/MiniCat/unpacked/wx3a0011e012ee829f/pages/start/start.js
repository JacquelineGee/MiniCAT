var t = getApp();
Page({
  data: {
    motto: "Hello World",
    userInfo: {},
    hasUserInfo: !1,
    canIUse: wx.canIUse("button.open-type.getUserInfo"),
    downFlage: !0,
    hasdown: !1,
    time: 3,
    phoneHeight: 0,
    interval: ""
  },
  bindViewTap: function() {},
  onLoad: function() {
    this.setData({
      phoneHeight: t.globalData.navHeight
    })
  },
  onShow: function() {
    var t = this,
      a = this;
    this.data.interval = setInterval((function() {
      a.data.time--, a.setData({
        time: t.data.time
      }), a.data.time <= 0 && (clearInterval(a.data.interval), wx.reLaunch({
        url: "../index/index"
      }))
    }), 1e3)
  },
  handleSkip: function() {
    clearInterval(this.data.interval), wx.reLaunch({
      url: "../index/index"
    })
  }
});