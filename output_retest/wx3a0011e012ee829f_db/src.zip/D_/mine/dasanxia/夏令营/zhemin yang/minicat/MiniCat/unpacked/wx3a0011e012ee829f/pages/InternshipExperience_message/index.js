var t = getApp();
Page({
  data: {
    info: {},
    query: {
      impId: "",
      currentPage: 1,
      pageSize: 1e4
    },
    comment: {},
    self_icon: "",
    content: "",
    statusBarHeight: 0,
    impId: ""
  },
  onLoad: function(t) {
    var n = this;
    this.setData({
      impId: t.impId
    }), wx.getSystemInfoAsync({
      success: function(t) {
        n.setData({
          statusBarHeight: 2 * t.statusBarHeight
        })
      }
    })
  },
  onReady: function() {},
  onShow: function() {
    this.getImpressionCommentList(), this.getImpressionList(), this.setData({
      self_icon: wx.getStorageSync("userInfo").avatarUrl
    })
  },
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {},
  getImpressionList: function() {
    var n = this,
      e = this.data.query,
      i = e.currentPage,
      a = e.pageSize,
      o = this.data.impId;
    t.yzapi.getImpressionList(1, i, a, o).then((function(t) {
      200 == t.code && n.setData({
        info: t.data.data[0]
      })
    }))
  },
  getImpressionCommentList: function() {
    var n = this;
    this.data.query.impId = this.data.impId;
    var e = this.data.query,
      i = e.impId,
      a = e.currentPage,
      o = e.pageSize;
    t.yzapi.getImpressionCommentList(i, a, o).then((function(t) {
      200 == t.code ? n.setData({
        comment: t.data
      }) : wx.showToast({
        title: t.msg,
        icon: "none",
        duration: 1500
      })
    }))
  },
  inputhandle: function(t) {
    this.setData({
      content: t.detail.value
    })
  },
  confirmhandle: function() {
    var n = this,
      e = {
        impId: this.data.info.impId,
        content: this.data.content
      };
    t.yzapi.getImpressionCommentWrite(e).then((function(t) {
      200 == t.code ? (wx.showToast({
        title: "发布成功",
        duration: 1500
      }), n.onShow(), n.setData({
        content: ""
      })) : wx.showToast({
        title: t.msg,
        icon: "none",
        duration: 1500
      })
    }))
  },
  liked: function(n) {
    var e = this,
      i = 1,
      a = n.currentTarget.dataset.impid;
    1 == n.currentTarget.dataset.selflikecount && (i = 2), t.yzapi.getImpressionPraise(i, a).then((function(t) {
      200 == t.code ? e.onShow() : wx.showToast({
        title: t.msg,
        icon: "none",
        duration: 1500
      })
    }))
  },
  backBtn: function() {
    wx.navigateBack({
      delta: 0,
      success: function(t) {},
      fail: function(t) {},
      complete: function(t) {}
    })
  }
});