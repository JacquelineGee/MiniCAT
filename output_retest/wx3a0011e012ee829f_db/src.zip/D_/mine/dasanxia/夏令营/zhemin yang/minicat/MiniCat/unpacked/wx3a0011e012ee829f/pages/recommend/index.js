var t = getApp();
Page({
  data: {
    imgUrls: ["https://i.loli.net/2020/06/01/hlfIg6wxKnOsjGP.png", "https://i.loli.net/2020/06/01/hlfIg6wxKnOsjGP.png", "https://i.loli.net/2020/06/01/hlfIg6wxKnOsjGP.png"],
    indicatorDots: !0,
    vertical: !1,
    autoplay: !0,
    circular: !0,
    interval: 2e3,
    duration: 500,
    tabs: ["地区", "薪资", "排序"],
    chooseTab: -1,
    types: ["全部", "见习", "兼职", "全职"],
    typeCurrent: 0,
    maskShow: !1,
    recommendList: [],
    query: {
      currentPage: 1,
      pageSize: 10,
      region: "",
      wage: ""
    },
    reachBottom: {
      loadIs: !1,
      loadMore: !1,
      loadAll: !1
    },
    wageList: "",
    topNavIndex: "",
    moreWageShow: !1
  },
  onLoad: function(t) {},
  clickTab: function(t) {
    this.setData({
      chooseTab: t.currentTarget.dataset.index,
      maskShow: !this.data.maskShow
    })
  },
  clickType: function(t) {
    this.setData({
      typeCurrent: t.currentTarget.dataset.index,
      maskShow: !this.data.maskShow
    }), console.log(this.data.maskShow)
  },
  clickMask: function() {
    this.setData({
      maskShow: !1
    }), console.log(this.data.maskShow)
  },
  onReady: function() {},
  onShow: function() {
    var t = this;
    wx.getStorage({
      key: "openid",
      success: function(e) {
        if (e.data) {
          var a = wx.getStorageSync("resumeInfo").resumeBasic;
          t.data.query.region = a.region, t.data.query.wage = a.wage, t.getRecommendList()
        }
      }
    }), this.getWageList()
  },
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {
    var t = this;
    t.data.reachBottom.loadMore || (t.setData({
      "reachBottom.loadIs": !0,
      "reachBottom.loadMore": !0,
      "reachBottom.loadAll": !1
    }), setTimeout((function() {
      t.onShow()
    }), 2e3))
  },
  onShareAppMessage: function() {},
  getRecommendList: function() {
    var e = this,
      a = this,
      o = this.data.query;
    1 == this.data.query.currentPage && a.setData({
      "reachBottom.loadMore": !0,
      "reachBottom.loadAll": !1
    });
    var n = a.data.query.currentPage + 1;
    t.yzapi.getRecommendList(o.currentPage, o.pageSize, o.region, o.wage).then((function(t) {
      if (200 == t.code) {
        var o = t.data.data;
        if (o && o.length > 0) {
          var r = a.data.recommendList.concat(o);
          a.setData({
            "query.currentPage": n,
            recommendList: r,
            "reachBottom.loadMore": !1
          }), o.length < e.data.query.pageSize && a.setData({
            "reachBottom.loadMore": !1,
            "reachBottom.loadAll": !0
          })
        } else o && 0 == o.length && 1 != a.data.query.currentPage || o && 0 == o.length ? a.setData({
          "reachBottom.loadMore": !1,
          "reachBottom.loadAll": !1
        }) : a.setData({
          "reachBottom.loadMore": !0,
          "reachBottom.loadAll": !1
        })
      } else a.setData({
        "reachBottom.loadMore": !1,
        "reachBottom.loadAll": !1
      })
    }))
  },
  receiveData: function(t) {
    var e = t.detail,
      a = e.query,
      o = e.list;
    this.setData({
      query: a,
      recommendList: o
    })
  },
  handleClick: function(e) {
    var a = this,
      o = e.target.dataset.index,
      n = this.data.query;
    console.log(e.target.dataset.index), this.data.query.wage = o, this.data.topNavIndex != o && (this.setData({
      topNavIndex: o,
      query: this.data.query
    }), t.yzapi.getRecommendList(n.currentPage, n.pageSize, n.region, n.wage).then((function(t) {
      200 == t.code && a.setData({
        recommendList: t.data.data
      })
    })))
  },
  getWageList: function() {
    var e = this;
    t.yzapi.getCommonJobOptions().then((function(t) {
      200 == t.code && e.setData({
        wageList: t.data.wage
      })
    }))
  },
  handleMore: function() {
    this.setData({
      moreWageShow: !0
    })
  },
  handleMask: function() {
    this.setData({
      moreWageShow: !1
    })
  },
  handleMoreItem: function(e) {
    var a = this,
      o = e.currentTarget.dataset.index,
      n = this.data.query;
    this.data.query.wage = o, this.setData({
      topNavIndex: o,
      moreWageShow: !1,
      query: this.data.query
    }), t.yzapi.getRecommendList(n.currentPage, n.pageSize, n.region, n.wage).then((function(t) {
      200 == t.code && a.setData({
        recommendList: t.data.data
      })
    }))
  },
  handleMove: function() {}
});