var t = getApp();
Page({
  data: {
    query: {
      currentPage: 1,
      pageSize: 1e4
    },
    dataList: {}
  },
  onLoad: function(t) {},
  onReady: function() {},
  onShow: function() {
    this.getCardList()
  },
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {},
  getCardList: function() {
    var n = this;
    t.yzapi.getCardList(this.data.query).then((function(t) {
      n.setData({
        dataList: t.data.data
      })
    }))
  }
});