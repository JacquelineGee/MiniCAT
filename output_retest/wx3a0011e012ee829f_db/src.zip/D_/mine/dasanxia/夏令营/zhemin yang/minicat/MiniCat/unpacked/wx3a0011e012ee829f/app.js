var e = require("./@babel/runtime/helpers/interopRequireDefault"),
  n = require("./@babel/runtime/helpers/typeof"),
  r = e(require("./libs/yzapi.js"));
App({
  globalData: {
    userInfo: null
  },
  onLaunch: function(e) {
    var n = this,
      r = wx.getStorageSync("logs") || [];
    r.unshift(Date.now()), wx.setStorageSync("logs", r), wx.getSystemInfo({
      success: function(e) {
        n.globalData.navHeight = e.statusBarHeight + 46
      },
      fail: function(e) {
        console.log(e)
      }
    }), this.overShare()
  },
  isEmpty: function(e) {
    switch (n(e)) {
      case "undefined":
        return !0;
      case "string":
        if (0 == e.replace(/(^[ \t\n\r]*)|([ \t\n\r]*$)/g, "").length) return !0;
        break;
      case "boolean":
        if (!e) return !0;
        break;
      case "number":
        if (0 === e || isNaN(e)) return !0;
        break;
      case "object":
        if (null === e || 0 === e.length) return !0;
        for (var r in e) return !1;
        return !0
    }
    return !1
  },
  checkLogin: function() {
    if (!wx.getStorageSync("openid")) return wx.showToast({
      title: "未登录,请先登录!",
      icon: "none",
      duration: 2e3
    }), !0
  },
  onShow: function(e) {
    var n = e.shareTicket;
    wx.getShareInfo({
      shareTicket: n,
      success: function(e) {}
    })
  },
  onShareAppMessage: function(e) {
    return {
      title: "青年赣州"
    }
  },
  overShare: function() {
    wx.onAppRoute((function(e) {
      var n, r = getCurrentPages(),
        t = r[r.length - 1];
      "pages/user/index" != t.route && "pages/volunteering_detail/index" != t.route && t && ((n = t.data).isOverShare || (n.isOverShare = !0, t.onShareAppMessage = function() {
        return {
          title: "青年赣州小程序",
          imageUrl: ""
        }
      }), wx.showShareMenu({
        withShareTicket: !0,
        menus: ["shareAppMessage", "shareTimeline"]
      }))
    }))
  },
  yzapi: new r.default
});