Page({
  data: {
    url: ["https://flyplan.obs.myhuaweicloud.com/doc/imgs/0001.jpg", "https://flyplan.obs.myhuaweicloud.com/doc/imgs/0002.jpg", "https://flyplan.obs.myhuaweicloud.com/doc/imgs/0003.jpg", "https://flyplan.obs.myhuaweicloud.com/doc/imgs/0004.jpg", "https://flyplan.obs.myhuaweicloud.com/doc/imgs/0005.jpg", "https://flyplan.obs.myhuaweicloud.com/doc/imgs/0006.jpg", "https://flyplan.obs.myhuaweicloud.com/doc/imgs/0007.jpg", "https://flyplan.obs.myhuaweicloud.com/doc/imgs/0008.jpg", "https://flyplan.obs.myhuaweicloud.com/doc/imgs/0009.jpg", "https://flyplan.obs.myhuaweicloud.com/doc/imgs/0010.jpg", "https://flyplan.obs.myhuaweicloud.com/doc/imgs/0011.jpg", "https://flyplan.obs.myhuaweicloud.com/doc/imgs/0012.jpg", "https://flyplan.obs.myhuaweicloud.com/doc/imgs/0013.jpg", "https://flyplan.obs.myhuaweicloud.com/doc/imgs/0014.jpg", "https://flyplan.obs.myhuaweicloud.com/doc/imgs/0015.jpg", "https://flyplan.obs.myhuaweicloud.com/doc/imgs/0016.jpg", "https://flyplan.obs.myhuaweicloud.com/doc/imgs/0017.jpg"]
  },
  onLoad: function(o) {},
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {},
  preview: function(o) {
    console.log(o.currentTarget.dataset.src);
    var c = o.currentTarget.dataset.src;
    wx.previewImage({
      current: c,
      urls: this.data.url
    })
  }
});