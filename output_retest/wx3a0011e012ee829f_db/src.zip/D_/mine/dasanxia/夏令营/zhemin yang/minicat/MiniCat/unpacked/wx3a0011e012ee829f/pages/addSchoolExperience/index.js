var e = require("../../@babel/runtime/helpers/defineProperty"),
  t = getApp();
Page({
  data: {
    eduitem: {
      eduId: "",
      school: "",
      professional: "",
      startTime: "2017",
      endTime: "2021"
    },
    eduType: "初中",
    eduTypeCode: 1,
    eduTypes: [],
    date: "开始时间",
    date2: "结束时间",
    endDate: (new Date).getFullYear(),
    maxWordsNumbers: 50,
    currentWords: 0,
    information: "",
    isedit: !1
  },
  binSchool: function(t) {
    this.setData(e({}, "eduitem.school", t.detail.value))
  },
  bindTypeChange: function(e) {
    this.setData({
      eduType: this.data.eduTypes[e.detail.value].value,
      eduTypeCode: this.data.eduTypes[e.detail.value].field
    })
  },
  binProfessional: function(t) {
    this.setData(e({}, "eduitem.professional", t.detail.value))
  },
  bindDateChange: function(t) {
    this.setData(e({}, "eduitem.startTime", t.detail.value))
  },
  bindDateChange2: function(t) {
    this.setData(e({}, "eduitem.endTime", t.detail.value))
  },
  getDataBindTap: function(e) {
    var t = e.detail.value,
      i = parseInt(t.length);
    this.setData({
      currentWords: i,
      information: t
    })
  },
  submitform: function() {
    if ("" == this.data.eduitem.school) return wx.showToast({
      title: "请填写学校名称!",
      icon: "none",
      duration: 2e3
    }), !1;
    if ("" == this.data.eduitem.professional) return wx.showToast({
      title: "请填写专业名称!",
      icon: "none",
      duration: 2e3
    }), !1;
    if (!this.compareTime()) return wx.showToast({
      title: "请选择正确的就读时间!",
      icon: "none",
      duration: 2e3
    }), !1;
    var e = {
        eduId: this.data.eduitem.eduId,
        school: this.data.eduitem.school,
        startTime: this.data.eduitem.startTime,
        endTime: this.data.eduitem.endTime,
        bgEdu: this.data.eduTypeCode,
        professional: this.data.eduitem.professional,
        experience: this.data.information
      },
      i = wx.getStorageSync("openid");
    i ? t.yzapi.editEducation(i, e).then((function(e) {
      200 == e.code ? (wx.showToast({
        title: "修改成功!",
        icon: "success",
        duration: 2e3
      }), setTimeout((function() {
        wx.navigateBack({
          url: "/pages/resume/index"
        })
      }), 1e3)) : wx.showToast({
        title: e.msg,
        icon: "none",
        duration: 2e3
      })
    })) : wx.showToast({
      title: "未登录,请先登录!",
      icon: "none",
      duration: 2e3
    })
  },
  compareTime: function() {
    return new Date(this.data.eduitem.startTime).getTime() - new Date(this.data.eduitem.endTime).getTime() < 0
  },
  onLoad: function(e) {
    var i = this,
      a = (new Date).getFullYear();
    this.setData({
      endDate: a
    });
    var n = wx.getStorageSync("openid");
    n && t.yzapi.getEduOptions(n).then((function(e) {
      200 == e.code ? i.setData({
        eduTypes: e.data
      }) : wx.showToast({
        title: "获取失败，请稍后重试!",
        icon: "none",
        duration: 2e3
      })
    }));
    var o = e.queryBean;
    if (o) {
      o = JSON.parse(o);
      for (var d = 1, s = 0; s < this.data.eduTypes.length; s++) this.data.eduTypes[s].value == o.bgEdu && (d = this.data.eduTypes[s].field);
      this.setData({
        eduitem: o,
        eduType: o.bgEdu,
        eduTypeCode: d,
        information: o.experience,
        currentWords: o.experience.length,
        isedit: !0
      })
    }
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {},
  deleteEducation: function() {
    var e = this.data.eduitem.eduId;
    wx.showModal({
      title: "确认删除",
      content: "您确认删除该教育经历吗",
      success: function(i) {
        i.confirm ? t.yzapi.educationDelete(e).then((function(e) {
          console.log(e), 200 == e.code ? wx.showToast({
            title: "删除成功",
            success: function() {
              setTimeout((function() {
                wx.navigateBack()
              }), 1e3)
            }
          }) : wx.showToast({
            title: e.msg,
            icon: "none",
            duration: 2e3
          })
        })) : i.cancel
      }
    })
  }
});