var t, a = require("../../@babel/runtime/helpers/defineProperty"),
  e = getApp();
Page((t = {
  data: {
    imgUrls: ["../../images/banner_szjg.png"],
    userinfo: {},
    indicatorDots: !0,
    vertical: !1,
    autoplay: !0,
    circular: !0,
    interval: 2e3,
    duration: 500,
    currentTab: 1,
    companyTab: 0,
    showAll: !1,
    messageTab: 0,
    showAllMessage: !1,
    showAllEvaluate: !1,
    PositionDetail: !1,
    posId: 0,
    compId: 0,
    companyDetail: "",
    companyBasic: [],
    companyIntro: [],
    companyDetailJoblist: [],
    companyDetailLeaveWord: [],
    companyDetailEval: [],
    leaveMessage: !0,
    isDeliveryShow: !1,
    replyContent: "",
    companyDetailHeight: "",
    positionDetailHeight: "",
    ellipsis: !0,
    ellipsisTwo: !0,
    workType: "",
    isInternship: "",
    chongfu: !1,
    onloading: !1
  },
  ellipsis: function() {
    var t = !this.data.ellipsis;
    this.setData({
      ellipsis: t
    })
  },
  ellipsisTwo: function() {
    var t = !this.data.ellipsisTwo;
    this.setData({
      ellipsisTwo: t
    })
  },
  onLoad: function(t) {
    var a = this;
    null != t.isInternship && this.setData({
      isInternship: t.isInternship
    }), this.setData({
      workType: t.wordType
    });
    var e = 1;
    t.type && (e = t.type), this.setData({
      posId: t.posId,
      compId: t.compId,
      currentTab: e
    });
    var i = wx.getStorageSync("resumeInfo");
    this.setData({
      userinfo: i.basic
    });
    var o = wx.getStorageSync("openid");
    this.getCompanyDetail(t.posId, t.compId, o), this.getCompanyBasic(t.posId, t.compId), setTimeout((function() {
      "" == a.data.companyDetail && a.setData({
        onloading: !0
      })
    }), 100)
  },
  bindReply: function(t) {
    this.setData({
      replyContent: t.detail.value
    })
  },
  clickTab: function(t) {
    if (this.data.currentTab === t.target.dataset.current) return !1;
    this.setData({
      currentTab: t.target.dataset.current
    }), 1 == this.data.currentTab ? this.getPositionHeight() : 0 == this.data.currentTab && (this.getCompanyDetailJobList(this.data.compId), this.getCompanyDetailleaveWord(this.data.compId), this.getCompanyDetailEval(this.data.compId))
  },
  clickCompanyTab: function(t) {
    if (this.data.companyTab === t.target.dataset.current) return !1;
    this.setData({
      companyTab: t.target.dataset.current
    })
  },
  clickMessageTab: function(t) {
    console.log(t.target.dataset.current);
    if (this.data.messageTab === t.target.dataset.current) return !1;
    this.setData({
      messageTab: t.target.dataset.current
    })
  },
  getPositionHeight: function() {
    var t = this;
    setTimeout((function() {
      var a = t;
      wx.createSelectorQuery().select(".position_detail").boundingClientRect((function(t) {
        a.setData({
          positionDetailHeight: t.height
        })
      })).exec()
    }), 500)
  },
  showDetail: function() {
    this.setData({
      showAll: !this.data.showAll
    })
  },
  showMessage: function() {
    this.setData({
      showAllMessage: !this.data.showAllMessage
    })
  },
  showEvaluate: function() {
    this.setData({
      showAllEvaluate: !this.data.showAllEvaluate
    })
  },
  showPositionDetail: function() {
    this.setData({
      PositionDetail: !this.data.PositionDetail
    })
  },
  clickDeliveryShow: function() {
    this.setData({
      isDeliveryShow: !0
    })
  },
  clickDeliveryNone: function() {
    this.setData({
      isDeliveryShow: !1
    })
  },
  closeEvalTip: function() {
    this.setData(a({}, "companyBasic.canEval", !1))
  },
  goEval: function() {
    wx.redirectTo({
      url: "/pages/myEvaluate/index"
    })
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {},
  getCompanyDetail: function(t, a, i) {
    var o = this;
    e.yzapi.getCompanyDetail(t, a, i).then((function(t) {
      200 == t.code && o.setData({
        companyDetail: t.data,
        onloading: !1
      })
    }))
  },
  getCompanyBasic: function(t, a) {
    var i = this;
    e.yzapi.getCompanyBasic(t, a).then((function(t) {
      if (200 == t.code) {
        null == t.data.logo && (t.data.logo = "https://flyplan.obs.myhuaweicloud.com/wechat/static/images/top_banner.png"), i.setData({
          companyBasic: t.data
        });
        var a = i.data.companyBasic.compName;
        wx.setNavigationBarTitle({
          title: a
        })
      }
    }))
  },
  getCompanyDetailIntro: function(t) {
    var a = this;
    e.yzapi.getCompanyDetailIntro(t).then((function(t) {
      null == t.data.setUpTime && (t.data.setUpTime = ""), 200 == t.code && a.setData({
        companyIntro: t.data
      })
    }))
  },
  getCompanyDetailJobList: function(t) {
    var a = this;
    e.yzapi.getCompanyDetailJobList(t).then((function(t) {
      200 == t.code && a.setData({
        companyDetailJoblist: t.data
      })
    }))
  },
  getCompanyDetailleaveWord: function(t) {
    var a = this;
    e.yzapi.getCompanyDetailleaveWord(t).then((function(t) {
      200 == t.code && a.setData({
        companyDetailLeaveWord: t.data
      })
    }))
  },
  getCompanyDetailLeaveWordAdd: function() {
    var t = this;
    if ("" == this.data.replyContent) return wx.showToast({
      title: "留言不能为空!",
      icon: "none",
      duration: 2e3
    }), !1;
    e.yzapi.getCompanyDetailLeaveWordAdd(this.data.compId, this.data.replyContent).then((function(a) {
      200 == a.code ? (wx.showToast({
        title: "留言成功",
        icon: "success",
        duration: 2e3
      }), t.setData({
        leaveMessage: !1
      }), t.onLoad({
        compId: t.data.compId,
        posId: t.data.posId
      })) : wx.showToast({
        title: a.msg,
        icon: "none",
        duration: 2e3
      })
    }))
  },
  getCompanyDetailEval: function(t) {
    var a = this;
    e.yzapi.getCompanyDetailEval(t).then((function(t) {
      200 == t.code && a.setData({
        companyDetailEval: t.data
      })
    }))
  },
  submitDeliveryTab: function(t) {
    var i = this,
      o = this;
    e.yzapi.postdelivery(o.data.posId).then((function(t) {
      var e;
      200 == t.code ? (wx.showToast({
        title: "投递成功",
        icon: "success",
        duration: 2e3
      }), o.setData((a(e = {}, "companyBasic.applied", !0), a(e, "isDeliveryShow", !1), e))) : 500501 == t.code ? i.setData({
        chongfu: t.msg
      }) : wx.showToast({
        title: t.msg,
        icon: "none",
        duration: 2e3
      })
    }))
  },
  postFavorite: function(t) {
    var i = this;
    e.yzapi.postFavorite(this.data.posId).then((function(t) {
      200 == t.code ? (wx.showToast({
        title: "收藏成功",
        icon: "success",
        duration: 2e3
      }), i.setData(a({}, "companyBasic.favorited", !0))) : wx.showToast({
        title: "收藏失败,请先填写个人资料",
        icon: "none",
        duration: 2e3
      })
    }))
  },
  cancelFavorite: function(t) {
    var i = this;
    e.yzapi.cacelFavorite(this.data.posId).then((function(t) {
      200 == t.code ? (wx.showToast({
        title: "取消收藏成功",
        icon: "success",
        duration: 2e3
      }), i.setData(a({}, "companyBasic.favorited", !1))) : wx.showToast({
        title: "取消收藏失败",
        icon: "none",
        duration: 2e3
      })
    }))
  }
}, a(t, "onShareAppMessage", (function(t) {
  return t.from, {
    title: "分享单位",
    path: "/pages/companyDetail/company?posId=" + this.data.posId + "&compId=" + this.data.compId,
    success: function(t) {
      wx.showToast({
        title: "分享成功",
        icon: "success",
        duration: 2e3
      })
    }
  }
})), a(t, "showLeaveMsg", (function(t) {
  var a = !1,
    i = wx.getStorageSync("userInfo");
  e.isEmpty(i) ? (a = !1, wx.showToast({
    title: "请先授权登录！",
    icon: "none",
    duration: 2e3
  })) : e.isEmpty(this.data.userinfo) ? (a = !1, wx.showToast({
    title: "请先创建简历！",
    icon: "none",
    duration: 2e3
  })) : a = !0, this.setData({
    currentTab: 0,
    companyTab: 2,
    leaveMessage: a,
    showAllMessage: !0
  })
})), a(t, "premove", (function() {})), a(t, "closeMask", (function() {
  this.setData({
    onloading: !1
  })
})), t));