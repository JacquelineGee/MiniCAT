var t = require("../../@babel/runtime/helpers/createForOfIteratorHelper"),
  e = getApp();
Page({
  data: {
    selectIndex: 1,
    query: {
      currentPage: 1,
      pageSize: 1e4,
      state: 1
    },
    reocrdList: [],
    pointInfor: {}
  },
  onLoad: function(t) {},
  onReady: function() {},
  onShow: function() {
    this.getCardMyList(), this.getMyPoint()
  },
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {},
  handleSelect: function(t) {
    var e = t.target.dataset.index;
    this.setData({
      "query.state": e,
      reocrdList: []
    }), this.onShow()
  },
  getCardMyList: function() {
    var n = this,
      a = this.data.query,
      o = [];
    e.yzapi.getCardMyList(a).then((function(e) {
      var a, i = t(e.data.data);
      try {
        for (i.s(); !(a = i.n()).done;) {
          var r = a.value,
            s = Object.keys(r),
            c = {
              name: "",
              list: []
            };
          c.name = s[0], c.list = r[s[0]], o.push(c)
        }
      } catch (t) {
        i.e(t)
      } finally {
        i.f()
      }
      n.setData({
        reocrdList: o
      })
    }))
  },
  getMyPoint: function() {
    var t = this;
    e.yzapi.getMyPoint().then((function(e) {
      t.setData({
        pointInfor: e.data
      })
    }))
  }
});