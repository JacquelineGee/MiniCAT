var t = require("../../@babel/runtime/helpers/createForOfIteratorHelper"),
  a = getApp();
Page({
  data: {
    statusBarHeight: 0,
    scrollTop: 0,
    subCrdId: "",
    detail: {},
    code: "",
    isuserble: !0,
    crdId: "",
    detail2: {}
  },
  onLoad: function(t) {
    var a = this;
    wx.getSystemInfo({
      success: function(t) {
        var e = t.statusBarHeight;
        a.setData({
          statusBarHeight: e
        }), console.log(e)
      }
    }), this.setData({
      subCrdId: t.subCrdId,
      crdId: t.crdId
    }), t.state && 2 == t.state && this.setData({
      isuserble: !1
    })
  },
  onReady: function() {},
  onShow: function() {
    this.getCardMyOrderDetail(), this.getMallCardDetail()
  },
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {},
  backBtn: function() {
    wx.navigateBack({
      delta: 1
    })
  },
  onPageScroll: function(t) {
    var a = t.scrollTop;
    this.setData({
      scrollTop: a
    }), a >= 70 ? wx.setNavigationBarColor({
      backgroundColor: "#000000",
      frontColor: "#000000"
    }) : wx.setNavigationBarColor({
      backgroundColor: "#ffffff",
      frontColor: "#ffffff"
    })
  },
  handleCopy: function() {
    wx.setClipboardData({
      data: this.data.code,
      success: function(t) {
        console.log(t)
      }
    })
  },
  getCardMyOrderDetail: function() {
    var e = this,
      o = this.data.subCrdId;
    a.yzapi.getCardMyOrderDetail(o).then((function(a) {
      if (e.setData({
          code: a.data.code
        }), a.data.code.length >= 11) {
        var o, n = [],
          i = t(a.data.code);
        try {
          for (i.s(); !(o = i.n()).done;) {
            var r = o.value;
            n.push(r)
          }
        } catch (t) {
          i.e(t)
        } finally {
          i.f()
        }
        n.splice(4, 0, " "), n.splice(9, 0, " "), n.splice(14, 0, " "), n.splice(19, 0, " "), a.data.code = n.join("")
      }
      200 == a.code ? e.setData({
        detail: a.data
      }) : wx.showToast({
        title: a.msg,
        icon: "none",
        duration: 1500
      })
    }))
  },
  getMallCardDetail: function() {
    var t = this,
      e = this.data.crdId;
    a.yzapi.getMallCardDetail(e).then((function(a) {
      t.setData({
        detail2: a.data
      })
    }))
  }
});