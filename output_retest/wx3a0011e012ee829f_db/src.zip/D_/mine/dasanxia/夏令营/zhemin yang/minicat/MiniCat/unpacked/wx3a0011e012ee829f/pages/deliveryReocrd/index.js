var t = getApp();
Page({
  data: {
    currentTab: 0,
    navScrollLeft: 0,
    reocrditem: [],
    windowWidth: 0,
    stateStr: ["全部", "投递成功", "已查看", "不合适", "邀面试", "已撤回"],
    stateStr1: ["全部", "投递成功", "已查看", "不合适", "邀面试", "", "", "已撤回"],
    allreocrditem: [],
    after: !0,
    before: !1
  },
  clickTab: function(t) {
    var e = [],
      a = t.currentTarget.dataset.current,
      o = this.data.windowWidth / 5;
    if (this.setData({
        navScrollLeft: (a - 2) * o
      }), 0 == a) e = this.data.allreocrditem;
    else if (5 == a)
      for (var n = 0; n < this.data.allreocrditem.length; n++) 7 == this.data.allreocrditem[n].state && e.push(this.data.allreocrditem[n]);
    else
      for (n = 0; n < this.data.allreocrditem.length; n++) this.data.allreocrditem[n].state == a && e.push(this.data.allreocrditem[n]);
    if (this.setData({
        reocrditem: e
      }), this.data.currentTab === a) return !1;
    this.setData({
      currentTab: a
    })
  },
  onLoad: function(e) {
    var a = this;
    wx.getSystemInfo({
      success: function(t) {
        a.setData({
          windowWidth: t.windowWidth
        })
      }
    });
    var o = wx.getStorageSync("openid");
    o ? t.yzapi.getDeliveryReocrd(o).then((function(t) {
      if (console.log(t), 200 == t.code) {
        for (var e = 0; e < t.data.length; e++) t.data[e].stateText = a.data.stateStr[t.data[e].state], t.data[e].wage = t.data[e].minWage.toString() + "-" + t.data[e].maxWage.toString() + "k";
        a.setData({
          reocrditem: t.data,
          allreocrditem: t.data
        })
      } else 500217 == t.code ? wx.showToast({
        title: t.msg,
        icon: "none",
        duration: 2e3,
        success: function() {
          setTimeout((function() {
            wx.navigateBack({
              delta: -1,
              success: function(t) {},
              fail: function(t) {},
              complete: function(t) {}
            })
          }), 2e3)
        }
      }) : wx.showToast({
        title: "获取失败,请稍后重试!",
        icon: "none",
        duration: 2e3
      })
    })) : wx.showToast({
      title: "获取失败,请稍后重试!",
      icon: "none",
      duration: 2e3
    })
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {},
  canle_send: function(e) {
    var a = this;
    wx.showModal({
      title: "撤回简历",
      content: "是否确认撤回简历",
      cancelColor: "#ff3131",
      success: function(o) {
        if (o.confirm) {
          wx.showToast({
            title: "撤回中...",
            icon: "loading",
            duration: 100500
          });
          var n = wx.getStorageSync("openid"),
            i = a.data.reocrditem[e.currentTarget.dataset.index].applyId;
          t.yzapi.getcancleDelivery(n, i).then((function(t) {
            200 == t.code ? (wx.showToast({
              title: "撤回成功！",
              icon: "success",
              duration: 1500
            }), a.onLoad()) : wx.showToast({
              title: "撤回失败",
              icon: "none",
              duration: 1500
            })
          })), console.log(e)
        } else o.cancel
      }
    })
  },
  handleragging: function(t) {
    t.detail.scrollLeft > 62 ? this.setData({
      before: !0
    }) : this.setData({
      before: !1
    }), t.detail.scrollLeft < 19 ? this.setData({
      after: !0
    }) : this.setData({
      after: !1
    })
  }
});