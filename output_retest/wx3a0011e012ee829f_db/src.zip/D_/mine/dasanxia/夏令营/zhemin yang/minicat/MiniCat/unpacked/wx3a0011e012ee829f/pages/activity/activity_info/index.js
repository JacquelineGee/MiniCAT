var t = getApp();
Page({
  data: {
    title: "",
    id: "",
    activitieInfo: [],
    targeturl: ""
  },
  onLoad: function(t) {
    var i = t.id;
    this.setData({
      id: i,
      title: t.name
    }), wx.setNavigationBarTitle({
      title: this.data.title
    }), this.getActivitieInfo(i)
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {},
  getActivitieInfo: function(i) {
    var n = this;
    t.yzapi.getActivitieInfo(i).then((function(t) {
      200 == t.code && n.setData({
        activitieInfo: t.data
      })
    }))
  },
  nav_target: function() {
    wx.navigateTo({
      url: "../activity-nav/index?url=" + this.data.activitieInfo.url,
      success: function(t) {},
      fail: function(t) {},
      complete: function(t) {}
    })
  }
});