var t = require("../../utils/qrcodeTools.js"),
  o = (require("../../utils/qrcode.js"), getApp());
Page({
  data: {
    statusHeight: 0,
    showMask: !1,
    pointInfor: {},
    QRimg: "",
    scrollTop: 0,
    query: {
      currentPage: 1,
      pageSize: 1e4
    },
    dataList: []
  },
  onLoad: function(t) {
    var o = wx.getSystemInfoSync();
    wx.getStorageSync("resumeInfo");
    this.setData({
      statusHeight: o.statusBarHeight
    })
  },
  onReady: function() {},
  onShow: function() {
    this.getMyPoint(), this.getCardList()
  },
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {},
  backBtn: function() {
    wx.navigateBack({
      delta: 0,
      success: function(t) {},
      fail: function(t) {},
      complete: function(t) {}
    })
  },
  showQR: function() {
    wx.getStorageSync("openid") ? (this.setData({
      showMask: !0
    }), this.QRcreate()) : wx.showToast({
      title: "请先登录",
      icon: "none"
    })
  },
  preventTouchMove: function() {},
  out: function() {
    this.setData({
      showMask: !1
    })
  },
  getMyPoint: function() {
    var t = this;
    o.yzapi.getMyPoint().then((function(o) {
      t.setData({
        pointInfor: o.data
      })
    }))
  },
  QRcreate: function() {
    this.data.pointInfor;
    var o = t.createQrCodeImg("https://www.baidu.com", {
      size: 150,
      callback: function(t) {
        console.log(t)
      }
    });
    this.setData({
      QRimg: o
    })
  },
  onPageScroll: function(t) {
    var o = t.scrollTop;
    o > 35 ? (console.log(o), this.setData({
      scrollTop: o - 35
    })) : this.setData({
      scrollTop: 0
    })
  },
  getCardList: function() {
    var t = this;
    o.yzapi.getCardList(this.data.query).then((function(o) {
      t.setData({
        dataList: o.data.data
      })
    }))
  }
});