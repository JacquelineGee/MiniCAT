var t = getApp();
Page({
  data: {
    imgUrls: ["../../images/banner.png"],
    indicatorDots: !0,
    vertical: !1,
    autoplay: !0,
    circular: !0,
    interval: 2e3,
    duration: 500,
    tabs: ["地区", "类型", "薪资", "排序"],
    chooseTab: -1,
    types: ["不限", "机关单位", "国有企业", "民营企业"],
    typeCurrent: 0,
    maskShow: !1,
    internshipList: [],
    commonJobOptions: [],
    query_internship: {
      currentPage: 1,
      pageSize: 10,
      region: "",
      wage: "",
      paixu: ""
    },
    reachBottom: {
      loadIs: !1,
      loadMore: !1,
      loadAll: !1
    }
  },
  onLoad: function(t) {},
  clickTab: function(t) {
    this.setData({
      chooseTab: t.currentTarget.dataset.index,
      maskShow: !this.data.maskShow
    })
  },
  clickType: function(t) {
    this.setData({
      typeCurrent: t.currentTarget.dataset.index,
      maskShow: !this.data.maskShow
    }), console.log(this.data.maskShow)
  },
  clickMask: function() {
    this.setData({
      maskShow: !1
    }), console.log(this.data.maskShow)
  },
  changeIndicatorDots: function() {
    this.setData({
      indicatorDots: !this.data.indicatorDots
    })
  },
  changeAutoplay: function() {
    this.setData({
      autoplay: !this.data.autoplay
    })
  },
  intervalChange: function(t) {
    this.setData({
      interval: t.detail.value
    })
  },
  durationChange: function(t) {
    this.setData({
      duration: t.detail.value
    })
  },
  onReady: function() {},
  onShow: function() {
    this.getInternshipList()
  },
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {
    var t = this;
    t.data.reachBottom.loadMore || (t.setData({
      "reachBottom.loadIs": !0,
      "reachBottom.loadMore": !0,
      "reachBottom.loadAll": !1
    }), setTimeout((function() {
      t.getInternshipList()
    }), 2e3))
  },
  onShareAppMessage: function() {},
  getInternshipList: function() {
    var a = this,
      o = this,
      e = this.data.query_internship;
    1 == this.data.query_internship.currentPage && o.setData({
      "reachBottom.loadMore": !0,
      "reachBottom.loadAll": !1
    });
    var n = o.data.query_internship.currentPage + 1;
    t.yzapi.getLookJobList(e.currentPage, e.pageSize, e.region, e.wage, 3, "").then((function(t) {
      if (200 == t.code) {
        var e = t.data.data;
        if (e && e.length > 0) {
          var i = o.data.internshipList.concat(e);
          o.setData({
            "query_internship.currentPage": n,
            internshipList: i,
            "reachBottom.loadMore": !1
          }), e.length < a.data.query_internship.pageSize && (o.setData({
            "reachBottom.loadMore": !1,
            "reachBottom.loadAll": !0
          }), console.log(a.data.reachBottom.loadAll))
        } else e && 0 == e.length ? o.setData({
          "reachBottom.loadMore": !1,
          "reachBottom.loadAll": !0
        }) : o.setData({
          "reachBottom.loadMore": !0,
          "reachBottom.loadAll": !1
        })
      } else o.setData({
        "reachBottom.loadMore": !1,
        "reachBottom.loadAll": !1
      })
    }))
  },
  getCommonJobOptions: function() {
    var a = this;
    t.yzapi.getCommonJobOptions().then((function(t) {
      200 == t.code && a.setData({
        commonJobOptions: t.data
      })
    }))
  },
  receiveData: function(t) {
    var a = t.detail,
      o = a.query,
      e = a.list;
    this.setData({
      query_internship: o,
      internshipList: e
    })
  }
});