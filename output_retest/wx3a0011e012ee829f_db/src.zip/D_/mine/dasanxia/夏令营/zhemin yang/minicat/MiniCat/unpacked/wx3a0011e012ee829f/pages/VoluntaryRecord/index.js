var t = getApp();
Page({
  data: {
    statusHeight: 0,
    status: "",
    userHead: "",
    userActivity: {},
    topSelevt: 1,
    showMask: !1
  },
  onLoad: function(t) {
    var e = this;
    wx.getSystemInfo({
      success: function(t) {
        e.setData({
          statusHeight: t.statusBarHeight
        })
      }
    });
    var n = wx.getStorageSync("resumeInfo");
    this.setData({
      userHead: n.basic.head
    })
  },
  onReady: function() {},
  onShow: function() {
    this.getVolunteeringRecord()
  },
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {},
  getVolunteeringRecord: function() {
    var e = this,
      n = this.data.status;
    t.yzapi.getVolunteeringRecord(n).then((function(t) {
      e.setData({
        userActivity: t.data
      })
    }))
  },
  backBtn: function() {
    wx.navigateBack({
      delta: 0,
      success: function(t) {},
      fail: function(t) {},
      complete: function(t) {}
    })
  },
  changeSelect: function(t) {
    var e = t.target.dataset.index;
    this.setData({
      topSelevt: e,
      status: ["", "", 2, 3][e]
    }), this.onShow()
  },
  preventTouchMove: function() {},
  out: function() {
    this.setData({
      showMask: !1
    })
  },
  openRule: function() {
    this.setData({
      showMask: !0
    })
  }
});