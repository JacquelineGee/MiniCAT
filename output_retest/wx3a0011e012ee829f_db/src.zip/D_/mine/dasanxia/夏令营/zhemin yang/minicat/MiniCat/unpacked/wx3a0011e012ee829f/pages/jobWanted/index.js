var e = require("../../@babel/runtime/helpers/defineProperty"),
  t = getApp();
Page({
  data: {
    currentTab: 0,
    items: {},
    jobStatus: "",
    jobType: "",
    region: "",
    wage: "",
    selVal: "",
    internshipTime: "",
    isintern: !1
  },
  selSingle: function(e) {
    var t = this,
      a = e.currentTarget.dataset.index,
      i = t.data.items;
    t.data.selVal;
    i.forEach((function(e, n) {
      if (a == n) {
        i[a].checked = !0;
        var s = i[a].value;
        t.setData({
          selVal: s
        })
      } else i[n].checked = !1
    })), t.setData({
      items: i
    })
  },
  bindChange: function(e) {
    this.setData({
      currentTab: e.detail.current
    })
  },
  swichNav: function(e) {
    var t = parseInt(e.target.dataset.current) + 1;
    t >= 5 && (t = 4), this.setData({
      currentTab: t
    })
  },
  defaultSelected: function() {
    for (var e = this.data.items, t = 0, a = e.length; t < a; t++) e[t][0].checked = !0
  },
  radioChange: function(t) {
    for (var a, i = this.data.items[t.currentTarget.dataset.type], n = 0, s = i.length; n < s; ++n) i[n].checked = i[n].field == t.detail.value;
    5 == t.detail.value && 0 == this.data.currentTab ? this.setData({
      isintern: !0
    }) : 0 == this.data.currentTab && 5 != t.detail.value && this.setData({
      isintern: !1
    }), this.setData((e(a = {}, "items." + t.currentTarget.dataset.type, i), e(a, t.currentTarget.dataset.type, t.detail.value), a))
  },
  submitWant: function() {
    var e = wx.getStorageSync("openid");
    if (e) {
      var a = {
        jobStatus: Number(this.data.jobStatus),
        jobType: Number(this.data.jobType),
        region: Number(this.data.region),
        wage: Number(this.data.wage),
        internshipTime: ""
      };
      this.data.isintern && (a.internshipTime = String(this.data.internshipTime)), t.yzapi.editJobWanted(e, a).then((function(e) {
        200 == e.code ? (wx.showToast({
          title: "修改成功!",
          icon: "success",
          duration: 2e3
        }), setTimeout((function() {
          wx.navigateBack({
            url: "/pages/resume/index"
          })
        }), 1e3)) : wx.showToast({
          title: e.msg,
          icon: "none",
          duration: 2e3
        })
      }))
    } else wx.showToast({
      title: "未登录，请先登录!",
      icon: "none",
      duration: 2e3
    })
  },
  onLoad: function(e) {
    var a = this,
      i = wx.getStorageSync("openid");
    i ? t.yzapi.getUserOptions(i).then((function(t) {
      if (200 == t.code) {
        t.data.jobStatus.push({
          field: "999",
          value: "其他"
        }), t.data.jobStatus[e.jobStatus - 1].checked = !0, t.data.jobType[e.jobType - 1].checked = !0, t.data.region[e.region - 1].checked = !0, t.data.wage[e.wage - 1].checked = !0, t.data.internshipTime[e.internshipTime - 1].checked = !0;
        var i = a.data.isintern;
        5 == t.data.jobStatus[e.jobStatus - 1].field && (i = !0), a.setData({
          items: t.data,
          jobStatus: t.data.jobStatus[e.jobStatus - 1].field,
          jobType: t.data.jobType[e.jobType - 1].field,
          region: t.data.region[e.region - 1].field,
          wage: t.data.wage[e.wage - 1].field,
          internshipTime: t.data.internshipTime[e.internshipTime - 1].field,
          isintern: i
        })
      } else wx.showToast({
        title: "获取数据失败，请稍后重试!",
        icon: "none",
        duration: 2e3
      })
    })) : wx.showToast({
      title: "未登录，请稍后重试!",
      icon: "none",
      duration: 2e3
    })
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {}
});