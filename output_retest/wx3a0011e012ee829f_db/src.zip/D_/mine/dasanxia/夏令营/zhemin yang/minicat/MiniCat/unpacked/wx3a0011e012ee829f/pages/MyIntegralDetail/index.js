var t = getApp();
Page({
  data: {
    statusHeight: 0,
    topSelect: 1,
    timeSelect: "",
    startTime: "2020-1",
    endTime: "2022-12",
    query: {
      currentPage: 1,
      pageSize: 10,
      type: "",
      date: "2021-09"
    },
    dataList: []
  },
  onLoad: function(t) {
    var e = wx.getSystemInfoSync(),
      a = (wx.getStorageSync("resumeInfo"), new Date),
      n = a.getFullYear(),
      i = a.getMonth() + 1;
    this.setData({
      statusHeight: e.statusBarHeight,
      timeSelect: n + "年" + i + "月",
      "query.date": n + "-" + i
    })
  },
  onReady: function() {},
  onShow: function() {
    this.getMyPointList()
  },
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {},
  backBtn: function() {
    wx.navigateBack({
      delta: 0,
      success: function(t) {},
      fail: function(t) {},
      complete: function(t) {}
    })
  },
  tabSelect: function(t) {
    var e = t.target.dataset.index;
    this.data.query.type = ["", "", 1, 2][e], this.setData({
      topSelect: e,
      query: this.data.query
    }), this.onShow()
  },
  selectTime: function(t) {
    var e, a = t.detail.value.split("-");
    e = a[0] + "年" + a[1] + "月", this.data.query.date = t.detail.value, this.setData({
      timeSelect: e,
      query: this.data.query
    }), this.onShow()
  },
  getMyPointList: function() {
    var e = this;
    t.yzapi.getMyPointList(this.data.query).then((function(t) {
      200 == t.code && e.setData({
        dataList: t.data.data
      })
    }))
  }
});