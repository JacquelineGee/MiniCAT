Page({
  data: {
    currentTab: 0
  },
  clickTab: function(n) {
    if (this.data.currentTab === n.target.dataset.current) return !1;
    this.setData({
      currentTab: n.target.dataset.current
    })
  },
  onLoad: function(n) {},
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {}
});