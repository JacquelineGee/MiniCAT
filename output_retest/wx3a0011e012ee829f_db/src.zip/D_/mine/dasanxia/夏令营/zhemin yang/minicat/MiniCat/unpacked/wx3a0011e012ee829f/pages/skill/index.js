var t = getApp();
Page({
  data: {
    videoList: [{
      videoUrl: "http://wxsnsdy.tc.qq.com/105/20210/snsdyvideodownload?filekey=30280201010421301f0201690402534804102ca905ce620b1241b726bc41dcff44e00204012882540400&bizid=1023&hy=SH&fileparam=302c020101042530230204136ffd93020457e3c4ff02024ef202031e8d7f02030f42400204045a320a0201000400",
      titleImage: "https://res.wx.qq.com/wxdoc/dist/assets/img/0.4cb08bb4.jpg",
      time: "05:30",
      title: "江西理工大学线上技能培训",
      number: 1223
    }, {
      videoUrl: "http://wxsnsdy.tc.qq.com/105/20210/snsdyvideodownload?filekey=30280201010421301f0201690402534804102ca905ce620b1241b726bc41dcff44e00204012882540400&bizid=1023&hy=SH&fileparam=302c020101042530230204136ffd93020457e3c4ff02024ef202031e8d7f02030f42400204045a320a0201000400",
      titleImage: "https://res.wx.qq.com/wxdoc/dist/assets/img/0.4cb08bb4.jpg",
      time: "05:30",
      title: "江西理工大学线上技能培训",
      number: 1223
    }],
    _index: -1,
    skillList: [],
    query: {
      currentPage: 1,
      pageSize: 10
    },
    reachBottom: {
      loadIs: !1,
      loadMore: !1,
      loadAll: !1
    }
  },
  onLoad: function() {},
  onShow: function() {
    this.getSkillList()
  },
  onReachBottom: function() {
    var t = this;
    t.data.reachBottom.loadMore || (t.setData({
      "reachBottom.loadIs": !0,
      "reachBottom.loadMore": !0,
      "reachBottom.loadAll": !1
    }), setTimeout((function() {
      t.onShow()
    }), 2e3))
  },
  getSkillList: function() {
    var e = this,
      a = this,
      o = this.data.query;
    1 == this.data.query.currentPage && a.setData({
      "reachBottom.loadMore": !0,
      "reachBottom.loadAll": !1
    });
    var i = a.data.query.currentPage + 1;
    t.yzapi.getSkillsTrainingList(o.currentPage, o.pageSize).then((function(t) {
      if (200 == t.code) {
        var o = t.data.data;
        if (o && o.length > 0) {
          var r = a.data.skillList.concat(o);
          a.setData({
            "query.currentPage": i,
            skillList: r,
            "reachBottom.loadMore": !1
          }), o.length < e.data.query.pageSize && a.setData({
            "reachBottom.loadMore": !1,
            "reachBottom.loadAll": !0
          })
        } else o && 0 == o.length ? a.setData({
          "reachBottom.loadMore": !1,
          "reachBottom.loadAll": !0
        }) : a.setData({
          "reachBottom.loadMore": !0,
          "reachBottom.loadAll": !1
        })
      } else a.setData({
        "reachBottom.loadMore": !1,
        "reachBottom.loadAll": !1
      })
    }))
  },
  videoPlay: function(e) {
    var a = e.currentTarget.dataset.skillid;
    t.yzapi.getSkillsTrainingView(a);
    var o = e.currentTarget.dataset.id;
    this.setData({
      _index: o
    }), wx.createVideoContext(o + "").stop(), setTimeout((function() {
      wx.createVideoContext(o + "").play()
    }), 500)
  }
});