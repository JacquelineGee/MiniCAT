var t = require("../../@babel/runtime/helpers/defineProperty"),
  e = getApp();
Page({
  data: {
    workitem: {
      expeId: "",
      company: "",
      jobTitle: "",
      department: "",
      startTime: "2019-01",
      endTime: "2020-01"
    },
    skillStr: "",
    skills: [],
    skill: [],
    type1s: [],
    type2s: [],
    type: [0, 0],
    typeCode: [1, 1],
    positionType: 0,
    positionTypes: [],
    maxWordsNumbers: 50,
    currentWords: 0,
    information: "",
    show_value: !0,
    endDate: "2020-06",
    typeShow: !1,
    skillShow: !1,
    isedit: !1
  },
  checkboxChange: function(t) {
    for (var e = this.data.skills, i = t.detail.value, a = "", n = 0; n < i.length; n++) i[n] = parseInt(i[n]);
    for (var o = 0, s = e.length; o < s; ++o) {
      e[o].checked = !1;
      for (var l = 0, r = i.length; l < r; ++l)
        if (e[o].fieldId === i[l]) {
          a = a + e[o].name + ",", e[o].checked = !0;
          break
        }
    }
    a = a.substr(0, a.length - 1), this.setData({
      skills: e,
      skill: i,
      skillStr: a,
      skillShow: !0
    })
  },
  binCompany: function(e) {
    this.setData(t({}, "workitem.company", e.detail.value))
  },
  bindType: function() {
    this.setData({
      typeShow: !0
    })
  },
  bindSkillType: function() {
    this.setData({
      skillShow: !0
    })
  },
  bindSkillTypeNone: function() {
    this.setData({
      skillShow: !1
    })
  },
  bindTypeChange: function(e) {
    var i, a = e.detail.value;
    a[0] != this.data.type[0] && (a[1] = 0), this.setData((i = {
      type: a,
      type2s: this.data.type1s[a[0]].entry
    }, t(i, "typeCode[0]", this.data.type1s[a[0]].code), t(i, "typeCode[1]", this.data.type1s[a[0]].entry[a[1]].code), i))
  },
  closeTypeChoose: function() {
    this.setData({
      typeShow: !1
    })
  },
  bindPositionTypeChange: function(t) {
    var i = this,
      a = wx.getStorageSync("openid");
    if (a) {
      var n = parseInt(this.data.positionTypes[t.detail.value].field);
      e.yzapi.getJobSkills(a, n).then((function(e) {
        200 == e.code && i.setData({
          positionType: t.detail.value,
          skills: e.data,
          skillStr: "",
          skill: []
        })
      }))
    } else wx.showToast({
      title: "未登录,请先登录!",
      icon: "none",
      duration: 2e3
    })
  },
  binJobTitle: function(e) {
    this.setData(t({}, "workitem.jobTitle", e.detail.value))
  },
  getSkills: function(t) {
    var i = this,
      a = wx.getStorageSync("openid");
    if (a) {
      var n = parseInt(this.data.positionTypes[t].field);
      e.yzapi.getJobSkills(a, n).then((function(t) {
        if (200 == t.code) {
          for (var e = 0, a = t.data.length; e < a; ++e) {
            t.data[e].checked = !1;
            for (var n = 0, o = i.data.skill.length; n < o; ++n)
              if (t.data[e].fieldId === i.data.skill[n]) {
                t.data[e].checked = !0;
                break
              }
          }
          i.setData({
            skills: t.data
          })
        }
      }))
    }
  },
  bindSelectorChange: function(t) {
    this.setData({
      skill: t.detail.value,
      skillstr: t.detail.name
    })
  },
  bindDepartmentChange: function(e) {
    this.setData(t({}, "workitem.department", e.detail.value))
  },
  getDataBindTap: function(t) {
    var e = t.detail.value,
      i = parseInt(e.length);
    this.setData({
      currentWords: i,
      information: e
    })
  },
  bindDateChange: function(e) {
    this.setData(t({}, "workitem.startTime", e.detail.value))
  },
  bindDateChange2: function(e) {
    this.setData(t({}, "workitem.endTime", e.detail.value))
  },
  compareTime: function() {
    var t = this.data.workitem.startTime.replace(/-/g, "/");
    t += "/01 00:00";
    var e = this.data.workitem.endTime.replace(/-/g, "/");
    return e += "/01 00:00", new Date(t).getTime() - new Date(e).getTime() < 0
  },
  submitform: function() {
    if ("" == this.data.workitem.company) return wx.showToast({
      title: "请填写公司名称!",
      icon: "none",
      duration: 2e3
    }), !1;
    if ("" == this.data.workitem.jobTitle) return wx.showToast({
      title: "请填写职业名称!",
      icon: "none",
      duration: 2e3
    }), !1;
    if (!this.compareTime()) return wx.showToast({
      title: "请选择正确的在职时间!",
      icon: "none",
      duration: 2e3
    }), !1;
    var t = {
        expeId: this.data.workitem.expeId,
        company: this.data.workitem.company,
        induCode: this.data.typeCode[1],
        induParentCode: this.data.typeCode[0],
        jobTypeCode: this.data.positionTypes[this.data.positionType].field,
        jobTitle: this.data.workitem.jobTitle,
        department: this.data.workitem.department,
        jobDesc: this.data.information,
        startTime: this.data.workitem.startTime.replace(/\//g, "-"),
        endTime: this.data.workitem.endTime.replace(/\//g, "-"),
        labels: this.data.skill
      },
      i = wx.getStorageSync("openid");
    i ? e.yzapi.editExperience(i, t).then((function(t) {
      200 == t.code ? (wx.showToast({
        title: "修改成功!",
        icon: "success",
        duration: 2e3
      }), setTimeout((function() {
        wx.navigateBack({
          url: "/pages/resume/index"
        })
      }), 1e3)) : wx.showToast({
        title: t.msg,
        icon: "none",
        duration: 2e3
      })
    })) : wx.showToast({
      title: "未登录,请先登录!",
      icon: "none",
      duration: 2e3
    })
  },
  onLoad: function(t) {
    var i = this,
      a = new Date,
      n = a.getFullYear(),
      o = a.getMonth() + 1,
      s = n + "-" + (o = 1 == o.toString().length ? "0" + o : o.toString());
    this.setData({
      endDate: s,
      "workitem.endTime": s
    });
    var l = wx.getStorageSync("openid");
    l && (e.yzapi.getInduOptions(l).then((function(t) {
      200 == t.code ? i.setData({
        type1s: t.data,
        type2s: t.data[0].entry
      }) : wx.showToast({
        title: t.msg,
        icon: "none",
        duration: 2e3
      })
    })), e.yzapi.getJobTypeOptions(l).then((function(t) {
      200 == t.code ? i.setData({
        positionTypes: t.data
      }) : wx.showToast({
        title: "获取失败，请稍后重试!",
        icon: "none",
        duration: 2e3
      })
    })));
    var r = t.queryBean;
    if (r) {
      r = JSON.parse(r);
      for (var d = [], p = "", c = 0; c < r.skillLabels.length; c++) d.push(r.skillLabels[c].skillsCode), p = p + r.skillLabels[c].skillsName + ",";
      p = p.substr(0, p.length - 1), console.log(p), r.startTime = r.startTime.replace(/\./g, "-"), r.endTime = r.endTime.replace(/\./g, "-"), this.setData({
        workitem: r,
        information: r.jobDesc,
        currentWords: r.jobDesc.length,
        skill: d,
        skillStr: p,
        isedit: !0
      }), setTimeout((function() {
        for (var t = [0, 0], e = 0, a = 0; a < i.data.type1s.length; a++) {
          r.induParentName == i.data.type1s[a].name && (t[0] = a);
          for (var n = 0; n < i.data.type1s[a].entry.length; n++) r.induName == i.data.type1s[a].entry[n].name && (t[1] = n)
        }
        for (a = 0; a < i.data.positionTypes.length; a++)
          if (parseInt(r.jobTypeCode) == i.data.positionTypes[a].field) {
            i.data.positionTypes[a].field, e = a;
            break
          } i.setData({
          positionType: e,
          type2s: i.data.type1s[t[0]].entry,
          type: [t[0], t[1]]
        })
      }), 500)
    }
    setTimeout((function() {
      i.getSkills(i.data.positionType)
    }), 700)
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {},
  expeDelete: function() {
    var t = this.data.workitem.expeId;
    wx.showModal({
      title: "确认删除",
      content: "您确认删除该工作经历吗",
      success: function(i) {
        i.confirm ? e.yzapi.experienceDelect(t).then((function(t) {
          console.log(t), 200 == t.code ? wx.showToast({
            title: "删除成功",
            success: function() {
              setTimeout((function() {
                wx.navigateBack()
              }), 1e3)
            }
          }) : wx.showToast({
            title: t.msg,
            icon: "none",
            duration: 2e3
          })
        })) : i.cancel
      }
    })
  }
});