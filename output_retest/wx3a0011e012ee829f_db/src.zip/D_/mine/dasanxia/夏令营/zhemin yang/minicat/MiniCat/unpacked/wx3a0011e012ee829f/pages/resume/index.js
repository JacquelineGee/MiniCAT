var e = require("../../@babel/runtime/helpers/defineProperty"),
  t = getApp();
Page({
  data: {
    resumeInfo: {
      basic: {
        realName: "",
        head: "",
        gender: "",
        age: "",
        seniority: 0,
        habitation: "赣州",
        school: "",
        mobile: "",
        email: ""
      },
      resumeBasic: {
        description: "",
        jobStatuStr: "",
        jobTypeStr: "",
        jobStatus: 1,
        jobType: 1,
        region: 1,
        wage: 1
      },
      experiences: [],
      educations: []
    },
    isShow: !1,
    headicon: "",
    ischeck: !1
  },
  onLoad: function(e) {
    var t = this;
    wx.getStorage({
      key: "openid",
      success: function(e) {
        e.data && wx.getStorage({
          key: "userInfo",
          success: function(e) {
            console.log(e.data.avatarUrl), t.data.headicon = e.data.avatarUrl, t.setData({
              headicon: t.data.headicon
            })
          }
        })
      }
    })
  },
  editwork: function(e) {
    var t = e.currentTarget.dataset.workitem,
      i = JSON.stringify(t);
    wx.navigateTo({
      url: "/pages/addWorkExperience/index?queryBean=" + i
    })
  },
  editedu: function(e) {
    var t = e.currentTarget.dataset.eduitem,
      i = JSON.stringify(t);
    wx.navigateTo({
      url: "/pages/addSchoolExperience/index?queryBean=" + i
    })
  },
  editcerts: function(e) {
    var t = e.currentTarget.dataset.certsitem,
      i = JSON.stringify(t);
    wx.navigateTo({
      url: "/pages/awardWinning/index?queryBean=" + i
    })
  },
  onReady: function() {},
  onShow: function() {
    var i = this,
      a = wx.getStorageSync("openid");
    a ? t.yzapi.getUserInfo(a).then((function(t) {
      if (200 == t.code) wx.setStorageSync("resumeInfo", t.data), i.setData({
        resumeInfo: t.data,
        isShow: !0,
        ischeck: !1
      });
      else if (500217 == t.code) i.setData({
        ischeck: !0
      });
      else {
        wx.setStorageSync("resumeInfo", {});
        var a, n = wx.getStorageSync("userInfo");
        if (n) 1 == n.gender ? n.gender = "男" : 2 == n.gender ? n.gender = "女" : n.gender = "未知", i.setData((e(a = {
          isShow: !1
        }, "resumeInfo.basic.realName", n.nickName), e(a, "resumeInfo.basic.head", n.avatarUrl), e(a, "resumeInfo.basic.gender", n.gender), a))
      }
    })) : wx.showToast({
      title: "未登录,请先登录!",
      icon: "none",
      duration: 2e3
    })
  },
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {},
  iseidtempty: function() {
    this.data.ischeck && wx.showModal({
      title: "提示",
      content: "未完善个人信息将无法编写简历,请到个人信息页完善信息",
      success: function(e) {
        e.confirm && wx.navigateTo({
          url: "../editUserInfo/index"
        })
      }
    })
  },
  editUserInfo: function() {
    wx.navigateTo({
      url: "/pages/editUserInfo/index",
      success: function(e) {},
      fail: function(e) {},
      complete: function(e) {}
    })
  },
  editSelfDescribe: function() {
    this.data.ischeck ? this.iseidtempty() : wx.navigateTo({
      url: "/pages/editSelfDescribe/index?content=" + this.data.resumeInfo.resumeBasic.description
    })
  },
  jobWanted: function() {
    this.data.ischeck ? this.iseidtempty() : wx.navigateTo({
      url: "/pages/jobWanted/index?jobStatus=" + this.data.resumeInfo.resumeBasic.jobStatus + "&jobType=" + this.data.resumeInfo.resumeBasic.jobType + "&region=" + this.data.resumeInfo.resumeBasic.region + "&wage=" + this.data.resumeInfo.resumeBasic.wage + "&internshipTime=" + this.data.resumeInfo.resumeBasic.internshipTime
    })
  },
  addWorkExperience: function() {
    this.data.ischeck ? this.iseidtempty() : wx.navigateTo({
      url: "/pages/addWorkExperience/index"
    })
  },
  addSchoolExperience: function() {
    this.data.ischeck ? this.iseidtempty() : wx.navigateTo({
      url: "/pages/addSchoolExperience/index"
    })
  },
  awardWinning: function() {
    this.data.ischeck ? this.iseidtempty() : wx.navigateTo({
      url: "/pages/awardWinning/index"
    })
  }
});