var t = getApp();
Page({
  data: {
    value: "",
    indicatorDots: !0,
    vertical: !1,
    autoplay: !0,
    circular: !0,
    interval: 2e3,
    duration: 500,
    clearShow: !1,
    searchContent: "",
    focusSearch: !1,
    maskShow: !1,
    jobList: [],
    currentPage: 1,
    pageSize: 10,
    reachBottom: {
      loadIs: !1,
      loadMore: !1,
      loadAll: !1
    },
    flage: !1,
    query_lookjob: {
      currentPage: 1,
      pageSize: 10,
      region: "",
      wage: "",
      unitType: ""
    }
  },
  onLoad: function(t) {
    console.log(t.value), this.setData({
      value: t.value,
      searchContent: t.value
    }), this.getJobList()
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  receiveData: function(t) {
    var a = t.detail,
      e = a.query,
      o = a.list;
    this.setData({
      currentPage: 1,
      query_lookjob: e,
      jobList: o
    })
  },
  onReachBottom: function() {
    var t = this;
    t.data.reachBottom.loadMore || (t.setData({
      "reachBottom.loadIs": !0,
      "reachBottom.loadMore": !0,
      "reachBottom.loadAll": !1
    }), setTimeout((function() {
      t.getJobList()
    }), 2e3))
  },
  onShareAppMessage: function() {},
  getJobList: function() {
    var a = this,
      e = this;
    1 == this.data.currentPage && e.setData({
      "reachBottom.loadMore": !0,
      "reachBottom.loadAll": !1
    });
    var o = e.data.currentPage + 1;
    t.yzapi.getJobList(this.data.currentPage, this.data.pageSize, this.data.searchContent, this.data.query_lookjob.region, this.data.query_lookjob.wage, this.data.query_lookjob.unitType).then((function(t) {
      if (200 == t.code) {
        var r = t.data.data;
        if (r && r.length > 0) {
          var n = e.data.jobList.concat(r);
          e.setData({
            currentPage: o,
            jobList: n,
            "reachBottom.loadMore": !1
          }), r.length < a.data.pageSize && e.setData({
            "reachBottom.loadMore": !1,
            "reachBottom.loadAll": !0
          })
        } else r && 0 == r.length && 0 == e.data.jobList.length ? e.setData({
          "reachBottom.loadMore": !1,
          "reachBottom.loadAll": !1
        }) : r && 0 == r.length && 1 == e.data.currentPage || 0 == r.length ? e.setData({
          "reachBottom.loadMore": !1,
          "reachBottom.loadAll": !0
        }) : e.setData({
          "reachBottom.loadMore": !0,
          "reachBottom.loadAll": !1
        })
      } else e.setData({
        "reachBottom.loadMore": !1,
        "reachBottom.loadAll": !1
      })
    }))
  },
  search: function(t) {
    var a = t.detail.value;
    a.length > 0 ? this.setData({
      clearShow: !0
    }) : 0 == a.length && this.setData({
      clearShow: !1
    }), this.setData({
      searchContent: a,
      currentPage: 1,
      jobList: []
    }), this.getJobList()
  },
  clearSearch: function() {
    wx.navigateBack({
      delta: -1,
      success: function(t) {},
      fail: function(t) {},
      complete: function(t) {}
    })
  }
});