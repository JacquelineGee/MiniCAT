var t = getApp();
Page({
  data: {
    imgUrls: ["https://flyplan.obs.cn-north-4.myhuaweicloud.com/company/mini/index/banner3.png", "https://flyplan.obs.cn-north-4.myhuaweicloud.com/company/mini/index/banner1.png", "https://flyplan.obs.cn-north-4.myhuaweicloud.com/company/mini/index/banner2.png"],
    showAddressPicker: !1,
    area: "",
    slist: [],
    indicatorDots: !0,
    vertical: !1,
    autoplay: !0,
    circular: !0,
    interval: 2e3,
    duration: 500,
    clearShow: !1,
    searchContent: "",
    focusSearch: !1,
    maskShow: !1,
    jobList: [],
    currentPage: 1,
    pageSize: 6,
    reachBottom: {
      loadIs: !1,
      loadMore: !1,
      loadAll: !1
    },
    pdfloading: 1e5,
    statusBarHeight: 0
  },
  onLoad: function() {
    this.getSysInfo()
  },
  search: function(t) {
    var a = t.detail.value;
    a.length > 0 ? this.setData({
      clearShow: !0
    }) : 0 == a.length && this.setData({
      clearShow: !1
    }), this.setData({
      searchContent: a,
      currentPage: 1,
      jobList: []
    }), this.onShow()
  },
  clearSearch: function() {
    this.setData({
      clearShow: !1,
      searchContent: "",
      maskShow: !1,
      issearch: !0
    }), this.onShow()
  },
  focusInput: function() {
    this.setData({
      maskShow: !0
    })
  },
  blurInput: function() {
    this.setData({
      maskShow: !1
    })
  },
  changeIndicatorDots: function() {
    this.setData({
      indicatorDots: !this.data.indicatorDots
    })
  },
  changeAutoplay: function() {
    this.setData({
      autoplay: !this.data.autoplay
    })
  },
  intervalChange: function(t) {
    this.setData({
      interval: t.detail.value
    })
  },
  durationChange: function(t) {
    this.setData({
      duration: t.detail.value
    })
  },
  getJobList: function() {
    var a = this,
      e = this;
    1 == this.data.currentPage && e.setData({
      "reachBottom.loadMore": !0,
      "reachBottom.loadAll": !1
    });
    var o = e.data.currentPage + 1;
    t.yzapi.getJobList(this.data.currentPage, this.data.pageSize, this.data.searchContent).then((function(t) {
      if (200 == t.code) {
        var n = t.data.data;
        if (n && n.length > 0) {
          var i = e.data.jobList.concat(n);
          e.setData({
            currentPage: o,
            jobList: i,
            "reachBottom.loadMore": !1
          }), n.length < a.data.pageSize && e.setData({
            "reachBottom.loadMore": !1,
            "reachBottom.loadAll": !0
          })
        } else n && 0 == n.length ? e.setData({
          "reachBottom.loadMore": !1,
          "reachBottom.loadAll": !0
        }) : e.setData({
          "reachBottom.loadMore": !0,
          "reachBottom.loadAll": !1
        })
      } else e.setData({
        "reachBottom.loadMore": !1,
        "reachBottom.loadAll": !1
      })
    }))
  },
  onShow: function() {
    this.getJobList()
  },
  onPullDownRefresh: function() {},
  onReachBottom: function() {
    var t = this;
    t.data.reachBottom.loadMore || (t.setData({
      "reachBottom.loadIs": !0,
      "reachBottom.loadMore": !0,
      "reachBottom.loadAll": !1
    }), setTimeout((function() {
      t.getJobList()
    }), 2e3))
  },
  handlebanner: function(t) {
    var a = t.currentTarget.dataset.index;
    console.log(t.currentTarget.dataset.index), 1 == a && wx.navigateTo({
      url: "./pdfpage/index",
      success: function(t) {},
      fail: function(t) {},
      complete: function(t) {}
    })
  },
  commit: function(t) {
    var a = t.detail.value;
    a.length > 0 && wx.navigateTo({
      url: "./search_info/index?value=" + a,
      success: function(t) {},
      fail: function(t) {},
      complete: function(t) {}
    }), this.setData({
      searchContent: ""
    })
  },
  getSysInfo: function() {
    var t = this;
    wx.getSystemInfo({
      success: function(a) {
        t.setData({
          statusBarHeight: a.statusBarHeight
        })
      }
    })
  },
  navBack: function() {
    wx.navigateBack({
      delta: 0,
      fail: function() {
        wx.reLaunch({
          url: "/pages/index/index"
        })
      }
    })
  }
});