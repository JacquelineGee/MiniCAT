var t = getApp();
Page({
  data: {
    activitieList: [],
    query: {
      currentPage: 1,
      pageSize: 10,
      region: "",
      search: ""
    },
    query2: {
      currentPage: 1,
      pageSize: 10,
      region: "",
      search: ""
    },
    reachBottom: {
      loadIs: !1,
      loadMore: !1,
      loadAll: !1
    },
    flage: !0,
    start: "赣州市",
    slist: [],
    start1: "赣州市",
    slist1: [],
    isstart: !1,
    isInternship: 0,
    searchContent: "",
    topSelect: 2,
    activeList: [],
    searchMask: !1,
    clearShow: !1,
    clearShow1: !1
  },
  onLoad: function(a) {
    var e = this;
    t.yzapi.getCommonJobOptions().then((function(t) {
      200 == t.code && e.setData({
        slist: t.data.region,
        slist1: t.data.region
      })
    }))
  },
  onReady: function() {},
  onShow: function() {
    this.getActivitieList(), this.getlist2()
  },
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {
    console.log(1)
  },
  onReachBottom: function() {
    var t = this;
    t.data.reachBottom.loadMore || (t.setData({
      "reachBottom.loadIs": !0,
      "reachBottom.loadMore": !0,
      "reachBottom.loadAll": !1
    }), setTimeout((function() {
      t.onShow()
    }), 2e3))
  },
  onShareAppMessage: function() {},
  getActivitieList: function() {
    var a = this,
      e = this,
      o = this.data.query;
    1 == this.data.query.currentPage && e.setData({
      "reachBottom.loadMore": !0,
      "reachBottom.loadAll": !1
    });
    var s = e.data.query.currentPage + 1;
    t.yzapi.getActivitieList(o.currentPage, o.pageSize, o.region, o.search).then((function(t) {
      if (200 == t.code) {
        var o = t.data.data;
        if (o && o.length > 0) {
          var i = e.data.activitieList.concat(o);
          e.setData({
            "query.currentPage": s,
            activitieList: i,
            "reachBottom.loadMore": !1
          }), o.length < a.data.query.pageSize && (e.setData({
            "reachBottom.loadMore": !1,
            "reachBottom.loadAll": !0
          }), console.log(a.data.reachBottom.loadAll))
        } else o && 0 == o.length && 1 == e.data.query.currentPage ? e.setData({
          "reachBottom.loadMore": !1,
          "reachBottom.loadAll": !1
        }) : o && 0 == o.length ? e.setData({
          "reachBottom.loadMore": !1,
          "reachBottom.loadAll": !0
        }) : e.setData({
          "reachBottom.loadMore": !0,
          "reachBottom.loadAll": !1
        })
      } else e.setData({
        "reachBottom.loadMore": !1,
        "reachBottom.loadAll": !1
      })
    }))
  },
  opens: function(t) {
    switch (t.currentTarget.dataset.item) {
      case "1":
        this.data.isstart ? this.setData({
          isstart: !1
        }) : this.setData({
          isstart: !0
        })
    }
  },
  onclicks1: function(t) {
    var a = t.currentTarget.dataset.index - 1,
      e = (this.data.slist[a].name, t.currentTarget.dataset.index);
    2 == this.data.topSelect ? (this.data.query2.region = a + 1, this.setData({
      isstart: !1,
      isfinish: !1,
      isdates: !1,
      start: this.data.slist[a].name,
      finish: "目的地",
      "query2.currentPage": 1,
      "query2.region": e,
      lookJobList: []
    })) : (this.data.query.region = a + 1, this.setData({
      isstart: !1,
      isfinish: !1,
      isdates: !1,
      start1: this.data.slist[a].name,
      finish: "目的地",
      "query.currentPage": 1,
      "query.region": e,
      lookJobList: []
    })), this.onShow()
  },
  clearSearch: function() {
    2 == this.data.topSelect ? this.setData({
      clearShow: !1,
      "query2.search": "",
      "query2.currentPage": 1,
      lookJobList: []
    }) : this.setData({
      clearShow1: !1,
      "query.search": "",
      "query.currentPage": 1,
      lookJobList: []
    }), this.onShow()
  },
  search: function(a) {
    var e = a.detail.value;
    e.length > 0 ? this.setData({
      clearShow: !0
    }) : t.isEmpty(e) && this.setData({
      clearShow: !1
    }), 2 == this.data.topSelect && this.setData({
      "query2.search": e,
      "query2.currentPage": 1,
      lookJobList: []
    }), this.onShow()
  },
  search1: function(a) {
    var e = a.detail.value;
    e.length > 0 ? this.setData({
      clearShow1: !0
    }) : t.isEmpty(e) && this.setData({
      clearShow1: !1
    }), 2 == this.data.topSelect && this.setData({
      "query.search": e,
      "query.currentPage": 1,
      lookJobList: []
    }), this.onShow()
  },
  handleSelect: function(t) {
    var a = t.target.dataset.index;
    this.setData({
      topSelect: a
    })
  },
  getlist2: function() {
    var a = this,
      e = this,
      o = this.data.query2,
      s = o.region,
      i = o.currentPage,
      r = o.search;
    t.yzapi.getVolunteeringList(s, i, 1e4, r).then((function(t) {
      200 == t.code && (a.data.activeList = t.data.data, a.data.activeList.map((function(t) {
        t.title = t.title.replace(e.data.query2.search, '<span style="background-color: #FF9632;">'.concat(e.data.query2.search, "</span>"))
      })), a.setData({
        activeList: t.data.data
      }))
    }))
  },
  openSearcheMask: function() {
    this.setData({
      searchMask: !0
    })
  },
  closeSearchMask: function() {
    this.setData({
      searchMask: !1
    })
  },
  none: function() {},
  inputConfirm: function() {
    this.setData({
      searchMask: !1
    })
  },
  inputCancle: function() {
    2 == this.data.topSelect ? this.setData({
      "query2.search": "",
      searchMask: !1
    }) : this.setData({
      "query.search": "",
      searchMask: !1
    })
  }
});