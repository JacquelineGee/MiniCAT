var t = getApp();
Page({
  data: {
    imgUrls: ["https://flyplan.obs.myhuaweicloud.com/wechat/static/banner/find_job.png", "https://flyplan.obs.myhuaweicloud.com/wechat/static/banner/find_job.png", "https://flyplan.obs.myhuaweicloud.com/wechat/static/banner/find_job.png"],
    bannerurl: ["../../images/banner_szjg.png"],
    indicatorDots: !0,
    vertical: !1,
    autoplay: !0,
    circular: !0,
    interval: 2e3,
    duration: 500,
    tabs: ["地区", "类型", "薪资", "排序"],
    tabsList: [{
      key: "region",
      selectCode: 0,
      name: "地区",
      list: []
    }, {
      key: "workType",
      selectCode: 0,
      name: "类型",
      list: []
    }, {
      key: "wage",
      selectCode: 0,
      name: "薪资",
      list: []
    }],
    tabsSelect: {
      key: "",
      selectCode: 0,
      list: []
    },
    chooseTab: -1,
    types: ["全部", "见习", "兼职", "全职"],
    typeCurrent: 0,
    maskShow: !1,
    lookJobList: [],
    commonJobOptions: [],
    query_lookjob: {
      currentPage: 1,
      pageSize: 10,
      region: "",
      wage: "",
      workType: "",
      unitType: "",
      serch: ""
    },
    reachBottom: {
      loadIs: !1,
      loadMore: !1,
      loadAll: !1
    },
    title: "",
    flage: !0,
    start: "地区",
    slist: [],
    isstart: !1,
    isInternship: 0,
    searchContent: ""
  },
  onLoad: function(o) {
    var a = this;
    t.isEmpty(o.unitType) || this.setData({
      "query_lookjob.unitType": o.unitType,
      isInternship: 1
    }), t.isEmpty(o.workType) || this.setData({
      "query_lookjob.workType": o.workType
    }), console.log(o), this.titleselect(o.unitType), 10 == o.open && this.setData({
      flage: !1
    }), t.yzapi.getCommonJobOptions().then((function(t) {
      200 == t.code && (console.log(t.data.region), a.setData({
        slist: t.data.region
      }))
    }))
  },
  clickMask: function() {
    this.setData({
      maskShow: !1
    })
  },
  changeIndicatorDots: function() {
    this.setData({
      indicatorDots: !this.data.indicatorDots
    })
  },
  changeAutoplay: function() {
    this.setData({
      autoplay: !this.data.autoplay
    })
  },
  intervalChange: function(t) {
    this.setData({
      interval: t.detail.value
    })
  },
  durationChange: function(t) {
    this.setData({
      duration: t.detail.value
    })
  },
  onReady: function() {},
  onShow: function() {
    this.getLookJobList()
  },
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {
    var t = this;
    t.data.reachBottom.loadMore || (t.setData({
      "reachBottom.loadIs": !0,
      "reachBottom.loadMore": !0,
      "reachBottom.loadAll": !1
    }), setTimeout((function() {
      t.getLookJobList()
    }), 2e3))
  },
  onShareAppMessage: function() {},
  getInternshipList: function() {
    var o = this,
      a = this,
      e = this.data.query_lookjob;
    1 == this.data.query_lookjob.currentPage && a.setData({
      "reachBottom.loadMore": !0,
      "reachBottom.loadAll": !1
    });
    var i = a.data.query_lookjob.currentPage + 1;
    t.yzapi.getInternshipList(e.currentPage, e.pageSize, e.region, e.wage, e.unitType, e.search).then((function(t) {
      if (200 == t.code) {
        var e = t.data.data;
        if (e && e.length > 0) {
          var s = a.data.lookJobList.concat(e);
          a.setData({
            "query_lookjob.currentPage": i,
            lookJobList: s,
            "reachBottom.loadMore": !1
          }), e.length < o.data.query_lookjob.pageSize && a.setData({
            "reachBottom.loadMore": !1,
            "reachBottom.loadAll": !0
          })
        } else e && 0 == e.length && 0 == a.data.lookJobList.length ? a.setData({
          "reachBottom.loadMore": !1,
          "reachBottom.loadAll": !1
        }) : e && 0 == e.length && 1 == a.data.currentPage || 0 == e.length ? a.setData({
          "reachBottom.loadMore": !1,
          "reachBottom.loadAll": !0
        }) : a.setData({
          "reachBottom.loadMore": !0,
          "reachBottom.loadAll": !1
        })
      } else a.setData({
        "reachBottom.loadMore": !1,
        "reachBottom.loadAll": !1
      })
    }))
  },
  getLookJobList: function() {
    var o = this;
    if (1 == this.data.isInternship) return this.getInternshipList(), !0;
    var a = this,
      e = this.data.query_lookjob;
    1 == this.data.query_lookjob.currentPage && a.setData({
      "reachBottom.loadMore": !0,
      "reachBottom.loadAll": !1
    });
    var i = a.data.query_lookjob.currentPage + 1;
    t.yzapi.getLookJobList(e.currentPage, e.pageSize, e.region, e.wage, e.workType, e.unitType).then((function(t) {
      if (200 == t.code) {
        var e = t.data.data;
        if (e && e.length > 0) {
          var s = a.data.lookJobList.concat(e);
          a.setData({
            "query_lookjob.currentPage": i,
            lookJobList: s,
            "reachBottom.loadMore": !1
          }), e.length < o.data.query_lookjob.pageSize && a.setData({
            "reachBottom.loadMore": !1,
            "reachBottom.loadAll": !0
          })
        } else e && 0 == e.length ? a.setData({
          "reachBottom.loadMore": !1,
          "reachBottom.loadAll": !0
        }) : a.setData({
          "reachBottom.loadMore": !0,
          "reachBottom.loadAll": !1
        })
      } else a.setData({
        "reachBottom.loadMore": !1,
        "reachBottom.loadAll": !1
      })
    }))
  },
  receiveData: function(t) {
    var o = t.detail,
      a = o.query,
      e = o.list;
    this.setData({
      query_lookjob: a,
      lookJobList: e
    })
  },
  titleselect: function(t) {
    2 == t ? wx.setNavigationBarTitle({
      title: "市直机关"
    }) : 3 == t ? wx.setNavigationBarTitle({
      title: "国有企业"
    }) : 4 == t ? wx.setNavigationBarTitle({
      title: "民营企业"
    }) : 5 == t ? wx.setNavigationBarTitle({
      title: "县(市、区)"
    }) : 6 == t && wx.setNavigationBarTitle({
      title: "金融企业"
    })
  },
  opens: function(t) {
    switch (t.currentTarget.dataset.item) {
      case "1":
        this.data.isstart ? this.setData({
          isstart: !1
        }) : this.setData({
          isstart: !0
        })
    }
  },
  onclicks1: function(t) {
    var o = t.currentTarget.dataset.index - 1;
    this.data.slist[o].name;
    this.data.query_lookjob.region = o + 1;
    var a = t.currentTarget.dataset.index;
    this.setData({
      isstart: !1,
      isfinish: !1,
      isdates: !1,
      start: this.data.slist[o].name,
      finish: "目的地",
      "query_lookjob.currentPage": 1,
      "query_lookjob.region": a,
      lookJobList: []
    }), this.onShow()
  },
  clearSearch: function() {
    this.setData({
      clearShow: !1,
      "query_lookjob.search": "",
      "query_lookjob.currentPage": 1,
      lookJobList: []
    }), this.onShow()
  },
  search: function(t) {
    var o = t.detail.value;
    o.length > 0 ? this.setData({
      clearShow: !0
    }) : 0 == o.length && this.setData({
      clearShow: !1
    }), this.setData({
      "query_lookjob.search": o,
      "query_lookjob.currentPage": 1,
      lookJobList: []
    }), this.onShow()
  }
});