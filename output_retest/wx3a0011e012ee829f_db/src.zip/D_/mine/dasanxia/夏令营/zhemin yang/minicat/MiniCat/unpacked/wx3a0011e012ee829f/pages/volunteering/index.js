var t = getApp();
Page({
  data: {
    start: "赣州市",
    slist: [],
    query: {
      region: "",
      currentPage: 1,
      pageSize: 20,
      search: ""
    },
    activeList: []
  },
  onLoad: function(t) {
    wx.showShareMenu({
      withShareTicket: !0,
      menus: ["shareAppMessage", "shareTimeline"]
    })
  },
  onReady: function() {},
  onShow: function() {
    var e = this,
      a = this.data.query,
      n = a.region,
      i = a.currentPage,
      s = a.pageSize,
      r = a.search;
    t.yzapi.getCommonJobOptions().then((function(t) {
      200 == t.code && e.setData({
        slist: t.data.region
      })
    })), t.yzapi.getVolunteeringList(n, i, s, r).then((function(t) {
      200 == t.code && e.setData({
        activeList: t.data.data
      })
    }))
  },
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {
    return {
      title: "青年赣州志愿者活动列表",
      imageUrl: "../../images/banner_sy.png"
    }
  },
  onShareTimeline: function() {
    return {
      title: "青年赣州志愿者活动列表"
    }
  },
  opens: function(t) {
    switch (t.currentTarget.dataset.item) {
      case "1":
        this.data.isstart ? this.setData({
          isstart: !1
        }) : this.setData({
          isstart: !0
        })
    }
  },
  onclicks1: function(t) {
    var e = t.currentTarget.dataset.index - 1;
    this.data.slist[e].name;
    this.data.query.region = e + 1;
    var a = t.currentTarget.dataset.index;
    this.setData({
      isstart: !1,
      isfinish: !1,
      isdates: !1,
      start: this.data.slist[e].name,
      finish: "目的地",
      "query.currentPage": 1,
      "query.region": a,
      lookJobList: []
    }), this.onShow()
  },
  handleinput: function(t) {
    var e = t.detail.value;
    this.data.query.search = e, this.setData({
      query: this.data.query
    }), this.onShow()
  },
  handleconfirm: function() {
    this.onShow()
  },
  handleclean: function() {
    this.data.query.search = "", this.setData({
      query: this.data.query
    }), this.onShow()
  }
});