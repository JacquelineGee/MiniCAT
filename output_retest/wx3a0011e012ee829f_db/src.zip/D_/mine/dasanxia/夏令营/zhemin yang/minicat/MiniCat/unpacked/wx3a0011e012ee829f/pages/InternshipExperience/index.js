var t = getApp();
Page({
  data: {
    query: {
      type: 1,
      currentPage: 1,
      pageSize: 10
    },
    dataList: [],
    page: {},
    showMask: !1
  },
  onLoad: function(t) {},
  onReady: function() {},
  onShow: function() {
    this.getImpressionList()
  },
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {
    var t = this;
    t.data.reachBottom.loadMore || (t.setData({
      "reachBottom.loadIs": !0,
      "reachBottom.loadMore": !0,
      "reachBottom.loadAll": !1
    }), setTimeout((function() {
      t.getImpressionList()
    }), 2e3))
  },
  onShareAppMessage: function() {},
  getImpressionList: function() {
    var a = this,
      e = this,
      o = this.data.query,
      n = o.type,
      r = o.currentPage,
      s = o.pageSize;
    1 == this.data.currentPage && e.setData({
      "reachBottom.loadMore": !0,
      "reachBottom.loadAll": !1
    });
    var i = e.data.query.currentPage + 1;
    t.yzapi.getImpressionList(n, r, s, "").then((function(t) {
      if (200 == t.code) {
        var o = t.data.data;
        if (o && o.length > 0) {
          var n = e.data.dataList.concat(o);
          e.data.query.currentPage = i, e.setData({
            query: e.data.query,
            dataList: n,
            "reachBottom.loadMore": !1,
            page: t.data.page
          }), o.length < a.data.pageSize && e.setData({
            "reachBottom.loadMore": !1,
            "reachBottom.loadAll": !0
          })
        } else o && 0 == o.length ? e.setData({
          "reachBottom.loadMore": !1,
          "reachBottom.loadAll": !0
        }) : e.setData({
          "reachBottom.loadMore": !0,
          "reachBottom.loadAll": !1
        })
      } else e.setData({
        "reachBottom.loadMore": !1,
        "reachBottom.loadAll": !1
      })
    }))
  },
  liked: function(a) {
    var e = this,
      o = 1,
      n = a.currentTarget.dataset.impid;
    1 == a.currentTarget.dataset.selflikecount && (o = 2), t.yzapi.getImpressionPraise(o, n).then((function(a) {
      if (200 == a.code) {
        var o = e.data.dataList.length;
        t.yzapi.getImpressionList(1, 1, o, "").then((function(t) {
          e.setData({
            dataList: t.data.data
          })
        }))
      } else wx.showToast({
        title: a.msg,
        icon: "none",
        duration: 1500
      })
    }))
  },
  navMessage: function(t) {
    var a = t.currentTarget.dataset.index;
    wx.navigateTo({
      url: "../InternshipExperience_message/index?impId=" + a
    })
  },
  openMy: function() {
    this.setData({
      showMask: !0
    })
  },
  preventTouchMove: function() {},
  out: function() {
    this.setData({
      showMask: !1
    })
  }
});