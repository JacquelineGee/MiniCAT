Page({
  data: {
    maxWordsNumbers: 50,
    currentWords: 0,
    information: ""
  },
  getDataBindTap: function(n) {
    var t = n.detail.value,
      o = parseInt(t.length);
    this.setData({
      currentWords: o
    })
  },
  onLoad: function(n) {
    var t = Date.parse(new Date),
      o = new Date(t),
      e = o.getFullYear(),
      a = o.getMonth() + 1 < 10 ? "0" + (o.getMonth() + 1) : o.getMonth() + 1;
    console.log(e, a)
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {}
});