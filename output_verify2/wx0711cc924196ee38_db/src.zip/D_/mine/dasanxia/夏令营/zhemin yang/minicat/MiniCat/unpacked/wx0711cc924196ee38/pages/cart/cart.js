var t = require("../../config.js");
Page({
  data: {
    loadText: "加载中...",
    opacitys: .8,
    dpshow: !0,
    hidden: !1,
    nieig: "none",
    dall: [],
    carts: [],
    hasList: !1,
    totalPrice: 0,
    selectAllStatus: !0
  },
  onLoad: function(t) {
    wx.showShareMenu({
      withShareTicket: !0
    }), this.getdata()
  },
  getdata: function() {
    var e = this;
    wx.request({
      url: t.config.httpsPath + "Cart/cartList",
      data: {
        uid: wx.getStorageSync("uuid")
      },
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      method: "POST",
      success: function(t) {
        delete t.data.referer, delete t.data.state, console.log(t.data), e.setData({
          dall: t.data,
          carts: t.data.result,
          totalPrice: t.data.totalp,
          hidden: !0,
          opacitys: 0,
          dpshow: !1
        })
      },
      fail: function(t) {
        console.log("请求失败"), wx.showToast({
          title: "请求失败",
          icon: "loading",
          duration: 3e3
        })
      },
      complete: function() {
        console.log("complete"), wx.stopPullDownRefresh()
      }
    })
  },
  onChange: function() {
    var t = this;
    t.setData({
      nieig: "none" == t.data.nieig ? "block" : "none"
    })
  },
  onShow: function() {
    this.onLoad(), this.setData({
      hasList: !0
    })
  },
  selectList: function(t) {
    var e = t.currentTarget.dataset.index,
      a = this.data.carts,
      o = a[e].selected;
    a[e].selected = !o, this.setData({
      carts: a
    }), this.getTotalPrice(a)
  },
  deleteList: function(t) {
    var e = this;
    e.setData({
      nieig: "none" == e.data.nieig ? "block" : "none"
    });
    var a = t.currentTarget.dataset.index,
      o = this.data.carts;
    o.splice(a, 1), this.setData({
      carts: o
    }), o.length ? this.getTotalPrice() : this.setData({
      hasList: !1
    })
  },
  selectAll: function(t) {
    var e = this.data.selectAllStatus;
    e = !e;
    for (var a = this.data.carts, o = 0; o < a.length; o++) a[o].selected = e;
    this.setData({
      selectAllStatus: e,
      carts: a
    }), this.getTotalPrice(a)
  },
  addCount: function(t) {
    var e = t.currentTarget.dataset.index,
      a = this.data.carts,
      o = a[e].num;
    o += 1, a[e].num = o, this.setData({
      carts: a
    }), this.getTotalPrice()
  },
  delcartgoods: function(e) {
    var a = this;
    wx.showModal({
      title: "温馨提示",
      content: "您确定要将该商品移除购物车吗？",
      showCancel: !0,
      cancelText: "再想一想",
      confirmText: "确认删除",
      success: function(o) {
        if (o.confirm) wx.request({
          url: t.config.httpsPath + "Cart/delCart",
          data: {
            cart_id: e.currentTarget.dataset.cartid
          },
          header: {
            "Content-Type": "application/x-www-form-urlencoded"
          },
          method: "POST",
          success: function(t) {
            delete t.data.referer, delete t.data.state, console.log(t.data), a.setData({
              hidden: !0,
              opacitys: 0,
              dpshow: !1
            }), 200 == t.data.msg ? (wx.showToast({
              title: "移除成功",
              time: 1e3
            }), setTimeout(function() {
              a.onLoad()
            }, 1e3)) : (wx.showToast({
              title: "移除失败",
              time: 1e3
            }), setTimeout(function() {
              a.onLoad()
            }, 1e3))
          },
          fail: function(t) {
            console.log("请求失败"), wx.showToast({
              title: "请求失败",
              icon: "loading",
              duration: 3e3
            })
          },
          complete: function() {
            console.log("complete"), wx.stopPullDownRefresh()
          }
        });
        else if (o.cancel) return void console.log("用户点击取消")
      }
    })
  },
  changenum: function(e) {
    console.log(e);
    var a = this,
      o = e.currentTarget.dataset.gnum;
    if (o = parseInt(o), "add" == e.currentTarget.dataset.index) o += 1;
    else if ("redu" == e.currentTarget.dataset.index) {
      if (1 == o) return wx.showToast({
        title: "亲，不能再少了哦！"
      }), !1;
      o -= 1
    }
    a.setData({
      hidden: !1,
      opacitys: .8,
      dpshow: !0
    }), wx.request({
      url: t.config.httpsPath + "Cart/setCartGoods",
      data: {
        cart_id: e.currentTarget.dataset.cartid,
        num: o
      },
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      method: "POST",
      success: function(t) {
        delete t.data.referer, delete t.data.state, console.log(t.data), a.setData({
          dall: t.data.result,
          hidden: !0,
          opacitys: 0,
          dpshow: !1
        }), 200 == t.data.msg ? (wx.showToast({
          title: "编辑成功",
          time: 1e3
        }), a.onLoad()) : (wx.showToast({
          title: "编辑失败",
          time: 1e3
        }), a.onLoad())
      },
      fail: function(t) {
        console.log("请求失败"), wx.showToast({
          title: "请求失败",
          icon: "loading",
          duration: 3e3
        })
      },
      complete: function() {
        console.log("complete"), wx.stopPullDownRefresh()
      }
    })
  },
  getTotalPrice: function(t) {
    for (var e = t, a = 0, o = 0; o < e.length; o++) e[o].selected && (a += parseInt(e[o].goods_num) * e[o].goods_price);
    this.setData({
      carts: e,
      totalPrice: a
    })
  },
  cartojies: function() {
    for (var t = this, e = t.data.carts, a = [], o = 0; o < e.length; o++) e[o].selected && a.push(e[o].id);
    0 != a.length ? wx.navigateTo({
      url: "../jies2/jies2?cartid=" + a + "&totalp=" + t.data.totalPrice
    }) : wx.showToast({
      title: "请勾选要购买的商品"
    })
  }
});