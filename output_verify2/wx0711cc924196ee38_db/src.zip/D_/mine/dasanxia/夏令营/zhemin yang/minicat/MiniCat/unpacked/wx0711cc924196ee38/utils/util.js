function t(t) {
  return (t = t.toString())[1] ? t : "0" + t
}
module.exports = {
  formatTime: function(e) {
    var n = e.getFullYear(),
      r = e.getMonth() + 1,
      o = e.getDate(),
      u = e.getHours(),
      i = e.getMinutes(),
      g = e.getSeconds();
    return [n, r, o].map(t).join("/") + " " + [u, i, g].map(t).join(":")
  },
  getJsonLength: function(t) {
    var e = 0;
    for (var n in t) e++;
    return e
  }
};