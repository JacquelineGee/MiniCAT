var o = require("../../config.js");
Page({
  data: {
    loadText: "加载中...",
    opacitys: .8,
    dpshow: !0,
    hidden: !1,
    dall: []
  },
  onLoad: function(o) {
    wx.showShareMenu({
      withShareTicket: !0
    }), this.getdata(o.cid)
  },
  getdata: function(t) {
    var e = this;
    wx.request({
      url: o.config.httpsPath + "Goods/goodsList",
      data: {
        cat_id: t
      },
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      method: "POST",
      success: function(o) {
        delete o.data.referer, delete o.data.state, console.log(o.data.result), e.setData({
          dall: o.data.result,
          hidden: !0,
          opacitys: 0,
          dpshow: !1
        })
      },
      fail: function(o) {
        console.log("请求失败"), wx.showToast({
          title: "请求失败",
          icon: "loading",
          duration: 3e3
        })
      },
      complete: function() {
        console.log("complete"), wx.stopPullDownRefresh()
      }
    })
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {}
});