var o = require("../../config.js");
Page({
  data: {
    loadText: "加载中...",
    opacitys: .8,
    dpshow: !0,
    hidden: !1,
    dree: "none",
    num: null
  },
  onLoad: function(o) {
    console.log(o), this.setData({
      num: 1,
      isuse: o.isuse,
      ispay: o.ispay
    }), console.log(o), this.getdata(o.order_id)
  },
  getdata: function(e) {
    console.log(e);
    var t = this;
    wx.request({
      url: o.config.httpsPath + "User/getOrderDetail",
      data: {
        order_id: e,
        user_id: wx.getStorageSync("uuid")
      },
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      method: "POST",
      success: function(o) {
        delete o.data.referer, delete o.data.state, console.log(233334455), console.log(o.data), t.setData({
          dall: o.data.result,
          hidden: !0,
          opacitys: 0,
          dpshow: !1
        })
      },
      fail: function(o) {
        console.log("请求失败"), wx.showToast({
          title: "请求失败",
          icon: "loading",
          duration: 3e3
        })
      },
      complete: function() {
        console.log("complete"), wx.stopPullDownRefresh()
      }
    })
  },
  rightpay: function(e) {
    var t = this;
    wx.login({
      success: function(n) {
        console.log("立即付款请求后台-传值code"), n.code ? wx.request({
          url: o.config.httpsPath + "Shopping/payment",
          data: {
            order_id: e.currentTarget.dataset.orderid,
            code: n.code
          },
          header: {
            "Content-Type": "application/x-www-form-urlencoded"
          },
          method: "POST",
          success: function(o) {
            console.log("是统一下单方法返回值了"), console.log(o.data), wx.requestPayment({
              nonceStr: o.data.nonceStr,
              package: o.data.package,
              signType: o.data.signType,
              timeStamp: o.data.timeStamp,
              paySign: o.data.paySign,
              success: function(o) {
                console.log("调用成功"), t.paydata(e.currentTarget.dataset.orderid)
              },
              fail: function(o) {
                console.log("调用失败---"), console.log(o)
              }
            })
          }
        }) : console.log("获取用户登录态失败！" + n.errMsg)
      }
    })
  },
  paydata: function(e) {
    wx.request({
      url: o.config.httpsPath + "Shopping/paydata",
      data: {
        order_id: e,
        user_id: wx.getStorageSync("uuid")
      },
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      method: "POST",
      success: function(o) {
        console.log(233334455), wx.redirectTo({
          url: "../order1/order1?activeid=1"
        })
      },
      fail: function(o) {
        console.log("请求失败"), wx.showToast({
          title: "请求失败",
          icon: "loading",
          duration: 3e3
        })
      },
      complete: function() {
        console.log("complete"), wx.stopPullDownRefresh()
      }
    })
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {}
});