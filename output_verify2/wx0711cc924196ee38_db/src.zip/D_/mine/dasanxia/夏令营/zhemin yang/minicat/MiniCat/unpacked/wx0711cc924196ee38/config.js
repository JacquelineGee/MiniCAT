exports.config = {
  httpsPath: "https://dym.xcx023.com/dymshop/index.php/Api11/"
};