var e = require("../../config.js");
Page({
  data: {
    loadText: "加载中...",
    opacitys: .8,
    dpshow: !0,
    hidden: !1,
    dree: "none",
    num: null,
    pprice: null,
    dalladdr: [],
    dallgood: [],
    dall2: [],
    cartids: []
  },
  onLoad: function(e) {
    wx.showShareMenu({
      withShareTicket: !0
    }), e.dree, console.log(e), this.setData({
      num: e.number,
      pprice: e.totalp,
      cartids: e.cartid
    }), this.getdata(e), this.getdata2()
  },
  getdata: function(t) {
    var a = this;
    wx.request({
      url: e.config.httpsPath + "Cart/cartOrder",
      data: {
        user_id: wx.getStorageSync("uuid"),
        cart_id: t.cartid
      },
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      method: "POST",
      success: function(e) {
        delete e.data.referer, delete e.data.state, console.log(e.data.result), a.setData({
          dalladdr: e.data.result.user_addr,
          dallgood: e.data.result.goods,
          hidden: !0,
          opacitys: 0,
          dpshow: !1
        })
      },
      fail: function(e) {
        console.log("请求失败"), wx.showToast({
          title: "请求失败",
          icon: "loading",
          duration: 3e3
        })
      },
      complete: function() {
        console.log("complete"), wx.stopPullDownRefresh()
      }
    })
  },
  getdata2: function() {
    var t = this;
    wx.request({
      url: e.config.httpsPath + "User/getAddressList",
      data: {
        user_id: wx.getStorageSync("uuid")
      },
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      method: "POST",
      success: function(e) {
        delete e.data.referer, delete e.data.state, console.log(e.data), t.setData({
          dall2: e.data.result,
          hidden: !0,
          opacitys: 0,
          dpshow: !1
        })
      },
      fail: function(e) {
        console.log("请求失败"), wx.showToast({
          title: "请求失败",
          icon: "loading",
          duration: 3e3
        })
      },
      complete: function() {
        console.log("complete"), wx.stopPullDownRefresh()
      }
    })
  },
  onChange: function() {
    var e = this;
    e.setData({
      dree: "none" == e.data.dree ? "block" : "none"
    })
  },
  formSubmit: function(t) {
    var a = this;
    if (console.log("---------------uporder-----"), !t.detail.value.address_id) return wx.showToast({
      title: "未添加收货地址",
      icon: "loading",
      duration: 1e4
    }), void setTimeout(function() {
      wx.hideToast()
    }, 1e3);
    a.data.dall;
    var o = a.data.pprice;
    wx.request({
      url: e.config.httpsPath + "Cart/cartShop",
      data: {
        user_id: wx.getStorageSync("uuid"),
        total_amount: o,
        cart_id: a.data.cartids,
        address_id: t.detail.value.address_id,
        user_note: t.detail.value.user_note
      },
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      method: "POST",
      success: function(e) {
        delete e.data.referer, delete e.data.state, console.log("订单提交成功并返回值了"), console.log(e.data), a.setData({
          hidden: !0,
          opacitys: 0,
          dpshow: !1
        }), 200 == e.data.msg && wx.showModal({
          title: "温馨提示",
          content: "订单提交成功！",
          showCancel: !0,
          cancelText: "回到首页",
          confirmText: "前往付款",
          success: function(t) {
            t.confirm ? wx.redirectTo({
              url: "../pay/pay?order_id=" + e.data.result + "&ispay=0"
            }) : t.cancel && wx.switchTab({
              url: "../index/index"
            })
          }
        })
      },
      fail: function(e) {
        console.log("请求失败"), wx.showToast({
          title: "请求失败",
          icon: "loading",
          duration: 3e3
        })
      },
      complete: function() {
        console.log("complete"), wx.stopPullDownRefresh()
      }
    })
  },
  clickchose: function(e) {
    for (var t = this, a = 0; a < t.data.dall2.length; a++) ! function(a) {
      e.currentTarget.dataset.addid == t.data.dall2[a].address_id && (wx.showToast({
        title: "设置成功"
      }), setTimeout(function() {
        t.setData({
          dree: "none",
          dalladdr: t.data.dall2[a]
        })
      }, 1e3))
    }(a)
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {}
});