var o = require("../../config.js");
require("../../wxParse/wxParse.js");
Page({
  data: {
    indexone: "border-bottom:1px solid #3a85fc;",
    indexbot: 1,
    loadText: "加载中...",
    opacitys: .8,
    dpshow: !0,
    hidden: !1,
    dall: []
  },
  none: function() {
    this.setData({
      indexone: "border-bottom:none;",
      indextwo: "border-bottom:none;",
      indexthree: "border-bottom:none;",
      indexfour: "border-bottom:none;",
      indexfive: "border-bottom:none;",
      indexsix: "border-bottom:none;"
    })
  },
  onLoad: function() {
    wx.showShareMenu({
      withShareTicket: !0
    }), this.getdata()
  },
  getdata: function() {
    var e = this;
    wx.request({
      url: o.config.httpsPath + "Index/video",
      data: {},
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      method: "POST",
      success: function(o) {
        delete o.data.referer, delete o.data.state, console.log(o.data), e.setData({
          dall: o.data,
          hidden: !0,
          opacitys: 0,
          dpshow: !1
        })
      },
      fail: function(o) {
        console.log("请求失败"), wx.showToast({
          title: "请求失败",
          icon: "loading",
          duration: 3e3
        })
      },
      complete: function() {
        console.log("complete"), wx.stopPullDownRefresh()
      }
    })
  },
  one: function() {
    this.none(), this.setData({
      indexbot: 1,
      indexone: "border-bottom:1px solid #3a85fc;"
    })
  },
  two: function() {
    this.none(), this.setData({
      indexbot: 2,
      indextwo: "border-bottom:1px solid #3a85fc;"
    })
  }
});