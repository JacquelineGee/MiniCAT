var e = require("../../config.js"),
  t = require("../../wxParse/wxParse.js");
Page({
  data: {
    loadText: "加载中...",
    opacitys: .8,
    dpshow: !0,
    hidden: !1,
    data: []
  },
  onLoad: function(e) {
    wx.showShareMenu({
      withShareTicket: !0
    }), console.log(e.pid), this.getdata(e.pid)
  },
  getdata: function(o) {
    var a = this;
    wx.request({
      url: e.config.httpsPath + "Index/articleshow",
      data: {
        pid: o
      },
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      method: "POST",
      success: function(e) {
        delete e.data.referer, delete e.data.state, console.log(e.data), a.setData({
          data: e.data.article,
          hidden: !0,
          opacitys: 0,
          dpshow: !1
        }), t.wxParse("article", "html", e.data.article.content, a, 5)
      },
      fail: function(e) {
        console.log("请求失败"), wx.showToast({
          title: "请求失败",
          icon: "loading",
          duration: 3e3
        })
      },
      complete: function() {
        console.log("complete"), wx.stopPullDownRefresh()
      }
    })
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {}
});