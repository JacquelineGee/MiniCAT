var t = require("../../config.js"),
  a = require("../../wxParse/wxParse.js");
Page({
  data: {
    loadText: "加载中...",
    opacitys: .8,
    dpshow: !0,
    hidden: !1,
    data: []
  },
  onLoad: function(t) {
    wx.showShareMenu({
      withShareTicket: !0
    }), console.log(t.pid), this.getdata(t.pid)
  },
  getdata: function(e) {
    var o = this;
    wx.request({
      url: t.config.httpsPath + "Index/aboutus",
      data: {
        pid: e
      },
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      method: "POST",
      success: function(t) {
        delete t.data.referer, delete t.data.state, console.log(t.data), o.setData({
          data: t.data,
          hidden: !0,
          opacitys: 0,
          dpshow: !1
        }), a.wxParse("article", "html", t.data.aboutus[0].content, o, 5), a.wxParse("article1", "html", t.data.data1[0].content, o, 5), a.wxParse("article2", "html", t.data.data2[0].content, o, 5), a.wxParse("article3", "html", t.data.data3[0].content, o, 5)
      },
      fail: function(t) {
        console.log("请求失败"), wx.showToast({
          title: "请求失败",
          icon: "loading",
          duration: 3e3
        })
      },
      complete: function() {
        console.log("complete"), wx.stopPullDownRefresh()
      }
    })
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {}
});