var e = require("../../config.js");
Page({
  data: {
    loadText: "加载中...",
    opacitys: .8,
    dpshow: !0,
    hidden: !1,
    usermsg: [],
    tongji: []
  },
  callphone: function(e) {
    wx.makePhoneCall({
      phoneNumber: e.currentTarget.dataset.phone
    })
  },
  onLoad: function(e) {
    wx.showShareMenu({
      withShareTicket: !0
    });
    var t = this;
    wx.getStorage({
      key: "uuid",
      success: function(e) {
        t.getdata(e.data)
      }
    })
  },
  getdata: function(t) {
    var o = this;
    wx.request({
      url: e.config.httpsPath + "User/personal",
      data: {
        user_id: t
      },
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      method: "POST",
      success: function(e) {
        delete e.data.referer, delete e.data.state, console.log(e.data), o.setData({
          tongji: e.data.result,
          hidden: !0,
          opacitys: 0,
          dpshow: !1
        })
      },
      fail: function(e) {
        console.log("请求失败"), wx.showToast({
          title: "请求失败",
          icon: "loading",
          duration: 3e3
        })
      },
      complete: function() {
        console.log("complete"), wx.stopPullDownRefresh()
      }
    })
  },
  onReady: function() {
    var t = this;
    wx.getStorage({
      key: "userInfoo",
      success: function(o) {
        t.setData({
          usermsg: o.data
        }), wx.login({
          success: function(t) {
            console.log("打印头像等内容"), t.code ? wx.request({
              url: e.config.httpsPath + "User/getOpid",
              data: {
                code: t.code,
                name: o.data.nickName,
                avatar: o.data.avatarUrl
              },
              header: {
                "Content-Type": "application/x-www-form-urlencoded"
              },
              method: "POST",
              success: function(e) {
                console.log("res.data++++++++++++++++++++++++++"), console.log(e.data), wx.setStorageSync("uuid", e.data.uid)
              }
            }) : console.log("获取用户登录态失败！" + t.errMsg)
          }
        })
      }
    })
  },
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {}
});