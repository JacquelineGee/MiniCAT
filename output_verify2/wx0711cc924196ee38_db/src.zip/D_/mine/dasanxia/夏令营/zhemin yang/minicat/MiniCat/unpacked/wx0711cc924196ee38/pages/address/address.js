var e = require("../../config.js");
Page({
  data: {
    loadText: "加载中...",
    opacitys: .8,
    dpshow: !0,
    hidden: !1,
    dall: []
  },
  onLoad: function(e) {
    wx.showShareMenu({
      withShareTicket: !0
    }), this.getdata()
  },
  getdata: function() {
    var t = this;
    wx.request({
      url: e.config.httpsPath + "User/getAddressList",
      data: {
        user_id: wx.getStorageSync("uuid")
      },
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      method: "POST",
      success: function(e) {
        delete e.data.referer, delete e.data.state, console.log(e.data), t.setData({
          dall: e.data.result,
          hidden: !0,
          opacitys: 0,
          dpshow: !1
        })
      },
      fail: function(e) {
        console.log("请求失败"), wx.showToast({
          title: "请求失败",
          icon: "loading",
          duration: 3e3
        })
      },
      complete: function() {
        console.log("complete"), wx.stopPullDownRefresh()
      }
    })
  },
  checkdefault: function(t) {
    var o = this;
    wx.getStorage({
      key: "uuid",
      success: function(s) {
        wx.request({
          url: e.config.httpsPath + "User/setdefaultadd",
          data: {
            address_id: t.currentTarget.dataset.addid,
            uid: s.data
          },
          header: {
            "Content-Type": "application/x-www-form-urlencoded"
          },
          method: "POST",
          success: function(e) {
            console.log("checkdefault修改默认地址"), 200 == e.data.msg && (wx.showToast({
              title: "修改成功"
            }), setTimeout(function() {
              o.onLoad()
            }, 1e3))
          }
        })
      }
    })
  },
  deladdr: function(t) {
    var o = this;
    console.log(t), wx.showModal({
      title: "温馨提示",
      content: "您确定要删除该收货地址吗？",
      showCancel: !0,
      cancelText: "再想一想",
      confirmText: "确认删除",
      success: function(s) {
        if (s.confirm) wx.request({
          url: e.config.httpsPath + "User/delAddress",
          header: {
            "Content-Type": "application/x-www-form-urlencoded"
          },
          method: "POST",
          data: {
            address_id: t.currentTarget.dataset.addrid,
            user_id: wx.getStorageSync("uuid")
          },
          success: function(e) {
            console.log(e.data), 500 == e.data.msg ? wx.showToast({
              title: "默认地址不允许删除"
            }) : 200 == e.data.msg && (wx.showToast({
              title: "删除成功"
            }), o.onLoad())
          }
        });
        else if (s.cancel) return void console.log("用户点击取消")
      }
    })
  },
  onReady: function() {},
  setaddress: function(e) {
    var t = this;
    wx.getSetting({
      success: function(e) {
        e.authSetting["scope.address"] ? wx.chooseAddress({
          success: function(e) {
            console.log("用户已经同意小程序使用地址功能"), console.log(e), t.setData({
              newaddr: e
            }), t.saveaddress(e)
          }
        }) : wx.authorize({
          scope: "scope.address",
          success: function() {
            wx.chooseAddress({
              success: function(e) {
                console.log("新用户第一次进入"), console.log(e), t.saveaddress(e)
              }
            })
          }
        })
      }
    })
  },
  saveaddress: function(t) {
    var o = this;
    wx.request({
      url: e.config.httpsPath + "User/addAddress",
      method: "POST",
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      data: {
        user_id: wx.getStorageSync("uuid"),
        consignee: t.userName,
        zipcode: t.postalCode,
        province: t.provinceName,
        city: t.cityName,
        district: t.countyName,
        address: t.detailInfo,
        mobile: t.telNumber
      },
      succcess: function(e) {
        console.log("成功了")
      },
      fail: function() {
        console.log("失败了")
      }
    }), o.onLoad()
  },
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {}
});