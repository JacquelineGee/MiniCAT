var t = require("../../config.js"),
  e = require("../../wxParse/wxParse.js");
getApp();
Page({
  data: {
    loadText: "加载中...",
    opacitys: .8,
    dpshow: !0,
    hidden: !1,
    dall: []
  },
  onLoad: function() {
    wx.showShareMenu({
      withShareTicket: !0
    }), this.getdata()
  },
  getdata: function() {
    var a = this;
    wx.request({
      url: t.config.httpsPath + "Index/pro_xuanc",
      data: {},
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      method: "POST",
      success: function(t) {
        delete t.data.referer, delete t.data.state, console.log("请求首页数据成功"), console.log(t.data), a.setData({
          dall: t.data,
          hidden: !0,
          opacitys: 0,
          dpshow: !1
        }), e.wxParse("article1", "html", t.data.pro_xuanc[1].content, a, 5), e.wxParse("article2", "html", t.data.pro_xuanc[0].content, a, 5), e.wxParse("article3", "html", t.data.jk_dounai[1].content, a, 5), e.wxParse("article4", "html", t.data.jk_dounai[0].content, a, 5)
      },
      fail: function(t) {
        console.log("请求失败"), wx.showToast({
          title: "请求失败",
          icon: "loading",
          duration: 3e3
        })
      },
      complete: function() {
        console.log("complete"), wx.stopPullDownRefresh()
      }
    })
  }
});