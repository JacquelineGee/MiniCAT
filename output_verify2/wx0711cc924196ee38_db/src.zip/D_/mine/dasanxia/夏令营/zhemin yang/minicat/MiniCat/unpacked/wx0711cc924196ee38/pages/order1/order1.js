var e = require("../../config.js");
Page({
  data: {
    loadText: "加载中...",
    opacitys: .8,
    dpshow: !0,
    hidden: !1,
    tabs: [
      ["全部", "all"],
      ["待付款", "waitepay"],
      ["待发货", "waitfh"],
      ["待收货", "waitsh"]
    ],
    activeIndex: 0,
    sliderOffset: 0,
    sliderLeft: 0,
    dall: [],
    activeid1: []
  },
  onLoad: function(e) {
    wx.showShareMenu({
      withShareTicket: !0
    });
    var t = this;
    t.setData({
      activeIndex: e.activeid
    }), console.log(t.data.activeIndex), console.log("传值赋值搜索确定查询"), console.log(t.data.tabs[e.activeid][1]), wx.getStorage({
      key: "uuid",
      success: function(a) {
        t.getdata(a.data, t.data.tabs[e.activeid][1])
      }
    })
  },
  getdata: function(t) {
    var a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
      o = this;
    console.log(a), wx.request({
      url: e.config.httpsPath + "User/getOrderList",
      data: {
        user_id: t,
        were: a
      },
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      method: "POST",
      success: function(e) {
        delete e.data.referer, delete e.data.state, console.log("远程请求返回值了11"), console.log(e.data), o.setData({
          dall: e.data.result,
          hidden: !0,
          opacitys: 0,
          dpshow: !1
        })
      },
      fail: function(e) {
        console.log("请求失败"), wx.showToast({
          title: "请求失败",
          icon: "loading",
          duration: 3e3
        })
      },
      complete: function() {
        console.log("complete"), wx.stopPullDownRefresh()
      }
    })
  },
  tabClick: function(e) {
    var t = this;
    t.setData({
      opacitys: .8,
      dpshow: !0,
      hidden: !1
    }), wx.getStorage({
      key: "uuid",
      success: function(a) {
        t.getdata(a.data, e.currentTarget.dataset.tpe)
      }
    }), t.setData({
      sliderOffset: e.currentTarget.offsetLeft,
      activeIndex: e.currentTarget.dataset.id
    })
  },
  quxiaodd: function(t) {
    var a = this;
    wx.showModal({
      title: "温馨提示",
      content: "您确定要取消该订单吗？订单取消之后所选商品将重新选购",
      showCancel: !0,
      cancelText: "再想一想",
      confirmText: "确认取消",
      success: function(o) {
        if (o.confirm) wx.getStorage({
          key: "uuid",
          success: function(o) {
            wx.request({
              url: e.config.httpsPath + "User/delOrder",
              header: {
                "Content-Type": "application/x-www-form-urlencoded"
              },
              method: "POST",
              data: {
                user_id: o.data,
                order_id: t.currentTarget.dataset.id
              },
              success: function(e) {
                console.log("订单取消请求返回值了"), console.log(e.data), 200 == e.data.msg && (wx.showToast({
                  title: "订单取消成功"
                }), console.log(23333333), console.log(a.data.activeIndex), a.setData({
                  activeid1: {
                    activeid: a.data.activeIndex
                  }
                }), setTimeout(function() {
                  a.onLoad(a.data.activeid1)
                }, 1e3))
              }
            })
          }
        });
        else if (o.cancel) return !0
      }
    })
  },
  isok: function(t) {
    var a = this;
    wx.showModal({
      title: "温馨提示",
      content: "是否收货",
      showCancel: !0,
      cancelText: "否",
      confirmText: "是",
      success: function(o) {
        if (o.confirm) wx.request({
          url: e.config.httpsPath + "User/orderConfirm",
          data: {
            order_id: t.currentTarget.dataset.id,
            user_id: wx.getStorageSync("uuid")
          },
          header: {
            "Content-Type": "application/x-www-form-urlencoded"
          },
          method: "POST",
          success: function(e) {
            delete e.data.referer, delete e.data.state, console.log(2323), console.log(e.data), 1 == e.data.status ? (a.setData({
              activeid1: {
                activeid: 3
              }
            }), setTimeout(function() {
              a.onLoad(a.data.activeid1)
            }, 500)) : console.log(e.data)
          },
          fail: function(e) {
            console.log("请求失败"), wx.showToast({
              title: "请求失败",
              icon: "loading",
              duration: 3e3
            })
          }
        });
        else if (o.cancel) return !0
      }
    })
  },
  isth: function(e) {
    0 == e.currentTarget.dataset.code || 2 == e.currentTarget.dataset.code ? wx.navigateTo({
      url: "../customer/customer?order_id=" + e.currentTarget.dataset.id + "&code=" + e.currentTarget.dataset.code
    }) : wx.showModal({
      title: "温馨提示",
      content: "是否申请退货",
      showCancel: !0,
      cancelText: "否",
      confirmText: "是",
      success: function(t) {
        if (t.confirm) wx.navigateTo({
          url: "../customer/customer?order_id=" + e.currentTarget.dataset.id + "&code=" + e.currentTarget.dataset.code
        });
        else if (t.cancel) return !0
      }
    })
  },
  isth1: function(t) {
    var a = this;
    wx.showModal({
      title: "温馨提示",
      content: "是否申请退货",
      showCancel: !0,
      cancelText: "否",
      confirmText: "是",
      success: function(o) {
        if (o.confirm) wx.request({
          url: e.config.httpsPath + "User/return_goods",
          data: {
            order_id: t.currentTarget.dataset.id,
            user_id: wx.getStorageSync("uuid")
          },
          header: {
            "Content-Type": "application/x-www-form-urlencoded"
          },
          method: "POST",
          success: function(e) {
            delete e.data.referer, delete e.data.state, 1 == e.data.status ? (wx.showToast({
              title: e.data.msg,
              icon: "success",
              duration: 2e3
            }), a.setData({
              activeid1: {
                activeid: 0
              }
            }), setTimeout(function() {
              a.onLoad(a.data.activeid1)
            }, 500)) : console.log(e.data)
          },
          fail: function(e) {
            console.log("请求失败"), wx.showToast({
              title: "请求失败",
              icon: "loading",
              duration: 3e3
            })
          }
        });
        else if (o.cancel) return !0
      }
    })
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {}
});