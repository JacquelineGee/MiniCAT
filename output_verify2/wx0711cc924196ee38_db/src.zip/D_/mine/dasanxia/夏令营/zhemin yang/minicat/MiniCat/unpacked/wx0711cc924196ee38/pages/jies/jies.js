var e = require("../../config.js");
Page({
  data: {
    loadText: "加载中...",
    opacitys: .8,
    dpshow: !0,
    hidden: !1,
    dree: "none",
    num: null,
    pprice: null,
    dalladdr: [],
    dallgood: [],
    dall2: []
  },
  onLoad: function(o) {
    console.log(e.config.httpsPath), console.log(2333333), wx.showShareMenu({
      withShareTicket: !0
    }), o.dree, console.log(o), this.setData({
      num: o.number,
      cuid1: o.cuid1,
      cuid2: o.cuid2,
      pprice: o.pprice
    }), console.log(o), console.log(123456), this.getdata(o), this.getdata2()
  },
  getdata: function(o) {
    var t = this;
    console.log(o), console.log(123), wx.request({
      url: e.config.httpsPath + "Cart/shopOder",
      data: {
        uid: wx.getStorageSync("uuid"),
        cuid2: o.cuid2,
        cuid1: o.cuid1,
        gid: o.gid
      },
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      method: "POST",
      success: function(e) {
        delete e.data.referer, delete e.data.state, console.log(987654), console.log(e.data.result), t.setData({
          dalladdr: e.data.result.user_addr,
          dallgood: e.data.result.info,
          hidden: !0,
          opacitys: 0,
          dpshow: !1
        })
      },
      fail: function(e) {
        console.log("请求失败"), wx.showToast({
          title: "请求失败",
          icon: "loading",
          duration: 3e3
        })
      },
      complete: function() {
        console.log("complete"), wx.stopPullDownRefresh()
      }
    })
  },
  getdata2: function() {
    var o = this;
    wx.request({
      url: e.config.httpsPath + "User/getAddressList",
      data: {
        user_id: wx.getStorageSync("uuid")
      },
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      method: "POST",
      success: function(e) {
        delete e.data.referer, delete e.data.state, console.log(e.data), o.setData({
          dall2: e.data.result,
          hidden: !0,
          opacitys: 0,
          dpshow: !1
        })
      },
      fail: function(e) {
        console.log("请求失败"), wx.showToast({
          title: "请求失败",
          icon: "loading",
          duration: 3e3
        })
      },
      complete: function() {
        console.log("complete"), wx.stopPullDownRefresh()
      }
    })
  },
  onChange: function() {
    var e = this;
    e.setData({
      dree: "none" == e.data.dree ? "block" : "none"
    })
  },
  formSubmit: function(o) {
    var t = this;
    if (console.log("---------------uporder-----"), !o.detail.value.address_id) return wx.showToast({
      title: "未添加收货地址",
      icon: "loading",
      duration: 1e4
    }), void setTimeout(function() {
      wx.hideToast()
    }, 1e3);
    t.setData({
      hidden: !1,
      opacitys: .8,
      dpshow: !0,
      loadText: "订单创建中..."
    });
    var a = t.data.dallgood,
      d = t.data.pprice;
    wx.request({
      url: e.config.httpsPath + "Cart/uporder",
      data: {
        user_id: wx.getStorageSync("uuid"),
        total_amount: d,
        goods_id: a[0].goods_id,
        cuid1: t.data.cuid1,
        cuid2: t.data.cuid2,
        num: t.data.num,
        address_id: o.detail.value.address_id,
        user_note: o.detail.value.user_note
      },
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      method: "POST",
      success: function(e) {
        delete e.data.referer, delete e.data.state, console.log(e), console.log("订单提交成功并返回值了"), console.log(e.data), t.setData({
          hidden: !0,
          opacitys: 0,
          dpshow: !1
        }), 200 == e.data.msg && wx.showModal({
          title: "温馨提示",
          content: "订单提交成功！",
          showCancel: !0,
          cancelText: "回到首页",
          confirmText: "前往付款",
          success: function(o) {
            console.log(o), o.confirm ? wx.redirectTo({
              url: "../pay/pay?order_id=" + e.data.result + "&ispay=0"
            }) : o.cancel && wx.switchTab({
              url: "../index/index"
            })
          }
        })
      },
      fail: function(e) {
        console.log("请求失败"), wx.showToast({
          title: "请求失败",
          icon: "loading",
          duration: 3e3
        })
      },
      complete: function() {
        console.log("complete"), wx.stopPullDownRefresh()
      }
    })
  },
  clickchose: function(e) {
    for (var o = this, t = 0; t < o.data.dall2.length; t++) ! function(t) {
      e.currentTarget.dataset.addid == o.data.dall2[t].address_id && (wx.showToast({
        title: "设置成功"
      }), setTimeout(function() {
        o.setData({
          dree: "none",
          dalladdr: o.data.dall2[t]
        })
      }, 1e3))
    }(t)
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {}
});