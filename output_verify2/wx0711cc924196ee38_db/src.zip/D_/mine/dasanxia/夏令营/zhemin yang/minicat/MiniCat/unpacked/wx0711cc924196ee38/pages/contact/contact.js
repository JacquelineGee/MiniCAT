getApp();
var e = require("../../config.js"),
  t = require("../../wxParse/wxParse.js");
Page({
  data: {
    info: []
  },
  onLoad: function(e) {
    wx.showShareMenu({
      withShareTicket: !0
    }), this.getdata()
  },
  getdata: function() {
    var o = this;
    wx.request({
      url: e.config.httpsPath2 + "Index/info",
      data: {},
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      method: "POST",
      success: function(e) {
        delete e.data.referer, delete e.data.state, console.log(e.data), o.setData({
          info: e.data
        }), t.wxParse("article", "html", e.data.post_content, o, 5)
      },
      fail: function(e) {
        console.log("请求失败"), wx.showToast({
          title: "请求失败",
          icon: "loading",
          duration: 3e3
        })
      },
      complete: function() {
        console.log("complete"), wx.stopPullDownRefresh()
      }
    })
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {}
});