function e(e, o, t) {
  return o in e ? Object.defineProperty(e, o, {
    value: t,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : e[o] = t, e
}
getApp();
var o, t = require("../../config.js"),
  a = require("../../wxParse/wxParse.js"),
  n = require("../../utils/util.js"),
  s = [];
Page({
  data: (o = {
    tcolor: "#7b7b7c",
    collecturl: "/imgs/foot_07.png",
    collectname: "收藏",
    collectstt: 0,
    loadText: "加载中...",
    opacitys: .8,
    dpshow: !0,
    hidden: !1,
    tp0: 0,
    tp1: 1,
    jspricegg0: 0,
    jspricegg1: 0,
    totalpp: null,
    ison: null,
    ison2: null,
    dall: [],
    cartotal: 0
  }, e(o, "collectstt", 0), e(o, "showView", "none"), e(o, "nieig", "none"), e(o, "shownine", "none"), e(o, "Toast", !0), e(o, "indexone", "border-bottom:2px solid #f0524f;color:#f0524f"), e(o, "indexbot", 1), e(o, "num", 1), e(o, "minusStatus", "disabled"), o),
  one: function() {
    this.setData({
      indexbot: 1,
      indexone: "border-bottom:2px solid #f0524f;color:#f0524f",
      indextwo: "border-bottom:none;color:#1e1e1e"
    })
  },
  two: function() {
    this.setData({
      indexbot: 2,
      indextwo: "border-bottom:2px solid #f0524f;color:#f0524f",
      indexone: "border-bottom:none;color:#1e1e1e"
    })
  },
  changecolor0: function(e) {
    var o = this,
      t = e.currentTarget.dataset.guiid,
      a = e.currentTarget.dataset.id;
    wx.getStorage({
      key: "ispp0",
      success: function(e) {
        console.log("取到了" + a), console.log(e), console.log("--------第二次----ison-------------"), t == e.data.ggid ? o.setData({
          ison: a
        }) : (console.log("ispp0有值，且当前点击类别不是存储的对应类别"), console.log(a))
      },
      fail: function(e) {
        console.log(t + "---没取到，走的fail"), console.log(e), console.log("--------第一次--fail--ison-------------"), wx.setStorage({
          key: "ispp0",
          data: {
            ggid: t
          }
        }), o.setData({
          ison: a
        }), console.log(o.data.ison)
      }
    }), wx.setStorage({
      key: "cup0",
      data: {
        ggid: t,
        cuid: a
      }
    }), wx.getStorage({
      key: "cup0",
      success: function(e) {},
      fail: function() {
        wx.setStorage({
          key: "cup0",
          data: {
            ggid: t,
            cuid: a
          }
        })
      }
    })
  },
  changecolor1: function(e) {
    var o = this,
      t = e.currentTarget.dataset.guiid,
      a = e.currentTarget.dataset.id;
    wx.getStorage({
      key: "ispp1",
      success: function(e) {
        console.log("取到了" + a), console.log(e), console.log("--------第二次--success--ison2-------------"), t == e.data.ggid ? o.setData({
          ison2: a
        }) : (console.log("ispp1有值，且当前点击类别不是存储的对应类别"), console.log(a))
      },
      fail: function(e) {
        console.log(t + "---没取到，走的fail"), console.log(e), wx.setStorage({
          key: "ispp1",
          data: {
            ggid: t
          }
        }), o.setData({
          ison2: a
        }), console.log("--------第一次--fail--ison2-------------"), console.log(o.data.ison2)
      }
    }), wx.getStorage({
      key: "cup1",
      success: function(e) {},
      fail: function() {
        wx.setStorage({
          key: "cup1",
          data: {
            ggid: t,
            cuid: a
          }
        })
      }
    })
  },
  formSubmit2: function(e) {
    var o = this;
    o.data.dall.spec_goods_price;
    if (console.log("////////////////////////////////"), o.data.ison) a = o.data.ison;
    else var a = 0;
    if (o.data.ison2) n = o.data.ison2;
    else var n = 0;
    wx.request({
      url: t.config.httpsPath + "Goods/changePrice_gg",
      data: {
        gid: o.data.dall.goods.goods_id,
        number: e.detail.value.numall,
        cuid1: a,
        cuid2: n
      },
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      method: "POST",
      success: function(t) {
        console.log(1111111), console.log(t), o.setData({
          totalpp: t.data.price,
          hidden: !1,
          loadText: "处理中...."
        }), setTimeout(function() {
          o.setData({
            totalpp: t.data.price,
            hidden: !0
          }), wx.navigateTo({
            url: "../jies/jies?pprice=" + t.data.price + "&number=" + e.detail.value.numall + "&gid=" + o.data.dall.goods.goods_id + "&cuid1=" + a + "&cuid2=" + n
          })
        }, 1e3)
      }
    })
  },
  addcarchangecolor0: function(e) {
    var o = this;
    o.setData({
      jspricegg0: e.currentTarget.dataset.id
    });
    var t = e.currentTarget.dataset.guiid,
      a = e.currentTarget.dataset.id;
    wx.getStorage({
      key: "ispp0",
      success: function(e) {
        console.log("取到了" + a), console.log(e), console.log("--------第二次----ison-------------"), t == e.data.ggid ? o.setData({
          ison: a
        }) : (console.log("ispp0有值，且当前点击类别不是存储的对应类别"), console.log(a))
      },
      fail: function(e) {
        console.log(t + "---没取到，走的fail"), console.log(e), console.log("--------第一次--fail--ison-------------"), wx.setStorage({
          key: "ispp0",
          data: {
            ggid: t
          }
        }), o.setData({
          ison: a
        }), console.log(o.data.ison)
      }
    }), wx.setStorage({
      key: "cup0",
      data: {
        ggid: t,
        cuid: a
      }
    }), wx.getStorage({
      key: "cup0",
      success: function(e) {},
      fail: function() {
        wx.setStorage({
          key: "cup0",
          data: {
            ggid: t,
            cuid: a
          }
        })
      }
    })
  },
  addcarchangecolor1: function(e) {
    var o = this;
    o.setData({
      jspricegg1: e.currentTarget.dataset.id
    });
    var t = e.currentTarget.dataset.guiid,
      a = e.currentTarget.dataset.id;
    wx.getStorage({
      key: "ispp1",
      success: function(e) {
        console.log("取到了" + a), console.log(e), console.log("--------第二次--success--ison2-------------"), t == e.data.ggid ? o.setData({
          ison2: a
        }) : (console.log("ispp1有值，且当前点击类别不是存储的对应类别"), console.log(a))
      },
      fail: function(e) {
        console.log(t + "---没取到，走的fail"), console.log(e), wx.setStorage({
          key: "ispp1",
          data: {
            ggid: t
          }
        }), o.setData({
          ison2: a
        }), console.log("--------第一次--fail--ison2-------------"), console.log(o.data.ison2)
      }
    }), wx.getStorage({
      key: "cup1",
      success: function(e) {},
      fail: function() {
        wx.setStorage({
          key: "cup1",
          data: {
            ggid: t,
            cuid: a
          }
        })
      }
    })
  },
  formSubmit: function(e) {
    var o = this;
    if (o.data.ison) a = o.data.ison;
    else var a = 0;
    if (o.data.ison2) n = o.data.ison2;
    else var n = 0;
    wx.request({
      url: t.config.httpsPath + "Goods/changePrice_gg",
      data: {
        gid: o.data.dall.goods.goods_id,
        number: e.detail.value.numall,
        cuid1: a,
        cuid2: n
      },
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      method: "POST",
      success: function(s) {
        o.setData({
          totalpp: s.data.price,
          hidden: !1,
          loadText: "处理中...."
        }), wx.request({
          url: t.config.httpsPath + "Cart/addtocart",
          data: {
            uid: wx.getStorageSync("uuid"),
            gid: o.data.dall.goods.goods_id,
            number: e.detail.value.numall,
            cuid1: a,
            cuid2: n
          },
          header: {
            "Content-Type": "application/x-www-form-urlencoded"
          },
          method: "POST",
          success: function(e) {
            o.setData({
              hidden: !0
            }), 200 == e.data.msg ? (wx.showToast({
              title: "添加购物车成功",
              image: "../../imgs/success.png"
            }), setTimeout(function() {
              wx.switchTab({
                url: "../cart/cart"
              })
            }, 1e3)) : (wx.showToast({
              title: "添加购物车失败，请重新添加",
              image: "../../imgs/error.png"
            }), setTimeout(function() {
              wx.switchTab({
                url: "../index/index"
              })
            }, 1e3))
          }
        })
      }
    })
  },
  onLoad: function(e) {
    wx.showShareMenu({
      withShareTicket: !0
    }), wx.removeStorage({
      key: "ispp1"
    }), wx.removeStorage({
      key: "ispp0"
    }), wx.removeStorage({
      key: "cup1"
    }), wx.removeStorage({
      key: "cup0"
    });
    var o = this;
    e.nieig, e.shownine, e.showView, wx.getStorage({
      key: "userInfoo",
      success: function(e) {
        wx.login({
          success: function(o) {
            console.log("打印头像等内容"), o.code ? wx.request({
              url: t.config.httpsPath + "User/getOpid",
              data: {
                code: o.code,
                name: e.data.nickName,
                avatar: e.data.avatarUrl
              },
              header: {
                "Content-Type": "application/x-www-form-urlencoded"
              },
              method: "POST",
              success: function(e) {
                console.log("res.data++++++++++++++++++++++++++"), console.log(e.data), wx.setStorageSync("uuid", e.data.uid)
              }
            }) : console.log("获取用户登录态失败！" + o.errMsg)
          }
        })
      }
    }), o.getdata(e.gid), wx.getStorage({
      key: "uuid",
      success: function(a) {
        wx.request({
          url: t.config.httpsPath + "Goods/checkcollect",
          data: {
            gid: e.gid,
            uid: a.data
          },
          header: {
            "Content-Type": "application/x-www-form-urlencoded"
          },
          method: "POST",
          success: function(e) {
            console.log("收藏状态查询"), 1 == e.data[0] && o.setData({
              collecturl: "/imgs/foot_077.png",
              collectname: "已收藏",
              collectstt: 1
            })
          }
        })
      }
    })
  },
  getdata: function(e) {
    var o = this;
    wx.request({
      url: t.config.httpsPath + "Goods/goodsInfo",
      data: {
        gid: e
      },
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      method: "POST",
      success: function(e) {
        delete e.data.referer, delete e.data.state, console.log("打印商品详情所有信息返回值"), console.log(e.data.result), o.setData({
          gallaryview: e.data.result.gallery,
          totalpp: e.data.result.goods.shop_price,
          dall: e.data.result,
          hidden: !0,
          opacitys: 0,
          dpshow: !1
        }), console.log("打印商品的goods_content"), a.wxParse("article", "html", e.data.result.goods.goods_content, o, 5)
      },
      fail: function(e) {
        console.log("请求失败"), wx.showToast({
          title: "请求失败",
          icon: "loading",
          duration: 3e3
        })
      },
      complete: function() {
        console.log("complete"), wx.stopPullDownRefresh()
      }
    })
  },
  onChange: function() {
    var e = this;
    e.setData({
      nieig: "none" == e.data.nieig ? "block" : "none"
    })
  },
  onChangeShow: function(e) {
    var o = this;
    o.setData({
      shownine: "none" == o.data.shownine ? "block" : "none"
    }), this.showname(e)
  },
  onChangeShowState: function(e) {
    var o = this;
    o.setData({
      showView: "none" == o.data.showView ? "block" : "none"
    }), this.showname(e)
  },
  bindMinus: function(e) {
    var o = this,
      t = o.data.num;
    t > 1 && t--;
    var a = t <= 1 ? "disabled" : "normal",
      n = o.data.jspricegg0;
    parseInt(n) > 0 ? o.diyfunc(e.currentTarget.dataset.gprice) : o.setData({
      totalpp: parseFloat(e.currentTarget.dataset.gprice) * t
    }), o.setData({
      num: t,
      minusStatus: a
    })
  },
  bindPlus: function(e) {
    var o = this,
      t = o.data.num,
      a = ++t < 1 ? "disabled" : "normal",
      n = o.data.jspricegg0;
    console.log("选过规格了，下面是规格值"), console.log(n), parseInt(n) > 0 ? o.diyfunc() : o.setData({
      totalpp: parseFloat(e.currentTarget.dataset.gprice) * t
    }), o.setData({
      num: t,
      minusStatus: a
    })
  },
  bindManual: function(e) {
    var o = this,
      t = e.detail.value,
      a = o.data.jspricegg0;
    console.log("输入框输入值事件"), console.log(a), parseInt(a) > 0 ? o.diyfunc() : o.setData({
      totalpp: parseFloat(e.currentTarget.dataset.gprice) * t
    }), this.setData({
      num: t
    })
  },
  beforeppp: function(e) {
    var o = this,
      t = o.data.jspricegg0;
    t = parseInt(t);
    var a = o.data.jspricegg1;
    a = parseInt(a);
    var s = o.data.dall.goods.narr;
    console.log("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"), console.log(t), 1 == n.getJsonLength(s) ? (o.setData({
      jspricegg0: e.currentTarget.dataset.id
    }), o.diyfunc2(e.currentTarget.dataset.id)) : 2 == n.getJsonLength(s) && (0 == t || 0 == a ? console.log("有一个为0") : o.diyfunc())
  },
  diyfunc: function() {
    var e = this,
      o = (e.data.jspricegg0, e.data.jspricegg1, e.data.dall.goods.shop_price);
    wx.request({
      url: t.config.httpsPath + "Goods/beforeprice",
      data: {
        gg0: e.data.jspricegg0,
        gg1: e.data.jspricegg1,
        gid: e.data.dall.goods.goods_id
      },
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      method: "POST",
      success: function(t) {
        console.log("Goods/beforeprice返回数据了"), console.log(t), e.setData({
          totalpp: (parseFloat(o) + parseFloat(t.data.price)) * e.data.num
        })
      },
      fail: function() {
        console.log("Goods/beforeprice请求失败")
      }
    })
  },
  diyfunc2: function(e) {
    var o = this,
      a = o.data.dall.goods.shop_price;
    wx.request({
      url: t.config.httpsPath + "Goods/beforeprice",
      data: {
        gg0: e,
        gg1: 0,
        gid: o.data.dall.goods.goods_id
      },
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      method: "POST",
      success: function(e) {
        console.log("Goods/beforeprice返回数据了"), console.log(e.data), o.setData({
          totalpp: (parseFloat(a) + parseFloat(e.data.price)) * o.data.num
        })
      }
    })
  },
  onShow: function() {
    var e = this;
    wx.request({
      url: t.config.httpsPath + "Cart/cart_goods_num",
      data: {
        uid: wx.getStorageSync("uuid")
      },
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      method: "POST",
      success: function(o) {
        delete o.data.referer, delete o.data.state, console.log("+++++++++++++++++++++++++++++++++++++++++++++"), console.log(o.data), e.setData({
          cartotal: o.data
        })
      },
      fail: function(e) {
        console.log("请求失败"), wx.showToast({
          title: "请求失败",
          icon: "loading",
          duration: 3e3
        })
      },
      complete: function() {
        console.log("complete"), wx.stopPullDownRefresh()
      }
    })
  },
  changecollect: function(e) {
    var o = this;
    wx.getStorage({
      key: "uuid",
      success: function(a) {
        wx.request({
          url: t.config.httpsPath + "Goods/collectGoods",
          header: {
            "Content-Type": "application/x-www-form-urlencoded"
          },
          method: "POST",
          data: {
            type: e.currentTarget.dataset.stt,
            uid: a.data,
            gid: o.data.dall.goods.goods_id
          },
          success: function(e) {
            console.log("===================================="), console.log(e), 200 == e.data.msg ? (o.setData({
              collecturl: "/imgs/foot_077.png",
              collectname: "已收藏",
              collectstt: 1,
              tcolor: "#e20c26"
            }), wx.showToast({
              title: "已收藏"
            })) : 202 == e.data.msg ? (o.setData({
              collecturl: "/imgs/foot_07.png",
              collectname: "收藏",
              collectstt: 0,
              tcolor: "#7b7b7c"
            }), wx.showToast({
              title: "已取消收藏"
            })) : (o.setData({
              collecturl: "/imgs/foot_07.png",
              collectname: "收藏",
              collectstt: 0,
              tcolor: "#7b7b7c"
            }), wx.showToast({
              title: "收藏失败"
            }))
          },
          fail: function() {
            wx.showToast({
              title: "修改失败了"
            })
          }
        })
      },
      fail: function() {
        console.log("失败了")
      }
    })
  },
  clickview: function(e) {
    for (var o = this, t = 0; t < o.data.gallaryview.length; t++) s[t] = o.data.gallaryview[t].image_url;
    wx.previewImage({
      current: s[e.currentTarget.dataset.oncur],
      urls: s
    })
  },
  onUnload: function() {
    wx.removeStorage({
      key: "ispp1"
    }), wx.removeStorage({
      key: "ispp0"
    }), wx.removeStorage({
      key: "cup1"
    }), wx.removeStorage({
      key: "cup0"
    })
  },
  showname: function(e) {
    if (console.log(e.detail.userInfo), "1" == wx.getStorageSync("imgstatus")) {
      var o = wx.getStorageSync("openid");
      wx.request({
        url: t.config.httpsPath + "User/upname",
        data: {
          openid: o,
          name: e.detail.userInfo.nickName,
          avatarUrl: e.detail.userInfo.avatarUrl
        },
        header: {
          "Content-Type": "application/x-www-form-urlencoded"
        },
        method: "POST",
        success: function(e) {
          console.log("res2.data++++++++++++++++++++++++++"), console.log(e)
        }
      })
    }
  }
});