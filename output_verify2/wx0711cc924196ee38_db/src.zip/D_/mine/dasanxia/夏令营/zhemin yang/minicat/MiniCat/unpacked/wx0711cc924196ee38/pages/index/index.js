var e = require("../../config.js"),
  t = (require("../../wxParse/wxParse.js"), getApp());
Page({
  data: {
    loadText: "加载中...",
    opacitys: .8,
    dpshow: !0,
    hidden: !1,
    dall: [],
    dall1: [],
    ison: !1,
    movies: [],
    name: "",
    nizz: "",
    indexbot: 2
  },
  onLoad: function() {
    console.log(t.globalData), wx.showShareMenu({
      withShareTicket: !0
    }), this.getdata(), this.getdata1();
    var o = !0;
    o ? wx.login({
      success: function(t) {
        console.log(t), wx.request({
          url: e.config.httpsPath + "User/getOpid",
          data: {
            code: t.code
          },
          header: {
            "Content-Type": "application/x-www-form-urlencoded"
          },
          method: "POST",
          success: function(e) {
            console.log("res2.data++++++++++++++++++++++++++"), console.log(e.data), wx.setStorageSync("uuid", e.data.uid), wx.setStorageSync("openid", e.data.openid), wx.setStorageSync("imgstatus", e.data.imgstatus)
          }
        })
      }
    }) : wx.openSetting({
      success: function(e) {
        e && 1 == e.authSetting["scope.address"] && (o = !0, wx.getUserInfo({
          withCredentials: !1,
          success: function(e) {
            console.info("2成功获取用户返回数据"), console.info(e.userInfo)
          },
          fail: function() {
            console.info("2授权失败返回数据")
          }
        }))
      },
      fail: function() {
        console.info("设置失败返回数据")
      }
    })
  },
  getdata: function() {
    var t = this;
    wx.request({
      url: e.config.httpsPath + "Index/index",
      data: {},
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      method: "POST",
      success: function(e) {
        delete e.data.referer, delete e.data.state, console.log("请求首页数据成功"), console.log(e.data), t.setData({
          dall: e.data,
          hidden: !0,
          opacitys: 0,
          dpshow: !1
        })
      },
      fail: function(e) {
        console.log("请求失败"), wx.showToast({
          title: "请求失败",
          icon: "loading",
          duration: 3e3
        })
      },
      complete: function() {
        console.log("complete"), wx.stopPullDownRefresh()
      }
    })
  },
  getdata1: function() {
    var t = this;
    wx.request({
      url: e.config.httpsPath + "Index/yangsheng",
      data: {},
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      method: "POST",
      success: function(e) {
        delete e.data.referer, delete e.data.state, console.log(e.data), t.setData({
          ysdall: e.data.news,
          hidden: !0,
          opacitys: 0,
          dpshow: !1
        })
      },
      fail: function(e) {
        console.log("请求失败"), wx.showToast({
          title: "请求失败",
          icon: "loading",
          duration: 3e3
        })
      },
      complete: function() {
        console.log("complete"), wx.stopPullDownRefresh()
      }
    })
  },
  share2: function() {
    wx.showShareMenu({
      withShareTicket: !0
    })
  },
  navigateto_city: function(e) {
    wx.switchTab({
      url: "../list/list",
      success: function(e) {},
      fail: function() {},
      complete: function() {}
    })
  }
});