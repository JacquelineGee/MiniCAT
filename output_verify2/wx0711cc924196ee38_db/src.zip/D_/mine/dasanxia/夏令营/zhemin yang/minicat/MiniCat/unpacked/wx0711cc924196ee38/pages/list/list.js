var a = require("../../config.js");
Page({
  data: {
    loadText: "加载中...",
    opacitys: .8,
    dpshow: !0,
    hidden: !1,
    dall: [],
    defaultimg: a.config.staticImagePath,
    navall: [],
    curNav: 1,
    curIndex: 0
  },
  onLoad: function(t) {
    wx.showShareMenu({
      withShareTicket: !0
    });
    var e = this;
    console.log("--------------------------"), console.log(t), wx.request({
      url: a.config.httpsPath + "Index/goods_category",
      method: "POST",
      data: {},
      header: {
        Accept: "application/json"
      },
      success: function(a) {
        console.log(a.data);
        for (var o = 0; o < a.data.length; o++) t.catid == a.data[o].tree.id && e.setData({
          curNav: a.data[o].id,
          curIndex: o
        });
        e.setData({
          hidden: !0,
          opacitys: 0,
          dpshow: !1,
          navall: a.data
        }), console.log("+++++++++success+++++++++++"), console.log(t)
      }
    })
  },
  switchRightTab: function(a) {
    console.log(a);
    var t = a.target.dataset.id,
      e = parseInt(a.target.dataset.index);
    this.setData({
      curNav: t,
      curIndex: e
    })
  }
});