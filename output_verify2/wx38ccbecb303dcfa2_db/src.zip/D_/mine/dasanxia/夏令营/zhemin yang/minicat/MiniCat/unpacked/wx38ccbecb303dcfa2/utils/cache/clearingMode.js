var util = require('../util.js');
var app = getApp();
var clearingMode;

function init() {
  if (app.cache.clearingMode) clearingMode = app.cache.clearingMode;
  if (!clearingMode || clearingMode.length == 0) {
    var url = util.getQueryUrl(app.globalData.url + "/api/services/CodeData/CodeData/GetAll", {
      searchGroup: {
        rules: [{
          field: "codeDataTypeId",
          value: 200013
        }]
      },
      pageSize: 2000
    });
    util.request(url).then(function(res) {
      if (res.success) {
        clearingMode = res.result.items;
        app.cache.clearingMode = clearingMode;
      }
    }, function(error) {
      wx.showModal({
        title: '错误信息',
        content: error.error.message,
        showCancel: false
      });
    });
  }
}

function getNameById(uid) {
  var data = getclearingModeById(uid);
  if (!data || data == null) return uid + "";
  return data.name;
}

function getclearingModeById(uid) {
  clearingMode = app.cache.clearingMode;
  return clearingMode ? clearingMode.find(function(x) {
    return x.id == uid;
  }) : null;
}
module.exports = {
  getclearingModeById: getclearingModeById,
  getNameById: getNameById,
  init: init
};