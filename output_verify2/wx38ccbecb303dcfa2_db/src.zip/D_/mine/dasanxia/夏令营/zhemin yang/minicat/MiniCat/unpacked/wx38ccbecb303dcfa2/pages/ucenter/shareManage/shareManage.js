var _defineProperty2 = require("../../../@babel/runtime/helpers/defineProperty");
var _data;
var util = require('../../../utils/util.js');
var user = require('../../../utils/cache/user.js');
var WxParse = require('../../../lib/wxParse/wxParse.js');
var app = getApp();
var content = "";
var timer;
var recorderManager = wx.getRecorderManager();
var bgMusic = wx.getBackgroundAudioManager();
Page({
  data: (_data = {
    path: app.globalData.url,
    userName: "",
    userId: "",
    id: "",
    status: 0,
    introduce: "",
    startTime: "",
    tempFilePath: "",
    movie: [],
    movies: []
  }, _defineProperty2(_defineProperty2(_defineProperty2(_defineProperty2(_defineProperty2(_defineProperty2(_defineProperty2(_defineProperty2(_defineProperty2(_defineProperty2(_data, "path", app.globalData.url), "msrc", ""), "time", 0), "h", '00'), "m", '00'), "s", '00'), "setInter", ''), "num", 1), "fileSize", 0), "score", 0), _defineProperty2(_defineProperty2(_defineProperty2(_defineProperty2(_defineProperty2(_defineProperty2(_defineProperty2(_data, "readingContentId", ""), "open", false), "src", ""), "srcs", ""), "IsbgMusic", false), "MinReadingSec", 60), "MaxReadingSec", 500)),
  //格式时间
  FormatTime: function FormatTime() {
    var date = new Date();
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    m = m < 10 ? '0' + m : m;
    var d = date.getDate();
    d = d < 10 ? '0' + d : d;
    return y + "-" + m + "-" + d;
  },
  onLoad: function onLoad(options) {
    var that = this;
    var time = that.FormatTime();
    if (that.data.startTime == "") {
      that.setData({
        startTime: time,
        introduce: ""
      });
    }
    that.setData({
      userName: user.getNameById(app.globalData.information.id),
      userId: app.globalData.information.id,
      msrc: app.globalData.abp.setting.values["Score.MusicURL"],
      MinReadingSec: app.globalData.abp.setting.values["Score.MinReadingSec"],
      MaxReadingSec: app.globalData.abp.setting.values["Score.MaxReadingSec"],
      IsBgMusic: app.globalData.abp.setting.values["Score.IsBgMusic"]
    });
    if (that.data.IsBgMusic) {
      that.listenerMusicPlay();
    }
    var path = app.globalData.url + "/api/services/Score/ReadingContent/GetAll";
    var obj = {
      searchGroup: {
        rules: [{
          field: "date",
          value: that.data.startTime + " 00:00:00.0000000"
        }],
        sorting: "CreationTime DESC",
        pageSize: 1
      }
    };
    util.request(path, obj).then(function(res) {
      if (res.success && res.result.totalCount > 0) {
        that.setData({
          introduce: res.result.items[0].content,
          readingContentId: res.result.items[0].id,
          score: res.result.items[0].score
        });
      }
    });
    return;
  },
  click: function click() {
    this.upload(this, this.data.tempFilePath);
    //this.upload(this, "wxfile://store_08f11da020d9f05e03e1bf786e72d346298e762eaf4645c6.mp3");       
  },

  upload: function upload(page, path) {
    wx.showToast({
      icon: "loading",
      title: "正在上传"
    }), wx.uploadFile({
      url: app.globalData.url + "/Files/File/UploadFile",
      filePath: path[0],
      name: 'file',
      header: {
        "Content-Type": "multipart/form-data"
      },
      formData: {
        //和服务器约定的token, 一般也可以放在header中
        'session_token': wx.getStorageSync('session_token')
      },
      success: function success(res) {
        var json = JSON.parse(res.data);
        if (json.success) {
          content = "<img class='adjunct' src='" + page.data.path + "/Files/File/Image?FileName=" + json.result.fileNames[0] + "'>";
          WxParse.wxParse('topicDetail', 'html', content, page);
          page.setData({
            //上传成功修改显示头像
            src: "/Files/File/Image?FileName=" + json.result.fileNames,
            srcs: json.result.fileNames[0]
          });
        } else {
          wx.showModal({
            title: '提示',
            content: '上传失败',
            showCancel: false
          });
          return;
        }
      },
      fail: function fail(e) {
        wx.showModal({
          title: '提示',
          content: '上传失败',
          showCancel: false
        });
      },
      complete: function complete() {
        wx.hideToast(); //隐藏Toast
      }
    });
  },

  clockin: function clockin() {
    var that = this;
    if (that.data.num < that.data.MinReadingSec) {
      wx.showModal({
        title: '读书时间少于设置的时间',
        content: '请重新录制您的读书音频文件~~',
        showCancel: false
      });
      return;
    }
    wx.showModal({
      title: '',
      content: '是否确认提交本次读书内容',
      success: function success(res) {
        if (res.confirm) {
          var path;
          var obj;
          path = app.globalData.url + "/api/services/Score/ClockIn/Create";
          obj = {
            userId: that.data.userId,
            score: that.data.score,
            isClockIn: 0,
            date: that.data.startTime,
            image: that.data.tempFilePath,
            name: that.data.userName,
            department: app.globalData.information.organizationUnitId,
            readingContentId: that.data.readingContentId
          };
          //console.log(obj);
          util.request(path, obj, "POST").then(function(res) {
            if (res.success) {
              wx.showModal({
                title: '提示信息',
                content: "读书打卡成功！",
                showCancel: false
              });
              wx.navigateBack(1);
              return;
            }
          }, function(error) {
            wx.showModal({
              title: '提示信息',
              content: error.error.message,
              showCancel: false
            });
          });
        } else if (res.cancel) {
          return;
        }
      }
    });
  },
  //开始录音的时候
  start: function start() {
    var that = this;
    var duration = that.data.MaxReadingSec * 1000;
    var options = {
      duration: duration,
      //指定录音的时长5分钟，单位 ms
      sampleRate: 16000,
      //采样率
      numberOfChannels: 1,
      //录音通道数
      encodeBitRate: 96000,
      //编码码率
      format: 'mp3',
      //音频格式，有效值 aac/mp3
      frameSize: 50 //指定帧大小，单位 KB
    };
    //开始录音
    wx.authorize({
      scope: 'scope.record',
      success: function success() {
        //console.log("录音授权成功");
        //第一次成功授权后 状态切换为2
        that.setData({
          status: 2
        });
        recorderManager.start(options);
        recorderManager.onStart(function() {
          that.queryTime();
        });
        //错误回调
        recorderManager.onError(function(res) {
          console.log(res);
        });
      },
      fail: function fail() {
        //console.log("第一次录音授权失败");
        wx.showModal({
          title: '提示',
          content: '您未授权录音，功能将无法使用',
          showCancel: true,
          confirmText: "授权",
          confirmColor: "#52a2d8",
          success: function success(res) {
            if (res.confirm) {
              //确认则打开设置页面（重点）
              wx.openSetting({
                success: function success(res) {
                  if (!res.authSetting['scope.record']) {
                    //未设置录音授权
                    console.log("未设置录音授权");
                    wx.showModal({
                      title: '提示',
                      content: '您未授权录音，功能将无法使用',
                      showCancel: false,
                      success: function success(res) {}
                    });
                  } else {
                    //第二次才成功授权
                    //console.log("设置录音授权成功");
                    that.setData({
                      status: 2
                    });
                    recorderManager.start(options);
                    recorderManager.onStart(function() {
                      //console.log('recorder start')
                    });
                    //错误回调
                    recorderManager.onError(function(res) {
                      // console.log(res);
                    });
                  }
                },
                fail: function fail() {
                  // console.log("授权设置录音失败");
                }
              });
            } else if (res.cancel) {
              // console.log("cancel");
            }
          },
          fail: function fail() {
            //console.log("openfail");
          }
        });
      }
    });
  },
  //暂停录音
  pause: function pause() {
    recorderManager.pause();
    recorderManager.onPause(function(res) {
      console.log('暂停录音');
    });
  },
  //继续录音
  resume: function resume() {
    recorderManager.resume();
    recorderManager.onStart(function() {
      // console.log('重新开始录音')
    });
    //错误回调
    recorderManager.onError(function(res) {
      //console.log(res);
    });
  },
  //停止录音
  stop: function stop() {
    var that = this;
    recorderManager.stop();
    clearInterval(that.data.setInter);
    recorderManager.onStop(function(res) {
      that.setData({
        tempFilePath: res.tempFilePath
      });
      console.log('停止录音', res.tempFilePath);
      wx.saveFile({
        tempFilePath: that.data.tempFilePath,
        success: function success(res) {
          //持久路径
          //本地文件存储的大小限制为 100M
          var savedFilePath = res.savedFilePath;
          that.setData({
            tempFilePath: res.savedFilePath
          });
          wx.getSavedFileInfo({
            filePath: that.data.tempFilePath,
            success: function success(res) {
              that.setData({
                fileSize: res.size,
                author: that.data.userName,
                name: that.data.tempFilePath.substring(20) + "...",
                open: true
              });
            }
          });
        }
      });
    });
  },
  // 计时器
  queryTime: function queryTime() {
    var that = this;
    var hou = that.data.h;
    var min = that.data.m;
    var sec = that.data.s;
    that.data.setInter = setInterval(function() {
      sec++;
      if (sec >= 60) {
        sec = 0;
        min++;
        if (min >= 60) {
          min = 0;
          hou++;
          that.setData({
            h: hou < 10 ? '0' + min : min
          });
        } else {
          that.setData({
            m: min < 10 ? '0' + min : min
          });
        }
      } else {
        that.setData({
          s: sec < 10 ? '0' + sec : sec
        });
      }
      var numVal = that.data.num + 1;
      that.setData({
        num: numVal
      });
      //console.log('setInterval==' + that.data.num);
    }, 1000);
  },
  onUnload: function onUnload() {
    var that = this;
    if (that.data.IsBgMusic) {
      that.listenerMusicStop();
    }
    //清除计时器  即清除setInter
    clearInterval(that.data.setInter);
  },
  //播放声音
  listenerMusicPlay: function listenerMusicPlay() {
    var that = this;
    var src = that.data.msrc;
    bgMusic.title = "111";
    bgMusic.src = src;
    bgMusic.onEnded(function() {
      that.listenerMusicPlay(src);
    });
    bgMusic.pause();
  },
  listenerMusicStop: function listenerMusicStop() {
    bgMusic.stop();
  }
});