var _createForOfIteratorHelper2 = require("../../../@babel/runtime/helpers/createForOfIteratorHelper");
var util = require('../../../utils/util.js');
var user = require('../../../utils/cache/user.js');
var WxParse = require('../../../lib/wxParse/wxParse.js');
var app = getApp();
var content = "";
Page({
  data: {
    checkedname: false,
    checked: false,
    src: "",
    srcs: "",
    path: app.globalData.url,
    department: "规则管理",
    ruleClassify: "规则分类",
    userName: "",
    userId: "",
    score: "",
    scores: "-----请选择------",
    scoreTemplateId: "",
    id: "",
    GradeManageId: "",
    startTime: "",
    openscore: false,
    tab: false,
    open: true,
    username: '',
    introduce: '',
    introduces: "",
    thought: '',
    thoughts: "",
    opinion: "",
    message: "",
    scoreRuleId: "",
    scoreTemplateItemId: "",
    GradeManage: "",
    gradeManagescore: "",
    dep: [],
    ruleClassifys: [],
    workFlowTemp: [],
    movie: [],
    movies: [],
    department1: "选择部门",
    ruleClassifyId: "",
    depid: "",
    userInformation: "",
    organizationUnitId: "",
    update: false,
    hiddeName: true,
    hidderule: true,
    hiddedepar: true,
    hiddescore: true,
    hiddeintroduce: true,
    nocancel: true,
    hiddethought: true
  },
  confirm: function confirm() {
    var that = this;
    that.setData({
      hiddeName: true,
      hidderule: true,
      hiddedepar: true,
      hiddescore: true,
      introduce: that.data.introduces || that.data.introduce,
      hiddeintroduce: true,
      thought: that.data.thoughts || that.data.thought,
      hiddethought: true
    });
  },
  onLoad: function onLoad(options) {
    var that = this;
    var time = that.FormatTime();
    if (that.data.startTime == "") {
      that.setData({
        startTime: time
      });
    }
    that.setData({
      userName: user.getNameById(app.globalData.information.id),
      userId: app.globalData.information.id,
      scoreDateIsToday: app.globalData.abp && app.globalData.abp.setting.values["Score.ScoreDateIsToday"] == "true"
    });
    var path = app.globalData.url + "/api/services/WorkFlow/WFTemplate/GetWFTemplateByType";
    var obj = {
      Type: "160205001",
      Param: "",
      organizationUnitId: app.globalData.information.organizationUnitId,
      pageSize: 2000
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      that.setData({
        workFlowTemp: res.result
      });
    });
    if (options.id) {
      that.setData({
        state: options.state,
        update: true,
        GradeManageId: options.id
      });
      that.LoadDatas(options.id);
      return;
    } else {
      that.setData({
        state: "130008005"
      });
      that.LoadData();
      return;
    }
  },
  //格式时间
  FormatTime: function FormatTime() {
    var date = new Date();
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    m = m < 10 ? '0' + m : m;
    var d = date.getDate();
    d = d < 10 ? '0' + d : d;
    return y + "-" + m + "-" + d;
  },
  LoadData: function LoadData() {
    var that = this;
    var path = app.globalData.url + "/api/services/Score/GradeManage/GetAll";
    var obj = {
      searchGroup: {
        rules: [{
          field: "creatorUserId",
          value: app.globalData.information.id
        }, {
          field: "state",
          value: "130008005"
        }],
        sorting: "CreationTime DESC",
        pageSize: 1
      }
    };
    util.request(path, obj).then(function(res) {
      if (res.success && res.result.totalCount > 0) {
        content = "<img class='adjunct' src='" + "http://file.sinpedo.com/" + res.result.items[0].image + "'>";
        WxParse.wxParse('topicDetail', 'html', content, that);
        that.setData({
          GradeManageId: res.result.items[0].id,
          userName: res.result.items[0].name,
          userId: res.result.items[0].userId,
          department: res.result.items[0].scoreRuleName,
          startTime: res.result.items[0].date,
          introduce: res.result.items[0].introduce,
          scoreRuleId: res.result.items[0].scoreRuleId,
          scoreTemplateItemId: res.result.items[0].scoreTemplateItemId,
          gradeManagescore: res.result.items[0].score,
          scores: res.result.items[0].scoreTemplateItemName,
          checked: res.result.items[0].isSubjoinScore,
          organizationUnitId: res.result.items[0].organizationUnitId,
          srcs: res.result.items[0].image,
          thought: res.result.items[0].thoughts,
          opinion: null,
          update: true
        });
      }
    });
  },
  LoadDatas: function LoadDatas(id) {
    var that = this;
    var path = app.globalData.url + "/api/services/Score/GradeManage/Get";
    var obj = {
      Id: id
    };
    var Get = util.getQueryUrl(path, obj);
    util.request(Get).then(function(res) {
      if (res.success) {
        content = "<img class='adjunct' src='" + that.data.path + "/Files/File/Image?FileName=" + res.result.image + "'>";
        WxParse.wxParse('topicDetail', 'html', content, that);
        that.setData({
          userName: res.result.name,
          userId: res.result.userId,
          department: res.result.scoreRuleName,
          startTime: res.result.date,
          introduce: res.result.introduce,
          scoreRuleId: res.result.scoreRuleId,
          scoreTemplateItemId: res.result.scoreTemplateItemId,
          gradeManagescore: res.result.score,
          scores: res.result.scoreTemplateItemName,
          checked: res.result.isSubjoinScore,
          organizationUnitId: res.result.organizationUnitId,
          thought: res.result.thoughts,
          opinion: res.result.opinion,
          message: res.result.opinion == null ? "" : "审批意见：",
          srcs: res.result.image
        });
      }
    });
  },
  click: function click() {
    var that = this;
    wx.chooseImage({
      count: 1,
      // 默认9  
      sizeType: ['original', 'compressed'],
      // 可以指定是原图还是压缩图，默认二者都有  
      sourceType: ['album', 'camera'],
      // 可以指定来源是相册还是相机，默认二者都有  
      success: function success(res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片  
        var tempFilePaths = res.tempFilePaths;
        console.log("tempFilePaths:" + tempFilePaths);
        that.upload(that, tempFilePaths);
      }
    });
  },
  upload: function upload(page, path) {
    wx.showToast({
      icon: "loading",
      title: "正在上传"
    }), wx.uploadFile({
      url: app.globalData.url + "/Files/File/UploadFile",
      filePath: path[0],
      name: 'file',
      header: {
        "Content-Type": "multipart/form-data"
      },
      formData: {
        //和服务器约定的token, 一般也可以放在header中
        'session_token': wx.getStorageSync('session_token')
      },
      success: function success(res) {
        var json = JSON.parse(res.data);
        if (json.success) {
          content = "<img class='adjunct' src='" + page.data.path + "/Files/File/Image?FileName=" + json.result.fileNames[0] + "'>";
          WxParse.wxParse('topicDetail', 'html', content, page);
          page.setData({
            //上传成功修改显示头像
            src: "/Files/File/Image?FileName=" + json.result.fileNames,
            srcs: json.result.fileNames[0]
          });
        } else {
          wx.showModal({
            title: '提示',
            content: '上传失败',
            showCancel: false
          });
          return;
        }
      },
      fail: function fail(e) {
        wx.showModal({
          title: '提示',
          content: '上传失败',
          showCancel: false
        });
      },
      complete: function complete() {
        wx.hideToast(); //隐藏Toast
      }
    });
  },

  switchd: function switchd(e) {
    var that = this;
    that.setData({
      checkedname: e.detail.value
    });
  },
  username: function username() {
    var that = this;
    that.setData({
      hiddeName: false
    });
    var path = app.globalData.url + "/api/services/Foundation/User/GetUsers";
    var obj = {
      Filter: "",
      Permission: "",
      Role: "",
      Sorting: "",
      MaxResultCount: 2000,
      SkipCount: 1
    };
    util.request(path, obj, "Get").then(function(res) {
      that.setData({
        movie: res.result.items
      });
    });
  },
  userone: function userone(e) {
    this.setData({
      userName: e.currentTarget.dataset.name,
      userId: e.currentTarget.dataset.id,
      organizationUnitId: e.currentTarget.dataset.organizationunitid,
      hiddeName: true
    });
  },
  hiddeintroduce: function hiddeintroduce() {
    var that = this;
    that.setData({
      introduces: that.data.introduce,
      hiddeintroduce: false
    });
  },
  hiddethought: function hiddethought() {
    var that = this;
    that.setData({
      thoughts: that.data.thought,
      hiddethought: false
    });
  },
  ruleClassify: function ruleClassify() {
    this.setData({
      hidderule: false
    });
    var that = this;
    var path = app.globalData.url + "/api/services/CodeData/CodeData/GetAll";
    var obj = {
      searchGroup: {
        rules: [{
          field: "codeDataTypeId",
          value: 200011
        }]
      },
      pageSize: 2000
    };
    util.request(path, obj, "Get").then(function(res) {
      var arr = res.result.items;
      for (var index in arr) {
        if (arr[index].name === '任务规则') {
          arr.splice(index, 1);
        }
      }
      that.setData({
        ruleClassifys: arr
      });
    });
  },
  ruleone: function ruleone(e) {
    this.setData({
      hidderule: true,
      ruleClassify: e.currentTarget.dataset.name,
      ruleClassifyId: e.currentTarget.dataset.id,
      department: ""
      //scoreRuleId: e.currentTarget.dataset.scoreruleid
    });
  },

  department: function department() {
    if (this.data.ruleClassify == "规则分类") {
      wx.showModal({
        title: '提示消息',
        content: '请选择规则管理',
        showCancel: false
      });
      return;
    }
    this.setData({
      hiddedepar: false
    });
    var that = this;
    var path = app.globalData.url + "/api/services/Score/ScoreRule/GetAll";
    var obj = {
      searchGroup: {
        rules: [{
          field: "ruleClassify",
          value: that.data.ruleClassifyId
        }]
      },
      pageSize: 2000
    };
    util.request(path, obj, "Get").then(function(res) {
      that.setData({
        movies: res.result.items
      });
    });
  },
  one: function one(e) {
    this.setData({
      department: e.currentTarget.dataset.name,
      hiddedepar: true,
      scoreRuleId: e.currentTarget.dataset.scoreruleid,
      scores: "",
      scoreTemplateItemId: "",
      gradeManagescore: ""
    });
    var that = this;
    var path = app.globalData.url + "/api/services/Score/ScoreTemplate/GetItemsById";
    var obj = {
      id: e.currentTarget.dataset.id
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      that.setData({
        score: res.result,
        tab: true
      });
    });
  },
  scoretap: function scoretap(e) {
    if (!this.data.department) {
      wx.showModal({
        title: '提示消息',
        content: '请先选择哲学',
        showCancel: false
      });
      return;
    }
    this.setData({
      hiddescore: false
    });
  },
  scoreone: function scoreone(e) {
    this.setData({
      scores: e.currentTarget.dataset.name,
      hiddescore: true,
      scoreTemplateItemId: e.currentTarget.dataset.id,
      gradeManagescore: e.currentTarget.dataset.score
    });
  },
  bindUsernameInput: function bindUsernameInput(e) {
    this.setData({
      username: e.detail.value
    });
  },
  bindIntroduceInput: function bindIntroduceInput(e) {
    var that = this;
    this.setData({
      introduces: e.detail.value
    });
  },
  bindThoughtInput: function bindThoughtInput(e) {
    var that = this;
    this.setData({
      thoughts: e.detail.value
    });
  },
  datePicker: function datePicker(e) {
    this.setData({
      startTime: e.detail.value
    });
  },
  //获取输入的用户信息
  input: function input(e) {
    var that = this;
    this.setData({
      userInformation: e.detail.value
    });
  },
  //根据用户信息查询数据
  get: function get() {
    var that = this;
    var UserList = app.cache.users;
    var UserLists = [];
    var _iterator = _createForOfIteratorHelper2(UserList),
      _step;
    try {
      for (_iterator.s(); !(_step = _iterator.n()).done;) {
        var item = _step.value;
        if (item.name.indexOf(that.data.userInformation) > -1 && item.name != "admin") {
          UserLists.push(item);
        }
      }
    } catch (err) {
      err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
      _iterator.e(err);
    } finally {
      _iterator.f();
    }
    that.setData({
      movie: UserLists
    });
  },
  buttonsave: function buttonsave(options) {
    var that = this;
    if (that.data.userName == '用户' || !that.data.scoreRuleId || !that.data.scoreTemplateItemId) {
      wx.showModal({
        title: '错误信息',
        content: '请补充完数据~~',
        showCancel: false
      });
      return;
    }
    that.setData({
      open: false
    });
    var path;
    var obj;
    if (that.data.state == "130008010" || that.data.state == "130008005" && that.data.update == true) {
      path = app.globalData.url + "/api/services/Score/GradeManage/Update";
      obj = {
        id: that.data.GradeManageId,
        name: that.data.userName ? that.data.userName : "",
        thoughts: that.data.thought,
        userId: that.data.userId,
        creatorUserId: app.globalData.information.id,
        isSubjoinScore: that.data.checkedname ? "true" : "false",
        scoreRuleId: that.data.scoreRuleId,
        scoreTemplateItemId: that.data.scoreTemplateItemId,
        state: "130008005",
        date: that.data.startTime,
        organizationUnitId: that.data.organizationUnitId,
        score: that.data.gradeManagescore,
        image: that.data.srcs,
        introduce: that.data.introduce ? that.data.introduce : ""
      };
    } else {
      path = app.globalData.url + "/api/services/Score/GradeManage/Create";
      obj = {
        name: that.data.userName ? that.data.userName : "",
        thoughts: that.data.thought,
        userId: that.data.userId,
        creatorUserId: app.globalData.information.id,
        isSubjoinScore: that.data.checkedname ? "true" : "false",
        scoreRuleId: that.data.scoreRuleId,
        scoreTemplateItemId: that.data.scoreTemplateItemId,
        date: that.data.startTime,
        organizationUnitId: that.data.organizationUnitId,
        score: that.data.gradeManagescore,
        image: that.data.srcs,
        introduce: that.data.introduce ? that.data.introduce : ""
      };
    }
    util.request(path, obj).then(function(res) {
      if (res.success) {
        that.setData({
          GradeManage: res.result.id,
          rejectOpen: true,
          open: false
        });
        wx.showModal({
          title: '提示信息',
          content: "保存成功，请点击申请审批！",
          showCancel: false
        });
      }
      //res = "";
    }, function(error) {
      wx.showModal({
        title: '错误信息',
        content: error.error.message,
        showCancel: false
      });
      that.setData({
        open: true
      });
    });
  },
  reject: function reject() {
    var that = this;
    wx.showModal({
      title: '',
      content: '是否确认提交审核本条哲学',
      success: function success(res) {
        if (res.confirm) {
          var path = app.globalData.url + "/api/services/WorkFlow/WorkFlow/Create";
          var obj = {
            fkNo: that.data.FkNo,
            name: that.data.workFlowTemp.name,
            moduleName: "Score",
            entity: that.data.entityList,
            remark: that.data.introduce,
            wfTempID: that.data.workFlowTemp.id,
            fkID: that.data.GradeManage,
            fkType: "GradeManage",
            startIndex: "1",
            userId: that.data.userId,
            data: JSON.stringify({
              id: that.data.GradeManage,
              fkType: "GradeManage"
            })
          };
          // console.log(obj);
          util.request(path, obj, "POST").then(function(res) {
            if (res.success) {
              wx.switchTab({
                url: '/pages/ucenter/work/work'
              });
              return;
            }
          }, function(error) {
            wx.showModal({
              title: '错误信息',
              content: error.error.message,
              showCancel: false
            });
          });
        } else if (res.cancel) {
          return;
        }
      }
    });
  }
});