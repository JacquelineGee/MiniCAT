var _createForOfIteratorHelper2 = require("../../../@babel/runtime/helpers/createForOfIteratorHelper");
var util = require('../../../utils/util.js');
var workFlow = require('../../../utils/WorkFlow.js');
var app = getApp();
var WxParse = require('../../../lib/wxParse/wxParse.js');
var users = require('../../../utils/cache/user.js');
Page({
  data: {
    movies: [],
    workFlowTemp: [],
    workFlowAction: [],
    nodeID: [],
    opinion: "",
    user: {},
    path: app.globalData.url + "/File/Image?FileName=",
    id: "",
    name: "",
    date: "",
    scores: "",
    scoreRuleId: "",
    ScoreTemplateId: "",
    ScoreTemplateItemId: "",
    OrganizationUnitId: "",
    departmentId: 0,
    gradeManagescore: "",
    checkedname: "",
    topname: "",
    introduce: "",
    introduces: "",
    ShowImage: false,
    lastWorkFlowId: "",
    hiddescore: true,
    hiddeintroduce: true,
    nocancel: true,
    openstate: true,
    Tops: false,
    Rejected: false,
    open1: false,
    No: "",
    state: "",
    isrejected: false,
    istop: false
  },
  confirm: function confirm() {
    var that = this;
    that.setData({
      hiddescore: true,
      hiddeintroduce: true
    });
  },
  hiddeintroduce: function hiddeintroduce() {
    var that = this;
    that.setData({
      introduces: that.data.introduce,
      hiddeintroduce: false
    });
  },
  onLoad: function onLoad(options) {
    var that = this;
    that.setData({
      departmentId: options.departmentId
    });
    var userConfiguration = wx.getStorageSync('userConfiguration');
    if (userConfiguration["Score/GradeManage/Tops"] == 'true') {
      that.setData({
        Tops: true
      });
    }
    if (userConfiguration["Score/GradeManage/Rejected"] == 'true') {
      that.setData({
        Rejected: true
      });
    }
    var path = app.globalData.url + "/api/services/WorkFlow/WFTemplate/GetWFTemplateByType";
    var obj = {
      Type: "160205001",
      Param: "",
      organizationUnitId: app.globalData.information.organizationUnitId,
      pageSize: 2000
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      that.setData({
        workFlowTemp: res.result
      });
    });
    var path = app.globalData.url + "/api/services/Score/GradeManage/Get";
    var obj = {
      id: options.id
    };
    var Get = util.getQueryUrl(path, obj);
    util.request(Get).then(function(res) {
      if (res.success) {
        that.setData({
          scoreRuleId: res.result.scoreRuleId,
          lastWorkFlowId: res.result.lastWorkFlowId,
          gradeManagestate: res.result.state,
          OrganizationUnitId: res.result.organizationUnitId
        });
        var path1 = app.globalData.url + "/api/services/Score/ScoreRule/Get";
        var obj1 = {
          id: that.data.scoreRuleId
        };
        var GetData = util.getQueryUrl(path1, obj1);
        util.request(GetData).then(function(res1) {
          that.setData({
            ScoreTemplateId: res1.result.scoreTemplateId
          });
          var path2 = app.globalData.url + "/api/services/Score/ScoreTemplate/GetItemsById";
          var obj2 = {
            id: that.data.ScoreTemplateId
          };
          var GetData1 = util.getQueryUrl(path2, obj2);
          util.request(GetData1).then(function(res2) {
            that.setData({
              score: res2.result,
              tab: true
            });
          });
        });
        //console.log(that.data.path + res.result.image);
        var result;
        var images = [];
        var content = "";
        if (res.result.image) {
          result = res.result.image.split("|");
          var _iterator = _createForOfIteratorHelper2(result),
            _step;
          try {
            for (_iterator.s(); !(_step = _iterator.n()).done;) {
              var item = _step.value;
              //if (item[0] == '/') item = item.substr(1);
              //var image = that.data.path + item;
              var image = "http://file.sinpedo.com/" + item;
              content += "<img src='" + image + "'>";
            }
          } catch (err) {
            err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
            _iterator.e(err);
          } finally {
            _iterator.f();
          }
        }
        try {
          WxParse.wxParse('topicDetail', 'html', content, that);
        } catch (err) {
          err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
          console.log(err);
        }
        res.result.name = users.getNameById(res.result.userId);
        that.setData({
          user: res.result,
          scores: res.result.scoreTemplateItemName,
          No: res.result.score,
          date: res.result.date,
          checkedname: res.result.isSubjoinScore,
          gradeManagescore: res.result.score,
          scoreTemplateItemId: res.result.scoreTemplateItemId,
          opinion: res.result.opinion,
          id: options.id,
          name: res.result.name,
          state: res.result.state,
          introduce: res.result.introduce,
          no: res.result.state == "130008020" || res.result.top == "1" ? true : false,
          open: res.result.state == "130008020" || res.result.top == "1" ? false : true,
          open1: res.result.state == "130008020" && res.result.top != "1" ? true : false
        });
      }
      if (that.data.lastWorkFlowId) {
        var pathFkID = app.globalData.url + "/api/services/WorkFlow/WorkFlowNode/GetAll";
        var objFkID = {
          searchGroup: {
            rules: [{
              field: "FlowID",
              value: that.data.lastWorkFlowId
            }]
          },
          pageSize: 2000
        };
        var GetDataFkID = util.getQueryUrl(pathFkID, objFkID);
        util.request(GetDataFkID).then(function(res) {
          var item = res.result.items;
          var items = item.filter(function(x) {
            return x.isCurrent == true;
          });
          if (items && items.length > 0) {
            that.setData({
              nodeID: items[0]
            });
            if (that.data.nodeID.userID == app.globalData.information.id || userConfiguration["Score/GradeManage/Approve"] == 'true') {
              var path = app.globalData.url + "/api/services/WorkFlow/WorkFlowAction/GetAll";
              var obj = {
                searchGroup: {
                  rules: [{
                    field: "NodeID",
                    value: that.data.nodeID.id
                  }]
                },
                sorting: "LastModificationTime DESC",
                pageSize: 2000
              };
              var GetData = util.getQueryUrl(path, obj);
              util.request(GetData).then(function(res) {
                if (that.data.state == "130008020") {
                  that.setData({
                    open: false
                  });
                } else {
                  that.setData({
                    workFlowAction: res.result.items,
                    open: true
                  });
                }
              }, function(err) {
                console.log(error);
              });
            } else {
              that.setData({
                open: false
              });
            }
          }
        }, function(err) {
          console.log(error);
        });
      }
    });
  },
  switchd: function switchd(e) {
    var that = this;
    var user = that.data.user;
    user.isSubjoinScore = e.detail.value;
    that.setData({
      user: that.data.user,
      checkedname: e.detail.value
    });
  },
  switchds: function switchds(e) {
    var that = this;
    var user = that.data.user;
    user.top = e.detail.value;
    that.setData({
      user: that.data.user,
      topname: e.detail.value
    });
  },
  scoretap: function scoretap(e) {
    var that = this;
    that.setData({
      hiddescore: false
    });
  },
  scoreone: function scoreone(e) {
    this.setData({
      scores: e.currentTarget.dataset.name,
      hiddescore: true,
      scoreTemplateItemId: e.currentTarget.dataset.id,
      gradeManagescore: e.currentTarget.dataset.score,
      No: e.currentTarget.dataset.score
    });
  },
  totalScore: function totalScore(e) {
    this.setData({
      totalScore: e.detail.value
    });
  },
  bindopinionInput: function bindopinionInput(e) {
    var that = this;
    that.data.opinion = e.detail.value;
    console.log(e.detail.value);
    this.setData({
      opinion: e.detail.value
    });
  },
  //长按复制
  copy: function copy(e) {
    var that = this;
    console.log(e);
    wx.setClipboardData({
      data: that.data.introduce,
      success: function success(res) {
        wx.showToast({
          title: '复制成功'
        });
      }
    });
  },
  reject: function reject(e) {
    var that = this;
    // if (e.currentTarget.dataset.index == "temporary") {
    //   if (!that.data.workFlowTemp) {
    //     wx.showModal({
    //       title: '错误信息',
    //       content: '未设定审批流模板，无法发起审批！',
    //       showCancel: false
    //     })
    //   }
    //   else {
    //     that.setData({
    //       open1state: false
    //     })
    //     var path = app.globalData.url + "/api/services/WorkFlow/WorkFlow/Create"
    //     var obj = {
    //       name: "", wfTempID: that.data.workFlowTemp.id, fkID: that.data.user.id, fkType: "GradeManage",
    //       startIndex: "1", userId: that.data.user.userId, data: JSON.stringify({ id: that.data.user.id, fkType: "GradeManage" })
    //     }
    //     util.request(path, obj, "POST").then((res) => {
    //       if (res.success) {
    //         wx.navigateBack(1)
    //         return;
    //       }
    //     }, (error) => {
    //       wx.showModal({
    //         title: '错误信息',
    //         content: error.error.message,
    //         showCancel: false
    //       });
    //     })
    //   }
    // }
    var bool = e.currentTarget.dataset.cmd == "pass" ? true : false;
    if (!bool) {
      if (!that.data.opinion) {
        //wx.showModal({
        //  title: '提示信息',
        //  content: '请输入审核意见~~',
        //  showCancel: false
        //});
        that.setData({
          opinion: "驳回"
        });
      }
    }
    if (that.data.openstate) {
      that.setData({
        openstate: false
      });
      var path = app.globalData.url + "/api/services/Score/GradeManage/ChangeState";
      var obj = {
        id: that.data.user.id,
        state: "130008020",
        workFlowId: that.data.lastWorkFlowId,
        workNodeId: that.data.nodeID.id,
        workActionId: e.currentTarget.dataset.id,
        cMD: e.currentTarget.dataset.cmd,
        userId: app.globalData.information.id,
        remark: that.data.opinion,
        data: {
          id: that.data.user.id,
          scoreTemplateItemId: that.data.scoreTemplateItemId,
          score: that.data.totalScore == null ? that.data.gradeManagescore : that.data.totalScore,
          isSubjoinScore: that.data.checkedname,
          state: bool ? "130008020" : "130008010",
          opinion: that.data.opinion,
          top: that.data.topname ? "true" : "false"
        }
      };
      util.request(path, obj, "POST").then(function(res) {
        if (res.success) {
          /* wx.redirectTo(
            {
              url:'/pages/ucenter/gradeManage1/gradeManage1?state=130008015&departmentId='+JSON.stringify(this.data.OrganizationUnitId),
            }  
          );   */
          var pages = getCurrentPages();
          var prepages = pages[pages.length - 2];
          prepages.setData({
            departmentId: that.data.departmentId,
            loading: that.data.departmentId
          });
          wx.navigateBack({
            changed: true
          }); //返回上一页
        }
      });
    }
  },

  listenCheckboxChange: function listenCheckboxChange(e) {
    var that = this;
    var user = that.data.user;
    user.isSubjoinScore = !e.target.dataset.checks;
    that.setData({
      user: that.data.user,
      checkedname: user.isSubjoinScore
    });
  },
  Top: function Top(e) {
    var that = this;
    wx.showModal({
      title: '',
      content: '是否确认置顶本条哲学',
      success: function success(res) {
        if (res.confirm) {
          var user = that.data.user;
          var path = app.globalData.url + "/api/services/Score/GradeManage/GradeManageTop";
          var obj = {
            id: that.data.user.id
          };
          var GetData = util.getQueryUrl(path, obj);
          if (that.data.istop == false) {
            that.setData({
              istop: true
            });
            util.request(GetData).then(function(res) {
              if (res.success) {
                wx.navigateBack(-1);
              }
            });
          }
        } else if (res.cancel) {
          return;
        }
      }
    });
  },
  Rejected: function Rejected(e) {
    var that = this;
    wx.showModal({
      title: '',
      content: '是否确认强制驳回本条哲学',
      success: function success(res) {
        if (res.confirm) {
          var user = that.data.user;
          var path = app.globalData.url + "/api/services/Score/GradeManage/GradeManageRejected";
          var obj = {
            id: that.data.user.id
          };
          var GetData = util.getQueryUrl(path, obj);
          if (that.data.isrejected == false) {
            that.setData({
              isrejected: true
            });
            util.request(GetData).then(function(res) {
              if (res.success) {
                wx.navigateBack(-1);
              }
            });
          }
        } else if (res.cancel) {
          console.log('用户点击取消');
        }
      }
    });
  },
  /**
   * bindtouchmove
   */
  bindTouchMove: function bindTouchMove(e) {
    if (e.touches.length == 2) {
      //二指缩放
      var xMove = e.touches[1].clientX - e.touches[0].clientX;
      var yMove = e.touches[1].clientY - e.touches[0].clientY;
      var distance = Math.sqrt(xMove * xMove + yMove * yMove); //开根号
      this.distanceList.shift();
      this.distanceList.push(distance);
      if (this.distanceList[0] == 0) {
        return;
      }
      var distanceDiff = this.distanceList[1] - this.distanceList[0]; //两次touch之间, distance的变化. >0,放大图片.<0 缩小图片
      // 假设缩放scale基数为1:  newScale = oldScale + 0.005 * distanceDiff
      var baseScale = this.data.img.baseScale + 0.005 * distanceDiff;
      if (baseScale > 0) {
        this.data.img.baseScale = baseScale;
        var imgWidth = baseScale * parseInt(this.data.img.imgWidth);
        var imgHeight = baseScale * parseInt(this.data.img.imgHeight);
        this.setData({
          img: this.data.img
        });
      } else {
        this.data.img.baseScale = 0;
        this.setData({
          img: this.data.img
        });
      }
    }
  }
});