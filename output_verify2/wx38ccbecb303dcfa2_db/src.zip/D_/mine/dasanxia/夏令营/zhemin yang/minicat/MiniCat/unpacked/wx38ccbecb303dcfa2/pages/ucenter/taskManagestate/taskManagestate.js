var _createForOfIteratorHelper2 = require("../../../@babel/runtime/helpers/createForOfIteratorHelper");
var util = require('../../../utils/util.js');
var workFlow = require('../../../utils/WorkFlow.js');
var app = getApp();
var WxParse = require('../../../lib/wxParse/wxParse.js');
var users = require('../../../utils/cache/user.js');
Page({
  data: {
    movies: [],
    workFlowTemp: [],
    workFlowAction: [],
    nodeID: [],
    opinion: "",
    user: {},
    path: app.globalData.url + "/File/Image?FileName=",
    department: "规则管理",
    ruleClassify: "规则分类",
    PublishuserName: "",
    PbulishuserId: "",
    TaskManageId: "",
    startTime: "",
    endTime: "",
    TeamId: "",
    Publishintroduce: '',
    Publishintroduces: "",
    userName: "",
    userId: "",
    Publishimage: "",
    RewardScore: 0,
    RewardScoresId: "",
    thoughts: "",
    id: "",
    name: "",
    date: "",
    scores: "",
    scoreRuleId: "",
    ScoreTemplateId: "",
    ScoreTemplateItemId: "",
    taskManagescore: "",
    checkedname: "",
    TaskManagescore: 0,
    topname: "",
    introduce: "",
    introduces: "",
    ShowImage: false,
    lastWorkFlowId: "",
    hiddescore: true,
    hiddeintroduce: true,
    nocancel: true,
    openstate: true,
    Tops: false,
    Rejected: false,
    open: false,
    No: "",
    hidderule: true,
    RewardScores: [],
    isview: false,
    state: ""
  },
  confirm: function confirm() {
    var that = this;
    that.setData({
      hiddeName: true,
      hidderule: true,
      hiddedepar: true
    });
  },
  RewardScore: function RewardScore() {
    this.setData({
      hidderule: false
    });
    var that = this;
    var path = app.globalData.url + "/api/services/CodeData/CodeData/GetAll";
    var obj = {
      searchGroup: {
        rules: [{
          field: "codeDataTypeId",
          value: 202012
        }]
      },
      pageSize: 999
    };
    util.request(path, obj, "Get").then(function(res) {
      that.setData({
        RewardScores: res.result.items
      });
    });
  },
  Rewardone: function Rewardone(e) {
    this.setData({
      hidderule: true,
      RewardScore: e.currentTarget.dataset.value
    });
  },
  hiddeintroduce: function hiddeintroduce() {
    var that = this;
    that.setData({
      introduces: that.data.introduce,
      hiddeintroduce: false
    });
  },
  onLoad: function onLoad(options) {
    var that = this;
    that.setData({
      isview: options.view == 1 ? true : false
    });
    var userConfiguration = wx.getStorageSync('userConfiguration');
    if (userConfiguration["Score/TaskManage/Rejected"] == 'true') {
      that.setData({
        Rejected: true
      });
    }
    var path = app.globalData.url + "/api/services/WorkFlow/WFTemplate/GetWFTemplateByType";
    var obj = {
      Type: "160205026",
      Param: "",
      organizationUnitId: app.globalData.information.organizationUnitId,
      pageSize: 999
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      that.setData({
        workFlowTemp: res.result
      });
    });
    var path = app.globalData.url + "/api/services/Score/TaskManage/Get";
    var obj = {
      Id: options.id
    };
    var Get = util.getQueryUrl(path, obj);
    util.request(Get).then(function(res) {
      if (res.success) {
        that.setData({
          scoreRuleId: res.result.scoreRuleId,
          lastWorkFlowId: res.result.lastWorkFlowId,
          taskManagestate: res.result.state
        });
        //console.log('wfid:',res.result.scoreRuleId)
        var path1 = app.globalData.url + "/api/services/Score/ScoreRule/Get";
        var obj1 = {
          id: that.data.scoreRuleId
        };
        var GetData = util.getQueryUrl(path1, obj1);
        util.request(GetData).then(function(res1) {
          that.setData({
            ScoreTemplateId: res1.result.scoreTemplateId
          });
          var path2 = app.globalData.url + "/api/services/Score/ScoreTemplate/GetItemsById";
          var obj2 = {
            id: that.data.ScoreTemplateId
          };
          var GetData1 = util.getQueryUrl(path2, obj2);
          util.request(GetData1).then(function(res2) {
            that.setData({
              score: res2.result,
              tab: true
            });
          });
        });
        //console.log(that.data.path + res.result.image);
        var result;
        var images = [];
        var content = "";
        if (res.result.publishImage) {
          result = res.result.publishImage.split("|");
          var _iterator = _createForOfIteratorHelper2(result),
            _step;
          try {
            for (_iterator.s(); !(_step = _iterator.n()).done;) {
              var item = _step.value;
              //if (item[0] == '/') item = item.substr(1);
              //var image = that.data.path + item;
              var image = "http://file.sinpedo.com/" + item;
              content += "<img src='" + image + "'>";
            }
          } catch (err) {
            err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
            _iterator.e(err);
          } finally {
            _iterator.f();
          }
        }
        try {
          WxParse.wxParse('topicDetail', 'html', content, that);
        } catch (err) {
          err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
          console.log(err);
        }
        content = "";
        if (res.result.image) {
          result = res.result.image.split("|");
          var _iterator2 = _createForOfIteratorHelper2(result),
            _step2;
          try {
            for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
              var item = _step2.value;
              //if (item[0] == '/') item = item.substr(1);
              //var image = that.data.path + item;
              var image = "http://file.sinpedo.com/" + item;
              content += "<img src='" + image + "'>";
            }
          } catch (err) {
            err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
            _iterator2.e(err);
          } finally {
            _iterator2.f();
          }
        }
        try {
          WxParse.wxParse('topicDetail1', 'html', content, that);
        } catch (err) {
          err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
          console.log(err);
        }
        res.result.name = users.getNameById(res.result.userId);
        that.setData({
          user: res.result,
          scores: res.result.scoreTemplateItemName,
          No: res.result.score,
          date: res.result.date,
          checkedname: res.result.isSubjoinScore,
          department: res.result.scoreRuleName,
          taskManagescore: res.result.score,
          scoreTemplateItemId: res.result.scoreTemplateItemId,
          opinion: res.result.opinion,
          id: options.id,
          name: res.result.name,
          state: res.result.state,
          introduce: res.result.introduce,
          PublishuserName: res.result.publishUserName,
          PbulishuserId: res.result.userId,
          userName: res.result.name,
          userId: res.result.userId,
          TaskManageId: options.id,
          startTime: res.result.startDate,
          endTime: res.result.endDate,
          Publishintroduce: res.result.publishIntroduce,
          Publishimage: res.result.publishImage,
          image: res.result.image,
          thoughts: res.result.thoughts,
          TaskManagescore: res.result.score,
          RewardScore: res.result.rewardScore,
          TeamId: res.result.teamId,
          no: res.result.state == "130008020" ? true : false,
          open: res.result.state == "130008020" ? false : true,
          open1: res.result.state == "130008020" ? true : false
        });
      }
      //console.log('that.data.lastWorkFlowId:',that.data.lastWorkFlowId)
      if (that.data.lastWorkFlowId) {
        var pathFkID = app.globalData.url + "/api/services/WorkFlow/WorkFlowNode/GetAll";
        var objFkID = {
          searchGroup: {
            rules: [{
              field: "FlowID",
              value: that.data.lastWorkFlowId
            }]
          },
          pageSize: 999
        };
        var GetDataFkID = util.getQueryUrl(pathFkID, objFkID);
        util.request(GetDataFkID).then(function(res) {
          var item = res.result.items;
          var items = item.filter(function(x) {
            return x.isCurrent == true;
          });
          if (items && items.length > 0) {
            that.setData({
              nodeID: items[0]
            });
            //console.log('that.data.nodeID.id:',that.data.nodeID.id)
            //console.log('userid:',users.getNameById(app.globalData.information.id))
            if (that.data.nodeID.userID == app.globalData.information.id || userConfiguration["Score/TaskManage/Approve"] == 'true') {
              var path = app.globalData.url + "/api/services/WorkFlow/WorkFlowAction/GetAll";
              var obj = {
                searchGroup: {
                  rules: [{
                    field: "NodeID",
                    value: that.data.nodeID.id
                  }]
                },
                sorting: "LastModificationTime DESC",
                pageSize: 999
              };
              var GetData = util.getQueryUrl(path, obj);
              util.request(GetData).then(function(res) {
                if (that.data.state == "130008020") {
                  that.setData({
                    open: false
                  });
                } else if (that.data.PublishuserName == users.getNameById(app.globalData.information.id)) {
                  that.setData({
                    workFlowAction: res.result.items,
                    open: true
                  });
                }
                //console.log(that.data.workFlowAction)
                //console.log("open:"+that.data.open)
                //console.log("openstate:"+that.data.openstate)
              }, function(err) {
                console.log(error);
              });
            } else {
              that.setData({
                open: false
              });
            }
          }
        }, function(err) {
          console.log(error);
        });
      }
    });
  },
  viewtask: function viewtask(e) {
    var that = this;
    wx.navigateTo({
      url: '/pages/ucenter/taskPlan/taskPlan?id=' + that.data.TeamId
    });
  },
  switchd: function switchd(e) {
    var that = this;
    var user = that.data.user;
    user.isSubjoinScore = e.detail.value;
    that.setData({
      user: that.data.user,
      checkedname: e.detail.value
    });
  },
  switchds: function switchds(e) {
    var that = this;
    var user = that.data.user;
    user.top = e.detail.value;
    that.setData({
      user: that.data.user,
      topname: e.detail.value
    });
  },
  scoretap: function scoretap(e) {
    var that = this;
    that.setData({
      hiddescore: false
    });
  },
  scoreone: function scoreone(e) {
    this.setData({
      scores: e.currentTarget.dataset.name,
      hiddescore: true,
      scoreTemplateItemId: e.currentTarget.dataset.id,
      taskManagescore: e.currentTarget.dataset.score,
      No: e.currentTarget.dataset.score
    });
  },
  totalScore: function totalScore(e) {
    this.setData({
      totalScore: e.detail.value
    });
  },
  bindopinionInput: function bindopinionInput(e) {
    var that = this;
    that.data.opinion = e.detail.value;
    this.setData({
      opinion: e.detail.value
    });
  },
  //长按复制
  copy: function copy(e) {
    var that = this;
    //console.log(e);
    wx.setClipboardData({
      data: that.data.introduce,
      success: function success(res) {
        wx.showToast({
          title: '复制成功'
        });
      }
    });
  },
  reject: function reject(e) {
    var that = this;
    var bool = e.currentTarget.dataset.cmd == "pass" ? true : false;
    if (!bool) {
      if (!that.data.opinion) {
        wx.showModal({
          title: '提示信息',
          content: '请输入审核意见~~',
          showCancel: false
        });
        return;
      }
    } else {}
    if (that.data.openstate) {
      that.setData({
        openstate: false
      });
      //console.log("that.data.RewardScore:"+that.data.RewardScore);
      var path = app.globalData.url + "/api/services/Score/TaskManage/ChangeState";
      var obj = {
        id: that.data.user.id,
        state: "130008020",
        workFlowId: that.data.lastWorkFlowId,
        workNodeId: that.data.nodeID.id,
        workActionId: e.currentTarget.dataset.id,
        cMD: e.currentTarget.dataset.cmd,
        userId: app.globalData.information.id,
        remark: that.data.opinion,
        rewardScore: that.data.RewardScore,
        data: {
          id: that.data.user.id,
          scoreTemplateItemId: that.data.scoreTemplateItemId,
          score: that.data.TaskManagescore,
          isSubjoinScore: that.data.checkedname,
          state: bool ? "130008020" : "130008010",
          opinion: that.data.opinion,
          rewardScore: that.data.RewardScore,
          top: that.data.topname ? "true" : "false"
        }
      };
      util.request(path, obj, "POST").then(function(res) {
        if (res.success) {
          wx.navigateBack(1);
        }
      });
    }
  },
  listenCheckboxChange: function listenCheckboxChange(e) {
    var that = this;
    var user = that.data.user;
    user.isSubjoinScore = !e.target.dataset.checks;
    that.setData({
      user: that.data.user,
      checkedname: user.isSubjoinScore
    });
  },
  Top: function Top(e) {
    var that = this;
    var user = that.data.user;
    var path = app.globalData.url + "/api/services/Score/TaskManage/TaskManageTop";
    var obj = {
      id: that.data.user.id
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      if (res.success) {
        wx.navigateBack(1);
      }
    });
  },
  Rejected: function Rejected(e) {
    var that = this;
    var user = that.data.user;
    var path = app.globalData.url + "/api/services/Score/TaskManage/TaskManageRejected";
    var obj = {
      id: that.data.user.id
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      if (res.success) {
        wx.navigateBack(1);
      }
    });
  },
  /**      
   * bindtouchmove
   */
  bindTouchMove: function bindTouchMove(e) {
    if (e.touches.length == 2) {
      //二指缩放
      var xMove = e.touches[1].clientX - e.touches[0].clientX;
      var yMove = e.touches[1].clientY - e.touches[0].clientY;
      var distance = Math.sqrt(xMove * xMove + yMove * yMove); //开根号
      this.distanceList.shift();
      this.distanceList.push(distance);
      if (this.distanceList[0] == 0) {
        return;
      }
      var distanceDiff = this.distanceList[1] - this.distanceList[0]; //两次touch之间, distance的变化. >0,放大图片.<0 缩小图片
      // 假设缩放scale基数为1:  newScale = oldScale + 0.005 * distanceDiff
      var baseScale = this.data.img.baseScale + 0.005 * distanceDiff;
      if (baseScale > 0) {
        this.data.img.baseScale = baseScale;
        var imgWidth = baseScale * parseInt(this.data.img.imgWidth);
        var imgHeight = baseScale * parseInt(this.data.img.imgHeight);
        this.setData({
          img: this.data.img
        });
      } else {
        this.data.img.baseScale = 0;
        this.setData({
          img: this.data.img
        });
      }
    }
  }
});