var _createForOfIteratorHelper2 = require("../../../@babel/runtime/helpers/createForOfIteratorHelper");
var util = require('../../../utils/util.js');
var api = require('../../../config/api.js');
var user = require('../../../utils/cache/user.js');
var app = getApp();
var obj = {};
var flag = true;
var pageindex = 1;
var pagesize = 100;
var data;
var userData = false;
var num = 1;
var totalCount;
Page({
  data: {
    scrollTop: 0,
    lastScrollTop: 0,
    lastScrollTop2: 0,
    winWidth: 0,
    winHeight: 0,
    scrollHeight: 0,
    totalCount: 0,
    // tab切换  
    currentTab: 0,
    userInformation: "",
    getState: "",
    getName: "",
    userName: "",
    loading: "",
    open: false,
    movies: [],
    movies1: [],
    movies2: [],
    movies3: [],
    movies4: [],
    url_img: app.globalData.url + "/File/Image?FileName="
  },
  onLoad: function onLoad(options) {
    var that = this;
    that.setData({
      userInformation: "",
      currentTab: 0
    });
    if (options.name) {
      that.setData({
        loading: options.name,
        userInformation: options.name,
        currentTab: 1
      });
      //this.get(options);   
      that.LoadData("130008000", 0);
      return;
    }
  },
  onShow: function onShow(options) {
    var that = this;
    that.setData({
      userInformation: ""
    });
    var userConfiguration = wx.getStorageSync('userConfiguration');
    var user1 = wx.setStorageSync('user');
    if (userConfiguration["Score/TaskManage/Create"] == 'true') {
      that.setData({
        open: true
      });
    } else {
      that.setData({
        open: false
      });
    }
    wx.getSystemInfo({
      success: function success(res) {
        if (res) {
          if (res.windowWidth) that.setData({
            winWidth: res.windowWidth
          });
          if (res.winHeight) that.setData({
            winWidth: res.winHeight
          });
          if (res.windowHeight) that.setData({
            scrollHeight: res.windowHeight
          });
        }
      }
    });
    if (that.data.loading == "") {
      that.LoadData("130008000", 0);
    }
  },
  //页面滑动到底部
  bindDownLoad: function bindDownLoad(e) {
    var that = this;
    if (flag) {
      flag = false;
      pageindex++;
      var count = parseInt(totalCount) % pagesize == 0 ? parseInt(totalCount) / pagesize : Math.floor(parseInt(totalCount) / pagesize);
      if (pageindex > count + 1) {
        //flag = true
        // wx.showModal({
        //   title: '提示信息',
        //   content: '下拉数据加载完毕！！',
        //   showCancel: false
        // })
        return;
      }
      /* if (userData == true) {
        that.get();
      }
      else {
        that.LoadData(data);
      } */
      that.LoadData(data);
    }
  },
  scroll: function scroll(event) {
    //该方法绑定了页面滚动时的事件，我这里记录了当前的position.y的值,为了请求数据之后把页面定位到这里来。
    var scroll = event.detail.scrollTop;
    var that = this;
    this.setData({
      lastScrollTop2: that.data.lastScrollTop,
      lastScrollTop: scroll
    });
  },
  swichNav: function swichNav(e) {
    var that = this;
    pageindex = 1;
    that.setData({
      movies: [],
      movies1: [],
      movies2: [],
      movies3: [],
      movies4: []
    });
    var current = e.target.dataset.current;
    //obj = data = current == "0" ? "130008005" : current == "1" ? "130008015" : current == "2" ? "130008020" : current == "3" ? "130008010" : "true"
    obj = data = current == "0" ? "130008000" : current == "1" ? "130008010" : current == "2" ? "130008015" : current == "3" ? "130008020" : "true";
    if (data == "130008020") {
      pagesize = 10;
    } else {
      pagesize = 100;
    }
    that.setData({
      currentTab: e.target.dataset.current
    });
    that.LoadData(data, 0);
  },
  //获取输入的用户信息
  input: function input(e) {
    var that = this;
    this.setData({
      userInformation: e.detail.value
    });
  },
  teamTask: function teamTask() {
    wx.navigateTo({
      url: '/pages/ucenter/teamTask/teamTask'
    });
  },
  //根据用户信息查询数据
  get: function get(data) {
    var that = this;
    if (data != null) {
      that.setData({
        getState: data.state ? data.state : data.currentTarget.dataset.state,
        getName: data.name
      });
    }
    var path = app.globalData.url + "/api/services/Score/TaskManage/GetAll";
    var obj = {
      searchGroup: {
        op: 1,
        rules: [{
          field: "State",
          value: data ? data.state == null ? that.data.getState : data.state : that.data.getState,
          op: 3
        }, {
          field: "Remark",
          value: "team",
          op: 4
        }, {
          field: "PublishIntroduce",
          value: that.data.userInformation,
          op: 7
        }]
      },
      sorting: "LastModificationTime DESC",
      pageSize: pagesize,
      pageIndex: pageindex
    };
    util.request(path, obj, "GET").then(function(res) {
      flag = true;
      totalCount = res.result.totalCount;
      if (res.success && res.result.items.length > 0) {
        var _iterator = _createForOfIteratorHelper2(res.result.items),
          _step;
        try {
          for (_iterator.s(); !(_step = _iterator.n()).done;) {
            var item = _step.value;
            item.name = user.getNameById(item.userId);
            if (item.creatorUserId != null) {
              if (item.userId != item.creatorUserId) {
                item.creatorUser = user.getNameById(item.creatorUserId) + "发布";
              }
            } else {
              item.creatorUser = "";
            }
            if (item.publishIntroduce.length > 15) {
              item.publishIntroduce = item.publishIntroduce.substring(0, 12) + "...";
            }
            if (item.startDate.toString().length > 10) {
              item.startDate = item.startDate.toString().substring(0, 10);
            }
            if (item.endDate.toString().length > 10) {
              item.endDate = item.endDate.toString().substring(0, 10);
            }
          }
        } catch (err) {
          err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
          _iterator.e(err);
        } finally {
          _iterator.f();
        }
      }
      wx.hideToast();
      that.setData({
        movies1: res.result.items
      });
    }, function(err) {
      flag = true;
      wx.hideToast();
    }, function(com) {
      wx.hideToast();
    });
    //this.onShow();
  },

  //根据任务信息查询数据
  query: function query(data) {
    var that = this;
    if (data != null) {
      that.setData({
        getState: data.state ? data.state : data.currentTarget.dataset.state,
        userName: user.getNameById(app.globalData.information.id)
      });
    }
    var path = app.globalData.url + "/api/services/Score/TaskManage/GetAll";
    var obj = {
      searchGroup: {
        op: 1,
        rules: [{
          field: "State",
          value: data ? data.state == null ? that.data.getState : data.state : that.data.getState,
          op: 3
        }, {
          field: "Name",
          value: that.data.userName,
          op: 3
        }, {
          field: "PublishIntroduce",
          value: that.data.userInformation,
          op: 7
        }]
      },
      sorting: "CreationTime DESC",
      pageSize: pagesize,
      pageIndex: pageindex
    };
    util.request(path, obj, "GET").then(function(res) {
      flag = true;
      totalCount = res.result.totalCount;
      if (res.success && res.result.items.length > 0) {
        var _iterator2 = _createForOfIteratorHelper2(res.result.items),
          _step2;
        try {
          for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
            var item = _step2.value;
            item.name = user.getNameById(item.userId);
            if (item.creatorUserId != null) {
              if (item.userId != item.creatorUserId) {
                item.creatorUser = user.getNameById(item.creatorUserId) + "发布";
              }
            } else {
              item.creatorUser = "";
            }
            if (item.publishIntroduce.length > 15) {
              item.publishIntroduce = item.publishIntroduce.substring(0, 12) + "...";
            }
            if (item.startDate.toString().length > 10) {
              item.startDate = item.startDate.toString().substring(0, 10);
            }
            if (item.endDate.toString().length > 10) {
              item.endDate = item.endDate.toString().substring(0, 10);
            }
          }
        } catch (err) {
          err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
          _iterator2.e(err);
        } finally {
          _iterator2.f();
        }
      }
      wx.hideToast();
      that.setData({
        movies2: res.result.items
      });
    }, function(err) {
      flag = true;
      wx.hideToast();
    }, function(com) {
      wx.hideToast();
    });
    //this.onShow();
  },

  addTask: function addTask() {
    var that = this;
    wx.showModal({
      title: '',
      content: '选择任务类型',
      cancelText: '单个任务',
      confirmText: '项目任务',
      success: function success(res) {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/ucenter/taskPlan/taskPlan'
          });
        } else if (res.cancel) {
          wx.navigateTo({
            url: '/pages/ucenter/taskManage/taskManage'
          });
        }
      }
    });
  },
  LoadData: function LoadData(data) {
    var that = this;
    wx.showLoading({
      icon: "loading",
      title: "正在加载......",
      mask: true
    });
    var path = app.globalData.url + "/api/services/Score/TaskManage/GetAll";
    obj = {
      searchGroup: {
        op: 1,
        rules: [{
          field: "State",
          value: data,
          op: 3
        }, {
          field: "Remark",
          value: "team",
          op: 4
        }]
      },
      sorting: "CreationTime DESC",
      pageSize: pagesize,
      pageIndex: pageindex
    };
    if (data == "130008010") {
      path = app.globalData.url + "/api/services/Score/TaskManage/GetAll";
      obj = {
        searchGroup: {
          op: 1,
          rules: [{
            field: "State",
            value: data,
            op: 3
          }, {
            field: "Remark",
            value: "team",
            op: 4
          }, {
            field: "Name",
            value: user.getNameById(app.globalData.information.id),
            op: 3
          }]
        },
        sorting: "CreationTime DESC",
        pageSize: pagesize,
        pageIndex: pageindex
      };
    }
    if (data == "130008000") {
      path = app.globalData.url + "/api/services/Score/TaskManage/GetAll";
      obj = {
        searchGroup: {
          op: 1,
          rules: [{
            field: "State",
            value: data,
            op: 3
          }, {
            field: "Remark",
            value: "team",
            op: 4
          }, {
            field: "Name",
            value: 'NULL',
            op: 3
          }]
        },
        sorting: "CreationTime DESC",
        pageSize: pagesize,
        pageIndex: pageindex
      };
    }
    if (data == "130008015") {
      path = app.globalData.url + "/api/services/Score/TaskManage/GetAll";
      obj = {
        searchGroup: {
          op: 1,
          rules: [{
            field: "State",
            value: data,
            op: 3
          }, {
            field: "PublishUserName",
            value: user.getNameById(app.globalData.information.id),
            op: 3
          }]
        },
        sorting: "CreationTime DESC",
        pageSize: pagesize,
        pageIndex: pageindex
      };
    }
    util.request(path, obj, "GET").then(function(res) {
      flag = true;
      totalCount = res.result.totalCount;
      if (res.success && res.result.items.length > 0) {
        var _iterator3 = _createForOfIteratorHelper2(res.result.items),
          _step3;
        try {
          for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
            var item = _step3.value;
            item.name = user.getNameById(item.userId);
            if (item.creatorUserId != null) {
              if (item.userId != item.creatorUserId) {
                item.creatorUser = user.getNameById(item.creatorUserId) + "发布";
              }
            } else {
              item.creatorUser = "";
            }
            if (item.publishIntroduce != null && item.publishIntroduce.length > 15) {
              item.publishIntroduce = item.publishIntroduce.substring(0, 12) + "...";
            }
            if (item.startDate != null && item.startDate.toString().length > 10) {
              item.startDate = item.startDate.toString().substring(0, 10);
            }
            if (item.endDate != null && item.endDate.toString().length > 10) {
              item.endDate = item.endDate.toString().substring(0, 10);
            }
          }
        } catch (err) {
          err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
          _iterator3.e(err);
        } finally {
          _iterator3.f();
        }
        wx.hideToast();
        if (res.success) {
          if (data == "130008015") {
            // var list = that.data.movies;
            // if (list.length >= 100) {
            //   for (var i = 0; i < 10; i++) {
            //     list.shift();
            //   }
            // }
            // for (var i = 0; i < res.result.items.length; i++) {
            //   var item = res.result.items[i];
            //   list.push(item);
            // }
            // that.setData({
            //   movies: list,
            // })
            that.setData({
              movies3: res.result.items
            });
          } else if (data == "130008000") {
            // var list = that.data.movies1;
            // if (list.length >= 100) {
            //   for (var i = 0; i < 10; i++) {
            //     list.shift();
            //   }
            // }
            // for (var i = 0; i < res.result.items.length; i++) {
            //   var item = res.result.items[i];
            //   list.push(item);
            // }
            // that.setData({
            //   movies1: list,
            // })
            that.setData({
              movies1: res.result.items
            });
          } else if (data == "130008020") {
            if (that.data.userInformation == "") {
              var list = that.data.movies2;
              var isRemove = false;
              // if (list.length >= 100) {
              //   isRemove = true;
              //   for (var i = 0; i < 10; i++) {
              //     list.shift();
              //   }
              // }
              for (var i = 0; i < res.result.items.length; i++) {
                var item = res.result.items[i];
                list.push(item);
              }
              that.setData({
                movies4: list
              });
            }
          } else if (data == "130008010") {
            // var list = that.data.movies3;
            // if (list.length >= 100) {
            //   for (var i = 0; i < 10; i++) {
            //     list.shift();
            //   }
            // }
            // for (var i = 0; i < res.result.items.length; i++) {
            //   var item = res.result.items[i];
            //   list.push(item);
            // }
            // that.setData({
            //   movies3: list,
            // })
            that.setData({
              movies2: res.result.items
            });
          } else if (data == "true") {
            var list = that.data.movies4;
            // if (list.length >= 100) {
            //   for (var i = 0; i < 10; i++) {
            //     list.shift();
            //   }
            // }
            for (var i = 0; i < res.result.items.length; i++) {
              var item = res.result.items[i];
              list.push(item);
            }
            that.setData({
              movies4: list
            });
            // that.setData({
            //   movies4: res.result,
            // })
          }
        }
      }

      // that.setData({
      //   scrollTop: that.data.lastScrollTop
      // });
      wx.hideLoading();
    }, function(err) {
      flag = true;
      wx.hideToast();
    }, function(com) {
      flag = true;
      wx.hideToast();
    });
  }
});