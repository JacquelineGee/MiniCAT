var _createForOfIteratorHelper2 = require("../../../@babel/runtime/helpers/createForOfIteratorHelper");
var util = require('../../../utils/util.js');
var api = require('../../../config/api.js');
var user = require('../../../utils/cache/user.js');
var app = getApp();
var obj = {};
var flag = true;
var pageindex = 1;
var pagesize = 500;
var data;
var userData = false;
var num = 1;
var totalCount;
Page({
  data: {
    scrollTop: 0,
    lastScrollTop: 0,
    lastScrollTop2: 0,
    winWidth: 0,
    winHeight: 0,
    scrollHeight: 0,
    totalCount: 0,
    // tab切换  
    currentTab: 0,
    userInformation: "",
    getState: "",
    getName: "",
    loading: "",
    movie: [],
    departmentList: [],
    hiddendep: true,
    nocancel: true,
    department: "",
    departmentId: 0,
    departments: "",
    departmentIds: "",
    movies: [],
    movies1: [],
    movies2: [],
    movies3: [],
    movies4: [],
    open: false,
    url_img: app.globalData.url + "/File/Image?FileName="
  },
  onLoad: function onLoad(options) {
    var that = this;
    that.setData({
      userInformation: ""
    });
    if (options.name) {
      that.setData({
        loading: options.name,
        userInformation: options.name,
        currentTab: 1
      });
      userData = true;
      this.get(options);
      return;
    }
    if (that.data.departmentId > 0) {
      /* that.setData({
        loading: options.departmentId,
        departmentId:that.departmentId
      }) */
      var option = {
        state: '130008015',
        departmentId: that.data.departmentId
      };
      that.get(option);
      return;
    }
    if (that.data.departmentId == 0) {
      that.LoadData("130008015", 0);
    }
  },
  onShow: function onShow(options) {
    var that = this;
    that.setData({
      userInformation: ""
    });
    var userConfiguration = wx.getStorageSync('userConfiguration');
    //console.log(userConfiguration);
    if (userConfiguration["Score/GradeManage/Create"] == 'true') {
      that.setData({
        open: true
      });
    } else {
      that.setData({
        open: false
      });
    }
    // if (app.globalData.information.id)
    wx.getSystemInfo({
      success: function success(res) {
        if (res) {
          if (res.windowWidth) that.setData({
            winWidth: res.windowWidth
          });
          if (res.winHeight) that.setData({
            winWidth: res.winHeight
          });
          if (res.windowHeight) that.setData({
            scrollHeight: res.windowHeight
          });
        }
      }
    });
    if (that.data.departmentId == 0) {
      that.LoadData("130008015", 0);
    } else {
      if (that.data.departmentId > 0) {
        var option = {
          state: '130008015',
          departmentId: that.data.departmentId
        };
        that.get(option);
      }
    }
    //console.log("departmentId:"+that.data.departmentId);
    var path = app.globalData.url + "/api/services/Foundation/OrganizationUnit/GetOrganizationUnits";
    var obj = {
      MaxResultCount: 2000,
      pageSize: 2000
    };
    util.request(path, obj, "Get").then(function(res) {
      that.setData({
        movie: res.result.items,
        departmentList: res.result.items
      });
    });
  },
  //部门
  bindAccountChange: function bindAccountChange(e) {
    var that = this;
    that.setData({
      hiddendep: false
    });
  },
  DepartmentChange: function DepartmentChange(e) {
    var that = this;
    that.setData({
      hiddendep: true,
      department: e.currentTarget.dataset.name,
      departmentId: e.currentTarget.dataset.index
    });
    //console.log("department:"+that.data.department+"   departmentId:"+that.data.departmentId);
    var option = {
      state: '130008015',
      departmentId: that.data.departmentId
    };
    that.get(option);
  },
  //明细部门
  bindAccountChanges: function bindAccountChanges(e) {
    var that = this;
    var temp = that.data.Item;
    temp[parseInt(e.currentTarget.dataset.data)].hiddendeps = false;
    that.setData({
      Item: temp
    });
  },
  DepartmentChanges: function DepartmentChanges(e) {
    var that = this;
    var temp = that.data.Item;
    temp[parseInt(e.currentTarget.dataset.data)].departmentName = e.currentTarget.dataset.name;
    temp[parseInt(e.currentTarget.dataset.data)].department = e.currentTarget.dataset.id;
    temp[parseInt(e.currentTarget.dataset.data)].hiddendeps = true;
    that.setData({
      Item: temp
    });
  },
  //取消弹出框
  confirm: function confirm(e) {
    var that = this;
    that.setData({
      hiddendep: true,
      hiddenCompany: true,
      hiddenlabor: true
    });
  },
  //页面滑动到底部
  bindDownLoad: function bindDownLoad(e) {
    var that = this;
    if (flag) {
      flag = false;
      pageindex++;
      var count = parseInt(totalCount) % pagesize == 0 ? parseInt(totalCount) / pagesize : Math.floor(parseInt(totalCount) / pagesize);
      if (pageindex > count + 1) {
        //flag = true
        // wx.showModal({
        //   title: '提示信息',
        //   content: '下拉数据加载完毕！！',
        //   showCancel: false
        // })
        return;
      }
      if (userData == true) {
        that.get();
      } else {
        that.LoadData(data);
      }
    }
  },
  // bindTopLoad(){
  //   var that = this;
  //   if (flag) {
  //     flag = false
  //     console.log(pageindex)
  //     pageindex--;
  //     if (pageindex <= 0) {
  //       return;
  //     }
  //     that.LoadData(data);
  //   }
  // },
  scroll: function scroll(event) {
    //该方法绑定了页面滚动时的事件，我这里记录了当前的position.y的值,为了请求数据之后把页面定位到这里来。
    var scroll = event.detail.scrollTop;
    var that = this;
    this.setData({
      lastScrollTop2: that.data.lastScrollTop,
      lastScrollTop: scroll
    });
  },
  /** 
   * 滑动切换tab 
   */
  // bindChange: function (e) {
  //   var that = this;
  //   that.setData({
  //     movies: [],
  //     movies1: [],
  //     movies2: [],
  //     movies3: [],
  //     movies4: [],
  //   })
  //   var current = e.detail.current
  //   data = current == "0" ? "130008005" : current == "1" ? "130008015" : current == "2" ? "130008020" : current == "3" ? "130008010" : "true"
  //   that.setData({ currentTab: e.detail.current });
  //   that.LoadData(data, 0);
  // },
  /** 
   * 点击tab切换 
   */
  swichNav: function swichNav(e) {
    var that = this;
    pageindex = 1;
    that.setData({
      movies: [],
      movies1: [],
      movies2: [],
      movies3: [],
      movies4: []
    });
    var current = e.target.dataset.current;
    // obj = data = current == "0" ? "130008005" : current == "1" ? "130008015" : current == "2" ? "130008020" : current == "3" ? "130008010" : "true"
    obj = data = current == "0" ? "130008015" : current == "1" ? "130008020" : current == "2" ? "130008010" : "true";
    if (data == "130008020" || data == "true") {
      pagesize = 100;
    } else {
      pagesize = 100;
    }
    that.setData({
      currentTab: e.target.dataset.current
    });
    that.LoadData(data, 0);
  },
  //获取输入的用户信息
  input: function input(e) {
    var that = this;
    this.setData({
      userInformation: e.detail.value
    });
  },
  //根据用户信息查询数据
  get: function get(data) {
    var that = this;
    //console.log("data:"+data.departmentId);
    if (data != null) {
      if (data.departmentId > 0) {
        that.setData({
          getState: data.state ? data.state : data.currentTarget.dataset.state,
          departmentId: data.departmentId
        });
      } else {
        that.setData({
          getState: data.state ? data.state : data.currentTarget.dataset.state,
          getName: data.name
        });
      }
    }
    //console.log("departmentId:"+that.data.departmentId);
    var path = app.globalData.url + "/api/services/Score/GradeManage/GetAll";
    if (data.departmentId > 0) {
      var obj = {
        searchGroup: {
          op: 1,
          rules: [{
            field: "State",
            value: "130008015",
            op: 3
          }, {
            field: "OrganizationUnitId",
            value: that.data.departmentId,
            op: 3
          }]
        },
        sorting: "CreationTime DESC",
        pageSize: pagesize,
        pageIndex: pageindex
      };
    } else {
      var obj = {
        searchGroup: {
          op: 1,
          rules: [{
            field: "State",
            value: data ? data.state == null ? that.data.getState : data.state : that.data.getState,
            op: 3
          }, {
            field: "Name",
            value: that.data.userInformation,
            op: 7
          }]
        },
        sorting: "CreationTime DESC",
        pageSize: pagesize,
        pageIndex: pageindex
      };
    }
    //console.log(obj);   
    util.request(path, obj, "GET").then(function(res) {
      flag = true;
      totalCount = res.result.totalCount;
      if (res.success && res.result.items.length > 0) {
        var _iterator = _createForOfIteratorHelper2(res.result.items),
          _step;
        try {
          for (_iterator.s(); !(_step = _iterator.n()).done;) {
            var item = _step.value;
            item.name = user.getNameById(item.userId);
            //console.log(item.name+item.id);
            if (item.creatorUserId != null) {
              if (item.userId != item.creatorUserId) {
                item.creatorUser = user.getNameById(item.creatorUserId) + "帮";
              }
            } else {
              item.creatorUser = "";
            }
            if (item.image) {
              var result = item.image.split("|");
              item.image = result[0];
            }
          }
        } catch (err) {
          err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
          _iterator.e(err);
        } finally {
          _iterator.f();
        }
      }
      wx.hideToast();
      //if (data ? data.state : that.data.getState) {
      if (data.state == "130008020") {
        var list = that.data.movies2;
        if (list.length >= 100) {
          for (var i = 0; i < 10; i++) {
            list.shift();
          }
        }
        for (var i = 0; i < res.result.items.length; i++) {
          var item = res.result.items[i];
          list.push(item);
        }
        that.setData({
          movies2: list,
          movies1: list
        });
      } else {
        if (data.state == "130008015") {
          that.setData({
            movies1: res.result.items
          });
        }
      }
    }, function(err) {
      flag = true;
      wx.hideToast();
    }, function(com) {
      wx.hideToast();
    });
  },
  LoadData: function LoadData(data) {
    var that = this;
    wx.showLoading({
      icon: "loading",
      title: "正在加载......",
      mask: true
    });
    var path = data == "true" ? app.globalData.url + "/api/services/Score/GradeManage/GetGradeManageTop" : app.globalData.url + "/api/services/Score/GradeManage/GetAll";
    obj = data == "true" ? {
      searchGroup: {
        op: 1,
        rules: [{
          field: "Top",
          value: data,
          op: 3
        }]
      },
      sorting: "CreationTime DESC",
      pageSize: pagesize,
      pageIndex: pageindex
    } : {
      searchGroup: {
        op: 1,
        rules: [{
          field: "State",
          value: data,
          op: 3
        }]
      },
      sorting: "CreationTime DESC",
      pageSize: pagesize,
      pageIndex: pageindex
    };
    if (data == "130008010") {
      path = app.globalData.url + "/api/services/Score/GradeManage/GetAll";
      obj = {
        searchGroup: {
          op: 1,
          rules: [{
            field: "State",
            value: data,
            op: 3
          }, {
            field: "CreatorUserId",
            value: app.globalData.information.id,
            op: 3
          }]
        },
        sorting: "CreationTime DESC",
        pageSize: pagesize,
        pageIndex: pageindex
      };
    }
    util.request(path, obj, "GET").then(function(res) {
      flag = true;
      totalCount = res.result.totalCount;
      if (res.success && res.result.items.length > 0) {
        var _iterator2 = _createForOfIteratorHelper2(res.result.items),
          _step2;
        try {
          for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
            var item = _step2.value;
            item.name = user.getNameById(item.userId);
            if (item.creatorUserId != null) {
              if (item.userId != item.creatorUserId) {
                item.creatorUser = user.getNameById(item.creatorUserId) + "帮";
              }
            } else {
              item.creatorUser = "";
            }
            if (item.image) {
              var result = item.image.split("|");
              item.image = result[0];
            }
          }
        } catch (err) {
          err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
          _iterator2.e(err);
        } finally {
          _iterator2.f();
        }
        wx.hideToast();
        if (res.success) {
          if (data == "130008005") {
            // var list = that.data.movies;
            // if (list.length >= 100) {
            //   for (var i = 0; i < 10; i++) {
            //     list.shift();
            //   }
            // }
            // for (var i = 0; i < res.result.items.length; i++) {
            //   var item = res.result.items[i];
            //   list.push(item);
            // }
            // that.setData({
            //   movies: list,
            // })
            that.setData({
              movies: res.result.items
            });
          } else if (data == "130008015") {
            // var list = that.data.movies1;
            // if (list.length >= 100) {
            //   for (var i = 0; i < 10; i++) {
            //     list.shift();
            //   }
            // }
            // for (var i = 0; i < res.result.items.length; i++) {
            //   var item = res.result.items[i];
            //   list.push(item);
            // }
            // that.setData({
            //   movies1: list,
            // })
            that.setData({
              movies1: res.result.items
            });
          } else if (data == "130008020") {
            if (that.data.userInformation == "") {
              var list = that.data.movies2;
              var isRemove = false;
              // if (list.length >= 100) {
              //   isRemove = true;
              //   for (var i = 0; i < 10; i++) {
              //     list.shift();
              //   }
              // }
              for (var i = 0; i < res.result.items.length; i++) {
                var item = res.result.items[i];
                list.push(item);
              }
              that.setData({
                movies2: list
              });
            }
          } else if (data == "130008010") {
            // var list = that.data.movies3;
            // if (list.length >= 100) {
            //   for (var i = 0; i < 10; i++) {
            //     list.shift();
            //   }
            // }
            // for (var i = 0; i < res.result.items.length; i++) {
            //   var item = res.result.items[i];
            //   list.push(item);
            // }
            // that.setData({
            //   movies3: list,
            // })
            that.setData({
              movies3: res.result.items
            });
          } else if (data == "true") {
            var list = that.data.movies4;
            // if (list.length >= 100) {
            //   for (var i = 0; i < 10; i++) {
            //     list.shift();
            //   }
            // }
            for (var i = 0; i < res.result.items.length; i++) {
              var item = res.result.items[i];
              list.push(item);
            }
            that.setData({
              movies4: list
            });
            // that.setData({
            //   movies4: res.result,
            // })
          }
        }
      }

      // that.setData({
      //   scrollTop: that.data.lastScrollTop
      // });
      wx.hideLoading();
    }, function(err) {
      flag = true;
      wx.hideToast();
    }, function(com) {
      flag = true;
      wx.hideToast();
    });
  }
});