var _defineProperty2 = require("../../../@babel/runtime/helpers/defineProperty");
var _data;
var app = getApp();
var WxParse = require('../../../lib/wxParse/wxParse.js');
var util = require('../../../utils/util.js');
var departmentcache = require('../../../utils/cache/department.js');
var accountcache = require('../../../utils/cache/account.js');
var paymentModecache = require('../../../utils/cache/paymentMode.js');
var array = [];
var items;
Page({
  data: (_data = {
    Item: [],
    nodeID: [],
    workFlowAction: [],
    workFlowTemp: [],
    movie: [],
    department: [],
    userName: [],
    displayId: "",
    winWidth: 0,
    category: "",
    openuser: "",
    open1: "",
    startTime: "",
    displayName: ''
  }, _defineProperty2(_defineProperty2(_defineProperty2(_defineProperty2(_defineProperty2(_defineProperty2(_defineProperty2(_defineProperty2(_defineProperty2(_defineProperty2(_data, "displayId", ''), "payOrderTemplateName", ''), "payOrderTemplateId", ''), "account", ''), "accountId", ''), "accountno", ''), "accounts", ''), "account1", ''), "distributionId", ''), "distributionName", ''), _defineProperty2(_defineProperty2(_defineProperty2(_defineProperty2(_defineProperty2(_defineProperty2(_defineProperty2(_defineProperty2(_defineProperty2(_data, "totalAmount", ''), "cycleDistribution", ''), "salaryManageId", ""), "lastWorkFlowId", ""), "remark", ""), "state", ""), "open", false), "openstate", true), "open1state", true)),
  onLoad: function onLoad(options) {
    var that = this;
    var userConfiguration = wx.getStorageSync('userConfiguration');
    if (userConfiguration["Salary/SalaryManagement/Approve"] == 'true') {
      that.setData({
        open: true
      });
    }
    //console.log(userConfiguration);
    var path = app.globalData.url + "/api/services/WorkFlow/WFTemplate/GetWFTemplateByType";
    var obj = {
      Type: "160205088",
      Param: "",
      organizationUnitId: app.globalData.information.organizationUnitId,
      pageSize: 2000
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      that.setData({
        workFlowTemp: res.result
      });
    });
    that.setData({
      salaryManageId: options.id
    });
    var path = app.globalData.url + "/api/services/Salary/SalaryManage/Get";
    var obj = {
      Id: options.id
    };
    var Get = util.getQueryUrl(path, obj);
    util.request(Get).then(function(res) {
      if (res.success) {
        that.setData({
          state: res.result.state,
          no: res.result.state == "130008005" || res.result.state == "130008020" || res.result.top == "1" ? true : false,
          open: res.result.state == "130008020" ? false : true,
          open1: res.result.state == "130008005" ? true : false,
          lastWorkFlowId: res.result.lastWorkFlowId
        });
        var path = app.globalData.url + "/api/services/Salary/SalaryManage/GetSalaryManageReportsState";
        var obj = {
          salaryManageId: options.id
        };
        var Get = util.getQueryUrl(path, obj);
        util.request(Get).then(function(res) {
          items = JSON.parse(res.result);
          var firstItem = items[0];
          var columns = [];
          for (var key in firstItem) {
            var parentKey = key;
            var deptName = departmentcache.getNameById(parentKey);
            var tableColumn = {
              property: key,
              text: deptName
            };
            tableColumn["text"] = parentKey;
            columns.push(tableColumn);
          }
          that.setData({
            movie: columns,
            winWidth: 90 * columns.length
          });
          that.setData({
            movies: items
          });
        });
      }
      if (that.data.lastWorkFlowId) {
        var pathFkID = app.globalData.url + "/api/services/WorkFlow/WorkFlowNode/GetAll";
        var objFkID = {
          searchGroup: {
            rules: [{
              field: "FlowID",
              value: that.data.lastWorkFlowId
            }]
          },
          pageSize: 2000
        };
        var GetDataFkID = util.getQueryUrl(pathFkID, objFkID);
        util.request(GetDataFkID).then(function(res) {
          var item = res.result.items;
          var items = item.filter(function(x) {
            return x.isCurrent == true;
          });
          if (items && items.length > 0) {
            that.setData({
              nodeID: items[0]
            });
            if (that.data.nodeID.userID == app.globalData.information.id || userConfiguration["Salary/SalaryManage/Approve"] == 'true') {
              var path = app.globalData.url + "/api/services/WorkFlow/WorkFlowAction/GetAll";
              var obj = {
                searchGroup: {
                  rules: [{
                    field: "NodeID",
                    value: that.data.nodeID.id
                  }]
                },
                sorting: "LastModificationTime DESC",
                pageSize: 2000
              };
              var GetData = util.getQueryUrl(path, obj);
              util.request(GetData).then(function(res) {
                if (that.data.state == "130008020") {
                  that.setData({
                    open: false
                  });
                } else {
                  that.setData({
                    workFlowAction: res.result.items,
                    open: true
                  });
                }
              });
            } else {
              that.setData({
                open: false
              });
            }
          }
        });
      }
    });
  },
  bindopinionInput: function bindopinionInput(e) {
    var that = this;
    this.setData({
      remark: e.detail.value
    });
  },
  reject: function reject(e) {
    var that = this;
    var bool = e.currentTarget.dataset.cmd == "pass" ? true : false;
    if (!bool) {
      if (!that.data.remark) {
        wx.showModal({
          title: '提示信息',
          content: '请输入审核意见~~',
          showCancel: false
        });
        return;
      }
    }
    if (that.data.openstate) {
      that.setData({
        openstate: false
      });
      var path = app.globalData.url + "/api/services/Salary/SalaryManage/ChangeState";
      var obj = {
        id: that.data.salaryManageId,
        state: "130008020",
        workFlowId: that.data.lastWorkFlowId,
        workNodeId: that.data.nodeID.id,
        workActionId: e.currentTarget.dataset.id,
        cMD: e.currentTarget.dataset.cmd,
        userId: app.globalData.information.id,
        remark: that.data.remark,
        data: {
          id: that.data.salaryManageId,
          state: bool ? "130008020" : "130008010",
          remark: that.data.remark
        }
      };
      util.request(path, obj, "POST").then(function(res) {
        if (res.success) {
          wx.navigateBack(1);
        }
      });
    }
    //}
  }
});