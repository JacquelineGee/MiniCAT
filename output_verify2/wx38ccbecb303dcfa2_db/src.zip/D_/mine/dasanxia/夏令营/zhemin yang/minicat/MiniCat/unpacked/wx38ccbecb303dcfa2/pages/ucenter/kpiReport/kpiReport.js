var _createForOfIteratorHelper2 = require("../../../@babel/runtime/helpers/createForOfIteratorHelper");
var util = require('../../../utils/util.js');
var api = require('../../../config/api.js');
var user = require('../../../utils/cache/user.js');
var app = getApp();
var obj = {};
var flag = true;
var pageindex = 1;
var pagesize = 100;
var data;
var userData = false;
var num = 1;
var totalCount;
Page({
  data: {
    scrollTop: 0,
    lastScrollTop: 0,
    lastScrollTop2: 0,
    winWidth: 0,
    winHeight: 0,
    scrollHeight: 0,
    totalCount: 0,
    totalscore: 0,
    totalscore1: 0,
    // tab切换  
    currentTab: 0,
    userInformation: "",
    date: "",
    getState: "",
    getName: "",
    userName: "",
    loading: "",
    userId: "",
    startTime: "",
    open: false,
    movies: [],
    movies1: [],
    movies2: [],
    movies3: [],
    movies4: [],
    url_img: app.globalData.url + "/File/Image?FileName="
  },
  onLoad: function onLoad(options) {
    var that = this;
    var time = that.FormatMonth();
    if (that.data.startTime == "") {
      that.setData({
        startTime: time,
        movies2: [{
          content: "",
          id: "",
          score: 0,
          state: "",
          userId: 0
        }, {
          content: "",
          id: "",
          score: 0,
          state: "",
          userId: 0
        }, {
          content: "",
          id: "",
          score: 0,
          state: "",
          userId: 0
        }, {
          content: "",
          id: "",
          score: 0,
          state: "",
          userId: 0
        }, {
          content: "",
          id: "",
          score: 0,
          state: "",
          userId: 0
        }, {
          content: "",
          id: "",
          score: 0,
          state: "",
          userId: 0
        }, {
          content: "",
          id: "",
          score: 0,
          state: "",
          userId: 0
        }, {
          content: "",
          id: "",
          score: 0,
          state: "",
          userId: 0
        }, {
          content: "",
          id: "",
          score: 0,
          state: "",
          userId: 0
        }, {
          content: "",
          id: "",
          score: 0,
          state: "",
          userId: 0
        }],
        userName: options.id ? user.getNameById(options.id) : user.getNameById(app.globalData.information.id),
        userId: options.id ? options.id : app.globalData.information.id
      });
    }
    that.setData({
      userInformation: ""
    });
    if (options.id) {
      that.setData({
        loading: user.getNameById(options.id),
        userInformation: user.getNameById(options.id),
        startTime: options.startTime == "请选择时间" ? that.data.startTime : options.startTime.substr(0, 7)
      });
      userData = true;
      // console.log("options.startTime:"+options.startTime);
      var obj = {
        userId: options.id,
        name: that.data.userInformation,
        //date: that.data.startTime+"-01 00:00:00.0000000",
        date: options.startTime == "请选择时间" ? that.data.startTime : options.startTime.substr(0, 7),
        startTime: options.startTime == "请选择时间" ? that.data.startTime : options.startTime.substr(0, 7)
      };
      this.get(obj);
      return;
    }
  },
  onShow: function onShow(options) {
    var that = this;
    that.setData({
      userInformation: ""
    });
    wx.getSystemInfo({
      success: function success(res) {
        if (res) {
          if (res.windowWidth) that.setData({
            winWidth: res.windowWidth
          });
          if (res.winHeight) that.setData({
            winHeight: res.winHeight
          });
          if (res.windowHeight) that.setData({
            scrollHeight: res.windowHeight
          });
        }
      }
    });
    that.setData({
      winWidth: 90 * 7
    });
    if (that.data.loading == "") {
      that.LoadData("130008020", 0);
    }
  },
  FormatMonth: function FormatMonth() {
    var date = new Date();
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    m = m < 10 ? '0' + m : m;
    return y + "-" + m;
  },
  datePicker: function datePicker(e) {
    this.setData({
      startTime: e.detail.value
    });
    var obj = {
      userId: this.data.userId,
      name: this.data.userInformation,
      date: this.data.startTime + "-01 00:00:00.0000000"
    };
    //console.log(obj);   
    this.get(obj);
  },
  //页面滑动到底部
  bindDownLoad: function bindDownLoad(e) {
    var that = this;
    if (flag) {
      flag = false;
      pageindex++;
      var count = parseInt(totalCount) % pagesize == 0 ? parseInt(totalCount) / pagesize : Math.floor(parseInt(totalCount) / pagesize);
      if (pageindex > count + 1) {
        return;
      }
      if (userData == true) {
        that.get();
      } else {
        that.LoadData(data);
      }
    }
  },
  scroll: function scroll(event) {
    //该方法绑定了页面滚动时的事件，我这里记录了当前的position.y的值,为了请求数据之后把页面定位到这里来。
    var scroll = event.detail.scrollTop;
    var that = this;
    this.setData({
      lastScrollTop2: that.data.lastScrollTop,
      lastScrollTop: scroll
    });
  },
  //获取输入的用户信息
  input: function input(e) {
    var that = this;
    this.setData({
      userInformation: e.detail.value
    });
  },
  //根据用户信息查询数据
  get: function get(data) {
    var that = this;
    if (data != null) {
      that.setData({
        getName: data.name,
        date: data.date
      });
    }
    var path = app.globalData.url + "/api/services/Salary/KpiManage/GetAll";
    var obj = {
      searchGroup: {
        op: 1,
        rules: [{
          field: "State",
          value: "130008020",
          op: 3
        }, {
          field: "UserId",
          value: data.userId == null ? app.globalData.information.id : that.data.userId,
          op: 3
        }, {
          field: "Date",
          value: data.date == null ? that.data.startTime + "-01 00:00:00.0000000" : that.data.date,
          op: 3
        }]
      },
      sorting: "CreationTime DESC",
      pageSize: pagesize,
      pageIndex: pageindex
    };
    //console.log("that.data.startTime:"+that.data.startTime);
    util.request(path, obj, "GET").then(function(res) {
      flag = true;
      totalCount = res.result.totalCount;
      if (res.success && res.result.items.length > 0) {
        //console.log(res.result.items);
        var _iterator = _createForOfIteratorHelper2(res.result.items),
          _step;
        try {
          for (_iterator.s(); !(_step = _iterator.n()).done;) {
            var item = _step.value;
            item.name = user.getNameById(item.userId);
            if (item.creatorUserId != null) {} else {
              item.creatorUser = "";
            }
            if (item.image) {
              var result = item.image.split("|");
              item.image = result[0];
            }
          }
        } catch (err) {
          err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
          _iterator.e(err);
        } finally {
          _iterator.f();
        }
      }
      wx.hideToast();
      //if (data.state == "130008020") {
      var _iterator2 = _createForOfIteratorHelper2(res.result.items),
        _step2;
      try {
        for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
          var item = _step2.value;
          if (item.content.length >= 32) {
            item.content = item.content.substring(0, 32) + "...";
          }
        }
      } catch (err) {
        err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
        _iterator2.e(err);
      } finally {
        _iterator2.f();
      }
      var sumscore = 0;
      var sumscore1 = 0;
      for (var i = 0; i < res.result.items.length; i++) {
        var item = res.result.items[i];
        sumscore = sumscore + item.score4;
        sumscore1 = sumscore1 + item.score1;
      }
      that.setData({
        movies2: res.result.items,
        totalscore: sumscore,
        totalscore1: sumscore1
      });
      //}
    }, function(err) {
      flag = true;
      wx.hideToast();
    }, function(com) {
      wx.hideToast();
    });
  },
  LoadData: function LoadData(data) {
    var that = this;
    wx.showLoading({
      icon: "loading",
      title: "正在加载......",
      mask: true
    });
    var path = app.globalData.url + "/api/services/Salary/KpiManage/GetAll";
    var obj = {
      searchGroup: {
        op: 1,
        rules: [{
          field: "State",
          value: data,
          op: 3
        }, {
          field: "UserId",
          value: app.globalData.information.id,
          op: 3
        }, {
          field: "Date",
          value: data.date == null ? that.data.startTime + "-01 00:00:00.0000000" : that.data.date,
          op: 3
        }]
      },
      sorting: "CreationTime DESC",
      pageSize: pagesize,
      pageIndex: pageindex
    };
    //console.log(obj.searchGroup);
    util.request(path, obj, "GET").then(function(res) {
      flag = true;
      totalCount = res.result.totalCount;
      if (res.success && res.result.items.length > 0) {
        var _iterator3 = _createForOfIteratorHelper2(res.result.items),
          _step3;
        try {
          for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
            var item = _step3.value;
            item.name = user.getNameById(item.userId);
            if (item.content.length >= 32) {
              item.content = item.content.substring(0, 32) + "...";
            }
          }
        } catch (err) {
          err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
          _iterator3.e(err);
        } finally {
          _iterator3.f();
        }
        wx.hideToast();
        if (res.success) {
          if (data == "130008020") {
            if (that.data.userInformation == "") {
              var sumscore = 0;
              var sumscore1 = 0;
              for (var i = 0; i < res.result.items.length; i++) {
                var item = res.result.items[i];
                sumscore = sumscore + item.score4;
                sumscore1 = sumscore1 + item.score1;
              }
              that.setData({
                movies2: res.result.items,
                totalscore: sumscore,
                totalscore1: sumscore1
              });
            }
          }
        }
      }
      wx.hideLoading();
    }, function(err) {
      flag = true;
      wx.hideToast();
    }, function(com) {
      flag = true;
      wx.hideToast();
    });
  }
});