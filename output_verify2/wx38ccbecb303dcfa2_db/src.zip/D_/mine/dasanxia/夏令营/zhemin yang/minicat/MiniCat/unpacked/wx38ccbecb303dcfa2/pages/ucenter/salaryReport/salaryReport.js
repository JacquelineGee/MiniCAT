var app = getApp();
var WxParse = require('../../../lib/wxParse/wxParse.js');
var util = require('../../../utils/util.js');
var department = require('../../../utils/cache/department.js');
var items;
Page({
  data: {
    movie: [],
    department: [],
    userName: [],
    displayName: "部门",
    displayMonth: "",
    startTime: "请选择时间",
    endTime: "请选择时间",
    displayId: "",
    winWidth: 0,
    category: ""
  },
  onLoad: function onLoad(options) {
    var that = this;
    var time = that.FormatMonth();
    if (that.data.displayMonth == "") {
      that.setData({
        displayMonth: time
      });
    };
    var days = that.getDays(that.data.displayMonth);
    that.setData({
      startTime: that.data.displayMonth + "-01 00:00:00.0000000",
      endTime: that.data.displayMonth + "-" + days.toString() + " 23:59:59.9999999"
    });
    wx.getSystemInfo({
      success: function success(res) {
        that.setData({
          winWidth: res.winWidth
        });
      }
    });
    wx.showLoading({
      icon: "loading",
      title: "正在加载......",
      mask: true
    });
    var path = app.globalData.url + "/api/services/Salary/SalaryManage/GetSalaryManageReportsUserId";
    var obj = {};
    util.request(path, obj, "Get").then(function(res) {
      items = JSON.parse(res.result);
      var firstItem = items[0];
      var columns = [];
      for (var key in firstItem) {
        var parentKey = key;
        var deptName = department.getNameById(parentKey);
        var tableColumn = {
          property: key,
          text: deptName
        };
        tableColumn["text"] = parentKey;
        columns.push(tableColumn);
      }
      that.setData({
        movie: columns,
        winWidth: 90 * columns.length
      });
      that.setData({
        movies: items
      });
      //console.log(that.data.movies);
      wx.hideLoading();
    }, function(error) {
      wx.hideLoading();
      wx.showModal({
        title: '提示信息',
        content: error.error.message,
        //content: "没有此月工资数据，请核对查询时间！",
        showCancel: false
      });
    });
  },
  department: function department() {
    this.setData({
      openuser: !this.data.openuser
    });
    var that = this;
    var path = app.globalData.url + "/api/services/Foundation/OrganizationUnit/GetOrganizationUnits";
    var obj = {
      MaxResultCount: 2000,
      pageSize: 2000
    };
    util.request(path, obj, "Get").then(function(res) {
      that.setData({
        department: res.result.items
      });
    });
  },
  userone: function userone(e) {
    this.setData({
      displayName: e.currentTarget.dataset.index,
      displayId: e.currentTarget.dataset.id,
      openuser: !this.data.openuser
    });
  },
  datePicker: function datePicker(e) {
    var that = this;
    that.setData({
      displayMonth: e.detail.value
    });
    var days = that.getDays(that.data.displayMonth);
    that.setData({
      startTime: that.data.displayMonth + "-01 00:00:00",
      endTime: that.data.displayMonth + "-" + days.toString() + " 23:59:59"
    });
    //console.log(that.data.startTime);
    //console.log(that.data.endTime);
    that.get(false);
  },
  get: function get(e) {
    var that = this;
    wx.getSystemInfo({
      success: function success(res) {
        that.setData({
          winWidth: res.winWidth
        });
      }
    });
    wx.showLoading({
      icon: "loading",
      title: "正在加载......",
      mask: true
    });
    var path = app.globalData.url + "/api/services/Salary/SalaryManage/GetSalaryManageReportsUserId";
    var obj = {
      startTime: that.data.startTime,
      endTime: that.data.endTime
    };
    util.request(path, obj, "Get").then(function(res) {
      items = JSON.parse(res.result);
      var firstItem = items[0];
      var columns = [];
      for (var key in firstItem) {
        var parentKey = key;
        var deptName = department.getNameById(parentKey);
        var tableColumn = {
          property: key,
          text: deptName
        };
        tableColumn["text"] = parentKey;
        columns.push(tableColumn);
      }
      that.setData({
        movie: columns,
        winWidth: 90 * columns.length
      });
      that.setData({
        movies: items
      });

      //console.log(that.data.movies);
      wx.hideLoading();
    }, function(error) {
      wx.hideLoading();
      wx.showModal({
        title: '提示信息',
        content: error.error.message,
        showCancel: false
      });
    });
    /*  wx.showLoading({
       icon: "loading",
       title: "正在加载......",
       mask: true
     })
     var path = app.globalData.url + "/api/services/Salary/SalaryManage/GetSalaryManageReportsUserId"
     var obj = {        
       startTime: that.data.startTime,
       endTime: that.data.endTime
     }
     console.log(obj);
     util.request(path, obj, "Get").then((res) => {
       if (res.success){
         if (res.result.state == 1) {
           items = JSON.parse(res.result);
       console.log(items);
       var firstItem = items[0];
       var columns = [];
       for (var key in firstItem) {
         
         var parentKey = key;
         var deptName = department.getNameById(parentKey);
         var tableColumn = {
           property: key,
           text: deptName,
         };
        
           tableColumn["text"] = parentKey;
         
         columns.push(tableColumn);
       }
       that.setData({
         movie: columns,
         winWidth: 90 * columns.length
       })
       
       that.setData({
         movies: items
       }) 
         }
         else{
           console.log('查询失败1');
           wx.showModal({
             title: '错误信息',
             content: '没有该月工资，请检查！',
             showCancel: false
           });
         } 
          
       }
       if (res.fail){
         console.log('查询失败2');
       }
              
     }) */

    wx.hideLoading();
  },
  FormatMonth: function FormatMonth() {
    var date = new Date();
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    m = m < 10 ? '0' + m : m;
    return y + "-" + m;
  },
  getDays: function getDays(options) {
    var monthDaySize;
    var month = parseInt(options.substring(5, 7));
    var year = parseInt(options.substring(0, 5));
    //console.log(options.substring(5, 6));
    if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) {
      monthDaySize = 31;
    } else if (month == 4 || month == 6 || month == 9 || month == 11) {
      monthDaySize = 30;
    } else if (month == 2) {
      // 计算是否是闰年,如果是二月份则是29天
      if ((year - 2000) % 4 == 0) {
        monthDaySize = 29;
      } else {
        monthDaySize = 28;
      }
    };
    return monthDaySize;
  }
});