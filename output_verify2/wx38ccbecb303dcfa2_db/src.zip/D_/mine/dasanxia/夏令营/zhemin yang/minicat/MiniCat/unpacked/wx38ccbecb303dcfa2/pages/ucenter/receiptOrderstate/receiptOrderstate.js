var app = getApp();
var WxParse = require('../../../lib/wxParse/wxParse.js');
var util = require('../../../utils/util.js');
var departmentcache = require('../../../utils/cache/department.js');
var accountcache = require('../../../utils/cache/account.js');
var paymentModecache = require('../../../utils/cache/paymentMode.js');
var array = [];
Page({
  data: {
    Item: [],
    nodeID: [],
    workFlowAction: [],
    workFlowTemp: [],
    open1: "",
    account: '',
    receiptOrderId: "",
    lastWorkFlowId: "",
    companyName: "",
    department: "",
    departmentName: "",
    remark: "",
    state: "",
    open: true,
    openstate: true,
    open1state: true
  },
  onLoad: function onLoad(options) {
    var that = this;
    var userConfiguration = wx.getStorageSync('userConfiguration');
    that.setData({
      receiptOrderId: options.id
    });
    var path = app.globalData.url + "/api/services/Finace/ReceiptOrder/Get";
    var obj = {
      Id: options.id
    };
    var Get = util.getQueryUrl(path, obj);
    util.request(Get).then(function(res) {
      if (res.success) {
        that.setData({
          companyName: res.result.bU_Name,
          companyId: that.data.bU_Id,
          departmentName: res.result.departmentName,
          state: res.result.state,
          no: res.result.state == "130008005" || res.result.state == "130008020" || res.result.top == "1" ? true : false,
          open: res.result.state == "130008020" ? false : true,
          open1: res.result.state == "130008005" ? true : false,
          lastWorkFlowId: res.result.lastWorkFlowId
        });
        var path = app.globalData.url + "/api/services/Finace/ReceiptOrderItem/GetAll";
        var obj = {
          searchGroup: {
            rules: [{
              field: "receiptOrderId",
              value: options.id
            }]
          },
          pageSize: 2000
        };
        var Get = util.getQueryUrl(path, obj);
        util.request(Get).then(function(res) {
          for (var i = 0; i < res.result.items.length; i++) {
            res.result.items[i].department = departmentcache.getNameById(res.result.items[i].department);
            if (!res.result.items[i].name) {
              res.result.items[i].name = accountcache.getNameById(res.result.items[i].account);
            }
          }
          that.setData({
            Item: res.result.items
          });
        });
      }
      if (that.data.lastWorkFlowId) {
        var pathFkID = app.globalData.url + "/api/services/WorkFlow/WorkFlowNode/GetAll";
        var objFkID = {
          searchGroup: {
            rules: [{
              field: "FlowID",
              value: that.data.lastWorkFlowId
            }]
          },
          pageSize: 2000
        };
        var GetDataFkID = util.getQueryUrl(pathFkID, objFkID);
        util.request(GetDataFkID).then(function(res) {
          var item = res.result.items;
          var items = item.filter(function(x) {
            return x.isCurrent == true;
          });
          if (items && items.length > 0) {
            that.setData({
              nodeID: items[0]
            });
            if (that.data.nodeID.userID == app.globalData.information.id || userConfiguration["Finace/Receipt/Approve"] == 'true') {
              var path = app.globalData.url + "/api/services/WorkFlow/WorkFlowAction/GetAll";
              var obj = {
                searchGroup: {
                  rules: [{
                    field: "NodeID",
                    value: that.data.nodeID.id
                  }]
                },
                sorting: "LastModificationTime DESC",
                pageSize: 2000
              };
              var GetData = util.getQueryUrl(path, obj);
              util.request(GetData).then(function(res) {
                if (that.data.state == "130008020") {
                  that.setData({
                    open: false
                  });
                } else {
                  that.setData({
                    workFlowAction: res.result.items,
                    open: true
                  });
                }
              });
            } else {
              that.setData({
                open: false
              });
            }
          }
        });
      }
    });
    var path = app.globalData.url + "/api/services/WorkFlow/WFTemplate/GetAll";
    var obj = {
      searchGroup: {
        rules: [{
          field: "Type",
          value: "160205006"
        }]
      },
      pageSize: 2000
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      that.setData({
        workFlowTemp: res.result.items[0]
      });
    });
  },
  bindopinionInput: function bindopinionInput(e) {
    var that = this;
    this.setData({
      remark: e.detail.value
    });
  },
  reject: function reject(e) {
    var that = this;
    // var bool = e.currentTarget.dataset.index == "true" ? true : false;
    // var path = app.globalData.url + "/api/services/Finace/ReceiptOrder/ChangeState"
    // var obj = { id: that.data.receiptOrderId, state: bool ? "130008020" : "130008010", }
    // var Get = util.getQueryUrl(path, obj);
    // util.request(Get).then((res) => {
    //   if (res.success) {
    //     wx.switchTab({
    //       url: '/pages/ucenter/work/work',
    //     })
    //   }
    // })
    // if (e.currentTarget.dataset.index == "temporary") {
    //   if (!that.data.workFlowTemp) {
    //     wx.showModal({
    //       title: '错误信息',
    //       content: '未设定审批流模板，无法发起审批！',
    //       showCancel: false
    //     })
    //   }
    //   else {
    //     that.setData({
    //       open1state: false
    //     })
    //     var path = app.globalData.url + "/api/services/WorkFlow/WorkFlow/Create"
    //     var obj = {
    //       name: "", wfTempID: that.data.workFlowTemp.id, fkID: that.data.receiptOrderId, fkType: "ReceiptOrder",
    //       startIndex: "1", data: JSON.stringify({ id: that.data.receiptOrderId, fkType: "ReceiptOrder" })
    //     }
    //     util.request(path, obj, "POST").then((res) => {
    //       if (res.success) {
    //         wx.navigateBack(1)
    //         return;
    //       }
    //     }, (error) => {
    //       wx.showModal({
    //         title: '错误信息',
    //         content: error.error.message,
    //         showCancel: false
    //       });
    //     })
    //   }
    // }
    // else {
    var bool = e.currentTarget.dataset.cmd == "pass" ? true : false;
    if (!bool) {
      if (!that.data.remark) {
        wx.showModal({
          title: '提示信息',
          content: '请输入审核意见~~',
          showCancel: false
        });
        return;
      }
    }
    if (that.data.openstate) {
      that.setData({
        openstate: false
      });
      var path = app.globalData.url + "/api/services/Finace/ReceiptOrder/ChangeState";
      var obj = {
        id: that.data.receiptOrderId,
        state: "130008020",
        workFlowId: that.data.lastWorkFlowId,
        workNodeId: that.data.nodeID.id,
        workActionId: e.currentTarget.dataset.id,
        cMD: e.currentTarget.dataset.cmd,
        userId: app.globalData.information.id,
        remark: that.data.remark,
        data: {
          id: that.data.receiptOrderId,
          state: bool ? "130008020" : "130008010",
          remark: that.data.remark
        }
      };
      util.request(path, obj, "POST").then(function(res) {
        if (res.success) {
          wx.navigateBack(1);
        }
      });
    }
    //}
  }
});