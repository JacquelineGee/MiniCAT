var _createForOfIteratorHelper2 = require("../../../@babel/runtime/helpers/createForOfIteratorHelper");
var util = require('../../../utils/util.js');
var api = require('../../../config/api.js');
var user = require('../../../utils/cache/user.js');
var department = require('../../../utils/cache/department.js');
var usercache = require('../../../utils/cache/user.js');
var app = getApp();
Page({
  data: {
    scrollTop: 0,
    winWidth: 0,
    winHeight: 0,
    movie: [],
    movies: [],
    userInformation: "",
    hiddendep: true,
    nocancel: true,
    startTime: "",
    startTime1: "请选择时间",
    endTime1: "请选择时间",
    userName: "",
    userId: ""
  },
  onLoad: function onLoad(option) {
    var that = this;
    wx.getSystemInfo({
      success: function success(res) {
        if (res) {
          if (res.windowHeight) that.setData({
            scrollHeight: res.windowHeight
          });
        }
      }
    });
    var path = app.globalData.url + "/api/services/Foundation/User/GetUsers";
    var obj = {
      Filter: "",
      Permission: "",
      Role: "",
      Sorting: "",
      MaxResultCount: 2000,
      SkipCount: 1
    };
    util.request(path, obj, "Get").then(function(res) {
      that.setData({
        movie: res.result.items
      });
    });
    that.setData({
      overView: that.data.currentTab
    });
    //that.LoadData(that.data.overView)
  },

  onShow: function onShow() {
    var that = this;
    var time = new Date().toISOString().slice(0, 10);
    that.setData({
      userName: user.getNameById(app.globalData.information.id),
      userId: app.globalData.information.id,
      startTime: time
    });
    wx.getSystemInfo({
      success: function success(res) {
        if (res) {
          if (res.windowWidth) that.setData({
            winWidth: res.windowWidth
          });
          if (res.winHeight) that.setData({
            winHeight: res.winHeight
          });
          if (res.windowHeight) that.setData({
            scrollHeight: res.windowHeight - 120
          });
        }
      }
    });
    that.LoadData();
  },
  //获取输入的用户信息
  input: function input(e) {
    var that = this;
    this.setData({
      userInformation: e.detail.value
    });
  },
  //根据用户信息查询数据
  get: function get() {
    var that = this;
    var UserList = app.cache.users;
    var UserLists = [];
    var _iterator = _createForOfIteratorHelper2(UserList),
      _step;
    try {
      for (_iterator.s(); !(_step = _iterator.n()).done;) {
        var item = _step.value;
        if (item.name.indexOf(that.data.userInformation) > -1 && item.name != "admin") {
          UserLists.push(item);
        }
      }
    } catch (err) {
      err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
      _iterator.e(err);
    } finally {
      _iterator.f();
    }
    that.setData({
      movie: UserLists
    });
  },
  userone: function userone(e) {
    this.setData({
      userName: e.currentTarget.dataset.name,
      userId: e.currentTarget.dataset.id,
      organizationUnitId: e.currentTarget.dataset.organizationunitid,
      hiddendep: true
    });
  },
  //页面滑动到底部
  bindDownLoad: function bindDownLoad(e) {
    var that = this;
    if (flag) {
      flag = false;
      pageindex++;
      var count = parseInt(totalCount) % pagesize == 0 ? parseInt(totalCount) / pagesize : Math.floor(parseInt(totalCount) / pagesize);
      if (pageindex > count + 1) {
        return;
      }
      that.LoadData(data);
    }
  },
  scroll: function scroll(event) {
    //该方法绑定了页面滚动时的事件，我这里记录了当前的position.y的值,为了请求数据之后把页面定位到这里来。
    var scroll = event.detail.scrollTop;
    var that = this;
    this.setData({
      lastScrollTop: scroll
    });
  },
  LoadData: function LoadData(data) {
    var that = this;
    /*wx.showLoading({
      icon: "loading",
      title: "正在加载......",
      mask: true   
    })*/
    var path = "";
    path = app.globalData.url + "/api/services/Score/ReadingShare/GetUserGrade";
    var obj = {
      userId: that.data.userId,
      startTime: that.data.startTime1 == "请选择时间" ? "" : that.data.startTime1,
      endTime: that.data.endTime1 == "请选择时间" ? "" : that.data.endTime1
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      var list = res.result;
      if (list.duration != null) {
        list.duration = "读书" + list.duration.substring(0, list.duration.indexOf(".")) + "秒";
      } else {
        list.duration = "";
      }
      that.setData({
        movies: list
      });
    }, function(error) {
      wx.showModal({
        title: '提示信息',
        content: error.error.message,
        showCancel: false
      });
      console.log(error.error.message);
      //wx.hideToast();
    }, function(com) {
      //wx.hideToast();
    });
  },
  FormatMonth: function FormatMonth() {
    var date = new Date();
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    //m = m < 10 ? ('0' + m) : m;  
    var d = date.getDate();
    //d= d<10?('0'+m) :m; 
    //return y + "-" + m+"-"+d;
    return [y, m, d].map(formatNumber).join('-');
  },
  datePicker: function datePicker(e) {
    this.setData({
      startTime: e.detail.value
    });
  },
  datePicker1: function datePicker1(e) {
    this.setData({
      startTime1: e.detail.value
    });
  },
  datePickers1: function datePickers1(e) {
    this.setData({
      endTime1: e.detail.value
    });
  },
  //人员
  bindAccountChange: function bindAccountChange(e) {
    var that = this;
    that.setData({
      hiddendep: false
    });
  },
  //取消弹出框
  confirm: function confirm(e) {
    var that = this;
    that.setData({
      hiddendep: true
    });
  },
  query: function query(e) {
    var that = this;
    that.LoadData();
  }
});