var _createForOfIteratorHelper2 = require("../../@babel/runtime/helpers/createForOfIteratorHelper");
var util = require('../../utils/util.js');
var api = require('../../config/api.js');
var user = require('../../utils/cache/user.js');
var app = getApp();
var obj = {};
var flag = true;
var pageindex = 1;
var pagesize = 100;
var data;
var userData = false;
var num = 1;
var totalCount;
Page({
  data: {
    scrollTop: 0,
    lastScrollTop: 0,
    lastScrollTop2: 0,
    winWidth: 0,
    winHeight: 0,
    scrollHeight: 0,
    totalCount: 0,
    // tab切换  
    currentTab: 0,
    userInformation: "",
    getState: "",
    getName: "",
    loading: "",
    movies: [],
    movies1: [],
    movies2: [],
    movies3: [],
    movies4: [],
    url_img: app.globalData.url + "/File/Image?FileName="
  },
  onLoad: function onLoad(options) {
    var that = this;
    that.setData({
      userInformation: ""
    });
    if (options.name) {
      that.setData({
        loading: options.name,
        userInformation: options.name,
        currentTab: 1
      });
      userData = true;
      this.get(options);
      return;
    }
  },
  onShow: function onShow(options) {
    var that = this;
    that.setData({
      userInformation: ""
    });
    var userConfiguration = wx.getStorageSync('userConfiguration');
    if (userConfiguration["Score/GradeManage/Create"] == 'true') {
      that.setData({
        open: true
      });
    } else {
      that.setData({
        open: false
      });
    }
    // if (app.globalData.information.id)
    wx.getSystemInfo({
      success: function success(res) {
        if (res) {
          if (res.windowWidth) that.setData({
            winWidth: res.windowWidth
          });
          if (res.winHeight) that.setData({
            winWidth: res.winHeight
          });
          if (res.windowHeight) that.setData({
            scrollHeight: res.windowHeight
          });
        }
      }
    });
    if (that.data.loading == "") {
      that.LoadData("130008015", 0);
    }
  },
  //页面滑动到底部
  bindDownLoad: function bindDownLoad(e) {
    var that = this;
    if (flag) {
      flag = false;
      pageindex++;
      var count = parseInt(totalCount) % pagesize == 0 ? parseInt(totalCount) / pagesize : Math.floor(parseInt(totalCount) / pagesize);
      if (pageindex > count + 1) {
        //flag = true
        // wx.showModal({
        //   title: '提示信息',
        //   content: '下拉数据加载完毕！！',
        //   showCancel: false
        // })
        return;
      }
      if (userData == true) {
        that.get();
      } else {
        that.LoadData(data);
      }
    }
  },
  // bindTopLoad(){
  //   var that = this;
  //   if (flag) {
  //     flag = false
  //     console.log(pageindex)
  //     pageindex--;
  //     if (pageindex <= 0) {
  //       return;
  //     }
  //     that.LoadData(data);
  //   }
  // },
  scroll: function scroll(event) {
    //该方法绑定了页面滚动时的事件，我这里记录了当前的position.y的值,为了请求数据之后把页面定位到这里来。
    var scroll = event.detail.scrollTop;
    var that = this;
    this.setData({
      lastScrollTop2: that.data.lastScrollTop,
      lastScrollTop: scroll
    });
  },
  /** 
   * 滑动切换tab 
   */
  // bindChange: function (e) {
  //   var that = this;
  //   that.setData({
  //     movies: [],
  //     movies1: [],
  //     movies2: [],
  //     movies3: [],
  //     movies4: [],
  //   })
  //   var current = e.detail.current
  //   data = current == "0" ? "130008005" : current == "1" ? "130008015" : current == "2" ? "130008020" : current == "3" ? "130008010" : "true"
  //   that.setData({ currentTab: e.detail.current });
  //   that.LoadData(data, 0);
  // },
  /** 
   * 点击tab切换 
   */

  LoadData: function LoadData(data) {
    var that = this;
    wx.showToast({
      icon: "loading",
      title: "正在加载......",
      duration: 3000
    });
    var path = app.globalData.url + "/api/services/WorkFlow/WorkFlow/GetAll";
    obj = {
      searchGroup: {
        op: 1,
        rules: [{
          field: "state",
          value: "160202003",
          op: 3
        }, {
          field: "userId",
          value: app.globalData.information.id,
          op: 3
        }]
      },
      sorting: "CreationTime DESC",
      pageSize: 10,
      pageIndex: pageindex
    };
    util.request(path, obj, "GET").then(function(res) {
      flag = true;
      totalCount = res.result.totalCount;
      if (res.success && res.result.items.length > 0) {
        var _iterator = _createForOfIteratorHelper2(res.result.items),
          _step;
        try {
          for (_iterator.s(); !(_step = _iterator.n()).done;) {
            var item = _step.value;
            var str = item.fkType;
            str = str.substring(0, 1);
            item.fkType = item.fkType.substr(1); //fkType去掉了首字母            
            if (item.fkType == "aborHour") {
              item.fkType = str.toLowerCase() + item.fkType + "ManageState";
            } else {
              item.fkType = str.toLowerCase() + item.fkType + "state";
            }
            item.url = "/pages/ucenter/" + item.fkType + "/" + item.fkType;
            item.creatorUser = user.getNameById(item.creatorUserId);
            /*if (item.creatorUserId != null) {
              if (item.userId != item.creatorUserId) {
                item.creatorUser = user.getNameById(item.creatorUserId) + "帮"     
              }
            } else {
              item.creatorUser = ""
            }
            item.user = user.getNameById(item.userId);
            */
            if (item.image) {
              var result = item.image.split("|");
              item.image = result[0];
            }
          }
        } catch (err) {
          err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
          _iterator.e(err);
        } finally {
          _iterator.f();
        }
        wx.hideToast();
        if (res.success) {
          for (var i = 0; i < res.result.items.length; i++) {
            if (res.result.items[i].state == "160202003") {
              // var list = that.data.movies1;
              // if (list.length >= 100) {
              //   for (var i = 0; i < 10; i++) {
              //     list.shift();
              //   }
              // }
              // for (var i = 0; i < res.result.items.length; i++) {
              //   var item = res.result.items[i];
              //   list.push(item);
              // }
              // that.setData({
              //   movies1: list,
              // })
              that.setData({
                movies1: res.result.items
              });
            }
          }
        }
      }

      // that.setData({
      //   scrollTop: that.data.lastScrollTop
      // });
    }, function(err) {
      flag = true;
      wx.hideToast();
    }, function(com) {
      flag = true;
      wx.hideToast();
    });
  }
});