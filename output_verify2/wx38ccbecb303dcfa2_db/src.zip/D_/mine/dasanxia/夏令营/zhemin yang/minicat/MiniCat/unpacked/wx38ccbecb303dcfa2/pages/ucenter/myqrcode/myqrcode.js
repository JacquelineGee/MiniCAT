var util = require('../../../utils/util.js');
var app = getApp();
Page({
  data: {
    img: ""
  },
  onLoad: function onLoad(options) {
    var that = this;
    var path = app.globalData.url + "/api/services/Member/MemberInfo/GetQRCode";
    var data = {
      memberId: app.globalData.information.id
    };
    util.request(path, data, "GET", "application/x-www-form-urlencoded").then(function(res) {
      if (res.success) {
        that.setData({
          img: res.result.qrCode
        });
      }
    });
  }
});