var util = require('../../../utils/util.js');
var api = require('../../../config/api.js');
var user = require('../../../services/user.js');
var app = getApp();
Page({
  data: {
    userInfo: {},
    LaborHour: false,
    InsiderTrading: false,
    ReceiptOrder: false,
    PayOrder: false,
    BusinessReport: false,
    BusinessReports: false,
    Product: false,
    ClockIn: false,
    ReadingShare: false,
    setInter: '',
    taskManage: false
  },
  onLoad: function onLoad(options) {},
  onReady: function onReady() {},
  onShow: function onShow() {
    this.setData({
      userInfo: app.globalData.userInfo,
      token: app.globalData.token
    });
    var that = this;
    app.showTabBar(app.globalData.notificationsum);
    that.data.setInter = setInterval(function() {
      app.showTabBar(app.globalData.notificationsum);
    }, app.globalData.notificationtime);
    var userConfiguration = wx.getStorageSync('userConfiguration');
    if (userConfiguration["Wage/LaborHour"] == 'true') {
      that.setData({
        LaborHour: true
      });
    }
    if (userConfiguration["Sales/InsiderTrading"] == 'true') {
      that.setData({
        InsiderTrading: true
      });
    }
    if (userConfiguration["Finace/Receipt"] == 'true') {
      that.setData({
        ReceiptOrder: true
      });
    }
    if (userConfiguration["Finace/PaybillOrder"] == 'true') {
      that.setData({
        PayOrder: true
      });
    }
    if (userConfiguration["Product/PriceSetting"] == 'true') {
      that.setData({
        PriceSetting: true
      });
    }
    if (userConfiguration["Finace/BusinessReport"] == 'true') {
      that.setData({
        BusinessReport: true
      });
    }
    if (userConfiguration["Product/Product/Create"] == 'true') {
      that.setData({
        Product: true
      });
    }
    if (userConfiguration["Finace/BusinessReports"] == 'true') {
      that.setData({
        BusinessReports: true
      });
    }
    if (userConfiguration["Score/ClockIn"] == 'true') {
      that.setData({
        ClockIn: true
      });
    }
    if (userConfiguration["Score/ReadingShare"] == 'true') {
      that.setData({
        ReadingShare: true
      });
    }
    if (userConfiguration["Score/TaskManage/Create"] == 'true') {
      that.setData({
        taskManage: true
      });
    }
  },
  onHide: function onHide() {
    // 页面隐藏
    var that = this;
    //清除计时器  即清除setInter
    clearInterval(that.data.setInter);
  },
  onUnload: function onUnload() {
    // 页面关闭
    var that = this;
    //清除计时器  即清除setInter
    clearInterval(that.data.setInter);
  },
  goLogin: function goLogin() {
    var _this = this;
    user.loginByWeixin().then(function(res) {
      _this.setData({
        userInfo: res.data.userInfo
      });
      //  app.globalData.userInfo = res.data.userInfo;
      //  app.globalData.token = res.data.token;
    }).catch(function(err) {});
  } // exitLogin: function () {
  //   wx.showModal({
  //     title: '',
  //     confirmColor: '#b4282d',
  //     content: '退出登录？',
  //     success: function (res) {
  //       if (res.confirm) {
  //         wx.removeStorageSync('token');
  //         wx.removeStorageSync('userInfo');
  //         wx.switchTab({
  //           url: '/pages/index/index'
  //         });
  //       }
  //     }
  //   })
  // }
});