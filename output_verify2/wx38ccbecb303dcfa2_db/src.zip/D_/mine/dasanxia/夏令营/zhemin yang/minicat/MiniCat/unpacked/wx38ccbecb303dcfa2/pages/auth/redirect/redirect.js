var app = getApp();
var util = require('../../../utils/util.js');
var usercache = require('../../../utils/cache/user.js');
var departmentcache = require('../../../utils/cache/department.js');
var accountcache = require('../../../utils/cache/account.js');
var paymentModecache = require('../../../utils/cache/paymentMode.js');
var clearingMode = require('../../../utils/cache/clearingMode.js');
var unit = require('../../../utils/cache/unit.js');
var interval;
var varName;
var ctx = wx.createCanvasContext('canvasArcCir');
Page({
  data: {
    referrerId: ""
  },
  onShow: function onShow(options) {
    app.getUserInfo();
    this.startRegister();
  },
  startRegister: function startRegister() {
    var that = this;
    app.getCurrentUser(function() {
      var authorization = wx.getStorageSync('authorization');
      var userConfiguration = wx.getStorageSync('userConfiguration');
      usercache.init();
      departmentcache.init();
      accountcache.init();
      paymentModecache.init();
      clearingMode.init();
      unit.init();
      var tenantId = wx.getStorageSync('tenantId');
      if (authorization) {
        //wx.switchTab({
        // url: '/pages/ucenter/work/work'
        wx.redirectTo({
          url: '/pages/auth/login/login'
        });
      } else {
        wx.redirectTo({
          url: '/pages/auth/login/login'
        });
      }
    });
  }
});