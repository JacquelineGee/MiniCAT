var util = require('../../../utils/util.js');
var api = require('../../../config/api.js');
var user = require('../../../utils/cache/user.js');
var department = require('../../../utils/cache/department.js');
var app = getApp();
Page({
  data: {
    Items: [],
    filter: ''
  },
  onLoad: function onLoad() {
    var that = this;
    var path = app.globalData.url + "/api/services/Product/Product/GetAll";
    var obj = {
      pageSize: 500
    };
    util.request(path, obj, "GET").then(function(res) {
      that.setData({
        Items: res.result.items
      });
    });
  },
  input: function input(e) {
    var that = this;
    this.setData({
      filter: e.detail.value
    });
  },
  Search: function Search() {
    var that = this;
    var path = app.globalData.url + "/api/services/Product/Product/GetAll";
    var obj = {
      filter: that.data.filter,
      pageSize: 500
    };
    util.request(path, obj, "GET").then(function(res) {
      that.setData({
        Items: res.result.items
      });
    });
  }
});