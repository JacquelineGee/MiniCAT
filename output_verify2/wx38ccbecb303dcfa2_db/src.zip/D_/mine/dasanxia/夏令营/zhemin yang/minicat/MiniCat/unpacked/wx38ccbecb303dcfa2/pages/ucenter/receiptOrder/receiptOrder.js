var _createForOfIteratorHelper2 = require("../../../@babel/runtime/helpers/createForOfIteratorHelper");
var _defineProperty2 = require("../../../@babel/runtime/helpers/defineProperty");
// pages/ucenter/payOrder/payOrder.js
var app = getApp();
var WxParse = require('../../../lib/wxParse/wxParse.js');
var util = require('../../../utils/util.js');
var departmentcache = require('../../../utils/cache/department.js');
var accountcache = require('../../../utils/cache/account.js');
var paymentModecache = require('../../../utils/cache/paymentMode.js');
var array = [];
var temp;
var item = {
  "department": "",
  "count": "",
  "name": "",
  "price": "",
  "accountName": "",
  "amount": "",
  "remark": "",
  hiddendeps: true,
  hiddensubjects: true,
  hidden: true
};
var productId;
var price;
Page({
  data: {
    companyList: [],
    movie: [],
    departmentList: [],
    rpt: [],
    distribution: [],
    accountingSubject: [],
    product: [],
    Item: [],
    paymentModes: [],
    paymentModeName: "",
    paymentModeId: "",
    openuser: "",
    open1: "",
    startTime: "",
    startTimes: "",
    displayName: '',
    displayId: '',
    receiptTemplateName: '',
    receiptTemplateId: '',
    accountingsubjectName: "",
    accountingsubjectId: '',
    department: "",
    departmentId: "",
    departments: "",
    departmentIds: "",
    distributionId: '',
    companyId: "",
    companyName: "",
    distributionName: '',
    totalAmount: '',
    cycleDistribution: '',
    state: "",
    no: "",
    creatorUserId: "",
    receiptOrderId: "",
    ReceiptOrder: "",
    productInformation: "",
    companyInformation: "",
    productTypeId: "",
    productTypeName: "-请选择分类-",
    hiddendep: true,
    hiddenCompany: true,
    nocancel: true,
    open: true,
    rejectOpen: false,
    openitem: [],
    workFlowTemp: [],
    ProductTypeList: [],
    entityList: {}
  },
  //取消弹出框
  confirm: function confirm(e) {
    var that = this;
    that.setData({
      hiddendep: true,
      hiddenCompany: true,
      hiddenlabor: true
    });
  },
  confirms: function confirms(e) {
    var that = this;
    var temp = that.data.Item;
    temp[parseInt(e.currentTarget.dataset.data)].hiddendeps = true;
    temp[parseInt(e.currentTarget.dataset.data)].hidden = true;
    temp[parseInt(e.currentTarget.dataset.data)].hiddensubjects = true;
    that.setData({
      Item: temp
    });
  },
  onLoad: function onLoad(options) {
    var that = this;
    var path = app.globalData.url + "/api/services/BasicData/BusinessUnit/GetAll";
    var obj = {
      MaxResultCount: 2000,
      pageSize: 2000
    };
    util.request(path, obj, "Get").then(function(res) {
      that.setData({
        companyList: res.result.items
      });
    });
    var path = app.globalData.url + "/api/services/CodeData/CodeData/GetAll";
    var obj = {
      searchGroup: {
        rules: [{
          field: "codeDataTypeId",
          value: 130009
        }]
      },
      pageSize: 2000
    };
    util.request(path, obj, "Get").then(function(res) {
      that.setData({
        paymentModes: res.result.items
      });
    });
    var path = app.globalData.url + "/api/services/Foundation/OrganizationUnit/GetOrganizationUnits";
    var obj = {
      MaxResultCount: 2000,
      pageSize: 2000
    };
    util.request(path, obj, "Get").then(function(res) {
      that.setData({
        movie: res.result.items,
        departmentList: res.result.items
      });
    });
    var path = app.globalData.url + "/api/services/Finace/AccountingSubject/GetAll";
    var obj = {
      MaxResultCount: 2000,
      pageSize: 2000
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      that.setData({
        accountingSubject: res.result.items
      });
    });
    var path = app.globalData.url + "/api/services/Product/Product/GetAll";
    var obj = {
      MaxResultCount: 2000,
      pageSize: 2000
    };
    util.request(path, obj, "Get").then(function(res) {
      that.setData({
        product: res.result.items
      });
    });
    var path = app.globalData.url + "/api/services/Finace/Distribution/GetAll";
    var obj = {
      MaxResultCount: 2000,
      pageSize: 2000
    };
    util.request(path, obj).then(function(res) {
      that.setData({
        distribution: res.result.items
      });
    });
    that.Add();
    if (options.id) {
      that.setData({
        hiddendep: true,
        hiddenCompany: true,
        hiddenlabor: true,
        state: options.state,
        receiptOrderId: options.id
      });
      that.LoadDatas(options.id);
      return;
    }
  },
  LoadDatas: function LoadDatas(id) {
    var that = this;
    var path = app.globalData.url + "/api/services/Finace/ReceiptOrder/Get";
    var obj = {
      Id: id
    };
    var Get = util.getQueryUrl(path, obj);
    util.request(Get).then(function(res) {
      that.setData({
        companyName: res.result.bU_Name,
        companyId: that.data.bU_Id,
        departmentId: res.result.department,
        department: res.result.departmentName,
        no: res.result.no
      });
      var path = app.globalData.url + "/api/services/Finace/ReceiptOrderItem/GetAll";
      var obj = {
        searchGroup: {
          rules: [{
            field: "receiptOrderId",
            value: that.data.receiptOrderId
          }]
        },
        pageSize: 2000
      };
      var Get = util.getQueryUrl(path, obj);
      util.request(Get).then(function(res) {
        for (var i = 0; i < res.result.items.length; i++) {
          res.result.items[i].department = departmentcache.getNameById(res.result.items[i].department);
          res.result.items[parseInt(i)].hiddendeps = true;
          res.result.items[parseInt(i)].hidden = true;
          res.result.items[parseInt(i)].hiddensubjects = true;
        }
        that.setData({
          Item: res.result.items
        });
      });
    });
  },
  //客户
  companyChange: function companyChange(e) {
    var that = this;
    that.setData({
      hiddenCompany: false
    });
  },
  CompanyNameChange: function CompanyNameChange(e) {
    var that = this;
    that.setData({
      hiddenCompany: true,
      companyName: e.currentTarget.dataset.name,
      companyId: e.currentTarget.dataset.id
    });
  },
  //获取输入的客户信息
  inputcompany: function inputcompany(e) {
    var that = this;
    this.setData({
      companyInformation: e.detail.value
    });
  },
  //根据产品信息查询数据
  getcompany: function getcompany() {
    var that = this;
    var path = app.globalData.url + "/api/services/BasicData/BusinessUnit/GetAll";
    var obj = {
      filter: that.data.companyInformation,
      pageSize: 200
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      that.setData({
        companyList: res.result.items
      });
    });
  },
  //获取输入的会计科目
  inputaccountingsubject: function inputaccountingsubject(e) {
    var that = this;
    this.setData({
      accountingsubjectInformation: e.detail.value
    });
  },
  //根据获取的信息查询数据
  getaccountingsubject: function getaccountingsubject() {
    var that = this;
    var path = app.globalData.url + "/api/services/Finace/AccountingSubject/GetAll";
    var obj = {};
    if (that.data.accountingsubjectInformation == null || that.data.accountingsubjectInformation == "" || that.data.accountingsubjectInformation == undefined) {
      obj = {
        searchGroup: {
          rules: [{
            field: "id",
            value: that.data.id
          }]
        },
        sorting: "sort asc",
        pageSize: 200
      };
    } else {
      obj = {
        filter: that.data.accountingsubjectInformation,
        sorting: "sort asc",
        pageSize: 200
      };
    }
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      that.setData({
        accountingSubject: res.result.items
      });
    });
  },
  //部门
  bindAccountChange: function bindAccountChange(e) {
    var that = this;
    that.setData({
      hiddendep: false
    });
  },
  DepartmentChange: function DepartmentChange(e) {
    var that = this;
    that.setData({
      hiddendep: true,
      department: e.currentTarget.dataset.name,
      departmentId: e.currentTarget.dataset.index
    });
  },
  //明细部门
  bindAccountChanges: function bindAccountChanges(e) {
    var that = this;
    var temp = that.data.Item;
    temp[parseInt(e.currentTarget.dataset.data)].hiddendeps = false;
    that.setData({
      Item: temp
    });
  },
  DepartmentChanges: function DepartmentChanges(e) {
    var that = this;
    var temp = that.data.Item;
    temp[parseInt(e.currentTarget.dataset.data)].departmentName = e.currentTarget.dataset.name;
    temp[parseInt(e.currentTarget.dataset.data)].department = e.currentTarget.dataset.id;
    temp[parseInt(e.currentTarget.dataset.data)].hiddendeps = true;
    that.setData({
      Item: temp
    });
  },
  //会计科目
  AccountingSubject: function AccountingSubject(e) {
    var that = this;
    var temp = that.data.Item;
    temp[parseInt(e.currentTarget.dataset.data)].hiddensubjects = false;
    that.setData({
      Item: temp
    });
  },
  //备注信息
  bindRemark: function bindRemark(e) {
    var that = this;
    var temp = that.data.Item;
    temp[parseInt(e.currentTarget.dataset.data)].remark = e.detail.value;
    that.setData({
      items: temp
    });
  },
  Subjectone: function Subjectone(e) {
    var that = this;
    var temp = that.data.Item;
    temp[parseInt(e.currentTarget.dataset.data)].account = e.currentTarget.dataset.id;
    temp[parseInt(e.currentTarget.dataset.data)].name = e.currentTarget.dataset.index;
    temp[parseInt(e.currentTarget.dataset.data)].hiddensubjects = true;
    that.setData({
      Item: temp
    });
  },
  //产品名称
  Product: function Product(e) {
    var that = this;
    var temp = that.data.Item;
    temp[parseInt(e.currentTarget.dataset.data)].hidden = false;
    that.setData({
      Item: temp
    });
  },
  Productone: function Productone(e) {
    var that = this;
    var temp = that.data.Item;
    var i = parseInt(e.currentTarget.dataset.index);
    /*temp[parseInt(e.currentTarget.dataset.data)].productName = that.data.product[i].name;
    temp[parseInt(e.currentTarget.dataset.data)].productId = that.data.product[i].id;
    temp[parseInt(e.currentTarget.dataset.data)].price = that.data.product[i].salePrice;
    productId = that.data.product[i].id;
    temp[parseInt(e.currentTarget.dataset.data)].count = "";
    temp[parseInt(e.currentTarget.dataset.data)].amount = "";
    temp[parseInt(e.currentTarget.dataset.data)].hidden = true;
    temp[parseInt(e.currentTarget.dataset.data)].model=that.data.product[i].model;*/
    var product2 = new Object();
    product2.productName = that.data.product[i].name;
    product2.productId = that.data.product[i].id;
    product2.price = that.data.product[i].salePrice;
    product2.count = "";
    product2.amount = "";
    product2.hidden = true;
    product2.hiddensubjects = true;
    product2.hiddendeps = true;
    product2.model = that.data.product[i].model;
    temp[parseInt(e.currentTarget.dataset.data)] = product2;
    temp[parseInt(e.currentTarget.dataset.data)].hidden = true;
    that.setData({
      Item: temp
    });
  },
  //选择产品分类
  ProductType: function ProductType() {
    this.setData({
      openuser: !this.data.openuser
    });
    var that = this;
    var path = app.globalData.url + "/api/services/Product/ProductType/GetAll";
    var obj = {
      MaxResultCount: 2000,
      pageSize: 2000
    };
    util.request(path, obj, "Get").then(function(res) {
      that.setData({
        ProductTypeList: res.result.items
      });
    });
  },
  ProductTypeone: function ProductTypeone(e) {
    this.setData({
      productTypeName: e.currentTarget.dataset.index,
      productTypeId: e.currentTarget.dataset.id,
      openuser: !this.data.openuser
    });
    this.getproduct();
  },
  bindCount: function bindCount(e) {
    var that = this;
    var temp = that.data.Item;
    temp[parseInt(e.currentTarget.dataset.data)].count = e.detail.value;
    temp[parseInt(e.currentTarget.dataset.data)].amount = temp[parseInt(e.currentTarget.dataset.data)].price * e.detail.value;
    that.setData({
      Item: temp
    });
  },
  bindAmount: function bindAmount(e) {
    var that = this;
    var temp = that.data.Item;
    temp[parseInt(e.currentTarget.dataset.data)].amount = e.detail.value;
    temp[parseInt(e.currentTarget.dataset.data)].price = e.detail.value / temp[parseInt(e.currentTarget.dataset.data)].count;
    that.setData({
      Item: temp
    });
  },
  del: function del(e) {
    var that = this;
    wx.showModal({
      title: '提示信息',
      content: '是否要删除',
      showCancel: true,
      success: function success(res) {
        if (res.confirm) {
          var Item = that.data.Item;
          Item.splice(e.currentTarget.dataset.data, 1);
          that.setData({
            Item: Item
          });
        } else {}
      }
    });
  },
  Add: function Add() {
    var that = this;
    var temp = that.data.Item;
    temp.unshift(item);
    that.setData({
      Item: temp
    });
  },
  //获取输入的产品信息
  inputproduct: function inputproduct(e) {
    var that = this;
    this.setData({
      productInformation: e.detail.value
    });
  },
  //根据产品信息查询数据
  getproduct: function getproduct() {
    var that = this;
    var path = app.globalData.url + "/api/services/Product/Product/GetProduct";
    //var obj = { searchGroup: { rules: [{ field: "productTypeId", value: that.data.productTypeId }] }, filter: that.data.productInformation, pageSize: 200 }
    var obj = {};
    if (that.data.productInformation == null || that.data.productInformation == "" || that.data.productInformation == undefined) {
      obj = {
        searchGroup: {
          rules: [{
            field: "productTypeId",
            value: that.data.productTypeId
          }]
        },
        pageSize: 200
      };
    } else {
      obj = {
        filter: that.data.productInformation,
        pageSize: 200
      };
    }
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      that.setData({
        product: res.result.items
      });
    });
  },
  buttonsave1: function buttonsave1() {
    var that = this;
    if (that.data.department == "" || that.data.department == null || that.data.department == undefined) {
      wx.showModal({
        title: '提示信息',
        content: '请选择部门~~',
        showCancel: false
      });
      return;
    }
    for (var i = 0; i < that.data.Item.length; i++) {
      that.data.Item[i].department = that.data.departmentId;
      that.data.Item[i].departmentName = that.data.department;
      if (that.data.Item[i].name == "" || that.data.Item[i].name == null || that.data.Item[i].name == undefined) {
        wx.showModal({
          title: '提示信息',
          content: '请选择科目',
          showCancel: false
        });
        return;
      }
    }
    if (that.data.Item.length < 1) {
      wx.showModal({
        title: '提示信息',
        content: '请添加明细！！！',
        showCancel: false
      });
      return;
    }
    var path = that.data.state != "130008010" ? app.globalData.url + "/api/services/Finace/ReceiptOrder/CreateWithItems" : app.globalData.url + "/api/services/Finace/ReceiptOrder/UpdateWithItems";
    var obj = {
      id: that.data.receiptOrderId,
      bU_Name: that.data.companyName,
      bU_Id: that.data.companyId,
      department: that.data.departmentId,
      creatorUserId: app.globalData.information.id,
      departmentName: that.data.department,
      no: that.data.no == "" ? "" : that.data.no,
      state: "130008005",
      FkType: "ReceiptOrder",
      items: that.data.Item
    };
    that.data.state != "130008010" ? delete obj["id"] : obj;
    util.request(path, obj).then(function(res) {
      if (res.success) {
        that.setData({
          entityList: res.result,
          ReceiptOrder: res.result.id,
          rejectOpen: true,
          open: false
        });
        wx.showModal({
          title: '提示信息',
          content: "保存成功，请点击申请审批！",
          showCancel: false
        });
      }
    }, function(error) {
      wx.showModal({
        title: '错误信息',
        content: error.error.message,
        showCancel: false
      });
    });
  },
  reject: function reject() {
    var that = this;
    var path = app.globalData.url + "/api/services/WorkFlow/WFTemplate/GetWFTemplateByType";
    var obj = {
      Type: "160205006",
      Param: "",
      organizationUnitId: that.data.departmentId,
      pageSize: 2000
    }; //app.globalData.information.organizationUnitId, pageSize: 2000 }
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      that.setData({
        workFlowTemp: res.result
      });
      if (res.result.id) {
        var path = app.globalData.url + "/api/services/WorkFlow/WorkFlow/Create";
        var obj = _defineProperty2({
          name: that.data.department + "与" + that.data.companyName + "发起一笔销售交易，请审核",
          moduleName: "Finace",
          entity: that.data.entityList,
          wfTempID: that.data.workFlowTemp.id,
          fkID: that.data.ReceiptOrder,
          fkType: "ReceiptOrder",
          startIndex: "1",
          necessaryApprover: {
            "Manager": null
          },
          data: JSON.stringify({
            id: that.data.ReceiptOrder,
            fkType: "ReceiptOrder"
          })
        }, "entity", that.data.entityList);
        if (!obj.necessaryApprover.Manager) {
          var _iterator = _createForOfIteratorHelper2(app.cache.department),
            _step;
          try {
            for (_iterator.s(); !(_step = _iterator.n()).done;) {
              var item = _step.value;
              if (item.id == that.data.departmentId) {
                obj.necessaryApprover.Manager = item.manager;
                break;
              }
            }
          } catch (err) {
            err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
            _iterator.e(err);
          } finally {
            _iterator.f();
          }
        }
        util.request(path, obj, "POST").then(function(res) {
          if (res.success) {
            wx.switchTab({
              url: '/pages/ucenter/work/work'
            });
            return;
          }
        }, function(error) {
          wx.showModal({
            title: '错误信息',
            content: error.error.message,
            showCancel: false
          });
        });
      }
    });
  }
});