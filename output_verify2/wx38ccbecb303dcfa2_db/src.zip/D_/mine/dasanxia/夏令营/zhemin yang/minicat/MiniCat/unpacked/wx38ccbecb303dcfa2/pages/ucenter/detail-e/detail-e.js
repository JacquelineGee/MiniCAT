var util = require('../../../utils/util.js');
var api = require('../../../config/api.js');
var app = getApp();
Page({
  data: {
    orderList: [],
    name: "",
    sex: "",
    birthday: "",
    phone: "",
    location: "",
    email: "",
    img: ''
  },
  onLoad: function onLoad(options) {
    var _this = this;
    var that = this;
    var url = app.globalData.url + "/api/services/Member/MemberInfo/Get";
    var shuju = {
      id: app.globalData.information.id
    };
    util.request(url, shuju, "GET").then(function(res) {
      _this.setData({
        id: res.result.id,
        name: app.globalData.userInfo.nickName,
        sex: app.globalData.userInfo.gender ? '男' : '女',
        birthday: '保密',
        phone: res.result.mobile,
        location: app.globalData.userInfo.city,
        email: '保密',
        img: app.globalData.userInfo.avatarUrl
      });
    });
  },
  getOrderList: function getOrderList() {
    var that = this;
    util.request(api.OrderList).then(function(res) {
      if (res.errno === 0) {
        that.setData({
          orderList: res.data.data
        });
      }
    });
  },
  payOrder: function payOrder() {
    wx.redirectTo({
      url: '/pages/pay/pay'
    });
  },
  onReady: function onReady() {
    // 页面渲染完成
  },
  onShow: function onShow() {
    // 页面显示
  },
  onHide: function onHide() {
    // 页面隐藏
  },
  onUnload: function onUnload() {
    // 页面关闭
  },
  bname: function bname(e) {
    console.log(this);
    this.setData({
      name: e.detail.value
    });
  },
  bbirth: function bbirth(e) {
    console.log(this);
    this.setData({
      birthday: e.detail.value
    });
  },
  radioChange: function radioChange(e) {
    this.setData({
      sex: e.detail.value
    });
  },
  bphone: function bphone(e) {
    this.setData({
      phone: e.detail.value
    });
  },
  blocat: function blocat(e) {
    this.setData({
      location: e.detail.value
    });
  },
  bemail: function bemail(e) {
    this.setData({
      email: e.detail.value
    });
  },
  click: function click() {
    var that = this;
    wx.uploadFile({
      // url: rootUrl + url,
      // filePath: filePath,
      // name: name,
      header: {
        'content-type': 'multipart/form-data'
      },
      // 设置请求的 header
      // formData: formData, // HTTP 请求中其他额外的 form data
      success: function(_success) {
        function success(_x) {
          return _success.apply(this, arguments);
        }
        success.toString = function() {
          return _success.toString();
        };
        return success;
      }(function(res) {
        console.log(res);
        if (res.statusCode == 200 && !res.data.result_code) {
          typeof success == "function" && success(res.data);
        } else {
          typeof fail == "function" && fail(res);
        }
      }),
      fail: function(_fail) {
        function fail(_x2) {
          return _fail.apply(this, arguments);
        }
        fail.toString = function() {
          return _fail.toString();
        };
        return fail;
      }(function(res) {
        console.log(res);
        typeof fail == "function" && fail(res);
      })
    });
  },
  save: function save() {
    var path = app.globalData.url + "/api/services/Member/MemberInfo/Update";
    var da = {
      id: this.data.id,
      name: this.data.name,
      birthday: this.data.birthday,
      mobile: this.data.phone,
      location: this.data.location,
      email: this.data.email,
      sex: this.data.sex
    };
    util.request(path, da, "PUT").then(function(res) {
      wx.redirectTo({
        url: '../detail/detail'
      });
    });
  }
});