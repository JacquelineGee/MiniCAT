var _createForOfIteratorHelper2 = require("../../../@babel/runtime/helpers/createForOfIteratorHelper");
var util = require('../../../utils/util.js');
var user = require('../../../utils/cache/user.js');
var department = require('../../../utils/cache/department.js');
var paymentMode = require('../../../utils/cache/paymentMode.js');
var clearingMode = require('../../../utils/cache/clearingMode.js');
var account = require('../../../utils/cache/account.js');
var unit = require('../../../utils/cache/unit.js');
var app = getApp();
var item = {
  "accountingsubjects": "",
  "productName": "",
  "productId": "",
  "unit": "",
  "count": "",
  "price": "",
  "amount": "",
  hiddensubjects: true,
  hidden: true
};
var productId;
var bOMVersion;
var price;
var Items = [];
var AccountingSubjectItem = [];
Page({
  data: {
    path: app.globalData.url,
    sales: "",
    buyer: "",
    date: "",
    pay: "",
    payId: "",
    id: "",
    InsiderTradingId: "",
    name: "",
    no: "",
    unit: "",
    count: "",
    clearingModeId: "",
    clearingModeName: "",
    InsiderTrading: "",
    productInformation: "",
    productTypeId: "",
    productTypeName: "-请选择分类-",
    paymentModes: [],
    clearingModes: [],
    AccountingSubject: [],
    product: [],
    items: [],
    workFlowTemp: [],
    ProductTypeList: [],
    rejectOpen: false,
    open: true,
    nocancel: true,
    hiddensales: true,
    hiddenbuyer: true,
    hiddenpay: true,
    hiddenclearingMode: true,
    hidden_loading: true,
    state: "",
    entityList: {}
  },
  confirm: function confirm() {
    var that = this;
    that.setData({
      hiddensales: true,
      hiddenbuyer: true,
      hiddenpay: true,
      hiddenclearingMode: true
    });
  },
  confirms: function confirms(e) {
    var that = this;
    var temp = that.data.items;
    temp[parseInt(e.currentTarget.dataset.data)].hidden = true;
    temp[parseInt(e.currentTarget.dataset.data)].hiddensubjects = true;
    that.setData({
      items: temp
    });
  },
  onLoad: function onLoad(options) {
    var that = this;
    that.InitData();
    if (options.id) {
      that.setData({
        state: options.state,
        InsiderTradingId: options.id,
        hidden_loading: false
      });
      that.LoadData(options.id);
      return;
    }
    var time = that.FormatTime();
    var temp = that.data.items;
    temp.push(item);
    that.setData({
      date: time,
      items: temp
    });
    //that.Add();
  },

  //处理驳回的数据
  LoadData: function LoadData(id) {
    var that = this;
    var path = app.globalData.url + "/api/services/Sales/InsiderTrading/GetInsiderTradingById";
    var obj = {
      id: id
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      var time = that.FormatTime(res.result.date);
      var temp = res.result.items;
      for (var i = 0; i < res.result.items.length; i++) {
        temp[i]["hiddensubjects"] = true;
        temp[i]["hidden"] = true;
        temp[i]["name"] = account.getNameById(res.result.items[i].accountingsubjects);
        temp[i].unit = res.result.items[i].unit;
        temp[i].unitName = unit.getNameById(res.result.items[i].unit);
      }
      that.setData({
        salesName: department.getNameById(res.result.output),
        sales: res.result.output,
        no: res.result.no,
        buyerName: department.getNameById(res.result.input),
        buyer: res.result.input,
        pay: paymentMode.getNameById(res.result.paymentMode),
        payId: res.result.paymentMode,
        date: time,
        items: temp,
        clearingModeName: clearingMode.getNameById(res.result.clearingMode),
        clearingModeId: res.result.clearingMode,
        hidden_loading: true
      });
    }, function(err) {
      that.setData({
        hidden_loading: true
      });
    });
  },
  //时间格式
  FormatTime: function FormatTime(time) {
    var date = time ? new Date(time) : new Date();
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    m = m < 10 ? '0' + m : m;
    var d = date.getDate();
    d = d < 10 ? '0' + d : d;
    return y + "-" + m + "-" + d;
  },
  //销售方
  sales: function sales(e) {
    var that = this;
    this.setData({
      hiddensales: false
    });
  },
  salesone: function salesone(e) {
    var that = this;
    if (e.currentTarget.dataset.id == that.data.buyer) {
      wx.showModal({
        title: '提示信息',
        content: '部门不能相同~~',
        showCancel: false
      });
      return;
    }
    that.setData({
      hiddensales: true,
      sales: e.currentTarget.dataset.id,
      salesName: e.currentTarget.dataset.index
    });
  },
  //付款方式
  Payment: function Payment() {
    var that = this;
    that.setData({
      hiddenpay: false
    });
  },
  Payone: function Payone(e) {
    var that = this;
    that.setData({
      hiddenpay: true,
      pay: e.currentTarget.dataset.index,
      payId: e.currentTarget.dataset.id
    });
  },
  //采购方
  buyer: function buyer(e) {
    var that = this;
    that.setData({
      hiddenbuyer: false
    });
  },
  buyerone: function buyerone(e) {
    var that = this;
    if (e.currentTarget.dataset.id == that.data.sales) {
      wx.showModal({
        title: '提示信息',
        content: '部门不能相同~~',
        showCancel: false
      });
      return;
    }
    that.setData({
      hiddenbuyer: true,
      buyer: e.currentTarget.dataset.id,
      buyerName: e.currentTarget.dataset.index
    });
  },
  //选择日期
  datePickers: function datePickers(e) {
    var that = this;
    that.setData({
      date: e.detail.value
    });
  },
  //交易方式
  change: function change(e) {
    var that = this;
    that.setData({
      hiddenclearingMode: false
    });
  },
  changeone: function changeone(e) {
    var that = this;
    that.setData({
      hiddenclearingMode: true,
      clearingModeId: e.currentTarget.dataset.id,
      clearingModeName: e.currentTarget.dataset.index
    });
  },
  //初始化数据
  InitData: function InitData() {
    var that = this;
    //销售方 
    var path = app.globalData.url + "/api/services/Foundation/OrganizationUnit/GetOrganizationUnits";
    var obj = {
      MaxResultCount: 2000,
      pageSize: 2000
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      that.setData({
        movies: res.result.items
      });
    });

    //付款方式
    var path = app.globalData.url + "/api/services/CodeData/CodeData/GetAll";
    var obj = {
      searchGroup: {
        rules: [{
          field: "codeDataTypeId",
          value: 130009
        }]
      },
      pageSize: 2000
    };
    var GetData = util.getQueryUrl(path, obj);
    Items = [];
    util.request(GetData).then(function(res) {
      for (var i = 0; i < res.result.items.length; i++) {
        if (res.result.items[i].id == 130009001 || res.result.items[i].id == 130009002 || res.result.items[i].id == 130009005) {
          Items.push(res.result.items[i]);
        }
      }
      that.setData({
        paymentModes: Items
      });
    });
    //付款方式
    var path = app.globalData.url + "/api/services/CodeData/CodeData/GetAll";
    var obj = {
      searchGroup: {
        rules: [{
          field: "codeDataTypeId",
          value: 200013
        }]
      },
      pageSize: 2000
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      that.setData({
        clearingModes: res.result.items
      });
    });
    //会记科目
    var path = app.globalData.url + "/api/services/Finace/AccountingSubject/GetAll";
    var obj = {
      MaxResultCount: 2000,
      pageSize: 2000
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      that.setData({
        accountingSubject: res.result.items
      });
    });
    //产品名称
    var path = app.globalData.url + "/api/services/Product/Product/GetAll";
    var obj = {
      MaxResultCount: 2000,
      pageSize: 2000
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      that.setData({
        product: res.result.items
      });
    });
  },
  //会计科目
  AccountingSubject: function AccountingSubject(e) {
    var that = this;
    var temp = that.data.items;
    temp[parseInt(e.currentTarget.dataset.data)].hiddensubjects = false;
    that.setData({
      items: temp
    });
  },
  Subjectone: function Subjectone(e) {
    var that = this;
    var temp = that.data.items;
    temp[parseInt(e.currentTarget.dataset.data)].accountingsubjects = e.currentTarget.dataset.id;
    temp[parseInt(e.currentTarget.dataset.data)].name = e.currentTarget.dataset.index;
    temp[parseInt(e.currentTarget.dataset.data)].hiddensubjects = true;
    that.setData({
      items: temp
    });
  },
  //产品名称
  Product: function Product(e) {
    var that = this;
    var temp = that.data.items;
    temp[parseInt(e.currentTarget.dataset.data)].hidden = false;
    that.setData({
      items: temp
    });
  },
  //选择产品
  Productone: function Productone(e) {
    var that = this;
    var temp = that.data.items;
    var i = parseInt(e.currentTarget.dataset.index);
    /*temp[parseInt(e.currentTarget.dataset.data)].productName = that.data.product[i].name;
    temp[parseInt(e.currentTarget.dataset.data)].unit = that.data.product[i].unit;
    temp[parseInt(e.currentTarget.dataset.data)].unitName = unit.getNameById(that.data.product[i].unit);
    temp[parseInt(e.currentTarget.dataset.data)].productId = that.data.product[i].id;
    temp[parseInt(e.currentTarget.dataset.data)].price = that.data.product[i].costPrice;
    productId = that.data.product[i].id;
    temp[parseInt(e.currentTarget.dataset.data)].count = "";
    temp[parseInt(e.currentTarget.dataset.data)].amount = "";
    temp[parseInt(e.currentTarget.dataset.data)].hidden = true;*/

    var product = new Object();
    product.productName = that.data.product[i].name;
    product.unit = that.data.product[i].unit;
    product.unitName = unit.getNameById(that.data.product[i].unit);
    product.productId = that.data.product[i].id;
    product.price = that.data.product[i].costPrice;
    product.oldPrice = that.data.product[i].costPrice;
    product.count = "";
    product.amount = "";
    product.hidden = true;
    product.hiddensubjects = true;
    product.model = that.data.product[i].model;
    temp[parseInt(e.currentTarget.dataset.data)] = product;
    that.setData({
      items: temp
    });
  },
  //选择产品分类
  ProductType: function ProductType() {
    this.setData({
      openuser: !this.data.openuser
    });
    var that = this;
    var path = app.globalData.url + "/api/services/Product/ProductType/GetAll";
    var obj = {
      MaxResultCount: 2000,
      pageSize: 2000
    };
    util.request(path, obj, "Get").then(function(res) {
      that.setData({
        ProductTypeList: res.result.items
      });
    });
  },
  ProductTypeone: function ProductTypeone(e) {
    this.setData({
      productTypeName: e.currentTarget.dataset.index,
      productTypeId: e.currentTarget.dataset.id,
      openuser: !this.data.openuser
    });
    this.getproduct();
  },
  //数量
  bindCount: function bindCount(e) {
    var that = this;
    var temp = that.data.items;
    temp[parseInt(e.currentTarget.dataset.data)].count = e.detail.value;
    that.setData({
      items: temp
    });
  },
  //单价
  bindPrice: function bindPrice(e) {
    var that = this;
    var temp = that.data.items;
    temp[parseInt(e.currentTarget.dataset.data)].price = e.detail.value;
    that.setData({
      items: temp
    });
  },
  //最小一级BOM
  LastBom: function LastBom(e) {
    var that = this;
    var temp = that.data.items;
    if (temp[parseInt(e.currentTarget.dataset.data)].productId) {
      var path = app.globalData.url + "/api/services/Product/BOM/GetAll";
      var obj = {
        searchGroup: {
          rules: [{
            field: "productId",
            value: temp[parseInt(e.currentTarget.dataset.data)].productId
          }]
        },
        pageSize: 2000
      };
      var GetData = util.getQueryUrl(path, obj);
      util.request(GetData).then(function(res) {
        if (res.result.items && res.result.items.length > 0) {
          var path = app.globalData.url + "/api/services/Product/BOM/GetBOMTree";
          var obj = {
            productId: temp[parseInt(e.currentTarget.dataset.data)].productId,
            BOMVersions: res.result.items["0"].id
          };
          var GetData = util.getQueryUrl(path, obj);
          util.request(GetData).then(function(res) {
            var total = res.result;
            if (total && total.length > 0) {
              var _iterator = _createForOfIteratorHelper2(total),
                _step;
              try {
                for (_iterator.s(); !(_step = _iterator.n()).done;) {
                  var item = _step.value;
                  item.hiddensubjects = true;
                  item.hidden = true;
                  item.price = item.costPrice;
                  item.unitName = unit.getNameById(item.unit);
                  if (temp[parseInt(e.currentTarget.dataset.data)].count) {
                    item.count = temp[parseInt(e.currentTarget.dataset.data)].count * item.count;
                    item.amount = temp[parseInt(e.currentTarget.dataset.data)].count * item.amount;
                  } else {
                    item.count = item.count;
                    item.amount = item.amount;
                  }
                  temp.push(item);
                }
              } catch (err) {
                err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
                _iterator.e(err);
              } finally {
                _iterator.f();
              }
              temp.splice(parseInt(e.currentTarget.dataset.data), 1);
              that.setData({
                items: temp
              });
            }
          });
        } else {
          wx.showModal({
            title: '提示信息',
            content: '该产品不存在BOM清单！',
            showCancel: false
          });
        }
      });
    } else {
      wx.showModal({
        title: '提示信息',
        content: '请先选择产品！',
        showCancel: false
      });
    }
  },
  //数量
  bindRemark: function bindRemark(e) {
    var that = this;
    var temp = that.data.items;
    temp[parseInt(e.currentTarget.dataset.data)].remark = e.detail.value;
    that.setData({
      items: temp
    });
  },
  //下一级BOM
  NextBom: function NextBom(e) {
    var that = this;
    var temp = that.data.items;
    if (temp[parseInt(e.currentTarget.dataset.data)].productId) {
      var path = app.globalData.url + "/api/services/Product/BOM/GetAll";
      var obj = {
        searchGroup: {
          rules: [{
            field: "productId",
            value: temp[parseInt(e.currentTarget.dataset.data)].productId
          }]
        },
        pageSize: 2000
      };
      var GetData = util.getQueryUrl(path, obj);
      util.request(GetData).then(function(res) {
        if (res.result.items && res.result.items.length > 0) {
          var path = app.globalData.url + "/api/services/Product/BOMItem/GetAll";
          var obj = {
            searchGroup: {
              rules: [{
                field: "BOMId",
                value: res.result.items["0"].id
              }]
            },
            pageSize: 2000
          };
          var GetData = util.getQueryUrl(path, obj);
          util.request(GetData).then(function(res) {
            var total = res.result.items;
            if (total && total.length > 0) {
              var _iterator2 = _createForOfIteratorHelper2(total),
                _step2;
              try {
                for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
                  var item = _step2.value;
                  item.hiddensubjects = true;
                  item.hidden = true;
                  item.price = item.costPrice;
                  item.unitName = unit.getNameById(item.unit);
                  if (temp[parseInt(e.currentTarget.dataset.data)].count) {
                    item.count = temp[parseInt(e.currentTarget.dataset.data)].count * item.count;
                    item.amount = temp[parseInt(e.currentTarget.dataset.data)].count * item.amount;
                  } else {
                    item.count = item.count;
                    item.amount = item.amount;
                  }
                  temp.push(item);
                }
              } catch (err) {
                err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
                _iterator2.e(err);
              } finally {
                _iterator2.f();
              }
              temp.splice(parseInt(e.currentTarget.dataset.data), 1);
              that.setData({
                items: temp
              });
            }
          });
        } else {
          wx.showModal({
            title: '提示信息',
            content: '该产品不存在BOM清单！',
            showCancel: false
          });
        }
      });
    } else {
      wx.showModal({
        title: '提示信息',
        content: '请先选择产品！',
        showCancel: false
      });
    }
  },
  //新增
  Add: function Add() {
    var that = this;
    var temp = that.data.items;
    temp.push(item);
    that.setData({
      items: temp
    });
  },
  //删除 
  Del: function Del(e) {
    var that = this;
    wx.showModal({
      title: '提示信息',
      content: '你确定要删除吗',
      showCancel: true,
      success: function success(res) {
        if (res.confirm) {
          var temp = that.data.items;
          temp.splice(parseInt(e.currentTarget.dataset.data), 1);
          that.setData({
            items: temp
          });
        }
      }
    });
  },
  //计算
  calculate: function calculate(e) {
    var that = this;
    var path = app.globalData.url + "/api/services/Product/PriceSetting/ProductPriceInput";
    var items = [];
    var data = {};
    for (var p = 0; p < that.data.items.length; p++) {
      var item = {};
      item["productId"] = that.data.items[p].productId;
      item["productName"] = that.data.items[p].productName;
      item["unit"] = that.data.items[p].unit;
      item["price"] = that.data.items[p].price;
      item["count"] = that.data.items[p].count;
      items.push(item);
    }
    data["isSalePrice"] = false;
    data["input"] = that.data.buyer;
    data["output"] = that.data.sales;
    data["items"] = items;
    util.request(path, data).then(function(res) {
      var temp = that.data.items;
      for (var p = 0; p < that.data.items.length; p++) {
        that.data.items[p].price = res.result[p].price;
        that.data.items[p].amount = res.result[p].amount;
        var price = that.data.items[p].price;
        var amount = that.data.items[p].amount;
        temp[p].price = price;
        temp[p].amount = amount;
        that.setData({
          items: temp
        });
      }
    });
  },
  //获取输入的产品信息
  inputproduct: function inputproduct(e) {
    var that = this;
    this.setData({
      productInformation: e.detail.value
    });
  },
  //根据产品信息查询数据
  getproduct: function getproduct() {
    var that = this;
    var path = app.globalData.url + "/api/services/Product/Product/GetProduct";
    var obj = {};
    if (that.data.productInformation == null || that.data.productInformation == "" || that.data.productInformation == undefined) {
      obj = {
        searchGroup: {
          rules: [{
            field: "productTypeId",
            value: that.data.productTypeId
          }]
        },
        pageSize: 200
      };
    } else {
      obj = {
        filter: that.data.productInformation,
        pageSize: 200
      };
    }
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      that.setData({
        product: res.result.items
      });
    });
  },
  //获取输入的会计科目
  inputaccountingsubject: function inputaccountingsubject(e) {
    var that = this;
    this.setData({
      accountingsubjectInformation: e.detail.value
    });
  },
  //根据获取的信息查询数据
  getaccountingsubject: function getaccountingsubject() {
    var that = this;
    var path = app.globalData.url + "/api/services/Finace/AccountingSubject/GetAll";
    var obj = {};
    if (that.data.accountingsubjectInformation == null || that.data.accountingsubjectInformation == "" || that.data.accountingsubjectInformation == undefined) {
      obj = {
        searchGroup: {
          rules: [{
            field: "id",
            value: that.data.id
          }]
        },
        sorting: "sort asc",
        pageSize: 200
      };
    } else {
      obj = {
        filter: that.data.accountingsubjectInformation,
        sorting: "sort asc",
        pageSize: 200
      };
    }
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      that.setData({
        accountingSubject: res.result.items
      });
    });
  },
  //提交数据
  buttonsave1: function buttonsave1() {
    var that = this;
    if (!that.data.sales || !that.data.buyer || !that.data.payId || !that.data.clearingModeId) {
      wx.showModal({
        title: '提示信息',
        content: '请补全数据',
        showCancel: false
      });
      return;
    }
    for (var i = 0; i < that.data.items.length; i++) {
      if (!that.data.items[i].accountingsubjects || !that.data.items[i].productName || !that.data.items[i].count) {
        wx.showModal({
          title: '提示信息',
          content: '请补全数据',
          showCancel: false
        });
        return;
      }
      if (that.data.items[i].name == "" || that.data.items[i].name == null || that.data.items[i].name == undefined) {
        wx.showModal({
          title: '提示信息',
          content: '请选择科目',
          showCancel: false
        });
        return;
      }
    }
    var path = that.data.state != "130008010" ? app.globalData.url + "/api/services/Sales/InsiderTrading/CreateWithItems" : app.globalData.url + "/api/services/Sales/InsiderTrading/UpdateWithItems";
    var obj = {
      id: that.data.InsiderTradingId,
      output: that.data.sales,
      input: that.data.buyer,
      creatorUserId: app.globalData.information.id,
      state: "130008005",
      no: that.data.no,
      paymentMode: that.data.payId,
      date: that.data.date,
      clearingMode: that.data.clearingModeId,
      isInsiderTrading: false,
      items: that.data.items
    };
    that.data.state != "130008010" ? delete obj["id"] && delete obj["state"] : obj;
    util.request(path, obj, "POST").then(function(res) {
      if (res.success) {
        that.setData({
          entityList: res.result,
          InsiderTrading: res.result.id,
          rejectOpen: true,
          open: false
        });
        wx.showModal({
          title: '提示信息',
          content: "保存成功，请点击申请审批！",
          showCancel: false
        });
      }
    }, function(error) {
      wx.showModal({
        title: '错误信息',
        content: error.error.message,
        showCancel: false
      });
    });
  },
  reject: function reject() {
    var that = this;
    var path = app.globalData.url + "/api/services/WorkFlow/WFTemplate/GetWFTemplateByType";
    var obj = {
      Type: "160205007",
      Param: "MaterialRequisition",
      organizationUnitId: app.globalData.information.organizationUnitId,
      pageSize: 2000
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      that.setData({
        workFlowTemp: res.result
      });
      if (res.result.id) {
        var path = app.globalData.url + "/api/services/WorkFlow/WorkFlow/Create";
        var obj = {
          name: that.data.salesName + "与" + that.data.buyerName + "发起一笔领料单，请审核",
          moduleName: "Sales",
          wfTempID: that.data.workFlowTemp.id,
          fkID: that.data.InsiderTrading,
          fkType: "InsiderTrading",
          startIndex: "1",
          data: JSON.stringify({
            id: that.data.InsiderTrading,
            fkType: "InsiderTrading"
          }),
          entity: that.data.entityList
        };
        util.request(path, obj, "POST").then(function(res) {
          if (res.success) {
            wx.switchTab({
              url: '/pages/ucenter/work/work'
            });
            return;
          }
        }, function(error) {
          wx.showModal({
            title: '错误信息',
            content: error.error.message,
            showCancel: false
          });
        });
      }
    });
  }
});