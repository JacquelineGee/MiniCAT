var util = require('../../../utils/util.js');
var user = require('../../../utils/cache/user.js');
var department = require('../../../utils/cache/department.js');
var unit = require('../../../utils/cache/unit.js');
var clearingMode = require('../../../utils/cache/clearingMode.js');
var paymentModecache = require('../../../utils/cache/paymentMode.js');
var accountcache = require('../../../utils/cache/account.js');
var app = getApp();
Page({
  data: {
    insiderTrading: {},
    remark: "",
    insiderTradingId: "",
    lastWorkFlowId: "",
    output: "",
    input: "",
    state: "",
    open: true,
    openstate: true,
    open1state: true,
    nodeID: [],
    workFlowAction: [],
    workFlowTemp: []
  },
  onLoad: function onLoad(options) {
    var that = this;
    that.setData({
      insiderTradingId: options.id,
      state: options.state
    });
    if (options.state == "130008020") {
      that.setData({
        open: false
      });
    }
    if (options.state == "130008005") {
      that.setData({
        open1: true
      });
    }
    that.LoadData(options.id);
  },
  LoadData: function LoadData(id) {
    var that = this;
    var userConfiguration = wx.getStorageSync('userConfiguration');
    var path = app.globalData.url + "/api/services/Sales/InsiderTrading/GetInsiderTradingById";
    var obj = {
      id: id
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      if (res.success) {
        res.result.outputname = department.getNameById(res.result.output);
        res.result.inputname = department.getNameById(res.result.input);
        res.result.paymentMode = paymentModecache.getNameById(res.result.paymentMode);
        res.result.clearingMode = clearingMode.getNameById(res.result.clearingMode);
        for (var i = 0; i < res.result.items.length; i++) {
          res.result.items[i].unit = unit.getNameById(res.result.items[i].unit);
          res.result.items[i].accountingsubjects = accountcache.getNameById(res.result.items[i].accountingsubjects);
        }
        that.setData({
          insiderTrading: res.result,
          output: res.result.output,
          input: res.result.input,
          state: res.result.state,
          remark: res.result.remark,
          no: res.result.state == "130008005" || res.result.state == "130008020" || res.result.top == "1" ? true : false,
          lastWorkFlowId: res.result.lastWorkFlowId
        });
      }
      if (that.data.lastWorkFlowId) {
        var pathFkID = app.globalData.url + "/api/services/WorkFlow/WorkFlowNode/GetAll";
        var objFkID = {
          searchGroup: {
            rules: [{
              field: "FlowID",
              value: that.data.lastWorkFlowId
            }]
          },
          pageSize: 2000
        };
        var GetDataFkID = util.getQueryUrl(pathFkID, objFkID);
        util.request(GetDataFkID).then(function(res) {
          var item = res.result.items;
          var items = item.filter(function(x) {
            return x.isCurrent == true;
          });
          if (items && items.length > 0) {
            that.setData({
              nodeID: items[0]
            });
            if (that.data.nodeID.userID == app.globalData.information.id || userConfiguration["Sales/InsiderTrading/Approve"] == 'true') {
              var path = app.globalData.url + "/api/services/WorkFlow/WorkFlowAction/GetAll";
              var obj = {
                searchGroup: {
                  rules: [{
                    field: "NodeID",
                    value: that.data.nodeID.id
                  }]
                },
                sorting: "LastModificationTime DESC",
                pageSize: 2000
              };
              var GetData = util.getQueryUrl(path, obj);
              util.request(GetData).then(function(res) {
                if (that.data.state == "130008020") {
                  that.setData({
                    open: false
                  });
                } else {
                  that.setData({
                    workFlowAction: res.result.items,
                    open: true
                  });
                }
              });
            } else {
              that.setData({
                open: false
              });
            }
          }
        });
      }
    });
    var path = app.globalData.url + "/api/services/WorkFlow/WFTemplate/GetAll";
    var obj = {
      searchGroup: {
        rules: [{
          field: "Type",
          value: "160205007"
        }]
      },
      pageSize: 2000
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      that.setData({
        workFlowTemp: res.result.items[0]
      });
    });
  },
  bindopinionInput: function bindopinionInput(e) {
    var that = this;
    that.setData({
      remark: e.detail.value
    });
  },
  //提交数据
  submit: function submit(e) {
    var that = this;
    // if (e.currentTarget.dataset.index == "temporary") {
    //   if (!that.data.workFlowTemp) {
    //     wx.showModal({
    //       title: '错误信息',
    //       content: '未设定审批流模板，无法发起审批！',
    //       showCancel: false
    //     })
    //   } else {
    //     that.setData({
    //       open1state: false
    //     })
    //     var path = app.globalData.url + "/api/services/WorkFlow/WorkFlow/Create"
    //     var obj = {
    //       name: "",
    //       wfTempID: that.data.workFlowTemp.id,
    //       fkID: that.data.insiderTradingId,
    //       fkType: "InsiderTrading",
    //       startIndex: "1",
    //       userId: app.globalData.information.id,
    //       remark: that.data.remark,
    //       data: JSON.stringify({
    //         id: that.data.insiderTradingId,
    //         fkType: "InsiderTrading",
    //         remark: that.data.remark
    //       })
    //     }
    //     util.request(path, obj, "POST").then((res) => {
    //       if (res.success) {
    //         wx.navigateBack(1)
    //         return;
    //       }
    //     }, (error) => {
    //       wx.showModal({
    //         title: '错误信息',
    //         content: error.error.message,
    //         showCancel: false
    //       });
    //     })
    //   }
    // } else {
    var bool = e.currentTarget.dataset.cmd == "pass" ? true : false;
    if (that.data.openstate) {
      that.setData({
        openstate: false
      });
      var path = app.globalData.url + "/api/services/Sales/InsiderTrading/ChangeState";
      var obj = {
        id: that.data.insiderTradingId,
        state: "130008020",
        workFlowId: that.data.lastWorkFlowId,
        workNodeId: that.data.nodeID.id,
        workActionId: e.currentTarget.dataset.id,
        cMD: e.currentTarget.dataset.cmd,
        remark: that.data.remark,
        data: {
          id: that.data.insiderTradingId,
          accountingsubjects: that.data.insiderTrading.items.accountingsubjects,
          output: that.data.output,
          input: that.data.input,
          state: bool ? "130008020" : "130008010"
        }
      };
      util.request(path, obj, "POST").then(function(res) {
        if (res.success) {
          wx.navigateBack(1);
        }
      });
    }
    //}
  }
});