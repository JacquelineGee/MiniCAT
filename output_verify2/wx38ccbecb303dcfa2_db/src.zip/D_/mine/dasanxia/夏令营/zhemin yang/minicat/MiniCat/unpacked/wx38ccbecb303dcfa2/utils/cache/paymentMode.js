var util = require('../util.js');
var app = getApp();
var paymentMode;

function init() {
  if (app.cache.paymentMode) paymentMode = app.cache.paymentMode;
  if (!paymentMode || paymentMode.length == 0) {
    var url = util.getQueryUrl(app.globalData.url + "/api/services/CodeData/CodeData/GetAll", {
      searchGroup: {
        rules: [{
          field: "codeDataTypeId",
          value: 130009
        }]
      },
      pageSize: 2000
    });
    util.request(url).then(function(res) {
      if (res.success) {
        paymentMode = res.result.items;
        app.cache.paymentMode = paymentMode;
      }
    }, function(error) {
      wx.showModal({
        title: '错误信息',
        content: error.error.message,
        showCancel: false
      });
    });
  }
}

function getNameById(uid) {
  var data = getpaymentModeById(uid);
  if (!data || data == null) return uid + "";
  return data.name;
}

function getpaymentModeById(uid) {
  paymentMode = app.cache.paymentMode;
  return paymentMode ? paymentMode.find(function(x) {
    return x.id == uid;
  }) : null;
}
module.exports = {
  getpaymentModeById: getpaymentModeById,
  getNameById: getNameById,
  init: init
};