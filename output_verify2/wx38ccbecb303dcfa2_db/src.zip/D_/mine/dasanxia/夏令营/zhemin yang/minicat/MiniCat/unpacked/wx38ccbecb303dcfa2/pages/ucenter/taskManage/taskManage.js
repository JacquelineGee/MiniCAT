var _createForOfIteratorHelper2 = require("../../../@babel/runtime/helpers/createForOfIteratorHelper");
var util = require('../../../utils/util.js');
var user = require('../../../utils/cache/user.js');
var WxParse = require('../../../lib/wxParse/wxParse.js');
var app = getApp();
var content = "";
Page({
  data: {
    checkedname: false,
    checked: false,
    src: "",
    srcs: "",
    path: app.globalData.url,
    department: "选择任务类型",
    ruleClassify: "",
    userName: "",
    userId: 0,
    PublishuserName: "",
    PbulishuserId: "",
    score: "",
    scores: "-----请选择------",
    scoreTemplateId: "",
    id: "",
    TaskManageId: "",
    TeamId: "00000000-0000-0000-0000-000000000000",
    startTime: "",
    endTime: "",
    openscore: false,
    tab: false,
    open: true,
    username: '',
    introduce: '',
    introduces: "",
    Publishintroduce: '',
    Publishintroduces: "",
    thought: '',
    thoughts: "",
    scoreRuleId: "",
    scoreTemplateItemId: "",
    TaskManage: "",
    taskManagescore: "",
    dep: [],
    ruleClassifys: [],
    movie: [],
    movies: [],
    department1: "选择部门",
    ruleClassifyId: "200011010",
    depid: "",
    userInformation: "",
    organizationUnitId: 0,
    update: false,
    hiddeName: true,
    hidderule: true,
    hiddedepar: true,
    hiddescore: true,
    hiddeintroduce: true,
    nocancel: true,
    hiddethought: true,
    state: "",
    openstate: false
  },
  confirm: function confirm() {
    var that = this;
    that.setData({
      hiddeName: true,
      hidderule: true,
      hiddedepar: true,
      hiddescore: true,
      Publishintroduce: that.data.Publishintroduce || that.data.Publishintroduce,
      hiddeintroduce: true,
      thought: that.data.thoughts || that.data.thought,
      hiddethought: true
    });
  },
  onLoad: function onLoad(options) {
    var that = this;
    var time = that.FormatTime();
    if (that.data.startTime == "") {
      that.setData({
        startTime: time
      });
    }
    that.setData({
      PublishuserName: user.getNameById(app.globalData.information.id),
      PublishuserId: app.globalData.information.id,
      organizationUnitId: app.globalData.information.organizationUnitId
    });
    if (options.teamId) {
      that.setData({
        TeamId: options.teamId
      });
    }
    if (options.id) {
      that.setData({
        state: options.state,
        update: true,
        TaskManageId: options.id
      });
      that.LoadDatas(options.id);
      return;
    } else {
      that.setData({
        state: "130008005"
      });
      //that.LoadData();
      return;
    }
  },
  //格式时间
  FormatTime: function FormatTime() {
    var date = new Date();
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    m = m < 10 ? '0' + m : m;
    var d = date.getDate();
    d = d < 10 ? '0' + d : d;
    return y + "-" + m + "-" + d;
  },
  LoadData: function LoadData() {
    var that = this;
    var path = app.globalData.url + "/api/services/Score/TaskManage/GetAll";
    var obj = {
      searchGroup: {
        rules: [{
          field: "creatorUserId",
          value: app.globalData.information.id
        }, {
          field: "state",
          value: "130008005"
        }],
        sorting: "CreationTime DESC",
        pageSize: 1
      }
    };
    util.request(path, obj).then(function(res) {
      if (res.success && res.result.totalCount > 0) {
        content = "<img class='adjunct' src='" + "http://file.sinpedo.com/" + res.result.items[0].publishImage + "'>";
        WxParse.wxParse('topicDetail', 'html', content, that);
        that.setData({
          TaskManageId: res.result.items[0].id,
          PublishuserName: res.result.items[0].publishUserName,
          PublishuserId: res.result.items[0].publishUserId,
          department: res.result.items[0].scoreRuleName,
          startTime: res.result.items[0].startDate,
          endTime: res.result.items[0].endDate,
          Publishintroduce: res.result.items[0].publishIntroduce,
          scoreRuleId: res.result.items[0].scoreRuleId,
          scoreTemplateItemId: res.result.items[0].scoreTemplateItemId,
          taskManagescore: res.result.items[0].score,
          scores: res.result.items[0].scoreTemplateItemName,
          checked: res.result.items[0].isSubjoinScore,
          srcs: res.result.items[0].publishImage,
          userName: res.result.items[0].name ? res.result.items[0].name : "",
          checkedname: res.result.items[0].isSubjoinScore,
          organizationUnitId: res.result.items[0].organizationUnitId,
          userId: res.result.items[0].userId,
          update: true
        });
      }
    });
  },
  LoadDatas: function LoadDatas(id) {
    var that = this;
    var path = app.globalData.url + "/api/services/Score/TaskManage/Get";
    var obj = {
      Id: id
    };
    var Get = util.getQueryUrl(path, obj);
    util.request(Get).then(function(res) {
      if (res.success) {
        content = "<img class='adjunct' src='" + that.data.path + "/Files/File/Image?FileName=" + res.result.publishImage + "'>";
        WxParse.wxParse('topicDetail', 'html', content, that);
        that.setData({
          PublishuserName: res.result.publishUserName,
          PublishuserId: res.result.publishuserId,
          department: res.result.scoreRuleName,
          startTime: res.result.startDate,
          endTime: res.result.endDate,
          Publishintroduce: res.result.publishIntroduce,
          scoreRuleId: res.result.scoreRuleId,
          scoreTemplateItemId: res.result.scoreTemplateItemId,
          taskManagescore: res.result.score,
          scores: res.result.scoreTemplateItemName,
          checked: res.result.isSubjoinScore,
          srcs: res.result.publishImage,
          userName: res.result.name ? res.result.name : "",
          userId: res.result.userId,
          checkedname: res.result.isSubjoinScore
        });
      }
    });
  },
  click: function click() {
    var that = this;
    wx.chooseImage({
      count: 1,
      // 默认9  
      sizeType: ['original', 'compressed'],
      // 可以指定是原图还是压缩图，默认二者都有  
      sourceType: ['album', 'camera'],
      // 可以指定来源是相册还是相机，默认二者都有  
      success: function success(res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片  
        var tempFilePaths = res.tempFilePaths;
        that.upload(that, tempFilePaths);
      }
    });
  },
  upload: function upload(page, path) {
    wx.showToast({
      icon: "loading",
      title: "正在上传"
    }), wx.uploadFile({
      url: app.globalData.url + "/Files/File/UploadFile",
      filePath: path[0],
      name: 'file',
      header: {
        "Content-Type": "multipart/form-data"
      },
      formData: {
        //和服务器约定的token, 一般也可以放在header中
        'session_token': wx.getStorageSync('session_token')
      },
      success: function success(res) {
        var json = JSON.parse(res.data);
        if (json.success) {
          content = "<img class='adjunct' src='" + page.data.path + "/Files/File/Image?FileName=" + json.result.fileNames[0] + "'>";
          WxParse.wxParse('topicDetail', 'html', content, page);
          page.setData({
            //上传成功修改显示头像
            src: "/Files/File/Image?FileName=" + json.result.fileNames,
            srcs: json.result.fileNames[0]
          });
        } else {
          wx.showModal({
            title: '提示',
            content: '上传失败',
            showCancel: false
          });
          return;
        }
      },
      fail: function fail(e) {
        wx.showModal({
          title: '提示',
          content: '上传失败',
          showCancel: false
        });
      },
      complete: function complete() {
        wx.hideToast(); //隐藏Toast
      }
    });
  },

  switchd: function switchd(e) {
    var that = this;
    that.setData({
      checkedname: e.detail.value
    });
  },
  username: function username() {
    var that = this;
    that.setData({
      hiddeName: false
    });
    var path = app.globalData.url + "/api/services/Foundation/User/GetUsers";
    var obj = {
      Filter: "",
      Permission: "",
      Role: "",
      Sorting: "",
      MaxResultCount: 999,
      SkipCount: 1
    };
    util.request(path, obj, "Get").then(function(res) {
      that.setData({
        movie: res.result.items
      });
      //console.log(that.data.movie)
    });
  },

  userone: function userone(e) {
    var that = this;
    if (e.currentTarget.dataset.name == user.getNameById(app.globalData.information.id)) {
      wx.showModal({
        title: '提示信息',
        content: "不能自己给自己指定任务！"
      });
    } else {
      this.setData({
        userName: e.currentTarget.dataset.name,
        userId: e.currentTarget.dataset.id,
        organizationUnitId: e.currentTarget.dataset.organizationunitid,
        hiddeName: true
      });
    }
  },
  hiddeintroduce: function hiddeintroduce() {
    var that = this;
    that.setData({
      Publishintroduce: that.data.Publishintroduce,
      hiddeintroduce: false
    });
  },
  hiddethought: function hiddethought() {
    var that = this;
    that.setData({
      thoughts: that.data.thought,
      hiddethought: false
    });
  },
  ruleClassify: function ruleClassify() {
    this.setData({
      hidderule: false
    });
    var that = this;
    var path = app.globalData.url + "/api/services/CodeData/CodeData/GetAll";
    var obj = {
      searchGroup: {
        rules: [{
          field: "codeDataTypeId",
          value: 200011
        }]
      },
      pageSize: 999
    };
    util.request(path, obj, "Get").then(function(res) {
      that.setData({
        ruleClassifys: res.result.items
      });
    });
  },
  department: function department() {
    this.setData({
      hiddedepar: false
    });
    var that = this;
    var id = "";
    var path = app.globalData.url + "/api/services/CodeData/CodeData/GetAll";
    var obj = {
      searchGroup: {
        rules: [{
          field: "Name",
          value: "任务规则"
        }]
      },
      pageSize: 999
    };
    util.request(path, obj, "Get").then(function(res) {
      var id = res.result.items[0].id;
      var path1 = app.globalData.url + "/api/services/Score/ScoreRule/GetAll";
      var obj1 = {
        searchGroup: {
          rules: [{
            field: "ruleClassify",
            value: id
          }]
        },
        pageSize: 999
      };
      util.request(path1, obj1, "Get").then(function(res1) {
        that.setData({
          movies: res1.result.items
        });
      });
    });
  },
  one: function one(e) {
    this.setData({
      department: e.currentTarget.dataset.name,
      hiddedepar: true,
      scoreRuleId: e.currentTarget.dataset.scoreruleid,
      scores: "",
      scoreTemplateItemId: "",
      gradeManagescore: ""
    });
    var that = this;
    var path = app.globalData.url + "/api/services/Score/ScoreTemplate/GetItemsById";
    var obj = {
      id: e.currentTarget.dataset.id
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      that.setData({
        score: res.result,
        tab: true
      });
    });
  },
  scoretap: function scoretap(e) {
    if (this.data.department == "选择任务类型") {
      wx.showModal({
        title: '提示消息',
        content: '请先选择任务分类',
        showCancel: false
      });
      return;
    }
    this.setData({
      hiddescore: false
    });
  },
  scoreone: function scoreone(e) {
    this.setData({
      scores: e.currentTarget.dataset.name,
      hiddescore: true,
      scoreTemplateItemId: e.currentTarget.dataset.id,
      taskManagescore: e.currentTarget.dataset.score
    });
  },
  bindUsernameInput: function bindUsernameInput(e) {
    this.setData({
      username: e.detail.value
    });
  },
  bindIntroduceInput: function bindIntroduceInput(e) {
    var that = this;
    this.setData({
      Publishintroduce: e.detail.value
    });
  },
  bindThoughtInput: function bindThoughtInput(e) {
    var that = this;
    this.setData({
      thoughts: e.detail.value
    });
  },
  datePicker: function datePicker(e) {
    this.setData({
      startTime: e.detail.value
    });
  },
  datePicker1: function datePicker1(e) {
    this.setData({
      endTime: e.detail.value
    });
  },
  //获取输入的用户信息
  input: function input(e) {
    this.setData({
      userInformation: e.detail.value
    });
  },
  //根据用户信息查询数据
  get: function get() {
    var that = this;
    var UserList = app.cache.users;
    var UserLists = [];
    var _iterator = _createForOfIteratorHelper2(UserList),
      _step;
    try {
      for (_iterator.s(); !(_step = _iterator.n()).done;) {
        var item = _step.value;
        if (item.name.indexOf(that.data.userInformation) > -1 && item.name != "admin") {
          UserLists.push(item);
        }
      }
    } catch (err) {
      err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
      _iterator.e(err);
    } finally {
      _iterator.f();
    }
    that.setData({
      movie: UserLists
    });
    //console.log(that.data.movie)
    //console.log(UserLists)
  },

  buttonsave: function buttonsave(options) {
    var that = this;
    if (that.data.PublishuserName == '用户' || !that.data.scoreRuleId || !that.data.scoreTemplateItemId) {
      wx.showModal({
        title: '错误信息',
        content: '请补充完数据~~',
        showCancel: false
      });
      return;
    }
    if (that.data.Name != "" && that.data.Name == that.data.PublishuserName) {
      wx.showModal({
        title: '提示信息',
        content: "不能给自己指定任务！"
      });
      return;
    } else {
      that.setData({
        open: false
      });
      var path;
      var obj;
      if (that.data.update == true) {
        path = app.globalData.url + "/api/services/Score/TaskManage/Update";
        obj = {
          id: that.data.TaskManageId,
          publishUserId: app.globalData.information.id,
          publishUserName: that.data.PublishuserName,
          name: that.data.userName ? that.data.userName : "",
          userId: that.data.userId,
          creatorUserId: app.globalData.information.id,
          isSubjoinScore: that.data.checkedname ? "true" : "false",
          scoreRuleId: that.data.scoreRuleId,
          scoreTemplateItemId: that.data.scoreTemplateItemId,
          state: "130008005",
          startDate: that.data.startTime,
          endDate: that.data.endTime,
          organizationUnitId: that.data.organizationUnitId,
          score: that.data.taskManagescore,
          teamId: that.data.TeamId,
          publishimage: that.data.srcs,
          publishintroduce: that.data.Publishintroduce ? that.data.Publishintroduce : ""
        };
      } else {
        path = app.globalData.url + "/api/services/Score/TaskManage/Create";
        obj = {
          publishUserId: app.globalData.information.id,
          publishUserName: that.data.PublishuserName,
          name: that.data.userName ? that.data.userName : "",
          userId: that.data.userId,
          creatorUserId: app.globalData.information.id,
          isSubjoinScore: that.data.checkedname ? "true" : "false",
          scoreRuleId: that.data.scoreRuleId,
          scoreTemplateItemId: that.data.scoreTemplateItemId,
          state: "130008005",
          startDate: that.data.startTime,
          endDate: that.data.endTime,
          organizationUnitId: that.data.organizationUnitId,
          score: that.data.taskManagescore,
          teamId: that.data.TeamId,
          publishimage: that.data.srcs,
          publishintroduce: that.data.Publishintroduce ? that.data.Publishintroduce : ""
        };
      }
      //console.log(that.data.update)
      //console.log(obj)
      util.request(path, obj).then(function(res) {
        if (res.success) {
          that.setData({
            TaskManageId: res.result.id,
            rejectOpen: true,
            open: false,
            openstate: true
          });
          wx.showModal({
            title: '提示信息',
            content: "保存成功，请点击确认发布！",
            showCancel: false
          });
        }
        //res = "";
      }, function(error) {
        wx.showModal({
          title: '错误信息',
          content: error.error.message,
          showCancel: false
        });
      });
    }
  },
  publish: function publish(e) {
    var that = this;
    if (that.data.openstate) {
      that.setData({
        openstate: false
      });
      var status = that.data.userName ? "130008010" : "130008000";
      var path = app.globalData.url + "/api/services/Score/TaskManage/Update";
      var obj = {
        id: that.data.TaskManageId,
        publishUserId: app.globalData.information.id,
        publishUserName: that.data.PublishuserName,
        name: that.data.userName ? that.data.userName : "",
        userId: that.data.userId,
        creatorUserId: app.globalData.information.id,
        isSubjoinScore: that.data.checkedname ? "true" : "false",
        scoreRuleId: that.data.scoreRuleId,
        scoreTemplateItemId: that.data.scoreTemplateItemId,
        state: status,
        startDate: that.data.startTime,
        endDate: that.data.endTime,
        organizationUnitId: that.data.organizationUnitId,
        score: that.data.taskManagescore,
        teamId: that.data.TeamId,
        publishimage: that.data.srcs,
        publishintroduce: that.data.Publishintroduce ? that.data.Publishintroduce : ""
      };
      util.request(path, obj).then(function(res) {
        if (res.success) {
          if (that.data.TeamId != "00000000-0000-0000-0000-000000000000") {
            wx.navigateTo({
              url: '/pages/ucenter/taskPlan/taskPlan?id=' + that.data.TeamId
            });
          } else {
            wx.navigateBack(1);
          }
        }
      });
    }
  }
});