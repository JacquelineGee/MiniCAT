var _createForOfIteratorHelper2 = require("../@babel/runtime/helpers/createForOfIteratorHelper");
var api = require('../config/api.js');

function formatTime(date) {
  var year = date.getFullYear();
  var month = date.getMonth() + 1;
  var day = date.getDate();
  var hour = date.getHours();
  var minute = date.getMinutes();
  var second = date.getSeconds();
  return [year, month, day].map(formatNumber).join('-') + ' ' + [hour, minute, second].map(formatNumber).join(':');
}

function formatNumber(n) {
  n = n.toString();
  return n[1] ? n : '0' + n;
}
/**
 * Json字符串转换方法
 * 遇到ISO时间字符将转换为日期
 * @param value
 */
function jsonreviver(value) {
  var a;
  if (typeof value === 'string') {
    a = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2}(?:\.\d*)?)Z?$/.exec(value);
    if (a) {
      return formatTime(new Date(Date.UTC(+a[1], +a[2] - 1, +a[3], +a[4], +a[5], +a[6])));
    }
  }
  return value;
}

function jsonrevivers(value) {
  var date;
  var time = value + " " + "00:00";
  date = new Date(time).toISOString();
  return date;
}

function getQueryUrl(url, params) {
  url = url + "?";
  url += setQueryParameters(params);
  return url;
}
/**
 */
function request(url) {
  var input = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  var method = arguments.length > 2 ? arguments[2] : undefined;
  var Type = arguments.length > 3 ? arguments[3] : undefined;
  return new Promise(function(resolve, reject) {
    var options = {
      method: method ? method : "POST",
      headers: {
        "Content-Type": Type ? Type : "application/json; charset=UTF-8",
        "Accept": "application/json; charset=UTF-8",
        'X-Nideshop-Token': wx.getStorageSync('token'),
        "accept-language": "zh-CN,zh;q=0.8",
        "Abp.Localization.CultureName": "zh-CN",
        ".AspNetCore.Culture": "zh-CN"
      }
    };
    {
      var _url = url.toLowerCase() + "?";
      if (_url.indexOf('/get') > -1) {
        options.method = "GET";
        url = getQueryUrl(url, input);
        //console.log(url);
        input = null;
      } else if (_url.indexOf('/update') > -1) options.method = "PUT";
      else if (_url.indexOf('/delete') > -1) options.method = "DELETE";
    }
    var data = {};
    setJsData(input, data);
    var content_ = JSON.stringify(data); // JSON.stringify(input ? data : null);
    var authorization = wx.getStorageSync('authorization');
    if (authorization) options.headers["Authorization"] = authorization;
    var userConfiguration = wx.getStorageSync('userConfiguration');
    if (userConfiguration) options.headers["UserConfiguration"] = userConfiguration;
    var tenancyName = wx.getStorageSync('tenancyName');
    if (tenancyName) options.headers["TenancyName"] = tenancyName;
    var tenantId = wx.getStorageSync('tenantId');
    if (tenantId) options.headers["Abp.TenantId"] = tenantId;
    wx.request({
      url: url,
      data: content_,
      method: options.method,
      header: options.headers,
      success: function success(res) {
        if (res.statusCode == 200) {
          if (res.data.errno == 401) {
            //需要登录后才可以操作
            var code = null;
            return login().then(function(res) {
              code = res.code;
              return getUserInfo();
            }).then(function(userInfo) {
              //登录远程服务器
              request(api.AuthLoginByWeixin, {
                code: code,
                userInfo: userInfo
              }, 'POST').then(function(res) {
                if (res.errno === 0) {
                  //存储用户信息
                  wx.setStorageSync('userInfo', res.data.userInfo);
                  wx.setStorageSync('token', res.data.token);
                  resolve(res);
                } else {
                  reject(res);
                }
              }).catch(function(err) {
                reject(err);
              });
            }).catch(function(err) {
              reject(err);
            });
          } else {
            resolve(res.data);
          }
        } else {
          if (res.data.error.message == "Current user did not login to the application!" || res.data.error.message == "用户未登录！" || res.data.error.message == "当前用户没有登录到系统！" || res.data.error.details && res.data.error.details.indexOf("Current user did not login to the application") > -1) {
            wx.redirectTo({
              url: '/pages/auth/login/login'
            });
            return;
          }
          if (res.statusCode == 500) {
            reject(res.data);
            return;
          }
          reject(res.data);
        }
      },
      fail: function fail(err) {
        reject(err);
      }
    });
  });
}

/**
 * 检查微信会话是否过期
 */
function checkSession() {
  return new Promise(function(resolve, reject) {
    wx.checkSession({
      success: function success() {
        resolve(true);
      },
      fail: function fail() {
        reject(false);
      }
    });
  });
}

/**
 * 调用微信登录
 */
function login() {
  return new Promise(function(resolve, reject) {
    wx.login({
      success: function success(res) {
        if (res.code) {
          //登录远程服务器
          resolve(res);
        } else {
          reject(res);
        }
      },
      fail: function fail(err) {
        reject(err);
      }
    });
  });
}

function getUserInfo() {
  return new Promise(function(resolve, reject) {
    wx.getUserInfo({
      withCredentials: true,
      success: function success(res) {
        resolve(res);
      },
      fail: function fail(err) {
        reject(err);
      }
    });
  });
}

function redirect(url) {
  //判断页面是否需要登录
  if (false) {
    wx.redirectTo({
      url: '/pages/auth/login/login'
    });
    return false;
  } else {
    wx.redirectTo({
      url: url
    });
  }
}

function showErrorToast(msg) {
  wx.showToast({
    title: msg,
    image: '/static/images/icon_error.png'
  });
}

function setQueryParameters(params, prefix) {
  var url = '';
  for (var key in params) {
    if (params[key] == undefined || params[key] == null || typeof params[key] == "function") {
      continue;
    } else if (params[key] && params[key].constructor === Array) {
      var i = 0;
      var _iterator = _createForOfIteratorHelper2(params[key]),
        _step;
      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var item = _step.value;
          if (item.toString() === "[object Object]") {
            url += setQueryParameters(params[key][i], "".concat(prefix ? prefix + '.' + key : key, "[").concat(i, "]"));
          } else {
            url += "".concat(prefix ? prefix + '.' + key : key, "[").concat(i, "]") + "=" + encodeURIComponent("" + item) + "&";
          }
          i++;
        }
      } catch (err) {
        err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
    } else if (params[key].toString() === "[object Object]") {
      url += setQueryParameters(params[key], key);
    } else url += (prefix ? prefix + '.' + key : key) + "=" + encodeURIComponent("" + params[key]) + "&";
  }
  return url;
}

function setJsData(input, data) {
  for (var key in input) {
    //if (typeof input[key] == "function") continue;
    if (input[key] == undefined || input[key] == null) {
      //data[key] = null;
      continue;
    } else if (input[key] && input[key].constructor === Array) {
      data[key] = [];
      var index = 0;
      var _iterator2 = _createForOfIteratorHelper2(input[key]),
        _step2;
      try {
        for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
          var item = _step2.value;
          var newItem = {};
          if (item.toString() === "[object Object]") {
            setJsData(item, newItem);
            data[key].push(newItem);
          } else {
            data[key] = input[key];
          }
        }
      } catch (err) {
        err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
        _iterator2.e(err);
      } finally {
        _iterator2.f();
      }
    } else if (input[key].toString() === "[object Object]") {
      data[key] = {};
      for (var keyField in input[key]) {
        if (typeof input[key][keyField] == "function") continue;
        data[key][keyField] = input[key][keyField];
      }
    } else if (input[key].constructor === String) {
      data[key] = input[key].replace(/(^\s*)|(\s*$)/g, "");
      if (data[key] == "") data[key] = null;
    } else data[key] = input[key];
  }
}
module.exports = {
  formatTime: formatTime,
  request: request,
  redirect: redirect,
  showErrorToast: showErrorToast,
  checkSession: checkSession,
  login: login,
  getUserInfo: getUserInfo,
  jsonreviver: jsonreviver,
  jsonrevivers: jsonrevivers,
  getQueryUrl: getQueryUrl
};