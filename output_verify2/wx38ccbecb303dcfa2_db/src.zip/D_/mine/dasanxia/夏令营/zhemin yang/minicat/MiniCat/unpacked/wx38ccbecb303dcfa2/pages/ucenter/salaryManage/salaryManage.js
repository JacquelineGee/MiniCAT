var util = require('../../../utils/util.js');
var api = require('../../../config/api.js');
var usercache = require('../../../utils/cache/user.js');
var app = getApp();
Page({
  data: {
    login: "",
    name: "",
    salaryName: "工资",
    setInter: ''
  },
  onLoad: function onLoad(options) {
    var that = this;
    that.setData({
      name: usercache.getNameById(app.globalData.information.id),
      token: app.globalData.token
    });
    that.getProfilePicture();
    var userConfiguration = wx.getStorageSync('userConfiguration');
    if (userConfiguration["Salary/SalaryManagement/AllData"] == 'true') {
      that.setData({
        salaryManagement: true
      });
    }
    if (userConfiguration["Salary/KpiManage/AllData"] == 'true') {
      that.setData({
        KpiManage: true
      });
    }
    if (userConfiguration["Salary/SalaryManagementReport"] == 'true') {
      that.setData({
        salaryReport: true
      });
    }
    if (userConfiguration["Salary/SalaryManagementReport/AllData"] == 'true' || userConfiguration["Salary/SalaryManagementReport/OrgAllData"] == 'true') {
      that.setData({
        salaryManagementReport: true
      });
    }
    var path = app.globalData.url + "/api/services/Salary/SalaryManage/GetSalaryName";
    var obj = {};
    util.request(path, obj, "Get").then(function(res) {
      var name = res.result;
      that.setData({
        salaryName: name
      });
    });
  },
  getProfilePicture: function getProfilePicture() {
    var that = this;
    var path = app.globalData.url + "/api/services/Foundation/Profile/GetProfilePicture";
    var obj = {
      MaxResultCount: 2000,
      pageSize: 2000
    };
    util.request(path, obj, "Get").then(function(res) {
      var profilePicture = 'data:image/jpeg;base64,' + res.result.profilePicture;
      that.setData({
        login: profilePicture
      });
    });
  },
  profile: function profile() {
    var that = this;
    wx.chooseImage({
      count: 1,
      // 默认9  
      sizeType: ['original', 'compressed'],
      // 可以指定是原图还是压缩图，默认二者都有  
      sourceType: ['album', 'camera'],
      // 可以指定来源是相册还是相机，默认二者都有  
      success: function success(res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片  
        that.upload(res.tempFilePaths);
      }
    });
  },
  upload: function upload(tempFilePath) {
    var that = this;
    wx.showToast({
      icon: "loading",
      title: "正在上传"
    });
    var authorization = wx.getStorageSync('authorization');
    wx.uploadFile({
      url: app.globalData.url + "/Profile/UploadProfilePicture",
      filePath: tempFilePath[0],
      name: 'file',
      header: {
        "Content-Type": "multipart/form-data",
        "Authorization": authorization
      },
      formData: {
        //和服务器约定的token, 一般也可以放在header中
        'session_token': wx.getStorageSync('session_token')
      },
      success: function success(res) {
        var json = JSON.parse(res.data);
        if (json.success) {
          that.tempFilePaths(json.result.fileName);
        } else {
          wx.showModal({
            title: '提示',
            content: '上传失败',
            showCancel: false
          });
          return;
        }
      },
      fail: function fail(e) {
        wx.showModal({
          title: '提示',
          content: '上传失败',
          showCancel: false
        });
      },
      complete: function complete() {
        wx.hideToast(); //隐藏Toast
      }
    });
  },

  tempFilePaths: function tempFilePaths(_tempFilePaths) {
    var that = this;
    var path = app.globalData.url + "/api/services/Foundation/Profile/UpdateProfilePicture";
    var obj = {
      fileName: _tempFilePaths
    };
    util.request(path, obj).then(function(res) {
      if (res.success) {
        that.getProfilePicture();
      }
    });
  }
});