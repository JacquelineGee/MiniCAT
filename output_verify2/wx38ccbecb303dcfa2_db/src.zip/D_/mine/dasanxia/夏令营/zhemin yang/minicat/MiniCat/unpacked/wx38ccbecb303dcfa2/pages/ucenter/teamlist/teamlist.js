var app = getApp();
var WxParse = require('../../../lib/wxParse/wxParse.js');
var util = require('../../../utils/util.js');
Page({
  data: {
    movies: [],
    Id: ""
  },
  onLoad: function onLoad(options) {
    var that = this;
    that.setData({
      Id: options.id
    });
    var path = app.globalData.url + "/api/services/Score/Team/GetTeamByActivityId";
    var obj = {
      activityId: that.data.Id
    };
    var userConfiguration = wx.getStorageSync('userConfiguration');
    util.request(path, obj, "Get").then(function(res) {
      if (userConfiguration["Score/Team/Create"] == "true") {
        that.setData({
          open: true
        });
      }
      that.setData({
        movies: res.result
      });
    });
  },
  add: function add() {
    var that = this;
    wx.navigateTo({
      url: "/pages/ucenter/team1/team1?activityId=" + that.data.Id
    });
  },
  add1: function add1() {
    var that = this;
    wx.navigateTo({
      url: "/pages/ucenter/gradePreview/gradePreview?activityId=" + that.data.Id
    });
  }
});