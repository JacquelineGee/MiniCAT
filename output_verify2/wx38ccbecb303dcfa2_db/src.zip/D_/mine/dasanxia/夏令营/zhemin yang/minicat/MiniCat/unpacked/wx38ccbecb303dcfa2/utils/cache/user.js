var util = require('../util.js');
var app = getApp();
var users;

function init() {
  if (app.cache.users) users = app.cache.users;
  if (!users || users.length == 0) {
    var url = util.getQueryUrl(app.globalData.url + "/api/services/Foundation/User/GetUsers", {
      MaxResultCount: 2000,
      pageSize: 2000
    });
    util.request(url).then(function(res) {
      if (res.success) {
        users = res.result.items;
        app.cache.users = users;
      }
    }, function(error) {
      if (error.errMsg) {
        wx.showModal({
          title: '错误信息',
          content: error.errMsg,
          showCancel: false
        });
      } else {
        wx.showModal({
          title: '错误信息',
          content: error.error.message,
          showCancel: false
        });
      }
    });
  }
}

function getNameById(uid) {
  var data = getUserById(uid);
  if (!data || data == null) return uid + "";
  return data.name;
}

function getUserById(uid) {
  users = app.cache.users;
  if (!users || users.length == 0) init();
  else {
    return users ? users.find(function(x) {
      return x.id == uid;
    }) : null;
  }
}

function getOUIdById(uid) {
  var data = getUserById(uid);
  if (!data || data == null) return uid + "";
  return data.organizationUnitId;
}
module.exports = {
  getUserById: getUserById,
  getNameById: getNameById,
  getOUIdById: getOUIdById,
  init: init
};