var util = require('../../../utils/util.js');
var app = getApp();
var url = app.globalData.url + "/api/services/Score/Activity/GetAll";
var page = 0;
var page_size = 10;
var is_easy = 0;
var lange_id = 0;
var pos_id = 0;
var unlearn = 0;
var flag = true;
// 请求数据
var loadMore = function loadMore(that, data) {
  setTimeout(function() {
    flag = true;
  }, 1800);
  if (!data) {
    if (that.data.totalCount != 0) {
      if (that.data.totalCount % page_size == 0) {
        var count = that.data.totalCount / page_size;
        if (page > count) {
          return;
        }
      } else {
        var count = Math.ceil(that.data.totalCount / page_size);
        if (page >= count) {
          return;
        }
      }
    }
    page++;
  }
  that.setData({
    hidden: false
  });
  var obj = {
    searchGroup: {
      op: 1,
      rules: [{
        field: "no",
        value: "",
        op: 3
      }]
    },
    sorting: "CreationTime DESC",
    pageSize: data ? "2000" : page_size,
    pageIndex: data ? 1 : page,
    filter: data ? data : ""
  };
  var GetData = util.getQueryUrl(url, obj);
  util.request(GetData).then(function(res) {
    var list = that.data.list;
    for (var i = 0; i < res.result.items.length; i++) {
      list.push(res.result.items[i]);
    }
    that.setData({
      list: list,
      totalCount: res.result.totalCount
    });
    that.setData({
      hidden: true
    });
  }, function(err) {
    that.setData({
      hidden: true
    });
  });
};
Page({
  data: {
    hidden: true,
    list: [],
    scrollTop: 0,
    scrollHeight: 0,
    totalCount: 0,
    input: ""
  },
  onShow: function onShow() {
    //  这里要注意，微信的scroll-view必须要设置高度才能监听滚动事件，所以，需要在页面的onLoad事件中给scroll-view的高度赋值
    var that = this;
    wx.getSystemInfo({
      success: function success(res) {
        that.setData({
          scrollHeight: res.windowHeight
        });
      }
    });
    loadMore(that);
  },
  //页面滑动到底部
  bindDownLoad: function bindDownLoad(e) {
    var that = this;
    if (flag) {
      flag = false;
      loadMore(that);
    }
  },
  scroll: function scroll(event) {
    //该方法绑定了页面滚动时的事件，我这里记录了当前的position.y的值,为了请求数据之后把页面定位到这里来。
    this.setData({
      scrollTop: event.detail.scrollTop
    });
  },
  input: function input(e) {
    var that = this;
    that.setData({
      input: e.detail.value
    });
  },
  Search: function Search() {
    var that = this;
    //loadMore(that,that.data.input);
  },

  onHide: function onHide() {
    page = 0, this.setData({
      list: []
    });
  },
  onUnload: function onUnload() {
    page = 0, this.setData({
      list: []
    });
  }
});