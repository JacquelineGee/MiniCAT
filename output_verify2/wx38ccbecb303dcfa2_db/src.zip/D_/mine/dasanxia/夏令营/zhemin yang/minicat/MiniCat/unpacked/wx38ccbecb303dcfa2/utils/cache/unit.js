var util = require('../util.js');
var app = getApp();
var unit;

function init() {
  if (app.cache.unit) unit = app.cache.unit;
  if (!unit || unit.length == 0) {
    var url = util.getQueryUrl(app.globalData.url + "/api/services/CodeData/CodeData/GetAll", {
      searchGroup: {
        rules: [{
          field: "codeDataTypeId",
          value: 120040
        }]
      },
      pageSize: 2000
    });
    util.request(url).then(function(res) {
      if (res.success) {
        unit = res.result.items;
        app.cache.unit = unit;
      }
    }, function(error) {
      wx.showModal({
        title: '错误信息',
        content: error.error.message,
        showCancel: false
      });
    });
  }
}

function getNameById(uid) {
  var data = getunitById(uid);
  if (!data || data == null) return uid + "";
  return data.name;
}

function getunitById(uid) {
  unit = app.cache.unit;
  return unit ? unit.find(function(x) {
    return x.id == uid;
  }) : null;
}
module.exports = {
  getunitById: getunitById,
  getNameById: getNameById,
  init: init
};