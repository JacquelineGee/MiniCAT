var app = getApp();
var util = require('../../../utils/util.js');
var department = require('../../../utils/cache/department.js');
var StotalTime;
Page({
  data: {
    department: "",
    labor: "",
    id: "",
    hiddendep: true,
    hiddenlabor: true,
    nocancel: true,
    rejectOpen: false,
    open: true,
    date: "",
    state: "",
    LaborHour: "",
    movie: [],
    list: [],
    list1: [],
    workFlowTemp: [],
    entityList: {},
    laborSettingId: "",
    departmentId: ""
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {
    var that = this;
    that.InitData();
    if (options.id) {
      that.setData({
        state: options.state,
        id: options.id
      });
      that.LoadData(options.id);
      return;
    }
    var time = that.FormatTime();
    that.setData({
      date: time
    });
  },
  //处理驳回的数据
  LoadData: function LoadData(id) {
    var that = this;
    var path = app.globalData.url + "/api/services/Wage/LaborHour/GetLaborHourFullById";
    var obj = {
      id: id
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      if (res.success) {
        var time = that.FormatTime(res.result.creationTime);
        var temp = department.getNameById(res.result.department);
        that.setData({
          department: temp,
          departmentId: res.result.department,
          date: time,
          list: res.result.items
        });
      }
    }, function(error) {
      console.log(error);
    });
  },
  //格式时间
  FormatTime: function FormatTime() {
    var date = new Date();
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    m = m < 10 ? '0' + m : m;
    var d = date.getDate();
    d = d < 10 ? '0' + d : d;
    return y + "-" + m + "-" + d;
  },
  //取消弹出框
  confirm: function confirm(e) {
    var that = this;
    that.setData({
      hiddendep: true,
      hiddenlabor: true
    });
  },
  //初始化数据
  InitData: function InitData() {
    var that = this;
    //部门  
    var path = app.globalData.url + "/api/services/Foundation/OrganizationUnit/GetOrganizationUnits";
    var obj = {
      MaxResultCount: 2000,
      pageSize: 2000
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      that.setData({
        movie: res.result.items
      });
    });
    //工时设定
    var path1 = app.globalData.url + "/api/services/Wage/LaborSetting/GetAll";
    util.request(path1).then(function(res) {
      that.setData({
        list1: res.result.items
      });
    });
  },
  //部门 
  bindAccountChange: function bindAccountChange(e) {
    var that = this;
    that.setData({
      hiddendep: false
    });
  },
  DepartmentChange: function DepartmentChange(e) {
    var that = this;
    that.setData({
      hiddendep: true,
      department: e.currentTarget.dataset.name,
      departmentId: e.currentTarget.dataset.data
    });
  },
  //工时设定
  labor: function labor() {
    var that = this;
    that.setData({
      hiddenlabor: false
    });
  },
  select: function select() {
    var that = this;
    if (!that.data.departmentId || !that.data.date) {
      wx.showModal({
        title: '提示信息',
        content: "请补全数据再查询！",
        showCancel: false
      });
      return;
    }
    var path = app.globalData.url + "/api/services/Wage/LaborSetting/GetLaborSetting";
    var obj = {
      department: that.data.departmentId,
      date: that.data.date
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      var array = [];
      for (var i = 0; i < res.result.items.length; i++) {
        var temp = {
          profession: res.result.items[i].profession,
          laborGroup: res.result.items[i].laborGroup,
          hourlyWage: res.result.items[i].hourlyWage,
          extraWage: res.result.items[i].extraWage,
          workTime: res.result.items[i].workTime,
          numberOfWork: 0,
          overTime: 0,
          totalTime: 0,
          totalWage: 0
        };
        array.push(temp);
      }
      that.setData({
        list: array
      });
    }, function(err) {
      that.setData({
        list: []
      });
      wx.showModal({
        title: '提示信息',
        content: err.error.message,
        showCancel: false
      });
    });
  },
  //选择时间
  datePickers: function datePickers(e) {
    var that = this;
    that.setData({
      date: e.detail.value
    });
  },
  InputNumber: function InputNumber(e) {
    var that = this;
    var list = that.data.list;
    list[e.currentTarget.dataset.number].overTime = "";
    StotalTime = Math.round(parseFloat(e.detail.value) * e.currentTarget.dataset.worktime * 100) / 100;
    list[e.currentTarget.dataset.number].totalTime = StotalTime;
    list[e.currentTarget.dataset.number].numberOfWork = e.detail.value;
    that.setData({
      list: that.data.list
    });
  },
  InputHour: function InputHour(e) {
    var that = this;
    // if (that.data.list[e.currentTarget.dataset.number].totalTime == 0) {
    //   wx.showModal({
    //     title: '提示信息',
    //     content: '请输入上班人数~~',
    //     showCancel: false
    //   });
    //   return;
    // }
    var tempdata = that.data.list[e.currentTarget.dataset.number].numberOfWork * e.currentTarget.dataset.hourlywage * that.data.list[e.currentTarget.dataset.number].workTime;
    var totalWage = e.detail.value * e.currentTarget.dataset.extrawage + tempdata;
    var totalTime = StotalTime + parseFloat(e.detail.value);
    var list = that.data.list;
    list[e.currentTarget.dataset.number].totalWage = totalWage;
    list[e.currentTarget.dataset.number].overTime = e.detail.value;
    list[e.currentTarget.dataset.number].totalTime = totalTime;
    that.setData({
      list: that.data.list
    });
  },
  //输入总工时
  bindtotalTime: function bindtotalTime(e) {
    var that = this;
    var temp = that.data.list;
    temp[parseInt(e.currentTarget.dataset.input)].totalTime = e.detail.value;
    that.setData({
      list: temp
    });
  },
  //输入总工资
  bindtotalWage: function bindtotalWage(e) {
    var that = this;
    var temp = that.data.list;
    temp[parseInt(e.currentTarget.dataset.input)].totalWage = e.detail.value;
    that.setData({
      list: temp
    });
  },
  buttonsave1: function buttonsave1() {
    var that = this;
    if (!that.data.departmentId) {
      wx.showModal({
        title: '提示信息',
        content: '请补全数据！',
        showCancel: false
      });
      return;
    }
    for (var key in that.data.list) {
      if (!that.data.list[key].numberOfWork || !that.data.list[key].overTime) {
        wx.showModal({
          title: '提示信息',
          content: '请补全数据！',
          showCancel: false
        });
        return;
      }
    }
    var path = that.data.state != "130008010" ? app.globalData.url + "/api/services/Wage/LaborHour/CreateWithItems" : app.globalData.url + "/api/services/Wage/LaborHour/UpdateWithItems";
    var obj = {
      id: that.data.id,
      department: that.data.departmentId,
      state: "130008005",
      creatorUserId: app.globalData.information.id,
      date: that.data.date,
      items: that.data.list
    };
    that.data.state != "130008010" ? delete obj["id"] : obj;
    util.request(path, obj, 'POST').then(function(res) {
      if (res.success) {
        that.setData({
          entityList: res.result,
          LaborHour: res.result.id,
          rejectOpen: true,
          open: false
        });
        console.log(that.data.entityList);
        wx.showModal({
          title: '提示信息',
          content: "保存成功，请点击发起审核！",
          showCancel: false
        });
      }
    }, function(error) {
      wx.showModal({
        title: '提示信息',
        content: error.error.message,
        showCancel: false
      });
    });
  },
  reject: function reject() {
    var that = this;
    var path = app.globalData.url + "/api/services/WorkFlow/WFTemplate/GetWFTemplateByType";
    var obj = {
      Type: "160205008",
      Param: "",
      organizationUnitId: that.data.departmentId,
      pageSize: 2000
    }; //app.globalData.information.organizationUnitId, pageSize: 2000 }
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      that.setData({
        workFlowTemp: res.result
      });
      if (res.result.id) {
        var path = app.globalData.url + "/api/services/WorkFlow/WorkFlow/Create";
        var obj = {
          name: that.data.department + "发起一笔工时申报，请审核",
          moduleName: "Wage",
          wfTempID: that.data.workFlowTemp.id,
          fkID: that.data.LaborHour,
          fkType: "LaborHour",
          startIndex: "1",
          data: JSON.stringify({
            id: that.data.LaborHour,
            fkType: "LaborHour"
          }),
          entity: that.data.entityList
        };
        util.request(path, obj, "POST").then(function(res) {
          if (res.success) {
            wx.switchTab({
              url: '/pages/ucenter/work/work'
            });
            return;
          }
        }, function(error) {
          wx.showModal({
            title: '错误信息',
            content: error.error.message,
            showCancel: false
          });
        });
      }
    });
  }
});