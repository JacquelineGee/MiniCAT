var util = require('../../../utils/util.js');
var api = require('../../../config/api.js');
var user = require('../../../utils/cache/user.js');
var app = getApp();
var obj = {};
var flag = true;
var pageindex = 1;
var pagesize = 100;
var data;
var userData = false;
var num = 1;
var totalCount;
Page({
  data: {
    scrollTop: 0,
    lastScrollTop: 0,
    lastScrollTop2: 0,
    winWidth: 0,
    winHeight: 0,
    scrollHeight: 0,
    totalCount: 0,
    totalscore: 0,
    kpiUserId: 0,
    // tab切换  
    currentTab: 0,
    organizationUnitId: "",
    userInformation: "",
    date: "",
    getState: "",
    getName: "",
    userName: "",
    loading: "",
    userId: "",
    startTime: "",
    open: [],
    movies1: [],
    movies2: [],
    url_img: app.globalData.url + "/File/Image?FileName="
  },
  onLoad: function onLoad(options) {
    var that = this;
    var time = that.FormatMonth();
    if (that.data.startTime == "") {
      that.setData({
        startTime: time,
        movies2: [{
          content: "",
          id: "",
          score: 0,
          score1: 0,
          state: "",
          userId: 0
        }, {
          content: "",
          id: "",
          score: 0,
          score1: 0,
          state: "",
          userId: 0
        }, {
          content: "",
          id: "",
          score: 0,
          score1: 0,
          state: "",
          userId: 0
        }, {
          content: "",
          id: "",
          score: 0,
          score1: 0,
          state: "",
          userId: 0
        }, {
          content: "",
          id: "",
          score: 0,
          score1: 0,
          state: "",
          userId: 0
        }, {
          content: "",
          id: "",
          score: 0,
          score1: 0,
          state: "",
          userId: 0
        }, {
          content: "",
          id: "",
          score: 0,
          score1: 0,
          state: "",
          userId: 0
        }, {
          content: "",
          id: "",
          score: 0,
          score1: 0,
          state: "",
          userId: 0
        }, {
          content: "",
          id: "",
          score: 0,
          score1: 0,
          state: "",
          userId: 0
        }, {
          content: "",
          id: "",
          score: 0,
          score1: 0,
          state: "",
          userId: 0
        }],
        userName: user.getNameById(app.globalData.information.id),
        userId: app.globalData.information.id,
        organizationUnitId: user.getOUIdById(app.globalData.information.id)
      });
    }
    that.setData({
      userInformation: ""
    });
    if (options.id) {
      that.setData({
        loading: user.getNameById(app.globalData.information.id),
        userInformation: user.getNameById(app.globalData.information.id),
        kpiUserId: options.kpiUserId
      });
      userData = true;
      var obj = {
        codeDataTypeId: options.id,
        userId: app.globalData.information.id,
        name: that.data.userInformation,
        date: that.data.startTime + "-01 00:00:00.0000000"
      };
      that.get(obj);
    }
  },
  onShow: function onShow(options) {
    var that = this;
    that.setData({
      userInformation: ""
    });
    wx.getSystemInfo({
      success: function success(res) {
        if (res) {
          if (res.windowWidth) that.setData({
            winWidth: res.windowWidth
          });
          if (res.winHeight) that.setData({
            winWidth: res.winHeight
          });
          if (res.windowHeight) that.setData({
            scrollHeight: res.windowHeight
          });
        }
      }
    });
  },
  select: function select(e) {
    var that = this;
    var i = e.currentTarget.dataset.index;
    var path = app.globalData.url + "/api/services/Salary/KpiManage/Create";
    var obj = {
      name: user.getNameById(that.data.kpiUserId) ? user.getNameById(that.data.kpiUserId) : "",
      content: that.data.movies2[i].description,
      userId: that.data.kpiUserId,
      creatorUserId: app.globalData.information.id,
      date: that.data.startTime,
      organizationUnitId: that.data.organizationUnitId,
      score: parseInt(that.data.movies2[i].value),
      score1: 0,
      completionStatus: that.data.completionStatus ? that.data.completionStatus : ""
    };
    util.request(path, obj).then(function(res) {
      if (res.success) {
        that.data.movies2[i].isSystem = 1;
        //that.data.movies2.splice(i, 1);
        that.setData({
          kpiId: res.result.id,
          movies2: that.data.movies2
        });
        wx.showModal({
          title: '提示信息',
          content: "选择成功！",
          showCancel: false
        });
      }
    }, function(error) {
      wx.showModal({
        title: '错误信息',
        content: error.error.message,
        showCancel: false
      });
    });
  },
  FormatMonth: function FormatMonth() {
    var date = new Date();
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    m = m < 10 ? '0' + m : m;
    return y + "-" + m;
  },
  datePicker: function datePicker(e) {
    this.setData({
      startTime: e.detail.value
    });
    var obj = {
      userId: this.data.userId,
      name: this.data.userInformation,
      date: this.data.startTime + "-01 00:00:00.0000000"
    };
    this.get(obj);
  },
  //页面滑动到底部
  bindDownLoad: function bindDownLoad(e) {
    var that = this;
    if (flag) {
      flag = false;
      pageindex++;
      var count = parseInt(totalCount) % pagesize == 0 ? parseInt(totalCount) / pagesize : Math.floor(parseInt(totalCount) / pagesize);
      if (pageindex > count + 1) {
        return;
      }
      if (userData == true) {
        that.get();
      } else {
        that.get();
      }
    }
  },
  scroll: function scroll(event) {
    //该方法绑定了页面滚动时的事件，我这里记录了当前的position.y的值,为了请求数据之后把页面定位到这里来。
    var scroll = event.detail.scrollTop;
    var that = this;
    this.setData({
      lastScrollTop2: that.data.lastScrollTop,
      lastScrollTop: scroll
    });
  },
  //获取输入的用户信息
  input: function input(e) {
    var that = this;
    this.setData({
      userInformation: e.detail.value
    });
  },
  //根据用户信息查询数据
  get: function get(data) {
    var that = this;
    if (data != null) {
      that.setData({
        codeDataTypeId: data.codeDataTypeId
      });
    }
    console.log(data.codeDataTypeId);
    console.log(that.data.codeDataTypeId);
    var path = app.globalData.url + "/api/services/CodeData/CodeData/GetAll";
    var obj = {
      searchGroup: {
        op: 1,
        rules: [{
          field: "CodeDataTypeId",
          value: data.codeDataTypeId,
          op: 3
        }, {
          field: "IsShow",
          value: true,
          op: 3
        }]
      },
      sorting: "Sort ASC",
      pageSize: pagesize,
      pageIndex: pageindex
    };
    util.request(path, obj, "GET").then(function(res) {
      flag = true;
      totalCount = res.result.totalCount;
      if (res.success && res.result.items.length > 0) {
        var sumscore = 0;
        for (var i = 0; i < res.result.items.length; i++) {
          var item = res.result.items[i];
          sumscore = sumscore + item.value;
        }
        that.setData({
          movies2: res.result.items,
          totalscore: sumscore
        });
      }
      wx.hideToast();
    }, function(err) {
      flag = true;
      wx.hideToast();
    }, function(com) {
      wx.hideToast();
    });
  }
});