var _createForOfIteratorHelper2 = require("../../../@babel/runtime/helpers/createForOfIteratorHelper");
var util = require('../../../utils/util.js');
var api = require('../../../config/api.js');
var usercache = require('../../../utils/cache/user.js');
var department = require('../../../utils/cache/department.js');
var app = getApp();
var totalCount;
var data;
var flag = true;
var pageindex = 1;
var pagesize = 100;
Page({
  data: {
    scrollTop: 0,
    winWidth: 0,
    winHeight: 0,
    lastScrollTop: 0,
    // tab切换  
    currentTab: 0,
    movies: [],
    movies1: [],
    movies2: [],
    movies3: []
  },
  onShow: function onShow() {
    var that = this;
    var userConfiguration = wx.getStorageSync('userConfiguration');
    if (userConfiguration["Finace/Receipt/Create"] == 'true') {
      that.setData({
        open: true
      });
    } else {
      that.setData({
        open: false
      });
    }
    wx.getSystemInfo({
      success: function success(res) {
        if (res) {
          if (res.windowWidth) that.setData({
            winWidth: res.windowWidth
          });
          if (res.winHeight) that.setData({
            winHeight: res.winHeight
          });
          if (res.windowHeight) that.setData({
            scrollHeight: res.windowHeight
          });
        }
      }
    });
    that.LoadData("130008015", 0);
  },
  //页面滑动到底部
  bindDownLoad: function bindDownLoad(e) {
    var that = this;
    if (flag) {
      flag = false;
      pageindex++;
      var count = parseInt(totalCount) % pagesize == 0 ? parseInt(totalCount) / pagesize : Math.floor(parseInt(totalCount) / pagesize);
      if (pageindex > count + 1) {
        return;
      }
      that.LoadData(data);
    }
  },
  scroll: function scroll(event) {
    //该方法绑定了页面滚动时的事件，我这里记录了当前的position.y的值,为了请求数据之后把页面定位到这里来。
    var scroll = event.detail.scrollTop;
    var that = this;
    this.setData({
      lastScrollTop: scroll
    });
  },
  /** 
   * 点击tab切换 
   */
  swichNav: function swichNav(e) {
    var that = this;
    pageindex = 1;
    that.setData({
      movies: [],
      movies1: [],
      movies2: [],
      movies3: []
    });
    var current = e.target.dataset.current;
    //var data = current == "0" ? "130008005" : current == "1" ? "130008015" : current == "2" ? "130008020" : "130008010"
    data = current == "0" ? "130008015" : current == "1" ? "130008020" : "130008010";
    if (data == "130008020") {
      pagesize = 10;
    } else {
      pagesize = 100;
    }
    that.setData({
      currentTab: e.target.dataset.current
    });
    that.LoadData(data, 0);
  },
  LoadData: function LoadData(data) {
    var that = this;
    wx.showLoading({
      icon: "loading",
      title: "正在加载......",
      mask: true
    });
    var path = app.globalData.url + "/api/services/Finace/ReceiptOrder/GetAll";
    var obj = {
      searchGroup: {
        op: 1,
        rules: [{
          field: "State",
          value: data,
          op: 3
        }, {
          field: "FkType",
          value: "ReceiptOrder",
          op: 3
        }, data == "130008010" ? {
          field: "CreatorUserId",
          value: app.globalData.information.id,
          op: 3
        } : ""]
      },
      sorting: "CreationTime DESC",
      pageSize: pagesize,
      pageIndex: pageindex
    };
    util.request(path, obj, "GET").then(function(res) {
      var items = res.result.items;
      flag = true;
      totalCount = res.result.totalCount;
      var _iterator = _createForOfIteratorHelper2(items),
        _step;
      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var item = _step.value;
          item.creatorUserId = usercache.getNameById(item.creatorUserId);
          item.department = department.getNameById(item.department);
        }
      } catch (err) {
        err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
      if (res.success) {
        if (data == "130008005") {
          that.setData({
            movies: res.result.items
          });
        } else if (data == "130008015") {
          that.setData({
            movies1: res.result.items
          });
        } else if (data == "130008020") {
          var list = that.data.movies2;
          var isRemove = false;
          for (var i = 0; i < res.result.items.length; i++) {
            var item = res.result.items[i];
            list.push(item);
          }
          that.setData({
            movies2: list
          });
        } else if (data == "130008010") {
          that.setData({
            movies3: res.result.items
          });
        }
        //console.log("movies2:"+that.data.movies1[0].organizationUnitId);
        //console.log("movies2:"+that.data.movies1[0].name);
      }

      wx.hideLoading();
    }, function(err) {
      flag = true;
      wx.hideToast();
    }, function(com) {
      flag = true;
      wx.hideToast();
    });
  }
});