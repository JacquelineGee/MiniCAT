//获取应用实例  
var app = getApp();
var util = require('../../utils/util.js');
Page({
  data: {
    show: "",
    isShown: false,
    movie: [],
    gradeManageId: "",
    winWidth: 0
  },
  onShow: function onShow() {
    var that = this;
    var path = app.globalData.url + "/api/services/Notification/Notification/GetUserNotifications";
    var obj = {
      State: 0,
      MaxResultCount: 2000,
      SkipCount: 0
    };
    var path = util.getQueryUrl(path, obj);
    util.request(path).then(function(res) {
      that.setData({
        movie: res.result.items
      });
    });
    wx.getSystemInfo({
      success: function success(res) {
        that.setData({
          winWidth: res.windowWidth
        });
      }
    });
  },
  btn: function btn(e) {
    var that = this;
    if (e.currentTarget.dataset.notificationname == "WorkFlowNotify") {
      var path = app.globalData.url + "/api/services/Score/GradeManage/GetAll";
      var obj = {
        searchGroup: {
          rules: [{
            field: "lastWorkFlowId",
            value: e.currentTarget.dataset.id
          }]
        }
      };
      var Get = util.getQueryUrl(path, obj);
      util.request(Get).then(function(res) {
        if (res.success) {
          that.setData({
            gradeManageId: res.result.items[0].id
          });
          wx.navigateTo({
            url: '/pages/ucenter/gradeManagestate/gradeManagestate?id=' + that.data.gradeManageId
          });
        }
      });
    } else if (e.currentTarget.dataset.notificationname == "Score.SentTeamJoinRequestNotification") {
      wx.navigateTo({
        url: '/pages/ucenter/team/team?id=' + e.currentTarget.dataset.id
      });
    }
    var path = app.globalData.url + "/api/services/Notification/Notification/SetNotificationAsRead";
    var obj = {
      id: e.currentTarget.dataset.index
    };
    util.request(path, obj).then(function(res) {});
  }
});