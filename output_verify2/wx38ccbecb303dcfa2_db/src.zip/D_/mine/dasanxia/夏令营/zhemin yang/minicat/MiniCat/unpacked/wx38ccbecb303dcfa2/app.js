var _createForOfIteratorHelper2 = require("./@babel/runtime/helpers/createForOfIteratorHelper");
var util = require('./utils/util.js');
var api = require('./config/api.js');
var user = require('./services/user.js');
App({
  onLaunch: function onLaunch() {
    var _this = this;
    user.loginByWeixin();
    //获取用户的登录信息
    user.checkLogin().then(function(res) {
      _this.globalData.userInfo = wx.getStorageSync('userInfo');
      _this.globalData.token = wx.getStorageSync('token');
    }).catch(function() {});
    this.timeTask();
  },
  showTabBar: function showTabBar(sum) {
    var msg = "";
    if (sum > 0) {
      wx.setTabBarBadge({
        index: 1,
        text: '' + sum + ''
      });
    } else {
      wx.removeTabBarBadge({
        index: 1 //否则移除徽章
      });
    }
  },

  getNotification: function getNotification() {
    var that = this;
    var path = that.globalData.url + "/api/services/Foundation/Notification/GetUserNotifications";
    var obj = {
      state: 0,
      maxResultCount: 200
    };
    util.request(path, obj, "GET").then(function(res) {
      var totalCount = 0;
      var taskCount = 0;
      if (res.success && res.result.items.length > 0) {
        var _iterator = _createForOfIteratorHelper2(res.result.items),
          _step;
        try {
          for (_iterator.s(); !(_step = _iterator.n()).done;) {
            var item = _step.value;
            if (item.notification.notificationName == 'Score.TaskNotification') {
              totalCount++;
              taskCount++;
            }
            if (item.notification.notificationName == 'WorkFlowNotify' || item.notification.notificationName == 'Score.ReadingShare') {
              totalCount++;
            }
          }
        } catch (err) {
          err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
          _iterator.e(err);
        } finally {
          _iterator.f();
        }
        that.globalData.notificationsum = totalCount;
        that.globalData.notificationtasksum = taskCount;
        //console.log("超时通知信息："+taskCount);   
      }
    });
  },

  timeTask: function timeTask() {
    var that = this;
    that.getNotification();
    var selectCode = setInterval(function() {
      that.getNotification();
      var msg = "";
      if (that.globalData.notificationtasksum > 0) {
        msg = "您有" + that.globalData.notificationtasksum + "条任务超时，需要尽快处理！";
        wx.showToast({
          title: msg,
          icon: 'none',
          duration: 2000
        });
      }
    }, 300000); //定时间隔时间 这里是300秒
  },

  getCurrentUser: function getCurrentUser(callback) {
    var that = this;
    wx.getStorageSync('authorization');
    var post = that.globalData.url + "/AbpUserConfiguration/GetAll";
    util.request(post).then(function(res) {
      if (res.success) {
        that.globalData.abp = res.result;
        wx.setStorageSync("userConfiguration", res.result.auth.grantedPermissions);
      }
    });
    post = that.globalData.url + "/api/services/Foundation/Session/GetCurrentLoginInformations";
    util.request(post).then(function(res) {
      if (res.result.user != null) {
        that.globalData.information = {
          id: res.result.user.id,
          organizationUnitId: res.result.user.organizationUnitId
        };
      }
      if (callback) {
        callback();
        return;
      };
    }, function(error) {
      if (callback) callback();
      wx.showModal({
        title: '错误信息',
        content: error.error.message,
        showCancel: false
      });
    });
  },
  getUserInfo: function getUserInfo(cb) {
    var that = this;
    wx.login({
      success: function success(result) {
        if (result.code) {
          var url = that.globalData.url + "/api/services/Member/MemberInfo/GetWeChatOpenId";
          var data = {
            code: result.code
          };
          var GetData = util.getQueryUrl(url, data);
          util.request(GetData).then(function(res) {
            var json = JSON.parse(res.result);
            var obj = {};
            obj.openid = json.openid;
            obj.expires_in = Date.now() + json.expires_in;
            obj.session_key = json.session_key;
            wx.setStorageSync('user', obj); //存储openid  
          });
        }

        wx.getUserInfo({
          success: function success(res) {
            that.globalData.userInfo = res.userInfo;
            typeof cb == "function" && cb(that.globalData.userInfo);
          }
        });
      }
    });
  },
  globalData: {
    information: {},
    accessToken: "",
    notificationsum: 0,
    notificationtasksum: 0,
    notificationtime: 30000,
    userInfo: {
      nickName: 'Hi,游客',
      avatarUrl: 'http://yanxuan.nosdn.127.net/8945ae63d940cc42406c3f67019c5cb6.png'
    },
    token: '',
    //url: "http://localhost:5000"
    //url: "http://localhost:62114"
    url: "https://cloud.sinpedo.com"
    //url: "https://amb.soft1349.com"
    //url: "http://106.13.235.25:3389"
    //url: "https://pay.sinpedo.com"
    //url: "https://erp.sinpedo.com"
  },

  cache: {
    users: [],
    department: [],
    account: [],
    paymentMode: [],
    unit: [],
    clearingMode: []
  }
});