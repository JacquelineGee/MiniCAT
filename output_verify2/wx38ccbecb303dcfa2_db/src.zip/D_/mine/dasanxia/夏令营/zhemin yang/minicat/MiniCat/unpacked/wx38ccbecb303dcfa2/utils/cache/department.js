var util = require('../util.js');
var app = getApp();
var department;

function init() {
  if (app.cache.department) department = app.cache.department;
  if (!department || department.length == 0) {
    var url = util.getQueryUrl(app.globalData.url + "/api/services/Foundation/OrganizationUnit/GetOrganizationUnits", {
      MaxResultCount: 2000,
      pageSize: 2000
    });
    util.request(url).then(function(res) {
      if (res.success) {
        department = res.result.items;
        app.cache.department = department;
      }
    }, function(error) {
      wx.showModal({
        title: '错误信息',
        content: error.error.message,
        showCancel: false
      });
    });
  }
}

function getNameById(uid) {
  var data = getdepartmentById(uid);
  if (!data || data == null) return uid + "";
  return data.displayName;
}

function getdepartmentById(uid) {
  department = app.cache.department;
  return department ? department.find(function(x) {
    return x.id == uid;
  }) : null;
}
module.exports = {
  getdepartmentById: getdepartmentById,
  getNameById: getNameById,
  init: init
};