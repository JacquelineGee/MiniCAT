var app = getApp();
var WxParse = require('../../../lib/wxParse/wxParse.js');
var util = require('../../../utils/Test.js');
Page({
  data: {
    items: []
  },
  onLoad: function onLoad(res) {
    var that = this;
    util.Init(function(data) {
      WxParse.wxParse('data', 'html', data, that);
    });
  },
  click: function click() {
    wx.chooseImage({
      count: 1,
      // 默认9  
      sizeType: ['original', 'compressed'],
      // 可以指定是原图还是压缩图，默认二者都有  
      sourceType: ['album', 'camera'],
      // 可以指定来源是相册还是相机，默认二者都有  
      success: function success(res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片  
        console.log(res.tempFilePaths);
      }
    });
  }
});