var _createForOfIteratorHelper2 = require("../../../@babel/runtime/helpers/createForOfIteratorHelper");
var _defineProperty2 = require("../../../@babel/runtime/helpers/defineProperty");
var util = require('../../../utils/util.js');
var user = require('../../../utils/cache/user.js');
var department = require('../../../utils/cache/department.js');
var paymentMode = require('../../../utils/cache/paymentMode.js');
var clearingMode = require('../../../utils/cache/clearingMode.js');
var account = require('../../../utils/cache/account.js');
var unit = require('../../../utils/cache/unit.js');
var app = getApp();
var tempList;
var item = {
  "salesName": "",
  "buyerName": "",
  "accountingsubjects": "",
  "productName": "",
  "productId": "",
  "unit": "",
  "count": "",
  "price": "",
  "amount": "",
  "dateItem": "",
  "remark": "",
  hiddensubjects: true,
  hidden: true
};
var productId;
var price;
Page({
  data: {
    path: app.globalData.url,
    sales: "",
    buyer: "",
    salesManager: "",
    buyerManager: "",
    date: "",
    pay: "",
    payId: "",
    id: "",
    InsiderTradingId: "",
    name: "",
    no: "",
    unit: "",
    count: "",
    clearingModeId: "",
    clearingModeName: "",
    InsiderTrading: "",
    productInformation: "",
    productTypeId: "",
    totalAmount: "",
    cycleDistribution: "",
    distributionId: "",
    distributionName: "",
    account: "",
    accountId: "",
    productTypeName: "-请选择分类-",
    paymentModes: [],
    clearingModes: [],
    AccountingSubject: [],
    workFlowTemp: [],
    product: [],
    items: [],
    ProductTypeList: [],
    distribution: [],
    openSave: true,
    openCalculate: true,
    rejectOpen: false,
    open: true,
    nocancel: true,
    hiddensales: true,
    hiddenbuyer: true,
    hiddenpay: true,
    distributionHidden: true,
    hiddenclearingMode: true,
    accountHidden: true,
    hidden_loading: true,
    state: "",
    entityList: {}
  },
  confirm: function confirm() {
    var that = this;
    that.setData({
      hiddensales: true,
      hiddenbuyer: true,
      hiddenpay: true,
      accountHidden: true,
      distributionHidden: true,
      hiddenclearingMode: true
    });
  },
  confirms: function confirms(e) {
    var that = this;
    var temp = that.data.items;
    temp[parseInt(e.currentTarget.dataset.data)].hidden = true;
    temp[parseInt(e.currentTarget.dataset.data)].hiddensubjects = true;
    that.setData({
      items: temp
    });
  },
  onLoad: function onLoad(options) {
    var that = this;
    that.InitData();
    that.setData({
      isAllowChangeProductPrice: app.globalData.abp && app.globalData.abp.setting.values["Score.IsAllowChangeProductPrice"] == "true"
    });
    var path = app.globalData.url + "/api/services/Finace/Distribution/GetAll";
    var obj = {
      MaxResultCount: 2000,
      pageSize: 2000
    };
    util.request(path, obj).then(function(res) {
      that.setData({
        distribution: res.result.items
      });
    });
    if (options.id) {
      that.setData({
        state: options.state,
        InsiderTradingId: options.id,
        hidden_loading: false
      });
      that.LoadData(options.id);
      return;
    }
    var time = that.FormatTime();
    that.setData({
      date: time
    });
    that.Add();
  },
  //处理驳回的数据
  LoadData: function LoadData(id) {
    var that = this;
    var path = app.globalData.url + "/api/services/Sales/InsiderTrading/GetInsiderTradingById";
    var obj = {
      id: id
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      var time = that.FormatTime(res.result.date);
      var temp = res.result.items;
      for (var i = 0; i < res.result.items.length; i++) {
        temp[i]["hiddensubjects"] = true;
        temp[i]["hidden"] = true;
        temp[i]["name"] = account.getNameById(res.result.items[i].accountingsubjects);
        temp[i].unit = res.result.items[i].unit;
        temp[i].unitName = unit.getNameById(res.result.items[i].unit);
      }
      that.setData({
        salesName: department.getNameById(res.result.output),
        sales: res.result.output,
        no: res.result.no,
        buyerName: department.getNameById(res.result.input),
        buyer: res.result.input,
        pay: paymentMode.getNameById(res.result.paymentMode),
        payId: res.result.paymentMode,
        date: time,
        items: temp,
        clearingModeName: clearingMode.getNameById(res.result.clearingMode),
        clearingModeId: res.result.clearingMode,
        hidden_loading: true
      });
    }, function(err) {
      that.setData({
        hidden_loading: true
      });
    });
  },
  //时间格式
  FormatTime: function FormatTime(time) {
    var date = time ? new Date(time) : new Date();
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    m = m < 10 ? '0' + m : m;
    var d = date.getDate();
    d = d < 10 ? '0' + d : d;
    return y + "-" + m + "-" + d;
  },
  //销售方
  sales: function sales(e) {
    var that = this;
    this.setData({
      hiddensales: false
    });
  },
  salesone: function salesone(e) {
    var that = this;
    if (e.currentTarget.dataset.id == that.data.buyer) {
      wx.showModal({
        title: '提示信息',
        content: '部门不能相同~~',
        showCancel: false
      });
      return;
    }
    that.setData({
      hiddensales: true,
      sales: e.currentTarget.dataset.id,
      salesName: e.currentTarget.dataset.index,
      salesManager: e.currentTarget.dataset.manager
    });
  },
  //付款方式
  Payment: function Payment() {
    var that = this;
    that.setData({
      hiddenpay: false
    });
  },
  Payone: function Payone(e) {
    var that = this;
    console.log(e);
    that.setData({
      hiddenpay: true,
      pay: e.currentTarget.dataset.index,
      payId: e.currentTarget.dataset.id
    });
  },
  //采购方
  buyer: function buyer(e) {
    var that = this;
    that.setData({
      hiddenbuyer: false
    });
  },
  buyerone: function buyerone(e) {
    var that = this;
    if (e.currentTarget.dataset.id == that.data.sales) {
      wx.showModal({
        title: '提示信息',
        content: '部门不能相同~~',
        showCancel: false
      });
      return;
    }
    that.setData({
      hiddenbuyer: true,
      buyer: e.currentTarget.dataset.id,
      buyerName: e.currentTarget.dataset.index,
      buyerManager: e.currentTarget.dataset.manager
    });
  },
  //选择日期
  datePickers: function datePickers(e) {
    var that = this;
    that.setData({
      date: e.detail.value
    });
  },
  //交易方式
  change: function change(e) {
    var that = this;
    that.setData({
      hiddenclearingMode: false
    });
  },
  changeone: function changeone(e) {
    var that = this;
    that.setData({
      hiddenclearingMode: true,
      clearingModeId: e.currentTarget.dataset.id,
      clearingModeName: e.currentTarget.dataset.index
    });
  },
  //总金额
  totalAmount: function totalAmount(e) {
    this.setData({
      totalAmount: e.detail.value
    });
  },
  //分摊周期
  cycleDistribution: function cycleDistribution(e) {
    this.setData({
      cycleDistribution: e.detail.value
    });
  },
  //分摊方式
  distributionChange: function distributionChange(e) {
    var that = this;
    that.setData({
      distributionHidden: false
    });
  },
  distribution: function distribution(e) {
    var that = this;
    this.setData({
      distributionHidden: true,
      distributionName: e.currentTarget.dataset.name,
      distributionId: e.currentTarget.dataset.id
    });
  },
  //表头会计科目
  accountChange: function accountChange(e) {
    var that = this;
    that.setData({
      accountHidden: false
    });
  },
  account: function account(e) {
    var that = this;
    that.setData({
      accountHidden: true,
      account: e.currentTarget.dataset.name,
      accountId: e.currentTarget.dataset.id
    });
  },
  //初始化数据
  InitData: function InitData() {
    var that = this;
    //销售方 
    var path = app.globalData.url + "/api/services/Foundation/OrganizationUnit/GetOrganizationUnits";
    var obj = {
      MaxResultCount: 2000,
      pageSize: 2000
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      that.setData({
        movies: res.result.items
      });
    });

    //付款方式
    var path = app.globalData.url + "/api/services/CodeData/CodeData/GetAll";
    var obj = {
      searchGroup: {
        rules: [{
          field: "codeDataTypeId",
          value: 130009
        }]
      },
      pageSize: 2000
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      that.setData({
        paymentModes: res.result.items
      });
    });
    //付款方式
    var path = app.globalData.url + "/api/services/CodeData/CodeData/GetAll";
    var obj = {
      searchGroup: {
        rules: [{
          field: "codeDataTypeId",
          value: 200013
        }]
      },
      pageSize: 2000
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      that.setData({
        clearingModes: res.result.items
      });
    });
    //会记科目
    var path = app.globalData.url + "/api/services/Finace/AccountingSubject/GetAll";
    var obj = {
      MaxResultCount: 2000,
      pageSize: 2000
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      that.setData({
        accountingSubject: res.result.items
      });
    });
    //产品名称
    var path = app.globalData.url + "/api/services/Product/Product/GetAll";
    var obj = {
      MaxResultCount: 2000,
      pageSize: 2000
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      that.setData({
        product: res.result.items
      });
    });
  },
  //会计科目
  AccountingSubject: function AccountingSubject(e) {
    var that = this;
    var temp = that.data.items;
    temp[parseInt(e.currentTarget.dataset.data)].hiddensubjects = false;
    that.setData({
      items: temp
    });
  },
  Subjectone: function Subjectone(e) {
    var that = this;
    var temp = that.data.items;
    temp[parseInt(e.currentTarget.dataset.data)].accountingsubjects = e.currentTarget.dataset.id;
    temp[parseInt(e.currentTarget.dataset.data)].name = e.currentTarget.dataset.index;
    temp[parseInt(e.currentTarget.dataset.data)].hiddensubjects = true;
    that.setData({
      items: temp
    });
  },
  //产品名称
  Product: function Product(e) {
    var that = this;
    var temp = that.data.items;
    temp[parseInt(e.currentTarget.dataset.data)].hidden = false;
    that.setData({
      items: temp
    });
  },
  Productone: function Productone(e) {
    var that = this;
    var temp = that.data.items;
    var i = parseInt(e.currentTarget.dataset.index);

    /*temp[parseInt(e.currentTarget.dataset.data)].productName = that.data.product[i].name;
    temp[parseInt(e.currentTarget.dataset.data)].unit = that.data.product[i].unit;
    temp[parseInt(e.currentTarget.dataset.data)].unitName = unit.getNameById(that.data.product[i].unit);
    temp[parseInt(e.currentTarget.dataset.data)].productId = that.data.product[i].id;
    temp[parseInt(e.currentTarget.dataset.data)].price = that.data.product[i].costPrice;
    temp[parseInt(e.currentTarget.dataset.data)].oldPrice = that.data.product[i].costPrice;
    //productId = that.data.product[i].id;
    temp[parseInt(e.currentTarget.dataset.data)].count = "";
    temp[parseInt(e.currentTarget.dataset.data)].amount = "";
    temp[parseInt(e.currentTarget.dataset.data)].hidden = true;
    temp[parseInt(e.currentTarget.dataset.data)].model=that.data.product[i].model;*/
    var product = new Object();
    product.productName = that.data.product[i].name;
    product.unit = that.data.product[i].unit;
    product.unitName = unit.getNameById(that.data.product[i].unit);
    product.productId = that.data.product[i].id;
    product.price = that.data.product[i].costPrice;
    product.oldPrice = that.data.product[i].costPrice;
    product.count = "";
    product.amount = "";
    product.hidden = true;
    product.hiddensubjects = true;
    product.model = that.data.product[i].model;
    temp[parseInt(e.currentTarget.dataset.data)] = product;
    temp[parseInt(e.currentTarget.dataset.data)].hidden = true;
    that.setData({
      items: temp
    });
  },
  //选择产品分类
  ProductType: function ProductType() {
    this.setData({
      openuser: !this.data.openuser
    });
    var that = this;
    var path = app.globalData.url + "/api/services/Product/ProductType/GetAll";
    var obj = {
      MaxResultCount: 2000,
      pageSize: 2000
    };
    util.request(path, obj, "Get").then(function(res) {
      that.setData({
        ProductTypeList: res.result.items
      });
    });
  },
  ProductTypeone: function ProductTypeone(e) {
    this.setData({
      productTypeName: e.currentTarget.dataset.index,
      productTypeId: e.currentTarget.dataset.id,
      openuser: !this.data.openuser
    });
    this.getproduct();
  },
  //数量
  bindCount: function bindCount(e) {
    var that = this;
    var temp = that.data.items;
    var reg = new RegExp("^-?[0-9]*.?[0-9]*$");
    if (!reg.test(e.detail.value)) {
      wx.showModal({
        title: '错误信息',
        content: '请输入数字',
        showCancel: false
      });
    } else {
      temp[parseInt(e.currentTarget.dataset.data)].count = e.detail.value;
      that.setData({
        items: temp
      });
    }
  },
  //单价
  bindPrice: function bindPrice(e) {
    var that = this;
    var temp = that.data.items;
    temp[parseInt(e.currentTarget.dataset.data)].price = e.detail.value;
    that.setData({
      items: temp
    });
  },
  //数量
  bindRemark: function bindRemark(e) {
    var that = this;
    var temp = that.data.items;
    temp[parseInt(e.currentTarget.dataset.data)].remark = e.detail.value;
    that.setData({
      items: temp
    });
  },
  //新增
  Add: function Add() {
    var that = this;
    var temp = that.data.items;
    temp.unshift(item);
    that.setData({
      items: temp
    });
  },
  //删除 
  Del: function Del(e) {
    var that = this;
    wx.showModal({
      title: '提示信息',
      content: '你确定要删除吗',
      showCancel: true,
      success: function success(res) {
        if (res.confirm) {
          var temp = that.data.items;
          temp.splice(parseInt(e.currentTarget.dataset.data), 1);
          that.setData({
            items: temp
          });
        }
      }
    });
  },
  //计算
  calculate: function calculate(e) {
    var that = this;
    that.setData({
      openSave: false
    });
    var path = app.globalData.url + "/api/services/Product/PriceSetting/ProductPriceInput";
    var items = [];
    var data = {};
    for (var p = 0; p < that.data.items.length; p++) {
      var tempprice = "";
      if (that.data.isAllowChangeProductPrice) {
        if (app.globalData.abp && app.globalData.abp.setting.values["Score.ProductPriceScope"]) {
          var ProductPriceScope = app.globalData.abp.setting.values["Score.ProductPriceScope"].split(',');
          var priceDiff = that.data.items[p].price - that.data.items[p].oldPrice;
          if (priceDiff < 0) {
            var percent = (0 - priceDiff) * 100 / that.data.items[p].oldPrice;
            if (percent > parseFloat(ProductPriceScope[0])) {
              wx.showModal({
                title: '提示信息',
                content: '产品[' + that.data.items[p].productName + ']价格修改过低，超过了允许的最低比例:' + ProductPriceScope[0] + "%",
                showCancel: false
              });
              return;
            } else {
              tempprice = that.data.items[p].price;
            }
          } else {
            var percent = (priceDiff + that.data.items[p].oldPrice) * 100 / that.data.items[p].oldPrice;
            if (percent > parseFloat(ProductPriceScope[1])) {
              wx.showModal({
                title: '提示信息',
                content: '产品[' + that.data.items[p].productName + ']价格修改过高，超过了允许的最高比例:' + ProductPriceScope[1] + "%",
                showCancel: false
              });
              return;
            } else {
              tempprice = that.data.items[p].price;
            }
          }
        }
      } else {
        tempprice = that.data.items[p].oldPrice;
      }
      var item = {};
      item["productId"] = that.data.items[p].productId;
      item["productName"] = that.data.items[p].productName;
      item["unit"] = that.data.items[p].unit;
      item["price"] = tempprice;
      item["count"] = that.data.items[p].count;
      item["remark"] = that.data.items[p].remark;
      item["model"] = that.data.items[p].model;
      items.push(item);
    }
    data["isSalePrice"] = false;
    data["input"] = that.data.buyer;
    data["output"] = that.data.sales;
    data["items"] = items;
    util.request(path, data).then(function(res) {
      var temp = that.data.items;
      for (var p = 0; p < that.data.items.length; p++) {
        that.data.items[p].price = res.result[p].price;
        that.data.items[p].amount = res.result[p].amount;
        var price = that.data.items[p].price;
        var amount = that.data.items[p].amount;
        temp[p].price = price;
        temp[p].amount = amount;
        that.setData({
          items: temp
        });
      }
    }, function(error) {
      wx.showModal({
        title: '错误信息',
        content: error.error.message,
        showCancel: false
      });
    });
  },
  //分摊
  buttonsave: function buttonsave() {
    var that = this;
    that.setData({
      isAllowChangeProductPrice: false,
      openCalculate: false
    });
    var path = app.globalData.url + "/api/services/Finace/PayOrder/AutomaticDistribution";
    var obj = {
      totalAmount: that.data.totalAmount,
      date: that.data.date,
      cycleDistribution: that.data.cycleDistribution,
      distributionId: that.data.distributionId ? that.data.distributionId : null,
      account: that.data.accountId,
      department: that.data.buyer ? that.data.buyer : null
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      var temp = that.data.items;
      for (var p = 0; p < res.result.length; p++) {
        res.result[p].sales = res.result[p].department;
        res.result[p].salesName = department.getNameById(res.result[p].department);
        res.result[p].buyer = that.data.buyer;
        res.result[p].buyerName = department.getNameById(that.data.buyer);
        res.result[p].accountingsubjects = that.data.accountId;
        res.result[p].name = that.data.account;
        res.result[p].unitName = "";
        res.result[p].productName = "";
        res.result[p].price = 0;
        res.result[p].count = 0;
        res.result[p].hiddensubjects = true;
        res.result[p].hidden = true;
        temp.unshift(res.result[p]);
      }
      that.setData({
        items: temp
      });
    }, function(error) {
      wx.showModal({
        title: '错误信息',
        content: error.error.message,
        showCancel: false
      });
    });
  },
  //获取输入的产品信息
  inputproduct: function inputproduct(e) {
    var that = this;
    this.setData({
      productInformation: e.detail.value
    });
  },
  //根据产品信息查询数据
  getproduct: function getproduct() {
    var that = this;
    var path = app.globalData.url + "/api/services/Product/Product/GetProduct";
    var obj = {};
    if (that.data.productInformation == null || that.data.productInformation == "" || that.data.productInformation == undefined) {
      obj = {
        searchGroup: {
          rules: [{
            field: "productTypeId",
            value: that.data.productTypeId
          }]
        },
        sorting: "sort asc",
        pageSize: 200
      };
    } else {
      obj = {
        filter: that.data.productInformation,
        sorting: "sort asc",
        pageSize: 200
      };
    }
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      that.setData({
        product: res.result.items
      });
    });
  },
  //获取输入的会计科目
  inputaccountingsubject: function inputaccountingsubject(e) {
    var that = this;
    this.setData({
      accountingsubjectInformation: e.detail.value
    });
  },
  //根据获取的信息查询数据
  getaccountingsubject: function getaccountingsubject() {
    var that = this;
    var path = app.globalData.url + "/api/services/Finace/AccountingSubject/GetAll";
    var obj = {};
    if (that.data.accountingsubjectInformation == null || that.data.accountingsubjectInformation == "" || that.data.accountingsubjectInformation == undefined) {
      obj = {
        searchGroup: {
          rules: [{
            field: "id",
            value: that.data.id
          }]
        },
        sorting: "sort asc",
        pageSize: 200
      };
    } else {
      obj = {
        filter: that.data.accountingsubjectInformation,
        sorting: "sort asc",
        pageSize: 200
      };
    }
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      that.setData({
        accountingSubject: res.result.items
      });
    });
  },
  //提交数据
  buttonsave1: function buttonsave1() {
    var that = this;
    for (var i = 0; i < that.data.items.length; i++) {
      if (that.data.items[i].name == "" || that.data.items[i].name == null || that.data.items[i].name == undefined) {
        wx.showModal({
          title: '提示信息',
          content: '请选择科目',
          showCancel: false
        });
        return;
      }
    }
    if (that.data.items.length < 1) {
      wx.showModal({
        title: '提示信息',
        content: '请增加明细！！！'
      });
      return;
    }
    // if (!that.data.sales || !that.data.buyer || !that.data.payId || !that.data.clearingModeId) {
    //   wx.showModal({
    //     title: '提示信息',
    //     content: '请补全数据',
    //     showCancel: false
    //   });
    //   return;
    // }
    // for (var i = 0; i < that.data.items.length; i++) {
    //   // if (!that.data.items[i].accountingsubjects || !that.data.items[i].productName || !that.data.items[i].count) {
    //   //   wx.showModal({
    //   //     title: '提示信息',
    //   //     content: '请补全数据',
    //   //     showCancel: false
    //   //   });
    //   //   return;
    //   // }
    //   if (that.data.isAllowChangeProductPrice) {
    //     if (app.globalData.abp && app.globalData.abp.setting.values["Score.ProductPriceScope"]) {
    //       var ProductPriceScope = app.globalData.abp.setting.values["Score.ProductPriceScope"].split(',');
    //       var priceDiff = that.data.items[i].price - that.data.items[i].oldPrice;
    //       if (priceDiff < 0) {
    //         var percent = (0 - priceDiff) * 100 / that.data.items[i].oldPrice;
    //         if (percent > parseFloat(ProductPriceScope[0])) {
    //           wx.showModal({
    //             title: '提示信息',
    //             content: '产品[' + that.data.items[i].productName + ']价格修改过低，超过了允许的最低比例:' + ProductPriceScope[0] + "%",
    //             showCancel: false
    //           });
    //           return;
    //         }
    //       }
    //       else {
    //         var percent = (priceDiff) * 100 / that.data.items[i].oldPrice;
    //         if (percent > parseFloat(ProductPriceScope[1])) {
    //           wx.showModal({
    //             title: '提示信息',
    //             content: '产品[' + that.data.items[i].productName + ']价格修改过高，超过了允许的最高比例:' + ProductPriceScope[1] + "%",
    //             showCancel: false
    //           });
    //           return;
    //         }
    //       }
    //     }
    //   }

    // }
    var path = that.data.state != "130008010" ? app.globalData.url + "/api/services/Sales/InsiderTrading/CreateWithItems" : app.globalData.url + "/api/services/Sales/InsiderTrading/UpdateWithItems";
    var obj = {
      id: that.data.InsiderTradingId,
      output: that.data.sales,
      input: that.data.buyer,
      creatorUserId: app.globalData.information.id,
      state: "130008005",
      no: that.data.no,
      paymentMode: that.data.payId,
      date: that.data.date,
      totalAmount: that.data.totalAmount,
      cycleDistribution: that.data.cycleDistribution,
      distributionId: that.data.distributionId ? that.data.distributionId : null,
      clearingMode: that.data.clearingModeId,
      isInsiderTrading: true,
      items: that.data.items
    };
    that.data.state != "130008010" ? delete obj["id"] && delete obj["state"] : obj;
    util.request(path, obj, "POST").then(function(res) {
      if (res.success) {
        that.setData({
          entityList: res.result,
          InsiderTrading: res.result.id,
          rejectOpen: true,
          open: false
        });
        wx.showModal({
          title: '提示信息',
          content: "保存成功，请点击申请审批！",
          showCancel: false
        });
      }
    }, function(error) {
      wx.showModal({
        title: '错误信息',
        content: error.error.message,
        showCancel: false
      });
    });
  },
  reject: function reject() {
    var that = this;
    that.setData({
      rejectOpen: false
    });
    var path = app.globalData.url + "/api/services/WorkFlow/WFTemplate/GetWFTemplateByType";
    var obj = {
      Type: "160205007",
      Param: "InsiderTradingManage",
      organizationUnitId: app.globalData.information.organizationUnitId,
      pageSize: 2000
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      that.setData({
        workFlowTemp: res.result
      });
      if (res.result.id) {
        var path = app.globalData.url + "/api/services/WorkFlow/WorkFlow/Create";
        var obj = _defineProperty2({
          name: that.data.salesName + "与" + that.data.buyerName + "发起一笔内部交易，请审核",
          moduleName: "Sales",
          entity: that.data.entityList,
          wfTempID: that.data.workFlowTemp.id,
          fkID: that.data.InsiderTrading,
          fkType: "InsiderTrading",
          startIndex: "1",
          necessaryApprover: {
            "Sale": that.data.salesManager == null ? "" : that.data.salesManager.toString(),
            "Buy": that.data.buyerManager == null ? "" : that.data.buyerManager.toString()
          },
          data: JSON.stringify({
            id: that.data.InsiderTrading,
            fkType: "InsiderTrading"
          })
        }, "entity", that.data.entityList);
        if (!obj.necessaryApprover.Sale) {
          var _iterator = _createForOfIteratorHelper2(app.cache.department),
            _step;
          try {
            for (_iterator.s(); !(_step = _iterator.n()).done;) {
              var item = _step.value;
              if (item.id == that.data.sales) {
                obj.necessaryApprover.Sale = item.manager;
                break;
              }
            }
          } catch (err) {
            err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
            _iterator.e(err);
          } finally {
            _iterator.f();
          }
        }
        if (!obj.necessaryApprover.Buy) {
          var _iterator2 = _createForOfIteratorHelper2(app.cache.department),
            _step2;
          try {
            for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
              var item = _step2.value;
              if (item.id == that.data.buyer) {
                obj.necessaryApprover.Buy = item.manager;
                break;
              }
            }
          } catch (err) {
            err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
            _iterator2.e(err);
          } finally {
            _iterator2.f();
          }
        }
        util.request(path, obj, "POST").then(function(res) {
          if (res.success) {
            wx.switchTab({
              url: '/pages/ucenter/work/work'
            });
            return;
          }
        }, function(error) {
          that.setData({
            rejectOpen: true
          });
          wx.showModal({
            title: '错误信息',
            content: error.error.message,
            showCancel: false
          });
        });
      }
    });
  }
});