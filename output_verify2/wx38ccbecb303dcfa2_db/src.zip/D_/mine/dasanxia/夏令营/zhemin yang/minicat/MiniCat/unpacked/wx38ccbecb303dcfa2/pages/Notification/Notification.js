var _createForOfIteratorHelper2 = require("../../@babel/runtime/helpers/createForOfIteratorHelper");
var util = require('../../utils/util.js');
var api = require('../../config/api.js');
var user = require('../../utils/cache/user.js');
var app = getApp();
var obj = {};
var flag = true;
var pageindex = 1;
var pagesize = 100;
var data;
var userData = false;
var num = 1;
var totalCount;
Page({
  data: {
    scrollTop: 0,
    lastScrollTop: 0,
    lastScrollTop2: 0,
    winWidth: 0,
    winHeight: 0,
    scrollHeight: 0,
    totalCount: 0,
    // tab切换  
    currentTab: 0,
    userInformation: "",
    getState: "",
    getName: "",
    loading: "",
    movies: [],
    movies_1: [],
    movies1: [],
    movies1_1: [],
    movies2: [],
    movies2_1: [],
    url_img: app.globalData.url + "/File/Image?FileName=",
    setInter: ''
  },
  onLoad: function onLoad(options) {
    var that = this;
    that.setData({
      userInformation: ""
    });
    if (options.name) {
      that.setData({
        loading: options.name,
        userInformation: options.name,
        currentTab: 0
      });
      userData = true;
      this.get(options);
      return;
    }
  },
  onShow: function onShow(options) {
    var that = this;
    app.showTabBar(app.globalData.notificationsum);
    that.data.setInter = setInterval(function() {
      app.showTabBar(app.globalData.notificationsum);
    }, app.globalData.notificationtime);
    that.setData({
      userInformation: ""
    });

    // if (app.globalData.information.id)
    wx.getSystemInfo({
      success: function success(res) {
        if (res) {
          if (res.windowWidth) that.setData({
            winWidth: res.windowWidth
          });
          if (res.winHeight) that.setData({
            winWidth: res.winHeight
          });
          if (res.windowHeight) that.setData({
            scrollHeight: res.windowHeight
          });
        }
      }
    });
    if (that.data.loading == "") {
      that.LoadData("130008010");
    }
  },
  swichNav: function swichNav(e) {
    var that = this;
    pageindex = 1;
    that.setData({
      movies: [],
      movies1: [],
      movies2: [],
      movies_1: [],
      movies1_1: [],
      movies2_1: []
    });
    var current = e.target.dataset.current;
    that.setData({
      currentTab: e.target.dataset.current
    });
    that.LoadData(data, 0);
  },
  //页面滑动到底部
  bindDownLoad: function bindDownLoad(e) {
    var that = this;
    if (flag) {
      flag = false;
      pageindex++;
      var count = parseInt(totalCount) % pagesize == 0 ? parseInt(totalCount) / pagesize : Math.floor(parseInt(totalCount) / pagesize);
      if (pageindex > count + 1) {
        //flag = true
        // wx.showModal({
        //   title: '提示信息',
        //   content: '下拉数据加载完毕！！',
        //   showCancel: false
        // })
        return;
      }
      if (userData == true) {
        that.get();
      } else {
        that.LoadData(data);
      }
    }
  },
  scroll: function scroll(event) {
    //该方法绑定了页面滚动时的事件，我这里记录了当前的position.y的值,为了请求数据之后把页面定位到这里来。
    var scroll = event.detail.scrollTop;
    var that = this;
    this.setData({
      lastScrollTop2: that.data.lastScrollTop,
      lastScrollTop: scroll
    });
  },
  //确认消息，以后不再关联任务
  read: function read(data) {
    var that = this;
    //console.log(data.currentTarget.dataset.id);
    var path = app.globalData.url + "/api/services/Foundation/Notification/SetNotificationAsRead";
    obj = {
      id: data.currentTarget.dataset.id
    };
    util.request(path, obj).then(function(res) {
      if (res.success) {
        wx.showModal({
          title: '提示信息',
          content: "通知信息已确认处理，不再关联！",
          showCancel: false
        });
        that.LoadData();
        app.globalData.notificationsum--;
        app.showTabBar(app.globalData.notificationsum);
        return;
      }
      //res = "";
    }, function(error) {
      wx.showModal({
        title: '错误信息',
        content: error.error.message,
        showCancel: false
      });
    });
  },
  LoadData: function LoadData(data) {
    var _this = this;
    var that = this;
    wx.showToast({
      icon: "loading",
      title: "正在加载......",
      duration: 3000
    });
    that.setData({
      movies: [],
      movies1: [],
      movies2: [],
      movies_1: [],
      movies1_1: [],
      movies2_1: []
    });
    var path = app.globalData.url + "/api/services/Foundation/Notification/GetUserNotifications";
    obj = {
      state: 0,
      maxResultCount: 200
    };
    util.request(path, obj, "GET").then(function(res) {
      flag = true;
      totalCount = res.result.totalCount;
      if (res.success && res.result.items.length > 0) {
        var _iterator = _createForOfIteratorHelper2(res.result.items),
          _step;
        try {
          for (_iterator.s(); !(_step = _iterator.n()).done;) {
            var item = _step.value;
            if (item.notification.notificationName == 'Score.ReadingShare') {
              var str = item.notification.data.message.split(",");
              item.notification.data.message = str[0];
              item.notification.entityId = str[1];
              that.data.movies2_1.push(item);
              //console.log("点赞通知信息："+str[0]+str[1]);           
            }

            if (item.notification.notificationName == 'Score.TaskNotification') {
              var str = item.notification.data.message.split(",");
              item.notification.data.message = str[0];
              item.notification.entityId = str[1];
              that.data.movies_1.push(item);
              //console.log("超时通知信息："+item.notification.data.message);           
            }

            if (item.notification.notificationName == 'WorkFlowNotify') {
              //var str=item.notification.data.message.split(",");
              //item.notification.data.message=item.notification.data.message;
              //item.notification.entityId=str[1];
              that.data.movies1_1.push(item);
              //console.log("流程通知信息："+item.notification.data.message);           
            }
          }
        } catch (err) {
          err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
          _iterator.e(err);
        } finally {
          _iterator.f();
        }
        _this.setData({
          movies2: that.data.movies2_1,
          movies1: that.data.movies1_1,
          movies: that.data.movies_1
        });
        //console.log(that.data.movies);
        wx.hideToast();
      }
    }, function(err) {
      flag = true;
      wx.hideToast();
    }, function(com) {
      flag = true;
      wx.hideToast();
    });
  },
  onHide: function onHide() {
    // 页面隐藏
    var that = this;
    //清除计时器  即清除setInter
    clearInterval(that.data.setInter);
  },
  onUnload: function onUnload() {
    // 页面关闭
    var that = this;
    //清除计时器  即清除setInter
    clearInterval(that.data.setInter);
  }
});