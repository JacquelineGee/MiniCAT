/**
 * 页面的初始数据
 */
var app = getApp();
var WxParse = require('../../../lib/wxParse/wxParse.js');
var util = require('../../../utils/util.js');
var flag = true;
var totalCount;
var pageindex = 1;
var pagesize = 100;
Page({
  data: {
    movies: [],
    movie: [],
    open: false,
    winWidth: 0,
    winHeight: 0,
    scrollTop: 0,
    scrollHeight: 0,
    kpiUserId: 0,
    url: app.globalData.url,
    login: "",
    overView: 0,
    tenantId: ""
  },
  onLoad: function onLoad(option) {
    var that = this;
    var tenantId = wx.getStorageSync('tenantId');
    that.setData({
      tenantId: tenantId
    });
    wx.getSystemInfo({
      success: function success(res) {
        if (res) {
          if (res.windowHeight) that.setData({
            scrollHeight: res.windowHeight
          });
        }
      }
    });
    if (option.userId) {
      that.setData({
        kpiUserId: option.userId
      });
    }
    that.LoadData(that.data.overView);
  },
  getProfilePictureByUid: function getProfilePictureByUid(uid) {
    var that = this;
    var path = app.globalData.url + "/api/services/Foundation/Profile/GetProfilePictureByUid";
    var obj = {
      userId: uid.id
    };
    util.request(path, obj).then(function(res) {
      var movies = that.data.movies;
      if (res.result.profilePicture != "") {
        var profilePicture = 'data:image/jpeg;base64,' + res.result.profilePicture;
        for (var i = 0; i < movies.length; i++) {
          if (movies[i].id == uid.id) {
            movies[i].images = profilePicture;
          }
        }
      } else {}
      that.setData({
        movies: movies
      });
    });
  },
  //页面滑动到顶部
  bindTopLoad: function bindTopLoad(e) {
    var that = this;
    that.setData({
      pageIndex: 0
    });
    if (flag) {
      flag = false;
      if (pageIndex == 0) {
        return;
      } else {
        pageIndex--;
      }
      var count = parseInt(totalCount) % 100 == 0 ? parseInt(totalCount) / 100 : Math.floor(parseInt(totalCount) / 100);
      if (pageIndex < 1) {
        flag = true;
        return;
      }
      that.LoadData(0);
    }
  },
  //页面滑动到底部
  bindDownLoad: function bindDownLoad(e) {
    var that = this;
    if (flag) {
      flag = false;
      var count = parseInt(totalCount) % 100 == 0 ? parseInt(totalCount) / 100 : Math.floor(parseInt(totalCount) / 100);
      if (pageIndex == count) {
        flag = true;
        return;
      } else {
        pageIndex++;
      }
      if (pageIndex > count) {
        flag = true;
        return;
      }
      that.LoadData(0);
    }
  },
  scroll: function scroll(event) {
    //该方法绑定了页面滚动时的事件，我这里记录了当前的position.y的值,为了请求数据之后把页面定位到这里来。
    var scroll = event.detail.scrollTop;
    var that = this;
    this.setData({
      lastScrollTop2: that.data.lastScrollTop,
      lastScrollTop: scroll
    });
  },
  LoadData: function LoadData(e) {
    var that = this;
    var path = app.globalData.url + "/api/services/CodeData/CodeDataType/GetAll";
    wx.showToast({
      icon: "loading",
      title: "正在加载......"
    });
    var obj = {
      searchGroup: {
        op: 1,
        rules: [{
          field: "DataType",
          value: 40,
          op: 3
        }, {
          field: "IsShow",
          value: true,
          op: 3
        }]
      },
      sorting: "Sort ASC",
      pageSize: pagesize,
      pageIndex: pageindex
    };
    util.request(path, obj, "GET").then(function(res) {
      flag = true;
      totalCount = res.result.totalCount;
      //console.log(totalCount);
      if (res.success && res.result.items.length > 0) {
        that.setData({
          movies: res.result.items
        });
      }
      wx.hideToast();
    }, function(err) {
      flag = true;
      wx.hideToast();
    }, function(com) {
      wx.hideToast();
    });
  },
  stopSwiper: function stopSwiper() {}
});