function temporary(temporary) {
  if (temporary == "temporary") {
    if (!that.data.workFlowTemp) {
      wx.showModal({
        title: '错误信息',
        content: '未设定审批流模板，无法发起审批！',
        showCancel: false
      });
    } else {
      var path = app.globalData.url + "/api/services/WorkFlow/WorkFlow/Create";
      var obj = {
        name: "",
        wfTempID: that.data.workFlowTemp.id,
        fkID: that.data.user.id,
        fkType: "GradeManage",
        startIndex: "0",
        data: JSON.stringify({
          id: that.data.user.id,
          fkType: "GradeManage"
        })
      };
      util.request(path, obj, "POST").then(function(res) {
        if (res.success) {
          wx.navigateBack(1);
          return;
        }
      }, function(error) {
        wx.showModal({
          title: '错误信息',
          content: error.error.message,
          showCancel: false
        });
      });
    }
  } else {
    var bool = e.currentTarget.dataset.cmd == "pass" ? true : false;
    if (!bool) {
      if (!that.data.user.opinion) {
        wx.showModal({
          title: '提示信息',
          content: '请输入审核意见~~',
          showCancel: false
        });
        return;
      }
    }
    var path = app.globalData.url + "/api/services/Score/GradeManage/ChangeState";
    var obj = {
      id: that.data.user.id,
      state: "130008020",
      workFlowId: that.data.lastWorkFlowId,
      workNodeId: that.data.nodeID.id,
      workActionId: e.currentTarget.dataset.id,
      cMD: e.currentTarget.dataset.cmd,
      userId: app.globalData.information.id,
      remark: that.data.user.opinion,
      data: {
        id: that.data.user.id,
        scoreTemplateItemId: that.data.scoreTemplateItemId,
        score: that.data.totalScore == null ? that.data.gradeManagescore : that.data.totalScore,
        isSubjoinScore: that.data.checkedname,
        state: bool ? "130008020" : "130008010",
        opinion: that.data.user.opinion,
        top: that.data.topname ? "true" : "false"
      }
    };
    util.request(path, obj, "POST").then(function(res) {
      if (res.success) {
        wx.navigateBack(1);
      }
    });
  }
}

// function lastWorkFlow(lastWorkFlowId) {
//   var pathFkID = app.globalData.url + "/api/services/WorkFlow/WorkFlowNode/GetAll"
//   var objFkID = { searchGroup: { rules: [{ field: "FlowID", value: that.data.lastWorkFlowId }] }, pageSize: 2000 }
//   var GetDataFkID = util.getQueryUrl(pathFkID, objFkID);
//   util.request(GetDataFkID).then((res) => {
//     var item = res.result.items;
//     var items = item.filter(x => x.isCurrent == true)
//     if (items && items.length > 0) {
//       that.setData({
//         nodeID: items[0]
//       })
//       if (that.data.nodeID.userID == app.globalData.information.id || userConfiguration["Score/GradeManage/Approve"] == 'true') {
//         var path = app.globalData.url + "/api/services/WorkFlow/WorkFlowAction/GetAll"
//         var obj = { searchGroup: { rules: [{ field: "NodeID", value: that.data.nodeID.id }] }, pageSize: 2000 }
//         var GetData = util.getQueryUrl(path, obj);
//         util.request(GetData).then((res) => {
//           that.setData({
//             workFlowAction: res.result.items,
//             open: true
//           })
//         });
//       }
//       else {
//         that.setData({
//           open: false
//         })
//       }
//     }
//   });
// }

module.exports = {
  temporary: temporary
};