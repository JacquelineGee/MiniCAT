var _createForOfIteratorHelper2 = require("../../../@babel/runtime/helpers/createForOfIteratorHelper");
var util = require('../../../utils/util.js');
var api = require('../../../config/api.js');
var user = require('../../../utils/cache/user.js');
var department = require('../../../utils/cache/department.js');
var usercache = require('../../../utils/cache/user.js');
var app = getApp();
var totalCount;
var data;
var attendance;
var flag = true;
var pageindex = 1;
var pagesize = 100;
var innerAudioContext = wx.createInnerAudioContext();
Page({
  data: {
    scrollTop: 0,
    winWidth: 0,
    winHeight: 0,
    scrollHeight: 0,
    lastScrollTop: 0,
    displayName: "全部组",
    displayName1: "全部组",
    displayId: "",
    displayId1: "",
    openuser: false,
    // tab切换  
    currentTab: 1,
    movie: [],
    movies: [],
    movies1: [],
    movies2: [],
    noClockin: [],
    ncNum: 0,
    hiddendep: true,
    hiddendep1: true,
    nocancel: true,
    addReading: false,
    isplay: false,
    startTime: "请选择时间",
    endTime: "请选择时间",
    startTime1: "请选择时间",
    endTime1: "请选择时间",
    userName: "",
    userId: "",
    url_img: app.globalData.url + "/File/Image?FileName="
  },
  onLoad: function onLoad(option) {
    var that = this;
    wx.getSystemInfo({
      success: function success(res) {
        if (res) {
          if (res.windowHeight) that.setData({
            scrollHeight: res.windowHeight
          });
        }
      }
    });
    var userConfiguration = wx.getStorageSync('userConfiguration');
    if (userConfiguration["Score/ReadingShare/Create"] == 'true') {
      that.setData({
        addReading: true
      });
    } else {
      that.setData({
        addReading: false
      });
    }
    /*if (option.operation == "department") {
      var that = this;
      that.setData({
        displayId: option.id,
        startTime: that.data.startTime1 == "请选择时间" ? "" : that.data.startTime1,
        endTime: that.data.endTime1 == "请选择时间" ? "" : that.data.endTime1,
        operation: option.operation,
        overView: option.overView,
        currentTab: option.overView
      })
      //that.LoadData(that.data.overView)
    }
    else {  
      var that = this;
      that.setData({   
        
        overView: that.data.currentTab
      })          
    }*/
    var path = app.globalData.url + "/api/services/Foundation/OrganizationUnit/GetOrganizationUnits";
    var obj = {
      MaxResultCount: 2000,
      pageSize: 2000
    };
    util.request(path, obj, "Get").then(function(res) {
      that.setData({
        movie: res.result.items,
        departmentList: res.result.items
      });
    });
    that.setData({
      overView: that.data.currentTab
    });
    that.LoadData(that.data.overView);
  },
  onShow: function onShow() {
    var that = this;
    var time = new Date().toISOString().slice(0, 10);
    that.setData({
      userName: user.getNameById(app.globalData.information.id),
      userId: app.globalData.information.id
    });
    var userConfiguration = wx.getStorageSync('userConfiguration');
    if (userConfiguration["Score/ReadingShare/Create"] == 'true') {
      that.setData({
        open: true
      });
    } else {
      that.setData({
        open: false
      });
    }
    wx.getSystemInfo({
      success: function success(res) {
        if (res) {
          if (res.windowWidth) that.setData({
            winWidth: res.windowWidth
          });
          if (res.winHeight) that.setData({
            winHeight: res.winHeight
          });
          if (res.windowHeight) that.setData({
            scrollHeight: res.windowHeight - 130
          });
        }
      }
    });
    that.LoadData("0", 0);
  },
  //页面滑动到底部
  bindDownLoad: function bindDownLoad(e) {
    var that = this;
    if (flag) {
      flag = false;
      pageindex++;
      var count = parseInt(totalCount) % pagesize == 0 ? parseInt(totalCount) / pagesize : Math.floor(parseInt(totalCount) / pagesize);
      if (pageindex > count + 1) {
        return;
      }
      that.LoadData(data);
    }
  },
  scroll: function scroll(event) {
    //该方法绑定了页面滚动时的事件，我这里记录了当前的position.y的值,为了请求数据之后把页面定位到这里来。
    var scroll = event.detail.scrollTop;
    var that = this;
    this.setData({
      lastScrollTop: scroll
    });
  },
  /** 
   * 点击tab切换 
   */
  swichNav: function swichNav(e) {
    var that = this;
    pageindex = 1;
    that.setData({
      movies: [],
      movies1: [],
      movies2: []
    });
    var current = e.target.dataset.current;
    //data = current == "1" ?  "1" :  "2"    
    data = current == "0" ? "0" : current == "1" ? "1" : "2";
    that.setData({
      currentTab: e.target.dataset.current
    });
    that.LoadData(data, 0);
  },
  LoadData: function LoadData(data) {
    var that = this;
    /*wx.showLoading({
      icon: "loading",
      title: "正在加载......",
      mask: true   
    })*/
    var path = "";
    if (data == "0") path = app.globalData.url + "/api/services/Score/ReadingShare/GetReadingAttendanceList";
    if (data == "1") path = app.globalData.url + "/api/services/Score/ReadingShare/GetAll";
    if (data == "2") path = app.globalData.url + "/api/services/Score/ReadingShare/GetReadingListPersonal";
    if (data == "0") {
      var obj = {
        department: that.data.displayId1,
        startTime: that.data.startTime1 == "请选择时间" ? "" : that.data.startTime1,
        endTime: that.data.endTime1 == "请选择时间" ? "" : that.data.endTime1
      };
      var GetData = util.getQueryUrl(path, obj);
      util.request(GetData).then(function(res) {
        wx.hideToast();
        flag = true;
        if (res.success) {
          var list = res.result;
          var ncIds = res.result.noClockinUserIds;
          var ncnames = [];
          ncIds.forEach(function(id) {
            var uname = user.getNameById(id);
            if (uname.length > 3) {
              uname = uname.substring(0, 3);
            }
            ncnames.push(uname);
          });
          that.setData({
            attendance: list,
            //List,
            noClockin: ncnames,
            ncNum: res.result.noClockinUserIds.length
            //winHeight: res.result.items.length ? res.result.items.length * 72 : 0,          
          });
        }
      }, function(error) {
        wx.showModal({
          title: '提示信息',
          content: error.error.message,
          showCancel: false
        });
        wx.hideToast();
      }, function(com) {
        wx.hideToast();
      });
    }
    if (data == "1") {
      var obj = {
        sorting: "CreationTime DESC",
        pageSize: pagesize,
        pageIndex: pageindex
      };
      util.request(path, obj, "GET").then(function(res) {
        var items = res.result.items;
        flag = true;
        totalCount = res.result.totalCount;
        for (var item in items) {
          items[item].creatorUserId = usercache.getNameById(items[item].creatorUserId);
          items[item].name = department.getNameById(items[item].department);
        }
        //wx.hideToast();
        if (res.success) {
          var _iterator = _createForOfIteratorHelper2(res.result.items),
            _step;
          try {
            for (_iterator.s(); !(_step = _iterator.n()).done;) {
              var item = _step.value;
              if (item.content != null) {
                if (item.content.length >= 10) {
                  item.content = item.content.substring(0, 10);
                }
                item.date = item.date.substring(0, 10);
              }
            }
          } catch (err) {
            err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
            _iterator.e(err);
          } finally {
            _iterator.f();
          }
          that.setData({
            movies1: items,
            winHeight: 96 * res.result.items.length
          });
        }
        //wx.hideLoading();
      }, function(err) {
        flag = true;
        //wx.hideToast();
      }, function(com) {
        flag = true;
        //wx.hideToast();
      });
    }

    if (data == "2") {
      var obj = {
        department: that.data.displayId,
        startTime: that.data.startTime == "请选择时间" ? "" : that.data.startTime,
        endTime: that.data.endTime == "请选择时间" ? "" : that.data.endTime
      };
      var GetData = util.getQueryUrl(path, obj);
      util.request(GetData).then(function(res) {
        wx.hideToast();
        flag = true;
        totalCount = res.result.totalCount;
        var list = res.result.items;
        that.setData({
          movies2: list,
          //List,
          winHeight: res.result.items.length ? res.result.items.length * 72 : 0
        });
      }, function(error) {
        wx.showModal({
          title: '提示信息',
          content: error.error.message,
          showCancel: false
        });
        wx.hideToast();
      }, function(com) {
        wx.hideToast();
      });
    }
  },
  FormatMonth: function FormatMonth() {
    var date = new Date();
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    //m = m < 10 ? ('0' + m) : m;  
    var d = date.getDate();
    //d= d<10?('0'+m) :m; 
    //return y + "-" + m+"-"+d;
    return [y, m, d].map(formatNumber).join('-');
  },
  datePicker: function datePicker(e) {
    this.setData({
      startTime: e.detail.value
    });
  },
  stopSwiper: function stopSwiper() {},
  datePicker1: function datePicker1(e) {
    this.setData({
      startTime1: e.detail.value
    });
  },
  datePickers: function datePickers(e) {
    this.setData({
      endTime: e.detail.value
    });
  },
  datePickers1: function datePickers1(e) {
    this.setData({
      endTime1: e.detail.value
    });
  },
  /** 
   * 滑动切换tab 
   */
  bindChange: function bindChange(e) {
    var that = this;
    that.setData({
      pageIndex: 0,
      currentTab: e.detail.current,
      overView: e.detail.current,
      movies: []
    });
    that.LoadData(e.detail.current);
  },
  //部门
  bindAccountChange: function bindAccountChange(e) {
    var that = this;
    that.setData({
      hiddendep: false
    });
  },
  //部门
  bindAccountChange1: function bindAccountChange1(e) {
    var that = this;
    that.setData({
      hiddendep1: false
    });
  },
  DepartmentChange: function DepartmentChange(e) {
    var that = this;
    that.setData({
      hiddendep: true,
      displayName: e.currentTarget.dataset.name,
      displayId: e.currentTarget.dataset.index
    });
  },
  DepartmentChange1: function DepartmentChange1(e) {
    var that = this;
    that.setData({
      hiddendep1: true,
      displayName1: e.currentTarget.dataset.name,
      displayId1: e.currentTarget.dataset.index
    });
  },
  //取消弹出框
  confirm: function confirm(e) {
    var that = this;
    that.setData({
      hiddendep: true
    });
  },
  query: function query(e) {
    var that = this;
    that.LoadData("2");
  },
  query1: function query1(e) {
    var that = this;
    that.LoadData("0");
  }
});