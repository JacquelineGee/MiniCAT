var _createForOfIteratorHelper2 = require("../../../@babel/runtime/helpers/createForOfIteratorHelper");
var app = getApp();
var WxParse = require('../../../lib/wxParse/wxParse.js');
var util = require('../../../utils/util.js');
var user = require('../../../utils/cache/user.js');
Page({
  data: {
    items: [],
    name: "",
    slogan: "",
    activityName: "",
    Id: "",
    activityId: "",
    movies: [],
    movie: [],
    permission: ["管理员", "参与者"],
    userItem: [],
    tableMovies: [],
    tempId: "",
    opens: true,
    openName: true,
    remark: "",
    nocancel: true,
    switchd: false
  },
  onLoad: function onLoad(options) {
    var that = this;
    var path = app.globalData.url + "/api/services/Foundation/User/GetUsers";
    var obj = {
      Filter: "",
      Permission: "",
      Role: "",
      Sorting: "",
      MaxResultCount: 2000,
      SkipCount: 0
    };
    util.request(path, obj, "Get").then(function(res) {
      that.setData({
        movie: res.result.items
      });
    });
    that.setData({
      Id: options.id,
      activityId: options.activityId
    });
    if (options.id) {
      that.setData({
        openstates: true
      });
      var path = app.globalData.url + "/api/services/Score/Team/Get";
      var obj = {
        Id: options.id
      };
      var userConfiguration = wx.getStorageSync('userConfiguration');
      util.request(path, obj, "Get").then(function(res) {
        if (userConfiguration["Score/Team/Approve"] == 'true') {
          that.setData({
            openstate: true
          });
          if (res.result.state == '130008020') {
            that.setData({
              open: false,
              openstate: false
            });
          } else {
            that.setData({
              open: true
            });
          }
        } else {
          that.setData({
            openstate: false
          });
          if (res.result.state == '130008020') {
            that.setData({
              open: false
            });
          } else {
            that.setData({
              open: true
            });
          }
        }
        var path = app.globalData.url + "/api/services/Score/Team/GetItemsById";
        var obj = {
          Id: options.id
        };
        util.request(path, obj, "Get").then(function(res) {
          var items = res.result;
          var _iterator = _createForOfIteratorHelper2(items),
            _step;
          try {
            for (_iterator.s(); !(_step = _iterator.n()).done;) {
              var item = _step.value;
              item.userName = user.getNameById(item.userId);
            }
          } catch (err) {
            err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
            _iterator.e(err);
          } finally {
            _iterator.f();
          }
          that.setData({
            tableMovies: items
          });
        });
        that.update(options);
      });
    } else {
      that.setData({
        open: true,
        openstates: false
      });
      var path = app.globalData.url + "/api/services/Score/Activity/Get";
      var obj = {
        Id: options.activityId
      };
      util.request(path, obj, "Get").then(function(res) {
        that.setData({
          activityName: res.result.name,
          activityId: options.activityId
        });
      });
    }
  },
  confirm: function confirm(e) {
    var that = this;
    that.setData({
      openName: true
    });
  },
  save: function save() {
    var that = this;
    wx.showModal({
      title: '提示信息',
      content: '您确定要提交数据吗？',
      showCancel: true,
      success: function success(res) {
        if (res.confirm) {
          that.commen();
        }
      }
    });
  },
  commen: function commen(options) {
    var that = this;
    if (!that.data.name || !that.data.slogan || that.data.tableMovies.length <= 0) {
      wx.showModal({
        title: '提示信息',
        content: '数据没有完整！',
        showCancel: false
      });
      return;
    }
    if (that.data.Id) {
      var path = app.globalData.url + "/api/services/Score/Team/UpdateWithItems";
      var obj = {
        id: that.data.Id,
        name: that.data.name,
        slogan: that.data.slogan,
        activityId: that.data.activityId,
        activityName: that.data.activityName,
        items: that.data.tableMovies
      };
      util.request(path, obj).then(function(res) {
        if (res.success) {
          wx.switchTab({
            url: '/pages/ucenter/work/work'
          });
        }
      }, function(error) {
        wx.showModal({
          title: '错误信息',
          content: '该团队修改信息有误，请检查后重试！',
          showCancel: false
        });
      });
      return;
    } else {
      var path = app.globalData.url + "/api/services/Score/Team/CreateWithItems";
      var obj = {
        remark: that.data.remark,
        name: that.data.name,
        slogan: that.data.slogan,
        activityId: that.data.activityId,
        activityName: that.data.activityName,
        items: that.data.tableMovies
      };
      util.request(path, obj, "POST").then(function(res) {
        if (res.success) {
          wx.switchTab({
            url: '/pages/ucenter/work/work'
          });
        }
      }, function(error) {
        wx.showModal({
          title: '错误信息',
          content: '请将信息补充完整！',
          showCancel: false
        });
      });
    }
  },
  state: function state(options) {
    var that = this;
    var path = app.globalData.url + "/api/services/Score/Team/TeamState";
    var obj = {
      id: that.data.Id
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      if (res.success) {
        wx.switchTab({
          url: '/pages/ucenter/work/work'
        });
      }
    });
  },
  add: function add() {
    var that = this;
    if (that.data.movies.length > 0 && that.data.movies[0].userName == '') {
      wx.showModal({
        title: '提示信息',
        content: '请选择姓名！！',
        showCancel: false
      });
      return;
    }
    var obj;
    if (that.data.movies.length <= 0) {
      obj = {
        teamId: that.data.Id,
        userName: "",
        limits: "",
        title: "",
        calculation: false,
        userId: ""
      };
      var data = that.data.movies.push(obj);
      this.setData({
        movies: that.data.movies,
        opens: false
      });
    } else {
      for (var i = 0; i < that.data.tableMovies.length; i++) {
        if (that.data.tableMovies[i].userName == that.data.movies[0].userName) {
          wx.showModal({
            title: '提示信息',
            content: '姓名已经添加！！',
            showCancel: false
          });
          return;
        }
      }
      var temp = that.data.tableMovies;
      temp.unshift(that.data.movies[0]);
      that.setData({
        tableMovies: temp
      });
    }
  },
  userName: function userName(e) {
    this.setData({
      name: e.detail.value
    });
  },
  userslogan: function userslogan(e) {
    this.setData({
      slogan: e.detail.value
    });
  },
  useractivityName: function useractivityName(e) {
    this.setData({
      activityName: e.detail.value
    });
  },
  update: function update(options) {
    var that = this;
    var path = app.globalData.url + "/api/services/Score/Team/Get";
    var obj = {
      Id: options.id
    };
    util.request(path, obj, "Get").then(function(res) {
      that.setData({
        name: res.result.name,
        slogan: res.result.slogan,
        activityName: res.result.activityName,
        activityId: res.result.activityId,
        remark: res.result.remark
      });
    });
  },
  del: function del(e) {
    var that = this;
    wx.showModal({
      title: '提示信息',
      content: '是否要删除',
      showCancel: true,
      success: function success(res) {
        if (res.confirm) {
          var tableMovies = that.data.tableMovies;
          tableMovies.splice(e.currentTarget.dataset.index, 1);
          that.setData({
            tableMovies: tableMovies
          });
        } else {}
      }
    });
  },
  //获取姓名
  PickerName: function PickerName() {
    var that = this;
    that.setData({
      openName: false
    });
  },
  Picker: function Picker(e) {
    var that = this;
    that.setData({
      openName: true
    });
    that.data.movies[parseInt(e.currentTarget.dataset.index)].userName = e.currentTarget.dataset.value;
    that.data.movies[parseInt(e.currentTarget.dataset.index)].userId = e.currentTarget.dataset.data;
    that.setData({
      movies: that.data.movies,
      tempId: e.detail.value
    });
  },
  //获取权限
  PickerPer: function PickerPer(e) {
    var that = this;
    that.data.movies[parseInt(e.currentTarget.dataset.index)].limits = e.detail.value == '0' ? "200012001" : "200012002";
    that.setData({
      movies: that.data.movies
    });
  },
  switchd: function switchd(e) {
    var that = this;
    that.data.movies[0].calculation = e.detail.value;
    that.setData({
      movies: that.data.movies
    });
  },
  // listenCheckboxChange(e) {
  //   var that = this;
  //   that.data.movies[e.currentTarget.dataset.index].calculation = e.target.dataset.checks ? false : true;
  //   that.setData({
  //     movies: that.data.movies
  //   })
  // },
  Title: function Title(e) {
    var that = this;
    that.data.movies[e.currentTarget.dataset.index].title = e.detail.value;
    that.setData({
      movies: that.data.movies
    });
  },
  Introduce: function Introduce(e) {
    var that = this;
    that.setData({
      remark: e.detail.value
    });
  }
});