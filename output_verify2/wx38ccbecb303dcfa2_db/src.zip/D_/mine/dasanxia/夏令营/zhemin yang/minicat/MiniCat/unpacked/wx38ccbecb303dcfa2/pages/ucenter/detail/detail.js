var app = getApp();
var util = require('../../../utils/util.js');
Page({
  data: {
    motto: 'Hello World',
    userInfo: {},
    information: "",
    Industry: {}
  },
  onLoad: function onLoad(res) {
    var that = this;

    //调用应用实例的方法获取全局数据  
    app.getUserInfo(function(userInfo) {
      //更新数据  
      that.setData({
        information: userInfo
      });
    });
    var path = app.globalData.url + '/api/services/Member/MemberInfo/Get';
    var data = {
      id: app.globalData.information.id
    };
    util.request(path, data, "GET").then(function(res) {
      that.setData({
        Industry: res.result
      });
    });
  },
  changeName: function changeName() {
    wx.redirectTo({
      url: '../detail-e/detail-e'
    });
  }
});