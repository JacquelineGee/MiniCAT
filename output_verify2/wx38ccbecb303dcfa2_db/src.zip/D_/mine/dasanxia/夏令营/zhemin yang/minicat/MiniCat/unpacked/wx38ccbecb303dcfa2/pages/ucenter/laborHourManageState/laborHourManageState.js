var app = getApp();
var util = require('../../../utils/util.js');
var department = require('../../../utils/cache/department.js');
var accountcache = require('../../../utils/cache/account.js');
var paymentModecache = require('../../../utils/cache/paymentMode.js');
Page({
  data: {
    open: true,
    openstate: true,
    open1state: true,
    date: "",
    remark: "",
    state: "",
    list: {},
    laborHourId: "",
    lastWorkFlowId: "",
    nodeID: [],
    workFlowAction: []
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {
    var that = this;
    var userConfiguration = wx.getStorageSync('userConfiguration');
    that.setData({
      laborHourId: options.id
    });
    that.LoadData(options.id);
    var path = app.globalData.url + "/api/services/Wage/LaborHour/Get";
    var obj = {
      Id: options.id
    };
    var Get = util.getQueryUrl(path, obj);
    util.request(Get).then(function(res) {
      if (res.success) {
        that.setData({
          state: res.result.state,
          no: res.result.state == "130008005" || res.result.state == "130008020" || res.result.top == "1" ? true : false,
          open: res.result.state == "130008020" ? false : true,
          open1: res.result.state == "130008005" ? true : false,
          lastWorkFlowId: res.result.lastWorkFlowId
        });
      }
      if (that.data.lastWorkFlowId) {
        var pathFkID = app.globalData.url + "/api/services/WorkFlow/WorkFlowNode/GetAll";
        var objFkID = {
          searchGroup: {
            rules: [{
              field: "FlowID",
              value: that.data.lastWorkFlowId
            }]
          },
          pageSize: 2000
        };
        var GetDataFkID = util.getQueryUrl(pathFkID, objFkID);
        util.request(GetDataFkID).then(function(res) {
          var item = res.result.items;
          var items = item.filter(function(x) {
            return x.isCurrent == true;
          });
          if (items && items.length > 0) {
            that.setData({
              nodeID: items[0]
            });
            if (that.data.nodeID.userID == app.globalData.information.id || userConfiguration["Wage/LaborHour/Approve"] == 'true') {
              var path = app.globalData.url + "/api/services/WorkFlow/WorkFlowAction/GetAll";
              var obj = {
                searchGroup: {
                  rules: [{
                    field: "NodeID",
                    value: that.data.nodeID.id
                  }]
                },
                sorting: "LastModificationTime DESC",
                pageSize: 2000
              };
              var GetData = util.getQueryUrl(path, obj);
              util.request(GetData).then(function(res) {
                if (that.data.state == "130008020") {
                  that.setData({
                    open: false
                  });
                } else {
                  that.setData({
                    workFlowAction: res.result.items,
                    open: true
                  });
                }
                console.log(that.data.open);
              });
            } else {
              that.setData({
                open: false
              });
            }
          }
        });
      }
    });
    var path = app.globalData.url + "/api/services/WorkFlow/WFTemplate/GetAll";
    var obj = {
      searchGroup: {
        rules: [{
          field: "Type",
          value: "160205008"
        }]
      },
      pageSize: 999
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      that.setData({
        workFlowTemp: res.result.items[0]
      });
    });
  },
  bindopinionInput: function bindopinionInput(e) {
    var that = this;
    this.setData({
      remark: e.detail.value
    });
  },
  submit: function submit(e) {
    var that = this;
    // if (e.currentTarget.dataset.index == "temporary") {
    //   if (!that.data.workFlowTemp) {
    //     wx.showModal({
    //       title: '错误信息',
    //       content: '未设定审批流模板，无法发起审批！',
    //       showCancel: false
    //     })
    //    }
    //else {
    //   that.setData({
    //     open1state: false
    //   })
    //   var path = app.globalData.url + "/api/services/WorkFlow/WorkFlow/Create"
    //   var obj = {
    //     name: "",
    //     wfTempID: that.data.workFlowTemp.id,
    //     fkID: that.data.laborHourId,
    //     fkType: "LaborHour",
    //     startIndex: "1",
    //     userId: app.globalData.information.id,
    //     remark: that.data.remark,
    //     data: JSON.stringify({
    //       id: that.data.laborHourId,
    //       fkType: "LaborHour",
    //       remark: that.data.remark
    //     })
    //   }
    //   util.request(path, obj, "POST").then((res) => {
    //     if (res.success) {
    //       wx.navigateBack(1)
    //       return;
    //     }
    //   }, (error) => {
    //     wx.showModal({
    //       title: '错误信息',
    //       content: error.error.message,
    //       showCancel: false
    //     });
    //   })
    // }
    //} else {
    var bool = e.currentTarget.dataset.cmd == "pass" ? true : false;
    if (!bool) {
      if (!that.data.remark) {
        wx.showModal({
          title: '提示信息',
          content: '请输入审核意见~~',
          showCancel: false
        });
        return;
      }
    }
    if (that.data.openstate) {
      that.setData({
        openstate: false
      });
      var path = app.globalData.url + "/api/services/Wage/LaborHour/ChangeState";
      var obj = {
        id: that.data.laborHourId,
        state: "130008020",
        workFlowId: that.data.lastWorkFlowId,
        workNodeId: that.data.nodeID.id,
        workActionId: e.currentTarget.dataset.id,
        cMD: e.currentTarget.dataset.cmd,
        userId: app.globalData.information.id,
        remark: that.data.remark,
        data: {
          id: that.data.laborHourId,
          remark: that.data.remark,
          state: bool ? "130008020" : "130008010"
        }
      };
      util.request(path, obj, "POST").then(function(res) {
        if (res.success) {
          wx.navigateBack(1);
        }
      });
    }
    //}
  },
  // submit: function (e) {
  //   var that = this;
  //   var path = app.globalData.url +"/api/services/Wage/LaborHour/ChangeState"
  //   var state = e.currentTarget.dataset.index;
  //   var obj = { id: that.data.list.id, remark: that.data.remark, state: state }
  //   var GetData = util.getQueryUrl(path, obj);
  //   util.request(GetData).then((res) => {
  //     if (res.success) {
  //       wx.redirectTo({
  //         url: '/pages/ucenter/laborHourManage/laborHourManage',
  //       })
  //     }
  //   }, (error) => {
  //     wx.showModal({
  //       title: '提示信息',
  //       content: error.error.message,
  //       showCancel: false
  //     });
  //   })
  // },
  LoadData: function LoadData(id) {
    var that = this;
    var path = app.globalData.url + "/api/services/Wage/LaborHour/GetLaborHourFullById";
    var obj = {
      id: id
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      if (res.success) {
        res.result.name = department.getNameById(res.result.department);
        res.result.date = util.jsonreviver(res.result.date);
        that.setData({
          remark: res.result.remark,
          list: res.result
        });
      }
    }, function(error) {
      console.log(error);
    });
  }
});