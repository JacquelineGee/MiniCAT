var _createForOfIteratorHelper2 = require("../../../@babel/runtime/helpers/createForOfIteratorHelper");
var util = require('../../../utils/util.js');
var api = require('../../../config/api.js');
var user = require('../../../utils/cache/user.js');
var app = getApp();
var obj = {};
var flag = true;
var pageindex = 1;
var pagesize = 100;
var data;
var userData = false;
var num = 1;
var totalCount;
Page({
  data: {
    scrollTop: 0,
    lastScrollTop: 0,
    lastScrollTop2: 0,
    winWidth: 0,
    winHeight: 0,
    scrollHeight: 0,
    totalCount: 0,
    totalscore: 0,
    // tab切换  
    currentTab: 0,
    userInformation: "",
    date: "",
    getState: "",
    getName: "",
    userName: "",
    loading: "",
    userId: "",
    startTime: "",
    KPIScoreMax: 100,
    open: false,
    movies: [],
    movies1: [],
    movies2: [],
    movies3: [],
    movies4: [],
    url_img: app.globalData.url + "/File/Image?FileName="
  },
  onLoad: function onLoad(options) {
    var that = this;
    var time = that.FormatMonth();
    if (that.data.startTime == "") {
      that.setData({
        startTime: time,
        movies2: [{
          content: "",
          id: "",
          score: 0,
          score1: 0,
          state: "",
          userId: 0
        }, {
          content: "",
          id: "",
          score: 0,
          score1: 0,
          state: "",
          userId: 0
        }, {
          content: "",
          id: "",
          score: 0,
          score1: 0,
          state: "",
          userId: 0
        }, {
          content: "",
          id: "",
          score: 0,
          score1: 0,
          state: "",
          userId: 0
        }, {
          content: "",
          id: "",
          score: 0,
          score1: 0,
          state: "",
          userId: 0
        }, {
          content: "",
          id: "",
          score: 0,
          score1: 0,
          state: "",
          userId: 0
        }, {
          content: "",
          id: "",
          score: 0,
          score1: 0,
          state: "",
          userId: 0
        }, {
          content: "",
          id: "",
          score: 0,
          score1: 0,
          state: "",
          userId: 0
        }, {
          content: "",
          id: "",
          score: 0,
          score1: 0,
          state: "",
          userId: 0
        }, {
          content: "",
          id: "",
          score: 0,
          score1: 0,
          state: "",
          userId: 0
        }],
        userName: options.id ? user.getNameById(options.id) : user.getNameById(app.globalData.information.id),
        userId: options.id ? options.id : app.globalData.information.id
      });
    }
    length: 1;
    that.setData({
      userInformation: "",
      KPIScoreMax: app.globalData.abp && app.globalData.abp.setting.values["Salary.KPIScoreMax"] != null ? app.globalData.abp.setting.values["Salary.KPIScoreMax"] : 100
    });
    if (options.id) {
      that.setData({
        loading: user.getNameById(options.id),
        userInformation: user.getNameById(options.id)
      });
      userData = true;
      var obj = {
        userId: options.id,
        name: that.data.userInformation,
        date: that.data.startTime + "-01 00:00:00.0000000"
      };
      that.get(obj);
      //return;
    }
  },

  onShow: function onShow(options) {
    var that = this;
    that.setData({
      userInformation: ""
    });
    wx.getSystemInfo({
      success: function success(res) {
        if (res) {
          if (res.windowWidth) that.setData({
            winWidth: res.windowWidth
          });
          if (res.winHeight) that.setData({
            winWidth: res.winHeight
          });
          if (res.windowHeight) that.setData({
            scrollHeight: res.windowHeight
          });
        }
      }
    });
    if (that.data.loading == "") {
      that.LoadData("130008020", 0);
    }
  },
  create: function create(e) {
    var that = this;
    if (that.data.totalscore > that.data.KPIScoreMax) {
      wx.showModal({
        title: '提示',
        content: '您本月KPI计划总分已超过' + that.data.KPIScoreMax + '分，不能再添加KPI！',
        showCancel: false
      });
      return;
    }
    wx.showModal({
      title: '',
      content: 'KPI录入方式',
      cancelText: '手动录入',
      confirmText: '模板录入',
      success: function success(res) {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/ucenter/kpiTemplate/kpiTemplate?userId=' + that.data.userId
          });
        } else if (res.cancel) {
          wx.navigateTo({
            url: '/pages/ucenter/kpiAdd/kpiAdd?userId=' + that.data.userId
          });
        }
      }
    });
  },
  del: function del(options) {
    var that = this;
    wx.showModal({
      title: '',
      content: '请确认是否删除本条KPI?',
      success: function success(res) {
        if (res.confirm) {
          var id = options.currentTarget.dataset.id;
          var path = app.globalData.url + "/api/services/Salary/KpiManage/Delete?id=" + id;
          var obj = {};
          util.request(path, obj, "GET").then(function(res) {
            if (res.success) {
              wx.showModal({
                title: '提示',
                content: '删除成功！',
                showCancel: false
              });
              //wx.navigateBack(1);
              wx.navigateTo({
                url: '/pages/ucenter/kpiPlan/kpiPlan'
              });
              return;
            } else {
              wx.showToast({
                title: '服务器网络错误!',
                icon: 'loading',
                duration: 1500
              });
            }
          });
        }
      }
    });
  },
  withdraw: function withdraw(options) {
    var that = this;
    wx.showModal({
      title: '',
      content: '请确认是否撤回本条KPI?',
      success: function success(res) {
        if (res.confirm) {
          //var id = options.currentTarget.dataset.id; 
          var path = app.globalData.url + "/api/services/Salary/KpiManage/KPIRejected";
          var obj = {
            id: options.currentTarget.dataset.id
          };
          var GetData = util.getQueryUrl(path, obj);
          util.request(GetData).then(function(res) {
            if (res.success) {
              wx.showModal({
                title: '提示',
                content: '撤回成功！',
                showCancel: false
              });
              wx.navigateTo({
                url: '/pages/ucenter/kpiPlan/kpiPlan'
              });
              return;
            } else {
              wx.showToast({
                title: '服务器网络错误!',
                icon: 'loading',
                duration: 1500
              });
            }
          });
        }
      }
    });
  },
  FormatMonth: function FormatMonth() {
    var date = new Date();
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    m = m < 10 ? '0' + m : m;
    return y + "-" + m;
  },
  datePicker: function datePicker(e) {
    this.setData({
      startTime: e.detail.value
    });
    var obj = {
      userId: this.data.userId,
      name: this.data.userInformation,
      date: this.data.startTime + "-01 00:00:00.0000000"
    };
    this.get(obj);
  },
  //页面滑动到底部
  bindDownLoad: function bindDownLoad(e) {
    var that = this;
    if (flag) {
      flag = false;
      pageindex++;
      var count = parseInt(totalCount) % pagesize == 0 ? parseInt(totalCount) / pagesize : Math.floor(parseInt(totalCount) / pagesize);
      if (pageindex > count + 1) {
        return;
      }
      if (userData == true) {
        that.get();
      } else {
        that.LoadData(data);
      }
    }
  },
  scroll: function scroll(event) {
    //该方法绑定了页面滚动时的事件，我这里记录了当前的position.y的值,为了请求数据之后把页面定位到这里来。
    var scroll = event.detail.scrollTop;
    var that = this;
    this.setData({
      lastScrollTop2: that.data.lastScrollTop,
      lastScrollTop: scroll
    });
  },
  //获取输入的用户信息
  input: function input(e) {
    var that = this;
    this.setData({
      userInformation: e.detail.value
    });
  },
  //根据用户信息查询数据
  get: function get(data) {
    var that = this;
    if (data != null) {
      that.setData({
        getName: data.name,
        date: data.date
      });
    }
    var path = app.globalData.url + "/api/services/Salary/KpiManage/GetAll";
    var obj = {
      searchGroup: {
        op: 1,
        rules: [{
          field: "UserId",
          value: data.userId == null ? app.globalData.information.id : that.data.userId,
          op: 3
        }, {
          field: "Date",
          value: data.date == null ? that.data.startTime + "-01 00:00:00.0000000" : that.data.date,
          op: 3
        }, {
          field: "IsDeleted",
          value: false,
          op: 3
        }, {
          field: "Opinion",
          value: "task",
          op: 4
        }]
      },
      sorting: "CreationTime DESC",
      pageSize: pagesize,
      pageIndex: pageindex
    };
    util.request(path, obj, "GET").then(function(res) {
      flag = true;
      totalCount = res.result.totalCount;
      if (res.success && res.result.items.length > 0) {
        var _iterator = _createForOfIteratorHelper2(res.result.items),
          _step;
        try {
          for (_iterator.s(); !(_step = _iterator.n()).done;) {
            var item = _step.value;
            if (item.content.length >= 32) {
              item.content = item.content.substring(0, 32) + "...";
            }
          }
        } catch (err) {
          err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
          _iterator.e(err);
        } finally {
          _iterator.f();
        }
        var sumscore = 0;
        for (var i = 0; i < res.result.items.length; i++) {
          var item = res.result.items[i];
          sumscore = sumscore + item.score;
        }
        that.setData({
          movies2: res.result.items,
          totalscore: sumscore
        });
      }
      wx.hideToast();
    }, function(err) {
      flag = true;
      wx.hideToast();
    }, function(com) {
      wx.hideToast();
    });
  },
  LoadData: function LoadData(data) {
    var that = this;
    wx.showLoading({
      icon: "loading",
      title: "正在加载......",
      mask: true
    });
    var path = app.globalData.url + "/api/services/Salary/KpiManage/GetAll";
    var obj = {
      searchGroup: {
        op: 1,
        rules: [{
          field: "UserId",
          value: app.globalData.information.id,
          op: 3
        }, {
          field: "Date",
          value: data.date == null ? that.data.startTime + "-01 00:00:00.0000000" : that.data.date,
          op: 3
        }, {
          field: "Opinion",
          value: "task",
          op: 4
        }]
      },
      sorting: "CreationTime DESC",
      pageSize: pagesize,
      pageIndex: pageindex
    };
    util.request(path, obj, "GET").then(function(res) {
      totalCount = res.result.totalCount;
      if (res.success && res.result.items.length > 0) {
        var _iterator2 = _createForOfIteratorHelper2(res.result.items),
          _step2;
        try {
          for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
            var item = _step2.value;
            item.name = user.getNameById(item.userId);
            if (item.content == undefined || item.content == null) {
              item.content = "";
            } else {
              if (item.content.length >= 32) {
                item.content = item.content.substring(0, 32) + "...";
              }
            }
          }
        } catch (err) {
          err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
          _iterator2.e(err);
        } finally {
          _iterator2.f();
        }
        wx.hideToast();
        if (that.data.userInformation == "") {
          var sumscore = 0;
          for (var i = 0; i < res.result.items.length; i++) {
            var item = res.result.items[i];
            sumscore = sumscore + item.score;
          }
          that.setData({
            movies2: res.result.items,
            totalscore: sumscore
          });
        }
        if (sumscore > that.data.KPIScoreMax) {
          wx.showModal({
            title: '提示',
            content: '您本月KPI计划总分已超过' + that.data.KPIScoreMax + '分，请调整KPI的分值！',
            showCancel: false
          });
        }
      }
      wx.hideLoading();
    }, function(err) {
      flag = true;
      wx.hideToast();
    }, function(com) {
      flag = true;
      wx.hideToast();
    });
  }
});