var app = getApp();
Page({
  data: {
    username: '',
    code: ''
  },
  onLoad: function onLoad(options) {
    // 页面初始化 options为页面跳转所带来的参数
    // 页面渲染完成
  },
  onReady: function onReady() {},
  onShow: function onShow() {
    // 页面显示
  },
  onHide: function onHide() {
    // 页面隐藏
  },
  onUnload: function onUnload() {
    // 页面关闭
  },
  startLogin: function startLogin() {
    var that = this;
  },
  bindUsernameInput: function bindUsernameInput(e) {
    this.setData({
      username: e.detail.value
    });
  },
  bindCodeInput: function bindCodeInput(e) {
    this.setData({
      code: e.detail.value
    });
  },
  clearInput: function clearInput(e) {
    switch (e.currentTarget.id) {
      case 'clear-username':
        this.setData({
          username: ''
        });
        break;
      case 'clear-code':
        this.setData({
          code: ''
        });
        break;
    }
  }
});