var _createForOfIteratorHelper2 = require("../../../@babel/runtime/helpers/createForOfIteratorHelper");
// pages/ucenter/taskPlan/taskPlan.js
var util = require('../../../utils/util.js');
var api = require('../../../config/api.js');
var user = require('../../../utils/cache/user.js');
var app = getApp();
var obj = {};
var flag = true;
var pageindex = 1;
var pagesize = 100;
var data;
var userData = false;
var num = 1;
var totalCount;
Page({
  data: {
    scrollTop: 0,
    lastScrollTop: 0,
    lastScrollTop2: 0,
    winWidth: 0,
    winHeight: 0,
    scrollHeight: 0,
    totalCount: 0,
    totalscore: 0,
    hiddeintroduce: true,
    nocancel: false,
    remark: "",
    TaskManageId: "",
    organizationUnitId: 0,
    Score: 0,
    TeamId: "",
    IsSubjoinScore: false,
    State: "",
    RewardScore: 0,
    ScoreRuleId: "DFE911EA-03B4-46A9-C7D1-08D8F71CF6D4",
    ScoreTemplateItemId: "C8B96C6E-A116-4A3E-9BF8-9CE87FA1D639",
    CreatorUserId: 1,
    userInformation: "",
    date: "",
    getState: "",
    getName: "",
    userName: "",
    loading: "",
    userId: "",
    startTime: "",
    open: false,
    movies: [],
    movies1: [],
    movies2: []
  },
  onLoad: function onLoad(options) {
    var that = this;
    var time = that.FormatMonth();
    if (that.data.startTime == "") {
      that.setData({
        startTime: time,
        movies2: [{
          publishIntroduce: "",
          id: "",
          score: 0,
          name: "",
          startDate: "",
          endDate: "",
          state: "",
          userId: 0
        }, {
          publishIntroduce: "",
          id: "",
          score: 0,
          name: "",
          startDate: "",
          endDate: "",
          state: "",
          userId: 0
        }, {
          publishIntroduce: "",
          id: "",
          score: 0,
          name: "",
          startDate: "",
          endDate: "",
          state: "",
          userId: 0
        }, {
          publishIntroduce: "",
          id: "",
          score: 0,
          name: "",
          startDate: "",
          endDate: "",
          state: "",
          userId: 0
        }, {
          publishIntroduce: "",
          id: "",
          score: 0,
          name: "",
          startDate: "",
          endDate: "",
          state: "",
          userId: 0
        }, {
          publishIntroduce: "",
          id: "",
          score: 0,
          name: "",
          startDate: "",
          endDate: "",
          state: "",
          userId: 0
        }, {
          publishIntroduce: "",
          id: "",
          score: 0,
          name: "",
          startDate: "",
          endDate: "",
          state: "",
          userId: 0
        }, {
          publishIntroduce: "",
          id: "",
          score: 0,
          name: "",
          startDate: "",
          endDate: "",
          state: "",
          userId: 0
        }, {
          publishIntroduce: "",
          id: "",
          score: 0,
          name: "",
          startDate: "",
          endDate: "",
          state: "",
          userId: 0
        }, {
          publishIntroduce: "",
          id: "",
          score: 0,
          name: "",
          startDate: "",
          endDate: "",
          state: "",
          userId: 0
        }],
        userName: options.id ? user.getNameById(options.id) : user.getNameById(app.globalData.information.id),
        userId: options.id ? options.id : app.globalData.information.id
      });
    }
    var path = app.globalData.url + "/api/services/Score/RuleTemplate/GetAll";
    var obj = obj = {
      searchGroup: {
        op: 1,
        rules: [{
          field: "Name",
          value: "任务模板",
          op: 3
        }, {
          field: "IsDeleted",
          value: false,
          op: 3
        }]
      },
      pageSize: 999
    };
    var Get = util.getQueryUrl(path, obj);
    util.request(Get).then(function(res) {
      if (res.success) {
        var ruletempId = res.result.items[0].id;
        var path = app.globalData.url + "/api/services/Score/RuleTemplateItem/GetAll";
        var obj = {
          searchGroup: {
            rules: [{
              field: "RuleTemplateId",
              value: ruletempId
            }]
          },
          pageSize: 2000
        };
        var Get = util.getQueryUrl(path, obj);
        util.request(Get).then(function(res) {
          that.setData({
            ScoreRuleId: res.result.items[0].scoreRuleId
          });
        });
      }
    });
    path = app.globalData.url + "/api/services/Score/ScoreTemplate/GetAll";
    obj = obj = {
      searchGroup: {
        op: 1,
        rules: [{
          field: "Introduce",
          value: "指定任务分",
          op: 3
        }, {
          field: "IsDeleted",
          value: false,
          op: 3
        }]
      },
      pageSize: 999
    };
    var Get = util.getQueryUrl(path, obj);
    util.request(Get).then(function(res) {
      if (res.success) {
        var scoretempId = res.result.items[0].id;
        var path = app.globalData.url + "/api/services/Score/ScoreTemplateItem/GetAll";
        var obj = {
          searchGroup: {
            rules: [{
              field: "ScoreTemplateId",
              value: scoretempId
            }]
          },
          pageSize: 2000
        };
        var Get = util.getQueryUrl(path, obj);
        util.request(Get).then(function(res) {
          that.setData({
            ScoreTemplateItemId: res.result.items[0].id
          });
        });
      }
    });
    that.setData({
      PublishuserName: user.getNameById(app.globalData.information.id),
      PublishuserId: app.globalData.information.id,
      organizationUnitId: app.globalData.information.organizationUnitId,
      userInformation: ""
    });
    if (options.id) {
      that.setData({
        TaskManageId: options.id
      });
      userData = true;
      var obj = {
        id: options.id
      };
      that.get(obj);
      //return;
    }
  },

  onShow: function onShow(options) {
    var that = this;
    that.setData({
      userInformation: ""
    });
    wx.getSystemInfo({
      success: function success(res) {
        if (res) {
          if (res.windowWidth) that.setData({
            winWidth: res.windowWidth
          });
          if (res.winHeight) that.setData({
            winWidth: res.winHeight
          });
          if (res.windowHeight) that.setData({
            scrollHeight: res.windowHeight
          });
        }
      }
    });
  },
  create: function create(e) {
    var that = this;
    if (!that.data.TaskManageId == "") {
      wx.navigateTo({
        url: '/pages/ucenter/taskManage/taskManage?teamId=' + that.data.TaskManageId
      });
    } else {
      wx.showModal({
        title: '提示信息',
        content: "请先添加项目介绍信息后再添加子任务！",
        showCancel: false
      });
    }
  },
  cancel: function cancel() {
    var that = this;
    that.setData({
      hiddeintroduce: true
    });
  },
  confirm: function confirm() {
    var that = this;
    if (that.data.remark == null || that.data.remark.length == 0) {
      wx.showModal({
        title: '提示信息',
        content: "项目介绍不能为空！",
        showCancel: false
      });
      return;
    }
    that.setData({
      remark: that.data.remark || that.data.remark,
      hiddeintroduce: true
    });
    that.setData({
      open: false
    });
    var path;
    var obj;
    if (!that.data.TaskManageId == "") {
      path = app.globalData.url + "/api/services/Score/TaskManage/Update";
      obj = {
        id: that.data.TaskManageId,
        creatorUserId: that.data.CreatorUserId,
        publishUserId: app.globalData.information.id,
        publishUserName: that.data.PublishuserName,
        organizationUnitId: that.data.organizationUnitId,
        scoreRuleId: that.data.ScoreRuleId,
        scoreTemplateItemId: that.data.ScoreTemplateItemId,
        state: "130008005",
        publishintroduce: that.data.remark,
        remark: "team"
      };
    } else {
      path = app.globalData.url + "/api/services/Score/TaskManage/Create";
      obj = {
        publishUserId: app.globalData.information.id,
        publishUserName: that.data.PublishuserName,
        creatorUserId: app.globalData.information.id,
        isSubjoinScore: "true",
        state: "130008005",
        organizationUnitId: that.data.organizationUnitId,
        scoreRuleId: that.data.ScoreRuleId,
        scoreTemplateItemId: that.data.ScoreTemplateItemId,
        publishintroduce: that.data.remark,
        remark: "team"
      };
    }
    util.request(path, obj).then(function(res) {
      if (res.success) {
        that.setData({
          TaskManageId: res.result.id,
          rejectOpen: true,
          open: false
        });
        wx.showModal({
          title: '提示信息',
          content: "保存成功",
          showCancel: false
        });
      }
      //res = "";
    }, function(error) {
      wx.showModal({
        title: '错误信息',
        content: error.error.message,
        showCancel: false
      });
      that.setData({
        open: true
      });
    });
  },
  hiddeintroduce: function hiddeintroduce() {
    var that = this;
    that.setData({
      introduces: that.data.introduce,
      hiddeintroduce: false
    });
  },
  del: function del(options) {
    var that = this;
    wx.showModal({
      title: '',
      content: '请确认是否删除本条任务?',
      success: function success(res) {
        if (res.confirm) {
          var id = options.currentTarget.dataset.id;
          var path = app.globalData.url + "/api/services/Score/TaskManage/Delete?id=" + id;
          var obj = {};
          util.request(path, obj, "GET").then(function(res) {
            if (res.success) {
              wx.showModal({
                title: '提示',
                content: '删除成功！',
                showCancel: false
              });
              //wx.navigateBack(1);
              wx.navigateTo({
                url: '/pages/ucenter/taskPlan/taskPlan?id=' + that.data.TaskManageId
              });
              return;
            } else {
              wx.showToast({
                title: '服务器网络错误!',
                icon: 'loading',
                duration: 1500
              });
            }
          });
        }
      }
    });
  },
  deltask: function deltask(options) {
    var that = this;
    wx.showModal({
      title: '',
      content: '请确认是否删除本项目?',
      success: function success(res) {
        if (res.confirm) {
          if (that.data.totalscore > 0) {
            wx.showModal({
              title: '提示',
              content: '本项目已经有子任务发布，不能删除！',
              showCancel: false
            });
            return;
          } else {
            var id = that.data.TaskManageId;
            var path = app.globalData.url + "/api/services/Score/TaskManage/Delete?id=" + id;
            var obj = {};
            util.request(path, obj, "GET").then(function(res) {
              if (res.success) {
                wx.showModal({
                  title: '提示',
                  content: '删除成功！',
                  showCancel: false
                });
                wx.navigateBack(1);
                return;
              } else {
                wx.showToast({
                  title: '服务器网络错误!',
                  icon: 'loading',
                  duration: 1500
                });
              }
            });
          }
        }
      }
    });
  },
  bindremarkInput: function bindremarkInput(e) {
    var that = this;
    this.setData({
      remark: e.detail.value
    });
  },
  FormatMonth: function FormatMonth() {
    var date = new Date();
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    m = m < 10 ? '0' + m : m;
    return y + "-" + m;
  },
  get: function get(data) {
    var that = this;
    if (data != null) {
      var path = app.globalData.url + "/api/services/Score/TaskManage/Get";
      var obj = {
        Id: data.id
      };
      var Get = util.getQueryUrl(path, obj);
      util.request(Get).then(function(res) {
        if (res.success) {
          that.setData({
            PublishuserName: res.result.publishUserName,
            PublishuserId: res.result.publishuserId,
            organizationUnitId: res.result.organizationUnitId,
            TaskManageId: res.result.id,
            Score: res.result.score,
            TeamId: res.result.teamId,
            IsSubjoinScore: res.result.isSubjoinScore,
            RewardScore: res.result.rewardScore,
            ScoreRuleId: res.result.scoreRuleId,
            ScoreTemplateItemId: res.result.scoreTemplateItemId,
            State: res.result.state,
            CreatorUserId: res.result.creatorUserId,
            remark: res.result.publishIntroduce
          });
        }
      });
    }
    if (that.data.TaskManageId != "") {
      var obj = {
        id: that.data.TaskManageId
      };
      that.getTask(obj);
    }
  },
  //根据用户信息查询数据
  getTask: function getTask(data) {
    var that = this;
    if (data != null) {
      that.setData({
        getName: data.id
      });
    }
    var path = app.globalData.url + "/api/services/Score/TaskManage/GetAll";
    var obj = {
      searchGroup: {
        op: 1,
        rules: [{
          field: "TeamId",
          value: that.data.getName,
          op: 3
        }, {
          field: "IsDeleted",
          value: false,
          op: 3
        }]
      },
      sorting: "CreationTime ASC",
      pageSize: pagesize,
      pageIndex: pageindex
    };
    util.request(path, obj, "GET").then(function(res) {
      flag = true;
      var totalCount = res.result.totalCount;
      if (res.success && res.result.items.length > 0) {
        var _iterator = _createForOfIteratorHelper2(res.result.items),
          _step;
        try {
          for (_iterator.s(); !(_step = _iterator.n()).done;) {
            var item = _step.value;
            if (item.publishIntroduce.length >= 32) {
              item.publishIntroduce = item.publishIntroduce.substring(0, 32) + "...";
            }
            if (item.state == "130008020") {
              item.remark = "完成";
            } else {
              item.remark = "未完成";
            }
            if (item.name == null || item.name.length == 0) {
              item.name = "未确定";
            }
            if (item.startDate != null) {
              item.startDate = item.startDate.substring(0, 10);
            }
            if (item.endDate != null) {
              item.endDate = item.endDate.substring(0, 10);
            }
          }
        } catch (err) {
          err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
          _iterator.e(err);
        } finally {
          _iterator.f();
        }
        that.setData({
          movies2: res.result.items,
          totalscore: totalCount
        });
      }
      wx.hideToast();
    }, function(err) {
      flag = true;
      wx.hideToast();
    }, function(com) {
      wx.hideToast();
    });
  }
});