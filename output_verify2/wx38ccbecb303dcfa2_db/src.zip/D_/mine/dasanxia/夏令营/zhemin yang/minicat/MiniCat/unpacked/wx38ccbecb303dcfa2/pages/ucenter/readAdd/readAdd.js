var util = require('../../../utils/util.js');
var user = require('../../../utils/cache/user.js');
var WxParse = require('../../../lib/wxParse/wxParse.js');
var dep = require('../../../utils/cache/department.js');
var app = getApp();
var content = "";
Page({
  data: {
    checkedname: false,
    checked: false,
    hiddendep: true,
    department: "",
    departmentId: "",
    title: "",
    movie: [],
    src: "",
    srcs: "",
    path: app.globalData.url,
    userName: "",
    userId: "",
    score: 0,
    score1: 10,
    id: "",
    startTime: "",
    openscore: false,
    tab: false,
    open: false,
    hiddeintroduce: true,
    nocancel: true,
    organizationUnitId: ""
  },
  //取消弹出框
  confirm1: function confirm1(e) {
    var that = this;
    that.setData({
      hiddendep: true
    });
  },
  //部门 
  bindAccountChange: function bindAccountChange(e) {
    var that = this;
    that.setData({
      hiddendep: false
    });
  },
  DepartmentChange: function DepartmentChange(e) {
    var that = this;
    that.setData({
      hiddendep: true,
      department: e.currentTarget.dataset.name,
      departmentId: e.currentTarget.dataset.data
    });
  },
  confirm: function confirm() {
    var that = this;
    that.setData({
      content: that.data.content,
      hiddeintroduce: true
    });
  },
  hiddeintroduce: function hiddeintroduce() {
    var that = this;
    that.setData({
      introduces: that.data.introduce,
      hiddeintroduce: false
    });
  },
  //备注信息
  bindTitle: function bindTitle(e) {
    var that = this;
    that.setData({
      title: e.detail.value
    });
  },
  onLoad: function onLoad(options) {
    var that = this;
    var time = new Date().toISOString().slice(0, 10);
    that.setData({
      userName: user.getNameById(app.globalData.information.id),
      userId: app.globalData.information.id,
      startTime: options.startTime ? options.startTime : time,
      organizationUnitId: app.globalData.information.organizationUnitId
    });
    //部门  
    var path = app.globalData.url + "/api/services/Foundation/OrganizationUnit/GetOrganizationUnits";
    var obj = {
      MaxResultCount: 2000,
      pageSize: 2000
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      that.setData({
        movie: res.result.items
      });
    });
    if (options.id) {
      that.setData({
        id: options.id
      });
      that.LoadDatas(options.id);
      return;
    }
    return;
  },
  LoadDatas: function LoadDatas(id) {
    var that = this;
    var path = app.globalData.url + "/api/services/Score/ReadingContent/Get";
    var obj = {
      Id: id
    };
    var Get = util.getQueryUrl(path, obj);
    util.request(Get).then(function(res) {
      if (res.success) {
        that.setData({
          userId: res.result.userId,
          startTime: that.FormatTime(res.result.date),
          content: res.result.content,
          score: res.result.score,
          title: res.result.title,
          department: dep.getNameById(res.result.department)
        });
      }
    });
  },
  //格式时间
  FormatTime: function FormatTime(time) {
    if (time.length >= 10) {
      return time.substring(0, 10);
    } else {
      return time;
    }
  },
  FormatMonth: function FormatMonth() {
    var date = new Date();
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    m = m < 10 ? '0' + m : m;
    var d = date.getDate() + 1;
    d = d < 10 ? '0' + m : m;
    return y + "-" + m + "-" + d;
  },
  bindContentInput: function bindContentInput(e) {
    var that = this;
    that.setData({
      content: e.detail.value
    });
    if (that.data.content.length > 1) {
      that.setData({
        open: true
      });
    }
  },
  datePicker: function datePicker(e) {
    this.setData({
      startTime: e.detail.value
    });
  },
  setNum: function setNum(e) {
    //this.setData({ score: e.detail.value,});
    //console.log(e.detail.value);
  },
  prevNum: function prevNum() {
    this.setData({
      score: this.data.score + 1
    });
  },
  nextNum: function nextNum() {
    this.setData({
      score: this.data.score - 1
    });
  },
  buttonsave: function buttonsave(options) {
    var that = this;
    if (that.data.departmentId == "" || !that.data.title) {
      wx.showModal({
        title: '错误信息',
        content: '读书小组或者内容标题必须输入！',
        showCancel: false
      });
      return;
    }
    that.setData({
      open: false
    });
    var path;
    var obj;
    path = app.globalData.url + "/api/services/Score/ReadingContent/Create";
    obj = {
      content: that.data.content,
      creatorUserId: app.globalData.information.id,
      date: that.data.startTime,
      organizationUnitId: that.data.organizationUnitId,
      title: that.data.title,
      department: that.data.departmentId,
      score: that.data.score,
      sum: 0
    };
    //console.log(obj);
    util.request(path, obj).then(function(res) {
      if (res.success) {
        that.setData({
          kpiId: res.result.id
        });
        wx.showModal({
          title: '提示信息',
          content: "保存成功！",
          showCancel: false
        });
        wx.navigateBack(1);
        return;
      }
      //res = "";
    }, function(error) {
      wx.showModal({
        title: '错误信息',
        content: error.error.message,
        showCancel: false
      });
    });
  }
});