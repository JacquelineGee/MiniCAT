var util = require('../../../utils/util.js');
var user = require('../../../utils/cache/user.js');
var WxParse = require('../../../lib/wxParse/wxParse.js');
var app = getApp();
var content = "";
Page({
  data: {
    checkedname: false,
    checked: false,
    src: "",
    srcs: "",
    path: app.globalData.url,
    userName: "",
    userId: "",
    score: 0,
    score1: 10,
    id: "",
    startTime: "",
    openscore: false,
    tab: false,
    open: false,
    hiddeintroduce: true,
    hiddelike: true,
    nocancel: true,
    organizationUnitId: "",
    title: "",
    shareScore: 1,
    readingContentId: "",
    likeNames: ""
  },
  confirm: function confirm() {
    var that = this;
    that.setData({
      content: that.data.content,
      hiddeintroduce: true
    });
  },
  hiddeintroduce: function hiddeintroduce() {
    var that = this;
    that.setData({
      introduces: that.data.introduce,
      hiddeintroduce: false
    });
  },
  like: function like() {
    var that = this;
    wx.showModal({
      title: '',
      content: '是否确认点赞本条分享',
      success: function success(res) {
        if (res.confirm) {
          var user = that.data.user;
          var path = app.globalData.url + "/api/services/Score/ReadingShare/ShareLike";
          var obj = {
            id: that.data.id
          };
          var GetData = util.getQueryUrl(path, obj);
          util.request(GetData).then(function(res) {
            if (res.success) {
              wx.navigateBack(-1);
            }
          }, function(error) {
            wx.showModal({
              title: '提示信息',
              content: error.error.message,
              showCancel: false
            });
          });
        } else if (res.cancel) {
          return;
        }
      }
    });
  },
  //格式时间
  FormatDate: function FormatDate() {
    var date = new Date();
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    m = m < 10 ? '0' + m : m;
    var d = date.getDate();
    d = d < 10 ? '0' + d : d;
    return y + "-" + m + "-" + d;
  },
  onLoad: function onLoad(options) {
    var that = this;
    //var time = new Date().toISOString().slice(0, 10);   
    var time = that.FormatDate();
    that.setData({
      userName: user.getNameById(app.globalData.information.id),
      userId: app.globalData.information.id,
      startTime: options.startTime ? options.startTime : time,
      organizationUnitId: app.globalData.information.organizationUnitId,
      shareScore: app.globalData.abp.setting.values["Score.ShareScore"]
    });
    if (options.id) {
      that.setData({
        id: options.id,
        hiddelike: false
      });
      that.LoadDatas(options.id);
      return;
    }
    var path = app.globalData.url + "/api/services/Score/ClockIn/GetAll";
    var obj;
    obj = {
      searchGroup: {
        op: 1,
        rules: [{
          field: "date",
          value: that.data.startTime + " 00:00:00.0000000",
          op: 3
        }, {
          field: "userId",
          value: app.globalData.information.id
        }],
        sorting: "CreationTime DESC",
        pageSize: 1
      }
    };
    util.request(path, obj).then(function(res) {
      if (res.success && res.result.totalCount > 0) {
        that.setData({
          title: res.result.items[0].title,
          readingContentId: res.result.items[0].readingContentId
        });
      } else {
        that.setData({
          content: "请先读书打卡再分享！"
        });
      }
    });
    return;
  },
  LoadDatas: function LoadDatas(id) {
    var that = this;
    var path = app.globalData.url + "/api/services/Score/ReadingShare/Get";
    var obj = {
      Id: id
    };
    var Get = util.getQueryUrl(path, obj);
    util.request(Get).then(function(res) {
      var userName = "点赞人：";
      if (res.success) {
        if (res.result.likeUserIds != null) {
          var likeUserIds = res.result.likeUserIds.split(",");
          for (var i = 0; i < likeUserIds.length; i++) {
            userName = userName + user.getNameById(likeUserIds[i]) + ",";
          }
          userName = userName.slice(0, -2);
        }
        that.setData({
          userId: res.result.userId,
          startTime: that.FormatTime(res.result.date),
          content: res.result.content,
          shareScore: res.result.score,
          title: res.result.title,
          likeNames: userName,
          userName: res.result.name
        });
      }
    });
  },
  //格式时间
  FormatTime: function FormatTime(time) {
    if (time.length >= 10) {
      return time.substring(0, 10);
    } else {
      return time;
    }
  },
  FormatMonth: function FormatMonth() {
    var date = new Date();
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    m = m < 10 ? '0' + m : m;
    var d = date.getDate() + 1;
    d = d < 10 ? '0' + m : m;
    return y + "-" + m + "-" + d;
  },
  bindContentInput: function bindContentInput(e) {
    var that = this;
    if (that.data.title == "") {
      wx.showModal({
        title: '错误信息',
        content: '请先读书打卡后再分享',
        showCancel: false
      });
      return;
    }
    that.setData({
      content: e.detail.value
    });
    if (that.data.content.length > 1) {
      that.setData({
        open: true
      });
    }
  },
  datePicker: function datePicker(e) {
    this.setData({
      startTime: e.detail.value
    });
  },
  buttonsave: function buttonsave(options) {
    var that = this;
    if (that.data.content == "" || !that.data.startTime) {
      wx.showModal({
        title: '错误信息',
        content: '请补充完数据~~',
        showCancel: false
      });
      return;
    }
    that.setData({
      open: false
    });
    var path;
    var obj;
    path = app.globalData.url + "/api/services/Score/ReadingShare/Create";
    obj = {
      content: that.data.content,
      userId: that.data.userId,
      score: that.data.score,
      date: that.data.startTime,
      name: that.data.userName,
      department: app.globalData.information.organizationUnitId,
      readingContentId: that.data.readingContentId,
      title: that.data.title
    };
    //console.log(obj);   
    util.request(path, obj).then(function(res) {
      if (res.success) {
        that.setData({
          kpiId: res.result.id
        });
        wx.showModal({
          title: '提示信息',
          content: "保存成功！",
          showCancel: false
        });
        wx.navigateBack(1);
        return;
      }
      //res = "";
    }, function(error) {
      wx.showModal({
        title: '错误信息',
        content: error.error.message,
        showCancel: false
      });
    });
  }
});