var api = require('../../../config/api.js');
var util = require('../../../utils/util.js');
var usercache = require('../../../utils/cache/user.js');
var departmentcache = require('../../../utils/cache/department.js');
var accountcache = require('../../../utils/cache/account.js');
var paymentModecache = require('../../../utils/cache/paymentMode.js');
var clearingMode = require('../../../utils/cache/clearingMode.js');
var unit = require('../../../utils/cache/unit.js');
var app = getApp();
var tenancyName;
Page({
  data: {
    isTenantAvailable: '',
    username: '',
    password: '',
    code: '',
    loginErrorCount: 0,
    referrerId: "",
    tenancyName: ""
  },
  onLoad: function onLoad(options) {
    // var that = this;
    // that.setData({
    //   isTenantAvailable: options.tenancyName
    // })
    var that = this;
    var userName = wx.getStorageSync('userName');
    var tenancyName = wx.getStorageSync('tenancyName');
    var password = wx.getStorageSync('password');
    that.setData({
      isTenantAvailable: tenancyName,
      tenancyName: tenancyName,
      username: userName,
      password: password
    });
    if (!options.change) {
      if (that.data.username && that.data.tenancyName && that.data.password) {
        that.startLogin();
      }
    }
  },
  startLogin: function startLogin() {
    var that = this;
    wx.setStorageSync('userName', that.data.username);
    wx.setStorageSync('password', that.data.password);
    if (that.data.password.length < 1 || that.data.username.length < 1) {
      wx.showModal({
        title: '错误信息',
        content: '请输入用户名和密码',
        showCancel: false
      });
      return false;
    }
    wx.showLoading({
      icon: "loading",
      mask: true,
      title: "登录中，请稍侯......"
    });
    if (that.data.isTenantAvailable) {
      that.IsTenantAvailableNoNull();
    } else {
      that.IsTenantAvailableNull();
    }
  },
  // IsTenantAvailableNoNull() {
  //   var that = this;
  //   var post = app.globalData.url + "/api/services/Foundation/Account/IsTenantAvailable"
  //   var obj = { tenancyName: that.data.isTenantAvailable ? that.data.isTenantAvailable : null, }
  //   wx.setStorageSync('tenancyName', '')
  //   wx.setStorageSync('tenantId', '')
  //   util.request(post, obj, "POST").then((res) => {
  //     if (res.success) {
  //       wx.setStorageSync('tenancyName', that.data.isTenantAvailable);
  //       wx.setStorageSync('tenantId', res.result.tenantId);
  //       that.IsTenantAvailableNull();
  //     }
  //     else
  //       wx.hideLoading();
  //     return;
  //   })
  // },
  // IsTenantAvailableNull() {
  //   var that = this;
  //   var post = app.globalData.url + "/api/TokenAuth/Authenticate"
  //   var obj = { userNameOrEmailAddress: that.data.username ? that.data.username : null, password: that.data.password ? that.data.password : null }
  //   wx.setStorageSync('authorization', '')
  //   if (that.data.isTenantAvailable) {
  //     if (that.data.isTenantAvailable == that.data.tenancyName) {
  //       that.IsTenantAvailableNull()
  //     }
  //     else {
  //       that.IsTenantAvailableNoNull()
  //     }
  //   }
  //   else {
  //     wx.setStorageSync('tenancyName', '')
  //     wx.setStorageSync('tenantId', '')
  //     that.IsTenantAvailableNull()
  //   }
  // },
  IsTenantAvailableNoNull: function IsTenantAvailableNoNull() {
    var that = this;
    var post = app.globalData.url + "/api/services/Foundation/Account/IsTenantAvailable";
    var obj = {
      tenancyName: that.data.isTenantAvailable ? that.data.isTenantAvailable : null
    };
    //console.log(post);
    //console.log(obj);
    util.request(post, obj, "POST").then(function(res) {
      if (res.success) {
        if (res.result.state == 1) {
          wx.setStorageSync('tenancyName', that.data.isTenantAvailable);
          wx.setStorageSync('tenantId', res.result.tenantId);
          //console.log(that.data.isTenantAvailable);
          that.IsTenantAvailableNull();
        } else {
          wx.hideLoading();
          wx.showModal({
            title: '错误信息',
            content: '该租户有误，请检查！',
            showCancel: false
          });
        }
      } else {
        wx.hideLoading();
      }
      return;
    }, function(error) {
      wx.hideLoading();
      wx.showModal({
        title: '错误信息',
        content: error.error.message,
        showCancel: false
      });
    });
  },
  IsTenantAvailableNull: function IsTenantAvailableNull() {
    var that = this;
    var post = app.globalData.url + "/api/TokenAuth/Authenticate";
    var obj = {
      userNameOrEmailAddress: that.data.username ? that.data.username : null,
      password: that.data.password ? that.data.password : null
    };
    wx.setStorageSync('authorization', '');
    util.request(post, obj, "POST").then(function(res) {
      if (res.success) {
        app.getUserInfo();
        wx.setStorageSync('authorization', "Bearer " + res.result.accessToken);
        app.getCurrentUser();
        usercache.init();
        departmentcache.init();
        accountcache.init();
        paymentModecache.init();
        clearingMode.init();
        unit.init();

        //console.log("token:  "+res.result.accessToken);
        var path = app.globalData.url + "/AbpUserConfiguration/GetAll";
        var objs = {};
        if (app.globalData.information != null && app.globalData.information != "" && app.globalData.information != undefined && app.globalData.information.id == res.result.userId) {
          wx.switchTab({
            url: '/pages/ucenter/work/work'
          });
        } else {
          util.request(path, objs).then(function(ress) {
            if (res.success) {
              wx.setStorageSync("userConfiguration", ress.result.auth.grantedPermissions);
              var path = app.globalData.url + "/api/services/Foundation/Session/GetCurrentLoginInformations";
              var objs = {};
              util.request(path, objs).then(function(res) {
                if (res.success) {
                  app.globalData.information = {
                    id: res.result.user.id,
                    organizationUnitId: res.result.user.organizationUnitId
                  };
                  wx.switchTab({
                    url: '/pages/ucenter/work/work'
                  });
                  return;
                }
              });
            }
          }, function(error) {
            wx.hideLoading();
            wx.showModal({
              title: '错误信息',
              content: error.error.message,
              showCancel: false
            });
          });
        }
      } else {
        wx.hideLoading();
      }
    }, function(error) {
      wx.hideLoading();
      wx.showModal({
        title: '错误信息',
        content: error.error.message,
        showCancel: false
      });
    });
  },
  formSubmit: function formSubmit(e) {
    var that = this;
    that.setData({
      isTenantAvailable: e.detail.value["isTenantAvailable"],
      username: e.detail.value["username"],
      password: e.detail.value["password"]
    });
    that.startLogin();
  }
  // IsTenantAvailable: function (e) {
  //   var that=this;
  //   that.setData({
  //     isTenantAvailable: e.detail.value
  //   });
  //   console.log("isTenantAvailable" + that.data.isTenantAvailable)
  // },
  // bindUsernameInput: function (e) {
  //   var that = this;
  //   that.setData({
  //     username: e.detail.value
  //   });
  //   console.log("Username" + that.data.username)
  // },
  // bindPasswordInput: function (e) {
  //   var that = this;
  //   that.setData({
  //     password: e.detail.value
  //   });
  //   console.log("Password" + that.data.password)
  // },
  // bindCodeInput: function (e) {
  //   this.setData({
  //     code: e.detail.value
  //   });
  // },
});