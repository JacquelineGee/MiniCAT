var app = getApp();
var WxParse = require('../../../lib/wxParse/wxParse.js');
var util = require('../../../utils/util.js');
var department = require('../../../utils/cache/department.js');
var items;
Page({
  data: {
    movie: [],
    department: [],
    userName: [],
    displayName: "部门",
    startTime: "请选择时间",
    endTime: "请选择时间",
    displayId: "",
    winWidth: 0,
    category: ""
  },
  onLoad: function onLoad(options) {
    var that = this;
    wx.getSystemInfo({
      success: function success(res) {
        that.setData({
          winWidth: res.winWidth
        });
      }
    });
    var path = app.globalData.url + "/api/services/Finace/Report/GetBusinessReport";
    var obj = {};
    util.request(path, obj, "Get").then(function(res) {
      //console.log(res.result);
      items = JSON.parse(res.result);
      var firstItem = items[0];
      //console.log(firstItem);
      var columns = [];
      for (var key in firstItem) {
        if (key == "AccountName" || key == "Account" || key == "Total") continue;
        var parentKey = key.substr(0, key.indexOf("_"));
        var deptName = department.getNameById(parentKey);
        var tableColumn = {
          property: key,
          text: deptName
        };
        if (key.indexOf("_1") != -1) {
          tableColumn["text"] = deptName + "\n预定值";
        } else if (key.indexOf("_2") != -1) {
          tableColumn["text"] = deptName + "\n差异值";
        } else {
          tableColumn["text"] = deptName + "\n实际值";
        }
        columns.push(tableColumn);
      }
      //console.log(columns);
      that.setData({
        movie: columns,
        winWidth: 90 * columns.length
      });
      for (var i = 0; i < items.length; i++) {
        for (var key in items[i]) {
          if (key != "AccountName" && key != "Account") {
            items[i][key] = Math.round(items[i][key] * 100) / 100;
          }
        }
        if (items[i].AccountName == "总费用") {
          items[i]["skip"] = true;
          items[i]["category"] = "reportPay_Out";
        } else if (items[i].AccountName == "对外销售") {
          items[i]["skip"] = true;
          items[i]["category"] = "reportReceipt_Out";
        } else if (items[i].AccountName == "内部销售") {
          items[i]["skip"] = true;
          items[i]["category"] = "reportReceipt_In";
        } else if (items[i].AccountName == "内部采购") {
          items[i]["skip"] = true;
          items[i]["category"] = "reportPay_In";
        } else {
          items[i]["skip"] = false;
        }
      }
      that.setData({
        movies: items
      });
    }, function(error) {
      wx.showModal({
        title: '提示信息',
        content: error.error.message,
        showCancel: false
      });
    });
  },
  department: function department() {
    this.setData({
      openuser: !this.data.openuser
    });
    var that = this;
    var path = app.globalData.url + "/api/services/Foundation/OrganizationUnit/GetOrganizationUnits";
    var obj = {
      MaxResultCount: 2000,
      pageSize: 2000
    };
    util.request(path, obj, "Get").then(function(res) {
      that.setData({
        department: res.result.items
      });
    });
  },
  userone: function userone(e) {
    this.setData({
      displayName: e.currentTarget.dataset.index,
      displayId: e.currentTarget.dataset.id,
      openuser: !this.data.openuser
    });
  },
  datePicker: function datePicker(e) {
    this.setData({
      startTime: e.detail.value
    });
  },
  datePickers: function datePickers(e) {
    this.setData({
      endTime: e.detail.value
    });
  },
  create: function create(e) {
    var that = this;
    if (that.data.startTime == "请选择时间" || that.data.endTime == "请选择时间") {
      wx.showModal({
        title: '提示信息',
        content: '请补充完数据~~',
        showCancel: false
      });
      return;
    } else {
      var path = app.globalData.url + "/api/services/Finace/Report/GetBusinessReport";
      var obj = {
        ouId: that.data.displayId,
        startTime: that.data.startTime == "请选择时间" ? "" : that.data.startTime,
        endTime: that.data.endTime == "请选择时间" ? "" : that.data.endTime
      };
      util.request(path, obj, "Get").then(function(res) {
        items = JSON.parse(res.result);
        var firstItem = items[0];
        var columns = [];
        for (var key in firstItem) {
          if (key == "AccountName" || key == "Account" || key == "Total") continue;
          var parentKey = key.substr(0, key.indexOf("_"));
          var deptName = department.getNameById(parentKey);
          var tableColumn = {
            property: key,
            text: deptName
          };
          if (key.indexOf("_1") != -1) {
            tableColumn["text"] = deptName + "\n预定值";
          } else if (key.indexOf("_2") != -1) {
            tableColumn["text"] = deptName + "\n差异值";
          } else {
            tableColumn["text"] = deptName + "\n实际值";
          }
          columns.push(tableColumn);
        }
        that.setData({
          movie: columns,
          winWidth: 90 * columns.length
        });
        for (var i = 0; i < items.length; i++) {
          for (var key in items[i]) {
            if (key != "AccountName" && key != "Account") {
              items[i][key] = Math.round(items[i][key] * 100) / 100;
            }
          }
          if (items[i].AccountName == "总费用") {
            items[i]["skip"] = true;
            items[i]["category"] = "reportPay_Out";
          } else if (items[i].AccountName == "对外销售") {
            items[i]["skip"] = true;
            items[i]["category"] = "reportReceipt_Out";
          } else if (items[i].AccountName == "内部销售") {
            items[i]["skip"] = true;
            items[i]["category"] = "reportReceipt_In";
          } else if (items[i].AccountName == "内部采购") {
            items[i]["skip"] = true;
            items[i]["category"] = "reportPay_In";
          } else {
            items[i]["skip"] = false;
          }
        }
        that.setData({
          movies: items
        });
      });
    }
  }
});