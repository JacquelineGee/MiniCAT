// pages/ucenter/payOrder/payOrder.js
var app = getApp();
var WxParse = require('../../../lib/wxParse/wxParse.js');
var util = require('../../../utils/util.js');
var departmentcache = require('../../../utils/cache/department.js');
var accountcache = require('../../../utils/cache/account.js');
var paymentModecache = require('../../../utils/cache/paymentMode.js');
var array = [];
var temp;
var item = {
  "departmentName": "",
  "percent": "",
  "name": "",
  "amount": "",
  "date": "",
  "remark": "",
  accountItem: true,
  departmentItem: true
};
var Items = [];
var content = "";
Page({
  data: {
    movie: [],
    movieItem: [],
    pot: [],
    distribution: [],
    movies: [],
    moviesItem: [],
    Item: [],
    paymentModes: [],
    workFlowTemp: [],
    paymentModeName: "",
    paymentModeId: "",
    openuser: "",
    open1: "",
    path: app.globalData.url,
    startTime: "",
    startTimes: "",
    displayName: '',
    displayId: '',
    payOrderTemplateName: '',
    payOrderTemplateId: '',
    account: '',
    accountId: '',
    accountno: '',
    accounts: '',
    account1: '',
    distributionId: '',
    distributionName: '',
    totalAmount: '',
    cycleDistribution: '',
    state: "",
    no: "",
    PayOrder: "",
    payOrderId: "",
    creatorUserId: "",
    hiddendepHidden: true,
    paymentModeHidden: true,
    accountHidden: true,
    payOrderHidden: true,
    distributionHidden: true,
    nocancel: true,
    rejectOpen: false,
    open: true,
    DepartmentOnChange: true,
    openitem: [],
    entityList: {},
    date: ""
  },
  //取消弹出框
  confirm: function confirm(e) {
    var that = this;
    that.setData({
      hiddendepHidden: true,
      paymentModeHidden: true,
      distributionHidden: true,
      accountHidden: true,
      payOrderHidden: true
    });
  },
  confirms: function confirms(e) {
    var that = this;
    var item = that.data.Item;
    item[parseInt(e.currentTarget.dataset.data)].accountItem = true;
    item[parseInt(e.currentTarget.dataset.data)].departmentItem = true;
    that.setData({
      Item: item
    });
  },
  onLoad: function onLoad(options) {
    var that = this;
    that.setData({
      startTime: util.formatTime(new Date())
    });
    //判断用户权限
    // var userConfiguration = wx.getStorageSync('userConfiguration')
    // if (userConfiguration["Finace/PayOrder/AllData"] == 'true') {
    //   that.setData({
    //     DepartmentOnChange: true
    //   });
    // }
    // else {
    //   that.setData({
    //     DepartmentOnChange: false
    //   });
    // }
    var path = app.globalData.url + "/api/services/CodeData/CodeData/GetAll";
    var obj = {
      searchGroup: {
        rules: [{
          field: "codeDataTypeId",
          value: 130009
        }]
      },
      pageSize: 2000
    };
    Items = [];
    util.request(path, obj, "Get").then(function(res) {
      for (var i = 0; i < res.result.items.length; i++) {
        if (res.result.items[i].id == 130009001 || res.result.items[i].id == 130009002 || res.result.items[i].id == 130009005) {
          Items.push(res.result.items[i]);
        }
      }
      that.setData({
        paymentModes: Items
      });
    });
    var path = app.globalData.url + "/api/services/Foundation/OrganizationUnit/GetOrganizationUnits";
    var obj = {
      MaxResultCount: 2000,
      pageSize: 2000
    };
    util.request(path, obj, "Get").then(function(res) {
      that.setData({
        movie: res.result.items,
        movieItem: res.result.items
      });
    });
    var path = app.globalData.url + "/api/services/Finace/AccountingSubject/GetAll";
    var obj = {
      MaxResultCount: 2000,
      pageSize: 2000
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      that.setData({
        movies: res.result.items,
        moviesItem: res.result.items
      });
    });
    var path = app.globalData.url + "/api/services/Finace/Distribution/GetAll";
    var obj = {
      MaxResultCount: 2000,
      pageSize: 2000
    };
    util.request(path, obj).then(function(res) {
      that.setData({
        distribution: res.result.items
      });
    });
    var path = app.globalData.url + "/api/services/Foundation/Session/GetCurrentLoginInformations";
    var obj = {};
    util.request(path, obj).then(function(res) {
      if (res.success) {
        that.setData({
          department: departmentcache.getNameById(res.result.user.organizationUnitId),
          departmentId: res.result.user.organizationUnitId
        });
      }
    });
    that.Add();
    if (options.id) {
      that.setData({
        state: options.state,
        payOrderId: options.id
      });
      that.LoadDatas(options.id);
      return;
    }
  },
  LoadDatas: function LoadDatas(id) {
    var that = this;
    content = "<img class='adjunct' src='" + that.data.path + "/Files/File/Image?FileName=" + res.result.image + "'>";
    WxParse.wxParse('topicDetail', 'html', content, that);
    var path = app.globalData.url + "/api/services/Finace/PayOrder/Get";
    var obj = {
      Id: id
    };
    var Get = util.getQueryUrl(path, obj);
    util.request(Get).then(function(res) {
      that.setData({
        startTimes: res.result.date,
        creatorUserId: res.result.creatorUserId,
        no: res.result.no,
        srcs: res.result.image
      });
      if (that.data.displayName == "null") {
        var path = app.globalData.url + "/api/services/Finace/Distribution/Get";
        var obj = {
          Id: that.data.distributionId
        };
        var Get = util.getQueryUrl(path, obj);
        util.request(Get).then(function(res) {
          that.setData({
            distributionName: res.result.name
          });
        });
      }
      var path = app.globalData.url + "/api/services/Finace/PayOrderItem/GetAll";
      var obj = {
        searchGroup: {
          rules: [{
            field: "payOrderId",
            value: that.data.payOrderId
          }]
        },
        pageSize: 2000
      };
      var Get = util.getQueryUrl(path, obj);
      util.request(Get).then(function(res) {
        for (var i = 0; i < res.result.items.length; i++) {
          res.result.items[i].department = departmentcache.getNameById(res.result.items[i].department);
        }
        that.setData({
          Item: res.result.items,
          department: departmentcache.getNameById(res.result.items[0].department)
        });
      });
    });
  },
  click: function click() {
    var that = this;
    wx.chooseImage({
      count: 1,
      // 默认9  
      sizeType: ['original', 'compressed'],
      // 可以指定是原图还是压缩图，默认二者都有  
      sourceType: ['album', 'camera'],
      // 可以指定来源是相册还是相机，默认二者都有  
      success: function success(res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片  
        var tempFilePaths = res.tempFilePaths;
        that.upload(that, tempFilePaths);
      }
    });
  },
  upload: function upload(page, path) {
    wx.showToast({
      icon: "loading",
      title: "正在上传"
    }), wx.uploadFile({
      url: app.globalData.url + "/Files/File/UploadFile",
      filePath: path[0],
      name: 'file',
      header: {
        "Content-Type": "multipart/form-data"
      },
      formData: {
        //和服务器约定的token, 一般也可以放在header中
        'session_token': wx.getStorageSync('session_token')
      },
      success: function success(res) {
        var json = JSON.parse(res.data);
        if (json.success) {
          content = "<img class='adjunct' src='" + page.data.path + "/Files/File/Image?FileName=" + json.result.fileNames[0] + "'>";
          WxParse.wxParse('topicDetail', 'html', content, page);
          page.setData({
            //上传成功修改显示头像
            src: "/Files/File/Image?FileName=" + json.result.fileNames,
            srcs: json.result.fileNames[0]
          });
        } else {
          wx.showModal({
            title: '提示',
            content: '上传失败',
            showCancel: false
          });
          return;
        }
      },
      fail: function fail(e) {
        wx.showModal({
          title: '提示',
          content: '上传失败',
          showCancel: false
        });
      },
      complete: function complete() {
        wx.hideToast(); //隐藏Toast
      }
    });
  },

  //付款方式
  paymentModeChange: function paymentModeChange(e) {
    var that = this;
    that.setData({
      paymentModeHidden: false
    });
  },
  paymentMode: function paymentMode(e) {
    var that = this;
    this.setData({
      paymentModeHidden: true,
      paymentModeName: e.currentTarget.dataset.name,
      paymentModeId: e.currentTarget.dataset.id
    });
  },
  // DepartmentChange: function (e) {
  //   var that = this;
  //   that.setData({
  //     hiddendepHidden: true,
  //     department: e.currentTarget.dataset.name,
  //     departmentId: e.currentTarget.dataset.index,
  //   })
  // },
  //科目
  accountChange: function accountChange(e) {
    var that = this;
    that.setData({
      accountHidden: false
    });
  },
  account: function account(e) {
    var that = this;
    that.setData({
      accountHidden: true,
      account: e.currentTarget.dataset.name,
      accountId: e.currentTarget.dataset.id
    });
  },
  //部门
  bindAccountChange: function bindAccountChange(e) {
    var that = this;
    that.setData({
      hiddendepHidden: false
    });
  },
  DepartmentChange: function DepartmentChange(e) {
    var that = this;
    this.setData({
      hiddendepHidden: true,
      openuser: !this.data.openuser,
      department: e.currentTarget.dataset.name,
      departmentId: e.currentTarget.dataset.id,
      displayName: e.currentTarget.dataset.name,
      displayId: e.currentTarget.dataset.id
    });
    var path = app.globalData.url + "/api/services/Finace/PayOrderTemplate/GetAll";
    var obj = {
      searchGroup: {
        rules: [{
          field: "department",
          value: that.data.displayId
        }]
      },
      MaxResultCount: 2000,
      pageSize: 2000
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      that.setData({
        pot: res.result.items
      });
    });
  },
  //支出模板
  payOrderChange: function payOrderChange(e) {
    var that = this;
    that.setData({
      payOrderHidden: false
    });
  },
  payOrderTemplate: function payOrderTemplate(e) {
    var that = this;
    that.setData({
      payOrderHidden: true
    });
    if (that.data.displayName) {
      this.setData({
        payOrderTemplateName: e.currentTarget.dataset.name,
        payOrderTemplateId: e.currentTarget.dataset.id
      });
      var path = app.globalData.url + "/api/services/Finace/PayOrderTemplateItem/GetAll";
      var obj = {
        searchGroup: {
          rules: [{
            field: "payOrderTemplateId",
            value: e.currentTarget.dataset.id
          }]
        },
        MaxResultCount: 2000,
        pageSize: 2000
      };
      var GetData = util.getQueryUrl(path, obj);
      temp = that.data.Item;
      util.request(GetData).then(function(res) {
        for (var i = 0; i < res.result.items.length; i++) {
          var account = res.result.items[i].account;
          that.LoadData(account);
          if (!res.result.items[i].date) {
            res.result.items[i].date = util.formatTime(new Date());
          }
          res.result.items[i].departmentName = departmentcache.getNameById(res.result.items[i].department);
          res.result.items[parseInt(i)].accountItem = true;
          res.result.items[parseInt(i)].departmentItem = true;
          temp.unshift(res.result.items[i]);
        }
        that.setData({
          Item: temp,
          department: that.data.displayName
        });
      });
    } else {
      wx.showModal({
        title: '提示',
        content: '请先选择部门！',
        showCancel: false
      });
    }
  },
  LoadData: function LoadData(id) {
    var that = this;
    var paths = app.globalData.url + "/api/services/Finace/AccountingSubject/GetAll";
    var objs = {
      searchGroup: {
        rules: [{
          field: "id",
          value: id
        }]
      },
      MaxResultCount: 2000,
      pageSize: 2000
    };
    var GetDatas = util.getQueryUrl(paths, objs);
    array = [];
    util.request(GetDatas).then(function(res) {
      var Item = that.data.Item;
      for (var i = 0; i < res.result.items.length; i++) {
        array.push(res.result.items[i].name);
      }
      for (var i = 0; i < array.length; i++) {
        Item[i].name = array[i];
      }
      that.setData({
        Item: Item
      });
    });
  },
  //分摊方式
  distributionChange: function distributionChange(e) {
    var that = this;
    that.setData({
      distributionHidden: false
    });
  },
  distribution: function distribution(e) {
    var that = this;
    this.setData({
      distributionHidden: true,
      distributionName: e.currentTarget.dataset.name,
      distributionId: e.currentTarget.dataset.id
    });
  },
  //获取输入的会计科目
  inputaccountingsubject: function inputaccountingsubject(e) {
    var that = this;
    this.setData({
      accountingsubjectInformation: e.detail.value
    });
  },
  //根据获取的信息查询数据
  getaccountingsubject: function getaccountingsubject() {
    var that = this;
    var path = app.globalData.url + "/api/services/Finace/AccountingSubject/GetAll";
    var obj = {};
    if (that.data.accountingsubjectInformation == null || that.data.accountingsubjectInformation == "" || that.data.accountingsubjectInformation == undefined) {
      obj = {
        searchGroup: {
          rules: [{
            field: "id",
            value: that.data.id
          }]
        },
        sorting: "sort asc",
        pageSize: 200
      };
    } else {
      obj = {
        filter: that.data.accountingsubjectInformation,
        sorting: "sort asc",
        pageSize: 200
      };
    }
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      that.setData({
        movies: res.result.items,
        moviesItem: res.result.items
      });
    });
  },
  //部门明细
  departmentItemChange: function departmentItemChange(e) {
    var that = this;
    var item = that.data.Item;
    item[parseInt(e.currentTarget.dataset.data)].departmentItem = false;
    that.setData({
      Item: item
    });
  },
  departmentItem: function departmentItem(e) {
    var that = this;
    var item = that.data.Item;
    item[e.currentTarget.dataset.data].departmentName = e.currentTarget.dataset.name;
    item[e.currentTarget.dataset.data].department = e.currentTarget.dataset.id;
    item[parseInt(e.currentTarget.dataset.data)].departmentItem = true;
    this.setData({
      Item: item
    });
  },
  //会计科目明细
  accountItemChange: function accountItemChange(e) {
    var that = this;
    var item = that.data.Item;
    item[parseInt(e.currentTarget.dataset.data)].accountItem = false;
    that.setData({
      Item: item
    });
  },
  accountItemClick: function accountItemClick(e) {
    var that = this;
    var item = that.data.Item;
    item[parseInt(e.currentTarget.dataset.data)].name = e.currentTarget.dataset.name;
    item[parseInt(e.currentTarget.dataset.data)].account = e.currentTarget.dataset.id;
    item[parseInt(e.currentTarget.dataset.data)].accountItem = true;
    that.setData({
      Item: item
    });
  },
  //时间
  datePicker: function datePicker(e) {
    this.setData({
      startTime: e.detail.value
    });
  },
  //时间明细
  datePickerItem: function datePickerItem(e) {
    var that = this;
    var item = that.data.Item;
    item[parseInt(e.currentTarget.dataset.data)].date = e.detail.value;
    that.setData({
      Item: item
    });
  },
  totalAmount: function totalAmount(e) {
    this.setData({
      totalAmount: e.detail.value
    });
  },
  cycleDistribution: function cycleDistribution(e) {
    this.setData({
      cycleDistribution: e.detail.value
    });
  },
  amount: function amount(e) {
    var that = this;
    var item = that.data.Item;
    var reg = new RegExp("^-?[0-9]*.?[0-9]*$");
    if (!reg.test(e.detail.value)) {
      wx.showModal({
        title: '错误信息',
        content: '请输入数字',
        showCancel: false
      });
    } else {
      item[e.currentTarget.dataset.data].amount = e.detail.value;
      that.setData({
        Item: item
      });
    }
  },
  remark: function remark(e) {
    var that = this;
    var item = that.data.Item;
    item[e.currentTarget.dataset.data].remark = e.detail.value;
    this.setData({
      Item: item
    });
  },
  del: function del(e) {
    var that = this;
    wx.showModal({
      title: '提示信息',
      content: '是否要删除',
      showCancel: true,
      success: function success(res) {
        if (res.confirm) {
          var Item = that.data.Item;
          Item.splice(e.currentTarget.dataset.data, 1);
          that.setData({
            Item: Item
          });
        } else {}
      }
    });
  },
  Add: function Add() {
    var that = this;
    var temp = that.data.Item;
    temp.unshift(item);
    that.setData({
      Item: temp
    });
  },
  clear: function clear() {
    var that = this;
    that.setData({
      totalAmount: "",
      cycleDistribution: "",
      distributionId: "",
      distributionName: "",
      startTime: "",
      account: "",
      paymentModeId: "",
      paymentModeName: "",
      displayId: "",
      displayName: "",
      payOrderTemplateId: "",
      payOrderTemplateName: "",
      pot: []
    });
  },
  buttonsave: function buttonsave() {
    var that = this;
    var path = app.globalData.url + "/api/services/Finace/PayOrder/AutomaticDistribution";
    var obj = {
      totalAmount: that.data.totalAmount,
      date: that.data.startTime,
      cycleDistribution: that.data.cycleDistribution,
      distributionId: that.data.distributionId ? that.data.distributionId : null,
      account: that.data.accountId,
      department: that.data.departmentId ? that.data.departmentId : null
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      var item = res.result;
      temp = that.data.Item;
      for (var i = 0; i < res.result.length; i++) {
        var account = res.result[i].account;
        item[i].departmentName = departmentcache.getNameById(res.result[i].department);
        item[parseInt(i)].accountItem = true;
        item[parseInt(i)].departmentItem = true;
        that.LoadData(account);
        temp.unshift(item[i]);
      }
      that.setData({
        Item: temp
      });
    });
  },
  buttonsave1: function buttonsave1() {
    var that = this;
    if (that.data.department == "" || that.data.department == "null" || that.data.department == undefined) {
      wx.showModal({
        title: '提示信息',
        content: '请选择部门~~',
        showCancel: false
      });
      return;
    }
    if (that.data.account == "" || that.data.account == null || that.data.account == undefined) {
      wx.showModal({
        title: '提示信息',
        content: '请选择科目！'
      });
      return;
    }
    var path = that.data.state != "130008010" ? app.globalData.url + "/api/services/Finace/PayOrder/CreateWithItems" : app.globalData.url + "/api/services/Finace/PayOrder/UpdateWithItems";
    var obj = {
      id: that.data.payOrderId,
      date: that.data.startTimes,
      creatorUserId: that.data.creatorUserId,
      no: that.data.no == "" ? "" : that.data.no,
      state: "130008005",
      isSalary: false,
      FkType: "PayOrder",
      department: that.data.departmentId ? that.data.departmentId : null,
      items: that.data.Item,
      image: that.data.srcs
    };
    that.data.state != "130008010" ? delete obj["id"] : obj;
    for (var i = 0; i < that.data.Item.length; i++) {
      if (that.data.Item[i].department == "" || that.data.Item[i].department == null || that.data.Item[i].department == undefined) {
        wx.showModal({
          title: '提示信息',
          content: '请选择部门~~',
          showCancel: false
        });
        return;
      }
      if (that.data.Item[i].name == "" || that.data.Item[i].name == null || that.data.Item[i].name == undefined) {
        wx.showModal({
          title: '提示信息',
          content: '请选择科目~~',
          showCancel: false
        });
        return;
      }
    }
    if (that.data.Item.length < 1) {
      wx.showModal({
        title: '提示信息',
        content: '请添加明细！！！',
        showCancel: false
      });
      return;
    }
    util.request(path, obj).then(function(res) {
      if (res.success) {
        that.setData({
          entityList: res.result,
          PayOrder: res.result.id,
          rejectOpen: true,
          open: false
        });
        wx.showModal({
          title: '提示信息',
          content: "保存成功，请点击申请审批！",
          showCancel: false
        });
      }
    }, function(error) {
      wx.showModal({
        title: '错误信息',
        content: error.error.message,
        showCancel: false
      });
    });
  },
  reject: function reject() {
    var that = this;
    var path = app.globalData.url + "/api/services/WorkFlow/WFTemplate/GetWFTemplateByType";
    var obj = {
      Type: "160205005",
      Param: "PayOrder",
      organizationUnitId: that.data.departmentId,
      pageSize: 2000
    }; //app.globalData.information.organizationUnitId
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      that.setData({
        workFlowTemp: res.result
      });
      if (res.result.id) {
        var path = app.globalData.url + "/api/services/WorkFlow/WorkFlow/Create";
        var obj = {
          name: that.data.department + "发起一笔费用申报，请审核",
          moduleName: "Finace",
          wfTempID: that.data.workFlowTemp.id,
          fkID: that.data.PayOrder,
          fkType: "PayOrder",
          startIndex: "1",
          data: JSON.stringify({
            id: that.data.PayOrder,
            fkType: "PayOrder"
          }),
          entity: that.data.entityList
        };
        util.request(path, obj, "POST").then(function(res) {
          if (res.success) {
            wx.switchTab({
              url: '/pages/ucenter/work/work'
            });
            return;
          }
        }, function(error) {
          wx.showModal({
            title: '错误信息',
            content: error.error.message,
            showCancel: false
          });
        });
      }
    });
  }
});