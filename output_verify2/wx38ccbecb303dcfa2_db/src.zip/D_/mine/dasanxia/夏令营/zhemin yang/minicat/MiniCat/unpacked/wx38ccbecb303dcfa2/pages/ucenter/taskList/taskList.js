var _createForOfIteratorHelper2 = require("../../../@babel/runtime/helpers/createForOfIteratorHelper");
var util = require('../../../utils/util.js');
var api = require('../../../config/api.js');
var user = require('../../../utils/cache/user.js');
var _require = require('../../../config/api.js'),
  CommentCount = _require.CommentCount;
var app = getApp();
var obj = {};
var flag = true;
var pageindex = 1;
var pagesize = 100;
var data;
var userData = false;
var num = 1;
var totalCount;
Page({
  data: {
    scrollTop: 0,
    lastScrollTop: 0,
    lastScrollTop2: 0,
    winWidth: 0,
    winHeight: 0,
    scrollHeight: 0,
    totalCount: 0,
    // tab切换  
    currentTab: 0,
    userInformation: "",
    getState: "",
    getName: "",
    loading: "",
    open: false,
    movies: [],
    userId: 0,
    state: "130008010",
    istimeout: false,
    url_img: app.globalData.url + "/File/Image?FileName="
  },
  //格式时间
  FormatTime: function FormatTime() {
    var date = new Date();
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    m = m < 10 ? '0' + m : m;
    var d = date.getDate();
    d = d < 10 ? '0' + d : d;
    return y + "-" + m + "-" + d;
  },
  onLoad: function onLoad(options) {
    var that = this;
    if (options.id) {
      that.setData({
        userId: options.id,
        state: options.state,
        istimeout: options.istimeout == 1 ? true : false
      });
      that.LoadData(data);
      return;
    }
  },
  onShow: function onShow(options) {
    var that = this;
    wx.getSystemInfo({
      success: function success(res) {
        if (res) {
          if (res.windowWidth) that.setData({
            winWidth: res.windowWidth
          });
          if (res.winHeight) that.setData({
            winWidth: res.winHeight
          });
          if (res.windowHeight) that.setData({
            scrollHeight: res.windowHeight
          });
        }
      }
    });
  },
  LoadData: function LoadData(data) {
    var that = this;
    var todate = new Date().toISOString().slice(0, 10);
    wx.showToast({
      icon: "loading",
      title: "正在加载......"
    });
    var path = app.globalData.url + "/api/services/Score/TaskManage/GetAll";
    var obj;
    if (that.data.istimeout) {
      obj = {
        searchGroup: {
          op: 1,
          rules: [{
            field: "State",
            value: this.data.state,
            op: 3
          }, {
            field: "UserId",
            value: this.data.userId,
            op: 3
          }, {
            field: "EndDate",
            value: todate,
            op: 10
          }]
        },
        sorting: "CreationTime DESC",
        pageSize: pagesize,
        pageIndex: pageindex
      };
    } else {
      if (that.data.state == "130008010") {
        obj = {
          searchGroup: {
            op: 1,
            rules: [{
              field: "State",
              value: that.data.state,
              op: 3
            }, {
              field: "EndDate",
              value: that.FormatTime(),
              op: 9
            }, {
              field: "UserId",
              value: that.data.userId,
              op: 3
            }]
          },
          sorting: "CreationTime DESC",
          pageSize: pagesize,
          pageIndex: pageindex
        };
      } else {
        obj = {
          searchGroup: {
            op: 1,
            rules: [{
              field: "State",
              value: this.data.state,
              op: 3
            }, {
              field: "UserId",
              value: this.data.userId,
              op: 3
            }]
          },
          sorting: "CreationTime DESC",
          pageSize: pagesize,
          pageIndex: pageindex
        };
      }
    }
    util.request(path, obj, "GET").then(function(res) {
      flag = true;
      totalCount = res.result.totalCount;
      if (res.success && res.result.items.length > 0) {
        var _iterator = _createForOfIteratorHelper2(res.result.items),
          _step;
        try {
          for (_iterator.s(); !(_step = _iterator.n()).done;) {
            var item = _step.value;
            item.name = user.getNameById(item.userId);
            if (item.creatorUserId != null) {
              if (item.userId != item.creatorUserId) {
                item.creatorUser = user.getNameById(item.creatorUserId) + "发布";
              }
            } else {
              item.creatorUser = "";
            }
            if (item.publishIntroduce != null && item.publishIntroduce.length > 15) {
              item.publishIntroduce = item.publishIntroduce.substring(0, 12) + "...";
            }
            if (item.startDate != null && item.startDate.toString().length > 10) {
              item.startDate = item.startDate.toString().substring(0, 10);
            }
            if (item.endDate != null && item.endDate.toString().length > 10) {
              item.endDate = item.endDate.toString().substring(0, 10);
            }
          }
        } catch (err) {
          err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
          _iterator.e(err);
        } finally {
          _iterator.f();
        }
        that.setData({
          movies: res.result.items
        });
        wx.hideToast();
      }
    }, function(err) {
      flag = true;
      wx.hideToast();
    }, function(com) {
      flag = true;
      wx.hideToast();
    });
  },
  del: function del(options) {
    var that = this;
    wx.showModal({
      title: '',
      content: '请确认是否删除本条任务?',
      success: function success(res) {
        if (res.confirm) {
          var id = options.currentTarget.dataset.id;
          var path = app.globalData.url + "/api/services/Score/TaskManage/Delete?id=" + id;
          var obj = {};
          util.request(path, obj, "GET").then(function(res) {
            if (res.success) {
              wx.showModal({
                title: '提示',
                content: '删除成功！',
                showCancel: false
              });
              var timeout = that.data.istimeout ? 1 : 0;
              wx.navigateTo({
                url: '/pages/ucenter/taskList/taskList?id=' + that.data.userId + '&&state=' + that.data.state + '&&istimeout=' + timeout
              });
              return;
            } else {
              wx.showToast({
                title: '服务器网络错误!',
                icon: 'loading',
                duration: 1500
              });
            }
          });
        }
      }
    });
  }
});