var app = getApp();
var WxParse = require('../../../lib/wxParse/wxParse.js');
var util = require('../../../utils/util.js');
var department = require('../../../utils/cache/department.js');
Page({
  data: {
    movies: [],
    movie: [],
    AchievingRateRanking: [],
    open: false,
    displayName: "部门",
    startTime: "请选择时间",
    endTime: "请选择时间",
    winWidth: 0,
    winHeight: 0,
    currentTab: 0,
    activeId: "",
    displayId: ""
  },
  onLoad: function onLoad(option) {
    var that = this;
    wx.getSystemInfo({
      success: function success(res) {
        that.setData({
          winWidth: res.windowWidth
        });
      }
    });
    that.LoadData('0');
  },
  /** 
   * 点击tab切换 
   */
  swichNav: function swichNav(e) {
    var that = this;
    that.setData({
      movies: [],
      AchievingRateRanking: []
    });
    var current = e.target.dataset.current;
    that.setData({
      currentTab: e.target.dataset.current
    });
    that.LoadData(current);
  },
  department: function department() {
    this.setData({
      openuser: !this.data.openuser
    });
    var that = this;
    var path = app.globalData.url + "/api/services/Foundation/OrganizationUnit/GetOrganizationUnits";
    var obj = {
      MaxResultCount: 2000,
      pageSize: 2000
    };
    util.request(path, obj, "Get").then(function(res) {
      that.setData({
        movie: res.result.items
      });
    });
  },
  userone: function userone(e) {
    this.setData({
      displayName: e.currentTarget.dataset.index,
      displayId: e.currentTarget.dataset.id,
      openuser: !this.data.openuser
    });
  },
  datePicker: function datePicker(e) {
    this.setData({
      startTime: e.detail.value
    });
  },
  datePickers: function datePickers(e) {
    this.setData({
      endTime: e.detail.value
    });
  },
  create: function create(e) {
    var that = this;
    if (that.data.startTime == "请选择时间" || that.data.endTime == "请选择时间") {
      wx.showModal({
        title: '提示信息',
        content: '请补充完数据~~',
        showCancel: false
      });
      return;
    }
    that.LoadData(e.currentTarget.dataset.index);
  },
  LoadData: function LoadData(e) {
    var that = this;
    if (e == "0") {
      wx.showLoading({
        icon: "loading",
        title: "正在加载......",
        mask: true
      });
      var path = app.globalData.url + "/api/services/Finace/Report/GetBusinessRanking";
      var obj = {
        ouId: that.data.displayId,
        startTime: that.data.startTime == "请选择时间" ? "" : that.data.startTime,
        endTime: that.data.endTime == "请选择时间" ? "" : that.data.endTime
      };
      util.request(path, obj, "Get").then(function(res) {
        wx.hideToast();
        for (var i = 0; i < res.result.items.length; i++) {
          res.result.items[i].organizationUnitName = department.getNameById(res.result.items[i].organizationUnitId);
          res.result.items[i].totalScore = Math.round(res.result.items[i].totalScore * 100) / 100;
        }
        that.setData({
          movies: res.result.items,
          winHeight: res.result.items.length ? res.result.items.length * 72 : 0
        });
      }, function(error) {
        wx.showModal({
          title: '提示信息',
          content: error.error.message,
          showCancel: false
        });
        wx.hideToast();
      }, function(com) {
        wx.hideToast();
      });
    }
    if (e == "1") {
      wx.showLoading({
        icon: "loading",
        title: "正在加载......",
        mask: true
      });
      var path = app.globalData.url + "/api/services/Finace/Report/GetAchievingRateRanking";
      var obj = {
        ouId: that.data.displayId,
        startTime: that.data.startTime == "请选择时间" ? "" : that.data.startTime,
        endTime: that.data.endTime == "请选择时间" ? "" : that.data.endTime
      };
      util.request(path, obj, "Get").then(function(res) {
        wx.hideToast();
        for (var i = 0; i < res.result.items.length; i++) {
          res.result.items[i].organizationUnitName = department.getNameById(res.result.items[i].organizationUnitId);
          res.result.items[i].totalScore = Math.round(res.result.items[i].totalScore * 100) / 100;
        }
        that.setData({
          AchievingRateRanking: res.result.items,
          winHeight: res.result.items.length ? res.result.items.length * 72 : 0
        });
        wx.hideLoading();
      }, function(error) {
        wx.showModal({
          title: '提示信息',
          content: error.error.message,
          showCancel: false
        });
        wx.hideToast();
      }, function(com) {
        wx.hideToast();
      });
    }
  }
});