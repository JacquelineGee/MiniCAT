var util = require('./util.js');
var app = getApp();
var dItem = new Array();
var w = 130;
var h = 40;
var iw = 50;
var ih = 80;
var boxh = 80;
var startleft = 180;
var starttop = 60;
var hr = "<hr size=\"1\" noshade>";
var labledv = "<view class=\"dvItem\" style=\"";
var hdv = "<view class=\"dvhline\" style=\"width:";
var vdv = "<view class=\"dvvline\" style=\"height:" + h + "px;\"";
var endsdv = "\">";
var enddv = "</view>";
var htm = "";
var len;
var maxn = 0; //深度

function Init(callBack) {
  fetch(callBack);
}

function fetch(callBack) {
  var path = app.globalData.url + "/api/services/Member/MemberInfo/MemberLevelsForMiniProgram";
  var data = {
    memberId: app.globalData.information.id
  };
  var content_ = "";
  for (var key in data) {
    content_ += key + "=" + data[key] + "&";
  }
  util.request(path, content_, "POST", "application/x-www-form-urlencoded").then(function(res) {
    if (callBack) {
      callBack(Load_Data(res.result));
    }
  });
}

function Load_Data(item) {
  dItem = item;
  len = dItem.length;
  Set_Item(0, 0);
  Set_Max();
  Write_Item(0, 0, 0, 1);
  var htm1 = "";
  for (var i = 0; i < len; i++) {
    htm1 = htm1 + dItem[i] + "<br>";
  }

  //document.getElementById("Load_DV").innerHTML = htm1 ;
  return htm;
}

//设置层次
function Set_Item(pid, ni) {
  var n = ni + 1;
  var iAry = new Array();
  for (var i = 0; i < len; i++) {
    iAry = dItem[i].split("|");
    if (iAry[2] == pid) {
      dItem[i] = dItem[i] + ni;
      if (maxn < ni) {
        maxn = ni;
      }
      Set_Item(iAry[0], n);
    }
  }
}

//设置节点子节点中最大数
function Set_Max() {
  var iAry = new Array();
  var childnum;
  for (var i = 0; i < len; i++) {
    iAry = dItem[i].split("|");
    childnum = Get_Child_Num(iAry[0]);
    if (childnum <= 1) {
      dItem[i] = dItem[i] + "|0";
    } else {
      dItem[i] = dItem[i] + "|" + Get_Max(iAry[0], iAry[3]);
    }
  }
}

function Get_Max(pid, start) {
  var iAry = new Array();
  var m = 0;
  var n = 0;
  for (var j = start; j <= maxn; j++) {
    for (var i = 0; i < len; i++) {
      iAry = dItem[i].split("|");
      if (iAry[3] == j) {
        if (Get_RootID(pid, iAry[0])) {
          m = m + 1;
        }
      }
      if (n < m) {
        n = m;
      }
    }
    m = 0;
  }
  return n;
}

function Get_RootID(pid, id) {
  var iAry = new Array();
  for (var i = 0; i < len; i++) {
    iAry = dItem[i].split("|");
    if (iAry[0] == id) {
      if (iAry[2] == pid) {
        return true;
        break;
      } else {
        return Get_RootID(pid, iAry[2]);
      }
    }
  }
  return false;
}
//取得 id 所在的数组
function Get_Item(id) {
  var i;
  var items;
  var iAry = new Array();
  for (i = 0; i < len; i++) {
    iAry = dItem[i].split("|");
    if (iAry[0] == id) {
      items = dItem[i];
      break;
    }
  }
  return items;
}
//取得子节点个数
function Get_Child_Num(pid) {
  var i;
  var rnum = 0;
  var iAry = new Array();
  for (i = 0; i < len; i++) {
    iAry = dItem[i].split("|");
    if (iAry[2] == pid) {
      rnum = rnum + 1;
    }
  }
  return rnum;
}

function Write_Item(ipid, ltmp, wtmp, cnt) {
  var iAry = new Array();
  var id;
  var txt;
  var pid;
  var lens;
  var maxnum;
  var t;
  var l;
  var hline_width;
  var dvline = "";
  var childnum = 0;
  var itxt;
  var tmpcnt = 0;
  for (var i = 0; i < len; i++) {
    itxt = dItem[i];
    iAry = itxt.split("|");
    if (iAry[2] == ipid) {
      id = iAry[0];
      txt = iAry[1];
      pid = iAry[2];
      lens = iAry[3];
      maxnum = iAry[4];
      childnum = Get_Child_Num(id);
      hline_width = maxnum * iw - 60;
      if (pid == 0) {
        t = starttop;
        l = startleft;
      } else {
        t = starttop + 2 * lens * h + lens * ih;
        //  l = ltmp + wtmp / cnt  * tmpcnt;
        l = ltmp - wtmp / 2 + wtmp / 2 * tmpcnt;
      }
      dvline = "";
      if (childnum > 1) {
        var t1;
        var l1;
        var t2;
        var l2;
        var w2;
        t1 = t + ih;
        l1 = l + 12;
        w2 = hline_width / 2;
        t2 = t1 + h;
        l2 = l - w2 + 10;
        dvline = "<view class=\"dvvline\" style=\"height:" + h + "px;left:" + l1 + "px;top:" + t1 + "px\"></view>";
        dvline = dvline + "<view class=\"dvhline\" style=\"width:" + hline_width + "px;left:" + l2 + "px;top:" + t2 + "px\"></view>";
        for (var j = 0; j < childnum; j++) {
          var t3;
          var l3;
          t3 = t1 + h;
          l3 = l2 + hline_width / (childnum - 1) * j;
          var tmpline = "<view class=\"dvvline\" style=\"height:" + h + "px;left:" + l3 + "px;top:" + t3 + "px\"></view>";
          dvline = dvline + tmpline;
        }
        dvline = dvline;
      } else if (childnum == 1) {
        var t4;
        var l4;
        l4 = l + 12;
        dvline = "<view class=\"dvvline\" style=\"height:" + h + "px;left:" + l4 + "px;top:" + (t + ih) + "px\"></view>";
        dvline = dvline + "<view class=\"dvvline\" style=\"height:" + h + "px;left:" + l4 + "px;top:" + (t + ih + h) + "px\"></view>";
      }
      htm = htm + labledv + "left:" + l + "px;top:" + t + "px" + endsdv + txt + enddv + dvline;
      if (cnt % 2 == 0) {
        tmpcnt = tmpcnt + 2;
      } else {
        tmpcnt = tmpcnt + 1;
      }
      Write_Item(id, l, hline_width, childnum);
    } //if(iAry[2] == ipid)
  }
}

module.exports = {
  Init: Init,
  fetch: fetch,
  Load_Data: Load_Data,
  Set_Item: Set_Item,
  Set_Max: Set_Max,
  Get_Max: Get_Max,
  Get_RootID: Get_RootID,
  Get_Item: Get_Item,
  Get_Child_Num: Get_Child_Num,
  Write_Item: Write_Item
};