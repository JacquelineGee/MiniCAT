var util = require('../util.js');
var app = getApp();
var account;

function init() {
  if (app.cache.account) account = app.cache.account;
  if (!account || account.length == 0) {
    var url = util.getQueryUrl(app.globalData.url + "/api/services/Finace/AccountingSubject/GetAll", {
      pageSize: 2000
    });
    util.request(url).then(function(res) {
      if (res.success) {
        account = res.result.items;
        app.cache.account = account;
      }
    }, function(error) {
      console.log(error);
    });
  }
}

function getNameById(uid) {
  var data = getaccountById(uid);
  if (!data || data == null) return uid + "";
  return data.name;
}

function getaccountById(uid) {
  account = app.cache.account;
  return account ? account.find(function(x) {
    return x.id == uid;
  }) : null;
}
module.exports = {
  getaccountById: getaccountById,
  getNameById: getNameById,
  init: init
};