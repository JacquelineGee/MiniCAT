var _createForOfIteratorHelper2 = require("../../../@babel/runtime/helpers/createForOfIteratorHelper");
var app = getApp();
var WxParse = require('../../../lib/wxParse/wxParse.js');
var util = require('../../../utils/util.js');
var user = require('../../../utils/cache/user.js');
Page({
  data: {
    items: [],
    name: "",
    slogan: "",
    activityName: "",
    id: ""
  },
  onLoad: function onLoad(options) {
    var that = this;
    that.setData({
      id: options.id
    });
    if (options.id) {
      var path = app.globalData.url + "/api/services/Score/Team/Get";
      var obj = {
        Id: options.id
      };
      var userConfiguration = wx.getStorageSync('userConfiguration');
      util.request(path, obj, "Get").then(function(res) {
        if (userConfiguration["Score/Team/Update"] == 'true') {
          that.setData({
            openupdate: true
          });
        } else {
          that.setData({
            openupdate: false
          });
        }
        if (res.result.state == '130008020') {
          that.setData({
            open: false
          });
        } else {
          that.setData({
            open: true
          });
        }
        var path = app.globalData.url + "/api/services/Score/Team/GetItemsById";
        var obj = {
          id: options.id
        };
        var Getdata = util.getQueryUrl(path, obj);
        util.request(Getdata).then(function(res) {
          var items = [];
          var openinitiate = false;
          var _iterator = _createForOfIteratorHelper2(res.result),
            _step;
          try {
            for (_iterator.s(); !(_step = _iterator.n()).done;) {
              var item = _step.value;
              if (item.userId == app.globalData.information.id && item.limits == '200012001') {
                openinitiate = true;
              }
              if (item.state == true) {
                items.push(item);
              }
              var _iterator2 = _createForOfIteratorHelper2(items),
                _step2;
              try {
                for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
                  var item = _step2.value;
                  item.userName = user.getNameById(item.userId);
                }
              } catch (err) {
                err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
                _iterator2.e(err);
              } finally {
                _iterator2.f();
              }
              that.setData({
                movies: items
              });
            }
          } catch (err) {
            err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
            _iterator.e(err);
          } finally {
            _iterator.f();
          }
          that.setData({
            openinitiate: openinitiate
          });
        });
      });
    }
    that.teamItem(options);
  },
  teamItem: function teamItem(options) {
    var that = this;
    var path = app.globalData.url + "/api/services/Score/Team/Get";
    var obj = {
      id: options.id
    };
    var Getdata = util.getQueryUrl(path, obj);
    util.request(Getdata).then(function(res) {
      that.setData({
        name: res.result.name,
        slogan: res.result.slogan,
        activityName: res.result.activityName,
        activityId: res.result.activityId
      });
    });
  },
  update: function update() {
    var that = this;
    wx.navigateTo({
      url: '/pages/ucenter/team1/team1?id=' + that.data.id
    });
  },
  reject: function reject(e) {
    var that = this;
    var path = app.globalData.url + "/api/services/Score/TeamItem/TeamItemState";
    var obj = {
      id: that.data.id,
      userId: app.globalData.information.id,
      state: e.currentTarget.dataset.index
    };
    var Getdata = util.getQueryUrl(path, obj);
    util.request(Getdata).then(function(res) {
      if (res.success) {
        wx.switchTab({
          url: '/pages/scan/scan'
        });
      }
    }, function(res) {
      var content = res.error.message;
      if (!content) {
        content = "信息有误，请检查后重试！";
      }
      wx.showModal({
        title: '提示信息',
        content: content,
        showCancel: false
      });
    });
  },
  initiate: function initiate(e) {
    var that = this;
    var obj = {
      teamId: that.data.id
    };
    var path = util.getQueryUrl(app.globalData.url + "/api/services/Score/Team/SendTeamJoinRequest", obj);
    util.request(path).then(function(res) {
      if (res.success) {
        wx.showModal({
          title: '提示信息',
          content: '团队邀请发起成功！',
          showCancel: false
        });
      }
    }, function(error) {
      wx.showModal({
        title: '错误信息',
        content: '团队邀请发起失败！',
        showCancel: false
      });
    });
  }
});