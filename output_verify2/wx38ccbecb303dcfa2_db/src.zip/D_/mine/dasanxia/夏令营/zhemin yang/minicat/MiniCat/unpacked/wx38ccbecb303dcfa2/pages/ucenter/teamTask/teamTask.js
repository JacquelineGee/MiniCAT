var _defineProperty2 = require("../../../@babel/runtime/helpers/defineProperty");
var _createForOfIteratorHelper2 = require("../../../@babel/runtime/helpers/createForOfIteratorHelper");
var util = require('../../../utils/util.js');
var api = require('../../../config/api.js');
var user = require('../../../utils/cache/user.js');
var app = getApp();
var obj = {};
var flag = true;
var pageindex = 1;
var pagesize = 100;
var data;
var userData = false;
var num = 1;
var totalCount;
Page(_defineProperty2({
  data: {
    scrollTop: 0,
    lastScrollTop: 0,
    lastScrollTop2: 0,
    winWidth: 0,
    winHeight: 0,
    scrollHeight: 0,
    // tab切换  
    currentTab: 0,
    userInformation: "",
    getState: "",
    getName: "",
    loading: "",
    open: false,
    movies: [],
    movies1: [],
    url_img: app.globalData.url + "/File/Image?FileName="
  },
  onLoad: function onLoad(options) {
    var that = this;
    that.setData({
      userInformation: "",
      currentTab: 0
    });
    if (options.name) {
      that.setData({
        loading: options.name,
        userInformation: options.name,
        currentTab: 1
      });
    }
    this.get(options);
    //that.LoadData(data);
    return;
  },
  onShow: function onShow(options) {
    var that = this;
    that.setData({
      userInformation: ""
    });
    var userConfiguration = wx.getStorageSync('userConfiguration');
    var user1 = wx.setStorageSync('user');
    //console.log(user1);
    if (userConfiguration["Score/TaskManage/Create"] == 'true') {
      that.setData({
        open: true
      });
    } else {
      that.setData({
        open: false
      });
    }
    wx.getSystemInfo({
      success: function success(res) {
        if (res) {
          if (res.windowWidth) that.setData({
            winWidth: res.windowWidth
          });
          if (res.winHeight) that.setData({
            winWidth: res.winHeight
          });
          if (res.windowHeight) that.setData({
            scrollHeight: res.windowHeight
          });
        }
      }
    });
  },
  //页面滑动到底部
  bindDownLoad: function bindDownLoad(e) {
    var that = this;
    if (flag) {
      flag = false;
      pageindex++;
      var count = parseInt(totalCount) % pagesize == 0 ? parseInt(totalCount) / pagesize : Math.floor(parseInt(totalCount) / pagesize);
      if (pageindex > count + 1) {
        //flag = true
        // wx.showModal({
        //   title: '提示信息',
        //   content: '下拉数据加载完毕！！',
        //   showCancel: false
        // })
        return;
      }
    }
  },
  scroll: function scroll(event) {
    //该方法绑定了页面滚动时的事件，我这里记录了当前的position.y的值,为了请求数据之后把页面定位到这里来。
    var scroll = event.detail.scrollTop;
    var that = this;
    this.setData({
      lastScrollTop2: that.data.lastScrollTop,
      lastScrollTop: scroll
    });
  },
  //获取输入的用户信息
  input: function input(e) {
    var that = this;
    this.setData({
      userInformation: e.detail.value
    });
  },
  teamTask: function teamTask() {
    wx.navigateTo({
      url: '/pages/ucenter/teamTask/teamTask'
    });
  },
  //根据用户信息查询数据
  get: function get(data) {
    var that = this;
    //console.log('data:',data);
    var path = app.globalData.url + "/api/services/Score/TaskManage/GetTeamTasks";
    var obj = {
      searchGroup: {
        op: 1,
        rules: [{
          field: "Remark",
          value: "team",
          op: 3
        }, {
          field: "PublishIntroduce",
          value: that.data.userInformation,
          op: 7
        }]
      },
      sorting: "LastModificationTime DESC",
      pageSize: pagesize,
      pageIndex: pageindex
    };
    util.request(path, obj, "GET").then(function(res) {
      flag = true;
      totalCount = res.result.totalCount;
      //console.log(res.result.items)
      if (res.success && res.result.items.length > 0) {
        var _iterator = _createForOfIteratorHelper2(res.result.items),
          _step;
        try {
          for (_iterator.s(); !(_step = _iterator.n()).done;) {
            var item = _step.value;
            item.name = user.getNameById(item.userId);
            if (item.creatorUserId != null) {
              if (item.userId != item.creatorUserId) {
                item.creatorUser = user.getNameById(item.creatorUserId) + "发布";
              }
            } else {
              item.creatorUser = "";
            }
            if (item.publishIntroduce != null) {
              if (item.publishIntroduce.length > 30) {
                item.publishIntroduce = item.publishIntroduce.substring(0, 25) + "...";
              }
            }
          }
        } catch (err) {
          err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
          _iterator.e(err);
        } finally {
          _iterator.f();
        }
        that.setData({
          movies1: res.result.items
        });
      }
      wx.hideToast();
    }, function(err) {
      flag = true;
      wx.hideToast();
    }, function(com) {
      wx.hideToast();
    });
    this.onShow();
  }
}, "teamTask", function teamTask() {
  var that = this;
  wx.navigateTo({
    url: '/pages/ucenter/taskPlan/taskPlan'
  });
}));