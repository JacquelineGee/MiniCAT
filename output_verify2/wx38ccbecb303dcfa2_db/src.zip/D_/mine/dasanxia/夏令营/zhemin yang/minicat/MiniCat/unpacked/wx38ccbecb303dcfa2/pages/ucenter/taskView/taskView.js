var _createForOfIteratorHelper2 = require("../../../@babel/runtime/helpers/createForOfIteratorHelper");
// pages/ucenter/taskView/taskView.js
/**
 * 页面的初始数据
 */
var app = getApp();
var WxParse = require('../../../lib/wxParse/wxParse.js');
var util = require('../../../utils/util.js');
var flag = true;
var totalCount;
var pageIndex = 0;
Page({
  data: {
    movies: [],
    movie: [],
    open: false,
    lastScrollTop: 0,
    lastScrollTop2: 0,
    displayName: "部门",
    startTime: "请选择时间",
    endTime: "请选择时间",
    startTime1: "请选择时间",
    endTime1: "请选择时间",
    startTime2: "请选择时间",
    endTime2: "请选择时间",
    level: "级别",
    winWidth: 0,
    winHeight: 0,
    currentTab: 0,
    scrollTop: 0,
    scrollHeight: 0,
    operation: "",
    activeId: "",
    teamId: "",
    displayId: "",
    url: app.globalData.url,
    login: "",
    overView: 0
  },
  onLoad: function onLoad(option) {
    var that = this;
    wx.getSystemInfo({
      success: function success(res) {
        if (res) {
          if (res.windowHeight) that.setData({
            scrollHeight: res.windowHeight
          });
        }
      }
    });
    if (option.operation == "department") {
      that.setData({
        displayId: option.id,
        startTime: that.data.startTime1 == "请选择时间" ? "" : that.data.startTime1,
        endTime: that.data.endTime1 == "请选择时间" ? "" : that.data.endTime1,
        operation: option.operation,
        overView: parseInt(option.overView),
        currentTab: parseInt(option.overView)
      });
      //that.LoadData(that.data.overView)
    } else {
      var that = this;
      that.setData({
        overView: that.data.currentTab
      });
    }
    that.LoadData(that.data.overView);
  },
  getProfilePictureByUid: function getProfilePictureByUid(uid) {
    var that = this;
    var path = app.globalData.url + "/api/services/Foundation/Profile/GetProfilePictureByUid";
    var obj = {
      userId: uid.id
    };
    util.request(path, obj).then(function(res) {
      var movies = that.data.movies;
      if (res.result.profilePicture != "") {
        var profilePicture = 'data:image/jpeg;base64,' + res.result.profilePicture;
        for (var i = 0; i < movies.length; i++) {
          if (movies[i].id == uid.id) {
            movies[i].images = profilePicture;
          }
        }
      } else {}
      that.setData({
        movies: movies
      });
    });
  },
  department: function department() {
    this.setData({
      openuser: !this.data.openuser
    });
    var that = this;
    var path = app.globalData.url + "/api/services/Foundation/OrganizationUnit/GetOrganizationUnits";
    var obj = {
      MaxResultCount: 999,
      pageSize: 999
    };
    util.request(path, obj, "Get").then(function(res) {
      that.setData({
        movie: res.result.items
      });
    });
  },
  level: function level() {
    var that = this;
    that.setData({
      open: !this.data.open
    });
    var path = app.globalData.url + "/api/services/Foundation/OrganizationUnit/GetOrganizationUnits";
    var obj = {
      MaxResultCount: 999,
      pageSize: 999
    };
    util.request(path, obj, "Get").then(function(res) {
      that.setData({
        movie: res.result.items
      });
    });
  },
  userone: function userone(e) {
    this.setData({
      displayName: e.currentTarget.dataset.index,
      displayId: e.currentTarget.dataset.id,
      openuser: !this.data.openuser
    });
  },
  one: function one(e) {
    this.setData({
      level: e.currentTarget.dataset.index,
      open: !this.data.open
    });
  },
  two: function two(e) {
    this.setData({
      level: e.currentTarget.dataset.index,
      open: !this.data.open
    });
  },
  three: function three(e) {
    this.setData({
      level: e.currentTarget.dataset.index,
      open: !this.data.open
    });
  },
  datePicker: function datePicker(e) {
    this.setData({
      startTime: e.detail.value
    });
  },
  datePickers: function datePickers(e) {
    this.setData({
      endTime: e.detail.value
    });
  },
  datePicker1: function datePicker1(e) {
    this.setData({
      startTime1: e.detail.value
    });
  },
  datePickers1: function datePickers1(e) {
    this.setData({
      endTime1: e.detail.value
    });
  },
  datePicker3: function datePicker3(e) {
    this.setData({
      startTime2: e.detail.value
    });
  },
  datePickers3: function datePickers3(e) {
    this.setData({
      endTime2: e.detail.value
    });
  },
  create: function create(e) {
    var that = this;
    that.LoadData(parseInt(e.currentTarget.dataset.index));
  },
  /** 
   * 滑动切换tab 
   */
  bindChange: function bindChange(e) {
    var that = this;
    that.setData({
      pageIndex: 0,
      currentTab: e.detail.current,
      overView: e.detail.current,
      movies: []
    });
    that.LoadData(e.detail.current);
  },
  /** 
   * 点击tab切换 
   */
  swichNav: function swichNav(e) {
    var that = this;
    pageIndex: 0;
    that.setData({
      currentTab: e.target.dataset.current,
      operation: "",
      overView: e.target.dataset.current,
      movies: []
    });
    that.LoadData(parseInt(e.target.dataset.current));
  },
  //页面滑动到顶部
  bindTopLoad: function bindTopLoad(e) {
    var that = this;
    that.setData({
      pageIndex: 0
    });
    if (flag) {
      flag = false;
      if (pageIndex == 0) {
        return;
      } else {
        pageIndex--;
      }
      var count = parseInt(totalCount) % 100 == 0 ? parseInt(totalCount) / 100 : Math.floor(parseInt(totalCount) / 100);
      if (pageIndex < 1) {
        flag = true;
        return;
      }
      that.LoadData(0);
    }
  },
  //页面滑动到底部
  bindDownLoad: function bindDownLoad(e) {
    var that = this;
    if (flag) {
      flag = false;
      var count = parseInt(totalCount) % 100 == 0 ? parseInt(totalCount) / 100 : Math.floor(parseInt(totalCount) / 100);
      if (pageIndex == count) {
        flag = true;
        return;
      } else {
        pageIndex++;
      }
      if (pageIndex > count) {
        flag = true;
        return;
      }
      that.LoadData(0);
    }
  },
  scroll: function scroll(event) {
    //该方法绑定了页面滚动时的事件，我这里记录了当前的position.y的值,为了请求数据之后把页面定位到这里来。
    var scroll = event.detail.scrollTop;
    var that = this;
    this.setData({
      lastScrollTop2: that.data.lastScrollTop,
      lastScrollTop: scroll
    });
  },
  LoadData: function LoadData(e) {
    var that = this;
    if (that.data.operation == "department") {
      var path = app.globalData.url + "/api/services/Score/TaskManage/GetTaskListPersonal";
      wx.showToast({
        icon: "loading",
        title: "正在加载......"
      });
      var state1;
      switch (that.data.overView) {
        case 0:
          state1 = '130008010';
          break;
        case 1:
          state1 = '130008010';
          break;
        case 2:
          state1 = '130008015';
          break;
        case 3:
          state1 = '130008020';
          break;
        default:
          state1 = '130008010';
          break;
      }
      var obj = {
        department: that.data.displayId,
        startTime: that.data.startTime1 == "请选择时间" ? "" : that.data.startTime1,
        endTime: that.data.endTime1 == "请选择时间" ? "" : that.data.endTime1,
        state: state1,
        istimeout: that.data.overView == 0 ? true : false
      };
      var GetData = util.getQueryUrl(path, obj);
      util.request(GetData).then(function(res) {
        wx.hideToast();
        flag = true;
        totalCount = res.result.totalCount;
        var list = res.result.items;
        that.setData({
          movies: list,
          //List,
          winHeight: res.result.items.length ? res.result.items.length * 72 : 0,
          startTime: "请选择时间",
          endTime: "请选择时间"
        });
      }, function(error) {
        wx.showModal({
          title: '提示信息',
          content: error.error.message,
          showCancel: false
        });
        wx.hideToast();
      }, function(com) {
        wx.hideToast();
      });
    } else {
      var path = app.globalData.url + "/api/services/Score/TaskManage/GetTaskListDepartment";
      if (e == "0") {
        wx.showToast({
          icon: "loading",
          title: "正在加载......"
        });
        var obj = {
          departmentLevel: "timeout",
          state: "130008010",
          startTime: that.data.startTime == "请选择时间" ? "" : that.data.startTime,
          endTime: that.data.endTime == "请选择时间" ? "" : that.data.endTime
        };
        var GetData = util.getQueryUrl(path, obj);
        util.request(GetData).then(function(res) {
          wx.hideToast();
          flag = true;
          totalCount = res.result.totalCount;
          var list = res.result.items;
          var _iterator = _createForOfIteratorHelper2(list),
            _step;
          try {
            for (_iterator.s(); !(_step = _iterator.n()).done;) {
              var items = _step.value;
              if (items.id != null) {}
            }
          } catch (err) {
            err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
            _iterator.e(err);
          } finally {
            _iterator.f();
          }
          that.setData({
            movies: list,
            //List,
            winHeight: res.result.items.length ? res.result.items.length * 72 : 0
          });
          // var list = res.result.items;
          // for (var items of list) {
          //   if (items.id != null) {
          //    that.getProfilePictureByUid(items)
          //   }
          // }
        }, function(error) {
          wx.showModal({
            title: '提示信息',
            content: error.error.message,
            showCancel: false
          });
          wx.hideToast();
        }, function(com) {
          wx.hideToast();
        });
      } else {
        wx.showToast({
          icon: "loading",
          title: "正在加载......"
        });
        var state1;
        switch (e) {
          case 3:
            state1 = '130008020';
            break;
          case 1:
            state1 = '130008010';
            break;
          case 2:
            state1 = '130008015';
            break;
          default:
            state1 = '130008010';
            break;
        }
        var obj = {
          state: state1,
          startTime: that.data.startTime1 == "请选择时间" ? "" : that.data.startTime1,
          endTime: that.data.endTime1 == "请选择时间" ? "" : that.data.endTime1
        };
        var GetData = util.getQueryUrl(path, obj);
        util.request(GetData).then(function(res) {
          wx.hideToast();
          that.setData({
            movies: res.result.items,
            winHeight: res.result.items.length ? res.result.items.length * 72 : 0,
            startTime: "请选择时间",
            endTime: "请选择时间"
          });
        }, function(error) {
          wx.hideToast();
          wx.showModal({
            title: '提示信息',
            content: error.error.message,
            showCancel: false
          });
        }, function(com) {
          wx.hideToast();
        });
      }
    }
  },
  stopSwiper: function stopSwiper() {}
});