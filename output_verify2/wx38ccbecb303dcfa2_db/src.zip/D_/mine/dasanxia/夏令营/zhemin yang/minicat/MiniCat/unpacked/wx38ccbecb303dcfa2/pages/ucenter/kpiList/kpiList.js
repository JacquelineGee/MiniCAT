var util = require('../../../utils/util.js');
var api = require('../../../config/api.js');
var user = require('../../../utils/cache/user.js');
var app = getApp();
var obj = {};
var flag = true;
var pageindex = 1;
var pagesize = 100;
var data;
var userData = false;
var num = 1;
var totalCount;
Page({
  data: {
    scrollTop: 0,
    lastScrollTop: 0,
    lastScrollTop2: 0,
    winWidth: 0,
    winHeight: 0,
    scrollHeight: 0,
    totalCount: 0,
    totalscore: 0,
    // tab切换  
    userid: 0,
    currentTab: 0,
    userInformation: "",
    displayMonth: "",
    date: "",
    getState: "",
    getName: "",
    loading: "",
    startTime: "",
    endTime: "",
    open: false,
    movies: [],
    movies1: [],
    movies2: [],
    movies3: [],
    movies4: [],
    url_img: app.globalData.url + "/File/Image?FileName="
  },
  onLoad: function onLoad(options) {
    var that = this;
    var time = that.FormatMonth();
    if (that.data.startTime == "") {
      that.setData({
        startTime: time
      });
    }
    that.setData({
      userInformation: "",
      userid: options.id
    });
    if (options.name) {
      that.setData({
        loading: options.name,
        userInformation: options.name,
        currentTab: 0
      });
      userData = true;
    }
    this.get(options);
  },
  onShow: function onShow(options) {
    var that = this;
    that.setData({
      userInformation: ""
    });
    var userConfiguration = wx.getStorageSync('userConfiguration');
    if (userConfiguration["Salary/KpiManage/Create"] == 'true') {
      that.setData({
        open: true
      });
    } else {
      that.setData({
        open: false
      });
    }
    // if (app.globalData.information.id)
    wx.getSystemInfo({
      success: function success(res) {
        if (res) {
          if (res.windowWidth) that.setData({
            winWidth: res.windowWidth
          });
          if (res.winHeight) that.setData({
            winWidth: res.winHeight
          });
          if (res.windowHeight) that.setData({
            scrollHeight: res.windowHeight
          });
        }
      }
    });
    if (that.data.loading == "") {
      //that.LoadData("130008015", 0);
    }
  },
  FormatMonth: function FormatMonth() {
    var date = new Date();
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    m = m < 10 ? '0' + m : m;
    return y + "-" + m;
  },
  datePicker: function datePicker(e) {
    this.setData({
      startTime: e.detail.value
    });
    var obj = {
      state: "130008020",
      name: this.data.userInformation,
      date: this.data.startTime + "-01 00:00:00.0000000"
    };
    //console.log(obj);
    this.get(obj);
  },
  //页面滑动到底部
  bindDownLoad: function bindDownLoad(e) {
    var that = this;
    if (flag) {
      flag = false;
      pageindex++;
      var count = parseInt(totalCount) % pagesize == 0 ? parseInt(totalCount) / pagesize : Math.floor(parseInt(totalCount) / pagesize);
      if (pageindex > count + 1) {
        //flag = true
        // wx.showModal({
        //   title: '提示信息',
        //   content: '下拉数据加载完毕！！',
        //   showCancel: false
        // })
        return;
      }
      if (userData == true) {
        that.get();
      } else {
        that.LoadData(data);
      }
    }
  },
  scroll: function scroll(event) {
    //该方法绑定了页面滚动时的事件，我这里记录了当前的position.y的值,为了请求数据之后把页面定位到这里来。
    var scroll = event.detail.scrollTop;
    var that = this;
    this.setData({
      lastScrollTop2: that.data.lastScrollTop,
      lastScrollTop: scroll
    });
  },
  swichNav: function swichNav(e) {
    var that = this;
    pageindex = 1;
    that.setData({
      movies: [],
      movies1: [],
      movies2: [],
      movies3: [],
      movies4: []
    });
    var current = e.target.dataset.current;
    obj = data = current == "3" ? "130008005" : current == "0" ? "130008015" : current == "1" ? "130008020" : current == "2" ? "130008010" : "true";
    //obj = data = current == "0" ? "130008015" : current == "1" ? "130008020" : current == "2" ? "130008010" : "true"

    if (data == "130008020" || data == "true") {
      pagesize = 100;
    } else {
      pagesize = 100;
    }
    that.setData({
      currentTab: e.target.dataset.current
    });
    that.LoadData(data, 0);
  },
  //获取输入的用户信息
  input: function input(e) {
    var that = this;
    this.setData({
      userInformation: e.detail.value
    });
  },
  //根据用户信息查询数据
  get: function get(data) {
    var that = this;
    if (data != null) {
      //console.log("data："+data); 
      that.setData({
        getState: data.state ? data.state : data.state,
        startTime: data.startTime == "请选择时间" ? that.data.startTime : data.startTime,
        date: data.date ? data.date : that.data.date
      });
    }
    //console.log("startTime："+that.data.startTime);
    var path = app.globalData.url + "/api/services/Salary/KpiManage/GetAll";
    var obj = {
      searchGroup: {
        op: 1,
        rules: [{
          field: "State",
          value: data ? data.state == null ? that.data.getState : data.state : that.data.getState,
          op: 3
        }, {
          field: "UserId",
          value: that.data.userid,
          op: 3
        }, {
          field: "Date",
          value: data.date == null ? that.data.startTime.substr(0, 7) + "-01 00:00:00.0000000" : that.data.date,
          op: 3
        }]
      },
      sorting: "CreationTime DESC",
      pageSize: pagesize,
      pageIndex: pageindex
    };
    //console.log("userid："+that.data.userid);
    util.request(path, obj, "GET").then(function(res) {
      flag = true;
      totalCount = res.result.totalCount;
      if (res.success && res.result.items.length > 0) {
        // console.log(res.result.items);
        /* for (var item of res.result.items) {
          item.name = user.getNameById(item.userId);
          if (item.creatorUserId != null) {
            if (item.userId != item.creatorUserId) {
              item.creatorUser = user.getNameById(item.creatorUserId) + "帮"
            }
          }
          else {
            item.creatorUser = ""
          }
          if (item.image) {
            var result = item.image.split("|");
            item.image = result[0];
          }
        } */
      }
      wx.hideToast();
      that.setData({
        movies1: res.result.items
      });
    }, function(err) {
      flag = true;
      wx.hideToast();
    }, function(com) {
      wx.hideToast();
    });
  }
  /*   LoadData: function (data) {
      var that = this;
      wx.showLoading({
        icon: "loading",
        title: "正在加载......",
        mask:true
      })
      
      var path = data == "true" ? app.globalData.url + "/api/services/Salary/KpiManage/GetAll" : app.globalData.url + "/api/services/Salary/KpiManage/GetAll";
      obj = data == "true" ? {
        searchGroup: { op: 1, rules: [{ field: "Top", value: data, op: 3 },] },
        sorting: "CreationTime DESC", pageSize: pagesize, pageIndex: pageindex
      } : {
          searchGroup: { op: 1, rules: [{ field: "State", value: data, op: 3 }] },
          sorting: "CreationTime DESC", pageSize: pagesize, pageIndex: pageindex
        };
      if (data == "130008010"||data == "130008020"){
        path = app.globalData.url + "/api/services/Salary/KpiManage/GetAll";
        obj = {
          searchGroup: { op: 1, rules: [{ field: "State", value: data, op: 3 },{ field: "Date", value: data.date == null ? that.data.startTime+"-01 00:00:00.0000000" : that.data.date, op: 3 }]},
          sorting: "CreationTime DESC", pageSize: pagesize, pageIndex: pageindex
        };
      }
      util.request(path, obj, "GET").then((res) => {
        flag = true;
        totalCount = res.result.totalCount;      
        if (res.success && res.result.items.length > 0) {
          for (var item of res.result.items) {
            item.name = user.getNameById(item.userId);
            if (item.creatorUserId != null ) {
              
            }
            else {
              item.creatorUser = ""
            }
            if (item.image) {
              var result = item.image.split("|");
              item.image = result[0];
            }
          }
          wx.hideToast();
          if (res.success) {
            if (data == "130008005") {
             
              that.setData({
                movies: res.result.items,
              })
            } else if (data == "130008015") {
               var sumscore = 0;         
               for (var i = 0; i < res.result.items.length; i++) {
                 var item = res.result.items[i];
                 sumscore=+item.score;
               }           
              that.setData({
                movies1: res.result.items,
                totalscore:sumscore
              })
              
            } else if (data == "130008020") {
              if (that.data.userInformation == "") {
                var list = that.data.movies2;
                var isRemove = false;
               
                for (var i = 0; i < res.result.items.length; i++) {
                  var item = res.result.items[i];
                  list.push(item);
                }
                that.setData({
                  movies2: list,
                })
              }
            } else if (data == "130008010") {
             
              that.setData({
                movies3: res.result.items,
              })
            } else if (data == "true") {
              var list = that.data.movies4;
             
              for (var i = 0; i < res.result.items.length; i++) {
                var item = res.result.items[i];
                list.push(item);
              }
              that.setData({
                movies4: list,
              })
             
            }
          }
        }
  
       
        wx.hideLoading();
      }, (err) => {
        flag = true;
        wx.hideToast();
        }, (com) => {
          flag = true;
        wx.hideToast();
      });
    }, */
});