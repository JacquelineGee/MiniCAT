var app = getApp();
var WxParse = require('../../../lib/wxParse/wxParse.js');
var util = require('../../../utils/util.js');
var departmentStartTime;
var departmentEndTime;
var flag = true;
var totalCount;
var pageIndex = 0;
Page({
  data: {
    movies: [],
    movie: [],
    open: false,
    lastScrollTop: 0,
    lastScrollTop2: 0,
    displayName: "部门",
    startTime: "请选择时间",
    endTime: "请选择时间",
    startTime1: "请选择时间",
    endTime1: "请选择时间",
    startTime2: "请选择时间",
    endTime2: "请选择时间",
    level: "级别",
    winWidth: 0,
    winHeight: 0,
    currentTab: 0,
    scrollTop: 0,
    scrollHeight: 0,
    operation: "",
    activeId: "",
    teamId: "",
    displayId: "",
    url: app.globalData.url,
    login: "",
    overView: 0
  },
  onLoad: function onLoad(option) {
    var that = this;
    wx.getSystemInfo({
      success: function success(res) {
        if (res) {
          if (res.windowHeight) that.setData({
            scrollHeight: res.windowHeight
          });
        }
      }
    });
    if (option.operation == "department") {
      var that = this;
      that.setData({
        displayId: option.id,
        operation: option.operation,
        startTime: option.startTime,
        endTime: option.endTime,
        startTime1: option.startTime1,
        endTime1: option.endTime1,
        overView: option.overView,
        currentTab: option.overView
      });
      //that.LoadData(that.data.overView)
      //console.log('1startTime:',that.data.startTime);
    } else {
      var that = this;
      that.setData({
        startTime: option.startTime,
        endTime: option.endTime,
        startTime1: option.startTime1,
        endTime1: option.endTime1,
        //operation: option.operation,
        overView: that.data.currentTab
      });
    }
    //console.log('overView:',that.data.overView)   
    that.LoadData(that.data.overView);
  },
  getProfilePictureByUid: function getProfilePictureByUid(uid) {
    var that = this;
    var path = app.globalData.url + "/api/services/Foundation/Profile/GetProfilePictureByUid";
    var obj = {
      userId: uid.id
    };
    util.request(path, obj).then(function(res) {
      var movies = that.data.movies;
      if (res.result.profilePicture != "") {
        var profilePicture = 'data:image/jpeg;base64,' + res.result.profilePicture;
        for (var i = 0; i < movies.length; i++) {
          if (movies[i].id == uid.id) {
            movies[i].images = profilePicture;
          }
        }
      } else {}
      that.setData({
        movies: movies
      });
    });
  },
  department: function department() {
    this.setData({
      openuser: !this.data.openuser
    });
    var that = this;
    var path = app.globalData.url + "/api/services/Foundation/OrganizationUnit/GetOrganizationUnits";
    var obj = {
      MaxResultCount: 999,
      pageSize: 999
    };
    util.request(path, obj, "Get").then(function(res) {
      that.setData({
        movie: res.result.items
      });
    });
  },
  level: function level() {
    var that = this;
    that.setData({
      open: !this.data.open
    });
    var path = app.globalData.url + "/api/services/Foundation/OrganizationUnit/GetOrganizationUnits";
    var obj = {
      MaxResultCount: 999,
      pageSize: 999
    };
    util.request(path, obj, "Get").then(function(res) {
      that.setData({
        movie: res.result.items
      });
    });
  },
  userone: function userone(e) {
    this.setData({
      displayName: e.currentTarget.dataset.index,
      displayId: e.currentTarget.dataset.id,
      openuser: !this.data.openuser
    });
  },
  one: function one(e) {
    this.setData({
      level: e.currentTarget.dataset.index,
      open: !this.data.open
    });
  },
  two: function two(e) {
    this.setData({
      level: e.currentTarget.dataset.index,
      open: !this.data.open
    });
  },
  three: function three(e) {
    this.setData({
      level: e.currentTarget.dataset.index,
      open: !this.data.open
    });
  },
  datePicker: function datePicker(e) {
    this.setData({
      startTime: e.detail.value
    });
  },
  datePickers: function datePickers(e) {
    this.setData({
      endTime: e.detail.value
    });
  },
  datePicker1: function datePicker1(e) {
    this.setData({
      startTime1: e.detail.value
    });
  },
  datePickers1: function datePickers1(e) {
    this.setData({
      endTime1: e.detail.value
    });
  },
  datePicker3: function datePicker3(e) {
    this.setData({
      startTime2: e.detail.value
    });
    departmentStartTime = e.detail.value;
  },
  datePickers3: function datePickers3(e) {
    this.setData({
      endTime2: e.detail.value
    });
    departmentEndTime = e.detail.value;
  },
  create: function create(e) {
    var that = this;
    //console.log('chaxun:',e.currentTarget.dataset.index);
    that.LoadData(parseInt(e.currentTarget.dataset.index));
  },
  /** 
   * 滑动切换tab 
   */
  bindChange: function bindChange(e) {
    var that = this;
    that.setData({
      pageIndex: 0,
      currentTab: e.detail.current,
      overView: e.detail.current,
      movies: []
    });
    that.LoadData(e.detail.current);
  },
  /** 
   * 点击tab切换 
   */
  swichNav: function swichNav(e) {
    var that = this;
    pageIndex: 0;
    that.setData({
      currentTab: e.target.dataset.current,
      operation: "",
      overView: e.target.dataset.current,
      movies: []
    });
    //console.log('currentTab:',that.data.currentTab)
    that.LoadData(parseInt(e.target.dataset.current));
  },
  //页面滑动到顶部
  bindTopLoad: function bindTopLoad(e) {
    var that = this;
    that.setData({
      pageIndex: 0
    });
    if (flag) {
      flag = false;
      if (pageIndex == 0) {
        return;
      } else {
        pageIndex--;
      }
      var count = parseInt(totalCount) % 100 == 0 ? parseInt(totalCount) / 100 : Math.floor(parseInt(totalCount) / 100);
      if (pageIndex < 1) {
        flag = true;
        return;
      }
      that.LoadData(0);
    }
  },
  //页面滑动到底部
  bindDownLoad: function bindDownLoad(e) {
    var that = this;
    if (flag) {
      flag = false;
      var count = parseInt(totalCount) % 100 == 0 ? parseInt(totalCount) / 100 : Math.floor(parseInt(totalCount) / 100);
      if (pageIndex == count) {
        flag = true;
        return;
      } else {
        pageIndex++;
      }
      if (pageIndex > count) {
        flag = true;
        return;
      }
      that.LoadData(0);
    }
  },
  scroll: function scroll(event) {
    //该方法绑定了页面滚动时的事件，我这里记录了当前的position.y的值,为了请求数据之后把页面定位到这里来。
    var scroll = event.detail.scrollTop;
    var that = this;
    this.setData({
      lastScrollTop2: that.data.lastScrollTop,
      lastScrollTop: scroll
    });
  },
  LoadData: function LoadData(e) {
    var that = this;
    if (that.data.operation == "department") {
      var path = app.globalData.url + "/api/services/Salary/KPIManage/GetKPIListPersonal";
      wx.showToast({
        icon: "loading",
        title: "正在加载......"
      });
      //console.log("that.data.overView:"+that.data.overView);
      var state1;
      switch (that.data.overView) {
        case 0:
          state1 = '130008015';
          var obj = {
            department: that.data.displayId,
            startTime: that.data.startTime == "请选择时间" ? null : that.data.startTime,
            endTime: that.data.endTime == "请选择时间" ? null : that.data.endTime,
            state: state1
          };
          break;
        case 1:
          state1 = '130008020';
          var obj = {
            department: that.data.displayId,
            startTime: that.data.startTime1 == "请选择时间" ? null : that.data.startTime1,
            endTime: that.data.endTime1 == "请选择时间" ? null : that.data.endTime1,
            state: state1
          };
          break;
        case 2:
          state1 = '130008005';
          var obj = {
            department: that.data.displayId,
            startTime: null,
            endTime: null,
            state: state1
          };
          break;
        default:
          state1 = '130008015';
          var obj = {
            department: that.data.displayId,
            startTime: that.data.startTime == "请选择时间" ? null : that.data.startTime,
            endTime: that.data.endTime == "请选择时间" ? null : that.data.endTime,
            state: state1
          };
          //console.log("startTime:"+that.data.startTime);
          break;
      }
      //console.log('obj:',obj);
      var GetData = util.getQueryUrl(path, obj);
      util.request(GetData).then(function(res) {
        wx.hideToast();
        flag = true;
        totalCount = res.result.totalCount;
        var list = res.result.items;
        switch (that.data.overView) {
          case 0:
            that.setData({
              movies: list,
              //List,
              winHeight: res.result.items.length ? res.result.items.length * 72 : 0
            });
            break;
          case 1:
            that.setData({
              movies: list,
              //List,
              winHeight: res.result.items.length ? res.result.items.length * 72 : 0
            });
            break;
          case 2:
            that.setData({
              movies: list,
              //List,
              winHeight: res.result.items.length ? res.result.items.length * 72 : 0
            });
            break;
          default:
            that.setData({
              movies: list,
              //List,
              winHeight: res.result.items.length ? res.result.items.length * 72 : 0
            });
            break;
        }
        //console.log('movies:',list);
      }, function(error) {
        wx.showModal({
          title: '提示信息',
          content: error.error.message,
          showCancel: false
        });
        wx.hideToast();
      }, function(com) {
        wx.hideToast();
      });
    } else {
      var path = app.globalData.url + "/api/services/Salary/KPIManage/GetKPIListDepartment";
      if (e == "2") {
        var obj = {
          startTime: null,
          endTime: null,
          state: "130008005",
          departmentLevel: 1
        };
        var GetData = util.getQueryUrl(path, obj);
        util.request(GetData).then(function(res) {
          wx.hideToast();
          that.setData({
            movies: res.result.items,
            winHeight: res.result.items.length ? res.result.items.length * 72 : 0
          });
          //console.log('movies:',res.result.items);
        }, function(error) {
          wx.hideToast();
        }, function(com) {
          wx.hideToast();
        });
      } else {
        //console.log('switch:',e)
        wx.showToast({
          icon: "loading",
          title: "正在加载......"
        });
        var state1;
        switch (that.data.overView) {
          case 0:
            state1 = '130008015';
            var obj = {
              state: state1,
              startTime: that.data.startTime == "请选择时间" ? null : that.data.startTime,
              endTime: that.data.endTime == "请选择时间" ? null : that.data.endTime
            };
            break;
          case 1:
            state1 = '130008020';
            var obj = {
              state: state1,
              startTime: that.data.startTime1 == "请选择时间" ? null : that.data.startTime1,
              endTime: that.data.endTime1 == "请选择时间" ? null : that.data.endTime1
            };
            break;
          case 2:
            state1 = '130008005';
            var obj = {
              state: state1,
              startTime: null,
              endTime: null
            };
            break;
          default:
            state1 = '130008015';
            var obj = {
              state: state1,
              startTime: that.data.startTime == "请选择时间" ? null : that.data.startTime,
              endTime: that.data.endTime == "请选择时间" ? null : that.data.endTime
            };
            break;
        }
        console.log('obj1:', obj);
        var GetData = util.getQueryUrl(path, obj);
        util.request(GetData).then(function(res) {
          wx.hideToast();
          that.setData({
            movies: res.result.items,
            winHeight: res.result.items.length ? res.result.items.length * 72 : 0
          });
          //console.log('GetTaskList:',res.result.items)
        }, function(error) {
          wx.hideToast();
          wx.showModal({
            title: '提示信息',
            content: error.error.message,
            showCancel: false
          });
        }, function(com) {
          wx.hideToast();
        });
      }
    }
  },
  stopSwiper: function stopSwiper() {}
});