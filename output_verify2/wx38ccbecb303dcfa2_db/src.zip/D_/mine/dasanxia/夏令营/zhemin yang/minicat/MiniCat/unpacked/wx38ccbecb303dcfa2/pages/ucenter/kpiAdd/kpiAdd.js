var _createForOfIteratorHelper2 = require("../../../@babel/runtime/helpers/createForOfIteratorHelper");
var util = require('../../../utils/util.js');
var user = require('../../../utils/cache/user.js');
var WxParse = require('../../../lib/wxParse/wxParse.js');
var app = getApp();
var content = "";
Page({
  data: {
    checkedname: false,
    checked: false,
    src: "",
    srcs: "",
    path: app.globalData.url,
    userName: "",
    userId: "",
    score: 10,
    score1: 10,
    id: "",
    kpiId: "",
    state: "",
    startTime: "",
    openscore: false,
    tab: false,
    open: true,
    rejectOpen: false,
    isKPIEdit: true,
    username: "",
    content: "",
    completionStatus: "",
    dep: [],
    workFlowTemp: [],
    movie: [],
    movies: [],
    userInformation: "",
    organizationUnitId: "",
    update: false,
    hiddeName: true,
    hidderule: true,
    hiddedepar: true,
    hiddescore: true,
    hiddeintroduce: true,
    nocancel: true,
    hiddethought: true
  },
  confirm: function confirm() {
    var that = this;
    that.setData({
      hiddeName: true,
      hidderule: true,
      hiddedepar: true,
      hiddescore: true,
      content: that.data.content || that.data.content,
      hiddeintroduce: true,
      completionStatus: that.data.completionStatus || that.data.completionStatus,
      hiddethought: true
    });
  },
  onLoad: function onLoad(options) {
    var that = this;
    var time = that.FormatMonth();
    if (that.data.startTime == "") {
      that.setData({
        startTime: time
      });
    }
    that.setData({
      userName: options.userId ? user.getNameById(options.userId) : user.getNameById(app.globalData.information.id),
      userId: options.userId ? options.userId : app.globalData.information.id,
      organizationUnitId: options.userId ? user.getOUIdById(options.userId) : user.getOUIdById(app.globalData.information.id),
      isKPIEdit: app.globalData.abp && app.globalData.abp.setting.values["Salary.IsKPIEdit"] == "true"
    });
    if (options.id) {
      that.setData({
        state: options.state,
        update: true,
        kpiId: options.id
      });
      that.LoadDatas(options.id);
      return;
    } else if (options.content) {
      path = app.globalData.url + "/api/services/Salary/KpiManage/Create";
      obj = {
        name: that.data.userName ? that.data.userName : "",
        content: that.data.content,
        userId: that.data.userId,
        creatorUserId: app.globalData.information.id,
        date: that.data.startTime,
        organizationUnitId: that.data.organizationUnitId,
        score: that.data.score,
        score1: that.data.score1,
        image: that.data.srcs,
        completionStatus: that.data.completionStatus ? that.data.completionStatus : ""
      };
      util.request(path, obj).then(function(res) {
        if (res.success) {
          that.setData({
            kpiId: res.result.id
          });
          wx.showModal({
            title: '提示信息',
            content: "保存成功！",
            showCancel: false
          });
          wx.navigateBack(1);
          return;
        }
        //res = "";
      }, function(error) {
        wx.showModal({
          title: '错误信息',
          content: error.error.message,
          showCancel: false
        });
      });
    } else {
      return;
    }
  },
  //格式时间
  FormatTime: function FormatTime(time) {
    if (time.length >= 7) {
      return time.substring(0, 4) + "-" + time.substring(5, 7);
    } else {
      return time;
    }
  },
  FormatMonth: function FormatMonth() {
    var date = new Date();
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    m = m < 10 ? '0' + m : m;
    return y + "-" + m;
  },
  LoadDatas: function LoadDatas(id) {
    var that = this;
    var path = app.globalData.url + "/api/services/Salary/KpiManage/Get";
    var obj = {
      Id: id
    };
    var Get = util.getQueryUrl(path, obj);
    util.request(Get).then(function(res) {
      if (res.success) {
        content = "<img class='adjunct' src='" + that.data.path + "/Files/File/Image?FileName=" + res.result.image + "'>";
        WxParse.wxParse('topicDetail', 'html', content, that);
        that.setData({
          userName: res.result.name,
          userId: res.result.userId,
          startTime: that.FormatTime(res.result.date),
          content: res.result.content,
          score: res.result.score,
          organizationUnitId: res.result.organizationUnitId,
          srcs: res.result.image,
          state: res.result.state
        });
      }
    });
  },
  click: function click() {
    var that = this;
    wx.chooseImage({
      count: 1,
      // 默认9  
      sizeType: ['original', 'compressed'],
      // 可以指定是原图还是压缩图，默认二者都有  
      sourceType: ['album', 'camera'],
      // 可以指定来源是相册还是相机，默认二者都有  
      success: function success(res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片  
        var tempFilePaths = res.tempFilePaths;
        that.upload(that, tempFilePaths);
      }
    });
  },
  upload: function upload(page, path) {
    wx.showToast({
      icon: "loading",
      title: "正在上传"
    }), wx.uploadFile({
      url: app.globalData.url + "/Files/File/UploadFile",
      filePath: path[0],
      name: 'file',
      header: {
        "Content-Type": "multipart/form-data"
      },
      formData: {
        //和服务器约定的token, 一般也可以放在header中
        'session_token': wx.getStorageSync('session_token')
      },
      success: function success(res) {
        var json = JSON.parse(res.data);
        if (json.success) {
          content = "<img class='adjunct' src='" + page.data.path + "/Files/File/Image?FileName=" + json.result.fileNames[0] + "'>";
          WxParse.wxParse('topicDetail', 'html', content, page);
          page.setData({
            //上传成功修改显示头像
            src: "/Files/File/Image?FileName=" + json.result.fileNames,
            srcs: json.result.fileNames[0]
          });
        } else {
          wx.showModal({
            title: '提示',
            content: '上传失败',
            showCancel: false
          });
          return;
        }
      },
      fail: function fail(e) {
        wx.showModal({
          title: '提示',
          content: '上传失败',
          showCancel: false
        });
      },
      complete: function complete() {
        wx.hideToast(); //隐藏Toast
      }
    });
  },

  username: function username() {
    var that = this;
    that.setData({
      hiddeName: false
    });
    var path = app.globalData.url + "/api/services/Foundation/User/GetUsers";
    var obj = {
      Filter: "",
      Permission: "",
      Role: "",
      Sorting: "",
      MaxResultCount: 2000,
      SkipCount: 1
    };
    util.request(path, obj, "Get").then(function(res) {
      that.setData({
        movie: res.result.items
      });
    });
  },
  hiddeintroduce: function hiddeintroduce() {
    var that = this;
    that.setData({
      introduces: that.data.introduce,
      hiddeintroduce: false
    });
  },
  hiddethought: function hiddethought() {
    var that = this;
    that.setData({
      thoughts: that.data.thought,
      hiddethought: false
    });
  },
  bindContentInput: function bindContentInput(e) {
    var that = this;
    this.setData({
      content: e.detail.value
    });
  },
  bindCompletionStatusInput: function bindCompletionStatusInput(e) {
    var that = this;
    this.setData({
      completionStatus: e.detail.value
    });
  },
  datePicker: function datePicker(e) {
    this.setData({
      startTime: e.detail.value
    });
  },
  prevNum: function prevNum() {
    this.setData({
      score: this.data.score + 1
    });
  },
  nextNum: function nextNum() {
    this.setData({
      score: this.data.score - 1
    });
  },
  //根据用户信息查询数据
  get: function get() {
    var that = this;
    var UserList = app.cache.users;
    var UserLists = [];
    var _iterator = _createForOfIteratorHelper2(UserList),
      _step;
    try {
      for (_iterator.s(); !(_step = _iterator.n()).done;) {
        var item = _step.value;
        if (item.name.indexOf(that.data.userInformation) > -1 && item.name != "admin") {
          UserLists.push(item);
        }
      }
    } catch (err) {
      err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
      _iterator.e(err);
    } finally {
      _iterator.f();
    }
    that.setData({
      movie: UserLists
    });
  },
  buttonsave: function buttonsave(options) {
    var that = this;
    if (that.data.userName == '用户' || !that.data.score || !that.data.score1 || !that.data.content || !that.data.startTime) {
      wx.showModal({
        title: '错误信息',
        content: '请补充完数据~~',
        showCancel: false
      });
      return;
    }
    that.setData({
      open: false
    });
    var path;
    var obj;
    if (that.data.state == "130008010" || that.data.state == "130008005" && that.data.update == true) {
      path = app.globalData.url + "/api/services/Salary/KpiManage/Update";
      obj = {
        id: that.data.kpiId,
        name: that.data.userName ? that.data.userName : "",
        content: that.data.content,
        userId: that.data.userId,
        creatorUserId: app.globalData.information.id,
        state: "130008005",
        date: that.data.startTime,
        organizationUnitId: that.data.organizationUnitId,
        score: that.data.score,
        score1: that.data.score1,
        image: that.data.srcs,
        completionStatus: that.data.completionStatus ? that.data.completionStatus : ""
      };
    } else {
      path = app.globalData.url + "/api/services/Salary/KpiManage/Create";
      obj = {
        name: that.data.userName ? that.data.userName : "",
        content: that.data.content,
        userId: that.data.userId,
        creatorUserId: app.globalData.information.id,
        date: that.data.startTime,
        organizationUnitId: that.data.organizationUnitId,
        score: that.data.score,
        score1: that.data.score1,
        image: that.data.srcs,
        completionStatus: that.data.completionStatus ? that.data.completionStatus : ""
      };
    }
    util.request(path, obj).then(function(res) {
      if (res.success) {
        that.setData({
          kpiId: res.result.id
        });
        wx.showModal({
          title: '提示信息',
          content: "保存成功！",
          showCancel: false
        });
        wx.navigateBack(1);
        return;
      }
      //res = "";
    }, function(error) {
      wx.showModal({
        title: '错误信息',
        content: error.error.message,
        showCancel: false
      });
    });
  }
});