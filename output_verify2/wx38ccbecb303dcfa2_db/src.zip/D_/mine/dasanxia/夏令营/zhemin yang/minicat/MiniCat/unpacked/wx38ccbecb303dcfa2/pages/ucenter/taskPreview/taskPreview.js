var _createForOfIteratorHelper2 = require("../../../@babel/runtime/helpers/createForOfIteratorHelper");
var util = require('../../../utils/util.js');
var user = require('../../../utils/cache/user.js');
var WxParse = require('../../../lib/wxParse/wxParse.js');
var app = getApp();
var content = "";
Page({
  data: {
    checkedname: false,
    checked: false,
    src: "",
    srcs: "",
    path: app.globalData.url,
    department: "规则管理",
    ruleClassify: "规则分类",
    userName: "",
    userId: "",
    PublishUserName: "",
    PbulishuserId: "",
    score: "",
    scores: "-----请选择------",
    scoreTemplateId: "",
    id: "",
    TaskManageId: "",
    startTime: "",
    endTime: "",
    openscore: false,
    tab: false,
    open: true,
    username: '',
    introduce: '',
    introduces: "",
    Publishintroduce: '',
    Publishintroduces: "",
    thought: '',
    thoughts: "",
    scoreRuleId: "",
    scoreTemplateItemId: "",
    TeamId: "",
    TaskManage: "",
    taskManagescore: "",
    dep: [],
    ruleClassifys: [],
    workFlowTemp: [],
    movie: [],
    movies: [],
    department1: "选择部门",
    ruleClassifyId: "",
    depid: "",
    userInformation: "",
    organizationUnitId: "",
    update: false,
    hiddeName: true,
    hidderule: true,
    hiddedepar: true,
    hiddescore: true,
    hiddeintroduce: true,
    nocancel: true,
    hiddethought: true,
    openstate: false
  },
  confirm: function confirm() {
    var that = this;
    that.setData({
      hiddeName: true,
      hidderule: true,
      hiddedepar: true,
      hiddescore: true,
      Publishintroduce: that.data.Publishintroduces || that.data.Publishintroduce,
      hiddeintroduce: true,
      thought: that.data.thoughts || that.data.thought,
      hiddethought: true
    });
  },
  onLoad: function onLoad(options) {
    var that = this;
    var time = that.FormatTime();
    if (that.data.startTime == "") {
      that.setData({
        startTime: time
      });
    }
    that.setData({
      scoreDateIsToday: app.globalData.abp && app.globalData.abp.setting.values["Score.ScoreDateIsToday"] == "true"
    });
    var path = app.globalData.url + "/api/services/WorkFlow/WFTemplate/GetWFTemplateByType";
    var obj = {
      Type: "160205001",
      Param: "",
      organizationUnitId: app.globalData.information.organizationUnitId,
      pageSize: 999
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      that.setData({
        workFlowTemp: res.result
      });
    });
    if (options.id) {
      that.setData({
        update: true,
        TaskManageId: options.id
      });
      that.LoadDatas(options.id);
      return;
    } else {
      that.LoadData();
      return;
    }
  },
  //格式时间
  FormatTime: function FormatTime() {
    var date = new Date();
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    m = m < 10 ? '0' + m : m;
    var d = date.getDate();
    d = d < 10 ? '0' + d : d;
    return y + "-" + m + "-" + d;
  },
  LoadData: function LoadData() {
    var that = this;
    var path = app.globalData.url + "/api/services/Score/TaskManage/GetAll";
    var obj = {
      searchGroup: {
        rules: [{
          field: "creatorUserId",
          value: app.globalData.information.id
        }, {
          field: "state",
          value: "130008000"
        }],
        sorting: "CreationTime DESC",
        pageSize: 1
      }
    };
    util.request(path, obj).then(function(res) {
      if (res.success && res.result.totalCount > 0) {
        content = "<img class='adjunct' src='" + "http://file.sinpedo.com/" + res.result.items[0].publishImage + "'>";
        WxParse.wxParse('topicDetail', 'html', content, that);
        that.setData({
          TaskManageId: res.result.items[0].id,
          PublishUserName: res.result.items[0].publishUserName,
          PublishuserId: res.result.items[0].publishUserId,
          department: res.result.items[0].scoreRuleName,
          startTime: res.result.items[0].startDate,
          endTime: res.result.items[0].endDate,
          Publishintroduce: res.result.items[0].publishIntroduce,
          scoreRuleId: res.result.items[0].scoreRuleId,
          scoreTemplateItemId: res.result.items[0].scoreTemplateItemId,
          taskManagescore: res.result.items[0].score,
          scores: res.result.items[0].scoreTemplateItemName,
          checked: res.result.items[0].isSubjoinScore,
          srcs: res.result.items[0].publishImage,
          userName: res.result.items[0].name,
          TeamId: res.result.items[0].teamId,
          update: true
        });
      }
    });
  },
  LoadDatas: function LoadDatas(id) {
    var that = this;
    var path = app.globalData.url + "/api/services/Score/TaskManage/Get";
    var obj = {
      Id: id
    };
    var Get = util.getQueryUrl(path, obj);
    util.request(Get).then(function(res) {
      if (res.success) {
        content = "<img class='adjunct' src='" + that.data.path + "/Files/File/Image?FileName=" + res.result.publishImage + "'>";
        WxParse.wxParse('topicDetail', 'html', content, that);
        that.setData({
          PublishUserName: res.result.publishUserName,
          PublishuserId: res.result.userId,
          department: res.result.scoreRuleName,
          startTime: res.result.startDate,
          endTime: res.result.endDate,
          Publishintroduce: res.result.publishIntroduce,
          scoreRuleId: res.result.scoreRuleId,
          scoreTemplateItemId: res.result.scoreTemplateItemId,
          taskManagescore: res.result.score,
          scores: res.result.scoreTemplateItemName,
          checked: res.result.isSubjoinScore,
          userName: res.result.name ? res.result.name : "",
          TeamId: res.result.teamId,
          srcs: res.result.publishImage
        });
        /* console.log(that.data.PublishuserId);
        console.log(app.globalData.information.id);
        console.log(that.data.PublishUserName);
        console.log(user.getNameById(app.globalData.information.id)); */
      }
    });
  },

  click: function click() {
    var that = this;
    wx.chooseImage({
      count: 1,
      // 默认9  
      sizeType: ['original', 'compressed'],
      // 可以指定是原图还是压缩图，默认二者都有  
      sourceType: ['album', 'camera'],
      // 可以指定来源是相册还是相机，默认二者都有  
      success: function success(res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片  
        var tempFilePaths = res.tempFilePaths;
        that.upload(that, tempFilePaths);
      }
    });
  },
  upload: function upload(page, path) {
    wx.showToast({
      icon: "loading",
      title: "正在上传"
    }), wx.uploadFile({
      url: app.globalData.url + "/Files/File/UploadFile",
      filePath: path[0],
      name: 'file',
      header: {
        "Content-Type": "multipart/form-data"
      },
      formData: {
        //和服务器约定的token, 一般也可以放在header中
        'session_token': wx.getStorageSync('session_token')
      },
      success: function success(res) {
        var json = JSON.parse(res.data);
        if (json.success) {
          content = "<img class='adjunct' src='" + page.data.path + "/Files/File/Image?FileName=" + json.result.fileNames[0] + "'>";
          WxParse.wxParse('topicDetail', 'html', content, page);
          page.setData({
            //上传成功修改显示头像
            src: "/Files/File/Image?FileName=" + json.result.fileNames,
            srcs: json.result.fileNames[0]
          });
        } else {
          wx.showModal({
            title: '提示',
            content: '上传失败',
            showCancel: false
          });
          return;
        }
      },
      fail: function fail(e) {
        wx.showModal({
          title: '提示',
          content: '上传失败',
          showCancel: false
        });
      },
      complete: function complete() {
        wx.hideToast(); //隐藏Toast
      }
    });
  },

  switchd: function switchd(e) {
    var that = this;
    that.setData({
      checkedname: e.detail.value
    });
  },
  username: function username() {
    var that = this;
    that.setData({
      hiddeName: false
    });
    var path = app.globalData.url + "/api/services/Foundation/User/GetUsers";
    var obj = {
      Filter: "",
      Permission: "",
      Role: "",
      Sorting: "",
      MaxResultCount: 999,
      SkipCount: 1
    };
    util.request(path, obj, "Get").then(function(res) {
      that.setData({
        movie: res.result.items
      });
    });
  },
  userone: function userone(e) {
    this.setData({
      userName: e.currentTarget.dataset.name,
      userId: e.currentTarget.dataset.id,
      organizationUnitId: e.currentTarget.dataset.organizationunitid,
      hiddeName: true
    });
  },
  viewtask: function viewtask(e) {
    var that = this;
    wx.navigateTo({
      url: '/pages/ucenter/taskPlan/taskPlan?id=' + that.data.TeamId
    });
  },
  hiddeintroduce: function hiddeintroduce() {
    var that = this;
    that.setData({
      Publishintroduces: that.data.Publishintroduce,
      hiddeintroduce: false
    });
  },
  hiddethought: function hiddethought() {
    var that = this;
    that.setData({
      thoughts: that.data.thought,
      hiddethought: false
    });
  },
  ruleClassify: function ruleClassify() {
    this.setData({
      hidderule: false
    });
    var that = this;
    var path = app.globalData.url + "/api/services/CodeData/CodeData/GetAll";
    var obj = {
      searchGroup: {
        rules: [{
          field: "codeDataTypeId",
          value: 200011
        }]
      },
      pageSize: 999
    };
    util.request(path, obj, "Get").then(function(res) {
      that.setData({
        ruleClassifys: res.result.items
      });
    });
  },
  ruleone: function ruleone(e) {
    this.setData({
      hidderule: true,
      ruleClassify: e.currentTarget.dataset.name,
      ruleClassifyId: e.currentTarget.dataset.id,
      department: ""
      //scoreRuleId: e.currentTarget.dataset.scoreruleid
    });
  },

  department: function department() {
    if (this.data.ruleClassify == "规则分类") {
      wx.showModal({
        title: '提示消息',
        content: '请选择规则管理',
        showCancel: false
      });
      return;
    }
    this.setData({
      hiddedepar: false
    });
    var that = this;
    var path = app.globalData.url + "/api/services/Score/ScoreRule/GetAll";
    var obj = {
      searchGroup: {
        rules: [{
          field: "ruleClassify",
          value: that.data.ruleClassifyId
        }]
      },
      pageSize: 999
    };
    util.request(path, obj, "Get").then(function(res) {
      that.setData({
        movies: res.result.items
      });
    });
  },
  one: function one(e) {
    this.setData({
      department: e.currentTarget.dataset.name,
      hiddedepar: true,
      scoreRuleId: e.currentTarget.dataset.scoreruleid,
      scores: "",
      scoreTemplateItemId: "",
      gradeManagescore: ""
    });
    var that = this;
    var path = app.globalData.url + "/api/services/Score/ScoreTemplate/GetItemsById";
    var obj = {
      id: e.currentTarget.dataset.id
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      that.setData({
        score: res.result,
        tab: true
      });
    });
  },
  scoretap: function scoretap(e) {
    if (!this.data.department) {
      wx.showModal({
        title: '提示消息',
        content: '请先选择哲学',
        showCancel: false
      });
      return;
    }
    this.setData({
      hiddescore: false
    });
  },
  scoreone: function scoreone(e) {
    this.setData({
      scores: e.currentTarget.dataset.name,
      hiddescore: true,
      scoreTemplateItemId: e.currentTarget.dataset.id,
      taskManagescore: e.currentTarget.dataset.score
    });
  },
  bindUsernameInput: function bindUsernameInput(e) {
    this.setData({
      username: e.detail.value
    });
  },
  bindIntroduceInput: function bindIntroduceInput(e) {
    var that = this;
    this.setData({
      Publishintroduces: e.detail.value
    });
  },
  bindThoughtInput: function bindThoughtInput(e) {
    var that = this;
    this.setData({
      thoughts: e.detail.value
    });
  },
  datePicker: function datePicker(e) {
    this.setData({
      startTime: e.detail.value
    });
  },
  datePicker1: function datePicker1(e) {
    this.setData({
      endTime: e.detail.value
    });
  },
  //获取输入的用户信息
  input: function input(e) {
    this.setData({
      userInformation: e.detail.value
    });
  },
  //根据用户信息查询数据
  get: function get() {
    var that = this;
    var UserList = app.cache.users;
    var UserLists = [];
    var _iterator = _createForOfIteratorHelper2(UserList),
      _step;
    try {
      for (_iterator.s(); !(_step = _iterator.n()).done;) {
        var item = _step.value;
        if (item.name.indexOf(that.data.userInformation) > -1 && item.name != "admin") {
          UserLists.push(item);
        }
      }
    } catch (err) {
      err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
      _iterator.e(err);
    } finally {
      _iterator.f();
    }
    that.setData({
      movie: UserLists
    });
  },
  buttoncancel: function buttoncancel(options) {
    console.log(this.data.PublishUserName);
    console.log(user.getNameById(app.globalData.information.id));
    //wx.navigateBack(1);   
  },

  accept: function accept(e) {
    var that = this;
    if (that.data.PublishUserName == user.getNameById(app.globalData.information.id)) {
      wx.navigateBack(1);
      wx.showModal({
        title: '提示信息',
        content: "不能抢自己发布的任务！"
      });
    } else {
      var path = app.globalData.url + "/api/services/Score/TaskManage/GrabTask";
      /* var obj =  { id: that.data.TaskManageId, name: user.getNameById(app.globalData.information.id), userId: app.globalData.information.id,   state: "130008010", organizationUnitId: app.globalData.information.organizationUnitId,isSubjoinScore: that.data.checked ? "true" : "false", scoreRuleId: that.data.scoreRuleId, scoreTemplateItemId: that.data.scoreTemplateItemId,  startDate: that.data.startTime,endDate: that.data.endTime,  score: that.data.taskManagescore, publishimage: that.data.srcs, publishintroduce: that.data.Publishintroduce ? that.data.Publishintroduce : "" }; */
      var obj = {
        id: that.data.TaskManageId,
        publishUserId: that.data.PublishUserId,
        publishUserName: that.data.PublishUserName,
        name: user.getNameById(app.globalData.information.id),
        userId: app.globalData.information.id,
        creatorUserId: that.data.PublishUserId,
        isSubjoinScore: that.data.checked ? "true" : "false",
        scoreRuleId: that.data.scoreRuleId,
        scoreTemplateItemId: that.data.scoreTemplateItemId,
        state: "130008010",
        startDate: that.data.startTime,
        endDate: that.data.endTime,
        organizationUnitId: app.globalData.information.organizationUnitId,
        score: that.data.taskManagescore,
        teamId: that.data.TeamId,
        publishimage: that.data.srcs,
        publishintroduce: that.data.Publishintroduce ? that.data.Publishintroduce : ""
      };
      wx.navigateBack(1);
      util.request(path, obj).then(function(res) {
        if (res.success) {
          wx.showModal({
            title: '提示信息',
            content: "抢任务成功，请尽快完成任务提交审核！"
          });
        }
      }, function(error) {
        wx.showModal({
          title: '错误信息',
          content: error.error.message,
          showCancel: false
        });
      });
    }
  }
});