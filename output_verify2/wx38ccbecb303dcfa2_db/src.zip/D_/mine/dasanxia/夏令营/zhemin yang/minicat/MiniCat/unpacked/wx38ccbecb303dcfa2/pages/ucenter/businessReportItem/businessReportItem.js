var _createForOfIteratorHelper2 = require("../../../@babel/runtime/helpers/createForOfIteratorHelper");
var app = getApp();
var WxParse = require('../../../lib/wxParse/wxParse.js');
var util = require('../../../utils/util.js');
var department = require('../../../utils/cache/department.js');
Page({
  data: {
    BusinessRepor: []
  },
  onLoad: function onLoad(options) {
    var that = this;
    var parentKey = options.ouId.substr(0, options.ouId.indexOf("_"));
    var startTime = options.startTime;
    var endTime = options.endTime;
    var category = options.category;
    if (startTime == "请选择时间") {
      startTime = "";
    }
    if (endTime == "请选择时间") {
      endTime = "";
    }
    var path = app.globalData.url + "/api/services/Finace/Report/GetBusinessReporAccount";
    var obj = {
      ouId: parentKey,
      startTime: startTime,
      endTime: endTime,
      category: category
    };
    var GetData = util.getQueryUrl(path, obj);
    util.request(GetData).then(function(res) {
      if (res.success) {
        var _iterator = _createForOfIteratorHelper2(res.result),
          _step;
        try {
          for (_iterator.s(); !(_step = _iterator.n()).done;) {
            var item = _step.value;
            item.total = Math.round(item.total * 100) / 100;
          }
        } catch (err) {
          err = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(err);
          _iterator.e(err);
        } finally {
          _iterator.f();
        }
        that.setData({
          BusinessRepor: res.result
        });
      }
    });
  }
});