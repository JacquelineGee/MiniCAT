var util = require('../../../utils/util.js');
var user = require('../../../utils/cache/user.js');
var WxParse = require('../../../lib/wxParse/wxParse.js');
var app = getApp();
Page({
  data: {
    currentPassword: "",
    newPassword: "",
    newPasswords: ""
  },
  onLoad: function onLoad(options) {},
  bindPasswordInput: function bindPasswordInput(e) {
    this.setData({
      currentPassword: e.detail.value
    });
  },
  bindNewPasswordInput: function bindNewPasswordInput(e) {
    this.setData({
      newPassword: e.detail.value
    });
  },
  bindNewPasswordsInput: function bindNewPasswordsInput(e) {
    this.setData({
      newPasswords: e.detail.value
    });
  },
  startLogin: function startLogin() {
    var that = this;
    var path = app.globalData.url + "/api/services/Foundation/Profile/ChangePassword";
    var obj = {
      currentPassword: that.data.currentPassword,
      newPassword: that.data.newPasswords
    };
    util.request(path, obj).then(function(res) {
      if (res.success) {
        wx.redirectTo({
          url: '/pages/auth/login/login'
        });
      }
    }, function(error) {
      wx.showModal({
        title: '错误信息',
        content: error.error.message,
        showCancel: false
      });
    });
  }
});