function a(a) {
  return !t.globalData.userData.fplockpasswdlist || (delete t.globalData.userData.fplockpasswdlist[a], wx.setStorageSync("fplockpasswd", t.globalData.userData.fplockpasswdlist), !0)
}
var t = getApp();
module.exports = {
  readFplock: function() {
    return !1
  },
  delFplock: function(l) {
    var e;
    if (!t.globalData.userData.fplocklistFlag) return wx.removeStorageSync("fplock"), !1;
    for (e in l) t.globalData.userData.fplocklist[l[e]] && (delete t.globalData.userData.fplocklist[l[e]], a(l[e]));
    return wx.setStorageSync("fplock", t.globalData.userData.fplocklist), !0
  },
  chgFplock: function(a, l) {
    if (!t.globalData.userData.fplocklistFlag) return !1;
    if (t.globalData.userData.fplocklist[a])
      for (var e in l) t.globalData.userData.fplocklist[a][e] = l[e];
    return wx.setStorageSync("fplock", t.globalData.userData.fplocklist), !0
  },
  addFplock: function(a, l) {
    if (t.globalData.userData.fplocklist) a && (t.globalData.userData.fplocklist[a] = l);
    else {
      var e = {};
      a ? (e[a] = l, t.globalData.userData.fplocklist = e) : t.globalData.userData.fplocklist = e
    }
    return wx.setStorageSync("fplock", t.globalData.userData.fplocklist), !0
  },
  readFplockPasswd: function() {
    try {
      var a = wx.getStorageSync("fplockpasswd");
      return !!a && (t.globalData.userData.fplockpasswdlist = a, !0)
    } catch (a) {
      return !1
    }
  },
  chgFplockPasswd: function(a, l) {
    return t.globalData.userData.fplockpasswdlist || (t.globalData.userData.fplockpasswdlist = {}), t.globalData.userData.fplockpasswdlist[a] = l, wx.setStorageSync("fplockpasswd", t.globalData.userData.fplockpasswdlist), !0
  },
  delFplockPasswd: a,
  readGateway: function() {
    return !1
  },
  delGateway: function(a) {
    var l;
    if (!t.globalData.userData.gatewaylistFlag) return wx.removeStorageSync("gateway"), !1;
    for (l in a)
      if (t.globalData.userData.gatewaylist[a[l]]) {
        for (var e in t.globalData.userData.fplocklist) t.globalData.userData.fplocklist[e].gateway == a[l] && delete t.globalData.userData.fplocklist[e];
        delete t.globalData.userData.gatewaylist[a[l]]
      } return wx.setStorageSync("gateway", t.globalData.userData.gatewaylist), wx.setStorageSync("fplock", t.globalData.userData.fplocklist), !0
  },
  chgGateway: function(a, l) {
    return !!t.globalData.userData.gatewaylistFlag && (t.globalData.userData.gatewaylist[a] && (t.globalData.userData.gatewaylist[a] = l), wx.setStorageSync("gateway", t.globalData.userData.gatewaylist), !0)
  },
  addGateway: function(a, l) {
    if (t.globalData.userData.gatewaylist) a && (t.globalData.userData.gatewaylist[a] = l);
    else {
      var e = {};
      a ? (e[a] = l, t.globalData.userData.gatewaylist = e) : t.globalData.userData.gatewaylist = e
    }
    return wx.setStorageSync("gateway", t.globalData.userData.gatewaylist), !0
  },
  userDataDefault: function() {
    t.globalData.userData.fplocklistFlag = !1, t.globalData.userData.fplocklist = null, t.globalData.userData.gatewaylistFlag = !1, t.globalData.userData.gatewaylist = null
  },
  userDataClear: function() {
    wx.removeStorageSync("fplock"), wx.removeStorageSync("gateway"), wx.removeStorageSync("dynamicKeys"), wx.removeStorageSync("visitorKeys"), wx.removeStorageSync("visitorKeysDuration")
  },
  findGatewayFromName: function(a) {
    if (!t.globalData.userData.gatewaylistFlag) return null;
    for (var l in t.globalData.userData.gatewaylist)
      if (t.globalData.userData.gatewaylist[l].name == a) return l;
    return null
  },
  getGatewayLength: function() {
    for (var a in t.globalData.userData.gatewaylist)
      if ("虚拟网关" == t.globalData.userData.gatewaylist[a].name) return Object.keys(t.globalData.userData.gatewaylist).length - 1;
    return Object.keys(t.globalData.userData.gatewaylist).length
  }
};