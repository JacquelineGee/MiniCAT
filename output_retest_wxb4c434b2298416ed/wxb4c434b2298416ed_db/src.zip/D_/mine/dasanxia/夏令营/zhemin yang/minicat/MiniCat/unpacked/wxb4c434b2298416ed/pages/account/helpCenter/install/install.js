require("../../../../80E7AA76438FECAFE681C27142BA10C4.js"), require("../../../../4E9A06A0438FECAF28FC6EA7F19A10C4.js");
var e = getApp();
Page({
  data: {
    list: [{
      url: "../../helpCenter/webView/webView",
      text: "锁体安装",
      webViewURL: "https://www.samcharm.com/weapp/install/lockbody/"
    }, {
      url: "../../helpCenter/webView/webView",
      text: "S3面板安装",
      webViewURL: "https://www.samcharm.com/weapp/install/s3panel/"
    }]
  },
  onLoad: function(e) {},
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  navBindtap: function(t) {
    e.globalData.webViewURL = this.data.list[t.currentTarget.dataset.id].webViewURL, wx.navigateTo({
      url: "../../helpCenter/webView/webView"
    })
  },
  onShareAppMessage: function() {}
});