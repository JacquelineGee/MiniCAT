var e = require("../../../438C6F16438FECAF25EA07112F9A10C4.js"),
  a = require("../../../80E7AA76438FECAFE681C27142BA10C4.js"),
  t = require("../../../978419B7438FECAFF1E271B0924A10C4.js"),
  r = getApp();
Page({
  data: {
    userCode: "",
    userCode_warn: "",
    userCode_errmsg: "",
    serialnum: "",
    uid: null,
    recipient: "",
    errflag: !1,
    errmsg: "",
    longTime: !1,
    dateTimeArrayStart: null,
    dateTimeStart: null,
    dateTimeArrayEnd: null,
    dateTimeEnd: null,
    startTime: null,
    endTime: null,
    startYear: 2e3,
    endYear: 2050
  },
  onLoad: function(e) {
    var r = t.dateTimePicker(this.data.startYear, this.data.endYear),
      i = t.customTime(r.dateTimeArray, r.dateTime).customTime,
      s = a.formatCustomTime(new Date(Date.parse(i.replace(/-/g, "/")) + 864e5), "yyyy-MM-dd hh:mm:ss"),
      d = t.dateTimePicker(this.data.startYear, this.data.endYear, s),
      n = (r.dateTimeArray.pop(), r.dateTime.pop(), d.dateTimeArray.pop(), d.dateTime.pop(), i.slice(0, 16)),
      m = s.slice(0, 16);
    this.setData({
      dateTimeStart: r.dateTime,
      dateTimeArrayStart: r.dateTimeArray,
      dateTimeEnd: d.dateTime,
      dateTimeArrayEnd: d.dateTimeArray,
      startTime: n,
      endTime: m,
      serialnum: e.serialnum,
      uid: e.uid
    })
  },
  changeDateTimeStart: function(e) {
    var a = t.customTime(this.data.dateTimeArrayStart, e.detail.value).customTime;
    this.setData({
      startTime: a
    })
  },
  changeDateTimeColumnStart: function(e) {
    var a = this.data.dateTimeStart,
      r = this.data.dateTimeArrayStart;
    a[e.detail.column] = e.detail.value, r[2] = t.getMonthDay(r[0][a[0]], r[1][a[1]]), this.setData({
      dateTimeArrayStart: r,
      end_date_warn: "",
      errmsg: ""
    })
  },
  changeDateTimeEnd: function(e) {
    var a = t.customTime(this.data.dateTimeArrayEnd, e.detail.value).customTime;
    this.setData({
      endTime: a
    })
  },
  changeDateTimeColumnEnd: function(e) {
    var a = this.data.dateTimeEnd,
      r = this.data.dateTimeArrayEnd;
    a[e.detail.column] = e.detail.value, r[2] = t.getMonthDay(r[0][a[0]], r[1][a[1]]), this.setData({
      dateTimeArrayEnd: r,
      end_date_warn: "",
      errmsg: ""
    })
  },
  scanQRCode: function(a) {
    var t = this;
    this.setData({
      userCode_warn: "",
      userCode_errmsg: ""
    }), wx.scanCode({
      success: function(a) {
        try {
          for (var i = e.enc.Utf8.parse(r.globalData.desKey), s = e.DES.decrypt(a.result, i, {
              mode: e.mode.ECB,
              padding: e.pad.Pkcs7
            }).toString(), d = "", n = 0; n < s.length; n += 2) d += String.fromCharCode(parseInt(s.slice(n, n + 2), 16));
          var m = JSON.parse(d),
            o = new Date(1970, 0, 1),
            u = Math.floor((Date.now() - o) / 6e4);
          if (u >= parseInt(m.beginTimeMin) && u <= parseInt(m.expireTimeMin)) {
            var l = m.data.substr(0, 6) + "********" + m.data.substr(-6, 6);
            t.setData({
              recipient: m.data,
              userCode: l,
              errflag: !1
            })
          } else t.setData({
            errflag: !0,
            errmsg: "二维码失效"
          })
        } catch (e) {
          t.setData({
            errflag: !0,
            errmsg: "数据非法"
          })
        }
      }
    })
  },
  serialnumInput: function(e) {
    this.setData({
      recipient: e.detail.value,
      errflag: !1
    })
  },
  addUserBtn: function() {
    var e = this;
    if ("" != this.data.userCode) {
      var a = {
        fplock: this.data.serialnum,
        recipient: this.data.recipient,
        forever: this.data.longTime
      };
      if (0 == this.data.longTime) {
        var i = t.customTime(this.data.dateTimeArrayStart, this.data.dateTimeStart).customTime,
          s = t.customTime(this.data.dateTimeArrayEnd, this.data.dateTimeEnd).customTime;
        if (Date.parse(s.replace(/-/g, "/")) - Date.parse(i.replace(/-/g, "/")) <= 0) return void this.setData({
          end_date_warn: "weui-cell_warn",
          errmsg: "请输入有效时间段"
        });
        a.beginTime = i, a.endTime = s
      }
      a.authortype = 2, a.renter_uid = parseInt(this.data.uid), wx.request({
        url: r.globalData.gburl + "wxxcx/GYadd_fpauthorize/" + r.globalData.gbvendor,
        method: "POST",
        header: {
          "content-type": "application/json",
          Authorization: r.globalData.token
        },
        data: a,
        success: function(a) {
          0 == a.data.errcode ? wx.showModal({
            title: "提示",
            content: "添加用户命令发送成功，请等待门锁同步信息",
            showCancel: !1,
            success: function(e) {
              wx.navigateBack()
            }
          }) : -2 == a.data.errcode ? e.setData({
            errflag: !0,
            errmsg: a.data.errtype
          }) : e.setData({
            errflag: !0,
            errmsg: "通信失败"
          })
        }
      })
    } else this.setData({
      userCode_warn: "weui-cell_warn",
      userCode_errmsg: "请输入用户识别码"
    })
  }
});