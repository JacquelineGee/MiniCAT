var t = require("../../../80E7AA76438FECAFE681C27142BA10C4.js"),
  a = getApp();
Page({
  data: {
    serialnum: "",
    start_date: t.formatCustomTime(new Date, "yyyy-MM-dd"),
    end_date: t.formatCustomTime(new Date, "yyyy-MM-dd"),
    unLockRecords: {},
    curRecordMaxTime: 0,
    unLockLog: []
  },
  onLoad: function(t) {
    var e;
    e = void 0 !== t.serialnum ? t.serialnum : a.globalData.curlockSerialnum, this.setData({
      serialnum: e
    }), this.queryUnlockRecord()
  },
  queryUnlockRecord: function() {
    var t = this,
      e = new Date("1970/1/1 00:00:00"),
      n = 60 * (new Date).getTimezoneOffset(),
      d = (new Date(this.data.start_date) - e) / 1e3 + n,
      i = (new Date(this.data.end_date) - e) / 1e3 + n + 86400;
    wx.request({
      url: a.globalData.gburl + "wxxcx/GYGetRecord/" + a.globalData.gbvendor,
      method: "POST",
      header: {
        "content-type": "application/json",
        Authorization: a.globalData.token
      },
      data: {
        fpSerialnum: t.data.serialnum,
        beginTimeSec: d,
        endTimeSec: i
      },
      success: function(a) {
        var e = [];
        if (0 == a.data.errcode)
          for (var n = 0; n < a.data.data.length; n++) e.push([a.data.data[n].time, a.data.data[n].uid, a.data.data[n].name]);
        t.data.unLockRecords[t.data.serialnum] = e, t.syncDispUnlockRecord()
      },
      fail: function(t) {}
    })
  },
  syncDispUnlockRecord: function() {
    new Date(this.data.start_date);
    for (var a = new Date(this.data.end_date), e = new Date("1970/1/1 00:00:00"), n = this.data.unLockRecords[this.data.serialnum], d = [], i = 60 * (new Date).getTimezoneOffset(), o = new Date(this.data.start_date); o <= a; o.setDate(o.getDate() + 1)) {
      var r = (o - e) / 1e3 + i,
        s = r + 86400,
        u = {
          date: t.formatCustomTime(o, "yyyy-MM-dd"),
          detail: []
        };
      for (var c in n)
        if (n[c][0] >= r && n[c][0] < s) {
          var l = new Date("1970/1/1 00:00:00");
          l.setSeconds(l.getSeconds() + n[c][0]);
          var h = "";
          h = n[c][2].length > 0 ? n[c][2] : n[c][1] >= 101 && n[c][1] <= 105 || n[c][1] >= 126 && n[c][1] < 129 ? "密码用户" : n[c][1].toString();
          var m = "";
          n[c][1] >= 1 && n[c][1] <= 100 ? m = "指纹" : n[c][1] >= 101 && n[c][1] <= 105 ? m = "密码" : n[c][1] >= 106 && n[c][1] <= 115 ? m = "门卡" : n[c][1] >= 116 && n[c][1] <= 125 ? m = "遥控器" : 126 == n[c][1] ? m = "动态授权密码" : 127 == n[c][1] ? m = "计次授权密码" : 128 == n[c][1] ? m = "计时授权密码" : 129 == n[c][1] && (m = "远程开锁"), u.detail.push({
            time: t.formatCustomTime(l, "hh:mm:ss"),
            userID: n[c][1],
            userName: h,
            unLockMethod: m
          })
        } u.detail.sort(function(t, a) {
        return a.time.localeCompare(t.time)
      }), u.detail.length && d.push(u)
    }
    this.setData({
      unLockLog: d
    })
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  bindStartDateChange: function(t) {
    var a = t.detail.value.split("-"),
      e = this.data.end_date.split("-");
    a[0] + a[1] + a[2] > e[0] + e[1] + e[2] && this.setData({
      end_date: t.detail.value
    }), this.data.dateErr && this.setData({
      end_date_warn: "",
      dateErr: !1
    }), this.setData({
      start_date_warn: "",
      errmsg: ""
    }), this.setData({
      start_date: t.detail.value
    })
  },
  bindEndDateChange: function(t) {
    this.data.dateErr && this.setData({
      start_date_warn: "",
      dateErr: !1
    }), this.setData({
      end_date_warn: "",
      errmsg: ""
    }), this.setData({
      end_date: t.detail.value
    })
  },
  checkLogBtn: function(t) {
    this.queryUnlockRecord(), wx.showToast({
      title: "更新成功"
    })
  }
});