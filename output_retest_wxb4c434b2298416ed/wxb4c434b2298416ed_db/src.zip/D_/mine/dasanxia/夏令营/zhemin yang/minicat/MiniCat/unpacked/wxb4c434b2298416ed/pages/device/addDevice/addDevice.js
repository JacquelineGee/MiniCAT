var a = require("../../../4E9A06A0438FECAF28FC6EA7F19A10C4.js"),
  e = require("../../../80E7AA76438FECAFE681C27142BA10C4.js"),
  t = getApp();
Page({
  data: {
    gateways: ["虚拟网关"],
    gatewayIndex: 0,
    nickname: "",
    serialnum: "",
    roomNum: "",
    roomRegion: ["浙江省", "杭州市", "萧山区"],
    roomStreets: ["城厢街道", "北干街道", "蜀山街道", "新塘街道", "义蓬街道", "南阳街道", "靖江街道", "河庄街道", "前进街道", "新湾街道", "临江街道", "闻堰街道", "宁围街道", "新街街道", "河上镇", "戴村镇", "浦阳镇", "进化镇", "临浦镇", "楼塔镇", "义桥镇", "所前镇", "衙前镇", "瓜沥镇", "益农镇", "党湾镇"],
    roomStreetIndex: 13,
    roomAddress: "",
    nickname_warn: "",
    serialnum_warn: "",
    roomNum_warn: "",
    roomRegion_warn: "",
    roomAddress_warn: "",
    errflag: !1,
    errmsg: ""
  },
  onLoad: function(a) {
    if (t.globalData.unionid) {
      t.globalData.userData.gatewaylistFlag || e.resyncUserData();
      for (var n in t.globalData.userData.gatewaylist) "虚拟网关" != t.globalData.userData.gatewaylist[n].name && this.data.gateways.push(t.globalData.userData.gatewaylist[n].name);
      this.setData({
        gateways: this.data.gateways
      })
    } else wx.reLaunch({
      url: "/pages/login/login"
    })
  },
  scanQRCode: function(a) {
    var e = this;
    wx.scanCode({
      success: function(a) {
        e.setData({
          serialnum: a.result
        })
      }
    })
  },
  addLockBtn: function(e) {
    if (this.setData({
        nickname_warn: "",
        serialnum_warn: "",
        errflag: !1
      }), this.data.nickname.length <= 0) this.setData({
      nickname_warn: "weui-cell_warn",
      errflag: !0,
      errmsg: "请输入设备名称"
    });
    else if (this.data.serialnum.length <= 0) this.setData({
      serialnum_warn: "weui-cell_warn",
      errflag: !0,
      errmsg: "请输入序列号"
    });
    else if (this.data.roomNum.length <= 0) this.setData({
      roomNum_warn: "weui-cell_warn",
      errflag: !0,
      errmsg: "请输入房间号"
    });
    else if (this.data.roomRegion.length <= 0) this.setData({
      roomRegion_warn: "weui-cell_warn",
      errflag: !0,
      errmsg: "请选择地区"
    });
    else if (this.data.roomAddress.length <= 0) this.setData({
      roomAddress_warn: "weui-cell_warn",
      errflag: !0,
      errmsg: "请输入详细地址"
    });
    else {
      var n = this;
      wx.showLoading({
        title: "同步中",
        mask: !0
      }), 28 == n.data.serialnum.length ? wx.request({
        url: t.globalData.gburl + "wxxcx/add_agateway/" + t.globalData.gbvendor,
        method: "POST",
        header: {
          "content-type": "application/json",
          Authorization: t.globalData.token
        },
        data: {
          nickname: n.data.nickname,
          serialnum: n.data.serialnum
        },
        success: function(e) {
          if (wx.hideLoading(), 0 == e.data.errcode) {
            var t = n.data.gateways[n.data.gatewayIndex];
            e.data.gateway && a.addGateway(e.data.gateway, {
              name: t
            }), a.addFplock(n.data.serialnum, {
              name: n.data.nickname,
              gateway: a.findGatewayFromName(t),
              locktype: 3
            }), wx.showModal({
              title: "提示",
              content: "添加成功",
              showCancel: !1,
              success: function(a) {
                wx.navigateBack()
              }
            })
          } else n.setData({
            serialnum_warn: "weui-cell_warn",
            errflag: !0,
            errmsg: e.data.errtype
          })
        },
        fail: function(a) {
          wx.hideLoading()
        }
      }) : "4" === n.data.serialnum[17] && "0" === n.data.serialnum[18] ? wx.request({
        url: t.globalData.gburl + "wxxcx/add_fplock/" + t.globalData.gbvendor,
        method: "POST",
        header: {
          "content-type": "application/json",
          Authorization: t.globalData.token
        },
        data: {
          nickname: n.data.nickname,
          serialnum: n.data.serialnum,
          gateway: n.data.gateways[n.data.gatewayIndex],
          lock_address: n.data.roomAddress,
          lock_street: n.data.roomStreets[n.data.roomStreetIndex],
          lock_province: n.data.roomRegion.join(","),
          room_no: n.data.roomNum
        },
        success: function(e) {
          if (wx.hideLoading(), 0 == e.data.errcode) {
            var t = n.data.gateways[n.data.gatewayIndex];
            e.data.gateway && a.addGateway(e.data.gateway, {
              name: t
            }), a.addFplock(n.data.serialnum, {
              name: n.data.nickname,
              gateway: a.findGatewayFromName(t),
              locktype: 0
            }), wx.showModal({
              title: "提示",
              content: "添加成功",
              showCancel: !1,
              success: function(a) {
                wx.navigateBack()
              }
            })
          } else "serialnum" == e.data.errtype ? n.setData({
            serialnum_warn: "weui-cell_warn",
            errflag: !0,
            errmsg: "序列号无效"
          }) : "nickname" == e.data.errtype ? n.setData({
            nickname_warn: "weui-cell_warn",
            errflag: !0,
            errmsg: "用户名已存在"
          }) : "gateway" == e.data.errtype ? wx.showModal({
            title: "提示",
            content: "网关不存在",
            showCancel: !1
          }) : "fplock" == e.data.errtype ? wx.showModal({
            title: "提示",
            content: "门锁已注册",
            showCancel: !1
          }) : wx.showModal({
            title: "提示",
            content: "通信故障",
            showCancel: !1
          })
        },
        fail: function(a) {
          wx.hideLoading()
        }
      }) : (wx.hideLoading(), wx.showModal({
        title: "提示",
        content: "序列号无效",
        showCancel: !1
      }))
    }
  },
  nicknameInput: function(a) {
    this.setData({
      nickname: a.detail.value,
      nickname_warn: "",
      errflag: !1
    })
  },
  serialnumInput: function(a) {
    this.setData({
      serialnum: a.detail.value,
      serialnum_warn: "",
      errflag: !1
    })
  },
  roomNumInput: function(a) {
    this.setData({
      roomNum: a.detail.value,
      roomNum_warn: "",
      errflag: !1
    })
  },
  bindRoomRegionChange: function(a) {
    this.setData({
      roomRegion: a.detail.value,
      roomRegion_warn: "",
      errflag: !1
    })
  },
  bindRoomStreetChange: function(a) {
    this.setData({
      roomStreetIndex: a.detail.value
    })
  },
  roomAddressInput: function(a) {
    this.setData({
      roomAddress: a.detail.value,
      roomAddress_warn: "",
      errflag: !1
    })
  }
});