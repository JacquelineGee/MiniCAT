require("../../../80E7AA76438FECAFE681C27142BA10C4.js"), require("../../../4E9A06A0438FECAF28FC6EA7F19A10C4.js");
var n = getApp();
Page({
  data: {
    list: [{
      url: "quickstart/quickstart",
      icon: "iconfont icon-kuaisurumen",
      text: "快速使用"
    }, {
      url: "problem/problem",
      icon: "iconfont icon-changjianwenti",
      text: "常见问题"
    }, {
      url: "manual/manual",
      icon: "iconfont icon-wenjian",
      text: "使用说明"
    }],
    iconStyle: "margin-right: 5px;vertical-align: middle;font-size:50rpx;color:#2db3e9"
  },
  navBindtap: function(t) {
    n.globalData.webViewURL = this.data.list[t.currentTarget.dataset.id].webViewURL, wx.navigateTo({
      url: this.data.list[t.currentTarget.dataset.id].url
    })
  },
  onLoad: function(n) {},
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {}
});