'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
/*
 * @Date: 2018-12-21 16:26:31
 * @LastEditors: lynatao
 * @LastEditTime: 2019-11-19 11:44:04
 */
var uploadPhoto = function uploadPhoto(filePath, isForePhoto, certificateType, cb, errCb) {
  wx.showLoading({
    title: '正在处理'
  });
  var uploadUrl = 'https://mp.weixin.qq.com/wxamusic/ocr/idcard?action=idcard&type=photo';
  if (certificateType == 'bankCard') {
    uploadUrl = 'https://mp.weixin.qq.com/wxamusic/ocr/idcard?action=bankcard';
  } else if (certificateType == 'drivingLicense') {
    uploadUrl = 'https://mp.weixin.qq.com/wxamusic/ocr/idcard?action=driving';
  } else if (certificateType == 'businessLicense') {
    uploadUrl = 'https://mp.weixin.qq.com/wxamusic/ocr/idcard?action=biz_license&type=photo';
  }
  wx.uploadFile({
    url: uploadUrl,
    filePath: filePath,
    name: 'file',
    complete: function complete() {
      wx.hideLoading();
    },
    success: function success(res) {
      var data = {};
      try {
        data = JSON.parse(res.data);
      } catch (e) {
        // empty
      }
      var ret = data.base_resp ? data.base_resp.err_code : -1;
      switch (certificateType) {
        case 'bankCard':
          if (ret || !data.bankcard_result) {
            console.log("错误就走到这里");
            wx.showModal({
              title: '未能识别银行卡',
              content: '请重新拍摄或上传',
              showCancel: false,
              success: function success(res) {
                if (res.confirm) {
                  errCb(result);
                }
              }
            });
            return cb(true);
          }

          cb(false, data.bankcard_result);
          break;
        case 'businessLicense':
          if (ret || !data.biz_license_result) {
            console.log("错误就走到这里");
            wx.showModal({
              title: '未能识营业执照',
              content: '请重新拍摄或上传',
              showCancel: false,
              success: function success(res) {
                if (res.confirm) {
                  errCb(result);
                }
              }
            });
            return cb(true);
          }

          cb(false, data.biz_license_result);
          break;
        case 'drivingLicense':
          if (ret || !data.driving_result || data.driving_result.type == 3) {
            console.log("错误就走到这里");
            var tempValue = 3;
            if (ret != 0) {
              tempValue = ret;
            }
            wx.showModal({
              title: '未能识别行驶证',
              content: '请重新拍摄或上传',
              showCancel: false,
              success: function success(res) {
                if (res.confirm) {
                  errCb(result);
                }
              }
            });
            return cb(true);
          }
          cb(false, data.driving_result);
          break;

        default:
          if (ret || !data.result) {
            console.log("错误就走到这里");
            wx.showModal({
              title: '未能识别身份证',
              content: '请重新拍摄或上传',
              showCancel: false,
              success: function success(res) {
                if (res.confirm) {
                  errCb(result);
                }
              }
            });
            return cb(true);
          }
          cb(false, data.result);

      }
    }
  });
};

var takePhoto = exports.takePhoto = function takePhoto(isFore, certificateType, type, path, successCb, errCb, imgCb) {
  // ['album', 'camera']
  if (type == 'camera') {
    uploadPhoto(path, isFore, certificateType, function(err, result) {
      if (err) {
        errCb(err);
        return;
      }
      switch (certificateType) {
        case 'bankCard':
          break;
        case 'drivingLicense':
          break;
        case 'businessLicense':
          break;
        default:
          if (isFore) {
            if (result.type !== 0) {
              wx.showModal({
                title: '请将身份证翻面拍摄',
                content: '请拍摄身份证的人像面',
                showCancel: false,
                success: function success(res) {
                  if (res.confirm) {
                    errCb(result);
                  }
                }
              });
              return;
            }
          } else {
            if (result.type !== 1) {
              wx.showModal({
                title: '请将身份证翻面拍摄',
                content: '请拍摄身份证的国徽面',
                showCancel: false,
                success: function success(res) {
                  if (res.confirm) {
                    errCb(result);
                  }
                }
              });
              return;
            }
          }
      }
      successCb(result, path);
    }, errCb);
  } else {
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: type,
      success: function success(res) {
        var path = res.tempFilePaths[0];
        imgCb(path);
        uploadPhoto(path, isFore, certificateType, function(err, result) {
          if (err) return;
          switch (certificateType) {
            case 'bankCard':
              break;
            case 'drivingLicense':
              break;
            case 'businessLicense':
              break;
            default:
              if (isFore) {
                if (result.type !== 0) {
                  wx.showModal({
                    title: '请将身份证翻面拍摄',
                    content: '请拍摄身份证的人像面',
                    showCancel: false,
                    success: function success(res) {
                      if (res.confirm) {
                        errCb(result);
                      }
                    }
                  });
                  return;
                }
              } else {
                if (result.type !== 1) {
                  wx.showModal({
                    title: '请将身份证翻面拍摄',
                    content: '请拍摄身份证的国徽面',
                    showCancel: false,
                    success: function success(res) {
                      if (res.confirm) {
                        errCb(result);
                      }
                    }
                  });
                  return;
                }
              }
          }
          successCb(result, path);
        }, errCb);
      },
      fail: function fail(res) {
        console.error(res);
      }
    });
  }
};