var t = require("../../80E7AA76438FECAFE681C27142BA10C4.js"),
  e = getApp();
Page({
  data: {
    iconStyle: "margin-right: 5px;vertical-align: middle;font-size:65rpx;color:#2db3e9",
    tabs: ["全部", "已出租", "未出租"],
    activeIndex: 0,
    sliderOffset: 0,
    sliderLeft: 0,
    device: [],
    rented: !0
  },
  onLoad: function(a) {
    var n = this;
    wx.getSystemInfo({
      success: function(t) {
        n.setData({
          sliderLeft: (t.windowWidth / n.data.tabs.length - 96) / 2,
          sliderOffset: t.windowWidth / n.data.tabs.length * n.data.activeIndex
        })
      }
    }), e.globalData.unionid && (e.globalData.userData.fplocklistFlag || t.resyncUserData())
  },
  onShow: function() {
    var t = this,
      a = [],
      n = [],
      o = [],
      i = e.globalData.userData.fplocklist;
    for (var c in i)
      if (4 != i[c].locktype) {
        var l = i[c].name;
        i[c].note && (l = i[c].note), o.push(c), a.push({
          type: "lock",
          tab: "",
          id: c,
          name: l,
          icon: "iconfont icon-fangjian",
          remoteUnlock: i[c].remoteUnlock
        })
      } this.setData({
      device: a
    }), wx.request({
      url: e.globalData.gburl + "wxxcx/GYGetLocksInfo/" + e.globalData.gbvendor,
      method: "POST",
      header: {
        "content-type": "application/json",
        Authorization: e.globalData.token
      },
      data: {
        fpSerialnums: o
      },
      success: function(e) {
        var a = e.data.data;
        for (var o in a) {
          var c = i[o].name;
          i[o].note && (c = i[o].note), a[o].isRented ? n.push({
            type: "lock",
            tab: "已出租",
            id: o,
            name: c,
            icon: "iconfont icon-fangjian",
            remoteUnlock: i[o].remoteUnlock
          }) : n.push({
            type: "lock",
            tab: "未出租",
            id: o,
            name: c,
            icon: "iconfont icon-fangjian",
            remoteUnlock: i[o].remoteUnlock
          })
        }
        t.setData({
          device: n
        })
      },
      fail: function(t) {}
    })
  },
  tabClick: function(t) {
    this.setData({
      sliderOffset: t.currentTarget.offsetLeft,
      activeIndex: t.currentTarget.id
    })
  },
  roomClick: function(t) {
    wx.navigateTo({
      url: "lockManagement/lockManagement?serialnum=" + t.currentTarget.dataset.id
    })
  },
  addDevice: function() {
    e.globalData.unionid ? wx.navigateTo({
      url: "../device/addDevice/addDevice"
    }) : wx.showModal({
      title: "提示",
      content: "请登录系统",
      success: function(t) {
        t.confirm ? wx.reLaunch({
          url: "../account/account"
        }) : t.cancel && console.log("取消")
      }
    })
  }
});