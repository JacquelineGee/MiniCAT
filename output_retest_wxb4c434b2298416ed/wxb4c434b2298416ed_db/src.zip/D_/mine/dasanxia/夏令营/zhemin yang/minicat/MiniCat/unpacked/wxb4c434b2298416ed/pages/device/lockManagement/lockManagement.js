function a(a) {
  wx.request({
    url: n.globalData.gburl + "wxxcx/set_fpnotify/" + n.globalData.gbvendor,
    method: "POST",
    header: {
      "content-type": "application/json",
      Authorization: n.globalData.token
    },
    data: {
      serialnum: a.data.id,
      openrecord_notify: a.data.openRecordSw,
      disassembly_alarm_notify: a.data.disassemblyAlarmSw,
      lockcylinder_alarm_notify: a.data.lockCylinderAlarmSw,
      systemlock_notify: a.data.systemLockSw
    },
    success: function(a) {
      a.data.errcode
    },
    fail: function(a) {}
  })
}
var t = require("../../../80E7AA76438FECAFE681C27142BA10C4.js"),
  e = require("../../../4E9A06A0438FECAF28FC6EA7F19A10C4.js"),
  o = require("../../../438C6F16438FECAF25EA07112F9A10C4.js"),
  n = getApp();
Page({
  data: {
    type: "lock",
    tab: "智能锁",
    id: "",
    icon: "iconfont icon-zhinengsuo",
    name: "",
    version: "",
    netInfo: "未连接",
    service: "",
    iccid: "",
    deviceOnline: !1,
    openRecordSw: !1,
    alarmSW: !0,
    disassemblyAlarmSw: !0,
    lockCylinderAlarmSw: !0,
    systemLockSw: !0,
    showToastQRCode: !1,
    showToastName: !1,
    showToastNote: !1,
    canvasHidden: !1,
    maskHidden: !0,
    imagePath: "/image/qrmask.png",
    deviceQRCode: null,
    deviceType: null,
    community: !1,
    pInfo: "",
    pTel: "",
    pAddress: "",
    roomNum: "",
    roomRegion: "",
    roomStreet: "",
    roomAddress: "",
    showToastPasswordR: !1,
    roomStreets: ["城厢街道", "北干街道", "蜀山街道", "新塘街道", "义蓬街道", "南阳街道", "靖江街道", "河庄街道", "前进街道", "新湾街道", "临江街道", "闻堰街道", "宁围街道", "新街街道", "河上镇", "戴村镇", "浦阳镇", "进化镇", "临浦镇", "楼塔镇", "义桥镇", "所前镇", "衙前镇", "瓜沥镇", "益农镇", "党湾镇"],
    roomStreetIndex: 13
  },
  onLoad: function(a) {
    var t = a.serialnum,
      e = this;
    this.setData({
      name: n.globalData.userData.fplocklist[t].name,
      deviceType: n.globalData.userData.fplocklist[t].locktype,
      id: t
    }), 0 == e.data.deviceType ? wx.request({
      url: n.globalData.gburl + "wxxcx/get_fpflag/" + n.globalData.gbvendor,
      method: "POST",
      header: {
        "content-type": "application/json",
        Authorization: n.globalData.token
      },
      data: {
        serialnum: t,
        type: "network"
      },
      success: function(a) {
        0 == a.data.errcode && 1 == a.data.flag ? (e.setData({
          deviceOnline: !0
        }), wx.request({
          url: n.globalData.gburl + "wxxcx/get_fpnotify/" + n.globalData.gbvendor,
          method: "POST",
          header: {
            "content-type": "application/json",
            Authorization: n.globalData.token
          },
          data: {
            serialnum: e.data.id
          },
          success: function(a) {
            if (0 == a.data.errcode) {
              var t = e.data.roomStreets.findIndex(function(t, e, o) {
                return t == a.data.lock_street
              });
              e.setData({
                openRecordSw: a.data.openrecord_notify,
                disassemblyAlarmSw: a.data.disassembly_alarm_notify,
                lockCylinderAlarmSw: a.data.lockcylinder_alarm_notify,
                systemLockSw: a.data.systemlock_notify,
                version: a.data.version,
                iccid: a.data.ccid,
                community: a.data.community,
                pInfo: a.data.vpinfo,
                pTel: a.data.vpphone,
                pAddress: a.data.address,
                roomNum: a.data.room_no,
                roomRegion: a.data.lock_province.split(","),
                roomStreet: a.data.lock_street,
                roomStreetIndex: t,
                roomAddress: a.data.lock_address
              }), "1" == a.data.wifitype ? e.setData({
                netInfo: "Wi-Fi"
              }) : e.setData({
                netInfo: "NB-IoT"
              }), a.data.ccid && e.setISPService(e)
            }
          },
          fail: function(a) {}
        })) : e.setData({
          deviceOnline: !1,
          netInfo: "未连接"
        })
      }
    }) : 1 == e.data.deviceType ? wx.request({
      url: n.globalData.gburl + "wxxcx/get_rcvfpauthorize/" + n.globalData.gbvendor,
      method: "POST",
      header: {
        "content-type": "application/json",
        Authorization: n.globalData.token
      },
      data: {
        fplock: e.data.id,
        recipient: n.globalData.unionid
      },
      success: function(a) {
        0 == a.data.errcode && e.setData({
          note: a.data.data.recipientnote
        })
      },
      fail: function(a) {}
    }) : e.data.deviceType
  },
  setISPService: function(a) {
    var t = a.data.iccid.split("");
    0 == t[4] && 0 == t[5] || 0 == t[4] && 2 == t[5] || 0 == t[4] && 4 == t[5] || 0 == t[4] && 2 == t[7] ? a.setData({
      service: "中国移动"
    }) : 0 == t[4] && 1 == t[5] || 0 == t[4] && 6 == t[5] || 0 == t[4] && 9 == t[5] ? a.setData({
      service: "中国联通"
    }) : 0 == t[4] && 3 == t[5] || 0 == t[4] && 5 == t[5] || 1 == t[4] && 1 == t[5] ? a.setData({
      service: "中国电信"
    }) : 2 == t[4] && 0 == t[5] ? a.setData({
      service: "中国铁通"
    }) : a.setData({
      service: "未知"
    })
  },
  changeName: function(a) {
    this.setData({
      showToastName: !0,
      errflag: !1,
      toastInput: ""
    })
  },
  changeRoomNum: function(a) {
    this.setData({
      showToastRoomNum: !0,
      errflag: !1,
      toastInput: ""
    })
  },
  changeRoomAddress: function(a) {
    this.setData({
      showToastRoomAddress: !0,
      errflag: !1,
      toastInput: ""
    })
  },
  changeNote: function(a) {
    this.setData({
      showToastNote: !0,
      errflag: !1,
      toastInput: ""
    })
  },
  toastCancelName: function(a) {
    this.setData({
      showToastName: !1
    })
  },
  toastCancelNote: function(a) {
    this.setData({
      showToastNote: !1
    })
  },
  toastCancelRoomNum: function(a) {
    this.setData({
      showToastRoomNum: !1
    })
  },
  toastCancelRoomAddress: function(a) {
    this.setData({
      showToastRoomAddress: !1
    })
  },
  toastConfirmName: function(a) {
    if (this.data.toastInput) {
      var t = this;
      wx.showLoading({
        title: "同步中",
        mask: !0
      });
      var o = n.globalData.userData.fplocklist[t.data.id].gateway;
      wx.request({
        url: n.globalData.gburl + "wxxcx/chg_fplock/" + n.globalData.gbvendor,
        method: "POST",
        header: {
          "content-type": "application/json",
          Authorization: n.globalData.token
        },
        data: {
          nickname: t.data.toastInput,
          serialnum: t.data.id,
          gateway: n.globalData.userData.gatewaylist[o].name
        },
        success: function(a) {
          wx.hideLoading(), 0 == a.data.errcode ? (e.chgFplock(t.data.id, {
            name: t.data.toastInput,
            gateway: o,
            locktype: n.globalData.userData.fplocklist[t.data.id].locktype,
            note: n.globalData.userData.fplocklist[t.data.id].note
          }), wx.showModal({
            title: "提示",
            content: "修改成功",
            showCancel: !1,
            success: function(a) {
              t.setData({
                showToastName: !1,
                name: t.data.toastInput
              })
            }
          })) : "serialnum" == a.data.errtype ? t.setData({
            errflag: !0,
            errmsg: "门锁不存在"
          }) : "nickname" == a.data.errtype ? t.setData({
            errflag: !0,
            errmsg: "门锁名称已存在"
          }) : t.setData({
            errflag: !0,
            errmsg: "通信故障"
          })
        },
        fail: function(a) {
          wx.hideLoading(), t.setData({
            errflag: !0,
            errmsg: "通信故障"
          })
        }
      })
    } else this.setData({
      errflag: !0,
      errmsg: "请输入名称"
    })
  },
  toastConfirmNote: function(a) {
    wx.showLoading({
      title: "上传中",
      mask: !0
    });
    var t = this;
    wx.request({
      url: n.globalData.gburl + "wxxcx/chg_rcvfpauthorize/" + n.globalData.gbvendor,
      method: "POST",
      header: {
        "content-type": "application/json",
        Authorization: n.globalData.token
      },
      data: {
        fplock: this.data.id,
        note: this.data.toastInput,
        recipient: n.globalData.unionid
      },
      success: function(a) {
        wx.hideLoading(), 0 == a.data.errcode ? (wx.showToast({
          title: "修改成功",
          icon: "none",
          duration: 1e3
        }), t.setData({
          showToastNote: !1,
          note: t.data.toastInput
        }), e.chgFplock(t.data.id, {
          name: n.globalData.userData.fplocklist[t.data.id].name,
          gateway: n.globalData.userData.fplocklist[t.data.id].gateway,
          locktype: n.globalData.userData.fplocklist[t.data.id].locktype,
          note: t.data.toastInput
        })) : t.setData({
          errflag: !0,
          errmsg: a.data.errtype
        })
      },
      fail: function(a) {
        wx.hideLoading(), t.setData({
          errflag: !0,
          errmsg: "通信超时"
        })
      }
    })
  },
  toastConfirmRoomNum: function(a) {
    this.data.toastInput ? (this.setData({
      roomNum: this.data.toastInput,
      showToastRoomNum: !1
    }), this.chgFplockField("room_no", this.data.toastInput)) : this.setData({
      errflag: !0,
      errmsg: "请输入房间号"
    })
  },
  bindRoomRegionChange: function(a) {
    this.setData({
      roomRegion: a.detail.value
    }), this.chgFplockField("lock_province", a.detail.value.join(","))
  },
  bindRoomStreetChange: function(a) {
    this.setData({
      roomStreetIndex: a.detail.value,
      roomStreet: this.data.roomStreets[a.detail.value]
    }), this.chgFplockField("lock_street", this.data.roomStreet)
  },
  toastConfirmRoomAddress: function(a) {
    this.data.toastInput ? (this.setData({
      roomAddress: this.data.toastInput,
      showToastRoomAddress: !1
    }), this.chgFplockField("lock_address", this.data.toastInput)) : this.setData({
      errflag: !0,
      errmsg: "请输入详细地址"
    })
  },
  chgFplockField: function(a, t) {
    var e = this;
    wx.showLoading({
      title: "同步中",
      mask: !0
    }), wx.request({
      url: n.globalData.gburl + "wxxcx/chg_fplockfield/" + n.globalData.gbvendor,
      method: "POST",
      header: {
        "content-type": "application/json",
        Authorization: n.globalData.token
      },
      data: {
        serialnum: e.data.id,
        fieldname: a,
        fielddata: t
      },
      success: function(a) {
        wx.hideLoading(), 0 == a.data.errcode ? wx.showModal({
          title: "提示",
          content: "修改成功",
          showCancel: !1
        }) : e.setData({
          errflag: !0,
          errmsg: a.data.errtype
        })
      },
      fail: function(a) {
        wx.hideLoading(), e.setData({
          errflag: !0,
          errmsg: "通信故障"
        })
      }
    })
  },
  toastInput: function(a) {
    this.setData({
      errflag: !1,
      errmsg: "",
      toastInput: a.detail.value
    })
  },
  toastClose: function() {
    this.setData({
      showToastQRCode: !1,
      maskHidden: !0,
      canvasHidden: !0,
      imagePath: "/image/qrmask.png"
    })
  },
  showDeviceQRCode: function() {
    var a = t.formatCustomTime(new Date(Date.parse(new Date) + 3e5), "yyyy-MM-dd hh:mm"),
      e = this,
      i = new Date(1970, 0, 1),
      s = Math.floor((Date.now() - i) / 6e4).toString(),
      l = Math.floor((new Date(Date.parse(new Date) + 3e5) - i) / 6e4).toString(),
      r = JSON.stringify({
        type: 1,
        data: this.data.id,
        beginTimeMin: s,
        expireTimeMin: l
      }),
      d = o.enc.Utf8.parse(n.globalData.desKey),
      c = o.DES.encrypt(r, d, {
        mode: o.mode.ECB,
        padding: o.pad.Pkcs7
      }).toString();
    this.setData({
      showToastQRCode: !0,
      maskHidden: !1,
      canvasHidden: !1,
      deviceQRCode: c,
      expireTime: a
    }), wx.showLoading({
      title: "加载中"
    }), t.creatIdentificationCode(this.data.deviceQRCode), setTimeout(function() {
      wx.canvasToTempFilePath({
        canvasId: "qrcanvas",
        success: function(a) {
          var t = a.tempFilePath;
          wx.hideLoading(), e.setData({
            imagePath: t
          })
        },
        fail: function(a) {
          wx.hideLoading(), wx.showToast({
            title: "加载失败",
            icon: "none"
          })
        }
      })
    }, 1e3)
  },
  deleteDevice: function() {
    0 == n.globalData.userData.fplocklist[this.data.id].locktype ? this._deleteDevice() : this._deleteDeviceAuthor()
  },
  _deleteDeviceAuthor: function() {
    var a = this;
    wx.showLoading({
      title: "同步中",
      mask: !0
    }), wx.request({
      url: n.globalData.gburl + "wxxcx/del_fpauthorize/" + n.globalData.gbvendor,
      method: "POST",
      header: {
        "content-type": "application/json",
        Authorization: n.globalData.token
      },
      data: {
        fplock: this.data.id,
        recipient: n.globalData.unionid
      },
      success: function(t) {
        if (wx.hideLoading(), 0 == t.data.errcode) {
          var o = [a.data.id];
          e.delFplock(o), wx.showModal({
            title: "提示",
            content: "删除成功",
            showCancel: !1,
            success: function(a) {
              wx.navigateBack()
            }
          })
        } else wx.showModal({
          title: "提示",
          content: "删除失败",
          showCancel: !1
        })
      },
      fail: function(a) {
        wx.hideLoading(), wx.showModal({
          title: "提示",
          content: a.errMsg,
          showCancel: !1,
          success: function(a) {
            wx.navigateBack()
          }
        })
      }
    })
  },
  _deleteDevice: function() {
    var a = [this.data.id];
    wx.showLoading({
      title: "同步中",
      mask: !0
    }), wx.request({
      url: n.globalData.gburl + "wxxcx/del_fplock/" + n.globalData.gbvendor,
      method: "POST",
      header: {
        "content-type": "application/json",
        Authorization: n.globalData.token
      },
      data: {
        dfp_checkbox: a
      },
      success: function(t) {
        wx.hideLoading(), 0 == t.data.errcode ? (e.delFplock(a), wx.showModal({
          title: "提示",
          content: "删除成功",
          showCancel: !1,
          success: function(a) {
            wx.navigateBack()
          }
        })) : wx.showModal({
          title: "提示",
          content: "删除失败",
          showCancel: !1
        })
      },
      fail: function(a) {
        wx.hideLoading(), wx.showModal({
          title: "提示",
          content: a.errMsg,
          showCancel: !1,
          success: function(a) {
            wx.navigateBack()
          }
        })
      }
    })
  },
  remoteUnlock: function() {
    n.globalData.curlockSerialnum = this.data.id;
    var a = this;
    if (null != n.globalData.curlockSerialnum && (2 == n.globalData.curlockSerialnum[17] && 4 == n.globalData.curlockSerialnum[18] || 3 == n.globalData.curlockSerialnum[17] && 0 == n.globalData.curlockSerialnum[18] || 2 == n.globalData.curlockSerialnum[17] && 5 == n.globalData.curlockSerialnum[18] || 4 == n.globalData.curlockSerialnum[17] && 0 == n.globalData.curlockSerialnum[18]))
      if (n.globalData.curlockAdminPassword || 3 == n.globalData.curlockSerialnum[17] && 0 == n.globalData.curlockSerialnum[18]) {
        if (wx.showLoading({
            title: "开启中",
            mask: !0
          }), 3 == n.globalData.curlockSerialnum[17] && 0 == n.globalData.curlockSerialnum[18]) e = t.genRemoteOpenPasswd_NoPasswd(n.globalData.curlockSerialnum.split("-")[0]);
        else var e = t.genRemoteOpenPasswd(n.globalData.curlockSerialnum.split("-")[0], n.globalData.curlockAdminPassword);
        wx.request({
          url: n.globalData.gburl + "wxxcx/remote_open/" + n.globalData.gbvendor,
          method: "POST",
          header: {
            "content-type": "application/json",
            Authorization: n.globalData.token
          },
          data: {
            serialnum: n.globalData.curlockSerialnum,
            passwd: e,
            nickname: n.globalData.userInfo.userInfo.nickName,
            id: n.globalData.unionid
          },
          success: function(a) {
            wx.hideLoading(), 0 == a.data.errcode ? wx.showToast({
              title: "远程开锁命令发送成功",
              icon: "none"
            }) : wx.showToast({
              title: "远程开锁命令发送失败",
              icon: "none"
            })
          },
          fail: function(a) {
            wx.hideLoading(), wx.showToast({
              title: "网络请求失败",
              icon: "none"
            })
          }
        })
      } else a.setData({
        showToastPasswordR: !0,
        errflag: !1,
        toastInput: ""
      })
  },
  toastCancelR: function(a) {
    this.setData({
      showToastPasswordR: !1
    })
  },
  toastConfirmR: function(a) {
    if (this.data.toastInput)
      if (this.data.toastInput.length < 6) this.setData({
        toastInput: "",
        errflag: !0,
        errmsg: "密码长度不符"
      });
      else {
        this.setData({
          showToastPasswordR: !1,
          lastRKeyReqTime: Date.now()
        }), wx.showLoading({
          title: "开启中",
          mask: !0
        });
        var e = t.genRemoteOpenPasswd(n.globalData.curlockSerialnum.split("-")[0], this.data.toastInput);
        wx.request({
          url: n.globalData.gburl + "wxxcx/remote_open/" + n.globalData.gbvendor,
          method: "POST",
          header: {
            "content-type": "application/json",
            Authorization: n.globalData.token
          },
          data: {
            serialnum: n.globalData.curlockSerialnum,
            passwd: e,
            nickname: n.globalData.userInfo.userInfo.nickName,
            id: n.globalData.unionid
          },
          success: function(a) {
            wx.hideLoading(), 0 == a.data.errcode ? wx.showToast({
              title: "远程开锁命令发送成功",
              icon: "none"
            }) : wx.showToast({
              title: "远程开锁命令发送失败",
              icon: "none"
            })
          },
          fail: function(a) {
            wx.hideLoading(), wx.showToast({
              title: "网络请求失败",
              icon: "none"
            })
          }
        })
      }
    else this.setData({
      errflag: !0,
      errmsg: "请输入密码"
    })
  },
  unlockLogSwitchChange: function(t) {
    this.setData({
      openRecordSw: t.detail.value
    }), a(this)
  },
  alarmSWChange: function(t) {
    this.setData({
      disassemblyAlarmSw: t.detail.value,
      lockCylinderAlarmSw: t.detail.value,
      systemLockSw: t.detail.value
    }), a(this)
  }
});