require("../../../../80E7AA76438FECAFE681C27142BA10C4.js"), require("../../../../4E9A06A0438FECAF28FC6EA7F19A10C4.js");
var n = getApp();
Page({
  data: {},
  onLoad: function(o) {
    this.setData({
      webViewURL: n.globalData.webViewURL
    }), wx.showLoading({
      title: "加载中"
    })
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  srcOnLoadSuccess: function() {
    wx.hideLoading()
  },
  srcOnLodeError: function() {
    wx.hideLoading(), wx.showToast({
      title: "加载失败",
      icon: "none"
    })
  }
});