require("../../../../80E7AA76438FECAFE681C27142BA10C4.js"), require("../../../../4E9A06A0438FECAF28FC6EA7F19A10C4.js");
var n = getApp();
Page({
  data: {
    iconStyle: "margin-right: 5px;vertical-align: middle;font-size:40px;color:#2db3e9",
    list: [{
      url: "../../helpCenter/manual/manual-1/manual-1",
      icon: "iconfont icon-lockA",
      name: "有显示屏类",
      open: !1,
      webViewURL: "https://www.samcharm.com/weapp/manual/slm-oled/"
    }, {
      url: "../../helpCenter/webView/webView",
      icon: "iconfont icon-lockB",
      name: "无显示屏类",
      open: !1,
      webViewURL: "https://www.samcharm.com/weapp/slm-tiny/"
    }]
  },
  onLoad: function(n) {},
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  navBindtap: function(e) {
    n.globalData.webViewURL = this.data.list[e.currentTarget.dataset.id].webViewURL, wx.navigateTo({
      url: this.data.list[e.currentTarget.dataset.id].url
    })
  },
  onShareAppMessage: function() {}
});