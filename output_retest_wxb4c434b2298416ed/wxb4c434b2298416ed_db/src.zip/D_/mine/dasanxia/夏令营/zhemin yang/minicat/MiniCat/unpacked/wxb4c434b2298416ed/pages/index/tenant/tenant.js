var a = require("../../../4E9A06A0438FECAF28FC6EA7F19A10C4.js"),
  t = getApp();
Page({
  data: {
    showToastNote: !1,
    toastInput: "",
    roomNote: "",
    roomNum: "",
    roomRegion: "",
    roomStreet: "",
    roomAddress: "",
    startTime: "",
    endTime: "",
    idUserNum: "",
    fpUserNum: [],
    fpserialnum: null,
    ownerRealName: "",
    ownerGender: "",
    ownerIDNumber: "",
    ownerMobile: ""
  },
  onLoad: function(a) {
    var e = JSON.parse(a.devNode),
      o = this;
    this.setData({
      roomNote: e.note,
      fpserialnum: e.fpserialnum
    }), wx.showLoading({
      title: "获取中",
      mask: !0
    }), wx.request({
      url: t.globalData.gburl + "wxxcx/GYGetRentDetail/" + t.globalData.gbvendor,
      method: "POST",
      header: {
        "content-type": "application/json",
        Authorization: t.globalData.token
      },
      data: {
        fpSerialnum: this.data.fpserialnum,
        recipient: t.globalData.unionid
      },
      success: function(a) {
        wx.hideLoading();
        var t = JSON.parse(a.data.data.userNumsJson),
          e = "",
          r = "",
          s = [];
        if (0 == a.data.errcode) {
          for (var n in t) parseInt(n) > parseInt(105) && parseInt(n) < parseInt(116) ? o.setData({
            idUserNum: n
          }) : s.push(n);
          switch (a.data.data.ownerSex) {
            case 1:
              e = "男";
              break;
            case 2:
              e = "女";
              break;
            default:
              e = "未知"
          }
          a.data.data.ownerIDCard && (r = a.data.data.ownerIDCard.substr(0, 4) + "**********" + a.data.data.ownerIDCard.substr(-4, 4)), o.setData({
            roomNote: a.data.data.rentNote,
            roomNum: a.data.data.roomNo,
            roomRegion: a.data.data.province,
            roomStreet: a.data.data.street,
            roomAddress: a.data.data.address,
            startTime: a.data.data.beginTime,
            endTime: a.data.data.endTime,
            ownerRealName: a.data.data.ownerName,
            ownerGender: e,
            ownerIDNumber: r,
            ownerMobile: a.data.data.ownerPhone,
            fpUserNum: s
          })
        } else wx.showToast({
          title: a.data.errtype,
          icon: "none"
        })
      },
      fail: function(a) {
        wx.hideLoading(), wx.showToast({
          title: "通信超时",
          icon: "none"
        })
      }
    })
  },
  changeNote: function(a) {
    this.setData({
      showToastNote: !0,
      errflag: !1,
      toastInput: ""
    })
  },
  toastInput: function(a) {
    this.setData({
      errflag: !1,
      errmsg: "",
      toastInput: a.detail.value
    })
  },
  toastCancelNote: function(a) {
    this.setData({
      showToastNote: !1
    })
  },
  toastConfirmNote: function(e) {
    if (this.data.toastInput) {
      wx.showLoading({
        title: "上传中",
        mask: !0
      });
      var o = this;
      wx.request({
        url: t.globalData.gburl + "wxxcx/chg_rcvfpauthorize/" + t.globalData.gbvendor,
        method: "POST",
        header: {
          "content-type": "application/json",
          Authorization: t.globalData.token
        },
        data: {
          fplock: this.data.fpserialnum,
          note: this.data.toastInput,
          recipient: t.globalData.unionid
        },
        success: function(e) {
          wx.hideLoading(), 0 == e.data.errcode ? (wx.showToast({
            title: "修改成功",
            icon: "none",
            duration: 1e3
          }), o.setData({
            showToastNote: !1,
            roomNote: o.data.toastInput
          }), a.chgFplock(o.data.fpserialnum, {
            name: t.globalData.userData.fplocklist[o.data.fpserialnum].name,
            gateway: t.globalData.userData.fplocklist[o.data.fpserialnum].gateway,
            locktype: t.globalData.userData.fplocklist[o.data.fpserialnum].locktype,
            note: o.data.toastInput
          })) : o.setData({
            errflag: !0,
            errmsg: e.data.errtype
          })
        },
        fail: function(a) {
          wx.hideLoading(), o.setData({
            errflag: !0,
            errmsg: "通信超时"
          })
        }
      })
    } else this.setData({
      errflag: !0,
      errmsg: "请输入名称"
    })
  }
});