var a = require("../../../80E7AA76438FECAFE681C27142BA10C4.js"),
  t = require("../../../4E9A06A0438FECAF28FC6EA7F19A10C4.js"),
  e = require("../../../438C6F16438FECAF25EA07112F9A10C4.js"),
  n = getApp();
Page({
  data: {
    vArray: ["关闭", "1", "2", "3", "4", "5", "6", "7", "8"],
    vIndex: "",
    serialnum: "",
    note: "",
    version: "",
    netInfo: "",
    iccid: "",
    pInfo: "",
    pTel: "",
    pAddress: "",
    community: !1
  },
  onLoad: function(a) {
    var t = a.serialnum;
    this.setData({
      serialnum: t
    });
    var e = this;
    wx.request({
      url: n.globalData.gburl + "wxxcx/get_agateway/" + n.globalData.gbvendor,
      method: "POST",
      header: {
        "content-type": "application/json",
        Authorization: n.globalData.token
      },
      data: {
        serialnum: this.data.serialnum
      },
      success: function(a) {
        if (0 == a.data.errcode) {
          var t = parseInt(a.data.data.syscfg_table.substring(0, 2), 16);
          e.setData({
            note: a.data.data.nickname,
            version: a.data.data.version,
            iccid: a.data.data.CCID,
            community: a.data.data.community,
            pInfo: a.data.data.vpinfo,
            pTel: a.data.data.vpphone,
            pAddress: a.data.data.address,
            vIndex: t
          }), a.data.data.CCID && (e.setData({
            netInfo: "NB-IoT"
          }), e.setISPService(e))
        } else wx.showModal({
          title: "提示",
          content: a.data.errtype,
          showCancel: !1
        })
      },
      fail: function(a) {
        wx.showModal({
          title: "提示",
          content: "通信超时",
          showCancel: !1
        })
      }
    })
  },
  setISPService: function(a) {
    var t = a.data.iccid.split("");
    0 == t[4] && 0 == t[5] || 0 == t[4] && 2 == t[5] || 0 == t[4] && 4 == t[5] || 0 == t[4] && 2 == t[7] ? a.setData({
      service: "中国移动"
    }) : 0 == t[4] && 1 == t[5] || 0 == t[4] && 6 == t[5] || 0 == t[4] && 9 == t[5] ? a.setData({
      service: "中国联通"
    }) : 0 == t[4] && 3 == t[5] || 0 == t[4] && 5 == t[5] || 1 == t[4] && 1 == t[5] ? a.setData({
      service: "中国电信"
    }) : 2 == t[4] && 0 == t[5] ? a.setData({
      service: "中国铁通"
    }) : a.setData({
      service: "未知"
    })
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  changeName: function(a) {
    this.setData({
      showToastName: !0,
      errflag: !1,
      toastInput: ""
    })
  },
  toastCancel: function(a) {
    this.setData({
      showToastName: !1
    })
  },
  toastConfirm: function(a) {
    if (this.data.toastInput) {
      var e = this;
      wx.showLoading({
        title: "同步中",
        mask: !0
      });
      var o = n.globalData.userData.fplocklist[e.data.serialnum].gateway;
      wx.request({
        url: n.globalData.gburl + "wxxcx/chg_agateway/" + n.globalData.gbvendor,
        method: "POST",
        header: {
          "content-type": "application/json",
          Authorization: n.globalData.token
        },
        data: {
          nickname: e.data.toastInput,
          serialnum: e.data.serialnum
        },
        success: function(a) {
          wx.hideLoading(), 0 == a.data.errcode ? (t.chgFplock(e.data.serialnum, {
            name: e.data.toastInput,
            gateway: o,
            locktype: n.globalData.userData.fplocklist[e.data.serialnum].locktype,
            note: n.globalData.userData.fplocklist[e.data.serialnum].note
          }), wx.showModal({
            title: "提示",
            content: "修改成功",
            showCancel: !1,
            success: function(a) {
              e.setData({
                showToastName: !1,
                note: e.data.toastInput
              })
            }
          })) : e.setData({
            errflag: !0,
            errmsg: a.data.errtype
          })
        },
        fail: function(a) {
          wx.hideLoading(), e.setData({
            errflag: !0,
            errmsg: "通信故障"
          })
        }
      })
    } else this.setData({
      errflag: !0,
      errmsg: "请输入名称"
    })
  },
  toastInput: function(a) {
    this.setData({
      errflag: !1,
      errmsg: "",
      toastInput: a.detail.value
    })
  },
  toastClose: function() {
    this.setData({
      showToastQRCode: !1,
      maskHidden: !0,
      canvasHidden: !0,
      imagePath: "/image/qrmask.png"
    })
  },
  showDeviceQRCode: function() {
    var t = a.formatCustomTime(new Date(Date.parse(new Date) + 3e5), "yyyy-MM-dd hh:mm"),
      o = this,
      s = new Date(1970, 0, 1),
      i = Math.floor((Date.now() - s) / 6e4).toString(),
      l = Math.floor((new Date(Date.parse(new Date) + 3e5) - s) / 6e4).toString(),
      d = JSON.stringify({
        type: 3,
        data: this.data.serialnum,
        beginTimeMin: i,
        expireTimeMin: l
      }),
      r = e.enc.Utf8.parse(n.globalData.desKey),
      c = e.DES.encrypt(d, r, {
        mode: e.mode.ECB,
        padding: e.pad.Pkcs7
      }).toString();
    this.setData({
      showToastQRCode: !0,
      maskHidden: !1,
      canvasHidden: !1,
      deviceQRCode: c,
      expireTime: t
    }), wx.showLoading({
      title: "加载中"
    }), a.creatIdentificationCode(this.data.deviceQRCode), setTimeout(function() {
      wx.canvasToTempFilePath({
        canvasId: "qrcanvas",
        success: function(a) {
          var t = a.tempFilePath;
          wx.hideLoading(), o.setData({
            imagePath: t
          })
        },
        fail: function(a) {
          console.log(a), wx.hideLoading(), wx.showToast({
            title: "加载失败",
            icon: "none"
          })
        }
      })
    }, 1e3)
  },
  deleteDevice: function() {
    var a = this;
    wx.showLoading({
      title: "同步中",
      mask: !0
    }), wx.request({
      url: n.globalData.gburl + "wxxcx/del_agateway/" + n.globalData.gbvendor,
      method: "POST",
      header: {
        "content-type": "application/json",
        Authorization: n.globalData.token
      },
      data: {
        serialnum: this.data.serialnum
      },
      success: function(e) {
        if (wx.hideLoading(), 0 == e.data.errcode) {
          var n = [a.data.serialnum];
          t.delFplock(n), wx.showModal({
            title: "提示",
            content: "删除成功",
            showCancel: !1,
            success: function(a) {
              wx.navigateBack()
            }
          })
        } else wx.showModal({
          title: "提示",
          content: "删除失败",
          showCancel: !1
        })
      },
      fail: function(a) {
        wx.hideLoading(), wx.showModal({
          title: "提示",
          content: a.errMsg,
          showCancel: !1,
          success: function(a) {
            wx.navigateBack()
          }
        })
      }
    })
  },
  bindVolumePickerChange: function(a) {
    this.setData({
      vIndex: a.detail.value
    }), wx.request({
      url: n.globalData.gburl + "wxxcx/chg_agateway_cfg/" + n.globalData.gbvendor,
      method: "POST",
      header: {
        "content-type": "application/json",
        Authorization: n.globalData.token
      },
      data: {
        serialnum: this.data.serialnum,
        type: "volume",
        value: parseInt(this.data.vIndex)
      },
      success: function(a) {
        0 == a.data.errcode || wx.showModal({
          title: "提示",
          content: a.data.errtype,
          showCancel: !1
        })
      },
      fail: function(a) {
        wx.showModal({
          title: "提示",
          content: "通信超时",
          showCancel: !1
        })
      }
    })
  }
});