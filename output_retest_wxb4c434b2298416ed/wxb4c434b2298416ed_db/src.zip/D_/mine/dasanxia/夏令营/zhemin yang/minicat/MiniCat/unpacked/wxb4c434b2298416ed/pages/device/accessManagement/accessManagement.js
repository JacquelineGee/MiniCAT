var a = require("../../../4E9A06A0438FECAF28FC6EA7F19A10C4.js"),
  t = getApp();
Page({
  data: {
    serialnum: "",
    name: "单元门禁",
    note: "",
    nInfo: "苏州启迪时尚科技城",
    detail: "38幢1单元",
    pInfo: "启迪物业",
    pTel: "15912345678"
  },
  onLoad: function(a) {
    var e = a.serialnum;
    this.setData({
      serialnum: e
    });
    var o = this;
    wx.request({
      url: t.globalData.gburl + "wxxcx/get_access/" + t.globalData.gbvendor,
      method: "POST",
      header: {
        "content-type": "application/json",
        Authorization: t.globalData.token
      },
      data: {
        fplock: this.data.serialnum,
        recipient: t.globalData.unionid
      },
      success: function(a) {
        0 == a.data.errcode ? o.setData({
          note: a.data.lockname,
          nInfo: a.data.info,
          detail: a.data.address
        }) : wx.showModal({
          title: "提示",
          content: a.data.errtype,
          showCancel: !1
        })
      },
      fail: function(a) {
        wx.showModal({
          title: "提示",
          content: "通信超时",
          showCancel: !1
        })
      }
    })
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  changeName: function(a) {
    this.setData({
      showToastName: !0,
      errflag: !1,
      toastInput: ""
    })
  },
  toastCancel: function(a) {
    this.setData({
      showToastName: !1
    })
  },
  toastConfirm: function(e) {
    if (this.data.toastInput) {
      wx.showLoading({
        title: "上传中",
        mask: !0
      });
      var o = this;
      wx.request({
        url: t.globalData.gburl + "wxxcx/chg_accessname/" + t.globalData.gbvendor,
        method: "POST",
        header: {
          "content-type": "application/json",
          Authorization: t.globalData.token
        },
        data: {
          fplock: o.data.serialnum,
          recipient: t.globalData.unionid,
          lockname: o.data.toastInput
        },
        success: function(e) {
          wx.hideLoading(), 0 == e.data.errcode ? (a.chgFplock(o.data.serialnum, {
            name: o.data.toastInput,
            gateway: null,
            locktype: t.globalData.userData.fplocklist[o.data.serialnum].locktype,
            note: t.globalData.userData.fplocklist[o.data.serialnum].note
          }), wx.showModal({
            title: "提示",
            content: "修改成功",
            showCancel: !1,
            success: function(a) {
              o.setData({
                showToastName: !1,
                note: o.data.toastInput
              })
            }
          })) : wx.showModal({
            title: "提示",
            content: e.data.errtype,
            showCancel: !1
          })
        },
        fail: function(a) {
          wx.hideLoading(), wx.showModal({
            title: "提示",
            content: "通信超时",
            showCancel: !1
          })
        }
      })
    } else this.setData({
      errflag: !0,
      errmsg: "请输入名称"
    })
  },
  toastInput: function(a) {
    this.setData({
      errflag: !1,
      errmsg: "",
      toastInput: a.detail.value
    })
  },
  deleteDevice: function() {
    var e = this;
    wx.showLoading({
      title: "同步中",
      mask: !0
    }), wx.request({
      url: t.globalData.gburl + "wxxcx/del_fpauthorize/" + t.globalData.gbvendor,
      method: "POST",
      header: {
        "content-type": "application/json",
        Authorization: t.globalData.token
      },
      data: {
        fplock: this.data.serialnum,
        recipient: t.globalData.unionid
      },
      success: function(t) {
        if (wx.hideLoading(), 0 == t.data.errcode) {
          var o = [e.data.serialnum];
          a.delFplock(o), wx.showModal({
            title: "提示",
            content: "删除成功",
            showCancel: !1,
            success: function(a) {
              wx.navigateBack()
            }
          })
        } else wx.showModal({
          title: "提示",
          content: "删除失败",
          showCancel: !1
        })
      },
      fail: function(a) {
        wx.hideLoading(), wx.showModal({
          title: "提示",
          content: a.errMsg,
          showCancel: !1,
          success: function(a) {
            wx.navigateBack()
          }
        })
      }
    })
  }
});