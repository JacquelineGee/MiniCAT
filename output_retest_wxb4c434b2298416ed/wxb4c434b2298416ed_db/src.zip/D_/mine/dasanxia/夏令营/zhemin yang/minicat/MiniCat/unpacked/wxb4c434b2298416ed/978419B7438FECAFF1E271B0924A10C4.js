function e(e) {
  if (Array.isArray(e)) {
    for (var t = 0, r = Array(e.length); t < e.length; t++) r[t] = e[t];
    return r
  }
  return Array.from(e)
}

function t(e) {
  return e < 10 ? "0" + e : "" + e
}

function r(e, r) {
  for (var e = e || 0, r = r || 1, n = [], a = e; a <= r; a++) n.push(t(a));
  return n
}

function n(e, t) {
  var n = e % 400 == 0 || e % 4 == 0 && e % 100 != 0,
    a = null;
  switch (t) {
    case "01":
    case "03":
    case "05":
    case "07":
    case "08":
    case "10":
    case "12":
      a = r(1, 31);
      break;
    case "04":
    case "06":
    case "09":
    case "11":
      a = r(1, 30);
      break;
    case "02":
      a = n ? r(1, 29) : r(1, 28);
      break;
    default:
      a = "月份格式不正确，请重新输入！"
  }
  return a
}

function a() {
  var e = new Date;
  return [t(e.getFullYear()), t(e.getMonth() + 1), t(e.getDate()), t(e.getHours()), t(e.getMinutes()), t(e.getSeconds())]
}
module.exports = {
  dateTimePicker: function(t, c, s) {
    var u = [],
      i = [
        [],
        [],
        [],
        [],
        [],
        []
      ],
      o = t || 1978,
      l = c || 2100,
      f = s ? [].concat(e(s.split(" ")[0].split("-")), e(s.split(" ")[1].split(":"))) : a();
    return i[0] = r(o, l), i[1] = r(1, 12), i[2] = n(f[0], f[1]), i[3] = r(0, 23), i[4] = r(0, 59), i[5] = r(0, 59), i.forEach(function(e, t) {
      u.push(e.indexOf(f[t]))
    }), {
      dateTimeArray: i,
      dateTime: u
    }
  },
  getMonthDay: n,
  customTime: function(e, t) {
    var r = null;
    return 5 == e.length ? r = e[0][t[0]] + "-" + e[1][t[1]] + "-" + e[2][t[2]] + " " + e[3][t[3]] + ":" + e[4][t[4]] : 6 == e.length && (r = e[0][t[0]] + "-" + e[1][t[1]] + "-" + e[2][t[2]] + " " + e[3][t[3]] + ":" + e[4][t[4]] + ":" + e[5][t[5]]), {
      customTime: r
    }
  }
};