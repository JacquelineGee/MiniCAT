require("../../../../438C6F16438FECAF25EA07112F9A10C4.js"), require("../../../../80E7AA76438FECAFE681C27142BA10C4.js");
var a = require("../../../../978419B7438FECAFF1E271B0924A10C4.js"),
  t = getApp();
Page({
  data: {
    serialnum: "",
    nameRecords: [],
    id: "",
    name: "",
    type: "",
    showToastName: !1,
    longTime: !1,
    dateTimeArrayStart: null,
    dateTimeStart: null,
    dateTimeArrayEnd: null,
    dateTimeEnd: null,
    startTime: null,
    endTime: null,
    startYear: 2019,
    endYear: 2030,
    errmsg: "",
    isAdmin: !1,
    userBinded: !1,
    realName: "",
    gender: "",
    idNumber: "",
    moblie: ""
  },
  onLoad: function(e) {
    var i = JSON.parse(e.userNode);
    this.setData({
      serialnum: i.serialnum,
      nameRecords: i.nameRecords,
      id: i.info.id,
      name: i.info.name,
      type: i.info.type
    }), "管理指纹" == this.data.type || "管理密码" == this.data.type ? this.setData({
      isAdmin: !0,
      userBinded: !0
    }) : this.setData({
      isAdmin: !1,
      userBinded: !1
    });
    var r = this;
    wx.request({
      url: t.globalData.gburl + "wxxcx/GYGetFpuser/" + t.globalData.gbvendor,
      method: "POST",
      header: {
        "content-type": "application/json",
        Authorization: t.globalData.token
      },
      data: {
        fpSerialnum: this.data.serialnum,
        fpUid: parseInt(this.data.id)
      },
      success: function(t) {
        if (t.data.data.isRented) {
          var e = t.data.data.beginTime + ":00",
            i = a.dateTimePicker(r.data.startYear, r.data.endYear, e),
            n = t.data.data.endTime + ":00",
            d = a.dateTimePicker(r.data.startYear, r.data.endYear, n),
            s = (i.dateTimeArray.pop(), i.dateTime.pop(), d.dateTimeArray.pop(), d.dateTime.pop(), t.data.data.idCard.substr(0, 4) + "*********" + t.data.data.idCard.substr(-4, 4)),
            o = "";
          switch (t.data.data.sex) {
            case 1:
              o = "男";
              break;
            case 2:
              o = "女";
              break;
            default:
              o = "未知"
          }
          r.setData({
            dateTimeStart: i.dateTime,
            dateTimeArrayStart: i.dateTimeArray,
            dateTimeEnd: d.dateTime,
            dateTimeArrayEnd: d.dateTimeArray,
            userBinded: t.data.data.isRented,
            startTime: t.data.data.beginTime,
            endTime: t.data.data.endTime,
            longTime: t.data.data.forever,
            realName: t.data.data.name,
            gender: o,
            idNumber: s,
            moblie: t.data.data.phone
          })
        }
      },
      fail: function(a) {}
    })
  },
  changeName: function(a) {
    this.setData({
      showToastName: !0,
      errflag: !1,
      toastInput: ""
    })
  },
  toastCancel: function(a) {
    this.setData({
      showToastName: !1
    })
  },
  toastConfirm: function(a) {
    var e = this;
    this.data.toastInput ? wx.request({
      url: t.globalData.gburl + "wxxcx/chg_fpusernames/" + t.globalData.gbvendor,
      method: "POST",
      header: {
        "content-type": "application/json",
        Authorization: t.globalData.token
      },
      data: {
        serialnum: e.data.serialnum,
        nameid: parseInt(e.data.id),
        nickname: e.data.toastInput
      },
      success: function(a) {
        e.setData({
          showToastName: !1,
          name: e.data.toastInput
        });
        for (var t = e.data.nameRecords[e.data.serialnum], i = parseInt(e.data.id), r = 0; r < t.length; r++) i == t[r][0] && (t[r][1] = e.data.toastInput);
        wx.setStorageSync("nameRecords", e.data.nameRecords)
      },
      fail: function(a) {
        wx.showModal({
          title: "提示",
          content: "修改失败",
          showCancel: !1,
          success: function(a) {
            e.setData({
              showToastName: !1
            })
          }
        })
      }
    }) : this.setData({
      errflag: !0,
      errmsg: "请输入名称"
    })
  },
  toastInput: function(a) {
    this.setData({
      errflag: !1,
      errmsg: "",
      toastInput: a.detail.value
    })
  },
  bindUser: function(a) {
    wx.navigateTo({
      url: "/pages/user/bindUser/bindUser?serialnum=" + this.data.serialnum + "&uid=" + this.data.id
    })
  },
  remoteDeleteUser: function(a) {
    var e = this;
    wx.request({
      url: t.globalData.gburl + "wxxcx/GYdel_remoteuser/" + t.globalData.gbvendor,
      method: "POST",
      header: {
        "content-type": "application/json",
        Authorization: t.globalData.token
      },
      data: {
        serialnum: e.data.serialnum,
        nameid: parseInt(e.data.id)
      },
      success: function(a) {
        0 == a.data.errcode ? wx.showModal({
          title: "提示",
          content: "删除命令发送成功，请等待门锁同步",
          showCancel: !1
        }) : wx.showModal({
          title: "提示",
          content: a.data.errtype,
          showCancel: !1
        })
      },
      fail: function(a) {
        "request:fail " == a.errMsg ? wx.showModal({
          title: "提示",
          content: "请求失败",
          showCancel: !1
        }) : wx.showModal({
          title: "提示",
          content: a.errMsg,
          showCancel: !1
        })
      }
    })
  },
  changeAuthDurantion: function(e) {
    var i = this;
    if (0 == this.data.longTime) {
      var r = a.customTime(this.data.dateTimeArrayStart, this.data.dateTimeStart).customTime,
        n = a.customTime(this.data.dateTimeArrayEnd, this.data.dateTimeEnd).customTime;
      if (Date.parse(n.replace(/-/g, "/")) - Date.parse(r.replace(/-/g, "/")) <= 0) return void this.setData({
        end_date_warn: "weui-cell_warn",
        errmsg: "请输入有效时间段"
      })
    }
    wx.request({
      url: t.globalData.gburl + "wxxcx/GYChgAuthorTime/" + t.globalData.gbvendor,
      method: "POST",
      header: {
        "content-type": "application/json",
        Authorization: t.globalData.token
      },
      data: {
        fpSerialnum: this.data.serialnum,
        fpUid: parseInt(this.data.id),
        forever: !1,
        beginTime: this.data.startTime,
        endTime: this.data.endTime
      },
      success: function(a) {
        0 == a.data.errcode ? wx.showToast({
          title: "修改成功"
        }) : i.setData({
          errflag: !0,
          errmsg: a.data.errtype
        })
      },
      fail: function(a) {
        i.setData({
          errflag: !0,
          errmsg: "通信超时"
        })
      }
    })
  },
  changeDateTimeStart: function(t) {
    var e = a.customTime(this.data.dateTimeArrayStart, t.detail.value).customTime;
    this.setData({
      startTime: e
    })
  },
  changeDateTimeColumnStart: function(t) {
    var e = this.data.dateTimeStart,
      i = this.data.dateTimeArrayStart;
    e[t.detail.column] = t.detail.value, i[2] = a.getMonthDay(i[0][e[0]], i[1][e[1]]), this.setData({
      dateTimeArrayStart: i,
      end_date_warn: "",
      errmsg: ""
    })
  },
  changeDateTimeEnd: function(t) {
    var e = a.customTime(this.data.dateTimeArrayEnd, t.detail.value).customTime;
    this.setData({
      endTime: e
    })
  },
  changeDateTimeColumnEnd: function(t) {
    var e = this.data.dateTimeEnd,
      i = this.data.dateTimeArrayEnd;
    e[t.detail.column] = t.detail.value, i[2] = a.getMonthDay(i[0][e[0]], i[1][e[1]]), this.setData({
      dateTimeArrayEnd: i,
      end_date_warn: "",
      errmsg: ""
    })
  }
});