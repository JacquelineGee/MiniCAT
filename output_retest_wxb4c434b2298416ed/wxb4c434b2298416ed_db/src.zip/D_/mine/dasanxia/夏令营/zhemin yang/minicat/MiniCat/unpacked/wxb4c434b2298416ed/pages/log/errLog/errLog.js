var t = require("../../../80E7AA76438FECAFE681C27142BA10C4.js"),
  a = getApp();
Page({
  data: {
    serialnum: "",
    start_date: t.formatCustomTime(new Date, "yyyy-MM-dd"),
    end_date: t.formatCustomTime(new Date, "yyyy-MM-dd"),
    alarmRecords: {},
    curAlarmMaxTime: 0,
    errLog: []
  },
  onLoad: function(t) {
    var a;
    a = t.serialnum, this.setData({
      serialnum: a
    }), this.queryAlarmRecord()
  },
  queryAlarmRecord: function() {
    var t = this,
      e = new Date("1970/1/1 00:00:00"),
      r = 60 * (new Date).getTimezoneOffset(),
      d = (new Date(this.data.start_date) - e) / 1e3 + r,
      s = (new Date(this.data.end_date) - e) / 1e3 + r + 86400;
    wx.request({
      url: a.globalData.gburl + "wxxcx/GYGetAlarm/" + a.globalData.gbvendor,
      method: "POST",
      header: {
        "content-type": "application/json",
        Authorization: a.globalData.token
      },
      data: {
        fpSerialnum: t.data.serialnum,
        beginTimeSec: d,
        endTimeSec: s
      },
      success: function(a) {
        var e = [];
        if (0 == a.data.errcode)
          for (var r = 0; r < a.data.data.length; r++) e.push([a.data.data[r].time, a.data.data[r].type, a.data.data[r].note]);
        t.data.alarmRecords[t.data.serialnum] = e, t.syncDispErrLog()
      },
      fail: function(t) {}
    })
  },
  syncDispErrLog: function() {
    new Date(this.data.start_date);
    for (var a = new Date(this.data.end_date), e = new Date("1970/1/1 00:00:00"), r = this.data.alarmRecords[this.data.serialnum], d = [], s = 60 * (new Date).getTimezoneOffset(), i = new Date(this.data.start_date); i <= a; i.setDate(i.getDate() + 1)) {
      var n = (i - e) / 1e3 + s,
        o = n + 86400,
        l = {
          date: t.formatCustomTime(i, "yyyy-MM-dd"),
          detail: []
        },
        m = ["系统锁定", "防拆开关", "锁芯开启", "低电压", "系统上电", "恢复出厂", "下发用户", "删除用户", "冻结用户", "启用用户", "修改设置"];
      for (var u in r)
        if (r[u][0] >= n && r[u][0] < o) {
          var h = new Date("1970/1/1 00:00:00");
          h.setSeconds(h.getSeconds() + r[u][0]);
          var c = m[r[u][1]];
          r[u][1] >= 6 && r[u][1] <= 9 && (c += r[u][2]), l.detail.push({
            time: t.formatCustomTime(h, "hh:mm:ss"),
            errSource: c
          })
        } l.detail.sort(function(t, a) {
        return a.time.localeCompare(t.time)
      }), l.detail.length && d.push(l)
    }
    this.setData({
      errLog: d
    })
  },
  bindStartDateChange: function(t) {
    var a = t.detail.value.split("-"),
      e = this.data.end_date.split("-");
    a[0] + a[1] + a[2] > e[0] + e[1] + e[2] && this.setData({
      end_date: t.detail.value
    }), this.data.dateErr && this.setData({
      end_date_warn: "",
      dateErr: !1
    }), this.setData({
      start_date_warn: "",
      errmsg: ""
    }), this.setData({
      start_date: t.detail.value
    })
  },
  bindEndDateChange: function(t) {
    this.data.dateErr && this.setData({
      start_date_warn: "",
      dateErr: !1
    }), this.setData({
      end_date_warn: "",
      errmsg: ""
    }), this.setData({
      end_date: t.detail.value
    })
  },
  checkLogBtn: function(t) {
    this.queryAlarmRecord(), wx.showToast({
      title: "更新成功"
    })
  }
});