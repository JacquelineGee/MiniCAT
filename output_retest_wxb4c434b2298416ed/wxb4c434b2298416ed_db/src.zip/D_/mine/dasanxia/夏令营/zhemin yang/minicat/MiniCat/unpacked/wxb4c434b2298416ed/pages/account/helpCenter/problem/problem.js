Page({
  data: {
    icon: "iconfont icon-biaoqian2",
    iconStyle: "margin-right: 5px;vertical-align: middle;font-size:40rpx;color:#2db3e9",
    list: [{
      id: 1,
      title: "访客密码是什么？",
      open: !1,
      content: [{
        icon: "iconfont icon-biaoqian2",
        text: "访客密码又称动态密码或电子钥匙。"
      }, {
        icon: "iconfont icon-biaoqian2",
        text: "动态授权密码，有效期为五分钟，每分钟可更新一次，有效期为更新时间的前后五分钟。"
      }, {
        icon: "iconfont icon-biaoqian2",
        text: "访客密码，计时与计次密码同时有效。"
      }, {
        icon: "iconfont icon-biaoqian2",
        text: "计次类密码与计时密码同时只有一组有效，输入新密码后，之前密码自动失效。"
      }]
    }, {
      id: 2,
      title: "访客密码无法解锁",
      open: !1,
      content: [{
        icon: "iconfont icon-zhinengsuo",
        text: "系统访客密码功能处于【关闭】状态。"
      }, {
        icon: "iconfont icon-zhinengsuo",
        text: "系统开门方式设置为【指纹】。"
      }, {
        icon: "iconfont icon-zhinengsuo",
        text: "系统时间跟标准北京时间误差过大。"
      }, {
        icon: "iconfont icon-zhinengsuo",
        text: "管理密码输入错误。"
      }]
    }, {
      id: 3,
      title: "IC卡无法解锁",
      open: !1,
      content: [{
        icon: "iconfont icon-zhinengsuo",
        text: "未设置开锁方式为【标准模式】。"
      }]
    }, {
      id: 4,
      title: "遥控器无法解锁",
      open: !1,
      content: [{
        icon: "iconfont icon-yaokongqi",
        text: "不在有效范围内。"
      }, {
        icon: "iconfont icon-yaokongqi",
        text: "电池电量低，请更换遥控器电池。"
      }]
    }, {
      id: 5,
      title: "系统无反应",
      open: !1,
      content: [{
        icon: "iconfont icon-zhinengsuo",
        text: "电池电量低，尝试接备用电源。"
      }]
    }]
  },
  onLoad: function(n) {},
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  accordionBindTap: function(n) {
    for (var o = n.currentTarget.id, i = this.data.list, t = 0; t < i.length; ++t) i[t].id == o ? i[t].open = !i[t].open : i[t].open = !1;
    this.setData({
      list: i
    })
  },
  onShareAppMessage: function() {}
});