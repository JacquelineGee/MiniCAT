var a = getApp(),
  e = require("../../C4C43A20438FECAFA2A25227A86A10C4.js"),
  t = require("../../80E7AA76438FECAFE681C27142BA10C4.js"),
  o = require("../../4E9A06A0438FECAF28FC6EA7F19A10C4.js"),
  n = require("../../438C6F16438FECAF25EA07112F9A10C4.js");
Page({
  data: {
    iconStyle: a.globalData.iconStyle,
    userInfo: {
      avatarUrl: "/image/userinfo-avatar-default.png",
      nickName: "未登录"
    },
    showToastQRCode: !1,
    canvasHidden: !1,
    maskHidden: !0,
    imagePath: "",
    userqrcode: null,
    expireTime: "",
    isLogin: !1,
    showToastRegisteredInfo: !1,
    realName: [],
    registered: !1,
    authenticated: !1
  },
  onLoad: function(n) {
    void 0 !== n.serialnum && (a.globalData.curlockSerialnum = n.serialnum), a.globalData.unionid || (o.userDataDefault(), wx.showLoading({
      title: "加载中",
      mask: !0
    }), e.login().then(function(e) {
      wx.request({
        url: a.globalData.gburl + "wxxcx/login/" + a.globalData.gbvendor,
        data: {
          login_stage: "codeid",
          code: e.code
        },
        header: {
          "content-type": "application/json"
        },
        success: function(e) {
          if (0 == e.data.errcode)
            if ("codeid" == e.data.login_stage) {
              if (a.globalData.sessionkey = e.data.sessionkey, wx.hideLoading(), !t.needRelogin()) {
                wx.showLoading({
                  title: "登录中",
                  mask: !0
                });
                var o = {
                  login_stage: "decrypt_unionid",
                  unionid: a.globalData.unionid
                };
                wx.request({
                  url: a.globalData.gburl + "wxxcx/login/" + a.globalData.gbvendor,
                  data: o,
                  method: "GET",
                  header: {
                    "content-type": "application/json"
                  },
                  success: function(e) {
                    if (wx.hideLoading(), 0 == e.data.errcode) {
                      switch (a.globalData.token = e.data.token, a.globalData.realName.name = e.data.realName.name, e.data.realName.phone ? a.globalData.realName.mobile = e.data.realName.phone : a.globalData.realName.mobile = "未登记", e.data.realName.idCard && (a.globalData.realName.idNumber = e.data.realName.idCard.substr(0, 4) + "**********" + e.data.realName.idCard.substr(-4, 4)), e.data.realName.sex) {
                        case 1:
                          a.globalData.realName.gender = "男";
                          break;
                        case 2:
                          a.globalData.realName.gender = "女";
                          break;
                        default:
                          a.globalData.realName.gender = "未知"
                      }
                      wx.reLaunch({
                        url: "/pages/index/index"
                      })
                    } else wx.removeStorageSync("unionid"), wx.showToast({
                      title: "登录失败",
                      icon: "none",
                      duration: 2e3
                    })
                  },
                  fail: function(a) {
                    wx.removeStorageSync("unionid"), wx.hideLoading(), wx.showToast({
                      title: "登录失败",
                      icon: "none",
                      duration: 2e3
                    })
                  }
                })
              }
            } else wx.hideLoading();
          else wx.hideLoading()
        },
        fail: function(a) {
          wx.hideLoading()
        }
      })
    }))
  },
  onShow: function() {
    a.globalData.unionid && this.setData({
      isLogin: !0,
      userInfo: a.globalData.userInfo.userInfo
    }), a.globalData.realName.name && this.setData({
      registered: !0,
      realName: a.globalData.realName
    }), a.globalData.realName.idNumber ? this.setData({
      authenticated: !0
    }) : this.setData({
      authenticated: !1
    })
  },
  toastClose: function() {
    this.setData({
      showToastQRCode: !1,
      maskHidden: !0,
      canvasHidden: !0,
      imagePath: "/image/qrmask.png"
    })
  },
  showUserQRCode: function() {
    if (a.globalData.unionid)
      if (this.data.registered) {
        var e = this,
          o = t.formatCustomTime(new Date(Date.parse(new Date) + 3e5), "yyyy-MM-dd hh:mm"),
          i = new Date(1970, 0, 1),
          l = Math.floor((Date.now() - i) / 6e4).toString(),
          s = Math.floor((new Date(Date.parse(new Date) + 3e5) - i) / 6e4).toString(),
          d = JSON.stringify({
            type: 0,
            data: a.globalData.unionid,
            beginTimeMin: l,
            expireTimeMin: s
          }),
          r = n.enc.Utf8.parse(a.globalData.desKey),
          g = n.DES.encrypt(d, r, {
            mode: n.mode.ECB,
            padding: n.pad.Pkcs7
          }).toString();
        this.setData({
          showToastQRCode: !0,
          maskHidden: !1,
          canvasHidden: !1,
          userqrcode: g,
          expireTime: o
        }), wx.showLoading({
          title: "加载中"
        }), t.creatIdentificationCode(this.data.userqrcode), setTimeout(function() {
          wx.canvasToTempFilePath({
            canvasId: "qrcanvas",
            success: function(a) {
              var t = a.tempFilePath;
              wx.hideLoading(), e.setData({
                imagePath: t
              })
            },
            fail: function(a) {
              wx.hideLoading(), wx.showToast({
                title: "加载失败",
                icon: "none"
              })
            }
          })
        }, 1e3)
      } else wx.showModal({
        title: "提示",
        content: "请先完成实名认证和信息登记",
        success: function(a) {
          a.confirm || a.cancel
        }
      });
    else wx.showToast({
      title: "请登录系统",
      icon: "none"
    })
  },
  quitBtn: function(e) {
    var t = this;
    wx.showModal({
      title: "提示",
      content: "退出系统",
      success: function(e) {
        if (e.confirm) try {
          wx.showLoading({
            title: "清空缓存"
          }), a.globalData.userinfo = null, a.globalData.unionid = null, a.globalData.token = null, a.globalData.curlockSerialnum = null, a.globalData.lastGetDpasswdTime = 0, a.globalData.userData.fplocklistFlag = !1, a.globalData.userData.fplocklist = null, a.globalData.userData.fplocklistFlag = !1, a.globalData.realName.name = null, a.globalData.realName.gender = null, a.globalData.realName.mobile = null, a.globalData.realName.idNumber = null, wx.clearStorageSync(), t.data.userInfo.avatarUrl = "/image/userinfo-avatar-default.png", t.data.userInfo.nickName = "未登录", t.setData({
            userInfo: t.data.userInfo,
            isLogin: !1,
            registered: !1
          }), wx.hideLoading()
        } catch (a) {} else e.cancel
      }
    })
  },
  loginBtn: function(e) {
    wx.showLoading({
      title: "登录中",
      mask: !0
    }), a.globalData.userInfo = e.detail, wx.setStorageSync("userInfo", a.globalData.userInfo);
    try {
      var t = wx.getStorageSync("unionid");
      if ("" == t) o = {
        login_stage: "decrypt_unionid",
        sessionkey: a.globalData.sessionkey,
        iv: e.detail.iv,
        encryptedData: e.detail.encryptedData
      };
      else o = {
        login_stage: "decrypt_unionid",
        sessionkey: a.globalData.sessionkey,
        iv: e.detail.iv,
        encryptedData: e.detail.encryptedData,
        unionid: t
      }
    } catch (t) {
      var o = {
        login_stage: "decrypt_unionid",
        sessionkey: a.globalData.sessionkey,
        iv: e.detail.iv,
        encryptedData: e.detail.encryptedData
      }
    }
    wx.request({
      url: a.globalData.gburl + "wxxcx/login/" + a.globalData.gbvendor,
      data: o,
      method: "GET",
      header: {
        "content-type": "application/json"
      },
      success: function(e) {
        if (wx.hideLoading(), 0 == e.data.errcode) {
          switch (a.globalData.unionid = e.data.unionid, a.globalData.token = e.data.token, a.globalData.realName.name = e.data.realName.name, e.data.realName.phone ? a.globalData.realName.mobile = e.data.realName.phone : a.globalData.realName.mobile = "未登记", e.data.realName.idCard && (a.globalData.realName.idNumber = e.data.realName.idCard.substr(0, 4) + "**********" + e.data.realName.idCard.substr(-4, 4)), e.data.realName.sex) {
            case 1:
              a.globalData.realName.gender = "男";
              break;
            case 2:
              a.globalData.realName.gender = "女";
              break;
            default:
              a.globalData.realName.gender = "未知"
          }
          wx.setStorageSync("unionid", a.globalData.unionid), wx.reLaunch({
            url: "/pages/index/index"
          })
        } else wx.showToast({
          title: "登录失败",
          icon: "none",
          duration: 2e3
        })
      },
      fail: function(a) {
        wx.hideLoading(), wx.showToast({
          title: "登录失败",
          icon: "none",
          duration: 2e3
        })
      }
    })
  },
  bindRegisteredInfo: function(a) {
    this.setData({
      showToastRegisteredInfo: !0
    })
  },
  toastCloseRPInfo: function(a) {
    this.setData({
      showToastRegisteredInfo: !1
    })
  },
  bindUnregistered: function(a) {
    wx.showModal({
      title: "提示",
      content: "请先完成实名认证和信息登记",
      showCancel: !1
    })
  },
  ocrSuccess: function(e) {
    var t = e.detail.id.text;
    wx.showModal({
      title: "识别结果",
      content: "身份号码: " + e.detail.id.text,
      cancelText: "识别错误",
      success: function(e) {
        e.confirm ? wx.request({
          url: a.globalData.gburl + "wxxcx/GYSyncIDCard/" + a.globalData.gbvendor,
          method: "POST",
          header: {
            "content-type": "application/json",
            Authorization: a.globalData.token
          },
          data: {
            idCard: t
          },
          success: function(a) {
            0 == a.data.errcode && wx.showModal({
              title: "提示",
              content: "认证成功，请重新登录"
            })
          }
        }) : e.cancel && console.log("用户点击取消")
      }
    })
  }
});