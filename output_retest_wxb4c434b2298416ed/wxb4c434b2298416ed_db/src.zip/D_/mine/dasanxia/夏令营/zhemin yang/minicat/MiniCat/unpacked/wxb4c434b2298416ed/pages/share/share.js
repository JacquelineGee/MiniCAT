var i = require("../../80E7AA76438FECAFE681C27142BA10C4.js"),
  e = getApp();
Page({
  data: {
    dynamicKeys: "",
    visitorKeys: "",
    expireTime: "",
    unlockNum: ""
  },
  onLoad: function(i) {
    var e = JSON.parse(i.dkeyNode);
    if (9 == e.keys.length)(t = e.keys.split("")).splice(4, 1), this.setData({
      dynamicKeys: t,
      expireTime: e.expireTime
    });
    else {
      var t = e.keys.split("");
      t.splice(4, 1), t.splice(8, 1), e.unlockNum && this.setData({
        visitorKeys: t,
        unlockNum: e.unlockNum
      }), e.expireTime && this.setData({
        visitorKeys: t,
        expireTime: e.expireTime
      })
    }
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function(i) {
    var e = null;
    return this.data.dynamicKeys ? (this.data.dynamicKeys.splice(4, 0, " "), e = JSON.stringify({
      keys: this.data.dynamicKeys.join(""),
      expireTime: this.data.expireTime
    })) : (this.data.visitorKeys.splice(4, 0, " "), this.data.visitorKeys.splice(9, 0, " "), e = this.data.unlockNum ? JSON.stringify({
      keys: this.data.visitorKeys.join(""),
      unlockNum: this.data.unlockNum
    }) : JSON.stringify({
      keys: this.data.visitorKeys.join(""),
      expireTime: this.data.expireTime
    })), {
      title: "解锁密码，不要轻易告诉他人哟！",
      path: "/pages/share/share?dkeyNode=" + e
    }
  },
  backIndexBtn: function(t) {
    e.globalData.unionid ? (e.globalData.lastGetDpasswdTime = 0, i.backIndex()) : wx.reLaunch({
      url: "/pages/login/login"
    })
  }
});