function n(n, e) {
  if (!(n instanceof e)) throw new TypeError("Cannot call a class as a function")
}
var e = function() {
    function n(n, e) {
      for (var r = 0; r < e.length; r++) {
        var t = e[r];
        t.enumerable = t.enumerable || !1, t.configurable = !0, "value" in t && (t.writable = !0), Object.defineProperty(n, t.key, t)
      }
    }
    return function(e, r, t) {
      return r && n(e.prototype, r), t && n(e, t), e
    }
  }(),
  r = function() {
    function r() {
      n(this, r)
    }
    return e(r, null, [{
      key: "login",
      value: function() {
        return new Promise(function(n, e) {
          return wx.login({
            success: n,
            fail: e
          })
        })
      }
    }]), r
  }();
module.exports = r;