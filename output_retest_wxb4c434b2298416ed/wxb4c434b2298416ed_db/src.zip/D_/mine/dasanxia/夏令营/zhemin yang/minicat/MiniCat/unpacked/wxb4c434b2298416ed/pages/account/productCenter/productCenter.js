require("../../../80E7AA76438FECAFE681C27142BA10C4.js"), require("../../../4E9A06A0438FECAF28FC6EA7F19A10C4.js");
var n, i = getApp();
Page({
  data: {
    imgUrls: ["https://www.samcharm.com/weapp/wp-content/uploads/sites/4/2019/05/SLM-OLED-Manual-V20_09.jpg", "https://www.samcharm.com/weapp/wp-content/uploads/sites/4/2019/05/SLM-OLED-Manual-V20_09.jpg", "https://www.samcharm.com/weapp/wp-content/uploads/sites/4/2019/05/SLM-OLED-Manual-V20_09.jpg", "https://www.samcharm.com/weapp/wp-content/uploads/sites/4/2019/05/SLM-OLED-Manual-V20_09.jpg", "https://www.samcharm.com/weapp/wp-content/uploads/sites/4/2019/05/SLM-OLED-Manual-V20_09.jpg"],
    iconStyle: "margin-right: 5px;vertical-align: middle;font-size:25px;color:#2db3e9",
    list: [{
      title: "门锁模块",
      detail: [{
        icon: "iconfont icon-lockA",
        name: "SLM-D600",
        webViewURL: "https://www.samcharm.com/weapp/install/lockbody/"
      }, {
        icon: "iconfont icon-lockA",
        name: "SLM-E200",
        url: ""
      }, {
        icon: "iconfont icon-lockA",
        name: "SLM-F200",
        webViewURL: ""
      }]
    }, {
      title: "全自动模块",
      detail: [{
        icon: "iconfont icon-danmokuai",
        name: "主板",
        webViewURL: ""
      }, {
        icon: "iconfont icon-danmokuai",
        name: "按键板",
        webViewURL: ""
      }]
    }, {
      title: "指纹头",
      detail: [{
        icon: "iconfont icon-zhiwen",
        name: "",
        webViewURL: ""
      }, {
        icon: "iconfont icon-zhiwen",
        name: "",
        webViewURL: ""
      }, {
        icon: "iconfont icon-zhiwen",
        name: "",
        webViewURL: ""
      }]
    }, {
      title: "门铃",
      detail: [{
        icon: "iconfont icon-menling2",
        name: "门铃模块",
        uwebViewURLrl: ""
      }, {
        icon: "iconfont icon-wuxianmenling",
        name: "无线门铃",
        webViewURL: ""
      }]
    }, {
      title: "遥控器",
      detail: [{
        icon: "iconfont icon-yingjian",
        name: "遥控器接收端",
        webViewURL: ""
      }, {
        icon: "iconfont icon-yaokongqi",
        name: "遥控器发射端",
        webViewURL: ""
      }]
    }, {
      title: "系统工具",
      detail: [{
        icon: "iconfont icon-USB",
        name: "配置工具",
        webViewURL: ""
      }, {
        icon: "iconfont icon-ICCard",
        name: "老化测试",
        webViewURL: ""
      }]
    }]
  },
  onLoad: function(n) {},
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  navTitleBindtap: function(e) {
    i.globalData.webViewURL = this.data.list[e.currentTarget.dataset.titleid].detail[n].webViewURL, wx.navigateTo({
      url: "../helpCenter/webView/webView"
    })
  },
  navBindtap: function(i) {
    n = i.currentTarget.dataset.detailid
  },
  onShareAppMessage: function() {}
});