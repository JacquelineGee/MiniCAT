var t = require("../../../80E7AA76438FECAFE681C27142BA10C4.js"),
  a = require("../../../978419B7438FECAFF1E271B0924A10C4.js"),
  e = getApp();
Page({
  data: {
    iconStyle: "margin-right: 5px;vertical-align: middle;font-size:50rpx;color:#2db3e9",
    insideTabs: ["计次", "计时"],
    insideActiveIndex: 0,
    insideSliderOffset: 0,
    insideSliderLeft: 0,
    unlock_num: "",
    admin_pw: "",
    day_count: "",
    admin_pw_duration: "",
    date_warn: "",
    time_warn: "",
    unlock_num_warn: "",
    admin_pw_warn: "",
    day_count_warn: "",
    admin_pw_duration_warn: "",
    curLockName: "",
    curLockNameColor: "",
    visitorKeys: [{
      keys: "",
      startTime: "",
      expireTime: "",
      creatTime: "",
      show: !1
    }, {
      keys: "",
      unlockNum: "",
      creatTime: "",
      show: !1
    }, {
      keys: "",
      startTime: "",
      expireTime: "",
      creatTime: "",
      show: !1
    }],
    expireTime: "",
    errmsg: "",
    dateTimeArrayStart: null,
    dateTimeStart: null,
    startTimeV: null,
    startYear: 2019,
    endYear: 2030,
    serialnum: ""
  },
  onLoad: function(t) {
    var i = this,
      s = t.serialnum;
    this.setData({
      serialnum: s
    }), wx.getSystemInfo({
      success: function(t) {
        i.setData({
          insideSliderLeft: (t.windowWidth / i.data.insideTabs.length - 96) / 2,
          insideSliderOffset: t.windowWidth / i.data.insideTabs.length * i.data.insideActiveIndex
        })
      }
    });
    var r = a.dateTimePicker(this.data.startYear, this.data.endYear),
      n = a.customTime(r.dateTimeArray, r.dateTime).customTime,
      o = (r.dateTimeArray.pop(), r.dateTime.pop(), n.slice(0, 16));
    o = n.slice(0, 14), o += "00", this.setData({
      dateTimeStart: r.dateTime,
      dateTimeArrayStart: r.dateTimeArray,
      startTimeV: o
    }), this.setData({
      curLockName: e.globalData.userData.fplocklist[s].name,
      curLockNameColor: "limegreen"
    })
  },
  onShow: function() {
    try {
      var t = wx.getStorageSync("visitorKeys");
      if (t) {
        var a = JSON.parse(t);
        this.setData({
          "visitorKeys[1].unlockNum": a.unlockNum,
          "visitorKeys[1].keys": a.keys,
          "visitorKeys[1].creatTime": a.creatTime,
          "visitorKeys[1].show": !0
        })
      } else this.setData({
        "visitorKeys[1].show": !1
      })
    } catch (t) {}
    try {
      var e = wx.getStorageSync("visitorKeysDuration");
      if (e) {
        var i = (a = JSON.parse(e)).expireTime.replace(/-/g, "/");
        Date.parse(new Date) > Date.parse(i) ? (this.setData({
          "visitorKeys[2].show": !1
        }), wx.removeStorage({
          key: "visitorKeysDuration",
          success: function(t) {}
        })) : this.setData({
          "visitorKeys[2].keys": a.keys,
          "visitorKeys[2].startTime": a.startTime,
          "visitorKeys[2].expireTime": a.expireTime,
          "visitorKeys[2].creatTime": a.creatTime,
          "visitorKeys[2].show": !0
        })
      } else this.setData({
        "visitorKeys[2].show": !1
      })
    } catch (t) {}
  },
  bindUnlockNumInput: function(t) {
    this.setData({
      unlock_num_warn: "",
      errmsg: ""
    }), 0 == t.detail.value ? this.setData({
      unlock_num: ""
    }) : this.setData({
      unlock_num: t.detail.value
    })
  },
  bindAdminPwInput: function(t) {
    this.setData({
      admin_pw_warn: "",
      errmsg: ""
    }), this.setData({
      admin_pw: t.detail.value
    })
  },
  bindDayCountInput: function(t) {
    this.setData({
      day_count_warn: "",
      errmsg: ""
    }), 0 == t.detail.value ? this.setData({
      day_count: ""
    }) : t.detail.value > 180 ? this.setData({
      day_count: 180
    }) : this.setData({
      day_count: t.detail.value
    })
  },
  bindAdminPwInputDuration: function(t) {
    this.setData({
      admin_pw_duration_warn: "",
      errmsg: ""
    }), this.setData({
      admin_pw_duration: t.detail.value
    })
  },
  bindCopyKeys: function(t) {
    this.data.insideActiveIndex ? wx.setClipboardData({
      data: this.data.visitorKeys[2].keys,
      success: function(t) {
        wx.showToast({
          title: "复制成功",
          duration: 1e3
        })
      }
    }) : wx.setClipboardData({
      data: this.data.visitorKeys[1].keys,
      success: function(t) {
        wx.showToast({
          title: "复制成功",
          duration: 1e3
        })
      }
    })
  },
  getVisitorKeys: function(a) {
    if (this.data.unlock_num)
      if (this.data.admin_pw)
        if (this.data.admin_pw.length < 6) this.setData({
          admin_pw: "",
          admin_pw_warn: "weui-cell_warn",
          errmsg: "密码长度不符"
        });
        else {
          var i = this;
          wx.request({
            url: e.globalData.gburl + "wxxcx/get_keeloqcnt/" + e.globalData.gbvendor,
            method: "POST",
            header: {
              "content-type": "application/json",
              Authorization: e.globalData.token
            },
            data: {
              serialnum: e.globalData.curlockSerialnum
            },
            success: function(a) {
              var s = a.data.cnt,
                r = e.globalData.curlockSerialnum.split("-")[0],
                n = t.gen_dpasswd_count(r, i.data.admin_pw, s, i.data.unlock_num),
                o = t.formatCustomTime(new Date, "yyyy-MM-dd hh:mm:ss");
              n.splice(4, 0, " "), n.splice(9, 0, " "), i.setData({
                "visitorKeys[1].unlockNum": i.data.unlock_num,
                "visitorKeys[1].keys": n.join(""),
                "visitorKeys[1].creatTime": o,
                "visitorKeys[1].show": !0
              });
              var d = JSON.stringify({
                unlockNum: i.data.visitorKeys[1].unlockNum,
                keys: i.data.visitorKeys[1].keys,
                creatTime: i.data.visitorKeys[1].creatTime
              });
              try {
                wx.setStorageSync("visitorKeys", d)
              } catch (t) {}
              i.setData({
                unlock_num: "",
                admin_pw: ""
              }), s > 65e3 && wx.request({
                url: e.globalData.gburl + "wxxcx/chg_keeloqcnt/" + e.globalData.gbvendor,
                method: "POST",
                header: {
                  "content-type": "application/json",
                  Authorization: e.globalData.token
                },
                data: {
                  cnt: 1,
                  serialnum: e.globalData.curlockSerialnum
                }
              })
            },
            fail: function(t) {
              wx.showToast({
                title: "获取计数密码失败",
                icon: "none"
              })
            }
          })
        }
    else this.setData({
      admin_pw_warn: "weui-cell_warn",
      errmsg: "请输入管理密码"
    });
    else this.setData({
      unlock_num_warn: "weui-cell_warn",
      errmsg: "请输入解锁次数"
    })
  },
  getVisitorKeysDuration: function(a) {
    var i = this.data.startTimeV.slice(0, 10),
      s = this.data.startTimeV.slice(11, 16),
      r = (i.split("-"), s.split(":")),
      n = new Date(i),
      o = e.globalData.curlockSerialnum.split("-")[0];
    new Date(2019, 0, 1), new Date(2030, 0, 1);
    if (this.data.day_count)
      if (this.data.admin_pw_duration)
        if (this.data.admin_pw_duration.length < 6) this.setData({
          admin_pw_duration: "",
          admin_pw_duration_warn: "weui-cell_warn",
          errmsg: "密码长度不符"
        });
        else if (2 == e.globalData.curlockSerialnum[17] && 4 == e.globalData.curlockSerialnum[18]) {
      var d = this;
      wx.request({
        url: e.globalData.gburl + "wxxcx/get_dpasswdcnt/" + e.globalData.gbvendor,
        method: "POST",
        header: {
          "content-type": "application/json",
          Authorization: e.globalData.token
        },
        data: {
          serialnum: e.globalData.curlockSerialnum
        },
        success: function(a) {
          var i = a.data.cnt;
          n.setHours(parseInt(r[0])), n.setMinutes(parseInt(r[1]));
          var s = t.gen_dpasswd_timeinv2(parseInt(i), d.data.admin_pw_duration, n, d.data.day_count),
            o = new Date(Date.parse(new Date(n)) + 24 * d.data.day_count * 60 * 60 * 1e3);
          s.splice(4, 0, " "), s.splice(9, 0, " "), d.setData({
            "visitorKeys[2].keys": s.join(""),
            "visitorKeys[2].startTime": t.formatCustomTime(new Date(n), "yyyy-MM-dd hh:mm:ss"),
            "visitorKeys[2].expireTime": t.formatCustomTime(o, "yyyy-MM-dd hh:mm:ss"),
            "visitorKeys[2].creatTime": t.formatCustomTime(new Date, "yyyy-MM-dd hh:mm:ss"),
            "visitorKeys[2].show": !0
          });
          var m = JSON.stringify({
            keys: d.data.visitorKeys[2].keys,
            startTime: d.data.visitorKeys[2].startTime,
            expireTime: d.data.visitorKeys[2].expireTime,
            creatTime: d.data.visitorKeys[2].creatTime
          });
          try {
            wx.setStorageSync("visitorKeysDuration", m)
          } catch (t) {}
          d.setData({
            day_count: "",
            admin_pw_duration: ""
          }), i > 15e3 && wx.request({
            url: e.globalData.gburl + "wxxcx/chg_dpasswdcnt/" + e.globalData.gbvendor,
            method: "POST",
            header: {
              "content-type": "application/json",
              Authorization: e.globalData.token
            },
            data: {
              cnt: 1,
              serialnum: e.globalData.curlockSerialnum
            }
          })
        },
        fail: function(t) {
          wx.showToast({
            title: "获取计时密码失败",
            icon: "none"
          })
        }
      })
    } else {
      n.setHours(parseInt(r[0])), n.setMinutes(parseInt(r[1]));
      var m = t.gen_dpasswd_timeinv(o, this.data.admin_pw_duration, n, this.data.day_count),
        l = new Date(Date.parse(new Date(n)) + 24 * this.data.day_count * 60 * 60 * 1e3);
      m.splice(4, 0, " "), m.splice(9, 0, " "), this.setData({
        "visitorKeys[2].keys": m.join(""),
        "visitorKeys[2].startTime": t.formatCustomTime(new Date(n), "yyyy-MM-dd hh:mm:ss"),
        "visitorKeys[2].expireTime": t.formatCustomTime(l, "yyyy-MM-dd hh:mm:ss"),
        "visitorKeys[2].creatTime": t.formatCustomTime(new Date, "yyyy-MM-dd hh:mm:ss"),
        "visitorKeys[2].show": !0
      });
      var u = JSON.stringify({
        keys: this.data.visitorKeys[2].keys,
        startTime: this.data.visitorKeys[2].startTime,
        expireTime: this.data.visitorKeys[2].expireTime,
        creatTime: this.data.visitorKeys[2].creatTime
      });
      try {
        wx.setStorageSync("visitorKeysDuration", u)
      } catch (t) {}
      this.setData({
        day_count: "",
        admin_pw_duration: ""
      })
    } else this.setData({
      admin_pw_duration_warn: "weui-cell_warn",
      errmsg: "请输入管理密码"
    });
    else this.setData({
      day_count_warn: "weui-cell_warn",
      errmsg: "请输入天数"
    })
  },
  bindShareVisitorKeys: function(t) {
    try {
      var a = wx.getStorageSync("visitorKeys")
    } catch (t) {}
    wx.navigateTo({
      url: "../../share/share?dkeyNode=" + a
    })
  },
  bindShareVisitorKeysDuration: function(t) {
    try {
      var a = wx.getStorageSync("visitorKeysDuration")
    } catch (t) {}
    wx.navigateTo({
      url: "../../share/share?dkeyNode=" + a
    })
  },
  insideTabClick: function(a) {
    if (e.globalData.curlockSerialnum = this.data.serialnum, this.data.insideActiveIndex != a.currentTarget.id && (e.globalData.curlockSerialnum ? this.setData({
        start_date: "",
        start_time: "",
        unlock_num: "",
        admin_pw: "",
        start_date_warn: "",
        start_time_warn: "sui-picker__ft_color",
        unlock_num_warn: "",
        admin_pw_warn: "",
        errmsg: "",
        insideSliderOffset: a.currentTarget.offsetLeft,
        insideActiveIndex: a.currentTarget.id
      }) : wx.showToast({
        title: "请添加设备",
        icon: "none",
        mask: !0
      })), 1 == a.currentTarget.id) {
      var i = t.formatTimePickerDate(new Date),
        s = t.formatTimePickerTime(new Date);
      this.setData({
        start_date: i,
        start_time: s[0] + s[1] + ":00"
      })
    }
  },
  changeDateTimeStart: function(t) {
    var e = (e = a.customTime(this.data.dateTimeArrayStart, t.detail.value).customTime).slice(0, 14);
    e += "00", this.setData({
      startTimeV: e
    })
  },
  changeDateTimeColumnStart: function(t) {
    var e = this.data.dateTimeStart,
      i = this.data.dateTimeArrayStart;
    e[t.detail.column] = t.detail.value, i[2] = a.getMonthDay(i[0][e[0]], i[1][e[1]]), this.setData({
      dateTimeArrayStart: i,
      end_date_warn: "",
      errmsg: ""
    })
  }
});