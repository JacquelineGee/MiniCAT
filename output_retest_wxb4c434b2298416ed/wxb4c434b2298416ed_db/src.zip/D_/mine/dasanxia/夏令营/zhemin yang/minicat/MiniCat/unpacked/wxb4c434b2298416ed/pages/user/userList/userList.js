require("../../../80E7AA76438FECAFE681C27142BA10C4.js");
var a = getApp();
Page({
  data: {
    iconStyle: a.globalData.iconStyle65rpx,
    tabs: ["全部", "指纹", "密码", "身份证"],
    activeIndex: 0,
    sliderOffset: 0,
    sliderLeft: 0,
    serialnum: "",
    userRecords: {},
    nameRecords: {},
    deledNameidArr: [],
    list: [],
    toastInput: "",
    currentListNum: "",
    errflag: !1,
    errmsg: "",
    community: !1,
    firstEmptyID: null,
    showAddUser: !1
  },
  onLoad: function(e) {
    var t;
    t = e.serialnum, this.setData({
      serialnum: t
    });
    try {
      if (this.data.userRecords = wx.getStorageSync("userRecords"), this.data.nameRecords = wx.getStorageSync("nameRecords"), !this.data.userRecords || !this.data.userRecords[this.data.serialnum]) {
        wx.showLoading({
          title: "获取中",
          mask: !0
        });
        s = this;
        return wx.request({
          url: a.globalData.gburl + "wxxcx/get_fpusers/" + a.globalData.gbvendor,
          method: "POST",
          header: {
            "content-type": "application/json",
            Authorization: a.globalData.token
          },
          data: {
            serialnum: s.data.serialnum
          },
          success: function(e) {
            0 == e.data.errcode ? (s.data.userRecords || (s.data.userRecords = {}, s.data.nameRecords = {}), s.data.userRecords[s.data.serialnum] = e.data.users, wx.request({
              url: a.globalData.gburl + "wxxcx/get_fpusernames/" + a.globalData.gbvendor,
              method: "POST",
              header: {
                "content-type": "application/json",
                Authorization: a.globalData.token
              },
              data: {
                serialnum: s.data.serialnum
              },
              success: function(e) {
                wx.hideLoading(), 0 == e.data.errcode ? (s.data.nameRecords[s.data.serialnum] = e.data.names, wx.setStorageSync("userRecords", s.data.userRecords), wx.setStorageSync("nameRecords", s.data.nameRecords), s.syncDispUsername(s), wx.request({
                  url: a.globalData.gburl + "wxxcx/set_fpflag/" + a.globalData.gbvendor,
                  method: "POST",
                  header: {
                    "content-type": "application/json",
                    Authorization: a.globalData.token
                  },
                  data: {
                    serialnum: s.data.serialnum,
                    type: "user",
                    flag: 0
                  }
                })) : wx.showModal({
                  title: "提示",
                  content: "获取失败",
                  showCancel: !1,
                  success: function(a) {
                    wx.navigateBack()
                  }
                })
              },
              fail: function(a) {
                wx.hideLoading(), wx.showModal({
                  title: "提示",
                  content: "获取失败",
                  showCancel: !1,
                  success: function(a) {
                    wx.navigateBack()
                  }
                })
              }
            })) : (wx.hideLoading(), wx.showModal({
              title: "提示",
              content: "获取失败",
              showCancel: !1,
              success: function(a) {
                wx.navigateBack()
              }
            }))
          },
          fail: function(a) {
            wx.hideLoading(), wx.showModal({
              title: "提示",
              content: "获取失败",
              showCancel: !1,
              success: function(a) {
                wx.navigateBack()
              }
            })
          }
        }), !0
      }
      var s = this;
      wx.showLoading({
        title: "获取中",
        mask: !0
      }), wx.request({
        url: a.globalData.gburl + "wxxcx/get_fpflag/" + a.globalData.gbvendor,
        method: "POST",
        header: {
          "content-type": "application/json",
          Authorization: a.globalData.token
        },
        data: {
          serialnum: s.data.serialnum,
          type: "user"
        },
        success: function(e) {
          0 == e.data.errcode && 1 == e.data.flag ? wx.request({
            url: a.globalData.gburl + "wxxcx/get_fpusers/" + a.globalData.gbvendor,
            method: "POST",
            header: {
              "content-type": "application/json",
              Authorization: a.globalData.token
            },
            data: {
              serialnum: s.data.serialnum
            },
            success: function(e) {
              if (wx.hideLoading(), 0 == e.data.errcode) {
                var t = s.data.serialnum;
                s.data.userRecords[t] = e.data.users, wx.setStorageSync("userRecords", s.data.userRecords), s.syncDispUsername(s), wx.request({
                  url: a.globalData.gburl + "wxxcx/set_fpflag/" + a.globalData.gbvendor,
                  method: "POST",
                  header: {
                    "content-type": "application/json",
                    Authorization: a.globalData.token
                  },
                  data: {
                    serialnum: s.data.serialnum,
                    type: "user",
                    flag: 0
                  }
                })
              }
            },
            fail: function(a) {
              wx.hideLoading(), wx.showModal({
                title: "提示",
                content: "获取失败",
                showCancel: !1,
                success: function(a) {
                  wx.navigateBack()
                }
              })
            }
          }) : wx.hideLoading()
        },
        fail: function(a) {
          wx.hideLoading(), wx.showModal({
            title: "提示",
            content: "获取失败",
            showCancel: !1,
            success: function(a) {
              wx.navigateBack()
            }
          })
        }
      }), this.syncDispUsername(this)
    } catch (a) {
      return console.log(a), !0
    }
  },
  syncDispUsername: function(e) {
    for (var t = [], s = this.data.userRecords[this.data.serialnum], n = this.data.nameRecords[this.data.serialnum], r = [], o = [], i = 0; i < s.length; i += 2) t.push(parseInt(s.slice(i, i + 2), 16));
    for (var d = null, i = 0; i < t.length; i++)
      for (var l = 0; l < 8; l++) t[i] & 1 << l ? r.push(8 * i + l + 1) : null == d && 8 * i + l + 1 >= 106 && 8 * i + l + 1 <= 115 && (d = 8 * i + l + 1);
    e.setData({
      firstEmptyID: d
    });
    for (i = 0; i < n.length; i++) o.push(n[i][0]);
    for (var c = !1, i = 0; i < r.length; i++) o.indexOf(r[i]) < 0 && (this.data.nameRecords[this.data.serialnum].push([r[i], r[i].toString(), !1]), c = !0);
    c && wx.setStorageSync("nameRecords", this.data.nameRecords);
    for (var u = [], i = 0; i < o.length; i++) r.indexOf(o[i]) < 0 && u.push(o[i]);
    if (u.length > 0) {
      var h = this;
      h.deledNameidArr = u, wx.request({
        url: a.globalData.gburl + "wxxcx/del_fpusernames/" + a.globalData.gbvendor,
        method: "POST",
        header: {
          "content-type": "application/json",
          Authorization: a.globalData.token
        },
        data: {
          serialnum: this.data.serialnum,
          users: h.deledNameidArr
        },
        success: function(a) {
          for (var e = h.data.nameRecords[h.data.serialnum], t = 0; t < h.deledNameidArr.length; t++)
            for (var s = 0; s < e.length; s++) e[s] && h.deledNameidArr[t] == e[s][0] && delete e[s];
          var n = [];
          for (var t in h.data.nameRecords[h.data.serialnum]) n.push(h.data.nameRecords[h.data.serialnum][t]);
          h.data.nameRecords[h.data.serialnum] = n, wx.setStorageSync("nameRecords", h.data.nameRecords), h.dispUsername()
        }
      })
    } else this.dispUsername()
  },
  dispUsername: function() {
    var a = [],
      e = this.data.nameRecords[this.data.serialnum];
    if (void 0 !== e) {
      for (var t = 0; t < e.length; t++) {
        var s = {},
          n = e[t][0].toString();
        switch (n.length) {
          case 1:
            n = "00" + n;
            break;
          case 2:
            n = "0" + n
        }
        s.id = n, s.name = e[t][1], s.intimidate = e[t][2], e[t][0] >= 1 && e[t][0] <= 3 ? (s.type = "管理指纹", s.icon = "iconfont icon-guanliyuan") : e[t][0] >= 4 && e[t][0] <= 100 ? (s.type = "指纹", s.icon = "iconfont icon-zhiwen1") : 101 == e[t][0] ? (s.type = "管理密码", s.icon = "iconfont icon-guanliyuan") : e[t][0] >= 102 && e[t][0] <= 105 ? (s.type = "密码", s.icon = "iconfont icon-jianpantianchong") : e[t][0] >= 106 && e[t][0] <= 115 && (s.type = "身份证", s.icon = "iconfont icon-credentials"), a.push(s)
      }
      this.setData({
        list: a
      }), 0 == a.length ? this.setData({
        showAddUser: !1
      }) : this.setData({
        showAddUser: !0
      })
    }
  },
  onShow: function() {
    this.data.nameRecords = wx.getStorageSync("nameRecords"), this.dispUsername()
  },
  tabClick: function(a) {
    this.setData({
      sliderOffset: a.currentTarget.offsetLeft,
      activeIndex: a.currentTarget.id
    })
  },
  userDetail: function(a) {
    for (var e = {}, t = 0; t < this.data.list.length; t++)
      if (this.data.list[t].id == a.currentTarget.dataset.id) {
        e.serialnum = this.data.serialnum, e.info = this.data.list[t], e.nameRecords = this.data.nameRecords, e.community = this.data.community;
        break
      } wx.navigateTo({
      url: "userInfo/userInfo?userNode=" + JSON.stringify(e)
    })
  },
  addUser: function(a) {
    null == this.data.firstEmptyID ? wx.showToast({
      title: "身份证用户已满",
      duration: 1e3
    }) : wx.navigateTo({
      url: "/pages/user/addUser/addUser?serialnum=" + this.data.serialnum + "&uid=" + this.data.firstEmptyID
    })
  }
});