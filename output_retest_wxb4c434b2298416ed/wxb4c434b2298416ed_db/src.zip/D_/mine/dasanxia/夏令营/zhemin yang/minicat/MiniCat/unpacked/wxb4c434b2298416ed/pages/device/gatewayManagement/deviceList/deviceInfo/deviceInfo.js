require("../../../../../80E7AA76438FECAFE681C27142BA10C4.js"), require("../../../../../4E9A06A0438FECAF28FC6EA7F19A10C4.js"), require("../../../../../438C6F16438FECAF25EA07112F9A10C4.js");
var a = getApp();
Page({
  data: {
    showToastName: !1,
    showToastLocation: !1,
    gateway: "",
    uid: "",
    note: "",
    type: "",
    location: "",
    logSw: !0,
    community: !1,
    communitySw: !1
  },
  onLoad: function(a) {
    var t = JSON.parse(a.devNode);
    this.setData({
      gateway: t.gateway,
      community: t.community,
      note: t.info.name,
      type: t.info.tab,
      uid: t.info.uid,
      logSw: t.info.alarmswitch,
      communitySw: t.info.vpalarmswitch,
      location: t.info.address
    })
  },
  changeName: function(a) {
    this.setData({
      showToastName: !0,
      errflag: !1,
      toastInput: ""
    })
  },
  changeLocation: function(a) {
    this.setData({
      showToastLocation: !0,
      errflag: !1,
      toastInput: ""
    })
  },
  toastCancelName: function(a) {
    this.setData({
      showToastName: !1
    })
  },
  toastCancelLocation: function(a) {
    this.setData({
      showToastLocation: !1
    })
  },
  toastConfirmName: function(t) {
    if (this.data.toastInput) {
      wx.showLoading({
        title: "上传中",
        mask: !0
      });
      var e = this;
      wx.request({
        url: a.globalData.gburl + "wxxcx/chg_agateway_devs/" + a.globalData.gbvendor,
        method: "POST",
        header: {
          "content-type": "application/json",
          Authorization: a.globalData.token
        },
        data: {
          serialnum: this.data.gateway,
          nameid: this.data.uid,
          nickname: e.data.toastInput
        },
        success: function(a) {
          wx.hideLoading(), e.setData({
            showToastName: !1,
            note: e.data.toastInput
          }), wx.showToast({
            title: "修改成功",
            icon: "none",
            duration: 1e3
          })
        },
        fail: function(a) {
          wx.hideLoading(), e.setData({
            errflag: !0,
            errmsg: "上传失败"
          })
        }
      })
    } else this.setData({
      errflag: !0,
      errmsg: "请输入名称"
    })
  },
  toastConfirmLocation: function(t) {
    if (this.data.toastInput) {
      wx.showLoading({
        title: "上传中",
        mask: !0
      });
      var e = this;
      wx.request({
        url: a.globalData.gburl + "wxxcx/chg_agateway_devscfg/" + a.globalData.gbvendor,
        method: "POST",
        header: {
          "content-type": "application/json",
          Authorization: a.globalData.token
        },
        data: {
          serialnum: this.data.gateway,
          nameid: this.data.uid,
          type: "address",
          value: e.data.toastInput
        },
        success: function(a) {
          wx.hideLoading(), e.setData({
            showToastLocation: !1,
            location: e.data.toastInput
          }), wx.showToast({
            title: "修改成功",
            icon: "none",
            duration: 1e3
          })
        },
        fail: function(a) {
          wx.hideLoading(), e.setData({
            errflag: !0,
            errmsg: "上传失败"
          })
        }
      })
    } else this.setData({
      errflag: !0,
      errmsg: "请输入名称"
    })
  },
  toastInput: function(a) {
    this.setData({
      errflag: !1,
      errmsg: "",
      toastInput: a.detail.value
    })
  },
  toastClose: function() {
    this.setData({
      showToastQRCode: !1,
      maskHidden: !0,
      canvasHidden: !0,
      imagePath: "/image/qrmask.png"
    })
  },
  deleteDevice: function() {
    wx.showLoading({
      title: "同步中",
      mask: !0
    }), wx.request({
      url: a.globalData.gburl + "wxxcx/del_agateway_devs/" + a.globalData.gbvendor,
      method: "POST",
      header: {
        "content-type": "application/json",
        Authorization: a.globalData.token
      },
      data: {
        serialnum: this.data.gateway,
        uid: 1 << this.data.uid
      },
      success: function(a) {
        wx.hideLoading(), 0 == a.data.errcode ? wx.showModal({
          title: "提示",
          content: "删除请求已发送成功，需按任意报警器触发网关删除",
          showCancel: !1,
          success: function(a) {
            wx.navigateBack()
          }
        }) : wx.showModal({
          title: "提示",
          content: "删除失败",
          showCancel: !1
        })
      },
      fail: function(a) {
        wx.hideLoading(), wx.showModal({
          title: "提示",
          content: a.errMsg,
          showCancel: !1,
          success: function(a) {
            wx.navigateBack()
          }
        })
      }
    })
  },
  logSwitchChange: function(t) {
    wx.request({
      url: a.globalData.gburl + "wxxcx/chg_agateway_devscfg/" + a.globalData.gbvendor,
      method: "POST",
      header: {
        "content-type": "application/json",
        Authorization: a.globalData.token
      },
      data: {
        serialnum: this.data.gateway,
        nameid: this.data.uid,
        type: "alarmswitch",
        value: t.detail.value
      },
      success: function(a) {
        0 == a.data.errcode || wx.showModal({
          title: "提示",
          content: a.data.errtype,
          showCancel: !1
        })
      },
      fail: function(a) {
        wx.showModal({
          title: "提示",
          content: "通信超时",
          showCancel: !1
        })
      }
    })
  },
  communitySwitchChange: function(t) {
    wx.request({
      url: a.globalData.gburl + "wxxcx/chg_agateway_devscfg/" + a.globalData.gbvendor,
      method: "POST",
      header: {
        "content-type": "application/json",
        Authorization: a.globalData.token
      },
      data: {
        serialnum: this.data.gateway,
        nameid: this.data.uid,
        type: "vpalarmswitch",
        value: t.detail.value
      },
      success: function(a) {
        0 == a.data.errcode || wx.showModal({
          title: "提示",
          content: a.data.errtype,
          showCancel: !1
        })
      },
      fail: function(a) {
        wx.showModal({
          title: "提示",
          content: "通信超时",
          showCancel: !1
        })
      }
    })
  }
});