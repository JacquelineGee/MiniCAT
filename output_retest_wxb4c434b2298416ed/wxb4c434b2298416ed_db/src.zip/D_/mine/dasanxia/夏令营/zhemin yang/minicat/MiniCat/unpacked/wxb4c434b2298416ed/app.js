App({
  onLaunch: function() {
    this.globalData.releaseVersion || (this.globalData.gburl = "http://seaman.w3.luyouxia.net/");
    try {
      var l = wx.getStorageSync("curlockSerialnum");
      this.globalData.curlockSerialnum = l
    } catch (l) {
      wx.setStorageSync("curlockSerialnum", this.globalData.curlockSerialnum)
    }
    wx.cloud.init({
      env: "sc-smartlock-37aefa",
      traceUser: !0
    })
  },
  globalData: {
    iconStyle: "margin-right: 5px;vertical-align: middle;font-size:50rpx;color:#2db3e9",
    iconStyle65rpx: "margin-right: 5px;vertical-align: middle;font-size:65rpx;color:#2db3e9",
    releaseVersion: !0,
    userInfo: null,
    unionid: null,
    sessionkey: null,
    token: null,
    curlockSerialnum: null,
    curlockAdminPassword: null,
    desKey: "k51h#^$A",
    adminPassword: "",
    lastGetDpasswdTime: 0,
    getDpasswdIntvalms: 6e4,
    userData: {
      fplocklistFlag: !1,
      fplocklist: null,
      fplockpasswdlist: null,
      gatewaylistFlag: !1,
      gatewaylist: null
    },
    realName: {
      name: "",
      gender: "",
      idNumber: "",
      mobile: ""
    },
    gburl: "https://gy.samcharm.com/",
    webViewURL: "",
    gbvendor: "weappGY"
  }
});