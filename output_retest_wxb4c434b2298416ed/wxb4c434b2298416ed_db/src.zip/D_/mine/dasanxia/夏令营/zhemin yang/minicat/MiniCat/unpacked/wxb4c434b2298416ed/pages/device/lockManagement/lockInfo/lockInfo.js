var a = require("../../../../80E7AA76438FECAFE681C27142BA10C4.js"),
  e = require("../../../../4E9A06A0438FECAF28FC6EA7F19A10C4.js"),
  t = getApp();
Page({
  data: {
    gateways: ["虚拟网关"],
    gatewayIndex: 0,
    gatewaynameDict: {},
    fplocks: [],
    fplocksDict: [],
    fplockIndex: 0,
    newnickname: "",
    newnickname_warn: "",
    gateway_warn: "",
    errflag: !1,
    errmsg: "",
    showToast: !1,
    canvasHidden: !1,
    maskHidden: !0,
    imagePath: "",
    deviceQRCode: null
  },
  onLoad: function(e) {
    t.globalData.userData.gatewaylistFlag || a.resyncUserData();
    var n = {};
    n["虚拟网关"] = 0;
    for (var s in t.globalData.userData.gatewaylist) "虚拟网关" != t.globalData.userData.gatewaylist[s].name && (this.data.gateways.push(t.globalData.userData.gatewaylist[s].name), n[t.globalData.userData.gatewaylist[s].name] = this.data.gateways.length - 1);
    if (this.setData({
        gateways: this.data.gateways,
        gatewaynameDict: n
      }), t.globalData.userData.fplocklistFlag)
      if (Object.keys(t.globalData.userData.fplocklist).length <= 0) wx.showModal({
        title: "提示",
        content: "没有门锁",
        showCancel: !1,
        success: function(a) {
          wx.navigateBack()
        }
      });
      else {
        var i = [],
          o = [],
          l = t.globalData.userData.fplocklist;
        for (var s in l) o.push({
          name: l[s].name,
          value: s,
          gateway: l[s].gateway
        }), i.push(l[s].name);
        this.setData({
          fplocks: i,
          fplockIndex: 0,
          fplocksDict: o,
          gatewayIndex: this.data.gatewaynameDict[t.globalData.userData.gatewaylist[o[0].gateway].name]
        })
      }
    else a.resyncUserData()
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  bindGatewayChange: function(a) {
    this.setData({
      gatewayIndex: a.detail.value,
      gateway_warn: "",
      errflag: !1
    })
  },
  newnicknameInput: function(a) {
    this.setData({
      newnickname: a.detail.value,
      newnickname_warn: "",
      errflag: !1
    })
  },
  bindFplockChange: function(a) {
    this.setData({
      fplockIndex: a.detail.value,
      gateway_warn: "",
      newnickname_warn: "",
      errflag: !1,
      gatewayIndex: this.data.gatewaynameDict[t.globalData.userData.gatewaylist[this.data.fplocksDict[a.detail.value].gateway].name]
    })
  },
  setLockBtn: function(a) {
    if (this.setData({
        gateway_warn: "",
        newnickname_warn: "",
        errflag: !1
      }), this.data.newnickname) {
      var n = this;
      wx.showLoading({
        title: "同步中",
        mask: !0
      }), wx.request({
        url: t.globalData.gburl + "wxxcx/chg_fplock/" + t.globalData.gbvendor,
        method: "POST",
        header: {
          "content-type": "application/json",
          Authorization: t.globalData.token
        },
        data: {
          nickname: n.data.newnickname,
          serialnum: n.data.fplocksDict[n.data.fplockIndex].value,
          gateway: n.data.gateways[n.data.gatewayIndex]
        },
        success: function(a) {
          if (wx.hideLoading(), 0 == a.data.errcode) {
            var s = n.data.fplocksDict[n.data.fplockIndex].value;
            e.chgFplock(s, {
              name: n.data.newnickname,
              gateway: e.findGatewayFromName(n.data.gateways[n.data.gatewayIndex]),
              locktype: t.globalData.userData.fplocklist[s].locktype,
              note: t.globalData.userData.fplocklist[s].note
            });
            var i = [],
              o = [],
              l = t.globalData.userData.fplocklist;
            for (var c in l) o.push({
              name: l[c].name,
              value: c
            }), i.push(l[c].name);
            n.setData({
              fplocks: i,
              fplocksDict: o
            }), wx.showModal({
              title: "提示",
              content: "修改成功",
              showCancel: !1,
              success: function(a) {
                wx.navigateBack()
              }
            })
          } else "serialnum" == a.data.errtype ? n.setData({
            serialnum_warn: "weui-cell_warn",
            errflag: !0,
            errmsg: "门锁不存在"
          }) : "nickname" == a.data.errtype ? n.setData({
            nickname_warn: "weui-cell_warn",
            errflag: !0,
            errmsg: "门锁名称已存在"
          }) : "gateway" == a.data.errtype ? wx.showModal({
            title: "提示",
            content: "网关不存在",
            showCancel: !1
          }) : wx.showModal({
            title: "提示",
            content: "通信故障",
            showCancel: !1
          })
        },
        fail: function(a) {
          wx.showLoading()
        }
      })
    } else this.setData({
      newnickname_warn: "weui-cell_warn",
      errflag: !0,
      errmsg: "请输入门锁名称"
    })
  },
  showQRCode: function() {
    var e = a.formatCustomTime(new Date(Date.parse(new Date) + 3e5), "yyyy-MM-dd hh:mm"),
      t = this;
    this.setData({
      showToast: !0,
      maskHidden: !1,
      canvasHidden: !1,
      deviceQRCode: t.data.fplocksDict[t.data.fplockIndex].value,
      expireTime: e
    }), wx.showLoading({
      title: "加载中"
    }), a.creatIdentificationCode(this.data.deviceQRCode), setTimeout(function() {
      wx.canvasToTempFilePath({
        canvasId: "qrcanvas",
        success: function(a) {
          var e = a.tempFilePath;
          wx.hideLoading(), t.setData({
            imagePath: e
          })
        },
        fail: function(a) {
          console.log(a), wx.hideLoading(), wx.showToast({
            title: "加载失败",
            icon: "none"
          })
        }
      })
    }, 1e3)
  },
  toastClose: function() {
    this.setData({
      showToast: !1,
      maskHidden: !0,
      canvasHidden: !0
    })
  }
});