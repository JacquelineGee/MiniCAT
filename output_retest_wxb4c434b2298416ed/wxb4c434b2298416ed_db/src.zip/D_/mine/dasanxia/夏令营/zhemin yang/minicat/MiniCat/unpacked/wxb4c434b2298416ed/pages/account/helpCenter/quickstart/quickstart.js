Page({
  data: {
    icon: "iconfont icon-biaoqian2",
    iconStyle: "margin-right: 5px;vertical-align: middle;font-size:40rpx;color:#2db3e9",
    list: [{
      id: 1,
      title: "绑定小程序",
      open: !1,
      content: [{
        icon: "iconfont icon-zhinengsuo",
        text: "进入设置界面，选择【产品信息】→【产品序号】→【二维码】。"
      }, {
        icon: "iconfont icon-xiaochengxu",
        text: "打开设备管理，选择【门锁管理】→【添加门锁】，输入门锁名称，扫描门锁二维码后点击【添加门锁】。"
      }]
    }, {
      id: 2,
      title: "进入设置界面",
      open: !1,
      content: [{
        icon: "iconfont icon-zhinengsuo",
        text: "唤醒系统后，短按后面板的【设置】键，验证管理指纹通过后进入设置界面。"
      }, {
        icon: "iconfont icon-zhinengsuo",
        text: "在待机模式，先按【*】键，然后按【#】键，验证管理员信息通过后进入设置界面。"
      }]
    }, {
      id: 3,
      title: "恢复出厂设置",
      open: !1,
      content: [{
        icon: "iconfont icon-zhinengsuo",
        text: "长按后面板的【设置】键，直到出现恢复出厂设置界面。"
      }, {
        icon: "iconfont icon-zhinengsuo",
        text: "进入设置界面，选择【系统设置】→【恢复出厂设置】。"
      }]
    }, {
      id: 4,
      title: "添加用户",
      open: !1,
      content: [{
        icon: "iconfont icon-yaokongqi",
        text: "进入设置界面后，选择【用户管理】→【添加用户】。"
      }]
    }, {
      id: 5,
      title: "同步设备信息",
      open: !1,
      content: [{
        icon: "iconfont icon-zhinengsuo",
        text: "联网设备，按设备上门铃键会同步更新设备信息。"
      }]
    }, {
      id: 6,
      title: "远程开锁",
      open: !1,
      content: [{
        icon: "iconfont icon-zhinengsuo",
        text: "联网设备，按设备上门铃键会查询是否存在有效的开锁指令，如果没有会向手机推送远程开锁请求通知。"
      }]
    }]
  },
  onLoad: function(n) {},
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  accordionBindTap: function(n) {
    for (var o = n.currentTarget.id, t = this.data.list, i = 0, e = t.length; i < e; ++i) t[i].id == o ? t[i].open = !t[i].open : t[i].open = !1;
    this.setData({
      list: t
    })
  },
  onShareAppMessage: function() {}
});