var t = require("../../../../../../80E7AA76438FECAFE681C27142BA10C4.js"),
  a = getApp();
Page({
  data: {
    serialnum: "",
    uid: "",
    start_date: t.formatCustomTime(new Date, "yyyy-MM-dd"),
    end_date: t.formatCustomTime(new Date, "yyyy-MM-dd"),
    unLockRecords: [],
    unLockLog: []
  },
  onLoad: function(t) {
    var a = t.serialnum,
      e = t.uid;
    this.setData({
      serialnum: a,
      uid: e
    }), this.checkLogBtn()
  },
  syncDispUnlockRecord: function() {
    new Date(this.data.start_date);
    for (var a = new Date(this.data.end_date), e = new Date("1970/1/1 00:00:00"), n = this.data.unLockRecords, s = [], i = 60 * (new Date).getTimezoneOffset(), d = new Date(this.data.start_date); d <= a; d.setDate(d.getDate() + 1)) {
      var o = (d - e) / 1e3 + i,
        r = o + 86400,
        c = {
          date: t.formatCustomTime(d, "yyyy-MM-dd"),
          detail: []
        };
      for (var u in n)
        if (n[u][0] >= o && n[u][0] < r) {
          var h = new Date("1970/1/1 00:00:00");
          h.setSeconds(h.getSeconds() + n[u][0]);
          var l = n[u][1],
            w = n[u][2],
            D = ["烟雾报警", "燃气报警", "门铃开关", "红外探测", "门磁开启", "门磁关闭", "水浸探测", "紧急呼叫"];
          c.detail.push({
            time: t.formatCustomTime(h, "hh:mm:ss"),
            userID: "",
            userName: l,
            unLockMethod: D[w]
          })
        } c.detail.sort(function(t, a) {
        return a.time.localeCompare(t.time)
      }), c.detail.length && s.push(c)
    }
    this.setData({
      unLockLog: s
    })
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  bindStartDateChange: function(t) {
    var a = t.detail.value.split("-"),
      e = this.data.end_date.split("-");
    a[0] + a[1] + a[2] > e[0] + e[1] + e[2] && this.setData({
      end_date: t.detail.value
    }), this.data.dateErr && this.setData({
      end_date_warn: "",
      dateErr: !1
    }), this.setData({
      start_date_warn: "",
      errmsg: ""
    }), this.setData({
      start_date: t.detail.value
    })
  },
  bindEndDateChange: function(t) {
    this.data.dateErr && this.setData({
      start_date_warn: "",
      dateErr: !1
    }), this.setData({
      end_date_warn: "",
      errmsg: ""
    }), this.setData({
      end_date: t.detail.value
    })
  },
  checkLogBtn: function(t) {
    wx.showLoading({
      title: "获取中",
      mask: !0
    });
    var e = this,
      n = new Date(this.data.start_date),
      s = new Date(this.data.end_date),
      i = new Date("1970/1/1 00:00:00"),
      d = 60 * (new Date).getTimezoneOffset(),
      o = (n - i) / 1e3 + d,
      r = (s - i) / 1e3 + d + 86400;
    wx.request({
      url: a.globalData.gburl + "wxxcx/get_agateway_records/" + a.globalData.gbvendor,
      method: "POST",
      header: {
        "content-type": "application/json",
        Authorization: a.globalData.token
      },
      data: {
        serialnum: this.data.serialnum,
        uid: this.data.uid,
        startt: o,
        endt: r
      },
      success: function(t) {
        wx.hideLoading(), 0 == t.data.errcode ? (e.data.unLockRecords = t.data.records, e.syncDispUnlockRecord()) : wx.showModal({
          title: "提示",
          content: "获取失败",
          showCancel: !1,
          success: function(t) {
            wx.navigateBack()
          }
        })
      },
      fail: function(t) {
        wx.hideLoading(), wx.showModal({
          title: "提示",
          content: "获取失败",
          showCancel: !1,
          success: function(t) {
            wx.navigateBack()
          }
        })
      }
    })
  },
  onShareAppMessage: function() {}
});