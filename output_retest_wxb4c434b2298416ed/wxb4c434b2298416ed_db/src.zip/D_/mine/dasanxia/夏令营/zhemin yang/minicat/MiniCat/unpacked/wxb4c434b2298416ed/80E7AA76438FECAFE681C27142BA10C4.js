function t(t, r) {
  return 0 != (t[Math.floor(r / 8)] & 1 << r % 8) ? 1 : 0
}

function r(t, r, e) {
  var n = 0;
  for (n = e - 1; n >= 0; n--) {
    var o = t[n];
    t[n] = 0 != r ? t[n] >> 1 | 128 : t[n] >> 1 & 127, r = 0 != (1 & o) ? 1 : 0
  }
  return t
}

function e(e, n) {
  var o = 0;
  for (o = 0; o < 528; o++) e = r(e, 0 != (g[t(e, 31)][t(e, 26)][t(e, 20)][t(e, 9)][t(e, 1)] ^ t(e, 16) ^ t(e, 0) ^ t(n, o % 64)) ? 1 : 0, 4);
  return e
}

function n() {
  f = f.multiply(1103515245), f = f.add(12345);
  var t = f = f.and(p);
  return t = t.div(65536), t = t.mod(c), t = t.mod(32768), parseInt(t.toString())
}

function o(t, r) {
  var e, n = [165, 56, 121, 66, 127, 131, 188, 213],
    o = [];
  for (e = 0; e < n.length; e++) e < r.length ? o.push((n[e] ^ t[e] ^ parseInt(r.slice(e, e + 1))) % 10) : o.push((n[e] ^ t[e]) % 10);
  var a = 0;
  for (e = 0; e < o.length; e++) a = 10 * a + o[e];
  return a
}

function a(t) {
  var r, e = [165, 56, 121, 66, 127, 131, 188, 213],
    n = [];
  for (r = 0; r < e.length; r++) n.push((e[r] ^ t[r]) % 10);
  var o = 0;
  for (r = 0; r < n.length; r++) o = 10 * o + n[r];
  return o
}
var s = require("D10A7C50438FECAFB76C1457E88A10C4.js"),
  u = require("B5A77236438FECAFD3C11A31267A10C4.js"),
  i = getApp(),
  l = function(t) {
    return (t = t.toString())[1] ? t : "0" + t
  },
  g = [
    [
      [
        [
          [0, 1],
          [1, 1]
        ],
        [
          [0, 1],
          [0, 0]
        ]
      ],
      [
        [
          [0, 0],
          [1, 0]
        ],
        [
          [1, 1],
          [1, 0]
        ]
      ]
    ],
    [
      [
        [
          [0, 0],
          [1, 1]
        ],
        [
          [1, 0],
          [1, 0]
        ]
      ],
      [
        [
          [0, 1],
          [0, 1]
        ],
        [
          [1, 1],
          [0, 0]
        ]
      ]
    ]
  ],
  f = new u(0, 0, !0),
  p = new u(4294967295, 4294967295, !0),
  c = new u(0, 1, !0);
module.exports = {
  formatTime: function(t) {
    var r = t.getFullYear(),
      e = t.getMonth() + 1,
      n = t.getDate(),
      o = t.getHours(),
      a = t.getMinutes(),
      s = t.getSeconds();
    return [r, e, n].map(l).join("/") + " " + [o, a, s].map(l).join(":")
  },
  formatCustomTime: function(t, r) {
    var e = {
      "M+": t.getMonth() + 1,
      "d+": t.getDate(),
      "h+": t.getHours(),
      "m+": t.getMinutes(),
      "s+": t.getSeconds(),
      "q+": Math.floor((t.getMonth() + 3) / 3),
      S: t.getMilliseconds()
    };
    /(y+)/.test(r) && (r = r.replace(RegExp.$1, (t.getFullYear() + "").substr(4 - RegExp.$1.length)));
    for (var n in e) new RegExp("(" + n + ")").test(r) && (r = r.replace(RegExp.$1, 1 == RegExp.$1.length ? e[n] : ("00" + e[n]).substr(("" + e[n]).length)));
    return r
  },
  backIndex: function() {
    wx.switchTab({
      url: "/pages/index/index"
    })
  },
  resyncUserData: function() {
    wx.showModal({
      title: "提示",
      content: "数据未同步，请重新同步",
      showCancel: !1,
      confirmText: "确认",
      success: function(t) {
        t.confirm && wx.reLaunch({
          url: "/pages/index/index"
        })
      }
    })
  },
  needRelogin: function() {
    try {
      var t = wx.getStorageSync("unionid");
      if ("" == t) return !0;
      i.globalData.unionid = t
    } catch (t) {
      return !0
    }
    try {
      var r = wx.getStorageSync("userInfo");
      if (!r) return !0;
      i.globalData.userInfo = r
    } catch (t) {
      return !0
    }
    return !1
  },
  formatTimePickerDate: function(t) {
    return [t.getFullYear(), t.getMonth() + 1, t.getDate()].map(l).join("-")
  },
  formatTimePickerTime: function(t) {
    return [t.getHours(), t.getMinutes()].map(l).join(":")
  },
  gen_dpasswd_timeinv: function(t, r, n, o) {
    var a = new Date(n.getFullYear(), n.getMonth(), n.getDate()),
      s = new Date(2019, 0, 1);
    if (a < s) return [];
    var u, i, l, g, f, p, c, h, v, d, m = Math.floor((a - s) / 864e5),
      w = n.getHours();
    u = parseInt(t.substring(0, 2), 16), i = parseInt(t.substring(2, 4), 16), l = parseInt(t.substring(4, 6), 16), g = parseInt(t.substring(6, 8), 16), f = parseInt(t.substring(8, 10), 16), p = parseInt(t.substring(10, 12), 16);
    for (var M = o >>> 7 & 1, I = v = u ^ l ^ f ^ (c = parseInt(t.substring(12, 14), 16)), b = (d = 252 & (i ^ g ^ p ^ (h = parseInt(t.substring(14, 16), 16)))) | m >>> 10, y = m >>> 2 & 255, x = (3 & m) << 6 | o >>> 1 & 63, D = 17 + (21 ^ (w << 1 | 1 & o)), S = [0, 0, 0, 0, 0, 0, 0, 0], _ = 0; _ < r.length; _++) _ < 8 && (S[_] = parseInt(r.slice(_, _ + 1)));
    var R = e([I, b, y, x], S);
    R[0] ^= D, R[1] ^= D, R[2] ^= D, R[3] ^= D;
    var T = (R[0] << 24 | R[1] << 16 | R[2] << 8 | R[3] << 0) >>> 0;
    0 != M && (T *= 2);
    for (var j = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], _ = 0; _ < 10; _++) j[9 - _] = T % 10, T = Math.floor(T / 10);
    return j[10] = Math.floor(D / 10), j[11] = D % 10, j
  },
  gen_dpasswd_timeinv2: function(t, r, n, o) {
    var a = new Date(n.getFullYear(), n.getMonth(), n.getDate()),
      s = new Date(2019, 0, 1);
    if (a < s) return [];
    for (var u = Math.floor((a - s) / 864e5), i = o >>> 7 & 1, l = 255 & t, g = (t >> 8 & 63) << 2 & 252 | u >>> 10, f = u >>> 2 & 255, p = (3 & u) << 6 | o >>> 1 & 63, c = 17 + (21 ^ (n.getHours() << 1 | 1 & o)), h = [0, 0, 0, 0, 0, 0, 0, 0], v = 0; v < r.length; v++) v < 8 && (h[v] = parseInt(r.slice(v, v + 1)));
    var d = e([l, g, f, p], h);
    d[0] ^= c, d[1] ^= c, d[2] ^= c, d[3] ^= c;
    var m = (d[0] << 24 | d[1] << 16 | d[2] << 8 | d[3] << 0) >>> 0;
    0 != i && (m *= 2);
    for (var w = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], v = 0; v < 10; v++) w[9 - v] = m % 10, m = Math.floor(m / 10);
    return w[10] = Math.floor(c / 10), w[11] = c % 10, w
  },
  gen_dpasswd_count: function(t, r, n, o) {
    var a, s, u, i, l, g, f, p, c, h, v, d, m, w, M;
    a = 7 & o, s = o >>> 3 & 7, u = o >>> 6 & 1, i = 7 & n, l = (65535 & n) >>> 3, g = parseInt(t.substring(0, 2), 16), f = parseInt(t.substring(2, 4), 16), p = parseInt(t.substring(4, 6), 16), c = parseInt(t.substring(6, 8), 16), h = parseInt(t.substring(8, 10), 16), v = parseInt(t.substring(10, 12), 16);
    for (var I = w = 255 & ~(g ^ p ^ h ^ (d = parseInt(t.substring(12, 14), 16))), b = M = f ^ c ^ v ^ (m = parseInt(t.substring(14, 16), 16)), y = l >>> 5 & 255, x = l << 3 & 255 | s, D = 17 + (21 ^ (i << 3 | a)), S = [0, 0, 0, 0, 0, 0, 0, 0], _ = 0; _ < r.length; _++) _ < 8 && (S[_] = parseInt(r.slice(_, _ + 1)));
    var R = e([I, b, y, x], S);
    R[0] ^= D, R[1] ^= D, R[2] ^= D, R[3] ^= D;
    var T = (R[0] << 24 | R[1] << 16 | R[2] << 8 | R[3] << 0) >>> 0;
    0 != u && (T *= 2);
    for (var j = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], _ = 0; _ < 10; _++) j[9 - _] = T % 10, T = Math.floor(T / 10);
    return j[10] = Math.floor(D / 10), j[11] = D % 10, j
  },
  creatIdentificationCode: function(t) {
    var r = {};
    try {
      var e = wx.getSystemInfoSync().windowWidth / 1.5,
        n = e;
      r.w = e, r.h = n
    } catch (t) {
      console.log("获取设备信息失败" + t)
    }
    s.api.draw(t, "qrcanvas", r.w, r.h)
  },
  genRemoteOpenPasswd: function(t, r, e) {
    var a, s = [];
    for (e || (e = Date.now()), a = 0; a < t.length; a += 2) s.push(parseInt(t.slice(a, a + 2), 16));
    var i = o(s, r);
    for (a = 0; a < 8; a++) s[a] ^= i % 10, i = Math.floor(i / 10);
    var l = new Date(1970, 0, 1);
    f = new u(Math.floor((e - l) / 6e4), 0, !0);
    var g = new u(n(), 0, !0);
    for (i = (g = (g = (g = (g = (g = (g = g.multiply(n())).mod(c)).multiply(n())).mod(c)).multiply(n())).mod(c)).toNumber(), a = 0; a < 8; a++) s[a] ^= i % 10, s[a] %= 10, i = Math.floor(i / 10);
    var p = "";
    for (a = 0; a < 8; a++) p += s[a].toString();
    return p
  },
  genRemoteOpenPasswd_NoPasswd: function(t) {
    var r, e = [];
    for (r = 0; r < t.length; r += 2) e.push(parseInt(t.slice(r, r + 2), 16));
    var o = a(e);
    for (r = 0; r < 8; r++) e[r] ^= o % 10, o = Math.floor(o / 10);
    var s = new Date(1970, 0, 1);
    f = new u(Math.floor((Date.now() - s) / 6e4), 0, !0);
    var i = new u(n(), 0, !0);
    for (o = (i = (i = (i = (i = (i = (i = i.multiply(n())).mod(c)).multiply(n())).mod(c)).multiply(n())).mod(c)).toNumber(), r = 0; r < 8; r++) e[r] ^= o % 10, e[r] %= 10, o = Math.floor(o / 10);
    var l = "";
    for (r = 0; r < 8; r++) l += e[r].toString();
    return l
  },
  gen_dpasswd_NoPasswd: function(t, r) {
    var e, o = [];
    for (e = 0; e < t.length; e += 2) o.push(parseInt(t.slice(e, e + 2), 16));
    var s = a(o);
    for (e = 0; e < 8; e++) o[e] ^= s % 10, s = Math.floor(s / 10);
    var i = new Date(1970, 0, 1);
    f = new u(Math.floor((r - i) / 6e4), 0, !0);
    var l = new u(n(), 0, !0);
    for (s = (l = (l = (l = (l = (l = (l = l.multiply(n())).mod(c)).multiply(n())).mod(c)).multiply(n())).mod(c)).toNumber(), e = 0; e < 8; e++) o[e] ^= s % 10, o[e] %= 10, s = Math.floor(s / 10);
    var g = "";
    for (e = 0; e < 8; e++) g += o[e].toString();
    return g
  }
};