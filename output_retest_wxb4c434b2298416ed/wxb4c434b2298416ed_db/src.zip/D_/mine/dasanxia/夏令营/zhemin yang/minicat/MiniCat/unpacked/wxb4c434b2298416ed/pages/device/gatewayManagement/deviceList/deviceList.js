require("../../../../80E7AA76438FECAFE681C27142BA10C4.js"), require("../../../../4E9A06A0438FECAF28FC6EA7F19A10C4.js");
var a = getApp();
Page({
  data: {
    gateway: "",
    iconStyle: "margin-right: 5px;vertical-align: middle;font-size:65rpx;color:#2db3e9",
    tabs: ["全部设备", "烟雾报警器", "燃气报警器", "其它"],
    activeIndex: 0,
    sliderOffset: 0,
    sliderLeft: 0,
    device: [],
    community: !1
  },
  onLoad: function(a) {
    var t = !1;
    "true" == a.community && (t = !0), this.setData({
      gateway: a.serialnum,
      community: t
    })
  },
  onReady: function() {},
  onShow: function() {
    var t = this;
    wx.request({
      url: a.globalData.gburl + "wxxcx/get_agateway_devs/" + a.globalData.gbvendor,
      method: "POST",
      header: {
        "content-type": "application/json",
        Authorization: a.globalData.token
      },
      data: {
        serialnum: this.data.gateway
      },
      success: function(a) {
        if (0 == a.data.errcode) {
          for (var i = [], e = a.data.data, s = 0; s < e.length; s++) 0 == e[s].type ? i.push({
            type: "smoke",
            tab: "烟雾报警器",
            uid: e[s].uid,
            name: e[s].name,
            alarmswitch: e[s].alarmswitch,
            vpalarmswitch: e[s].vpalarmswitch,
            address: e[s].address,
            icon: "iconfont icon-SmokeDetectors"
          }) : 1 == e[s].type ? i.push({
            type: "gas",
            tab: "燃气报警器",
            uid: e[s].uid,
            name: e[s].name,
            alarmswitch: e[s].alarmswitch,
            vpalarmswitch: e[s].vpalarmswitch,
            address: e[s].address,
            icon: "iconfont icon-keranqijiance"
          }) : 2 == e[s].type ? i.push({
            type: "switch",
            tab: "门铃开关",
            uid: e[s].uid,
            name: e[s].name,
            alarmswitch: e[s].alarmswitch,
            vpalarmswitch: e[s].vpalarmswitch,
            address: e[s].address,
            icon: "iconfont icon-menling"
          }) : 3 == e[s].type ? i.push({
            type: "switch",
            tab: "红外探测器",
            uid: e[s].uid,
            name: e[s].name,
            alarmswitch: e[s].alarmswitch,
            vpalarmswitch: e[s].vpalarmswitch,
            address: e[s].address,
            icon: "iconfont icon-rentiganying"
          }) : 4 == e[s].type || 5 == e[s].type ? i.push({
            type: "switch",
            tab: "门磁探测器",
            uid: e[s].uid,
            name: e[s].name,
            alarmswitch: e[s].alarmswitch,
            vpalarmswitch: e[s].vpalarmswitch,
            address: e[s].address,
            icon: "iconfont icon-menci"
          }) : 6 == e[s].type ? i.push({
            type: "switch",
            tab: "水浸探测器",
            uid: e[s].uid,
            name: e[s].name,
            alarmswitch: e[s].alarmswitch,
            vpalarmswitch: e[s].vpalarmswitch,
            address: e[s].address,
            icon: "iconfont icon-jinshui"
          }) : 7 == e[s].type ? i.push({
            type: "switch",
            tab: "紧急呼叫",
            uid: e[s].uid,
            name: e[s].name,
            alarmswitch: e[s].alarmswitch,
            vpalarmswitch: e[s].vpalarmswitch,
            address: e[s].address,
            icon: "iconfont icon-SOS"
          }) : i.push({
            type: "switch",
            tab: "无线开关",
            uid: e[s].uid,
            name: e[s].name,
            alarmswitch: e[s].alarmswitch,
            vpalarmswitch: e[s].vpalarmswitch,
            address: e[s].address,
            icon: "iconfont icon-switch"
          });
          t.setData({
            device: i
          })
        }
      },
      fail: function(a) {
        wx.showModal({
          title: "提示",
          content: "通信超时",
          showCancel: !1
        })
      }
    })
  },
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  tabClick: function(a) {
    this.setData({
      sliderOffset: a.currentTarget.offsetLeft,
      activeIndex: a.currentTarget.id
    })
  },
  deviceClick: function(a) {
    for (var t = {}, i = 0; i < this.data.device.length; i++)
      if (this.data.device[i].uid == a.currentTarget.dataset.id) {
        t.gateway = this.data.gateway, t.community = this.data.community, t.info = this.data.device[i];
        break
      } wx.navigateTo({
      url: "deviceInfo/deviceInfo?devNode=" + JSON.stringify(t)
    })
  }
});