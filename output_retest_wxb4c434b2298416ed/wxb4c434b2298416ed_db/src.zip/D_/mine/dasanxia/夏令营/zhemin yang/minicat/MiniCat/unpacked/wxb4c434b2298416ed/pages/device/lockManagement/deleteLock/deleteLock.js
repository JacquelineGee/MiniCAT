var e = require("../../../../80E7AA76438FECAFE681C27142BA10C4.js"),
  t = require("../../../../4E9A06A0438FECAF28FC6EA7F19A10C4.js"),
  a = getApp();
Page({
  data: {
    checkboxItems: []
  },
  onLoad: function(e) {},
  onReady: function() {},
  onShow: function() {
    if (a.globalData.userData.fplocklistFlag)
      if (Object.keys(a.globalData.userData.fplocklist).length <= 0) wx.showModal({
        title: "提示",
        content: "没有门锁",
        showCancel: !1,
        success: function(e) {
          wx.navigateBack()
        }
      });
      else {
        var t = [],
          o = a.globalData.userData.fplocklist;
        for (var n in o) t.push({
          name: o[n].name,
          value: n,
          checked: !1
        });
        this.setData({
          checkboxItems: t
        })
      }
    else e.resyncUserData()
  },
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  checkboxChange: function(e) {
    for (var t = this.data.checkboxItems, a = e.detail.value, o = 0, n = t.length; o < n; ++o) {
      t[o].checked = !1;
      for (var c = 0, s = a.length; c < s; ++c)
        if (t[o].value == a[c]) {
          t[o].checked = !0;
          break
        }
    }
    this.setData({
      checkboxItems: t
    })
  },
  delLockBtn: function(e) {
    for (var o = [], n = 0; n < this.data.checkboxItems.length; n++) this.data.checkboxItems[n].checked && o.push(this.data.checkboxItems[n].value);
    if (o.length <= 0) wx.showModal({
      title: "提示",
      content: "请选择要删除的门锁",
      showCancel: !1
    });
    else {
      wx.showLoading({
        title: "同步中",
        mask: !0
      }), wx.request({
        url: a.globalData.gburl + "wxxcx/del_fplock/" + a.globalData.gbvendor,
        method: "POST",
        header: {
          "content-type": "application/json",
          Authorization: a.globalData.token
        },
        data: {
          dfp_checkbox: o
        },
        success: function(e) {
          wx.hideLoading(), 0 == e.data.errcode ? (t.delFplock(o), wx.showModal({
            title: "提示",
            content: "删除成功",
            showCancel: !1,
            success: function(e) {
              wx.navigateBack()
            }
          })) : wx.showModal({
            title: "提示",
            content: "删除失败",
            showCancel: !1
          })
        },
        fail: function(e) {
          wx.hideLoading(), wx.showModal({
            title: "提示",
            content: e.errMsg,
            showCancel: !1,
            success: function(e) {
              wx.navigateBack()
            }
          })
        }
      })
    }
  }
});