var e = require("../../../438C6F16438FECAF25EA07112F9A10C4.js"),
  a = (require("../../../80E7AA76438FECAFE681C27142BA10C4.js"), require("../../../978419B7438FECAFF1E271B0924A10C4.js"), getApp());
Page({
  data: {
    userCode: "",
    userCode_warn: "",
    serialnum: "",
    uid: null,
    recipient: "",
    errflag: !1,
    errmsg: ""
  },
  onLoad: function(e) {
    this.setData({
      serialnum: e.serialnum,
      uid: e.uid
    })
  },
  scanQRCode: function(r) {
    var t = this;
    this.setData({
      userCode_warn: "",
      errmsg: ""
    }), wx.scanCode({
      success: function(r) {
        try {
          for (var s = e.enc.Utf8.parse(a.globalData.desKey), i = e.DES.decrypt(r.result, s, {
              mode: e.mode.ECB,
              padding: e.pad.Pkcs7
            }).toString(), n = "", d = 0; d < i.length; d += 2) n += String.fromCharCode(parseInt(i.slice(d, d + 2), 16));
          var o = JSON.parse(n),
            u = new Date(1970, 0, 1),
            l = Math.floor((Date.now() - u) / 6e4);
          if (l >= parseInt(o.beginTimeMin) && l <= parseInt(o.expireTimeMin)) {
            var c = o.data.substr(0, 6) + "********" + o.data.substr(-6, 6);
            t.setData({
              recipient: o.data,
              userCode: c,
              errflag: !1
            })
          } else t.setData({
            errflag: !0,
            errmsg: "二维码失效"
          })
        } catch (e) {
          t.setData({
            errflag: !0,
            errmsg: "数据非法"
          })
        }
      }
    })
  },
  bindUserBtn: function() {
    var e = this;
    "" != this.data.userCode ? wx.request({
      url: a.globalData.gburl + "wxxcx/GYBindFpuser/" + a.globalData.gbvendor,
      method: "POST",
      header: {
        "content-type": "application/json",
        Authorization: a.globalData.token
      },
      data: {
        fpSerialnum: this.data.serialnum,
        fpUid: parseInt(this.data.uid),
        recipient: this.data.recipient
      },
      success: function(a) {
        0 == a.data.errcode ? wx.showModal({
          title: "提示",
          content: "关联成功",
          showCancel: !1,
          success: function(e) {
            wx.navigateBack()
          }
        }) : -1 == a.data.errcode ? e.setData({
          errflag: !0,
          errmsg: a.data.errmsg
        }) : -2 == a.data.errcode ? e.setData({
          errflag: !0,
          errmsg: a.data.errtype
        }) : e.setData({
          errflag: !0,
          errmsg: "通信失败"
        })
      }
    }) : this.setData({
      userCode_warn: "weui-cell_warn",
      errmsg: "请输入用户识别码"
    })
  }
});