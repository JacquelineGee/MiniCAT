Page({
  data: {
    icon: "iconfont icon-biaoqian2",
    iconStyle: "margin-right: 5px;vertical-align: middle;font-size:40rpx;color:#2db3e9"
  },
  onLoad: function(n) {
    wx.showLoading({
      title: "加载中"
    })
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  srcOnLoadSuccess: function() {
    wx.hideLoading()
  },
  srcOnLodeError: function() {
    wx.hideLoading(), wx.showToast({
      title: "加载失败",
      icon: "none"
    })
  },
  onShareAppMessage: function() {}
});