var t = getApp();
Page({
  data: {
    id: "",
    lockConfig: []
  },
  onLoad: function(a) {
    var e = a.serialnum;
    this.setData({
      id: e
    });
    var l = this;
    wx.request({
      url: t.globalData.gburl + "wxxcx/get_fpsyscfg/" + t.globalData.gbvendor,
      method: "POST",
      header: {
        "content-type": "application/json",
        Authorization: t.globalData.token
      },
      data: {
        serialnum: e
      },
      success: function(t) {
        0 == t.data.errcode && t.data.syscfg.length >= 24 && l.analysisSyscfg(l, t.data.syscfg)
      }
    })
  },
  analysisSyscfg: function(t, a) {
    for (var e = ["指纹", "指纹或密码", "指纹加密码", "标准模式"], l = ["简体中文", "ENGLISH"], i = ["开启", "关闭"], s = ["前置", "后置"], n = ["正向", "反向"], o = [], u = 0; u < a.length; u += 2) o.push(parseInt(a.slice(u, u + 2), 16));
    var c = e[o[0]],
      r = (o[1], o[2] + "秒"),
      v = l[o[3]],
      g = i[1 & o[8]],
      d = i[o[8] >> 1 & 1],
      f = i[o[8] >> 2 & 1],
      h = i[o[8] >> 3 & 1],
      p = i[o[8] >> 4 & 1],
      y = (o[8], n[o[8] >> 6 & 1]),
      b = i[o[8] >> 7 & 1],
      D = i[1 & o[9]],
      x = i[o[9] >> 1 & 1],
      S = [{
        title: "开锁方式",
        value: c
      }, {
        title: "系统语音",
        value: g
      }, {
        title: "访客密码",
        value: d
      }, {
        title: "防拆报警",
        value: f
      }, {
        title: "锁芯报警",
        value: h
      }, {
        title: "门铃开关",
        value: p
      }];
    0 != (1 & o[11]) && (S = S.concat([{
      title: "电机转向",
      value: y
    }, {
      title: "自动关锁",
      value: b
    }])), S = S.concat([{
      title: "开锁时间",
      value: r
    }, {
      title: "远程开锁",
      value: D
    }, {
      title: "联网模块",
      value: x
    }, {
      title: "系统语言",
      value: v
    }]), t.setData({
      lockConfig: S
    })
  }
});