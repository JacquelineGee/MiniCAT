function i(i, t, h) {
  this.low = 0 | i, this.high = 0 | t, this.unsigned = !!h
}

function t(i) {
  return !0 === (i && i.__isLong__)
}

function h(i, t) {
  var h, n, e;
  return t ? (i >>>= 0, (e = 0 <= i && i < 256) && (n = g[i]) ? n : (h = s(i, (0 | i) < 0 ? -1 : 0, !0), e && (g[i] = h), h)) : (i |= 0, (e = -128 <= i && i < 128) && (n = o[i]) ? n : (h = s(i, i < 0 ? -1 : 0, !1), e && (o[i] = h), h))
}

function n(i, t) {
  if (isNaN(i)) return t ? v : c;
  if (t) {
    if (i < 0) return v;
    if (i >= a) return b
  } else {
    if (i <= -d) return q;
    if (i + 1 >= d) return y
  }
  return i < 0 ? n(-i, t).neg() : s(i % l | 0, i / l | 0, t)
}

function s(t, h, n) {
  return new i(t, h, n)
}

function e(i, t, h) {
  if (0 === i.length) throw Error("empty string");
  if ("NaN" === i || "Infinity" === i || "+Infinity" === i || "-Infinity" === i) return c;
  if ("number" == typeof t ? (h = t, t = !1) : t = !!t, (h = h || 10) < 2 || 36 < h) throw RangeError("radix");
  var s;
  if ((s = i.indexOf("-")) > 0) throw Error("interior hyphen");
  if (0 === s) return e(i.substring(1), t, h).neg();
  for (var r = n(f(h, 8)), u = c, o = 0; o < i.length; o += 8) {
    var g = Math.min(8, i.length - o),
      l = parseInt(i.substring(o, o + g), h);
    if (g < 8) {
      var a = n(f(h, g));
      u = u.mul(a).add(n(l))
    } else u = (u = u.mul(r)).add(n(l))
  }
  return u.unsigned = t, u
}

function r(i, t) {
  return "number" == typeof i ? n(i, t) : "string" == typeof i ? e(i, t) : s(i.low, i.high, "boolean" == typeof t ? t : i.unsigned)
}
module.exports = i;
var u = null;
try {
  u = new WebAssembly.Instance(new WebAssembly.Module(new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0, 1, 13, 2, 96, 0, 1, 127, 96, 4, 127, 127, 127, 127, 1, 127, 3, 7, 6, 0, 1, 1, 1, 1, 1, 6, 6, 1, 127, 1, 65, 0, 11, 7, 50, 6, 3, 109, 117, 108, 0, 1, 5, 100, 105, 118, 95, 115, 0, 2, 5, 100, 105, 118, 95, 117, 0, 3, 5, 114, 101, 109, 95, 115, 0, 4, 5, 114, 101, 109, 95, 117, 0, 5, 8, 103, 101, 116, 95, 104, 105, 103, 104, 0, 0, 10, 191, 1, 6, 4, 0, 35, 0, 11, 36, 1, 1, 126, 32, 0, 173, 32, 1, 173, 66, 32, 134, 132, 32, 2, 173, 32, 3, 173, 66, 32, 134, 132, 126, 34, 4, 66, 32, 135, 167, 36, 0, 32, 4, 167, 11, 36, 1, 1, 126, 32, 0, 173, 32, 1, 173, 66, 32, 134, 132, 32, 2, 173, 32, 3, 173, 66, 32, 134, 132, 127, 34, 4, 66, 32, 135, 167, 36, 0, 32, 4, 167, 11, 36, 1, 1, 126, 32, 0, 173, 32, 1, 173, 66, 32, 134, 132, 32, 2, 173, 32, 3, 173, 66, 32, 134, 132, 128, 34, 4, 66, 32, 135, 167, 36, 0, 32, 4, 167, 11, 36, 1, 1, 126, 32, 0, 173, 32, 1, 173, 66, 32, 134, 132, 32, 2, 173, 32, 3, 173, 66, 32, 134, 132, 129, 34, 4, 66, 32, 135, 167, 36, 0, 32, 4, 167, 11, 36, 1, 1, 126, 32, 0, 173, 32, 1, 173, 66, 32, 134, 132, 32, 2, 173, 32, 3, 173, 66, 32, 134, 132, 130, 34, 4, 66, 32, 135, 167, 36, 0, 32, 4, 167, 11])), {}).exports
} catch (i) {}
i.prototype.__isLong__, Object.defineProperty(i.prototype, "__isLong__", {
  value: !0
}), i.isLong = t;
var o = {},
  g = {};
i.fromInt = h, i.fromNumber = n, i.fromBits = s;
var f = Math.pow;
i.fromString = e, i.fromValue = r;
var l = 4294967296,
  a = l * l,
  d = a / 2,
  w = h(1 << 24),
  c = h(0);
i.ZERO = c;
var v = h(0, !0);
i.UZERO = v;
var m = h(1);
i.ONE = m;
var N = h(1, !0);
i.UONE = N;
var E = h(-1);
i.NEG_ONE = E;
var y = s(-1, 2147483647, !1);
i.MAX_VALUE = y;
var b = s(-1, -1, !0);
i.MAX_UNSIGNED_VALUE = b;
var q = s(0, -2147483648, !1);
i.MIN_VALUE = q;
var p = i.prototype;
p.toInt = function() {
  return this.unsigned ? this.low >>> 0 : this.low
}, p.toNumber = function() {
  return this.unsigned ? (this.high >>> 0) * l + (this.low >>> 0) : this.high * l + (this.low >>> 0)
}, p.toString = function(i) {
  if ((i = i || 10) < 2 || 36 < i) throw RangeError("radix");
  if (this.isZero()) return "0";
  if (this.isNegative()) {
    if (this.eq(q)) {
      var t = n(i),
        h = this.div(t),
        s = h.mul(t).sub(this);
      return h.toString(i) + s.toInt().toString(i)
    }
    return "-" + this.neg().toString(i)
  }
  for (var e = n(f(i, 6), this.unsigned), r = this, u = "";;) {
    var o = r.div(e),
      g = (r.sub(o.mul(e)).toInt() >>> 0).toString(i);
    if ((r = o).isZero()) return g + u;
    for (; g.length < 6;) g = "0" + g;
    u = "" + g + u
  }
}, p.getHighBits = function() {
  return this.high
}, p.getHighBitsUnsigned = function() {
  return this.high >>> 0
}, p.getLowBits = function() {
  return this.low
}, p.getLowBitsUnsigned = function() {
  return this.low >>> 0
}, p.getNumBitsAbs = function() {
  if (this.isNegative()) return this.eq(q) ? 64 : this.neg().getNumBitsAbs();
  for (var i = 0 != this.high ? this.high : this.low, t = 31; t > 0 && 0 == (i & 1 << t); t--);
  return 0 != this.high ? t + 33 : t + 1
}, p.isZero = function() {
  return 0 === this.high && 0 === this.low
}, p.eqz = p.isZero, p.isNegative = function() {
  return !this.unsigned && this.high < 0
}, p.isPositive = function() {
  return this.unsigned || this.high >= 0
}, p.isOdd = function() {
  return 1 == (1 & this.low)
}, p.isEven = function() {
  return 0 == (1 & this.low)
}, p.equals = function(i) {
  return t(i) || (i = r(i)), (this.unsigned === i.unsigned || this.high >>> 31 != 1 || i.high >>> 31 != 1) && (this.high === i.high && this.low === i.low)
}, p.eq = p.equals, p.notEquals = function(i) {
  return !this.eq(i)
}, p.neq = p.notEquals, p.ne = p.notEquals, p.lessThan = function(i) {
  return this.comp(i) < 0
}, p.lt = p.lessThan, p.lessThanOrEqual = function(i) {
  return this.comp(i) <= 0
}, p.lte = p.lessThanOrEqual, p.le = p.lessThanOrEqual, p.greaterThan = function(i) {
  return this.comp(i) > 0
}, p.gt = p.greaterThan, p.greaterThanOrEqual = function(i) {
  return this.comp(i) >= 0
}, p.gte = p.greaterThanOrEqual, p.ge = p.greaterThanOrEqual, p.compare = function(i) {
  if (t(i) || (i = r(i)), this.eq(i)) return 0;
  var h = this.isNegative(),
    n = i.isNegative();
  return h && !n ? -1 : !h && n ? 1 : this.unsigned ? i.high >>> 0 > this.high >>> 0 || i.high === this.high && i.low >>> 0 > this.low >>> 0 ? -1 : 1 : this.sub(i).isNegative() ? -1 : 1
}, p.comp = p.compare, p.negate = function() {
  return !this.unsigned && this.eq(q) ? q : this.not().add(m)
}, p.neg = p.negate, p.add = function(i) {
  t(i) || (i = r(i));
  var h = this.high >>> 16,
    n = 65535 & this.high,
    e = this.low >>> 16,
    u = 65535 & this.low,
    o = i.high >>> 16,
    g = 65535 & i.high,
    f = i.low >>> 16,
    l = 0,
    a = 0,
    d = 0,
    w = 0;
  return w += u + (65535 & i.low), d += w >>> 16, w &= 65535, d += e + f, a += d >>> 16, d &= 65535, a += n + g, l += a >>> 16, a &= 65535, l += h + o, l &= 65535, s(d << 16 | w, l << 16 | a, this.unsigned)
}, p.subtract = function(i) {
  return t(i) || (i = r(i)), this.add(i.neg())
}, p.sub = p.subtract, p.multiply = function(i) {
  if (this.isZero()) return c;
  if (t(i) || (i = r(i)), u) return s(u.mul(this.low, this.high, i.low, i.high), u.get_high(), this.unsigned);
  if (i.isZero()) return c;
  if (this.eq(q)) return i.isOdd() ? q : c;
  if (i.eq(q)) return this.isOdd() ? q : c;
  if (this.isNegative()) return i.isNegative() ? this.neg().mul(i.neg()) : this.neg().mul(i).neg();
  if (i.isNegative()) return this.mul(i.neg()).neg();
  if (this.lt(w) && i.lt(w)) return n(this.toNumber() * i.toNumber(), this.unsigned);
  var h = this.high >>> 16,
    e = 65535 & this.high,
    o = this.low >>> 16,
    g = 65535 & this.low,
    f = i.high >>> 16,
    l = 65535 & i.high,
    a = i.low >>> 16,
    d = 65535 & i.low,
    v = 0,
    m = 0,
    N = 0,
    E = 0;
  return E += g * d, N += E >>> 16, E &= 65535, N += o * d, m += N >>> 16, N &= 65535, N += g * a, m += N >>> 16, N &= 65535, m += e * d, v += m >>> 16, m &= 65535, m += o * a, v += m >>> 16, m &= 65535, m += g * l, v += m >>> 16, m &= 65535, v += h * d + e * a + o * l + g * f, v &= 65535, s(N << 16 | E, v << 16 | m, this.unsigned)
}, p.mul = p.multiply, p.divide = function(i) {
  if (t(i) || (i = r(i)), i.isZero()) throw Error("division by zero");
  if (u) return this.unsigned || -2147483648 !== this.high || -1 !== i.low || -1 !== i.high ? s((this.unsigned ? u.div_u : u.div_s)(this.low, this.high, i.low, i.high), u.get_high(), this.unsigned) : this;
  if (this.isZero()) return this.unsigned ? v : c;
  var h, e, o;
  if (this.unsigned) {
    if (i.unsigned || (i = i.toUnsigned()), i.gt(this)) return v;
    if (i.gt(this.shru(1))) return N;
    o = v
  } else {
    if (this.eq(q)) return i.eq(m) || i.eq(E) ? q : i.eq(q) ? m : (h = this.shr(1).div(i).shl(1)).eq(c) ? i.isNegative() ? m : E : (e = this.sub(i.mul(h)), o = h.add(e.div(i)));
    if (i.eq(q)) return this.unsigned ? v : c;
    if (this.isNegative()) return i.isNegative() ? this.neg().div(i.neg()) : this.neg().div(i).neg();
    if (i.isNegative()) return this.div(i.neg()).neg();
    o = c
  }
  for (e = this; e.gte(i);) {
    h = Math.max(1, Math.floor(e.toNumber() / i.toNumber()));
    for (var g = Math.ceil(Math.log(h) / Math.LN2), l = g <= 48 ? 1 : f(2, g - 48), a = n(h), d = a.mul(i); d.isNegative() || d.gt(e);) d = (a = n(h -= l, this.unsigned)).mul(i);
    a.isZero() && (a = m), o = o.add(a), e = e.sub(d)
  }
  return o
}, p.div = p.divide, p.modulo = function(i) {
  return t(i) || (i = r(i)), u ? s((this.unsigned ? u.rem_u : u.rem_s)(this.low, this.high, i.low, i.high), u.get_high(), this.unsigned) : this.sub(this.div(i).mul(i))
}, p.mod = p.modulo, p.rem = p.modulo, p.not = function() {
  return s(~this.low, ~this.high, this.unsigned)
}, p.and = function(i) {
  return t(i) || (i = r(i)), s(this.low & i.low, this.high & i.high, this.unsigned)
}, p.or = function(i) {
  return t(i) || (i = r(i)), s(this.low | i.low, this.high | i.high, this.unsigned)
}, p.xor = function(i) {
  return t(i) || (i = r(i)), s(this.low ^ i.low, this.high ^ i.high, this.unsigned)
}, p.shiftLeft = function(i) {
  return t(i) && (i = i.toInt()), 0 == (i &= 63) ? this : i < 32 ? s(this.low << i, this.high << i | this.low >>> 32 - i, this.unsigned) : s(0, this.low << i - 32, this.unsigned)
}, p.shl = p.shiftLeft, p.shiftRight = function(i) {
  return t(i) && (i = i.toInt()), 0 == (i &= 63) ? this : i < 32 ? s(this.low >>> i | this.high << 32 - i, this.high >> i, this.unsigned) : s(this.high >> i - 32, this.high >= 0 ? 0 : -1, this.unsigned)
}, p.shr = p.shiftRight, p.shiftRightUnsigned = function(i) {
  return t(i) && (i = i.toInt()), 0 == (i &= 63) ? this : i < 32 ? s(this.low >>> i | this.high << 32 - i, this.high >>> i, this.unsigned) : 32 === i ? s(this.high, 0, this.unsigned) : s(this.high >>> i - 32, 0, this.unsigned)
}, p.shru = p.shiftRightUnsigned, p.shr_u = p.shiftRightUnsigned, p.rotateLeft = function(i) {
  var h;
  return t(i) && (i = i.toInt()), 0 == (i &= 63) ? this : 32 === i ? s(this.high, this.low, this.unsigned) : i < 32 ? (h = 32 - i, s(this.low << i | this.high >>> h, this.high << i | this.low >>> h, this.unsigned)) : (i -= 32, h = 32 - i, s(this.high << i | this.low >>> h, this.low << i | this.high >>> h, this.unsigned))
}, p.rotl = p.rotateLeft, p.rotateRight = function(i) {
  var h;
  return t(i) && (i = i.toInt()), 0 == (i &= 63) ? this : 32 === i ? s(this.high, this.low, this.unsigned) : i < 32 ? (h = 32 - i, s(this.high << h | this.low >>> i, this.low << h | this.high >>> i, this.unsigned)) : (i -= 32, h = 32 - i, s(this.low << h | this.high >>> i, this.high << h | this.low >>> i, this.unsigned))
}, p.rotr = p.rotateRight, p.toSigned = function() {
  return this.unsigned ? s(this.low, this.high, !1) : this
}, p.toUnsigned = function() {
  return this.unsigned ? this : s(this.low, this.high, !0)
}, p.toBytes = function(i) {
  return i ? this.toBytesLE() : this.toBytesBE()
}, p.toBytesLE = function() {
  var i = this.high,
    t = this.low;
  return [255 & t, t >>> 8 & 255, t >>> 16 & 255, t >>> 24, 255 & i, i >>> 8 & 255, i >>> 16 & 255, i >>> 24]
}, p.toBytesBE = function() {
  var i = this.high,
    t = this.low;
  return [i >>> 24, i >>> 16 & 255, i >>> 8 & 255, 255 & i, t >>> 24, t >>> 16 & 255, t >>> 8 & 255, 255 & t]
}, i.fromBytes = function(t, h, n) {
  return n ? i.fromBytesLE(t, h) : i.fromBytesBE(t, h)
}, i.fromBytesLE = function(t, h) {
  return new i(t[0] | t[1] << 8 | t[2] << 16 | t[3] << 24, t[4] | t[5] << 8 | t[6] << 16 | t[7] << 24, h)
}, i.fromBytesBE = function(t, h) {
  return new i(t[4] << 24 | t[5] << 16 | t[6] << 8 | t[7], t[0] << 24 | t[1] << 16 | t[2] << 8 | t[3], h)
};