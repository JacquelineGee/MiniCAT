function a() {
  wx.showLoading({
    title: "数据更新中",
    mask: !0
  }), wx.request({
    url: i.globalData.gburl + "wxxcx/get_gateway/" + i.globalData.gbvendor,
    method: "POST",
    header: {
      "content-type": "application/json",
      Authorization: i.globalData.token
    },
    data: {},
    success: function(a) {
      if (0 != a.data.errcode) return wx.hideLoading(), void e.resyncUserData();
      if (a.data.gws.length <= 0) o.addGateway(null, null);
      else
        for (var t = 0; t < a.data.gws.length; t++) o.addGateway(a.data.gws[t][1], {
          name: a.data.gws[t][0]
        });
      i.globalData.userData.gatewaylistFlag = !0, wx.hideLoading()
    },
    fail: function(a) {
      wx.hideLoading(), e.resyncUserData()
    }
  })
}

function t(a) {
  var t = i.globalData.userData.fplocklist;
  if (t) {
    var e = [];
    for (var o in t) 4 == t[o].locktype && (t[o].note ? e.push({
      id: o,
      note: t[o].note,
      icon: "iconfont icon-fangjian",
      expireDate: t[o].other.expireDate
    }) : e.push({
      id: o,
      note: t[o].other.room_no,
      icon: "iconfont icon-fangjian",
      expireDate: t[o].other.expireDate
    }));
    a.setData({
      rooms: e,
      roomTotal: e.length
    })
  }
}
var e = require("../../80E7AA76438FECAFE681C27142BA10C4.js"),
  o = require("../../4E9A06A0438FECAF28FC6EA7F19A10C4.js"),
  i = getApp();
Page({
  data: {
    iconStyle: "margin-right: 5px;vertical-align: middle;font-size:50rpx;color:#2db3e9",
    percent: 0,
    timer: "",
    deviceType: null,
    showVisitorKey: !1,
    showToastPasswordD: !1,
    showToastPasswordR: !1,
    authVisitorKey: !1,
    authLogCheck: !1,
    authRemoteUnlock: !1,
    lastDKeyReqTime: 0,
    lastRKeyReqTime: 0,
    lastcheckAuthorify: 0,
    cur_lockname: "设备名称",
    cur_adminPassword: "",
    deviceUrl: "../device/lockList/lockList",
    dynamickey: [0, 0, 0, 0, 0, 0, 0, 0],
    tabs: ["全部", "未到期", "已到期"],
    rooms: [],
    roomTotal: 0
  },
  onLoad: function() {
    if (i.globalData.unionid)
      if (o.readFplock()) i.globalData.userData.fplocklistFlag = !0, o.readGateway() ? i.globalData.userData.gatewaylistFlag = !0 : a();
      else {
        wx.showLoading({
          title: "数据同步中",
          mask: !0
        });
        var n = this;
        wx.request({
          url: i.globalData.gburl + "wxxcx/get_devices/" + i.globalData.gbvendor,
          method: "POST",
          header: {
            "content-type": "application/json",
            Authorization: i.globalData.token
          },
          data: {},
          success: function(l) {
            if (0 != l.data.errcode) return wx.hideLoading(), void e.resyncUserData();
            if (l.data.fps.length <= 0) o.addFplock(null, null);
            else
              for (var s = 0; s < l.data.fps.length; s++) o.addFplock(l.data.fps[s][1], {
                name: l.data.fps[s][0],
                gateway: l.data.fps[s][2],
                locktype: l.data.fps[s][3],
                note: l.data.fps[s][4],
                visitorKeys: l.data.fps[s][5],
                logCheck: l.data.fps[s][6],
                remoteUnlock: l.data.fps[s][7],
                other: l.data.fps[s][8]
              });
            i.globalData.userData.fplocklistFlag = !0, wx.hideLoading(), o.readGateway() ? i.globalData.userData.gatewaylistFlag = !0 : a(), t(n)
          },
          fail: function(a) {
            wx.hideLoading(), e.resyncUserData()
          }
        })
      }
  },
  onShow: function() {
    t(this)
  },
  bindSyncInfo: function() {
    this.onLoad()
  },
  deviceClick: function(a) {
    var t = a.currentTarget.dataset.id,
      e = {
        fpserialnum: t,
        note: i.globalData.userData.fplocklist[t].note
      };
    for (var o in i.globalData.userData.fplocklist[t].other) e[o] = i.globalData.userData.fplocklist[t].other[o];
    wx.navigateTo({
      url: "/pages/index/tenant/tenant?devNode=" + JSON.stringify(e)
    })
  }
});