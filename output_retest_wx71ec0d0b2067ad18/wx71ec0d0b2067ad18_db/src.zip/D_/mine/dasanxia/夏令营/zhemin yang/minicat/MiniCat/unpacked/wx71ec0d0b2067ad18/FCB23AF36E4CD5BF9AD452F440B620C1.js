var e = require("./@babel/runtime/helpers/typeof.js"),
  t = getApp(),
  n = require("882CEAE56E4CD5BFEE4A82E20C8620C1.js").Base64;

function o(e, n, o, a) {
  var i = e.data.result;
  if ("" === t.stringFormat(a) && (a = !1), a) {
    if (i) {
      var r = t.aesDecrypt(i),
        c = JSON.parse(r);
      e.data.result = c
    }
  } else if (i) {
    c = r = i;
    e.data.result = c
  }
  return console.log(n + "接口反参:" + JSON.stringify(e.data)), e.data.code && e.data.code, "function" == typeof o && o(e.data)
}

function a(e, n) {
  var o = JSON.stringify(e);
  console.log(n + "请求入参:" + o);
  var a = t.aesEncrypt(o);
  return console.log(n + "加密请求入参:" + a), a
}
module.exports = {
  requestPost: function(i, r, c, l, s, u, f) {
    var d = !(arguments.length > 7 && void 0 !== arguments[7]) || arguments[7];
    return function(r) {
      if ("object" == e(i)) var p = i.url;
      else p = i;
      var g = 1;
      if (s) var w = a(r, l);
      else w = r;
      if (d) {
        var h = "加载中...";
        f && (h = f), wx.showLoading({
          title: h,
          mask: !0
        })
      }
      if (s) r = {
        data: w
      };
      else {
        r = w;
        console.log(JSON.stringify(r))
      }
      var y = p.split("/"),
        v = y[y.length - 1].trim();
      console.log("请求接口"), console.log(v);
      var m = wx.getStorageSync("openId"),
        x = {};
      if ("getWeiXinOpenId" === v) {
        var S = (Date.parse(new Date) / 1e3).toString(),
          D = n.encode(S),
          E = "H5Page" + S,
          M = n.encode(E),
          O = v + "-/-" + n.encode(m) + "-" + S;
        x = {
          time: D,
          canonicalType: M,
          signature: n.encode(O)
        }
      } else {
        S = Date.parse(new Date) / 1e3, D = t.aesEncrypt(S), E = "H5Page" + S, M = t.aesEncrypt(E), O = v + "-/-" + t.aesEncrypt(m) + "-" + S;
        x = {
          time: D,
          canonicalType: M,
          signature: t.aesEncrypt(O)
        }
      }
      wx.request({
        url: p,
        method: "POST",
        header: x,
        data: r,
        success: function(e) {
          return o(e, l, c, s)
        },
        fail: function(e) {
          if (u) return "function" == typeof u && u(e);
          console.log(e);
          var t = e.errMsg;
          null != t ? (console.log(t), t = "request:fail timeout" === t ? "抱歉！请求超时，请稍后重试" : "网络请求失败，请检查您的网络设置", wx.showModal({
            title: "提示",
            content: t,
            showCancel: !1,
            success: function(e) {
              e.confirm || e.cancel
            }
          })) : wx.showModal({
            title: "提示",
            content: "网络请求失败，请检查您的网络设置",
            showCancel: !1,
            success: function(e) {
              e.confirm || e.cancel
            }
          })
        },
        complete: function() {
          g -= 1, d && g <= 0 && wx.hideLoading()
        }
      })
    }(r)
  },
  uploadFile: function(e, n, a, i) {
    var r = this,
      c = arguments.length > 4 && void 0 !== arguments[4] && arguments[4],
      l = arguments.length > 5 ? arguments[5] : void 0,
      s = arguments.length > 6 ? arguments[6] : void 0,
      u = arguments.length > 7 ? arguments[7] : void 0,
      f = arguments.length > 8 ? arguments[8] : void 0;
    if (c) {
      var d = "加载中...";
      s && (d = s), wx.showLoading({
        title: d,
        mask: !0
      })
    }
    l || (l = {});
    var p = Date.parse(new Date);
    p /= 1e3, console.log("请求时间戳：{}", p);
    var g = "WXProgram" + p,
      w = wx.getStorageSync("openId"),
      h = t.aesEncrypt(p),
      y = t.aesEncrypt(g),
      v = {};
    v = "" != w && null != w && null != w ? {
      "content-type": "application/x-www-form-urlencoded;charset=utf-8",
      canonicalType: y,
      time: h,
      requestUser: t.aesEncrypt(w)
    } : {
      "content-type": "application/x-www-form-urlencoded;charset=utf-8",
      canonicalType: y,
      time: h
    }, wx.uploadFile({
      url: e,
      filePath: n,
      name: "file",
      formData: l,
      header: v,
      success: function(e) {
        return e.data = JSON.parse(e.data), o(e, i, a)
      },
      fail: function(e) {
        if (u) return "function" == typeof u && u(e);
        var t = e.errMsg;
        null != t ? (console.log(t), t = "uploadFile:fail timeout" === t ? "抱歉！请求超时，请稍后重试" : "网络请求失败，请检查您的网络设置", r.showModal(t)) : r.showModal("网络请求失败，请检查您的网络设置")
      },
      complete: function() {
        if (c && wx.hideLoading(), f) return "function" == typeof f && f()
      }
    })
  },
  showModal: function(e, t, n, o) {
    var a = !1;
    n && (a = n), wx.showModal({
      title: "提示",
      content: e,
      showCancel: a,
      success: function(e) {
        if (e.confirm) {
          if (t) return "function" == typeof t && t()
        } else if (e.cancel && o) return "function" == typeof o && o()
      }
    })
  },
  showToast: function(e, t) {
    wx.showToast({
      title: e,
      icon: "none",
      duration: 3e3,
      mask: !0
    })
  }
};