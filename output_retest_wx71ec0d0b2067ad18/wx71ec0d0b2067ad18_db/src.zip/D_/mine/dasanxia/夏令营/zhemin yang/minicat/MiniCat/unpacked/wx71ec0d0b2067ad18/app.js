var e = require("7FC231D46E4CD5BF19A459D39B9620C1.js");
App({
  onLaunch: function() {
    this.autoUpdate()
  },
  onShow: function(e) {
    this.globalData.scene = e.scene
  },
  onHide: function() {
    this.data.webShowed = !1
  },
  data: {
    webShowed: !1
  },
  globalData: {
    customerURL: "https://repairowner.chinalife-p.com.cn/repairCustomer/h5/",
    getWeiXinOpenId: "controller/user/user/getWeiXinOpenId",
    baseUrl: "index?"
  },
  stringFormat: function(e) {
    return null == e ? "" : e
  },
  autoUpdate: function() {
    var e = this;
    if (wx.canIUse("getUpdateManager")) {
      var t = wx.getUpdateManager();
      t.onCheckForUpdate((function(n) {
        console.log(n), n.hasUpdate && wx.showModal({
          title: "更新提示",
          content: "检测到新版本，是否下载新版本并重启小程序?",
          success: function(n) {
            n.confirm ? e.downAppUpdate(t) : n.cancel
          }
        })
      }))
    }
  },
  downAppUpdate: function(e) {
    wx.showLoading(), e.onUpdateReady((function() {
      wx.hideLoading(), e.applyUpdate()
    })), e.onUpdateFailed((function() {
      wx.showModal({
        title: "已经有新版本了哟~",
        content: "新版本已经上线啦~，请您删除当前小程序，重新搜索打开哟~"
      })
    }))
  },
  watch: function(e, t) {
    var n = this;
    Object.keys(t).forEach((function(a) {
      n.observer(e.data, a, e.data[a], (function(n) {
        t[a].call(e, n)
      }))
    }))
  },
  observer: function(e, t, n, a) {
    Object.defineProperty(e, t, {
      configurable: !0,
      enumerable: !0,
      get: function() {
        return n
      },
      set: function(e) {
        e !== n && (a && a(e), n = e)
      }
    })
  },
  aesEncrypt: function(t) {
    var n = e.enc.Utf8.parse(t),
      a = wx.getStorageSync("aesKey"),
      o = e.enc.Utf8.parse(a);
    return e.AES.encrypt(n, o, {
      mode: e.mode.ECB,
      padding: e.pad.Pkcs7
    }).ciphertext.toString().toUpperCase()
  },
  aesDecrypt: function(t) {
    var n = e.enc.Hex.parse(t),
      a = e.enc.Base64.stringify(n),
      o = wx.getStorageSync("aesKey"),
      r = e.enc.Utf8.parse(o);
    return e.AES.decrypt(a, r, {
      mode: e.mode.ECB,
      padding: e.pad.Pkcs7
    }).toString(e.enc.Utf8).toString()
  }
});