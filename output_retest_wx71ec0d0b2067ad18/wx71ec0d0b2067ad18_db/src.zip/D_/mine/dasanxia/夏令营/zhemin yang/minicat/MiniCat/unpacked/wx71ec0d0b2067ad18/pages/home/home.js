var t = getApp(),
  e = require("../../FCB23AF36E4CD5BF9AD452F440B620C1.js");
Page({
  data: {
    isLoginFlag: !0,
    userName: "",
    userImage: "",
    webURL: "",
    params: "",
    dataString: "",
    latitude: "",
    longitude: "",
    showCancleFlag: !1,
    userInfoFlag: !0,
    popupContent: "",
    popupDesc: "您好，安心赔申请获取您的昵称和头像",
    accidentNo: "",
    tz: "",
    selectAccidentNo: "",
    isCancelFlag: ""
  },
  onShow: function() {
    getApp().data.webShowed = !0
  },
  onLoad: function(e) {
    var a = this;
    "" !== t.stringFormat(e.dataJson) && this.setData({
      dataString: e.dataJson
    }), e.accidentNo && this.setData({
      accidentNo: e.accidentNo
    }), e.isCancelFlag && this.setData({
      isCancelFlag: !0
    }), wx.getStorageSync("isCancelFlag1") && (this.setData({
      isCancelFlag: !0
    }), wx.removeStorageSync("isCancelFlag1"));
    var o = "",
      n = this.data.dataString;
    "" !== t.stringFormat(n) && (o = "&dataJson=" + n), this.setData({
      params: o
    }), wx.getStorage({
      key: "userInfo",
      success: function(e) {
        var o = e.data;
        if ("" !== t.stringFormat(o)) {
          var n = JSON.parse(o);
          if ("" !== t.stringFormat(n)) {
            var i = n.nickName,
              s = n.avatarUrl;
            "" !== t.stringFormat(i) && "" !== t.stringFormat(s) && (a.setData({
              userName: i,
              userImage: s
            }), a.getUserInfo())
          }
        } else a.setData({
          isLoginFlag: !1
        })
      },
      fail: function(t) {
        console.log(t), a.setData({
          isLoginFlag: !1
        })
      }
    })
  },
  xiaoxi: function() {
    var t = "jKQioIn-x3c8JDGOuFD2PGU8LlEfRJ15YQBkhTbyNuI";
    wx.getSetting({
      withSubscriptions: !0,
      success: function(e) {
        if (!e.subscriptionsSetting.mainSwitch) return console.log("订阅消息未开启"), !1;
        if (console.log(e.subscriptionsSetting.itemSettings), null != e.subscriptionsSetting.itemSettings) {
          var a = e.subscriptionsSetting.itemSettings[t];
          if ("accept" === a) return console.log("接受了消息推送"), !0;
          if ("reject" === a) return console.log("拒绝消息推送"), !1;
          if ("ban" === a) return console.log("已被后台封禁"), !1
        } else wx.showModal({
          title: "提示",
          content: "请授权开通服务通知",
          showCancel: !0,
          success: function(e) {
            e.confirm && wx.requestSubscribeMessage({
              tmplIds: [t],
              success: function(t) {
                return !0
              },
              fail: function(t) {
                return console.log("订阅消息 失败 ", t), !1
              }
            })
          }
        })
      },
      fail: function(t) {
        return console.log(t), !1
      }
    })
  },
  getUserProfile: function(t) {
    var e = this;
    this.hidePopup(), wx.getUserProfile({
      desc: "用于展示用户信息",
      success: function(t) {
        var a = t.userInfo,
          o = JSON.stringify(a);
        wx.setStorage({
          key: "userInfo",
          data: o
        });
        var n = a.nickName,
          i = a.avatarUrl;
        e.setData({
          userName: n,
          userImage: i
        }), e.getUserInfo()
      },
      fail: function(t) {
        e.setData({
          userName: "",
          userImage: ""
        }), e.getUserInfo()
      }
    })
  },
  initWebURL: function() {
    this.setData({
      isLoginFlag: !0
    });
    var e = wx.getStorageSync("openID"),
      a = "";
    "" !== t.stringFormat(this.data.latitude) && (a = "&latitude=" + this.data.latitude);
    var o = "";
    "" !== t.stringFormat(this.data.longitude) && (o = "&longitude=" + this.data.longitude);
    var n = "";
    "" !== t.stringFormat(this.data.accidentNo) && (n = "&accidentNo=" + this.data.accidentNo);
    var i = "";
    "" !== t.stringFormat(this.data.isCancelFlag) && (i = "&isCancelFlag=" + this.data.isCancelFlag);
    var s = wx.getStorageSync("selectAccidentNo");
    "" !== t.stringFormat(s) && (s = "&selectAccidentNo=" + s);
    var c = "";
    t.globalData.scene && (c = "&scene=" + t.globalData.scene);
    var r = "userName=" + this.data.userName + "&userImage=" + this.data.userImage + "&openId=" + e + this.data.params + a + o + n + c + s + i,
      l = t.globalData.customerURL + t.globalData.baseUrl + encodeURIComponent(r);
    this.setData({
      webURL: l
    })
  },
  getUserInfo: function() {
    this.wxLogin("")
  },
  wxLogin: function(e) {
    var a = this;
    wx.checkSession({
      success: function() {
        var o = wx.getStorageSync("openID");
        "" !== t.stringFormat(o) ? (a.localLocation(), a.xiaoxi()) : a.getWXlogin(e)
      },
      fail: function() {
        a.getWXlogin(e)
      }
    })
  },
  localLocation: function() {
    var t = this;
    wx.getLocation({
      type: "gcj02",
      success: function(e) {
        var a = e.latitude,
          o = e.longitude;
        t.setData({
          latitude: a,
          longitude: o
        }), t.initWebURL()
      },
      fail: function(e) {
        wx.showModal({
          cancelColor: "cancelColor",
          title: "没有授权无法获取位置信息",
          content: "是否前往设置页面手动开启",
          success: function(t) {
            t.confirm ? wx.openSetting({}) : wx.showToast({
              icon: "none",
              title: "您取消了定位授权"
            })
          },
          fail: function(t) {
            console.log(t)
          }
        }), t.initWebURL()
      }
    })
  },
  getWXlogin: function(t) {
    var e = this;
    wx.login({
      success: function(t) {
        t.code && e.getOpenID(t.code)
      },
      fail: function(t) {
        var e = t.errMsg;
        e = "login:fail timeout" === e ? "抱歉！请求超时，请稍后重试" : "网络请求失败，请检查您的网络设置", wx.showModal({
          title: "提示",
          content: e,
          showCancel: !1,
          success: function(t) {}
        })
      }
    })
  },
  getOpenID: function(a) {
    var o = this,
      n = t.globalData.customerURL + t.globalData.getWeiXinOpenId,
      i = {
        js_code: a
      };
    e.requestPost(n, i, (function(a) {
      var n = "",
        i = "";
      if ("" !== t.stringFormat(a))
        if (n = a.code, i = a.message, "200" == n) {
          var s = a.result;
          if ("" !== t.stringFormat(s)) {
            var c = s.openid;
            wx.setStorageSync("openID", c), o.localLocation(), o.xiaoxi()
          }
        } else e.showModal(i);
      else e.showModal("抱歉！服务器暂时没有响应，请稍后重试")
    }), "获取微信唯一识别码", !1, (function(t) {
      console.log("获取失败", t), e.showModal("抱歉！服务器暂时没有响应，是否重试", (function() {
        o.getWXlogin("")
      }), !0)
    }))
  },
  onReady: function() {
    this.popup = this.selectComponent("#popup"), this.data.isLoginFlag || this.showPopup()
  },
  error: function() {
    this.popup.hidePopup()
  },
  success: function() {
    this.popup.showPopup()
  },
  showPopup: function() {
    this.popup.showPopup()
  },
  hidePopup: function() {
    this.popup.hidePopup()
  }
});