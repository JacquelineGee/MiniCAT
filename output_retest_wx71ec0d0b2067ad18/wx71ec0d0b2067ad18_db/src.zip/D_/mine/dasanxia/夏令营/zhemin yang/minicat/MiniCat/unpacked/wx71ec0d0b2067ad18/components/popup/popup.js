Component({
  externalClasses: ["my-class"],
  options: {
    multipleSlots: !0,
    styleIsolation: "isolated"
  },
  properties: {
    title: {
      type: String,
      value: "提示"
    },
    content: {
      type: String,
      value: "内容描述"
    },
    desc: {
      type: String,
      value: ""
    },
    cancelTitle: {
      type: String,
      value: "取消"
    },
    confirmTitle: {
      type: String,
      value: "确定"
    },
    showCancleFlag: {
      type: Boolean,
      value: !1
    },
    userInfoFlag: {
      type: Boolean,
      value: !1
    }
  },
  data: {
    isShowPopup: !0
  },
  lifetimes: {
    attached: function() {}
  },
  methods: {
    hidePopup: function() {
      this.setData({
        isShowPopup: !this.data.isShowPopup
      })
    },
    showPopup: function() {
      this.setData({
        isShowPopup: !this.data.isShowPopup
      })
    },
    errorCallback: function() {
      this.triggerEvent("error")
    },
    successCallback: function() {
      this.triggerEvent("success")
    },
    getUserProfile: function() {
      this.triggerEvent("bindtap")
    }
  }
});