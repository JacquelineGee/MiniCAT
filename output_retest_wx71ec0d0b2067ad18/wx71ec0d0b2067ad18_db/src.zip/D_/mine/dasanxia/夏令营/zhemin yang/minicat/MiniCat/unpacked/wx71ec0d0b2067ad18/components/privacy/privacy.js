Component({
  properties: {
    rejectType: ""
  },
  data: {
    privacyContractName: "",
    showPrivacy: !1
  },
  pageLifetimes: {
    show: function() {
      var t = this;
      wx.onNeedPrivacyAuthorization((function(i) {
        t.resolvePrivacyAuthorization = i
      })), wx.getPrivacySetting({
        success: function(i) {
          "getPrivacySetting:ok" == i.errMsg && t.setData({
            privacyContractName: i.privacyContractName,
            showPrivacy: i.needAuthorization
          }), i.needAuthorization || t.triggerEvent("result", {
            ok: !0
          })
        }
      })
    }
  },
  methods: {
    openPrivacyContract: function() {
      wx.openPrivacyContract({
        fail: function() {
          wx.showToast({
            title: "遇到错误",
            icon: "error"
          })
        }
      })
    },
    exitMiniProgram: function() {
      this.triggerEvent("result", {
        ok: !1
      }), wx.showToast({
        title: "需同意才可继续使用当前小程序",
        duration: 3e3,
        icon: "none"
      })
    },
    handleAgreePrivacyAuthorization: function() {
      this.setData({
        showPrivacy: !1
      }), this.triggerEvent("result", {
        ok: !0
      })
    }
  }
});