var a = getApp();
Page({
  data: {
    dataString: "",
    webURL: "",
    accidentNo: "",
    tz: "",
    airServiceFlag: 0,
    selectAccidentNo: "",
    isCancelFlag: ""
  },
  onLoad: function(t) {
    wx.getStorageSync("isCancelFlag") && (this.setData({
      isCancelFlag: wx.getStorageSync("isCancelFlag")
    }), wx.removeStorageSync("isCancelFlag")), t.isCancelFlag && wx.setStorageSync("isCancelFlag1", !0), t.accidentNo && this.setData({
      accidentNo: t.accidentNo
    }), t.tz && this.setData({
      tz: t.tz
    }), t.selectAccidentNo && wx.setStorageSync("selectAccidentNo", t.selectAccidentNo), t.airServiceFlag && this.setData({
      airServiceFlag: t.airServiceFlag
    }), "" !== a.stringFormat(t.dataJson) ? this.setData({
      dataString: t.dataJson
    }) : this.setData({
      dataString: this.data.dataString
    }), "" !== a.stringFormat(t["?dataJson"]) ? this.setData({
      dataString: t["?dataJson"]
    }) : this.setData({
      dataString: this.data.dataString
    })
  },
  onReady: function() {},
  onShow: function() {
    var t = this.data.dataString,
      e = "",
      i = "/pages/home/home" + e;
    "" !== a.stringFormat(t) ? (e = "?dataJson=" + t, this.data.accidentNo ? (i = "/pages/home/home" + e + "&accidentNo=" + this.data.accidentNo, this.data.isCancelFlag && (i = "/pages/home/home" + e + "&accidentNo=" + this.data.accidentNo + "&isCancelFlag=" + this.data.isCancelFlag)) : (i = "/pages/home/home" + e, this.data.isCancelFlag && (i = "/pages/home/home" + e + "&isCancelFlag=" + this.data.isCancelFlag))) : this.data.accidentNo ? (i = "/pages/home/home?accidentNo=" + this.data.accidentNo, this.data.isCancelFlag && (i = "/pages/home/home?accidentNo=" + this.data.accidentNo + "&isCancelFlag=" + this.data.isCancelFlag)) : (i = "/pages/home/home" + e, this.data.isCancelFlag && (i = "/pages/home/home?isCancelFlag=" + this.data.isCancelFlag)), a.data.webShowed && (i = "/pages/home/home" + e, this.data.isCancelFlag && (i = e ? "/pages/home/home" + e + "&isCancelFlag=" + this.data.isCancelFlag : "/pages/home/home?isCancelFlag=" + this.data.isCancelFlag)), "tz" == this.data.tz ? (this.setData({
      tz: ""
    }), wx.showModal({
      title: "温馨提示",
      content: "您好，将跳转“一路行”小程序进行资料补传",
      showCancel: !0,
      cancelText: "取消",
      confirmText: "确定",
      success: function(t) {
        t.cancel ? (wx.navigateTo({
          url: i
        }), a.data.webShowed = !1) : wx.navigateToMiniProgram({
          appId: "wxcba875e7a5383fd9",
          path: "pages/gsVideo/index/index",
          envVersion: "release",
          success: function(t) {
            t.cancel && (wx.navigateTo({
              url: i
            }), a.data.webShowed = !1), console.log("打开成功")
          },
          fail: function() {
            wx.navigateTo({
              url: i
            }), a.data.webShowed = !1
          }
        })
      }
    })) : 1 == this.data.airServiceFlag && a.data.webShowed ? this.closeF() : getCurrentPages().length >= 2 ? wx.navigateBack({
      delta: 2
    }) : wx.navigateTo({
      url: i
    })
  },
  closeF: function() {
    wx.showModal({
      title: "温馨提示",
      showCancel: !1,
      content: "即将关闭“国寿修车无忧”小程序",
      success: function(a) {
        a.confirm && wx.exitMiniProgram({
          success: function() {
            console.log("退出成功！")
          },
          fail: function() {
            console.log("6666")
          }
        })
      }
    })
  },
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {}
});