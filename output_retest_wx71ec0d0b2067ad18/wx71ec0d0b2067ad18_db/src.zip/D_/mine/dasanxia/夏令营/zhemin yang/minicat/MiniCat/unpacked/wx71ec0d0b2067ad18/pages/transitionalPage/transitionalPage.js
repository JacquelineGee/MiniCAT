Page({
  data: {},
  onLoad: function(n) {
    wx.hideTabBar(), wx.setStorageSync("isCancelFlag", !0), wx.redirectTo({
      url: "/pages/index/index"
    })
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {}
});