Page({
  data: {
    userInfoFlag: !1,
    popupContent: "微信小程序自定义组件？",
    popupDesc: ""
  },
  onLoad: function(o) {},
  onReady: function() {
    this.popup = this.selectComponent("#popup")
  },
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {},
  error: function() {
    this.popup.hidePopup()
  },
  success: function() {
    this.popup.showPopup(), console.log("处理逻辑。。。。。。")
  },
  showPopup: function() {
    this.popup.showPopup()
  }
});