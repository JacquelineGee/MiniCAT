Page({
  data: {
    src: ""
  },
  onLoad: function(n) {
    var o = "",
      i = n.agreementUrl.replace("%", "?").replace("!", "=");
    o = n.mobile ? i + "&isHistory=" + n.isHistory + "&mobile=" + n.mobile + "&isCancelAction=" + n.isCancelAction + "&url=" + n.url1 : i + "&isHistory=" + n.isHistory, this.setData({
      src: o
    })
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {}
});