var e = require("../../../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.hitPreloadDuration = exports.fetchMenuData = void 0;
var r = e(require("../../../b/regenerator")),
  t = require("../../../b/helpers/objectSpread2"),
  a = require("../../../b/helpers/asyncToGenerator"),
  n = require("../../../types/newMenu/MenuData"),
  o = require("../../../lib/wx/util"),
  u = e(require("../../../miniprogram_npm/seamless-immutable/index.js")),
  i = e(require("../../../lib/mix/log")),
  s = require("../../../types/IResponse"),
  p = require("./LocalDataSource"),
  d = require("../../../lib/wx/app-info"),
  l = require("../../../constants/decorate"),
  c = require("./RemoteDataSource"),
  m = e(require("../../../api/rmsStorage")),
  f = require("../../../constants/bizConstants"),
  b = require("../../commonHelper"),
  v = require("../../takeaway/takeawayHelper"),
  I = require("../../../lib/env"),
  h = (e(require("../shop/shopService")), e(require("../I18n/I18nService")), i.default),
  w = function(e, r) {
    var t = Date.now();
    return e && e > 0 && h.addPerformance(r, t - e, (0, o.getWxPathName)()), t
  };
exports.hitPreloadDuration = w;
var g = function() {
    var e = a(r.default.mark((function e(a) {
      var o, d, l, b, I, h, g, S, T, x, C, P, q, D, M, R, y;
      return r.default.wrap((function(e) {
        for (;;) switch (e.prev = e.next) {
          case 0:
            if (l = (d = a).mtShopId, b = d.tableNum, I = d.reserveMode, h = d.userGeoPoint, !(S = (0, p.fmpCacheInterceptor)(a)) || !(0, n.isCacheMenuData)(S)) {
              e.next = 9;
              break
            }
            return T = S.preloadTime, w(T, 16), e.next = 7, (0, c.updateFmpInfo)({
              mtShopId: l,
              tableNum: b,
              userGeoPoint: h,
              reserveMode: I
            }, S);
          case 7:
            return g = e.sent, e.abrupt("return", g);
          case 9:
            return x = m.default.getHasTakeCouponAtMenu(l), C = m.default.getActivityTypeList(), !x && C && (a = t(t({}, a), {}, {
              actTypes: C,
              timestamp: Date.now()
            })), P = {}, e.next = 14, (0, v.getTakeawayParams)();
          case 14:
            return P = e.sent, a = t(t({}, a), P), e.next = 18, (0, c.getMenuFmp)(a);
          case 18:
            if (g = e.sent) {
              e.next = 21;
              break
            }
            return e.abrupt("return", void i.default.addError("菜单页白屏", null == (q = g) ? void 0 : q.errorType));
          case 21:
            if (g !== s.ResponseState.REDIRECT && !(0, s.isErrorTips)(g)) {
              e.next = 23;
              break
            }
            return e.abrupt("return", g);
          case 23:
            return D = null == (o = g) ? void 0 : o.openTableInfo, Number(I) !== f.DISH_SOURCE.RESERVE || D && D.peopleCount && !(D.peopleCount <= 0) || (R = (M = a).peopleCount, y = M.selectedTime, D = {
              peopleCount: R,
              selectedTime: y
            }, g = u.default.setIn(g, ["openTableInfo"], D)), e.abrupt("return", g);
          case 26:
          case "end":
            return e.stop()
        }
      }), e)
    })));
    return function(r) {
      return e.apply(this, arguments)
    }
  }(),
  S = function() {
    var e = a(r.default.mark((function e(t) {
      var a, n, o, u, i, s, p, d, l, m, f, v, I, h, w, g;
      return r.default.wrap((function(e) {
        for (;;) switch (e.prev = e.next) {
          case 0:
            return a = t.shopId, n = t.tableNum, o = t.reserveMode, u = void 0 === o ? 0 : o, i = t.bizType, s = t.userGeoPoint, p = t.tenantId, d = t.restaurantViewId, l = t.brandId, m = t.shopCache, f = (0, b.getPreOrderInfo)(a, u), v = f.peopleCount, I = f.selectedTime, h = {
              mtShopId: a,
              tableNum: n,
              reserveMode: +u,
              peopleCount: v,
              selectedTime: I,
              pageNum: 1,
              timestamp: Date.now(),
              bizType: i,
              userGeoPoint: s,
              tenantId: p,
              brandId: l,
              restaurantViewId: d,
              shopCache: m
            }, e.next = 16, (0, c.getPageSpu)(h);
          case 16:
            if (w = e.sent) {
              e.next = 19;
              break
            }
            return e.abrupt("return");
          case 19:
            return g = w.spuDetail, e.abrupt("return", g);
          case 21:
          case "end":
            return e.stop()
        }
      }), e)
    })));
    return function(r) {
      return e.apply(this, arguments)
    }
  }(),
  T = function() {
    var e = a(r.default.mark((function e(a) {
      var n, o, u, i, p, c, f, v, h, w, T, x, C, P, q, D, M, R, y, E, N, k;
      return r.default.wrap((function(e) {
        for (;;) switch (e.prev = e.next) {
          case 0:
            return n = a.shopId, o = a.tableNum, u = a.reserveMode, i = void 0 === u ? 0 : u, p = a.orderBizTag, c = a.spuId, f = a.multiShop, v = void 0 === f ? "" : f, h = a.userGeoPoint, w = a.restaurantViewId, T = a.brandId, x = a.tenantId, C = a.orderViewId, P = void 0 === C ? "" : C, q = a.orderScene, D = void 0 === q ? 1 : q, M = (0, b.getValidateAllowOdAfterClose)(), R = !1, y = "", E = m.default.getShopCache(), R = (0, d.getNewApp)().diancanGlobalData.getPreview(l.CONTAINER_NAME.OD_MENU), y = (0, d.getNewApp)().diancanGlobalData.getPreviewParam(), I.isMpWebview && a.previewParam && (y = decodeURIComponent(a.previewParam), R = !0), N = S(t({
              shopCache: E
            }, a)), e.next = 7, g(t(t({
              mtShopId: n,
              tableNum: o,
              reserveMode: +i
            }, (0, b.getPreOrderInfo)(n, i)), {}, {
              fromMenu: !0,
              orderBizTag: p,
              explodeSpuId: c,
              timestamp: Date.now(),
              preview: !!R,
              previewParam: y,
              multiShop: v + "" || m.default.getMultiShop(),
              userGeoPoint: h,
              restaurantViewId: w,
              brandId: T,
              tenantId: x,
              orderViewId: P,
              shopCache: E,
              orderScene: D,
              validateAllowOdAfterClose: M,
              buffetLimitMealTipsFlag: m.default.getBuffetLimitMealTipsFlag(n)
            }));
          case 7:
            return k = e.sent, e.abrupt("return", k === s.ResponseState.REDIRECT ? s.ResponseState.REDIRECT : t({
              spuPromise: N
            }, k));
          case 9:
          case "end":
            return e.stop()
        }
      }), e)
    })));
    return function(r) {
      return e.apply(this, arguments)
    }
  }();
exports.fetchMenuData = T;