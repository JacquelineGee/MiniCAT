var t = require("../../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.addPanelSkuDish = function(t, e, u, r, a, s) {
  var l = arguments.length > 6 && void 0 !== arguments[6] && arguments[6],
    d = arguments.length > 7 ? arguments[7] : void 0,
    c = r.count,
    f = r.orderedCount,
    g = t.incBoughtCount,
    p = t.spuName,
    m = t.dishType,
    I = -1 === t.minBoughtCount ? 0 : t.minBoughtCount,
    h = -1 === r.stockCount ? 1 / 0 : r.stockCount,
    C = -1 === r.limitCount ? 1 / 0 : r.limitCount,
    S = u.refactorCartDishMap && u.refactorCartDishMap[t.spuId.toString()],
    v = 0;
  if (S && S.map((function(t) {
      return t.skuId === r.skuId && t.count && (v += t.count), null
    })), a) {
    var T = null == S ? void 0 : S.find((function(t) {
      return t.itemNo === s
    }));
    T && T.count && (v -= T.count)
  }
  if (e) {
    if (l) return t.showMultipleInput ? {
      calcValue: c,
      calcStatus: o.CALCULATOR_STATUS.ADD,
      showCalculatorPanel: !0,
      multiVisible: !1,
      packageVisible: !1
    } : {};
    var P = c + g;
    if (P + v > h) return i.default.show({
      content: "当前库存不足",
      duration: 1e3
    }), {};
    if (!(0, k.verifyLimitCount)({
        delta: P,
        limitCount: C,
        usedCount: v + f
      })) return i.default.show({
      content: (0, k.jointExceedLimitCountMessage)({
        dishName: p,
        limitCount: C,
        orderedCount: f
      }),
      duration: k.LIMIT_COUNT_MESSAGE_DURATION
    }), {};
    var N = n.default.set(r, "count", P);
    return d && d.discount && (N = n.default.set(r, "discount", d.discount), N = n.default.set(r, "campaignId", d.campaignId)), m === o.DISH_TYPE.NORMAL ? {
      cartSkuDish: N
    } : {
      cartPackageSku: N
    }
  }
  var A = c - g,
    E = (null == r ? void 0 : r.mustCount) || -1;
  if (A <= 0 || A < E) return i.default.show({
    content: "不能小于".concat(c, "份"),
    duration: 1e3
  }), {};
  if (A + v >= I) {
    var D = n.default.set(r, "count", A);
    return t.dishType === o.DISH_TYPE.NORMAL ? {
      cartSkuDish: D
    } : {
      cartPackageSku: D
    }
  }
  return i.default.show({
    content: I + "份起售，不能再少啦",
    duration: 1e3
  }), {}
}, exports.addTastesToPackage = function(t, e, i, l) {
  var d, c = null == (d = e) || null == (d = d.packageGroups) ? void 0 : d.findIndex((function(e) {
    return e.groupId === t.groupId
  }));
  if (-1 === c || void 0 === c) return e;
  var g = n.default.getIn(e, ["packageGroups", c]),
    k = n.default.getIn(g, ["optionType"]) || r.PACKAGE_OPTION_TYPE.FIXED,
    m = n.default.getIn(g, ["groupSkus"]),
    I = (0, p.getPackageGroupLimitNum)(g).maxCount;
  m.reduce((function(t, e) {
    return Number(t) + Number(e.count)
  }), 0) === I && 1 === I && k === r.PACKAGE_OPTION_TYPE.FIXED && (e = h(m, t, i, e));
  var C = f.default.findLastIndex(n.default.getIn(e, ["packageGroups", c, "groupSkus"]), (function(e) {
      return e.goodsNo === t.goodsNo
    }), null),
    S = (0, s.getUniqueKey)(t),
    v = f.default.findLastIndex(n.default.getIn(e, ["packageGroups", c, "groupSkus"]), (function(t) {
      return t.goodsNo === S
    }), null);
  t.goodsNo !== S && (t = -1 === v ? n.default.merge(t, {
    goodsNo: S
  }) : n.default.getIn(e, ["packageGroups", c, "groupSkus"]).find((function(t) {
    return t.goodsNo === S
  })));
  var T = n.default.getIn(e, ["packageGroups", c, "groupSkus"]).findIndex((function(e) {
    return e.skuId === t.skuId
  }));
  if (t.groupType === o.GROUP_TYPE.FIXED) e = n.default.setIn(e, ["packageGroups", c, "groupSkus", T], t);
  else if ((null == l ? void 0 : l.multiOperateType) === o.OPERATE_PACKAGE_TASTE_TYPE.MODIFY) e = n.default.setIn(e, ["packageGroups", c, "groupSkus", T], t);
  else {
    var P = t.count;
    if (0 === P) t = n.default.set(t, "count", 1), e = n.default.setIn(e, ["packageGroups", c, "groupSkus", T], t);
    else if (-1 !== v) e = n.default.setIn(e, ["packageGroups", c, "groupSkus", v, "count"], P + 1);
    else {
      t = n.default.set(t, "count", 1);
      var N = (0, n.default)([].concat(u(m.slice(0, C + 1)), [t], u(m.slice(C + 1))));
      e = n.default.setIn(e, ["packageGroups", c, "groupSkus"], N)
    }
  }
  return e = (0, a.computePackageAddPrice)(e)
}, exports.addWeightDish = function(t, e, u) {
  return u = n.default.set(u, "weight", +e), u = (0, a.computeAddPrice)(u), t.methods && t.methods.length || t.tastes && t.tastes.length ? {
    cartSkuDish: u,
    showCalculatorPanel: !1,
    showMultiPanel: !0,
    weightTastes: !0,
    firstEnterCalc: !0
  } : {
    cartSkuDish: u,
    showCalculatorPanel: !1,
    firstEnterCalc: !0
  }
}, exports.editWeightSkuDish = function(t, e) {
  var u, n = t.spuId,
    r = t.skuId,
    a = e[n.toString()],
    s = null == a || null == (u = a.skuMenuItems) ? void 0 : u.find((function(t) {
      return t.skuId === r
    }));
  return {
    calcStatus: o.CALCULATOR_STATUS.WEIGHT,
    spuDish: a,
    menuSkuDish: s,
    cartSkuDish: t,
    calcValue: t.weight,
    editDishSpuId: t.spuId,
    editDishGoodsNo: t.goodsNo,
    showCalculatorPanel: !0
  }
}, exports.groupSkuCheck = C, exports.initAddDishData = function(t, e, u) {
  var o, r = t.spuId,
    a = null == e || null == (o = e[r]) ? void 0 : o.find((function(t) {
      return t.goodsNo === u
    }));
  return {
    menuSkuDish: null != a && a.skuId ? t.skuMenuItems.find((function(t) {
      return t.skuId === a.skuId
    })) : n.default.getIn(t, ["skuMenuItems", 0]) || {},
    skuDish: a ? c.default.updateMustCount(a) : a
  }
}, exports.minusPackageSkuDish = I, exports.nextInCalc = function(t, u, n, r, a, s, d, c, f) {
  var p = t.spuName,
    I = t.incBoughtCount,
    h = -1 === t.minBoughtCount ? 0 : t.minBoughtCount,
    C = -1 === n.stockCount ? 1 / 0 : n.stockCount,
    S = -1 === t.minBoughtCount ? I : t.minBoughtCount,
    v = t.spuId.toString(),
    T = (null == u ? void 0 : u.refactorCartDishMap[v]) || {},
    P = t.unit ? t.unit : "份",
    N = t.skuMenuItems.find((function(t) {
      return t.skuId === n.skuId
    })),
    A = void 0 === (null == N ? void 0 : N.limitCount) || -1 === (null == N ? void 0 : N.limitCount) ? 1 / 0 : N.limitCount,
    E = (null == N ? void 0 : N.orderedCount) || 0,
    D = 0,
    _ = "",
    M = 0;
  Object.keys(T).length && r !== o.CALCULATOR_STATUS.WEIGHT && (null == T || T.map((function(t) {
    return t.skuId === n.skuId && t.itemNo !== n.goodsNo && (M += t.count || 0), null
  })));
  var O = Number(a) + c;
  if (r === o.CALCULATOR_STATUS.WEIGHT) 0 === O ? i.default.show({
    content: "请输入重量"
  }) : O > C ? i.default.show({
    content: "仅剩".concat(C).concat(P, "，请重新输入")
  }) : O < h ? i.default.show({
    content: "".concat(h).concat(P, "起售，请重新输入")
  }) : _ = "weight";
  else {
    var x, G, w = p,
      y = null == N ? void 0 : N.specAttrs;
    Array.isArray(y) && null != (x = y[0]) && x.value && (w += "-" + (null == (G = y[0]) ? void 0 : G.value));
    var L = O + M;
    if (O < 0) i.default.show({
      content: g.MUST_DISH_IN_PACKAGE_TEXT
    });
    else if (0 === O) s || d ? i.default.show({
      content: "不能为0".concat(P, "，请重新输入")
    }) : n.mustCount && n.mustCount > 0 && L < n.mustCount ? (D = n.mustCount - M, i.default.show({
      content: g.MUST_DISH_CANNOT_MINUS_TEXT
    })) : _ = "count";
    else if (L > C) D = (0, k.calculateNewProperDishCount)({
      incBoughtCount: I,
      maximumRestrictCount: C,
      minBoughtCount: h,
      orderedCount: M
    }), i.default.show({
      content: "不可高于库存数量".concat(C - M, "份")
    });
    else if ((0, k.verifyLimitCount)({
        limitCount: A,
        newUsedCount: L
      }))
      if (L < S) D = S - M, i.default.show({
        content: "不可低于起售数量".concat(S - M, "份")
      });
      else if ((L - h) % I != 0)(D = (Math.floor((L - h) / I) + 1) * I + h - M) + M > C && (D -= I), D + M > o.MAX_THRESHOLD && (D -= I), i.default.show({
      content: "输入的数量不符合规则，已为您调整"
    });
    else if (n.mustCount && L < n.mustCount) D = n.mustCount - M, i.default.show({
      content: g.MUST_DISH_CANNOT_MINUS_TEXT
    });
    else {
      var b, U = m.default.getShopServiceData().fmpBizData,
        R = null == U ? void 0 : U.promoLimitActivityVO;
      if (R && null != N && N.skuId) {
        var q, B = e(R.limitRuleTag);
        try {
          for (B.s(); !(q = B.n()).done;) {
            var H = q.value,
              V = H.skuIdList,
              Y = H.limitValue,
              X = H.limitValuePerPerson,
              K = H.limitActivityType;
            if (V.includes(+(null == N ? void 0 : N.skuId))) {
              var F = (0, k.computeSkuDishListInCart)(V.filter((function(t) {
                  return +t != +(null == N ? void 0 : N.skuId)
                })), f),
                j = F.skusCountInCart,
                W = F.skuNames;
              if (-1 === W.indexOf(w) && W.unshift(w), !(0, k.verifyLimitCount)({
                  limitCount: Y,
                  newUsedCount: O + j
                })) {
                var z;
                b = {
                  limitValue: Y,
                  limitValuePerPerson: X,
                  limitMessageTpl: null == (z = R.limitTextMode) ? void 0 : z["" + K],
                  skuNames: W,
                  skusCountInCart: j
                };
                break
              }
            }
          }
        } catch (t) {
          B.e(t)
        } finally {
          B.f()
        }
      }
      if (b) {
        D = (0, k.calculateNewProperDishCount)({
          incBoughtCount: I,
          minBoughtCount: h,
          maximumRestrictCount: b.limitValue - (b.skusCountInCart || 0),
          orderedCount: M
        });
        var J = {
          dishName: b.skuNames,
          limitCount: b.limitValue,
          orderedCount: 0,
          limitValuePerPerson: b.limitValuePerPerson,
          limitMessageTpl: b.limitMessageTpl
        };
        (0, l.default)({
          title: "温馨提示",
          body: (0, k.jointExceedLimitCountMessage)(J),
          buttons: [{
            text: "我知道了",
            type: "submit"
          }]
        })
      } else _ = "count"
    } else D = (0, k.calculateNewProperDishCount)({
      incBoughtCount: I,
      maximumRestrictCount: A,
      minBoughtCount: h,
      orderedCount: M + E
    }), i.default.show({
      content: (0, k.jointExceedLimitCountMessage)({
        dishName: w,
        limitCount: A,
        orderedCount: E
      }),
      duration: k.LIMIT_COUNT_MESSAGE_DURATION
    })
  }
  return D ? {
    calcValue: D
  } : _ ? {
    updateDish: _
  } : {}
}, exports.revertCartPackageSku = h, exports.selectPackageTastes = function(t, e, u, r, s) {
  var l, d = null == (l = t) || null == (l = l.packageGroups) ? void 0 : l.findIndex((function(t) {
      return t.groupId === u.groupId
    })),
    c = n.default.getIn(t, ["packageGroups", d]),
    g = n.default.getIn(c, ["groupSkus"]),
    p = f.default.findLastIndex(g, (function(t) {
      return t.goodsNo === u.goodsNo
    }), null),
    k = -1 === r.stockCount ? 1 / 0 : r.stockCount,
    m = n.default.getIn(c, ["groupSkus"]),
    I = u.count,
    S = u.number,
    v = r.methods,
    T = r.tastes,
    P = C(c, r, u),
    N = P.canSelect,
    A = P.isOptional,
    E = P.singleExclusive,
    D = P.toast;
  if (N || s === o.OPERATE_PACKAGE_TASTE_TYPE.MODIFY) return {
    menuSkuDish: r,
    cartSkuDish: u,
    packageTastes: !0,
    packageVisible: !1,
    showMultiPanel: !0
  };
  if (A) {
    E && (t = h(m, u, e, t));
    var _ = !v || v && 0 === v.length,
      M = !T || T && 0 === T.length;
    if (_ && M) return k && S * (I + 1) > k ? (i.default.show({
      content: "当前库存不足",
      duration: 1e3
    }), {}) : (t = n.default.setIn(t, ["packageGroups", d, "groupSkus", p, "count"], I + 1), {
      cartPackageSku: t = (0, a.computePackageAddPrice)(t)
    });
    var O = 0;
    return m.forEach((function(t) {
      t.skuId === u.skuId && (O += u.count)
    })), k && (O + 1) * S > k ? (i.default.show({
      content: "当前库存不足",
      duration: 1e3
    }), {}) : {
      menuSkuDish: r,
      cartSkuDish: u,
      packageTastes: !0,
      packageVisible: !1,
      cartVisible: !1,
      showMultiPanel: !0
    }
  }
  return D && i.default.show({
    content: D,
    duration: 1e3
  }), {}
}, exports.selectSkuDish = function(t) {
  var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : -1,
    u = arguments.length > 2 ? arguments[2] : void 0,
    o = arguments.length > 3 ? arguments[3] : void 0,
    r = arguments.length > 4 ? arguments[4] : void 0;
  if (t.skuMenuItems.length && t.skuMenuItems.some((function(t) {
      return "{}" === JSON.stringify(t)
    })) && d.default.addError("复杂菜品spuDish内的skuMenuItems数据为空"), -1 === e) {
    var l, f, p = -1;
    if (p = r ? null == t || null == (l = t.skuMenuItems) ? void 0 : l.findIndex((function(t) {
        return t.skuId === r
      })) : null == t || null == (f = t.skuMenuItems) ? void 0 : f.findIndex((function(t) {
        return !0 === t.defaultSelected
      })), e = -1 !== p && void 0 !== p ? p : 0, n.default.getIn(t, ["skuMenuItems", e, "soldOut"])) {
      for (e = 0; n.default.getIn(t, ["skuMenuItems", e, "soldOut"]);) e++;
      if (e >= t.skuMenuItems.length) return i.default.show({
        content: "该菜品已售罄~",
        duration: 1e3
      }), {}
    }
  }
  if (n.default.getIn(t, ["skuMenuItems", e, "soldOut"])) return {};
  var k = n.default.getIn(t, ["skuMenuItems", e]);
  if (u && u.skuId === k.skuId && u.stockCount === k.stockCount) return {};
  if (u && u.mustCount && u.mustCount > 0 && c.default.getSkuTotalCountInCart(o.refactorCartDishMap, u.skuId) - u.count < u.mustCount) return i.default.show({
    content: g.MUST_DISH_CANNOT_CHANGE_SPEC_TEXT,
    duration: 1e3
  }), {};
  var m, I = k.spuId,
    h = k.skuId,
    C = -1 === t.minBoughtCount ? t.incBoughtCount : t.minBoughtCount;
  if (k.canWeight) m = (null == u ? void 0 : u.count) || 1;
  else {
    var S, v = o.refactorCartDishMap[I.toString()];
    v && (S = v.find((function(t) {
      return t.skuId === h
    }))), m = S ? t.incBoughtCount : C
  }
  var T = (0, a.setCartSkuAttrs)(t),
    P = T.newMethods,
    N = T.newTastes,
    A = n.default.merge(k, {
      count: m,
      categoryId: n.default.getIn(t, ["parentCategoryId", 0]),
      methods: (null == u ? void 0 : u.methods) || P,
      tastes: (null == u ? void 0 : u.tastes) || N
    }),
    E = (0, s.getUniqueKey)(A);
  return A = n.default.set(A, "goodsNo", E), A = (0, a.computeAddPrice)(A), {
    menuSkuDish: k,
    cartSkuDish: A
  }
}, exports.updateDishCount = function(t, e, u, o, r, a, s) {
  var i = n.default.set(o, "count", +u);
  if (e) return {
    cartSkuDish: i
  };
  if (t) return {
    cartPackageSku: i
  };
  var l = o.spuId.toString(),
    d = a[l],
    c = d ? d.findIndex((function(t) {
      return t.goodsNo === o.goodsNo
    })) : -1,
    f = Number(u) + s;
  if (i = n.default.set(o, "count", f), 0 !== f)
    if (c >= 0) a = n.default.setIn(a, [l, c], i);
    else {
      var g = n.default.merge(i, {
        count: f,
        createTime: Date.now()
      });
      a = n.default.set(a, l, [g]), r = r.concat([{
        skuId: g.skuId,
        spuId: l,
        goodsNo: g.goodsNo
      }])
    }
  else {
    if (d.length > 1) {
      var p = n.default.flatMap(d, (function(t, e) {
        return e === c ? [] : t
      }));
      a = n.default.set(a, l, p)
    } else a = n.default.without(a, l);
    var k = r.findIndex((function(t) {
      return t.goodsNo === o.goodsNo
    }));
    r = n.default.flatMap(r, (function(t, e) {
      return e === k ? [] : t
    }))
  }
  return {
    cartSkuDish: i,
    cartDishList: a,
    cartDishSortMapList: r
  }
}, require("../../b/helpers/Arrayincludes");
var e = require("../../b/helpers/createForOfIteratorHelper"),
  u = require("../../b/helpers/toConsumableArray"),
  n = t(require("../../miniprogram_npm/seamless-immutable/index.js")),
  o = require("../../constants/bizConstants"),
  r = require("../../constants/menu"),
  a = require("../cartHelper"),
  s = require("../operateCartHelper"),
  i = t(require("../../lib/mix/toast")),
  l = t(require("../../lib/mix/confirm")),
  d = t(require("../../lib/wx/log")),
  c = t(require("../MustDishSdk")),
  f = t(require("../../miniprogram_npm/@mtfe/rms-triangle-c/index.js")),
  g = require("../../constants/cartConstants"),
  p = require("./panelHelper"),
  k = require("../dishHelper"),
  m = t(require("../menu/shop/shopService"));

function I(t, e, u) {
  var o, r = null == (o = t) || null == (o = o.packageGroups) ? void 0 : o.findIndex((function(t) {
      return t.groupId === e.groupId
    })),
    i = f.default.findLastIndex(n.default.getIn(t, ["packageGroups", r, "groupSkus"]), (function(t) {
      return t.goodsNo === e.goodsNo
    }), null),
    l = n.default.getIn(t, ["packageGroups", r, "groupSkus"]).find((function(t) {
      return t.skuId === e.skuId && t.goodsNo !== e.goodsNo
    })),
    d = e.count;
  if (d <= 0) return {};
  if (1 === d)
    if (l) {
      var c = n.default.flatMap(n.default.getIn(t, ["packageGroups", r, "groupSkus"]), (function(t, e) {
        return e === i ? [] : t
      }));
      t = n.default.setIn(t, ["packageGroups", r, "groupSkus"], c)
    } else {
      var g = (0, a.setCartSkuAttrs)(u),
        p = g.newMethods,
        k = g.newTastes,
        m = n.default.merge(u, {
          groupId: e.groupId,
          groupType: e.groupType,
          groupChoiceType: e.groupChoiceType,
          methods: p,
          tastes: k,
          number: e.number,
          count: 0
        });
      m = (0, a.computeAddPrice)(m);
      var I = (0, s.getUniqueKey)(m);
      m = n.default.set(m, "goodsNo", I), t = n.default.setIn(t, ["packageGroups", r, "groupSkus", i], m)
    }
  else t = n.default.setIn(t, ["packageGroups", r, "groupSkus", i, "count"], d - 1);
  return {
    cartPackageSku: t = (0, a.computePackageAddPrice)(t)
  }
}

function h(t, e, u, n) {
  var o, r, a = t.find((function(t) {
    return 1 === t.count
  }));
  if (!a) return n;
  var s = null == u || null == (o = u.packageGroups) ? void 0 : o.find((function(t) {
      return t.groupId === e.groupId
    })),
    i = null == s || null == (r = s.groupSkus) ? void 0 : r.find((function(t) {
      return t.skuId === a.skuId
    }));
  if (i) {
    var l = I(n, a, i);
    if (l.cartPackageSku) return l.cartPackageSku
  }
  return n
}

function C(t, e, u) {
  var s, i = n.default.getIn(t, ["optionType"]) || r.PACKAGE_OPTION_TYPE.FIXED,
    l = (0, p.getPackageGroupLimitNum)(t).maxCount,
    d = (0, p.getPackageGroupLimitText)(t),
    c = n.default.getIn(t, ["groupSkus"]),
    f = u.groupChoiceType,
    g = u.groupType,
    k = u.count,
    m = c.reduce((function(t, e) {
      return Number(t) + Number(e.count)
    }), 0),
    I = (f === o.GROUP_CHOICE_TYPE.REPEATABLE || f === o.GROUP_CHOICE_TYPE.NON_REPEATABLE && 0 === k) && m < l,
    h = g === o.GROUP_TYPE.FIXED && (0, a.selectTastes)(e),
    C = m === l && 1 === l && i === r.PACKAGE_OPTION_TYPE.FIXED,
    S = (0, p.checkGroupSkuLimit)(t, e),
    v = I && (m < l || C) && !S || null === n.default.getIn(t, ["optionType"]) && 1 === l && f === o.GROUP_CHOICE_TYPE.NON_REPEATABLE;
  if (m >= l) s = "您只能选择".concat(d, "份菜品");
  else if (S) {
    var T = e.maxChoiceAmount,
      P = e.skuNameAndSpecAttr;
    s = "[".concat(P, "]限购 ").concat(T, " 份哦～")
  }
  return {
    canSelect: h,
    isOptional: v,
    singleExclusive: C,
    toast: s
  }
}