var t = require("../../../@limo/container/behaviors/index");
Component({
  behaviors: [t.commonBehavior, t.limoShim],
  properties: {
    amount: {
      type: Number,
      value: 0
    },
    buttons: {
      type: Array,
      value: []
    }
  },
  methods: {
    limoAttached: function() {},
    confirmBtnClick: function(t) {
      var i, e = null == (i = this.data) || null == (i = i.buttons) ? void 0 : i.find((function(i) {
        return i.type === t.detail
      }));
      e && e.callback && e.callback()
    }
  },
  attached: function() {
    this.limoAttached()
  }
});