var e = require("../../../../../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
});
var o = require("../../../../../b/helpers/objectSpread2"),
  t = e(require("../../limo-core/index")),
  a = require("../../../../../miniprogram_npm/@limo/container/behaviors/index"),
  l = function(e) {
    return a._getModules.call(this, o(o({}, e), {}, {
      moduleDefaultProperties: i
    }))
  };
Component({
  behaviors: [a.commonBehavior],
  externalClasses: ["container-class"],
  properties: {
    data: {
      type: Object,
      value: {},
      observer: function(e) {
        if (e && e.modules) try {
          this.initEntryTs = Date.now(), this.initModuleLoadDurations = {};
          var o = l.call(this, e),
            t = o.modulesChange,
            a = o.modules,
            i = o.layoutStyle;
          t ? this.setData({
            modules: a,
            layoutStyle: i
          }) : this.watchData(e)
        } catch (e) {
          console.error(e)
        }
      }
    }
  },
  data: {
    layoutStyle: "",
    modules: [],
    dialogs: []
  },
  created: function() {
    this.lastCommonData = "", this.lastModules = [], this.linkedModules = []
  },
  attached: function() {
    var e = this.getInstance();
    e && e.linked(this, "limo-layout"), t.default.clearCaches()
  },
  methods: {
    watchData: function(e) {
      return a._watchData.call(this, e, i)
    },
    updateModule: a.updateModule,
    loadModule: a.loadModule,
    unLoadModule: a.unLoadModule,
    destroyModule: a.layoutDestroyModule,
    hasModule: a.layoutHasModule,
    transformStyle: a.transformStyle,
    validateLayoutValue: a.validateLayoutValue,
    formatLayoutInfo: a.formatLayoutInfo,
    limoShowDialog: function(e, o, t) {
      return a._limoShowDialog.call(this, e, o, t, i)
    },
    limoCloseDialog: a.limoCloseDialog,
    onMaskTap: a.onMaskTap,
    onMaskTouchMove: a.onMaskTouchMove,
    limoDidLoad: a.limoDidLoad,
    limoSetLayoutStyle: a.limoSetLayoutStyle,
    __getContainerLimoCore: function() {
      return t.default
    }
  }
});
var i = {
  "order-list": {
    orderList: [],
    status: 0
  },
  "tab-bar": {
    position: "fixed",
    selectedPageType: -1,
    tabBarList: [],
    color: "#999999",
    selectedColor: "#333333",
    showTabBar: !0,
    requestParams: {},
    customOptions: {}
  },
  "ui-confirm": {
    hasCloseBtn: !1,
    title: "",
    body: "",
    buttons: "{\n  text: '取消',\n  type: 'cancel'\n}, {\n  text: '确定',\n  type: 'submit'\n}"
  },
  "invoice-confirm": {
    amount: 0,
    buttons: []
  }
};