var e, t = require("../../../b/helpers/interopRequireDefault"),
  r = t(require("../../../b/regenerator")),
  i = require("../../../b/helpers/asyncToGenerator"),
  a = require("../../../b/helpers/objectSpread2"),
  n = t(require("../../../miniprogram_npm/@limo/core/index.js")),
  o = require("../../../miniprogram_npm/@limo/container/behaviors/index.js"),
  s = require("../../../miniprogram_npm/@mtfe/rms-sdk/index.js"),
  c = t(require("../decor-comp-behavior/index")),
  u = require("../common-helpers/memberHelper"),
  l = "accumulate-list-cache";
Component({
  behaviors: [c.default, o.commonBehavior, o.limoShim],
  properties: {
    accumulateList: {
      type: Array,
      value: [],
      observer: function(e) {
        e && e.length && this.initData(e)
      }
    },
    horizontal: {
      type: Boolean,
      value: !0
    },
    pollTimes: {
      type: Number,
      value: 0,
      observer: function(e, t) {
        if (e && e !== t) {
          var r = this.properties.requestParams;
          r && Object.keys(r).length && this.loadHttpData(r)
        }
      }
    },
    requestParams: {
      type: Object,
      value: {},
      observer: function(e, t) {
        e && JSON.stringify(e) !== JSON.stringify(t) && this.loadHttpData(e)
      }
    },
    appliedStyle: {
      type: Number,
      value: 2
    },
    showWarning: {
      type: Boolean,
      value: !1
    },
    selfMargin: {
      type: Boolean,
      value: !1
    },
    businessData: {
      type: Object,
      value: {},
      observer: function(e, t) {
        e && JSON.stringify(e) !== JSON.stringify(t) && this.loadHttpData({
          params: e
        })
      }
    },
    title: {
      type: String,
      value: ""
    },
    activityDesc: {
      type: String,
      value: ""
    },
    titleColor: {
      type: String,
      value: "",
      observer: function(e) {
        e && this.setData({
          titleColorStyle: "color: " + e
        })
      }
    },
    textColor: {
      type: String,
      value: "",
      observer: function(e) {
        e && this.setData({
          textColorStyle: "color: ".concat(e, ";")
        })
      }
    },
    backgroundImgUrl: {
      type: String,
      value: "",
      observer: function(e) {
        this.setData({
          backgroundStyle: e ? "background: url(".concat(e, ") center/cover no-repeat;") : ""
        })
      }
    },
    showActivityDesc: {
      type: Boolean,
      value: !0
    },
    isRms: {
      type: Boolean,
      value: !1
    },
    isH5Preview: {
      type: Boolean,
      value: !1
    }
  },
  pageLifetimes: {
    show: function() {
      this.limoPageShow()
    }
  },
  attached: function() {
    this.limoAttached(), this.limoPageShow()
  },
  detached: function() {
    this.properties.isH5Preview || s.Observer.getInstance().unsubscribe("updateMemberCardId", e)
  },
  data: {
    accumulateListRender: [],
    titleColorStyle: "",
    textColorStyle: "",
    backgroundStyle: ""
  },
  isLoading: !1,
  methods: {
    limoPageShow: function() {
      n.default.getLimoRuntime().sendMV("b_eco_4e979kjc_mv"), this.loadHttpData({
        params: this.properties.businessData
      })
    },
    limoAttached: function() {
      var t = this;
      if (!this.properties.isH5Preview) {
        var r = s.Observer.getInstance();
        e = function(e) {
          var r;
          t.loadHttpData({
            params: a(a({}, null == (r = t.properties) ? void 0 : r.businessData), {}, {
              cardId: e
            })
          })
        }, r.subscribe("updateMemberCardId", e), this.getListFormStorage()
      }
    },
    loadHttpData: function(e) {
      var t = this;
      return i(r.default.mark((function i() {
        var a, n, o, s, c, u, l, p, d;
        return r.default.wrap((function(r) {
          for (;;) switch (r.prev = r.next) {
            case 0:
              if (!t.isLoading) {
                r.next = 2;
                break
              }
              return r.abrupt("return");
            case 2:
              if (t.isLoading = !0, a = (null == e ? void 0 : e.params) || {}, n = a.cardId, o = a.restaurantViewId, s = a.tenantId, c = a.activityId, u = a.bizIdType, l = a.mtShopId, p = a.shopId, !Object.keys(null == e ? void 0 : e.params).length) {
                r.next = 9;
                break
              }
              return r.next = 7, t.requestList({
                params: {
                  cardId: n,
                  activityId: c,
                  tenantId: s,
                  restaurantViewId: o || "",
                  bizIdType: u || "",
                  mtShopId: l || "",
                  shopId: p || ""
                },
                url: "/api/v1/rmsmina/c/comp/member/point"
              });
            case 7:
              d = r.sent, t.initData(d);
            case 9:
              t.isLoading = !1;
            case 10:
            case "end":
              return r.stop()
          }
        }), i)
      })))()
    },
    getListFormStorage: function() {
      var e = this;
      (0, u.getStorageData)({
        key: l,
        success: function(t) {
          e.setData({
            accumulateListRender: t
          })
        }
      })
    },
    requestList: function(e) {
      var t = this;
      return new Promise((function(r) {
        var i = t.properties.mtShopId,
          n = e.params,
          o = e.url;
        (0, u.request)({
          url: o,
          params: a({
            mtShopId: i || ""
          }, n),
          completeCallbacks: function(e) {
            e.accumulateActivityVos && r(e.accumulateActivityVos)
          },
          failCallbacks: function() {
            r([])
          }
        })
      }))
    },
    viewActivityDetail: function(e) {
      this.triggerEvent("jumpToPage", e.detail || {})
    },
    initData: function(e) {
      var t = this,
        r = e.map((function(e) {
          return a(a({}, e), {}, {
            title: t.properties.title ? t.properties.title : e.title,
            titleImgUrl: e.titleImgUrl || "https://p1.meituan.net/scarlett/6e52890ede8c0cdaf961991b363d5fd51513.png",
            titleDescribe: t.properties.activityDesc ? t.properties.activityDesc : e.titleDescribe,
            describe: t.handleDescribe(e.describe) || [],
            collectPointClass: t.pointClass(e),
            collectPointPresent: t.activeStyle(e),
            progressIconList: t.calcProgress(e)
          })
        }));
      this.setData({
        accumulateListRender: r
      }), n.default.getLimoRuntime().setStorage({
        key: l,
        data: {
          data: r,
          expireTime: Date.now()
        }
      })
    },
    calcProgress: function(e) {
      for (var t = [], r = 0; r < e.maxCount; r++) r < e.count ? t.push(e.iconUrl || "https://p0.meituan.net/scarlett/9db899be66a722f57b4acc8168bd7af317869.png") : t.push(e.voidIconUrl || "https://p0.meituan.net/scarlett/e5835b20c29b3ad3cb7b7dbe91f79bfb7366.png");
      return t
    },
    pointClass: function(e) {
      var t = e.maxCount;
      return t >= 0 && t <= 5 ? "point-lg" : t > 5 && t <= 7 ? "point-md" : t > 7 && t <= 10 ? "point-sm" : void 0
    },
    activeStyle: function(e) {
      var t = e.count,
        r = void 0 === t ? 0 : t,
        i = e.maxCount,
        a = void 0 === i ? 0 : i,
        n = (r > a ? a : r) / a * 100;
      return Number.isNaN(n) ? "width: 0%" : "width:" + n + "%"
    },
    adRedirectTo: function(e) {
      var t = e.currentTarget.dataset.redirectUrl || e.currentTarget.redirectUrl;
      this.triggerEvent("jumpToPage", {
        url: t,
        type: 2
      }), t && (n.default.getLimoRuntime().sendMC("b_eco_4e979kjc_mc"), n.default.getLimoRuntime().navigateTo({
        url: t
      }))
    },
    handleDescribe: function() {
      var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
      return e.map((function(e, t) {
        return 1 === t && "number" == typeof Number(e.text) && e.text > 999 && (e.text = "999+"), e
      }))
    }
  }
});