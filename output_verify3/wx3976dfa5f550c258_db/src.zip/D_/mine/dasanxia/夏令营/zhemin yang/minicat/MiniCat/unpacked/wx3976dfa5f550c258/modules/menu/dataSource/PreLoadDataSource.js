var e = require("../../../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.preloadData = void 0;
var r = e(require("../../../b/regenerator")),
  t = require("../../../b/helpers/asyncToGenerator"),
  a = e(require("../../../lib/mix/log")),
  n = require("../../../types/IResponse"),
  u = require("./LocalDataSource"),
  c = require("./RemoteDataSource"),
  s = a.default,
  p = function() {
    var e = t(r.default.mark((function e(a, p) {
      return r.default.wrap((function(e) {
        for (;;) switch (e.prev = e.next) {
          case 0:
            (function() {
              var e = t(r.default.mark((function e(t, a) {
                var p, o;
                return r.default.wrap((function(e) {
                  for (;;) switch (e.prev = e.next) {
                    case 0:
                      if (e.prev = 0, p = (0, u.getPreloadParams)(a)) {
                        e.next = 4;
                        break
                      }
                      return e.abrupt("return");
                    case 4:
                      return t.requestStart = !0, e.next = 7, (0, c.getMenuFmp)(p);
                    case 7:
                      if (o = e.sent) {
                        e.next = 10;
                        break
                      }
                      return e.abrupt("return");
                    case 10:
                      if (!(0, n.isErrorTips)(o)) {
                        e.next = 12;
                        break
                      }
                      return e.abrupt("return");
                    case 12:
                      (0, u.mpCacheFmp)(t, o), e.next = 18;
                      break;
                    case 15:
                      e.prev = 15, e.t0 = e.catch(0), s.addError("fmp预加载失败", e.t0);
                    case 18:
                    case "end":
                      return e.stop()
                  }
                }), e, null, [
                  [0, 15]
                ])
              })));
              return function(r, t) {
                return e.apply(this, arguments)
              }
            })()(a.cache, p),
            function() {
              var e = t(r.default.mark((function e(t, a) {
                var n, p;
                return r.default.wrap((function(e) {
                  for (;;) switch (e.prev = e.next) {
                    case 0:
                      if (e.prev = 0, n = (0, u.getPreloadParams)(a)) {
                        e.next = 4;
                        break
                      }
                      return e.abrupt("return");
                    case 4:
                      return t.requestStart = !0, e.next = 7, (0, c.getPageSpu)(n);
                    case 7:
                      if (p = e.sent) {
                        e.next = 10;
                        break
                      }
                      return e.abrupt("return");
                    case 10:
                      (0, u.mpCacheSpu)(t, p), e.next = 16;
                      break;
                    case 13:
                      e.prev = 13, e.t0 = e.catch(0), s.addError("菜品预加载失败", e.t0);
                    case 16:
                    case "end":
                      return e.stop()
                  }
                }), e, null, [
                  [0, 13]
                ])
              })));
              return function(r, t) {
                return e.apply(this, arguments)
              }
            }()(a.spuCache, p);
          case 1:
          case "end":
            return e.stop()
        }
      }), e)
    })));
    return function(r, t) {
      return e.apply(this, arguments)
    }
  }();
exports.preloadData = p;