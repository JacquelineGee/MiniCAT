var e = require("../../b/helpers/interopRequireDefault"),
  t = require("../../b/helpers/defineProperty"),
  a = require("../../b/helpers/slicedToArray"),
  n = require("../../b/helpers/objectSpread2"),
  r = e(require("../../b/regenerator")),
  i = require("../../b/helpers/asyncToGenerator"),
  o = e(require("../../miniprogram_npm/seamless-immutable/index.js")),
  s = e(require("../../api/rmsStorage")),
  u = e(require("../../lib/mix/toast")),
  d = e(require("../../miniprogram_npm/@limo/core/index.js")),
  l = require("../../miniprogram_npm/@mtfe/rms-sdk/index.js"),
  c = require("../../constants/bizConstants"),
  p = require("../../constants/lxConstants"),
  h = require("../../constants/menu"),
  f = require("../../lib/mix/util"),
  m = require("../../constants/reportConstants"),
  g = require("../../constants/carBarConstants"),
  T = require("../../modules/menu/dish/expose"),
  P = require("../../modules/menu/category/CategoryDataTransfer"),
  D = require("../../modules/menuHelper"),
  I = require("../../modules/cartHelper"),
  C = require("../../store/actions/baseCart"),
  E = require("../../modules/operateCartHelper"),
  _ = require("../../store/actions/extraInfo"),
  S = require("../../store/actions/add-on"),
  v = require("../../store/actions/cart"),
  y = require("../../store/cart/PointPurchaseService"),
  A = e(require("../../modules/menu/cart/cartSdk")),
  w = require("../../store/actions/dish"),
  L = require("../../store/actions/panel"),
  M = require("../../store/actions/takeaway"),
  k = require("../../store/asyncActions/takeaway"),
  R = require("../../modules/takeaway/takeawayHelper"),
  b = require("../../modules/takeaway/util"),
  O = require("../../lib/wx/app-info"),
  x = require("../../lib/wx/util"),
  N = require("../../modules/LXHelper"),
  F = e(require("../../miniprogram_npm/@mtfe/rms-triangle-c/index.js")),
  q = require("../../lib/wx/page"),
  U = require("../../lib/wx/plugin/diancan"),
  B = require("../../modules/menu/dish/DishDataTransfer"),
  H = require("../../modules/menu/dish/PropertyUtil"),
  Y = require("../../lib/userInfo"),
  G = require("../../constants/decorate"),
  V = e(require("../../api/shop")),
  W = require("../../modules/menu/pageViewModel"),
  z = e(require("../../lib/mix/log")),
  K = require("../../modules/menu/dish/DishDataUtil"),
  j = require("../../modules/menu/limo/MpPageViewModel"),
  Q = require("../../types/IResponse"),
  X = require("../../lib/wx/transfer-rpx"),
  Z = require("../../modules/menu/dataSource/point"),
  J = e(require("../../modules/menu/grouponCoupon/GrouponCouponSdk")),
  $ = require("../../constants/errorTip"),
  ee = require("../../modules/error-tip/errorTipHelper"),
  te = require("../../lib/navigator"),
  ae = require("../../store/helpers/compose"),
  ne = require("../../modules/menu/scrollAnimation/index"),
  re = require("./utils/point"),
  ie = require("./utils/perfLog"),
  oe = require("../../modules/panel/panelTransaction"),
  se = require("../../types/common/URLParameters"),
  ue = require("../../store/actions/point-purchase"),
  de = require("../../lib/wx/weiqian-special"),
  le = require("../../constants/decorConstants"),
  ce = e(require("../../modules/MustDishSdk"));
(0, q.ProxyPage)((0, ae.composePage)((function(e) {
  return {
    cartDishList: o.default.getIn(e, ["cart", "cartDishList"]) || (0, o.default)({}),
    cartDishSortMapList: o.default.getIn(e, ["cart", "cartDishSortMapList"]) || (0, o.default)([]),
    spuDish: o.default.getIn(e, ["cart", "spuDish"]),
    mpUserInfo: o.default.getIn(e, ["extraInfo", "mpUserInfo"]),
    showContainerPanelTag: o.default.getIn(e, ["cart", "showContainerPanelTag"]),
    showDishInfoModal: o.default.getIn(e, ["panel", "showDishInfoModal"]),
    dishTimeInfoModalRequestInfo: o.default.getIn(e, ["panel", "dishTimeInfoModalRequestInfo"]),
    refactorLocalCart: o.default.getIn(e, ["cart", "refactorLocalCart"]),
    takeCouponPanelInfo: o.default.getIn(e, ["panel", "takeCouponPanelInfo"]) || {},
    takeCouponPanelData: o.default.getIn(e, ["panel", "takeCouponPanelData"]) || {},
    showPrePriceTips: o.default.getIn(e, ["panel", "showPrePriceTips"])
  }
}), (function(e) {
  return {
    pointPurchaseAdd: function(t) {
      return e(y.PointPurchase.addDish(t))
    },
    setPointPurchase: function(t) {
      return e((0, ue.setPointPurchase)(t))
    },
    addDish: function(t) {
      return e((0, v.addDish)(t))
    },
    addToCart: function(t) {
      return e((0, v.addToCart)(t))
    },
    minusDish: function(t) {
      return e((0, v.minusDish)(t))
    },
    minusCartGrouponDish: function(t, a) {
      return e((0, v.minusCartGrouponDish)(t, a))
    },
    openDishDetail: function(t) {
      return e((0, v.openDishDetail)(t))
    },
    updateBaseInfo: function(t, a) {
      return e((0, v.updateBaseInfo)(t, a))
    },
    setDishList: function(t, a) {
      return e((0, w.setDishList)(t, a))
    },
    setExtraInfo: function(t, a) {
      return e((0, _.setExtraInfo)(t, a))
    },
    initNewCart: function() {
      return e(A.default.init.apply(A.default, arguments))
    },
    setUrlParams: function(t) {
      return e((0, _.setUrlParams)(t))
    },
    setMpUserInfo: function(t) {
      return e((0, _.setMpUserInfo)(t))
    },
    showCalcPanel: function(t) {
      return e((0, v.showCalcPanel)(t))
    },
    updateCalculator: function(t) {
      return e((0, C.updateCalculator)(t))
    },
    editWeightSkuDish: function(t) {
      return e((0, v.editWeightSkuDish)(t))
    },
    toggleRegisterPanelAction: function(t) {
      return e((0, v.toggleRegisterPanelAction)(t))
    },
    updateCurrentDishId: function(t) {
      return e((0, C.updateCurrentDishId)(t))
    },
    toggleContainerPanelAction: function(t) {
      return e((0, C.toggleContainerPanelAction)(t))
    },
    setDishAddFromAction: function(t) {
      return e((0, v.setDishAddFromAction)(t))
    },
    updateEditSkuDishAction: function(t) {
      return e((0, C.updateEditSkuDishAction)(t))
    },
    toggleDishInfoModal: function(t) {
      return e((0, L.toggleDishInfoModal)(t))
    },
    showDishTimeInfoModal: function(t) {
      return e((0, L.showDishTimeInfoModal)(t))
    },
    showTakeCouponPanelAction: function(t) {
      return e((0, L.showTakeCouponPanelAction)(t))
    },
    addFixedPackage: function(t, a) {
      return e(A.default.addFixedPackage(t, a))
    },
    setAddOnShow: function(t) {
      return e((0, S.setAddOnShowAction)(t))
    },
    selectAddress: function(t) {
      return e((0, k.selectAddress)(t))
    },
    getUserAddressList: function() {
      return e((0, k.getUserAddressList)())
    },
    setUserAddressList: function(t) {
      return e((0, M.setUserAddressList)(t))
    },
    setAddressListModalFlag: function(t) {
      return e((0, M.setAddressListModalFlag)(t))
    },
    updateTakeawayConfigInfo: function(t) {
      return e((0, M.updateTakeawayConfigInfo)(t))
    },
    clearCart: function() {
      e(A.default.clearCart()), (0, N.sendMC)("b_saaspay_lxmzp99s_mc")
    },
    updatePickUpDistance: function() {
      return e((0, k.updatePickUpDistance)())
    },
    updateCloudCacheCartData: function() {
      return e((0, k.updateCloudCacheCartData)())
    },
    updatePrePriceTips: function(t) {
      return e((0, L.updatePrePriceTips)(t))
    }
  }
}), {
  pageViewModel: j.MpPageViewModel,
  defineFmpCondition: function() {
    return {
      conditions: ["shopInfo", "recycleList"]
    }
  },
  data: {
    showFullLoading: !0,
    dishShowType: "",
    allDishList: [],
    finishSetDishList: !1,
    firstScreenCollectEnd: !1,
    reachBoundary: "",
    menuScrollY: !0,
    categoriesList: [],
    isMember: !1,
    options: {},
    showOrderedDetailPanel: !1,
    expandedShopInfo: !1,
    resultCode: 100,
    recycleWinWidth: 0,
    isShowBigBtn: !0,
    hasTabBar: !1,
    initErrData: {},
    errorText: "",
    menuUpdateTime: 0,
    categoryStickyTop: ne.FIXED_HEAD_POSITION_MP,
    hasEnoughOptions: !1,
    location: {},
    isNativeTabbarPage: !1,
    errorInfo: null,
    hideCartBarWhenEmpty: g.HIDE_CART_BAR_WHEN_EMPTY.menu
  },
  isFirstShowToast: !0,
  realCategoryCount: 0,
  isFirstSet: !0,
  renderStartTime: 0,
  takeCouponData: {},
  isDestroy: !1,
  shareMsg: {},
  urlParams: {},
  isFirstEnterPage: !0,
  dishTimeInfoModalRequestInfo: {
    requestHost: "",
    requestParams: {}
  },
  menuDetailScrollHeight: 0,
  handleLoad: function(e) {
    var t = this;
    return i(r.default.mark((function a() {
      return r.default.wrap((function(a) {
        for (;;) switch (a.prev = a.next) {
          case 0:
            if (a.t0 = e && Object.keys(e).length, !a.t0) {
              a.next = 4;
              break
            }
            return a.next = 4, t._initPageShow(e);
          case 4:
          case "end":
            return a.stop()
        }
      }), a)
    })))()
  },
  onPageScroll: function(e) {
    var t = null == e ? void 0 : e.scrollTop;
    t < this.menuDetailScrollHeight && "top" !== this.data.reachBoundary ? this.setData({
      reachBoundary: "top"
    }) : t >= this.menuDetailScrollHeight && this.data.reachBoundary && this.setData({
      reachBoundary: ""
    }), t < 5 && "top" !== this.data.reachBoundary && (this.setData({
      reachBoundary: "top"
    }), d.default && d.default.setModuleData("menu-shop-info", {
      searchBannerOpacity: 0
    })), t >= this.stickyContainerScrollHeight && !this.stickyContainerFixed ? (this.stickyContainerFixed = !0, d.default && d.default.setModuleData("top-sticky-container", {
      fixed: !0
    })) : t < this.stickyContainerScrollHeight && this.stickyContainerFixed && (this.stickyContainerFixed = !1, d.default && d.default.setModuleData("top-sticky-container", {
      fixed: !1
    })), this.data.firstScreenCollectEnd || this.setData({
      firstScreenCollectEnd: !0
    }), (0, ne.setAnimation)(t, this, d.default)
  },
  onReachBottom: function() {
    this.setData({
      reachBoundary: "bottom"
    }), d.default && d.default.setModuleData("menu-shop-info", {
      searchBannerOpacity: 1
    })
  },
  switchCategory: function(e) {
    var t = this,
      a = F.default.MPInfo.getSystemInfo().windowWidth || 375,
      n = e.detail,
      r = this.createSelectorQuery();
    r.selectViewport().scrollOffset(), r.select(".container >>> #item-" + n).boundingClientRect(), r.exec((function(e) {
      var n = e[0] && e[0].scrollTop || 0,
        r = e[1] && e[1].top || 0,
        i = t.data.dishShowType === h.DISH_ITEM_TYPE_VAL.DEFAULT || t.data.dishShowType === h.DISH_ITEM_TYPE_VAL.RIGHT_LARGE,
        o = t.data.categoryStickyTop + (i ? 0 : 36) / 375 * a;
      d.default.getLimoRuntime().pageScrollTo({
        scrollTop: n + r - o,
        duration: 0
      })
    })), d.default && d.default.setModuleData("menu-shop-info", {
      searchBannerOpacity: 1
    })
  },
  getSelectedPageType: function() {
    var e = this.urlParams;
    return (0, f.isTakeAwayOrSelfPick)(e.bizType) ? Number(e.bizType) === c.BIZ_TYPE_MAP.TAKEAWAY ? c.PORTAL_TAB_TYPE.TAKEAWAY : c.PORTAL_TAB_TYPE.PICKUP : Number(e.reserveMode) === c.DISH_SOURCE.RESERVE ? c.PORTAL_TAB_TYPE.PRE_ORDER : c.PORTAL_TAB_TYPE.ORDER_MENU
  },
  loadTabBar: function(e) {
    var t, a, n = s.default.getTabBarData(e.restaurantViewId || e.shopId),
      r = (0, O.getNewApp)().diancanGlobalData.getPreview(G.CONTAINER_NAME.TAB_BAR),
      i = {
        params: {
          restaurantViewId: e.restaurantViewId || "",
          mtShopId: e.shopId || "",
          entrance: e.entrance || "",
          tenantId: e.tenantId || "",
          previewFlag: r,
          minaId: e.minaId || "",
          portalUrl: e.portalUrl || "",
          wmChannel: (0, b.getParamsFromCookie)("orderChannel") || -1
        },
        url: (0, f.getTabBarUrl)()
      },
      o = this.getSelectedPageType();
    return r && (n = [], s.default.setTabBarData(e.restaurantViewId || e.shopId, [])), this.setData({
      requestParams: null != (t = n) && t.length ? {} : i,
      catchTabBarList: n,
      selectedPageType: o
    }), {
      isVirtualTabbar: !(null == (a = n) || !a.length)
    }
  },
  onLoad: function(e) {
    var t = this;
    return i(r.default.mark((function a() {
      var o;
      return r.default.wrap((function(a) {
        for (;;) switch (a.prev = a.next) {
          case 0:
            if (t.__limoCore = d.default.LimoCoreFactory(), (0, q.initPageOnLoad)(), d.default.proxy({
                limoUseCustomHandler: {
                  sendMC: N.sendMC,
                  sendPV: N.sendPV,
                  sendMV: N.sendMV,
                  Toast: u.default,
                  Log: z.default,
                  Triangle: F.default,
                  ThemeUtil: {
                    ICON_TYPE: le.ICON_TYPE
                  },
                  rmsStorage: s.default,
                  appendExposeDishItem: T.appendExposeDishItem,
                  exposeDishItemNew: T.exposeDishItemNew,
                  dealOperationData: H.dealOperationData,
                  Cart: A.default,
                  MustDishSdk: ce.default,
                  dealOperationCountStyle: K.dealOperationCountStyle,
                  advertiseReporter: l.advertiseReporter
                }
              }), e = (0, x.getTabbarPageOptions)(e, t.route), t.optionsGuard(e)) {
              a.next = 2;
              break
            }
            return a.abrupt("return");
          case 2:
            return o = n(n({}, e), {}, {
              multiShop: e.multiShop || s.default.getMultiShop()
            }), t.setData({
              options: o,
              hasEnoughOptions: (0, D.hasEnoughOptions)(o),
              extraGetDecorationRequestParam: {
                shopCache: s.default.getShopCache()
              },
              isNativeTabbarPage: !!(0, O.isNativeTabbarPage)(t.route)
            }), (0, ie.updateIsFirstEnter)(t.isFirstEnterPage), (0, ie.addDataUpdateListener)(t), t.pageLoadTime = Date.now(), t.options = e, (0, W.showMustDishToast)(e), t._updateCacheKey(e.cacheKey), d.default.registerEvent("openAdSpuDetailEvent", (function(e) {
              t.openAdvertiseSpuDetail(e)
            })), d.default.registerEvent("universalLogin-uniLoginSuccess", i(r.default.mark((function e() {
              return r.default.wrap((function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, t.handleLoad(t.urlParams);
                  case 2:
                  case "end":
                    return e.stop()
                }
              }), e)
            })))), a.next = 14, t.handleLoad(e);
          case 14:
          case "end":
            return a.stop()
        }
      }), a)
    })))()
  },
  checkWeiQian: function(e) {
    var t = e.tenantId;
    if (Number(t) === de.WEI_QIAN_TANENT_ID) {
      var a = F.default.stringify(e);
      s.default.setMenuOps(a)
    }
  },
  saveUrlParameters: function(e) {
    this.setData({
      options: e,
      hasEnoughOptions: (0, D.hasEnoughOptions)(e)
    }), this.checkWeiQian(e), this.urlParams = e, this.setUrlParams(e), this.options = e
  },
  optionsGuard: function(e) {
    return !this.checkOldPerception(e)
  },
  checkOldPerception: function(e) {
    var t = e.p,
      a = e.q;
    if (t || a) {
      var n = F.default.stringify(e, !1);
      return this.loadFail(Z.FAIL_REASON.OLD_PERCEPTION), F.default.redirectTo({
        url: "/pages/splash/index?" + n
      }), !0
    }
    return !1
  },
  onShow: function() {
    var e = this;
    return i(r.default.mark((function t() {
      var a;
      return r.default.wrap((function(t) {
        for (;;) switch (t.prev = t.next) {
          case 0:
            if ((0, N.sendPV)("c_saaspay_gzi8cqe9"), e.showTakeCouponTips = !1, e.saveWMCloudData = !1, e.isFirstEnterPage) {
              t.next = 8;
              break
            }
            if (e.setData({
                errorInfo: null
              }), a = Object.assign(e.options, {}), a = (0, x.getTabbarPageOptions)({}, e.route, a), e.saveUrlParameters(a), (0, O.setTabbarPageParams)(e.route, a), !e.checkOldPerception(a)) {
              t.next = 5;
              break
            }
            return t.abrupt("return");
          case 5:
            return e._updateCacheKey(e.options.cacheKey), t.next = 8, e.handleLoad(e.urlParams);
          case 8:
            e.searchBannerOpacity && d.default && d.default.setModuleData("menu-shop-info", {
              searchBannerOpacity: e.searchBannerOpacity
            });
          case 9:
          case "end":
            return t.stop()
        }
      }), t)
    })))()
  },
  onReady: function() {
    var e = (0, O.getNewApp)();
    try {
      if (!e.isHide) {
        var t = Date.now() - e.report.launchTimeFromScan;
        z.default.addPerformance(m.RAPTOR_PERFORMANCE.MP.APP_READY, t)
      }
    } catch (e) {}
    this.updateMpUserInfo()
  },
  updateComponentsScrollTop: function() {
    var e = this,
      t = this.createSelectorQuery(),
      n = this.data.categoryStickyTop,
      r = ne.FIXED_HEAD_POSITION_MP;
    t.select(".container >>> .common-head-fixed").boundingClientRect(), t.select(".container >>> .top-sticky-container").boundingClientRect(), t.select(".container >>> .menu-detail").boundingClientRect(), t.selectViewport().scrollOffset(), t.exec((function(t) {
      if (Array.isArray(t)) {
        var i = a(t, 4),
          o = i[0],
          s = void 0 === o ? {} : o,
          u = i[1],
          l = i[2],
          c = void 0 === l ? {} : l,
          p = i[3].scrollTop || 0;
        s && s.height && (r = s.height, e.setData({
          categoryStickyTop: r
        }));
        var h = u || {},
          f = h.top,
          m = h.height;
        f && m && (f !== r && (e.stickyContainerScrollHeight = p + f - r), n = r + u.height, e.setData({
          categoryStickyTop: n
        }), d.default.setModuleData("top-sticky-container", {
          offsetTop: r
        })), c && c.top && (e.menuDetailScrollHeight = p + c.top - n)
      }
    }))
  },
  sendFstScanDuration: function() {
    var e, t = (0, O.getNewApp)();
    this.isFirstEnterPage && this.loadSuccess("recycleList"), this.urlParams.perceptionPage && ((0, ie.sendSplashMenuFmpDuration)(null == (e = t.report) ? void 0 : e.splashLoadTime), t.report.splashLoadTime = -1)
  },
  initLimoData: function(e, t) {
    var a = this;
    return i(r.default.mark((function n() {
      var i;
      return r.default.wrap((function(n) {
        for (;;) switch (n.prev = n.next) {
          case 0:
            return a.pageViewModel = new j.MpPageViewModel({
              pageInstance: a,
              Limo: d.default.getLimoRuntime(),
              options: a.urlParams
            }), i = a.urlParams.shopId, n.next = 4, J.default.initDealCoupons(i, a.pageViewModel, t);
          case 4:
            return n.abrupt("return", a.pageViewModel.getMenuViewModel(e));
          case 5:
          case "end":
            return n.stop()
        }
      }), n)
    })))()
  },
  _updateCacheKey: function(e) {
    e && (0, O.setCloudDataCacheKey)(e)
  },
  checkPointPurchase: function(e) {
    var t;
    null != e && null != (t = e.pointBuyCampaign) && t.campaignAndSkuRelations && this.setPointPurchase(e.pointBuyCampaign.campaignAndSkuRelations)
  },
  _initPageShow: function(e) {
    var t = this;
    return i(r.default.mark((function a() {
      var o, u, p, m, g, T, P, I, C, E, _, S, v, y, A, w, L, M, k, R, b, N, q, U, B, H, Y, G, V, K, j, J, $, ee, te, ae, ne, re, oe, ue, de, le, ce, pe, he, fe, me, ge, Te, Pe, De, Ie, Ce, Ee, _e, Se, ve, ye, Ae, we, Le, Me, ke;
      return r.default.wrap((function(a) {
        for (;;) switch (a.prev = a.next) {
          case 0:
            if (P = Date.now(), I = (0, ie.sendInitPageToRequestStart)(P), C = e.bizType, E = e.authGeo, e.reserveMode, a.t0 = (0, f.isTakeAwayOrSelfPick)(C) || E === se.URLParams.AuthGeo.REQUIRED, !a.t0) {
              a.next = 5;
              break
            }
            return a.next = 5, (0, l.transaction)("MENU.getLocation", i(r.default.mark((function e() {
              return r.default.wrap((function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, (0, D.getLocationInfo)({
                      canUseSessionCache: !0,
                      defaultTimeout: 5e5,
                      showAuthSettingDialog: !1
                    });
                  case 2:
                    (_ = e.sent) && t.setData({
                      location: _
                    });
                  case 4:
                  case "end":
                    return e.stop()
                }
              }), e)
            }))));
          case 5:
            return a.next = 7, (0, W.getMainData)(n(n({}, e), _ ? {
              userGeoPoint: _
            } : {}));
          case 7:
            if ((S = a.sent) !== Q.ResponseState.REDIRECT) {
              a.next = 10;
              break
            }
            return a.abrupt("return", void t.loadFail(Z.FAIL_REASON.REDIRECT));
          case 10:
            if (v = S.pageTitle, y = S.memberInfo, A = S.localHeadInfo, w = S.spuDetail, L = S.errorTips, M = S.spuPromise, k = S.moduleData, R = S.moduleSortList, b = S.userInfo, N = S.orderProductionProcessVO, q = (0, ie.sendRequestStartToRequestEnd)(I), B = (U = null != A ? A : {}).shopConfig, H = U.shopInfo, Y = U.fmpBizData, V = (G = null != Y ? Y : {}).recSceneFlag, K = G.shopCache, j = G.showCouponPackage, J = void 0 !== j && j, $ = (0, D.getCompleteParameters)({
                shopConfig: B,
                fmpBizData: Y,
                oldParameter: e
              }), t.checkPointPurchase(Y), t.saveUrlParameters($), (0, O.setTabbarPageParams)(t.route, $), !t.isDestroy) {
              a.next = 13;
              break
            }
            return a.abrupt("return");
          case 13:
            if (!L) {
              a.next = 15;
              break
            }
            return a.abrupt("return", void t.dealErrorInfo(L));
          case 15:
            if (A) {
              a.next = 17;
              break
            }
            return a.abrupt("return", void t.dealErrorInfo({
              errorType: Z.FAIL_REASON.EMPTY_HEAD,
              errorMsg: "localHeadInfo为空"
            }));
          case 17:
            return ee = t.loadTabBar($), te = ee.isVirtualTabbar, ae = void 0 !== te && te, ne = t.urlParams, re = ne.shopId, oe = ne.tableNum, ue = ne.spuId, de = ne.cacheKey, t._updateCacheKey(de), t.localHeadInfo = A, (0, x.setNavigationBarTitle)({
              title: v
            }, "/menu/"), (0, D.saveLocationInfo)({
              bizType: C,
              cacheKey: de,
              location: t.data.location
            }), z.default.setAsyncOptions("shopId", re), (0, W.clearLastShopInfo)($), t.setExtraInfo(re, A), t.updateBaseInfo(re, oe), (0, W.showMemberLoginToast)(y), (0, W.saveCardInfo)(re, y), null !== V && s.default.setRecSceneFlag(!!V), K && s.default.setShopCache(K), ce = (le = B || {}).menuStyle, pe = le.spuMatchRecommendPages, he = le.mtShopId, me = (fe = ce || {}).dishShowType, ge = void 0 === me ? 0 : me, Te = fe.spuComboShowType, Pe = void 0 === Te ? 0 : Te, De = ge > 0 && ge !== c.DISH_SHOW_TYPE.RIGHT_LARGE, Ie = 1, ge === c.DISH_SHOW_TYPE.TWO_IN_ROW ? Ie = 2 : ge === c.DISH_SHOW_TYPE.THREEE_IN_ROW && (Ie = 3), Ee = (Ce = H || {}).groupCouponInfo, _e = Ce.shopMarketings, ve = (Se = Ee || {}).showMTBind, ye = Se.dealCoupons, Ae = Se.mtUserName, we = (0, ie.sendRequestEndToDataStart)(q), a.next = 32, t.initLimoData({
              moduleData: k,
              moduleSortList: R,
              progressInfo: N
            }, ye);
          case 32:
            Le = a.sent, t.showTakeCouponTips && k && (0, D.showTakeCouponTipsHandle)(k, y, (function() {
              t.showTakeCouponTips = !1
            })), (Me = null == k || null == (o = k["menu-shop-info"]) || null == (o = o.data) ? void 0 : o.waiMaiConfig) && t.updateTakeawayConfigInfo(Me.takeAwayDeliveryFeeRule), ke = {
              limoMenuData: Le,
              userInfo: b,
              memberInfo: y,
              actionUrl: null == y ? void 0 : y.actionUrl,
              pageTitle: v,
              horizontal: De,
              showMTBind: ve,
              mtUserName: Ae,
              spuMatchRecommendPages: pe,
              column: Ie,
              recycleWinWidth: (0, X.transformRpxToNumber)(c.MENU_PAGE_INIT_CONFIG["INIT_".concat(h.DISH_ITEM_TYPE_MAP[ge], "_RECYCLE_VIEW_WIDTH")]),
              spuComboShowType: Pe,
              menuUpdateTime: Date.now(),
              currentShopId: he,
              showCouponPackage: "false" !== (null == ce || null == (u = ce.feConfig) ? void 0 : u.showPayCouponPackage) && J,
              payCouponDecoInfo: {
                couponPageSize: (null == ce || null == (p = ce.feConfig) ? void 0 : p.couponPageSize) && Number(null == ce || null == (m = ce.feConfig) ? void 0 : m.couponPageSize),
                payCouponPackageShowImgUrl: null == ce || null == (g = ce.feConfig) ? void 0 : g.payCouponPackageShowImgUrl,
                sizeScale: null == ce || null == (T = ce.feConfig) ? void 0 : T.couponPageSizeScale
              },
              shopMarketings: _e
            }, (0, l.transaction)("MENU.SET_DATA.SHOP_INFO", function() {
              var e = i(r.default.mark((function e(a) {
                return r.default.wrap((function(e) {
                  for (;;) switch (e.prev = e.next) {
                    case 0:
                      t.setData(ke, (function() {
                        a.success(), t.isFirstEnterPage && t.loadSuccess("shopInfo"), (0, ie.sendElseMenuListRenderDuration)(we), F.default.isByteDanceMicroApp ? setTimeout((function() {
                          t.updateComponentsScrollTop()
                        }), 200) : t.updateComponentsScrollTop(), d.default && d.default.setModuleData("menu-shop-info", {
                          isVirtualTabbar: ae
                        })
                      }));
                    case 1:
                    case "end":
                      return e.stop()
                  }
                }), e)
              })));
              return function(t) {
                return e.apply(this, arguments)
              }
            }(), !0), t.checkNewAdvanceToast(), t.popUpDetailPanel(ue), t.isFirstEnterPage ? t.dealRenderList(w, M) : t.updateMenuList(M);
          case 38:
          case "end":
            return a.stop()
        }
      }), a)
    })))()
  },
  dealRenderList: function(e, t) {
    var a = !!t,
      n = this.localHeadInfo,
      r = n.categories,
      i = n.shopConfig,
      o = n.memberInfo,
      s = n.shopInfo,
      u = n.fmpBizData,
      d = null == i ? void 0 : i.menuStyle,
      l = !(null == o || !o.cardId),
      p = d || {},
      f = p.recommendShowType,
      m = void 0 === f ? c.BOSS_DISH_SHOW_TYPE.DEFAULT : f,
      g = p.dishShowType,
      T = void 0 === g ? 0 : g,
      D = p.menuType,
      I = void 0 === D ? 0 : D,
      C = (null == s ? void 0 : s.shopMarketings) || [],
      E = u.pointBuyCampaign,
      _ = (0, P.getPluginActivityToCategory)(r, C, e),
      S = (0, P.generateCategoryList)(a, {
        categories: _,
        dishShowType: T,
        list: e,
        cartList: this.data.cartDishList,
        isLogin: l
      }),
      v = (0, P.categoryListHasIcon)(S),
      y = h.DISH_ITEM_TYPE_MAP[T] || h.DISH_ITEM_TYPE_VAL.DEFAULT,
      A = (0, B.generateDishList)(a, {
        categories: S,
        list: e,
        dishShowType: y,
        cartList: this.data.cartDishList,
        menuStyle: d,
        pointBuyCampaign: E
      });
    this.setData({
      menuType: I,
      categoriesList: S,
      categoryHasIcon: a ? r.some((function(e) {
        return !!e.categoryMultimediaList
      })) : v,
      dishShowType: y,
      recommendShowType: m
    }), t || (this.realCategoryCount = (null == A ? void 0 : A.length) || 0), this.renderDishList(A, t)
  },
  renderDishList: function(e, t) {
    var a = this;
    this.renderStartTime = this.isFirstEnterPage ? Date.now() : 0;
    var n = (0, B.sliceDataTransfer)(e),
      r = 0;
    n.forEach((function(e) {
      a.setData(e, (function() {
        r++, a.isFirstSet && (a.sendFstScanDuration(), (0, ie.sendMenuListRenderDuration)(a.renderStartTime), (0, re.setFmpMenuListSuccess)(), a.isFirstSet = !1), r === n.length && (a.updateMenuList(t), a.removeExtraCategories())
      }))
    }))
  },
  removeExtraCategories: function() {
    if (this.realCategoryCount > 0 && this.data.allDishList.length > this.realCategoryCount)
      for (var e = this.realCategoryCount; e < (null == (a = this.data.allDishList) ? void 0 : a.length); e++) {
        var a;
        this.setData(t({}, "allDishList[".concat(e, "]"), null))
      }
  },
  updateMenuList: function(e) {
    var t = this;
    return i(r.default.mark((function a() {
      var n, i, o, u, l, p, h, f, m, g, T;
      return r.default.wrap((function(a) {
        for (;;) switch (a.prev = a.next) {
          case 0:
            if (e) {
              a.next = 2;
              break
            }
            return a.abrupt("return", (d.default && d.default.setModuleData("recommendation-module", {
              menuUpdateTime: Date.now()
            }), t.isFirstEnterPage && (0, ie.sendLVC)(t.pageLoadTime), void t.setData({
              showFullLoading: !1,
              finishSetDishList: !0
            })));
          case 2:
            return n = t.urlParams, i = n.shopId, o = n.tenantId, u = n.mandatoryPrompt, l = t.localHeadInfo, p = l.shopConfig, h = l.shopInfo, a.prev = 3, a.next = 6, (0, W.getAllSpuWithCache)(t.urlParams, e);
          case 6:
            f = a.sent, a.next = 12;
            break;
          case 9:
            a.prev = 9, a.t0 = a.catch(3), z.default.addError("全量菜品网络异常", a.t0);
          case 12:
            if (f) {
              a.next = 14;
              break
            }
            return a.abrupt("return", void t.dealErrorInfo({
              errorType: Z.FAIL_REASON.ALL_DISH_FAIL,
              errorMsg: c.DEFAULT_ERROR_TITLE
            }));
          case 14:
            g = (m = p || {}).mandatoryInfos, T = m.cartConfig, t.setDishList(i, f), s.default.setUseMenuCacheForNonMenuPage(i, !0), t.initNewCart(g, f, null == T ? void 0 : T.openTogether, decodeURIComponent(null != u ? u : "")), t.dealRenderList(f, null), J.default.showMTAccountToast(h, s.default.getGrouponCouponList(i)), t.shopHomeShare(i, o), (0, W.initUser)();
          case 16:
          case "end":
            return a.stop()
        }
      }), a, null, [
        [3, 9]
      ])
    })))()
  },
  dealErrorInfo: function(e) {
    var t = e || {},
      a = t.errorType,
      n = t.errorMsg;
    this.getSelectedPageType(), (0, re.menuLoadFailPoint)({
      errorType: a,
      errorMsg: n
    }), this.loadFail(a);
    var r = (0, R.getErrPageInfo)(a),
      i = a === $.ERROR_TYPE.NEED_DOWNGRADE_CODE ? a : $.ERROR_TYPE.NEED_RELOAD,
      o = "",
      s = a === $.ERROR_TYPE.NEED_DOWNGRADE_CODE ? "去点餐" : "重新加载";
    r.type && (i = r.type, o = r.url, s = r.btnText), this.setData({
      errorInfo: {
        errorTitle: n,
        btnConfig: {
          buttonText: s
        },
        redirectUrl: o || "",
        type: i
      }
    })
  },
  handleErrorClick: function() {
    var e = this.data.errorInfo || {},
      t = e.type,
      a = e.redirectUrl;
    switch (+t) {
      case $.ERROR_TYPE.NEED_DOWNGRADE_CODE:
        var n = (0, te.getCurrentPagePath)();
        return void this.openIndependentApplets(n);
      case $.ERROR_TYPE.CUSTOM_JUMP:
        return void F.default.redirectTo({
          url: a
        });
      case $.ERROR_TYPE.NEED_RELOAD:
      default:
        var r = ((0, R.getTakeawayUrlParams)() || {}).multiShop;
        (0, te.customReLaunch)("menu", {
          multiShop: r
        })
    }
  },
  openIndependentApplets: function(e) {
    var t = "develop" === (0, ee.checkEnv)() ? "wx06a469c9bcc9f1ea" : "wx1fde2c33280d64b6";
    d.default.getLimoRuntime().navigateToMiniProgram({
      appId: t,
      path: e,
      extraData: {},
      envVersion: (0, ee.checkEnv)(),
      success: function(e) {},
      fail: function(e) {
        z.default.addError("小程序打开失败", e)
      }
    })
  },
  checkNewAdvanceToast: function() {
    var e = this.urlParams,
      t = e.orderBizTag,
      a = e.hasOrder; + t === c.ORDER_BIZ_TAG.AHEAD && "true" === a && F.default.showToast({
      icon: "none",
      title: "该桌台有订单，请您联系服务员或更换桌台用餐",
      duration: 3e3
    })
  },
  shopHomeShare: function(e, t) {
    var a = this;
    return i(r.default.mark((function n() {
      var i, o, s, u, l, p;
      return r.default.wrap((function(n) {
        for (;;) switch (n.prev = n.next) {
          case 0:
            return i = a.urlParams, o = Number(i.bizType), s = o === c.BIZ_TYPE_MAP.PICKUP || o === c.BIZ_TYPE_MAP.TAKEAWAY ? o : Number(i.reserveMode) ? c.SHARE_INFO_SOURCE.PRE_ORDER : c.SHARE_INFO_SOURCE.ORDER, u = {
              containerName: "shop-share-config",
              previewFlag: !1,
              bizId: e,
              bizIdType: "10",
              tenantId: t,
              sharePageSource: s
            }, n.prev = 3, n.next = 6, V.default.getShopHomeShare(u);
          case 6:
            l = n.sent, p = l.shareMsg, l.shareSwitch ? a.shareMsg = p : d.default.getLimoRuntime().hideShareMenu({
              menus: ["shareAppMessage"]
            }), n.next = 14;
            break;
          case 12:
            n.prev = 12, n.t0 = n.catch(3);
          case 14:
          case "end":
            return n.stop()
        }
      }), n, null, [
        [3, 12]
      ])
    })))()
  },
  onShareAppMessage: function(e) {
    var t, a = ((null == e || null == (t = e.target) ? void 0 : t.dataset) || {}).species;
    return "button" === (null == e ? void 0 : e.from) && a === c.DISH_SHARE_TYPE ? this.dishShareInfo : this.shareMsg
  },
  getSpuById: function(e) {
    var t = this.urlParams.shopId;
    if (!e || !t) return null;
    var a = s.default.getDishList(t);
    return a ? a[e] : null
  },
  updateMpUserInfo: function() {
    var e = (0, Y.getUserInfo)(),
      t = e.nickname,
      a = e.headimgurl;
    this.setMpUserInfo({
      nickname: t,
      headimgurl: a
    })
  },
  popUpDetailPanel: function(e) {
    var t = this.getSpuById(e),
      a = (0, H.dealPreventSale)(t) || !t && e;
    !this.data.alreadyPopup && e && (a ? F.default.showToast({
      icon: "none",
      title: "菜品已售完, 看看其他菜品吧~",
      duration: 3e3
    }) : this.menuDetail({
      detail: t
    }), this.setData({
      alreadyPopup: !0
    }))
  },
  menuDetail: function(e) {
    var t, a, r, i, o, u, d, l = e.detail;
    if (l) {
      var h = l.spuId,
        f = this.urlParams.shopId,
        m = null == (t = (s.default.getExtraInfo(f) || {}).shopInfo) || null == (t = t.recommendInfos) || null == (t = t.boss) ? void 0 : t.title;
      this.openDishDetail(n(n({}, l), {}, {
        reportConfig: n(n(n({}, l.reportConfig || {}), l.__reportConfig__ || {}), {}, {
          bossRecommendText: m,
          dishType: l.dishType,
          spuName: l.spuName,
          adFrom: T.EXPOSE_DISH_TYPE.BOSSRECOMMEND,
          spuId: h,
          skuId: l.skuMenuItems ? null == (a = l.skuMenuItems[0]) ? void 0 : a.skuId : 0
        })
      }));
      var g = {
          op_type: p.OP_TYPE.RECOMMEND_DISH,
          op_name: null != (r = l.__reportConfig__) && r.fromNetRecommend ? p.OP_NAME.RECOMMEND_NET : p.OP_NAME.RECOMMEND_BOSS,
          sn: null == (i = l.__reportConfig__) ? void 0 : i.index,
          show_title: null != (o = l.__reportConfig__) && o.fromNetRecommend ? c.TITLE_CONTENT.NET : c.TITLE_CONTENT.BOSS,
          spu_id: h,
          skuId: null == l || null == (u = l.skuMenuItems[0]) ? void 0 : u.skuId
        },
        P = n({}, g);
      null != (d = l.__reportConfig__) && d.fromNetRecommend || (P = n(n({
        is_defined_title: m ? 1 : 0
      }, g), {}, {
        show_title: m
      })), (0, N.sendMC)("b_saaspay_hlznku1a_mc", null, null, {
        clickData: n({}, P)
      })
    }
  },
  addDishFuncMenu: function(e) {
    var t = e.detail,
      a = (0, E.transToSkuDish)(t, this.data.cartDishList);
    this.addDish(a)
  },
  onClickCountNum: function(e) {
    var t = e.detail,
      a = (0, E.transToSkuDish)(t, this.data.cartDishList);
    this.showCalcPanel(a)
  },
  minusDishFuncMenu: function(e) {
    var t = e.detail,
      a = (0, E.transToSkuDish)(t, this.data.cartDishList);
    this.minusDish(a)
  },
  expandShopInfo: function(e) {
    var t = e.detail.showShopFlag;
    this.setData({
      expandedShopInfo: t,
      isShowToastFromMTLogin: !1
    })
  },
  hidePanel: function() {
    this.toggleRegisterPanelAction(!1), this.toggleContainerPanelAction(!1), this.setAddOnShow(!1), this.closeTakeCouponPanel()
  },
  onHide: function() {
    this.isFirstEnterPage = !1, (0, ie.updateIsFirstEnter)(this.isFirstEnterPage), this.hidePanel(), this.updateCloudCacheCartData(), this.saveWMCloudData = !0
  },
  onUnload: function() {
    this.isDestroy = !0, this.hidePanel(), this.saveWMCloudData || this.updateCloudCacheCartData(), F.default.hideLoading()
  },
  showPanelType: function(e) {
    var t = e.detail,
      a = t.operationData,
      r = void 0 === a ? {} : a,
      i = t.skuId,
      o = void 0 === i ? "" : i,
      s = t.__newReportConfig__,
      u = t.exposeDishType,
      d = void 0 === u ? "" : u,
      l = t.menuReportConfig,
      c = r.panelType,
      p = r.id,
      f = r.reportConfig,
      m = r.discount,
      g = void 0 === m ? "" : m;
    if (c && p) {
      var T = {
        reportConfig: n(n({}, l || {}), f)
      };
      switch (this.updateCurrentDishId({
          currentSpuId: p,
          currentSkuId: o,
          containerOpenExtraData: T,
          __newReportConfig__: s,
          currentDiscount: g
        }), this.toggleContainerPanelAction(!0), this.setDishAddFromAction(d), c) {
        case h.PANEL_TYPE_VAL.SPEC:
          oe.PanelTransaction.init(oe.PANEL_TYPE.MULTI_PANEL);
          break;
        case h.PANEL_TYPE_VAL.PACKAGE:
          oe.PanelTransaction.init(oe.PANEL_TYPE.PACKAGE_PANEL);
          break;
        case h.PANEL_TYPE_VAL.WEIGHT:
          oe.PanelTransaction.init(oe.PANEL_TYPE.CALCULATOR_PANEL)
      }
    }
  },
  showDishPanel: function(e) {
    var t, a, r, i, o = e.detail.dish.spuId,
      u = e.detail.isFirstScreen,
      d = e.detail.dish,
      l = this.getSpuById(o);
    if ((0, N.sendMC)("b_saaspay_hlznku1a_mc", null, null, {
        tab_id: d.categoryId,
        dishes_id: d.spuId,
        dishes_name: d.name,
        dishes_price: Number(d.currentPrice),
        dishes_status: l.soldOut ? 1 : l.canSaleNow ? 0 : void 0
      }), l && d) {
      var c = this.urlParams.shopId,
        h = s.default.getExtraInfo(c),
        f = null == h || null == (t = h.shopInfo) || null == (t = t.recommendInfos) || null == (t = t.boss) ? void 0 : t.title;
      this.openDishDetail(n(n({}, l), {}, {
        reportConfig: n(n(n({}, d.reportConfig || {}), d.__reportConfig__ || {}), {}, {
          bossRecommendText: f,
          dishType: d.dishType || l.dishType,
          spuName: d.spuName || l.spuName,
          adFrom: T.EXPOSE_DISH_TYPE.DISHLIST,
          spuId: o,
          skuId: d.skuMenuItems ? null == (a = d.skuMenuItems[0]) ? void 0 : a.skuId : 0,
          categoryId: d.categoryId,
          isFirstScreen: u
        })
      })), oe.PanelTransaction.init(oe.PANEL_TYPE.DISH_DETAIL_PANEL);
      var m, g = p.OP_NAME.OTHER;
      g = d.categoryId > 0 ? p.OP_NAME.RECOMMEND_CLASS : p.OP_NAME.RECOMMEND_DISH, m = null == (r = d.__reportConfig__) || null == (r = r.belongCategory) ? void 0 : r.parentName, (0, N.sendMC)("b_saaspay_hlznku1a_mc", null, null, {
        clickData: {
          op_type: p.OP_TYPE.RECOMMEND_CLASS,
          op_name: g,
          show_title: m,
          spu_id: o,
          sn: null == (i = d.__reportConfig__) ? void 0 : i.index
        }
      })
    }
  },
  addToCartCoupon: function(e) {
    var t = this,
      a = e.detail.dish,
      n = a.spuId,
      r = a.skuId,
      i = a.count;
    J.default.autoUseCouponAddToCart(n, r, i, (function() {
      t.addToCart(a)
    }), (function() {
      t.addToCart(a)
    }))
  },
  operateCartDish: function(e) {
    var t = this,
      a = e.detail,
      n = a.type,
      r = a.id,
      i = a.showCal,
      s = void 0 !== i && i,
      u = a.skuId,
      d = void 0 === u ? "" : u,
      l = a.discount,
      p = void 0 === l ? "" : l,
      f = this.getSpuById(r);
    if (f) {
      var m = !(p !== h.POINT_DISH_TYPE),
        g = (0, E.transToSkuDish)(f, this.data.cartDishList, d, m);
      if (g) {
        if (s) return this.updateCurrentDishId({
          currentSpuId: r,
          currentDiscount: p
        }), this.toggleContainerPanelAction(!0), this.updateCalculator({
          isShowCountCalc: !0
        }), void this.updateEditSkuDishAction({
          editDishSpuId: g.spuId,
          editDishGoodsNo: g.goodsNo
        });
        if ("plus" === n) {
          if (m) return void this.pointPurchaseAdd(g);
          J.default.autoUseCouponAddToCart(g.spuId, g.skuId, 1, (function() {
            t.addDish(g)
          }), (function(e) {
            if (e.dishType === c.DISH_TYPE.PACKAGE)(0, I.judgeFixedPackage)(e) ? t.addFixedPackage(e, t.data.refactorLocalCart) : (t.updateCurrentDishId({
              currentSpuId: e.spuId
            }), t.toggleContainerPanelAction(!0));
            else if ((0, I.judgeComplexSpuDish)(e)) t.updateCurrentDishId({
              currentSpuId: e.spuId
            }), t.toggleContainerPanelAction(!0);
            else {
              var a = o.default.getIn(e, ["skuMenuItems", 0]);
              t.addDish(a)
            }
          }))
        } else "minus" === n && this.minusDish(g)
      }
    }
  },
  tabBarRenderFn: function(e) {
    var t = e.detail.tabBarList,
      a = void 0 === t ? [] : t;
    !this.data.hasTabBar && a.length && (d.default && d.default.setModuleData("menu-shop-info", {
      isVirtualTabbar: !0
    }), this.setData({
      hasTabBar: !0
    }));
    var n = this.data.requestParams.params || {},
      r = n.restaurantViewId,
      i = void 0 === r ? "" : r,
      o = n.mtShopId,
      u = void 0 === o ? "" : o;
    (i || u) && s.default.setTabBarData(i || u, a)
  },
  openAdvertiseSpuDetail: function(e) {
    var t = e.exposeDishType,
      a = e.adType,
      r = e.spu,
      i = e.reportConfig;
    if (this.setDishAddFromAction(t), a === c.AD_TYPE.SPU) {
      if (!r) return;
      this.openDishDetail(n(n({}, r), {}, {
        reportConfig: i
      }))
    }
  },
  showDishTimeInfoModalFn: function(e) {
    var t = e.detail.spuId;
    this.showDishTimeInfoModal(t)
  },
  dishTimeInfoModalEvent: function() {
    this.toggleDishInfoModal(!1)
  },
  gotoThirdLogin: function() {
    this.pageViewModel.gotoThirdLoginClick()
  },
  useGrouponCoupon: function(e) {
    var t, a = this,
      n = e.detail || {},
      r = n.discountTempId,
      i = n.spuId,
      u = n.skuId;
    if (r && i && u) {
      var d = this.urlParams.shopId,
        l = s.default.getDishList(d);
      if (l) {
        var p = l[i],
          h = null == p || null == (t = p.skuMenuItems) ? void 0 : t.find((function(e) {
            return e.skuId === u
          }));
        J.default.addGrouponCouponDishToCart([r], p, h, !1, (function(e) {
          if (e.dishType === c.DISH_TYPE.PACKAGE)(0, I.judgeFixedPackage)(e) ? a.addFixedPackage(e, a.data.refactorLocalCart) : (a.updateCurrentDishId({
            currentSpuId: e.spuId
          }), a.toggleContainerPanelAction(!0));
          else if ((0, I.judgeComplexSpuDish)(e)) a.updateCurrentDishId({
            currentSpuId: e.spuId
          }), a.toggleContainerPanelAction(!0);
          else {
            var t = o.default.getIn(e, ["skuMenuItems", 0]);
            a.addDish(t)
          }
        }))
      }
    }
  },
  cancelGrouponCoupon: function(e) {
    var t = e.detail || {},
      a = t.discountTempId,
      n = t.spuId,
      r = J.default.cancelDealCoupon(a);
    r && this.minusCartGrouponDish(n, r)
  },
  closeTakeCouponPanel: function() {
    this.showTakeCouponPanelAction({
      takeCouponPanelTag: !1
    })
  },
  openCouponPanel: function(e) {
    this.showTakeCouponPanelAction({
      takeCouponPanelTag: !0,
      sourceType: e.detail.from
    })
  },
  handleTakeCoupon: function() {
    var e = this;
    return i(r.default.mark((function t() {
      return r.default.wrap((function(t) {
        for (;;) switch (t.prev = t.next) {
          case 0:
            return e.showTakeCouponTips = !0, t.next = 3, e._initPageShow(e.urlParams);
          case 3:
          case "end":
            return t.stop()
        }
      }), t)
    })))()
  },
  updateDishList: function(e) {
    var t = e.detail.categoryId,
      a = (0, B.getSetObj)(this.data.allDishList, t, this.data.dishShowType);
    this.setData(a)
  },
  modifyDishList: function(e) {
    var t = e.detail.modifyObj;
    t && this.setData(t)
  },
  selectedAddressFn: function(e) {
    var t = e.detail.address;
    this.selectAddress(t)
  },
  handleAddNewAddressFn: function() {
    var e = this.localHeadInfo.fmpBizData,
      t = (void 0 === e ? {} : e).addressPageUrl,
      a = void 0 === t ? "" : t;
    a && F.default.navigateTo({
      url: a
    })
  },
  closeAddressListModal: function() {
    this.setAddressListModalFlag(!1)
  },
  getUserAddressList: function() {
    this.getUserAddressList()
  },
  updateAddressFn: function(e) {
    var t = e.detail.addressList,
      a = void 0 === t ? [] : t;
    this.setUserAddressList(a)
  },
  toggleShop: function(e) {
    var t = e.detail.bizType;
    (0, R.viewOtherShop)(t)
  },
  switchBiz: function(e) {
    var t = this;
    return i(r.default.mark((function a() {
      var n, i, o, s;
      return r.default.wrap((function(a) {
        for (;;) switch (a.prev = a.next) {
          case 0:
            return n = e.detail.bizTypeStatus, t.clearCart(), i = t.localHeadInfo.fmpBizData, o = (void 0 === i ? {} : i).addressPageUrl, s = void 0 === o ? "" : o, a.next = 5, (0, R.switchBiz)(n, s);
          case 5:
          case "end":
            return a.stop()
        }
      }), a)
    })))()
  },
  updatePickUpDistanceFn: function() {
    this.updatePickUpDistance()
  },
  onTapTipsBannerButton: function(e) {
    var t = this;
    return i(r.default.mark((function a() {
      return r.default.wrap((function(a) {
        for (;;) switch (a.prev = a.next) {
          case 0:
            return a.next = 2, (0, D.handleTapTipsBannerButton)({
              event: e,
              onGotLocation: function(e) {
                t.urlParams.authGeo !== se.URLParams.AuthGeo.REQUIRED && t.saveUrlParameters(n(n({}, t.urlParams), {}, {
                  authGeo: se.URLParams.AuthGeo.REQUIRED
                })), t.setData({
                  location: e
                }), t._initPageShow(t.urlParams)
              },
              Limo: d.default
            });
          case 2:
          case "end":
            return a.stop()
        }
      }), a)
    })))()
  },
  closeOrderProgress: function() {
    s.default.setOrderProgress(this.urlParams.shopId)
  },
  updatePrePriceTipsFn: function() {
    this.data.showPrePriceTips && this.updatePrePriceTips(!1)
  }
}), U.plugins);