var e = require("../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.default = void 0;
var r = require("../b/helpers/objectSpread2"),
  t = e(require("../lib/mix/request")),
  u = {
    getShopPickUpConfig: function(e) {
      return t.default.post("/querySelfPickUpConfig", r({}, e))
    },
    getClosestShop: function(e, r) {
      return t.default.get("/v2/preferredShop", {
        params: e,
        headers: {
          "x-biz-type": r
        }
      })
    }
  };
exports.default = u;