var e = require("../../../../b/helpers/objectSpread2"),
  t = require("../../../@limo/container/behaviors/index"),
  r = require("../../limo-common/biz-constants/index");
Component({
  behaviors: [t.commonBehavior, t.limoShim],
  properties: {
    groups: {
      type: Object,
      value: {},
      observer: function(t) {
        Object.keys(t).length && this.setData(e({}, t))
      }
    }
  },
  data: {
    tasteMaxBoughtCount: r.SINGLE_CHOICE,
    tasteSingleChoice: r.TASTE_REPEAT_CHOICE.SINGLE
  },
  methods: {
    minusTasteHandle: function(e) {
      var t = e.currentTarget.dataset || e.currentTarget,
        r = t.valId,
        a = t.groupId;
      this.triggerEvent("minusTasteClick", {
        id: r,
        groupId: a
      })
    },
    addMultiTasteHandle: function(e) {
      var t = e.currentTarget.dataset || e.currentTarget,
        r = t.valId,
        a = t.groupId;
      t.mutex || this.triggerEvent("addMultiTasteClick", {
        id: r,
        groupId: a
      })
    },
    btnClickFn: function(e) {
      var t = e.currentTarget.dataset || e.currentTarget,
        r = t.valId,
        a = t.groupId,
        i = t.selected;
      t.mutex || this.triggerEvent("groupBtnClick", {
        id: r,
        groupId: a,
        selected: i
      })
    },
    mutexClickFn: function(e) {
      var t = e.currentTarget.dataset,
        r = t.valId,
        a = t.mutex,
        i = t.groupId,
        n = t.type;
      a && this.triggerEvent("mutexClick", {
        id: r,
        groupId: i,
        type: +n
      })
    }
  }
});