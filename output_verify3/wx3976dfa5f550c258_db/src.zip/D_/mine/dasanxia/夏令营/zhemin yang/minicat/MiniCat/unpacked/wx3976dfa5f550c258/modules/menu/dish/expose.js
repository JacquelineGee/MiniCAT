var e = require("../../../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.exposeDishItemNew = exports.appendExposeDishItem = exports.EXPOSE_DISH_TYPE = void 0;
var t = require("../../../b/helpers/objectSpread2"),
  a = e(require("../../../miniprogram_npm/seamless-immutable/index.js")),
  s = require("../../../lib/env"),
  r = e(require("../../../miniprogram_npm/@mtfe/rms-triangle-c/index.js")),
  n = require("../../../lib/mix/util"),
  i = require("../../../constants/bizConstants"),
  E = require("./util"),
  u = e(require("../../../api/rmsStorage")),
  o = require("../../cartHelper"),
  l = require("../../LXHelper"),
  D = {
    CATEGORY: "CATEGORY",
    DISHLIST: "DISHLIST",
    SEARCHLIST: "SEARCHLIST",
    BOSSRECOMMEND: "BOSSRECOMMEND",
    DPRECOMMEND: "DPRECOMMEND",
    NETRECOMMENDPAGE: "NETRECOMMENDPAGE",
    ORDERRECOMMOND: "ORDERRECOMMOND",
    ORDERDISHLIST: "ORDERDISHLIST",
    CART: "CART",
    DISHDETAIL: "DISHDETAIL",
    BANNER: "BANNER",
    ADMODE: "ADMODE",
    MATCHRECOMMEND: "MATCHRECOMMEND",
    ADDON: "ADDON"
  };
exports.EXPOSE_DISH_TYPE = D;
var m = {};
Object.keys(D).forEach((function(e) {
  m[e] = []
}));
var p = "",
  S = null;

function O(e, t) {
  var s, l, m = (0, n.getMixUrlParam)("shopId");
  switch (e) {
    case D.CATEGORY:
    case D.ORDERDISHLIST:
      break;
    case D.DISHLIST:
    case D.BOSSRECOMMEND:
    case D.SEARCHLIST:
    case D.NETRECOMMENDPAGE:
    case D.ORDERRECOMMOND:
    case D.CART:
      var p = t.item && t.item.dishType === i.DISH_TYPE.NORMAL && !((0, o.judgeMultiDish)(t.item) || (0, o.judgeComplexSpuDish)(t.item)) && a.default.getIn(t.item, ["skuMenuItems", 0, "skuId"]);
      p || (p = t.item && t.item.skuId), t.spuId = (null == t || null == (s = t.item) ? void 0 : s.spuId) || t.spuId, t.skuId = p || "", t.spuName = (null == t || null == (l = t.item) ? void 0 : l.spuName) || t.spuName, t.hotSaleTag = (0, E.dealHotSaleTag)(t.item && t.item.hotSellingImgTag && t.item.hotSellingImgTag.type), -1 === t.recommendShowType || r.default.isNullOrUndefined(t.recommendShowType) || (t.recommendShowType = t.recommendShowType > 0 ? 1 : 0);
      var S = u.default.getExtraInfo(m),
        O = a.default.getIn(S, ["shopConfig", "menuStyle", "dishShowType"]) || 0;
      t.dishShowType = O
  }
  delete t.item
}
exports.appendExposeDishItem = function(e, a) {
  var r;
  a instanceof Array ? (r = a.map((function(a) {
    return O(e, a), t(t({}, a), {}, {
      t: Date.now(),
      addFrom: e
    })
  })), m[e] = m[e].concat(r)) : (r = t(t({}, a), {}, {
    t: Date.now(),
    addFrom: e
  }), O(e, r), m[e].push(r)), p && !s.isNativeMp || (e === D.CATEGORY || e === D.DISHLIST || e === D.BOSSRECOMMEND || e === D.CART ? p = "b_saaspay_io0djuze_mv" : e === D.SEARCHLIST ? p = "b_saaspay_xgjpgsg7_mv" : e === D.ORDERRECOMMOND || e === D.ORDERDISHLIST ? p = "b_saaspay_lr9m8l1w_mv" : e === D.NETRECOMMENDPAGE && (p = "b_saaspay_4tl96hwp_mv")), S || (S = setInterval((function() {
    Object.keys(m).find((function(e) {
      return m[e].length
    })) && (p && (0, l.sendMV)(p, null, null, {
      exposeData: t({}, m)
    }), Object.keys(D).forEach((function(e) {
      m[e] = []
    })))
  }), 2e3))
};
exports.exposeDishItemNew = function(e) {
  e instanceof Array ? e.map((function(e) {
    return (0, l.sendMV)("b_saaspay_we46nheq_mv", null, null, t(t({}, e), {}, {
      t: Date.now()
    })), null
  })) : (0, l.sendMV)("b_saaspay_we46nheq_mv", null, null, t(t({}, e), {}, {
    t: Date.now()
  }))
};