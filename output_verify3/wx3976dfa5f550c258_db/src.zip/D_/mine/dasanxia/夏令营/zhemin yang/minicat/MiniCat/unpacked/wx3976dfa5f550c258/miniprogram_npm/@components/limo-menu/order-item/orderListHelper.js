Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.showReviewBtn = exports.getStatusMsgColor = exports.getInvoiceBtn = exports.INVOICETXT = exports.Countdown = void 0;
var t = require("../../../../b/helpers/classCallCheck"),
  e = require("../../../../b/helpers/createClass");
require("../../../../b/helpers/Arrayincludes");
var i, o = require("../../../../constants/invoice"),
  n = require("../../../../constants/orderConstants"),
  r = require("../../../../constants/review"),
  s = ((i = {}).TO_INVOICE = "开发票", i.INVOICE_STATUS = "开票状态", i);
exports.INVOICETXT = s;
exports.getInvoiceBtn = function(t) {
  var e = {
    available: !1,
    completed: !1,
    btnTxt: s.TO_INVOICE
  };
  if (null != t && t.invoiceStatus) {
    var i = o.INVOICE_STATUS.COMPLETED,
      n = o.INVOICE_STATUS.ENABLE,
      r = o.INVOICE_STATUS.INVOICE_PREPARE,
      u = o.INVOICE_STATUS.INVOICE_WAITING,
      a = o.INVOICE_STATUS.INVOICE_FAILURE,
      T = t.invoiceStatus.status;
    e.completed = T === i, e.available = [i, n, r, u, a].includes(T), e.btnTxt = [u, a, i].includes(T) ? s.INVOICE_STATUS : s.TO_INVOICE
  }
  return e
};
exports.getStatusMsgColor = function(t) {
  return -1 !== [n.ORDER_STATUS.BOOK_FAIL, n.ORDER_STATUS.BOOK_ERROR, n.ORDER_STATUS.BE_CANCELED, n.ORDER_STATUS.FAIL_FOR_ADD_DISH, n.ORDER_STATUS.CANCEL_FOR_ADD_DISH, n.ORDER_STATUS.REFUND, n.ORDER_STATUS.REFUND_BY_WAITER].indexOf(t) ? "fail" : ""
};
exports.showReviewBtn = function(t, e) {
  return {
    isShowCommentBtn: ((null == e ? void 0 : e.reviewStatus) === r.REVIEW_STATUS.WAIT_REWARD || (null == e ? void 0 : e.reviewStatus) === r.REVIEW_STATUS.WAIT_COMMENT) && n.ORDER_STATUS.FINISH === t,
    isShowReviewReward: null == e ? void 0 : e.rewardType
  }
};
var u = function() {
  function i(e, o, n) {
    t(this, i), this.expireSeconds = e, this.callback = o, this.displayCallback = n, this.timeoutId = null
  }
  return e(i, [{
    key: "start",
    value: function() {
      !this.expireSeconds || this.expireSeconds <= 0 ? this.clearTimeout() : this.countdownWithTimeout(this.expireSeconds)
    }
  }, {
    key: "countdownWithTimeout",
    value: function(t) {
      var e = this;
      this.displayCallback(this.formatDisplayTime(t)), t <= 0 ? this.callback() : this.timeoutId = setTimeout((function() {
        e.countdownWithTimeout(t - 1)
      }), 1e3)
    }
  }, {
    key: "clearTimeout",
    value: function(t) {
      function e() {
        return t.apply(this, arguments)
      }
      return e.toString = function() {
        return t.toString()
      }, e
    }((function() {
      this.timeoutId && clearTimeout(this.timeoutId)
    }))
  }, {
    key: "formatDisplayTime",
    value: function(t) {
      return "".concat((Math.floor(t / 60) + "").padStart(2, "0"), ":").concat((t % 60 + "").padStart(2, "0"))
    }
  }]), i
}();
exports.Countdown = u;