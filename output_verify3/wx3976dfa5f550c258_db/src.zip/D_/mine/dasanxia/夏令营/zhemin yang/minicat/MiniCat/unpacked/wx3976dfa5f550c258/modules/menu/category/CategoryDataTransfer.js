var e = require("../../../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.getPluginActivityToCategory = exports.generateCategoryList = exports.categoryListHasIcon = void 0, require("../../../b/helpers/Arrayincludes");
var t = e(require("../../../miniprogram_npm/@limo/core/index.js")),
  i = require("./util"),
  r = require("../../../constants/bizConstants"),
  o = e(require("../../../miniprogram_npm/@mtfe/rms-triangle-c/index.js")),
  n = e(require("../../../lib/mix/log")).default;
exports.getPluginActivityToCategory = function(e, i, a) {
  var s, u = e;
  if (!o.default.isWxNative || !i.length) return e;
  var c = null == t.default.getLimoRuntime().getExtConfigSync || null == (s = t.default.getLimoRuntime().getExtConfigSync()) ? void 0 : s.plugins;
  if (c && !c.includes("mercPlugin")) return n.addError("ext文件中未注入插件数据", c, {
    level: "info"
  }), e;
  if (!c) {
    var g = null == t.default.getLimoRuntime().getExtConfigSync ? void 0 : t.default.getLimoRuntime().getExtConfigSync();
    return n.addError("获取插件数据异常", {
      extData: g
    }), e
  }
  var l = (t.default.getLimoRuntime().getSystemInfoSync && t.default.getLimoRuntime().getSystemInfoSync() || {}).SDKVersion,
    d = void 0 === l ? "" : l;
  if (o.default.compareVersion(d, "2.10.4") < 0) return n.addError("微信基础库版本不支持低于插件最低支持版本", {
    SDKVersion: d
  }, {
    level: "info"
  }), e;
  var y = Object.keys(a);
  return e.find((function(e) {
    return e.categoryId === r.PLUGIN_CATEGORY
  })) || u.unshift({
    categoryId: r.PLUGIN_CATEGORY,
    categoryMultimediaList: null,
    categoryName: "活动",
    categorySellableType: 0,
    childDishCategories: null,
    iconType: 0,
    position: 0,
    rank: -1,
    spuIds: y.slice(0, i.length)
  }), u
}, exports.categoryListHasIcon = function(e) {
  return e.some((function(e) {
    return !!e.icon
  }))
}, exports.generateCategoryList = function(e, t) {
  var o = t.list,
    n = t.cartList,
    a = t.isLogin,
    s = function t(s) {
      var u = [],
        c = s.categories,
        g = s.isChildCategory,
        l = void 0 !== g && g,
        d = s.parentCategoryName,
        y = void 0 === d ? "" : d,
        m = s.dishShowType,
        v = s.activeIds,
        f = void 0 === v ? [] : v,
        C = 0;
      return c && c.forEach((function(s, c) {
        var g = s.spuIds;
        if (e || function() {
            var e, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [],
              i = arguments.length > 1 ? arguments[1] : void 0,
              r = arguments.length > 2 ? arguments[2] : void 0;
            return null != t && t.length ? t.some((function(e) {
              return !(!i || !i[e])
            })) : !(null == r || null == (e = r.childDishCategories) || !e.some((function(e) {
              var t;
              return null == e || null == (t = e.spuIds) ? void 0 : t.some((function(e) {
                return !(!i || !i[e])
              }))
            })))
          }(g, o, s)) {
          var d = function(e, t) {
            var o = t.category,
              n = t.isChildCategory,
              a = void 0 !== n && n,
              s = t.parentCategoryName,
              u = void 0 === s ? "" : s,
              c = t.index,
              g = t.dishShowType,
              l = t.activeIds,
              d = t.cartList,
              y = void 0 === d ? {} : d,
              m = t.isLogin,
              v = void 0 !== m && m,
              f = o.categoryId,
              C = o.iconType,
              p = void 0 === C ? 0 : C,
              h = o.categoryName,
              I = o.childDishCategories,
              S = o.subCategoryName,
              _ = o.categorySellableType,
              x = void 0 === _ ? 0 : _,
              L = o.spuIds;
            if (f) return null != L && L.length || null != I && I.length ? {
              categoryId: f,
              iconType: p,
              categoryName: h,
              subCategoryName: S,
              spuIds: L,
              categorySellableType: x,
              count: (0, i.computeCategoryCount)(y, o),
              active: (0, i.dealCategoryActive)(f, l),
              icon: (0, i.dealCategoryIcons)(o),
              subTitle: (0, i.dealCategorySubTitle)(f, v),
              id: "category-item-" + f,
              __reportConfig__: {
                categoryName: h,
                isChildCategory: a,
                parentCategoryName: u,
                index: c,
                dishShowType: g,
                categoryIcon: !!o.categoryMultimediaList,
                sn: c,
                dish_cate_name: h,
                dish_cate_type: p ? r.DISH_CATE_TYPE.RECOMMEND_DISH : r.DISH_CATE_TYPE.RECOMMEND_CLASS,
                dish_cate_id: p
              }
            } : void 0
          }(0, {
            category: s,
            isChildCategory: l,
            parentCategoryName: y,
            index: c,
            dishShowType: m,
            activeIds: f,
            cartList: n,
            isLogin: a
          });
          if (d) {
            var v = s.childDishCategories;
            if (v && v.length) {
              var p = t({
                categories: v,
                isChildCategory: !0,
                parentCategoryName: s.categoryName,
                index: c,
                dishShowType: m,
                activeIds: f,
                count: C
              });
              d.childDishCategories = p.categories, d.count = p.count, C += p.count
            } else C += +d.count;
            u.push(d)
          }
        }
      })), {
        categories: u,
        count: C
      }
    };
  return s(t).categories
};