var e = require("../../../../b/helpers/interopRequireDefault"),
  t = require("../../../../b/helpers/objectSpread2"),
  a = e(require("../../../@limo/core/index.js")),
  n = require("../../../@limo/container/behaviors/index"),
  o = e(require("../../../../lib/mix/log"));
Component({
  behaviors: [n.commonBehavior, n.limoShim],
  properties: {
    title: {
      type: Array,
      value: []
    },
    takeCouponPanelData: {
      type: Object,
      value: {},
      observer: function(e) {
        if (Object.keys(e).length) {
          a.default.getLimoRuntime().sendMV({
            valLab: null,
            bid: "b_saaspay_6h8402ar_mv",
            options: {}
          });
          var n = e.agreementsInfo;
          this.setData(t(t({}, e), function(e) {
            var t = e.agreementList,
              a = void 0 === t ? [] : t,
              n = e.agreementParams;
            return {
              agreements: {
                signAgreementDTOs: a.map((function(e) {
                  return {
                    agreementSnapshotId: e.snapshotId,
                    type: e.type
                  }
                })),
                sceneType: 10
              },
              commonHeaders: n
            }
          }(n)))
        }
      }
    },
    isNativeTabbarPage: {
      type: Boolean,
      value: !1
    }
  },
  data: {
    appliedStyle: 8,
    isH5Page: !1,
    takeCouponList: [],
    agreementsInfo: {},
    agreements: {},
    commonHeaders: {},
    userHasAgree: !1
  },
  attached: function() {
    this.limoAttached()
  },
  methods: {
    limoAttached: function() {
      this.setData({
        isH5Page: this.isH5
      })
    },
    closePanel: function() {
      this.sendMC("b_saaspay_dsj6qjz4_mc"), this.triggerEvent("closeTakeCouponPanel")
    },
    getCouponsFn: function() {
      this.data.userHasAgree && (this.sendMC("b_saaspay_6h8402ar_mc"), this.triggerEvent("getPhoneNumberFn"))
    },
    sendMC: function(e) {
      a.default.getLimoRuntime().sendMC({
        valLab: null,
        bid: e,
        options: {}
      })
    },
    onAuthError: function() {
      a.default.getLimoRuntime().showToast({
        title: "授权手机号失败",
        icon: "none",
        duration: 1e3
      })
    },
    onAgreementClick: function(e) {
      var a = this,
        n = this.data.agreementsInfo,
        o = n.agreementList,
        s = void 0 === o ? [] : o,
        i = n.agreementParams,
        r = e.currentTarget.dataset.id,
        u = s.find((function(e) {
          return e.snapshotId === r
        }));
      this.showDialog("limo-rules-modal-v2", {
        agreement: u,
        headers: t({}, i),
        closeRulesModal: function() {
          a.closeDialog("limo-rules-modal-v2")
        }
      }, {
        position: "bottom",
        maskClosable: !0
      })
    },
    loginSuccessCoupon: function() {
      this.data.userHasAgree && (a.default.getLimoRuntime().showLoading({
        title: "加载中"
      }), this.handleRes(!0))
    },
    loginFailedCoupon: function(e) {
      this.data.userHasAgree && (o.default.addLog("userAuth登录失败", e), this.handleRes(!1))
    },
    loginTapCoupon: function(e) {
      if (this.data.userHasAgree) {
        var t = e.detail.authSucceeded;
        this.sendMC(t ? "b_saaspay_ckf3aqc8_mc" : "b_saaspay_txodmokv_mc")
      }
    },
    handleRes: function(e) {
      this.triggerEvent("closeTakeCouponPanel"), e && this.triggerEvent("handleTakeCoupon")
    },
    prevent: function() {},
    onUserAgreeCheckClick: function() {
      var e = this.data.userHasAgree;
      this.setData({
        userHasAgree: !e
      })
    },
    hint: function() {
      var e;
      null != (e = wx) && e.showToast && a.default.getLimoRuntime().showToast({
        title: "请阅读并同意协议",
        icon: "none",
        duration: 2e3
      })
    }
  }
});