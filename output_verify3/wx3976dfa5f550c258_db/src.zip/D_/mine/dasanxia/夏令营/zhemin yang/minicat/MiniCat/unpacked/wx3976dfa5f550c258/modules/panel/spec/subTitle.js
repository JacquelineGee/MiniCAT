Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.noLimitChoice = exports.noLimitAndMax = exports.mustSelectedAndPermanent = exports.mustAndMax = void 0;
var t = require("../../../constants/bizConstants");
exports.mustAndMax = function(e, n, o, c, x) {
  return c === t.TASTE_REPEAT_CHOICE.SINGLE && e >= x ? o ? [{
    text: "(最少选 ".concat(n, " 份，已选 "),
    type: "NORMAL"
  }, {
    text: "" + o,
    type: "IMPORTANT"
  }, {
    text: "份)",
    type: "NORMAL"
  }] : [{
    text: "(最少选 ".concat(n, " 份)"),
    type: "NORMAL"
  }] : o ? [{
    text: "(请选 ".concat(n, "-").concat(e, " 份，已选 "),
    type: "NORMAL"
  }, {
    text: "" + o,
    type: "IMPORTANT"
  }, {
    text: "份)",
    type: "NORMAL"
  }] : [{
    text: "(请选 ".concat(n, "-").concat(e, " 份)"),
    type: "NORMAL"
  }]
}, exports.noLimitAndMax = function(e, n, o, c) {
  return o === t.TASTE_REPEAT_CHOICE.SINGLE && e >= c ? [{
    text: "(可多选)",
    type: "NORMAL"
  }] : n ? [{
    text: "(最多选 ".concat(e, " 份，已选 "),
    type: "NORMAL"
  }, {
    text: "" + n,
    type: "IMPORTANT"
  }, {
    text: "份)",
    type: "NORMAL"
  }] : [{
    text: "(最多选 ".concat(e, " 份)"),
    type: "NORMAL"
  }]
}, exports.mustSelectedAndPermanent = function(t, e) {
  return e ? [{
    text: "(请选择 ".concat(t, " 份，已选 "),
    type: "NORMAL"
  }, {
    text: "" + e,
    type: "IMPORTANT"
  }, {
    text: "份)",
    type: "NORMAL"
  }] : [{
    text: "(请选择 ".concat(t, " 份)"),
    type: "NORMAL"
  }]
}, exports.noLimitChoice = function() {
  return []
};