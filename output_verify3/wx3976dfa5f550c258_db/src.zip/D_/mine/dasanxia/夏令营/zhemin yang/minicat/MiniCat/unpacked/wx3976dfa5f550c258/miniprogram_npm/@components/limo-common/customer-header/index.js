var e = require("../../../../b/helpers/interopRequireDefault"),
  t = e(require("../../../@limo/core/index.js")),
  i = require("../../../@limo/container/behaviors/index.js"),
  o = e(require("../../../@mtfe/rms-triangle-c/index.js"));
Component({
  behaviors: [i.commonBehavior, i.limoShim],
  properties: {
    titleInfo: {
      type: Object,
      value: {},
      observer: function(e) {
        this.updateTitle(e)
      }
    },
    showHomeBtn: {
      type: Boolean,
      value: !1
    }
  },
  data: {
    navBarHeight: 0,
    menuHeight: 0,
    menuMargin: 0,
    titleStyle: ""
  },
  attached: function() {
    this.limoAttached()
  },
  methods: {
    limoAttached: function() {
      var e = o.default.MPInfo.getSystemInfo().statusBarHeight || 44,
        i = t.default.getLimoRuntime().getMenuButtonBoundingClientRect(),
        n = 2 * (i.top - e) + i.height + e,
        a = i.height,
        r = i.top;
      this.setData({
        navBarHeight: n,
        menuHeight: a,
        menuMargin: r
      })
    },
    updateTitle: function(e) {
      var t = e || {},
        i = t.titleBgColor,
        o = t.titleColor;
      this.setData({
        titleStyle: "background-color:".concat(i, ";color:").concat(o, ";")
      })
    },
    backToHome: function() {
      t.default.getLimoRuntime().redirectTo({
        url: "/pages/splash/index"
      })
    }
  }
});