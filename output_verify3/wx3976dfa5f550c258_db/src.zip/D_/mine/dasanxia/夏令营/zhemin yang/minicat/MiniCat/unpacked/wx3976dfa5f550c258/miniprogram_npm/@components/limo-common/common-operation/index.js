var t = require("../../../../b/helpers/interopRequireDefault"),
  e = require("../../../../b/helpers/objectSpread2"),
  i = require("../../../@limo/container/behaviors/index"),
  o = require("../../../../constants/menu"),
  a = require("../../../../constants/lxConstants"),
  n = require("../biz-constants/index"),
  s = require("../../limo-ui/ui-constant/enum"),
  u = require("./constants"),
  r = require("../../../../modules/menu/dish/DishDataUtil"),
  d = t(require("../../../../lib/mix/toast")),
  l = t(require("../../../../lib/mix/log")),
  p = require("../../../../modules/LXHelper"),
  h = t(require("../../../../modules/menu/shop/shopService")),
  c = require("../../../../modules/dishHelper"),
  m = t(require("../../../@mtfe/rms-triangle-c/index.js")),
  E = require("../../../../store/cart/plugins/verifyPoint");
Component({
  behaviors: [i.commonBehavior, i.limoShim],
  properties: {
    operationData: {
      type: Object,
      value: {},
      observer: function(t, e) {
        var i = !1;
        e && t && Object.keys(t).forEach((function(o) {
          t[o] !== e[o] && (i = !0)
        })), i && this.dealData(t)
      }
    },
    mini: {
      type: Boolean,
      value: !1
    },
    isBigSize: {
      type: Boolean,
      value: !1
    },
    size: {
      type: String,
      value: s.UI_SIZE.SMALL
    },
    pageFrom: {
      type: String,
      value: u.PAGE_NAME.MENU
    },
    moduleFrom: {
      type: String,
      value: u.MODULE_NAME.DISH
    },
    lxData: {
      type: Object,
      value: {}
    },
    reportParams: {
      type: Object,
      value: {}
    },
    disableAddReport: {
      type: Boolean,
      value: !1
    },
    preventTransform: {
      type: Boolean,
      value: !1
    },
    customHandleOperationEvent: {
      type: Boolean,
      value: !1
    },
    needBase: {
      type: Boolean,
      value: !1
    },
    canClickCountNum: {
      type: Boolean,
      value: !1
    },
    customClass: {
      type: String,
      value: ""
    },
    menuUpdateTime: {
      type: Number,
      value: 0
    }
  },
  data: {
    DISH_OPERATION_TYPE_VAL: o.DISH_OPERATION_TYPE_VAL,
    UI_SIZE: s.UI_SIZE,
    showCount: 0,
    displayMinus: !1,
    miniPlusRedPoint: !1,
    disablePlus: !1,
    needHelp: !1,
    showCountStyle: !1,
    showDishOperation: !0,
    POINT_DISH_TYPE: o.POINT_DISH_TYPE,
    showPointPurchaseCount: 0
  },
  observers: {
    menuUpdateTime: function() {
      var t = this.data.operationData;
      t && this.dealData(t)
    }
  },
  attached: function() {
    this.limoAttached()
  },
  methods: {
    limoAttached: function() {
      this.dealData(this.data.operationData)
    },
    dealData: function(t) {
      if (t) {
        var i, o = h.default.getShopServiceData().fmpBizData;
        this.sameSkuAllCount = t.count;
        var a = this.initShowCount(t),
          n = !!a && a > 0 && !this.data.operationData.mini;
        this.setData(e(e({}, t), {}, {
          showCount: a,
          showCountStyle: (0, r.dealOperationCountStyle)(t.id || "", this.data.canClickCountNum),
          displayMinus: n,
          miniPlusRedPoint: !n && this.data.operationData.mini,
          disablePlus: t.disablePlus || a === t.maxCount,
          showDishOperation: null == (i = null == o ? void 0 : o.showDishOperation) || i
        }))
      }
    },
    initShowCount: function(t) {
      var e = t.count,
        i = t.pointPurchaseCount;
      return t.discount === o.POINT_DISH_TYPE ? i || 0 : (e || 0) - (i || 0)
    },
    operationClick: function(t) {
      var e = t.currentTarget.dataset.operation,
        i = this.data,
        o = i.operationData,
        a = i.pageFrom,
        n = i.moduleFrom,
        s = i.customHandleOperationEvent;
      if (e)
        if (s) this.triggerEvent("operationBtnClick", {
          operation: e
        });
        else {
          if (null != o && o.discount && !(0, r.verifyMemberLogin)()) return;
          l.default.sendInfo({
            name: "[wxapp][operation]",
            content: {
              page: a,
              module: n,
              method: e,
              operationData: o
            }
          }), "plus" === e ? this.plusEvent() : "minus" === e ? this.minusEvent() : "button" === e && this.buttonEvent()
        }
    },
    clickReport: function(t) {
      var i, s, r = (null == (i = this.data) ? void 0 : i.lxData) || {},
        d = r.categoryId,
        l = r.spuId,
        h = r.id,
        c = r.spuName,
        m = r.dishType,
        E = r.adFrom,
        C = r.index,
        v = r.skuId,
        _ = r.belongCategory,
        D = r.fromNetRecommend,
        I = r.bossRecommendText,
        P = this.data.operationData;
      if (u.OPERATION_BID[this.data.pageFrom]) {
        (0, p.sendMC)(u.OPERATION_BID[this.data.pageFrom][t], null, null, {
          clickData: e(e({}, this.data.lxData), {}, {
            t: Date.now(),
            isFirstScreen: (null == (s = this.data.reportParams) || null == (s = s.firstScreenSpuIds) ? void 0 : s.indexOf(l || h)) > -1 ? 1 : 0
          })
        });
        var T, f = a.OP_NAME.OTHER,
          O = a.OP_TYPE.OTHER,
          b = "";
        d < 0 && (f = a.OP_NAME.RECOMMEND_DISH, b = null == _ ? void 0 : _.parentName, O = a.OP_TYPE.RECOMMEND_CLASS), d > 0 && (f = a.OP_NAME.RECOMMEND_CLASS, b = null == _ ? void 0 : _.parentName, O = a.OP_TYPE.RECOMMEND_CLASS), 1 === D ? (O = a.OP_TYPE.RECOMMEND_DISH, f = a.OP_NAME.RECOMMEND_NET, b = n.TITLE_CONTENT.NET) : 0 === D && (O = a.OP_TYPE.RECOMMEND_DISH, f = a.OP_NAME.RECOMMEND_BOSS, b = I || n.TITLE_CONTENT.BOSS), 0 === E && (O = a.OP_TYPE.BANNER), 1 === E && (O = a.OP_TYPE.AD_MODE), this.data.disableAddReport || (null == P ? void 0 : P.panelType) === o.PANEL_TYPE_VAL.WEIGHT || (null == P ? void 0 : P.panelType) === o.PANEL_TYPE_VAL.SPEC || (null == P ? void 0 : P.panelType) === o.PANEL_TYPE_VAL.PACKAGE || t === u.CLICK_TYPE.MINUS || (0, p.sendMC)("b_saaspay_bsz9zphw_mc", null, null, {
          clickData: {
            op_type: O,
            dish_details_func_area: n.DISH_DETAIL.MAIN_DISH,
            op_name: f,
            algorithm: "",
            sku_id_list: v,
            spu_id_list: l || h,
            show_title: b,
            dish_name_list: c,
            dish_type: m,
            add_dish_quantity: "",
            sn: C,
            isFirstScreen: (null == (T = this.data.reportParams) || null == (T = T.firstScreenSpuIds) ? void 0 : T.indexOf(l || h)) > -1 ? 1 : 0
          }
        })
      }
    },
    plusEvent: function() {
      var t = this.data.operationData,
        i = void 0 === t ? {} : t;
      if (this.clickReport(u.CLICK_TYPE.PLUS), this.data.disablePlus) this.triggerEvent("operationCount", {
        type: "plus",
        id: i.id
      }, {
        bubbles: !0,
        composed: !0,
        discount: i.discount
      });
      else {
        var a = +i.incCount || 1,
          n = 0 == +this.data.showCount ? 1 : +this.data.showCount + a,
          s = !!n && 0 !== n && !this.data.mini,
          l = 0 === this.sameSkuAllCount ? 1 : this.sameSkuAllCount + a,
          p = i.maxCount;
        if (p && l > p && -1 !== p) d.default.show({
          content: "当前库存不足"
        });
        else {
          var h = {
            spuId: i.id,
            skuId: i.skuId,
            count: a
          };
          if (i.discount !== o.POINT_DISH_TYPE || (0, E.verifyPoint)(h)) {
            var C = (0, r.verifyLimitCountRuleInOperation)({
                spuDishId: i.id,
                showCount: this.sameSkuAllCount,
                skuDishId: i.skuId,
                temporaryDishCount: i.temporaryDishCount,
                promoDishLimitCount: i.promoDishLimitCount
              }),
              v = C.passVerification,
              _ = C.errorMessage,
              D = C.promptType;
            v ? i.panelType ? this.triggerEvent("operationPanel", {
              operationData: e(e({}, i), {}, {
                count: n
              })
            }, {
              bubbles: !0,
              composed: !0
            }) : (i.preventPlus || this.setData({
              showCount: n,
              displayMinus: s,
              miniPlusRedPoint: !s && this.data.mini,
              disablePlus: this.data.disablePlus || n === p
            }), this.triggerEvent("operationCount", {
              type: "plus",
              count: n,
              id: i.id,
              discount: i.discount,
              skuId: i.skuId || ""
            }, {
              bubbles: !0,
              composed: !0
            })) : "confirm" === D ? m.default.showModal({
              title: "温馨提示",
              content: _,
              showCancel: !1,
              confirmText: "我知道了",
              confirmColor: "#fe8c00"
            }) : d.default.show({
              content: _,
              duration: c.LIMIT_COUNT_MESSAGE_DURATION
            })
          }
        }
      }
    },
    minusEvent: function() {
      var t = this.data.operationData,
        i = void 0 === t ? {} : t;
      this.clickReport(u.CLICK_TYPE.MINUS);
      var a = i.incCount || 1,
        n = this.data.showCount - a,
        s = n < 0 ? 0 : n,
        r = !!s && 0 !== s && !this.data.mini;
      s < i.minCount && i.minCount > 1 ? (!i.preventMinus && s > i.mustCount && this.setData(e(e({}, i), {}, {
        showCount: 0,
        displayMinus: r,
        count: 0,
        type: o.DISH_OPERATION_TYPE_VAL.BUTTON
      })), this.triggerEvent("operationCount", {
        type: "minus",
        count: s,
        id: i.id,
        discount: i.discount,
        skuId: i.skuId || ""
      }, {
        bubbles: !0,
        composed: !0
      })) : (!i.preventMinus && s > i.mustCount && this.setData({
        showCount: Math.max(0, s),
        displayMinus: r,
        disablePlus: this.data.disablePlus || s === i.maxCount
      }), this.triggerEvent("operationCount", {
        type: "minus",
        count: s,
        id: i.id,
        discount: i.discount,
        skuId: i.skuId || ""
      }, {
        bubbles: !0,
        composed: !0
      }))
    },
    buttonEvent: function() {
      var t = this.data.operationData,
        i = void 0 === t ? {} : t;
      this.clickReport(u.CLICK_TYPE.BUTTON);
      var a = i.minCount;
      i.cartCount > 0 && (a = i.incCount);
      var n = !!a && 0 !== a && !this.data.mini,
        s = i.maxCount;
      if (s && a > s && -1 !== s) d.default.show({
        content: "当前库存不足"
      });
      else if (i.panelType || this.data.preventTransform) {
        var l, p;
        this.triggerEvent("operationPanel", {
          operationData: e(e({}, i), {}, {
            reportConfig: e(e({}, (null == (l = this.data) ? void 0 : l.lxData) || {}), (null == (p = this.data) ? void 0 : p.reportParams) || {})
          })
        }, {
          bubbles: !0,
          composed: !0
        })
      } else {
        var h = {
          spuId: i.id,
          count: i.minCount,
          skuId: i.skuId
        };
        if (i.discount === o.POINT_DISH_TYPE && !(0, E.verifyPoint)(h)) return;
        var C = (0, r.verifyLimitCountRuleInOperation)({
            spuDishId: i.id,
            promoDishLimitCount: i.promoDishLimitCount
          }),
          v = C.passVerification,
          _ = C.errorMessage,
          D = C.promptType;
        if (!v) return void("confirm" === D ? m.default.showModal({
          title: "温馨提示",
          content: _,
          showCancel: !1,
          confirmText: "我知道了",
          confirmColor: "#fe8c00"
        }) : d.default.show({
          content: _,
          duration: c.LIMIT_COUNT_MESSAGE_DURATION
        }));
        this.setData({
          type: o.DISH_OPERATION_TYPE_VAL.NUMBER,
          showCount: a,
          displayMinus: n,
          disablePlus: this.data.disablePlus || a === i.maxCount
        }), this.triggerEvent("operationCount", {
          type: "plus",
          count: a,
          id: i.id,
          discount: i.discount,
          skuId: i.skuId || ""
        }, {
          bubbles: !0,
          composed: !0
        })
      }
    },
    showDishTimeInfoModal: function() {
      var t = this.data,
        e = t.id;
      t.needHelp && this.triggerEvent("showDishTimeInfoModalFn", {
        spuId: e
      }, {
        bubbles: !0,
        composed: !0
      })
    },
    numberClick: function() {
      this.data.operationData.showMultipleInput && this.triggerEvent("operationCount", {
        type: "plus",
        showCal: !0,
        count: this.data.showCount,
        id: this.data.operationData.id,
        discount: this.data.operationData.discount,
        skuId: this.data.operationData.skuId || ""
      }, {
        bubbles: !0,
        composed: !0
      })
    }
  }
});