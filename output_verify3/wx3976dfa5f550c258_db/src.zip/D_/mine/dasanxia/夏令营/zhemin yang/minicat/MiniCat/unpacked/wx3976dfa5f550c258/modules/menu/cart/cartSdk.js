var t = require("../../../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.default = void 0, require("../../../b/helpers/Arrayincludes");
var e = require("../../../b/helpers/createForOfIteratorHelper"),
  i = t(require("../../../miniprogram_npm/seamless-immutable/index.js")),
  r = t(require("../../../api/rmsStorage")),
  a = t(require("../../../api/cartPike")),
  u = t(require("../../../lib/mix/toast")),
  n = t(require("../../../lib/mix/confirm")),
  o = require("../../../constants/cartConstants"),
  l = require("../../../lib/mix/util"),
  s = t(require("../../../miniprogram_npm/@mtfe/rms-triangle-c/index.js")),
  c = require("../../../lib/env"),
  d = require("../../../store/actions/mustDish"),
  p = require("../../../store/actions/cart"),
  f = require("../../../store/asyncActions/cart"),
  h = require("../../../store/actions/newCart"),
  C = require("../../dishHelper"),
  m = require("../../cartHelper"),
  g = require("../../../lib/wx/app-info"),
  v = require("./cartDataTransfer"),
  D = t(require("../../MustDishSdk")),
  S = t(require("../grouponCoupon/GrouponCouponSdk")),
  L = require("../dish/DishSdk"),
  I = require("../../panel/package/utils"),
  k = require("../../../constants/menu"),
  M = function() {
    var t;
    return c.isNativeMp ? null == (t = (0, g.getNewApp)()) || null == (t = t.rmsDiancanStore) || null == (t = t.getState()) || null == (t = t.cart) ? void 0 : t.tableNum : (0, l.getMixUrlParam)("tableNum") || ""
  },
  T = {
    version: 0,
    refactorCartDishMap: {}
  },
  P = {
    lastSeqId: 0,
    operationList: []
  },
  q = {
    cartDishList: {},
    cartDishSortMapList: []
  },
  b = {
    init: function(t, e, i, u) {
      var n = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : {};
      return function(o) {
        var c = (0, l.getShopId)() || n.shopId,
          d = M() || n.tableNum,
          C = r.default.getUserOperation(c);
        !s.default.isNullOrUndefined(C) && Object.keys(C).length || (C = {
          lastSeqId: 0,
          operationList: []
        }), o((0, h.updateUserOperation)(c, C)), D.default.initMustDish(t, e), o((0, p.generateLocalCart)(c, d, u)), a.default.close(), (i || r.default.getNewAdvanceFlag(c) || r.default.getHasOpenTogether(c)) && o((0, f.getCloudCartDishList)(c, d, !1, (0, l.isInMenuPage)()))
      }
    },
    clearCart: function(t) {
      return function(e, i) {
        var r = i().cart.cartDishList,
          a = (0, C.getDishListFromStore)(i()),
          n = D.default.getFixedMustDishList({}, a),
          s = (0, v.batchDishWithTempCartDishList)(n, q),
          c = s.cartDishList,
          d = s.cartDishSortMapList;
        t ? e((0, p.updateCart)((0, l.getShopId)(), M(), c, d, {
          type: o.UPDATE_CART_TYPE.FROM_CLOUD_CART
        })) : (e((0, h.operationDispatch)(o.OPERATE_TYPE.CLEAR_CART, null, r, c)), e((0, p.updateCart)((0, l.getShopId)(), M(), c, d)));
        var f = 0 === Object.keys(c).length;
        f ? e((0, p.closeCartPanel)()) : f || t || u.default.show({
          content: o.MUST_DISH_CANNOT_MINUS_TEXT
        }), S.default.setApplyCouponId(null), S.default.setCancelCouponId(null)
      }
    },
    clearLocalCartAndRelatedInfos: function(t, e) {
      var a = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
      if (t && (r.default.setCartDishList(t, e, {}), r.default.setCartDishSortMapList(t, e, []), r.default.setRefactorLocalCart(t, e, T), r.default.setPartialCloudCartInfo(t, {}), a && (r.default.setCartDishList(t, "", {}), r.default.setCartDishSortMapList(t, "", []), r.default.setRefactorLocalCart(t, "", T), r.default.setCartPrice(t, (0, i.default)({})), r.default.setUserOperation(t, P), c.isNativeMp))) {
        var u, n = (0, g.getNewApp)();
        null == n || null == (u = n.rmsDiancanStore) || u.dispatch(function(t, e) {
          return function(r) {
            (0, m.stopPollTask)(), r((0, d.updateMustDishEnoughAction)(!0)), r((0, p.updateCart)(t, e, (0, i.default)({}), (0, i.default)([]), null)), r((0, h.updateUserOperation)(t, P)), S.default.setApplyCouponId(null), S.default.setCancelCouponId(null)
          }
        }(t, e))
      }
    },
    getRefactorCartDishMap: function(t) {
      var e, i, a = null == t || null == (e = t.cart) ? void 0 : e.refactorLocalCart;
      return void 0 === a && (a = r.default.getRefactorLocalCart((0, l.getShopId)(), M())), (null == (i = a) ? void 0 : i.refactorCartDishMap) || {}
    },
    batchDish: function(t) {
      var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [],
        i = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
      return function(r, a) {
        if (t && null != e && e.length) {
          var u, n = a().cart,
            s = n.cartDishList,
            c = n.cartDishSortMapList;
          u = t === o.OPERATE_TYPE.MODIFY ? (0, v.batchUpdateDish)(e, {
            cartDishList: s,
            cartDishSortMapList: c
          }) : (0, v.batchDishWithTempCartDishList)(e, {
            cartDishList: s,
            cartDishSortMapList: c
          }), r((0, h.operationDispatch)(t, null, s, u.cartDishList, i)), r((0, p.updateCart)((0, l.getShopId)(), M(), u.cartDishList, u.cartDishSortMapList))
        }
      }
    },
    computeCount: function(t, e) {
      var i = null == e ? void 0 : e[t.toString()];
      return (null == i ? void 0 : i.reduce((function(t, e) {
        return t + Number(e.count)
      }), 0)) || 0
    },
    computeWeight: function(t, e) {
      var i = e[t.toString()];
      return (null == i ? void 0 : i.reduce((function(t, e) {
        return t + Number(e.weight)
      }), 0)) || 0
    },
    validateAddDish: function(t, i) {
      var r, a, o, s, c, d = null == t || null == (r = t.spuId) ? void 0 : r.toString(),
        p = null == t || null == (a = t.skuId) ? void 0 : a.toString(),
        f = (0, L.GetDishSdkSingleton)((0, l.getShopId)()),
        h = f.findOriginalSpuDetail(d),
        m = f.findOriginalSkuDetail(d, t.skuId);
      if (!h || !m) return !1;
      var g, v = m.orderedCount,
        D = m.specAttrs,
        S = -1 === m.limitCount ? 1 / 0 : m.limitCount,
        I = -1 === m.stockCount ? 1 / 0 : m.stockCount,
        k = h.incBoughtCount,
        M = h.spuName,
        T = h.minBoughtCount,
        P = M;
      Array.isArray(D) && null != (o = D[0]) && o.value && (P += "-" + (null == (g = D[0]) ? void 0 : g.value));
      var q = -1 === T ? k : T,
        b = ((null == i || null == (s = i.cart) ? void 0 : s.refactorLocalCart).refactorCartDishMap[d] || []).filter((function(t) {
          return t.skuId === p
        })).reduce((function(t, e) {
          return t + (Number(e.count) || 0)
        }), 0) || 0;
      if (I < q || b > 0 && I < b + k) return u.default.show({
        content: "当前库存不足",
        duration: 1e3
      }), !1;
      if (!(0, C.verifySimpleSkuLimitCount)({
          limitCount: S,
          skuIdDishCountInCart: b,
          orderedCount: v,
          incBoughtCount: k,
          minBoughtCount: T
        })) return u.default.show({
        content: (0, C.jointExceedLimitCountMessage)({
          dishName: P,
          limitCount: S,
          orderedCount: v
        }),
        duration: C.LIMIT_COUNT_MESSAGE_DURATION
      }), !1;
      var A = ((null == i || null == (c = i.extraInfo) || null == (c = c.headInfo) ? void 0 : c.fmpBizData) || {}).promoLimitActivityVO;
      if (A && p) {
        var N, O, _ = e(null == A ? void 0 : A.limitRuleTag);
        try {
          for (_.s(); !(O = _.n()).done;) {
            var y, x = O.value,
              E = x.skuIdList,
              R = x.limitValue,
              U = x.limitActivityType,
              w = x.limitValuePerPerson;
            if (E.includes(+p)) {
              var V = (0, C.computeSkuDishListInCart)(E, null == i || null == (y = i.cart) ? void 0 : y.cartDishList),
                j = V.skusCountInCart,
                B = V.skuNames;
              if (-1 === B.indexOf(P) && B.unshift(P), !(0, C.verifyLimitCount)((0, C.convertAssociatedSkuLimitData)({
                  limitCount: R,
                  incBoughtCount: k,
                  isSkuIdDishInCart: !!b,
                  minBoughtCount: T,
                  skusCountInCart: j
                }))) {
                var F;
                N = {
                  limitValue: R,
                  limitValuePerPerson: w,
                  limitMessageTpl: null == A || null == (F = A.limitTextMode) ? void 0 : F["" + U],
                  skuNames: B
                };
                break
              }
            }
          }
        } catch (t) {
          _.e(t)
        } finally {
          _.f()
        }
        if (N) {
          var H = {
            dishName: N.skuNames,
            limitCount: N.limitValue,
            orderedCount: 0,
            limitValuePerPerson: N.limitValuePerPerson,
            limitMessageTpl: N.limitMessageTpl
          };
          return (0, n.default)({
            title: "温馨提示",
            body: (0, C.jointExceedLimitCountMessage)(H),
            buttons: [{
              text: "我知道了",
              type: "submit"
            }]
          }), !1
        }
      }
      return !0
    },
    computeSkuDishCountInCart: function(t, e, i) {
      return (i[t] || []).reduce((function(t, i) {
        return i.skuId === e && i.count ? t + i.count : t
      }), 0)
    },
    addFixedPackage: function(t, e) {
      return function(i) {
        var r = (0, I.initPackage)(t, e).cartPackageSku;
        i((0, p.addToCart)(r))
      }
    },
    computePointPurchaseDishCountInCart: function(t, e) {
      var i = null == e ? void 0 : e[t.toString()],
        r = 0;
      return null == i || i.forEach((function(t) {
        t.discount === k.POINT_DISH_TYPE && (r += t.count || 0)
      })), r
    }
  };
exports.default = b;