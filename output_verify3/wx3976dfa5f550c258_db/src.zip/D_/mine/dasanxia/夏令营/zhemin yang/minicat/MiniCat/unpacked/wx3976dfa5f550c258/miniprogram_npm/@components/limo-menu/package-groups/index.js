var e = require("../../../../b/helpers/interopRequireDefault"),
  t = require("../../../../b/helpers/toConsumableArray");
require("../../../../b/helpers/Objectvalues");
var a = require("../../../../b/helpers/objectSpread2"),
  r = require("../../../@limo/container/behaviors/index"),
  u = require("../../../../modules/panel/panelHelper"),
  s = require("../../../../constants/bizConstants"),
  i = e(require("../../../../modules/menu/shop/shopService")),
  n = {
    MINI: "mini",
    SMALL: "small",
    MIDDLE: "middle",
    LARGE: "large",
    SUPER_LARGE: "super-large"
  };
Component({
  behaviors: [r.commonBehavior, r.limoShim],
  options: {
    addGlobalClass: !0
  },
  properties: {
    needLine: {
      type: Boolean,
      value: !1
    },
    menuPackageSku: {
      type: Object,
      value: {}
    },
    cartPackageSku: {
      type: Object,
      value: {}
    },
    maxLen: {
      type: Number,
      value: 9,
      observer: function() {
        this.initPackages()
      }
    },
    title: {
      type: String,
      value: ""
    },
    packages: {
      type: Array,
      value: [],
      observer: function() {
        this.initPackages()
      }
    },
    spuComboShowType: {
      type: Number,
      value: 0
    }
  },
  data: {
    packagesModel: []
  },
  methods: {
    initPackages: function() {
      var e, t = this,
        r = this.data,
        u = r.maxLen,
        s = r.packagesModel,
        n = r.packages,
        l = r.title,
        o = i.default.getShopServiceData().shopConfig,
        g = "false" !== (null == o || null == (e = o.menuStyle) || null == (e = e.feConfig) ? void 0 : e.showPackageSubDish),
        c = null == n ? void 0 : n.map((function(e, r) {
          var i, n, o = a({}, e),
            c = g && (null == (i = o.list) ? void 0 : i.length) > u,
            d = null == (n = s[r]) ? void 0 : n.isOn,
            h = null == o ? void 0 : o.list;
          return o.showFold = c, c && (o.isOn = !!d, d || (o.list = (null == h ? void 0 : h.slice(0, u)) || [])), o.size = t.getCardSize(h, o.isFixed, !!l), o
        }));
      this.setData({
        packagesModel: c
      })
    },
    getCardSize: function(e, a, r) {
      if (r) return n.SMALL;
      var u = this.data.spuComboShowType,
        i = Object.values(n),
        l = e.map((function(e) {
          var t, r = e.isDefaultTastes,
            l = e.enableRepeatPlus,
            o = e.name,
            g = e.hasMethodsOrTastes,
            c = (null == o ? void 0 : o.length) > 8;
          return t = u === s.PACKAGE_TEMPLATE_TYPE.NO_PIC ? n.MINI : a ? r && !c ? n.SMALL : n.SUPER_LARGE : l ? g || !r || c ? n.SUPER_LARGE : n.LARGE : r && !c ? n.MIDDLE : n.LARGE, i.indexOf(t)
        }));
      return i[Math.max.apply(Math, t(l)) || 0]
    },
    foldClick: function(e) {
      var a = e.currentTarget.dataset.idx || 0,
        r = this.data,
        u = r.packagesModel,
        s = r.maxLen,
        i = r.packages;
      u.forEach((function(e, t) {
        var r;
        t === Number(a) && (e.isOn ? e.list = (null == (r = e.list) ? void 0 : r.slice(0, s)) || [] : e.list = i[t].list, e.isOn = !e.isOn)
      })), this.setData({
        packagesModel: t(u)
      })
    },
    addTastes: function(e) {
      var t = e.currentTarget.groupId || e.currentTarget.dataset.groupId,
        a = e.currentTarget.skuId || e.currentTarget.dataset.skuId,
        r = e.currentTarget.dataset.groupType,
        i = (0, u.getMatchedSkuDish)(this.data.menuPackageSku, t, a),
        n = i.length ? i[0] : null,
        l = (0, u.getMatchedSkuDish)(this.data.cartPackageSku, t, a),
        o = l.length ? l[0] : null,
        g = Number(r) === s.GROUP_TYPE.FIXED ? o : (0, u.initCartSku)(o, n);
      g && this.triggerEvent("addTastesFun", {
        cartSku: g,
        menuSku: n
      })
    },
    minusSkuDishFunc: function(e) {
      var t = e.currentTarget.groupId || e.currentTarget.dataset.groupId,
        a = e.currentTarget.skuId || e.currentTarget.dataset.skuId,
        r = (0, u.getMatchedSkuDish)(this.data.cartPackageSku, t, a);
      if (r.length > 1) this.triggerEvent("toggleSpecsFun", {
        cartSkuList: r,
        groupId: t,
        skuId: a
      });
      else if (1 === r.length) {
        var s = (0, u.getMatchedSkuDish)(this.data.menuPackageSku, t, a),
          i = s.length ? s[0] : null,
          n = r[0];
        this.triggerEvent("minusPackageSkuDishFun", {
          cartSku: n,
          menuSku: i
        })
      }
    },
    clickSpecInfoFn: function(e) {
      var t = e.currentTarget.groupId || e.currentTarget.dataset.groupId,
        a = e.currentTarget.skuId || e.currentTarget.dataset.skuId,
        r = (0, u.getMatchedSkuDish)(this.data.cartPackageSku, t, a);
      if ((null == r ? void 0 : r.length) > 1 || 1 === (null == r ? void 0 : r.length) && r[0].count > 1) this.triggerEvent("toggleSpecsFun", {
        cartSkuList: r,
        groupId: t,
        skuId: a
      });
      else {
        var s = r[0].goodsNo;
        this.triggerEvent("toggleSpecPanel", {
          goodsNo: s,
          groupId: t,
          skuId: a
        })
      }
    }
  }
});