Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.transferCouponData = exports.dealDiscountTag = void 0;
var O = require("../groupCouponHelper"),
  _ = require("../../constants/bizConstants");
exports.transferCouponData = function(_) {
  var T = [],
    I = (null == _ ? void 0 : _.length) || 0;
  return null == _ || _.forEach((function(_, P) {
    var e, R, S = I > 1 && P === I - 1 ? "last-coupon" : "";
    T.push({
      couponViewId: _.couponViewId,
      templateId: _.templateId,
      src: null == (e = _.matchDiscount) ? void 0 : e.src,
      activityDesc: _.activityDesc,
      applyStatus: _.applyStatus,
      couponDateDesc: _.couponDateDesc,
      startTime: _.startTime,
      endTime: _.endTime,
      upperAmount: _.upperAmount,
      couponDateWarnTips: _.couponDateWarnTips,
      couponDeductionAmount: _.couponDeductionAmount,
      couponDiscountType: _.couponDiscountType,
      subType: _.subType,
      couponName: _.couponName,
      couponNum: _.couponNum,
      discount: _.discount,
      invalidReason: _.invalidReason,
      thresholdInfos: _.thresholdInfos,
      rules: (0, O.isGroupCoupon)((null == _ || null == (R = _.matchDiscount) ? void 0 : R.src) || 0) ? null == _ ? void 0 : _.rules : [],
      lastItemClass: S,
      couponLabel: _.couponLabel,
      frontItemNos: _.frontItemNos,
      deleteDish: _.deleteDish,
      canStackUse: _.canStackUse,
      conflict: _.conflict
    })
  })), T
};
exports.dealDiscountTag = function(O) {
  var T = 0,
    I = _.SHOP_PROMOTION_TAG_TYPE.PROMOTION;
  switch (O) {
    case _.DISH_PROMOTION_TYPE_SRC.PROMOTION_FULL_GIFT:
    case _.DISH_PROMOTION_TYPE_SRC.PROMOTION_BUY_GIFT:
    case _.DISH_PROMOTION_TYPE_SRC.POS_DISCOUNT_GOODS_PRESENT:
    case _.DISH_PROMOTION_TYPE_SRC.DISH_WITH_FREE:
      T = _.PROMOTION_ICON_TYPE.GIFT;
      break;
    case _.DISH_PROMOTION_TYPE_SRC.PROMOTION_FULL_ADDPRICE:
    case _.DISH_PROMOTION_TYPE_SRC.PROMOTION_GOODS_BUY_ADD:
      T = _.PROMOTION_ICON_TYPE.CHANGE;
      break;
    case _.DISH_PROMOTION_TYPE_SRC.PROMOTION_SPECIAL_PRICE:
    case _.DISH_PROMOTION_TYPE_SRC.PROMOTION_GOODS_DISCOUNT:
    case _.DISH_PROMOTION_TYPE_SRC.PROMOTION_NTH_DISCOUNT:
    case _.DISH_PROMOTION_TYPE_SRC.POS_DISCOUNT_GOODS_CUSTOM:
    case _.DISH_PROMOTION_TYPE_SRC.PROMOTION_FULL_COUNT_DISCOUNT:
    case _.DISH_PROMOTION_TYPE_SRC.PROMOTION_NTH_SPECIAL_PRICE:
    case _.DISH_PROMOTION_TYPE_SRC.PROMOTION_FULL_COUNT_FIXED_PRICE:
    case _.DISH_PROMOTION_TYPE_SRC.PROMOTION_FULL_COUNT_SPEC_PRICE:
    case _.DISH_PROMOTION_TYPE_SRC.PROMOTION_FULL_DISCOUNT:
      T = _.PROMOTION_ICON_TYPE.DISCOUNT;
      break;
    case _.DISH_PROMOTION_TYPE_SRC.PROMOTION_NTH_CUT:
    case _.DISH_PROMOTION_TYPE_SRC.PROMOTION_FULL_COUNT_CUT:
    case _.DISH_PROMOTION_TYPE_SRC.PROMOTION_FULL_ADD_GOODS_REDUCE:
    case _.DISH_PROMOTION_TYPE_SRC.POS_DISCOUNT_SPECIAL_PRICE:
      T = _.PROMOTION_ICON_TYPE.CUT;
      break;
    case _.DISH_PROMOTION_TYPE_SRC.GROUP_COUPON_DISH_COUPON:
    case _.DISH_PROMOTION_TYPE_SRC.KOU_BEI_DISH_COUPON:
    case _.DISH_PROMOTION_TYPE_SRC.KOU_BEI_TIMES_CARD:
    case _.DISH_PROMOTION_TYPE_SRC.DOUYIN_DISH_COUPON:
    case _.DISH_PROMOTION_TYPE_SRC.DOUYIN_TIMES_CARD:
    case _.DISH_PROMOTION_TYPE_SRC.KS_DISH_COUPON:
      T = _.PROMOTION_ICON_TYPE.GROUPON;
      break;
    case _.DISH_PROMOTION_TYPE_SRC.MEMBER_DISCOUNT_GOODS_DISCOUNT:
    case _.DISH_PROMOTION_TYPE_SRC.MEMBER_GOODS_NTH_DISCOUNT:
    case _.DISH_PROMOTION_TYPE_SRC.MEMBER_NTH_DISCOUNT:
    case _.DISH_PROMOTION_TYPE_SRC.MEMBER_SPECIAL_PRICE:
      T = _.PROMOTION_ICON_TYPE.MEMBER_DISCOUNT, I = _.SHOP_PROMOTION_TAG_TYPE.MEMBER_COUPON;
      break;
    case _.DISH_PROMOTION_TYPE_SRC.MEMBER_NTH_FREE:
      T = _.PROMOTION_ICON_TYPE.CUT, I = _.SHOP_PROMOTION_TAG_TYPE.MEMBER_COUPON;
      break;
    case _.DISH_PROMOTION_TYPE_SRC.MEMBER_BUY_GIFT:
    case _.DISH_PROMOTION_TYPE_SRC.DISH_WITH_FREE_MEMBER:
      T = _.PROMOTION_ICON_TYPE.GIFT, I = _.SHOP_PROMOTION_TAG_TYPE.MEMBER_COUPON;
      break;
    default:
      return {
        iconType: -1, tagType: I
      }
  }
  return {
    iconType: T,
    tagType: I
  }
};