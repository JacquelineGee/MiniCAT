var t = require("../../../b/helpers/interopRequireDefault"),
  e = require("../../../miniprogram_npm/@limo/container/behaviors/index"),
  i = t(require("../../../miniprogram_npm/seamless-immutable/index.js")),
  n = require("../../../constants/bizConstants"),
  a = require("../../../ui/constant/enum"),
  s = "134rpx";
Component({
  behaviors: [e.commonBehavior, e.limoShim],
  options: {
    addGlobalClass: !0
  },
  properties: {
    dish: {
      type: Object,
      value: (0, i.default)({})
    },
    userColors: {
      type: Array,
      value: []
    },
    newCartDishList: {
      type: Array,
      value: []
    },
    promotionMap: {
      type: Object,
      value: null
    },
    isShowBigBtn: {
      type: Boolean,
      value: !0
    },
    cartDiscountData: {
      type: Object,
      value: null
    },
    needBuyFreeBtn: {
      type: Boolean,
      value: !0
    },
    customClass: {
      type: String,
      value: ""
    }
  },
  data: {
    MORE_USER: 4,
    MAX_WEIGHT_DESC: 7,
    isSingleLineTags: !0,
    reportConfig: {
      addFrom: n.DISH_ADD_FROM.CART
    },
    cartDisCountStripData: {},
    LABEL_TYPE: a.LABEL_TYPE,
    hotZoneRight: s
  },
  attached: function() {
    this.limoAttached()
  },
  lifetimes: {
    ready: function() {
      this.setHotZoneRight()
    }
  },
  observers: {
    "dish.renderTagList, dish.itemPrice.**": function() {
      this.adjustTagList()
    },
    "dish.**, cartDiscountData": function(t, e) {
      var i, a = t.renderFullCountDiscountData,
        s = (null == a ? void 0 : a.type) === n.SHOP_PROMOTION_TYPE.DISH_WITH_FREE && 0 === (null == t || null == (i = t.itemPrice) ? void 0 : i.actualPrice);
      this.setData({
        cartDisCountStripData: {
          renderFullCountDiscountData: a,
          cartDiscountData: e
        },
        showDiscountIcon: s
      })
    }
  },
  methods: {
    limoAttached: function() {
      this.adjustTagList()
    },
    adjustTagList: function() {
      var t = this,
        e = t.createSelectorQuery();
      e.select("#dish-tag-" + t.data.dish.goodsNo).boundingClientRect((function(e) {
        e && e.width && e.width > 180 && t.setData({
          isSingleLineTags: !1
        })
      })), e.exec()
    },
    setHotZoneRight: function() {
      var t = this;
      this.createSelectorQuery().select(".opration-wrap").boundingClientRect().exec((function(e) {
        var i;
        null != e && null != (i = e[0]) && i.width && t.setData({
          hotZoneRight: e[0].width + "px" || s
        })
      }))
    },
    editSkuDish: function() {
      this.triggerEvent("editSku", this.data.dish)
    },
    editWeightSkuDish: function() {
      this.triggerEvent("editWeight", this.data.dish)
    },
    addPanelSku: function(t) {
      this.triggerEvent("addToCart", t.detail)
    },
    minusPanelSku: function() {
      this.triggerEvent("minusDish", this.data.dish)
    },
    onclickCountNum: function() {
      this.triggerEvent("onclickCountNum", this.data.dish)
    },
    checkedBuyFreeFn: function(t) {
      this.triggerEvent("checkedBuyFreeFn", t.detail)
    }
  }
});