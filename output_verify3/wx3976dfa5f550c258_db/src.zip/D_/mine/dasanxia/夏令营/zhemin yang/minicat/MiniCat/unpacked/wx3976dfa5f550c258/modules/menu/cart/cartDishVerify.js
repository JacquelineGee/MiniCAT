var t = require("../../../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.handleUnverifyDish = function(t) {
  var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
  if (Array.isArray(t) && t.length > 0) {
    var e = (0, a.getUnveriedDishText)(t);
    (0, l.default)({
      body: e,
      buttons: [{
        text: i.CONFIRM_TEXT,
        type: "submit",
        callback: function() {}
      }]
    })
  } else if (Array.isArray(n) && n.length > 0) {
    var r = (0, a.getUnveriedDishText)(n, !0);
    (0, l.default)({
      body: r,
      buttons: [{
        text: i.CONFIRM_TEXT,
        type: "submit",
        callback: function() {}
      }]
    })
  }
}, exports.verifyCartDish = function(t, n, r) {
  var u, i = arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
    f = arguments.length > 4 && void 0 !== arguments[4] && arguments[4],
    l = (0, e.default)({});
  if (s = (0, e.default)([]), n && Object.keys(n).forEach((function(u) {
      var i, o = n[u],
        a = h(t[u.toString()], o, r, f);
      (null == a || null == (i = a.newCartSkuList) ? void 0 : i.length) > 0 && (l = e.default.set(l, u, a.newCartSkuList)), r = a.cartDishSortMapList
    })), !i) {
    var c = function(t, n, r) {
        var u = (0, e.default)({}),
          i = n;
        if (!Object.keys(n).length) return {
          resCartDishList: n,
          resCartDishSortMapList: r
        };
        Object.keys(n).sort((function(n, e) {
          return (0, a.judgePackageSpuDish)(t[e]) - (0, a.judgePackageSpuDish)(t[n])
        })).forEach((function(o) {
          var a = t[o];
          n[o].forEach((function(t, n) {
            var f = a.skuMenuItems.find((function(n) {
              return n.skuId === t.skuId
            }));
            if (f) {
              var l = a.incBoughtCount,
                c = -1 === a.minBoughtCount ? l : a.minBoughtCount,
                s = c,
                d = u,
                v = !1,
                g = t.count || 0,
                h = t.weight;
              if (h && h > 0) I(d = p(d, a, t)) || (u = d, s = Number(t.count || 0) + l, v = !0);
              else if (Array.isArray(t.packages) && t.packages.length > 0)
                for (; s <= g && !I(d = k(d, f, t));) u = d, s += l, v = !0;
              else
                for (; s <= g;) {
                  var C = s === c ? c : l;
                  d = m(d, f, C);
                  for (var b = 0; b < C; b++) d = p(d, a, t);
                  if (I(d)) break;
                  u = d, s += l, v = !0
                }
              var N = v ? s - l : 0;
              if (N !== t.count && (i = e.default.setIn(i, [o, n, "count"], N)), 0 === N) {
                var S = r.findIndex((function(n) {
                  return n.goodsNo === t.itemNo
                }));
                r = e.default.flatMap(r, (function(t, n) {
                  return n === S ? [] : t
                }))
              }
            }
          }))
        }));
        var o = (0, e.default)({});
        return Object.keys(i).forEach((function(t) {
          var n = i[t].filter((function(t) {
            return 0 !== t.count
          }));
          0 !== n.length && (o = e.default.set(o, t, n))
        })), {
          resCartDishList: o,
          resCartDishSortMapList: r
        }
      }(t, l, r),
      d = c.resCartDishList,
      v = c.resCartDishSortMapList;
    l = d, r = v
  }
  var g = function(t, n) {
    var r = (0, e.default)([]);
    return Object.keys(t).forEach((function(e) {
      var u = t[e],
        i = n[e];
      i ? null == u || u.forEach((function(t) {
        i.find((function(n) {
          return n.itemNo === t.itemNo
        })) || (r = r.concat([t]))
      })) : null == u || u.forEach((function(t) {
        r = r.concat([t])
      }))
    })), r
  }(n, l);
  return {
    cartDishList: (null == (u = (0, o.transferRefactorCartDishMapToCartDishList)(l, t)) ? void 0 : u.cartDishList) || (0, e.default)({}),
    cartDishSortMapList: r,
    unVerfiedDish: g,
    promptDishes: s
  }
};
var n = require("../../../b/helpers/typeof"),
  e = t(require("../../../miniprogram_npm/seamless-immutable/index.js")),
  r = t(require("../../MustDishSdk")),
  u = require("../../../lib/number"),
  i = require("../../../constants/bizConstants"),
  o = require("./cartDataTransfer"),
  a = require("../../cartHelper"),
  f = require("../../panel/panelHelper"),
  l = t(require("../../../lib/mix/confirm")),
  c = t(require("../grouponCoupon/GrouponCouponSdk")),
  s = (0, e.default)([]);

function d(t, r, u, o) {
  if (!(r && r.length || u && u.length)) return !0;
  if (!u) return !r;
  for (var a = 0, f = function(f) {
      var l = r[f];
      if (!l) return {
        v: !0
      };
      var g = u.find((function(t) {
        return t.groupId === l.groupId
      }));
      if (!g) return {
        v: !1
      };
      var h = -1 === (null == g ? void 0 : g.maxChoice) ? 1 / 0 : null == g ? void 0 : g.maxChoice,
        m = -1 === (null == g ? void 0 : g.minChoice) ? 0 : null == g ? void 0 : g.minChoice;
      if (void 0 === h || void 0 === m) return {
        v: !1
      };
      var p = null == (c = l.items) ? void 0 : c.reduce((function(t, n) {
        return t + Number(n.count)
      }), 0);
      if (p < m || p > h) return {
        v: !1
      };
      a += p;
      for (var k = function(n) {
          var r = l.items[n];
          if (!r) return {
            v: {
              v: !1
            }
          };
          var a = null == u ? void 0 : u.findIndex((function(t) {
            return t.groupId === l.groupId
          }));
          if (void 0 === a || -1 === a) return {
            v: {
              v: !1
            }
          };
          var f = e.default.getIn(u, [a, "items"]).find((function(t) {
              return t.id === r.id
            })),
            c = (null == o || null == (v = o.tasteGroupSetting) ? void 0 : v.repeatChoice) || g.repeatChoice;
          if (r.count > 1 && c === i.TASTE_REPEAT_CHOICE.SINGLE) return {
            v: {
              v: !1
            }
          };
          if (!f) return {
            v: {
              v: !1
            }
          };
          if (f.soldOut) return {
            v: {
              v: !1
            }
          };
          r.name !== f.name && (s = s.concat([t]));
          var d = -1 === f.maxBoughtCount ? 1 / 0 : f.maxBoughtCount,
            h = -1 === f.minBoughtCount ? 0 : f.minBoughtCount,
            m = -1 === f.stockCount ? 1 / 0 : f.stockCount,
            p = f.incBoughtCount,
            k = r.count;
          return k > d || k < h || k > m || (k - h) % p != 0 ? {
            v: {
              v: !1
            }
          } : void 0
        }, I = 0; I < (null == l || null == (d = l.items) ? void 0 : d.length); I++) {
        var C = k(I);
        if ("object" === n(C)) return C.v
      }
    }, l = 0; l < r.length; l++) {
    var c, d, v, g = f(l);
    if ("object" === n(g)) return g.v
  }
  if (null != o && o.tasteGroupSetting) {
    var h = o.tasteGroupSetting.maxChoice;
    if (a < (o.tasteGroupSetting.minChoice || i.NO_LIMIT_CHOICE) || a > (h && h !== i.NO_LIMIT_CHOICE ? h : 1 / 0)) return !1
  }
  return !0
}

function v(t, e, r, u) {
  if (!(e && e.length || r && r.length)) return !0;
  if (!r) return !e;
  for (var o = 0, a = function(u) {
      var i = e[u];
      if (!i) return {
        v: !0
      };
      var a = i.items.length;
      o += a;
      for (var f = function(n) {
          var e = i.items[n];
          if (!e) return {
            v: {
              v: !1
            }
          };
          var u = r.find((function(t) {
            return t.groupId === i.groupId
          }));
          if (!u || !u.items) return {
            v: {
              v: !1
            }
          };
          var o = u.items.find((function(t) {
            return t.id === e.id
          }));
          if (!o || o.soldOut) return {
            v: {
              v: !1
            }
          };
          e.name !== o.name && (s = s.concat([t]))
        }, l = 0; l < a; l++) {
        var c = f(l);
        if ("object" === n(c)) return c.v
      }
    }, f = 0; f < e.length; f++) {
    var l = a(f);
    if ("object" === n(l)) return l.v
  }
  if (null != u && u.methodGroupSetting) {
    var c = u.methodGroupSetting.maxChoice;
    if (o < (u.methodGroupSetting.minChoice || i.NO_LIMIT_CHOICE) || o > (c && c !== i.NO_LIMIT_CHOICE ? c : 1 / 0)) return !1
  } else {
    for (var d = function(t) {
        var n = r[t],
          u = -1 === (null == n ? void 0 : n.minChoice) ? 0 : null == n ? void 0 : n.minChoice;
        if (u > 0) {
          var i = e.find((function(t) {
            return t.groupId === n.groupId
          }));
          if (!i) return {
            v: !1
          };
          if (i.items.length < u) return {
            v: !1
          }
        }
      }, v = 0; v < r.length; v++) {
      var g = d(v);
      if ("object" === n(g)) return g.v
    }
    for (var h = function(t) {
        var n = e[t];
        if (!n) return {
          v: !0
        };
        var u = r.find((function(t) {
          return t.groupId === n.groupId
        }));
        if (!r) return {
          v: !1
        };
        var i = -1 === (null == u ? void 0 : u.maxChoice) ? 1 / 0 : null == u ? void 0 : u.maxChoice,
          o = -1 === (null == u ? void 0 : u.minChoice) ? 0 : null == u ? void 0 : u.minChoice;
        if (void 0 === i || void 0 === o) return {
          v: !1
        };
        var a = n.items.length;
        return a < o || a > i ? {
          v: !1
        } : void 0
      }, m = 0; m < e.length; m++) {
      var p = h(m);
      if ("object" === n(p)) return p.v
    }
  }
  return !0
}

function g(t, u, i) {
  var o = t.skuMenuItems.find((function(t) {
      return t.skuId === u.skuId
    })),
    a = function(t, n) {
      return n && t ? !t.validity || t.soldOut || t.canWeight && !n.weight || !t.canWeight && n.weight ? null : (t.skuName !== n.skuName && (s = s.concat([n]), n = e.default.set(n, "skuName", t.skuName)), n = r.default.updateMustCount(n)) : null
    }(o, u);
  return a = function(t, n) {
    if (!t || !n) return null;
    var e = -1 === t.minBoughtCount ? 0 : t.minBoughtCount,
      r = t.incBoughtCount;
    if (t.canWeight) {
      if ((n.weight || 0) < e) return null
    } else if (((n.count || 0) - e) % r != 0) return null;
    return n
  }(t, a), c.default.checkGrouponDishInfo(t) && !i ? null : a ? a = Array.isArray(a.packages) && a.packages.length > 0 ? function(t, r) {
    return function(t, r) {
      if (!t || !r) return null;
      var u = t.packageGroups,
        i = r.packages;
      if (!u || !i) return null;
      if (u.length !== i.length) return null;
      for (var o = 0; o < i.length; o++) {
        var a = i[o],
          l = u[o];
        if (Number(a.groupId) !== l.groupId) return null;
        if (a.groupName !== l.groupName) return null;
        var c = e.default.getIn(i, [o, "groupSkus"]),
          g = e.default.getIn(u, [o, "groupSkus"]);
        if (!c || !g) return null;
        for (var h = 0, m = function(t) {
            var n = c[t],
              u = g.find((function(t) {
                return t.skuId === n.skuId
              }));
            if (!n || !u) return {
              v: null
            };
            if (n.skuName !== u.skuName && (s = s.concat(r), n = e.default.set(n, "skuName", u.skuName)), n.number !== u.count) return {
              v: null
            };
            if (n.weight !== u.weight) return {
              v: null
            };
            var i = -1 === u.stockCount ? 1 / 0 : u.stockCount;
            return (n.weight && n.weight > 0 ? n.count * n.weight : n.count * n.number) > i ? {
              v: null
            } : v(r, n.methods, u.methods, null == u ? void 0 : u.spuGroupSetting) && d(r, n.tastes, u.tastes, null == u ? void 0 : u.spuGroupSetting) ? (n.count > 0 && (h += n.count), void(r = e.default.setIn(r, ["packages", o, "groupSkus", t], n))) : {
              v: null
            }
          }, p = 0; p < c.length; p++) {
          var k = m(p);
          if ("object" === n(k)) return k.v
        }
        for (var I = function(t) {
            var n = g[t],
              e = c.find((function(t) {
                return t.skuId === n.skuId
              }));
            if (n.required && (null == e || !e.count)) return {
              v: null
            }
          }, C = 0; C < g.length; C++) {
          var b = I(C);
          if ("object" === n(b)) return b.v
        }
        var N = (0, f.getPackageGroupLimitNum)(l),
          S = N.minCount,
          y = N.maxCount;
        if (h < S || h > y) return null
      }
      return r
    }(t, r)
  }(o, a) : function(t, n) {
    if (!t || !n) return null;
    if (!v(n, n.methods, t.methods, t.spuGroupSetting)) return null;
    var e = t.skuMenuItems.find((function(t) {
      return t.skuId === n.skuId
    }));
    return e || (e = t), d(n, n.tastes, t.tastes, t.spuGroupSetting) ? n : null
  }(t, a) : null
}

function h(t, n, r, u) {
  var i = (0, e.default)([]),
    o = (0, e.default)([]);
  if (t && t.validity && !t.soldOut ? n.forEach((function(n) {
      var e = g(t, n, u);
      e ? i = i.concat([e]) : o = o.concat([n])
    })) : (o = n, i = (0, e.default)([])), i && 0 !== i.length) {
    var a = (0, e.default)({});
    i.forEach((function(t) {
      var n = t.skuId;
      if (a[n]) {
        var r = a[n].concat([t]);
        a = e.default.set(a, t.skuId, r)
      } else a = e.default.set(a, n, [t])
    })), Object.keys(a).forEach((function(n) {
      var r = a[n],
        u = t.skuMenuItems.find((function(t) {
          return t.skuId === e.default.getIn(r, [0, "skuId"])
        }));
      if (u) {
        var f = -1 === u.stockCount ? 1 / 0 : u.stockCount,
          l = -1 === u.limitCount ? 1 / 0 : u.limitCount,
          c = u.orderedCount;
        if (0 === f || 0 === l) o = o.concat(r), i = i.filter((function(t) {
          return t.skuId !== e.default.getIn(r, [0, "skuId"])
        }));
        else if (t.canWeight) {
          var s = r[0];
          if (s.weight > f) {
            var d = e.default.set(s, "weight", f),
              v = i.findIndex((function(t) {
                return t.itemNo === d.itemNo
              }));
            i = e.default.set(i, v, d)
          }
        } else
          for (var g = r.reduce((function(t, n) {
              return t + (Number(n.count) || 0)
            }), 0), h = g > f, m = g + c > l, p = function() {
              var t = r[0],
                n = t.count,
                u = i.findIndex((function(n) {
                  return n.itemNo === t.itemNo
                }));
              (function(a) {
                if (a < n) {
                  var f = e.default.set(t, "count", n - a);
                  r = e.default.set(r, 0, f), i = e.default.set(i, u, f), g -= a
                } else r = r.slice(0), o = o.concat([t]), i = e.default.flatMap(i, (function(t, n) {
                  return n === u ? [] : t
                })), g -= n
              })(h ? g - f : g + c - l), h = g > f, m = g + c > l
            }; h || m;) p()
      }
    }))
  } else i = (0, e.default)([]);
  return o.length > 0 && o.forEach((function(t) {
    var n = r.findIndex((function(n) {
      return n.goodsNo === t.itemNo
    }));
    r = e.default.flatMap(r, (function(t, e) {
      return e === n ? [] : t
    }))
  })), {
    newCartSkuList: i,
    cartDishSortMapList: r
  }
}

function m(t, n, r) {
  if (-1 !== n.stockCount) {
    var u = n.stockCount,
      i = n.skuId;
    if (t[i]) {
      var o = t[i],
        a = e.default.set(o, "count", Number(e.default.getIn(t, [i, "count"]) || 0) + r);
      t = e.default.set(t, i, a)
    } else {
      var f = (0, e.default)({
        stockCount: u,
        count: r
      });
      t = e.default.set(t, i, f)
    }
  }
  return t
}

function p(t, n, r) {
  var u = r.tastes,
    i = n.tastes;
  if (!u || !u.length) return t;
  for (var o = function(n) {
      for (var r = u[n] || {}, o = function(n) {
          var u = e.default.getIn(r, ["items", n]) || {},
            o = null == i ? void 0 : i.findIndex((function(t) {
              return t.groupId === r.groupId
            })),
            a = null == (f = e.default.getIn(i, [o, "items"])) ? void 0 : f.find((function(t) {
              return t.id === u.id
            }));
          a && u && (t = m(t, a, u.count))
        }, a = 0; a < r.items.length; a++) o(a)
    }, a = 0; a < u.length; a++) {
    var f;
    o(a)
  }
  return t
}

function k(t, n, r) {
  for (var i = n.packageGroups || [], o = r.packages || [], a = 0; a < o.length; a++)
    for (var f = e.default.getIn(o, [a, "groupSkus"]), l = e.default.getIn(i, [a, "groupSkus"]), c = function(n) {
        var e = f[n],
          r = l.find((function(t) {
            return t.skuId === e.skuId
          })),
          i = r.canWeight ? (0, u.multiFloat)(e.count, e.weight) : e.count * e.number;
        if (e && r && i) {
          t = m(t, r, i);
          for (var o = 0; o < i; o++) t = p(t, r, e)
        }
      }, s = 0; s < f.length; s++) c(s);
  return t
}

function I(t) {
  if (!Object.keys(t).length) return !1;
  var n = !1;
  return Object.keys(t).forEach((function(e) {
    var r = t[e];
    r.count > r.stockCount && (n = !0)
  })), n
}