var t = require("../../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.setDishSize = exports.initCartSku = exports.hasMethods = exports.hasFeedingsNew = exports.getUnit = exports.getTastesText = exports.getSpecAttrsStyle = exports.getSelected = exports.getPackageOptionTitle = exports.getPackageGroupLimitText = exports.getPackageGroupLimitNum = exports.getOptionDishPriceStyle = exports.getMultiPanelReportConfig = exports.getMatchedSkuDish = exports.getMatchedMenuSku = exports.getGroupCouponNum = exports.getFeedingCount = exports.enablePlusSku = exports.checkGroupSkuLimit = void 0;
var e = require("../../b/helpers/objectSpread2"),
  u = require("../../constants/bizConstants"),
  r = require("../../constants/menu"),
  n = require("../cartHelper"),
  o = t(require("../../miniprogram_npm/seamless-immutable/index.js"));
exports.getGroupCouponNum = function(t, e) {
  var u = 0;
  return t && e && t.grouponCouponInfo && t.skuId === e.skuId && (u = t.grouponCouponInfo.length), u
};
exports.hasMethods = function(t, e) {
  if (!t) return !1;
  var u = !1;
  return t.map((function(t) {
    return t.id === e.id && (u = !0), !1
  })), u
};
exports.hasFeedingsNew = function(t, e, u, r) {
  return !!t && r > 0 && function(t) {
    return !!t && !(t.soldOut || 0 === t.stockCount)
  }(e)
};
exports.getFeedingCount = function(t, e, u) {
  if (!t) return 0;
  var r = t.tastes && t.tastes[e];
  if (!r) return 0;
  var n = 0;
  return r.map((function(t) {
    return t.id === u.id && (n = t.count), null
  })), n
};
exports.getPackageGroupLimitText = function(t) {
  var e = "" + t.groupLimit;
  return t.optionType === r.PACKAGE_OPTION_TYPE.RANGE && (e = "".concat(t.lowerCount, "~").concat(t.upperCount)), e
};
var i = function(t) {
  var e = t.groupLimit,
    u = e;
  return t.optionType === r.PACKAGE_OPTION_TYPE.RANGE && (e = t.lowerCount || 0, u = t.upperCount || 0), {
    minCount: e,
    maxCount: u
  }
};
exports.getPackageGroupLimitNum = i;
var s = function(t, e, u) {
  var r, n = (null == (r = t.find((function(t) {
    return t.groupId === e
  }))) ? void 0 : r.groupSkus) || [];
  return n.length && n.find((function(t) {
    return t.skuId === u.skuId
  })) || null
};
exports.getMatchedMenuSku = s;
exports.getSpecAttrsStyle = function(t) {
  var e = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
    u = e ? "specAttrs ellipsis" : "specAttrs";
  if (t && t.extraPrice) {
    var r = t.extraPrice.toString();
    r.length > 0 && 0 !== t.extraPrice ? 1 === r.length ? u += " spec-one" : 2 === r.length ? u += " spec-two" : 3 === r.length ? u += " spec-three" : u += " spec-max" : u += " spec-max"
  }
  return u
};
exports.getTastesText = function(t) {
  var e = [];
  if (t) {
    var u = t.methods,
      r = t.tastes;
    u && u.length > 0 && (null == u || u.map((function(t) {
      var u = Array.isArray(t) ? t : null == t ? void 0 : t.items;
      return null == u || u.map((function(t) {
        return e.push(t.name), null
      })), null
    }))), r && r.length > 0 && (null == r || r.map((function(t) {
      var u = Array.isArray(t) ? t : null == t ? void 0 : t.items;
      return null == u || u.map((function(t) {
        return e.push("".concat(t.name, "x").concat(t.count)), null
      })), null
    })))
  }
  return e.join("，")
};
var p = function(t) {
    var e = 0;
    return t.groupSkus && t.groupSkus.map((function(t) {
      return e += t.count, null
    })), e
  },
  a = function(t, e) {
    if (!e) return !1;
    var u = o.default.getIn(t, ["groupSkus"]),
      r = e.maxChoiceAmount,
      n = e.skuId,
      i = u.filter((function(t) {
        return t.skuId === n
      })).reduce((function(t, e) {
        return Number(t) + Number(e.count)
      }), 0);
    return r && -1 !== r && i >= r
  };
exports.checkGroupSkuLimit = a;
exports.enablePlusSku = function(t, e, n) {
  var s = t.groupChoiceType,
    l = t.optionType || r.PACKAGE_OPTION_TYPE.FIXED,
    c = null == n ? void 0 : n.find((function(e) {
      return e.groupId === t.groupId
    })),
    g = null == c ? void 0 : c.groupSkus.find((function(t) {
      return t.skuId === e.skuId
    })),
    d = i(t).maxCount,
    f = o.default.getIn(t, ["groupSkus"]).reduce((function(t, e) {
      return Number(t) + Number(e.count)
    }), 0),
    m = e.count,
    h = e.number,
    x = (s === u.GROUP_CHOICE_TYPE.REPEATABLE || s === u.GROUP_CHOICE_TYPE.NON_REPEATABLE && 0 === m) && f < d,
    v = l === r.PACKAGE_OPTION_TYPE.FIXED && 1 === t.groupLimit || p(t) < d,
    k = -1 === (null == g ? void 0 : g.stockCount) ? 1 / 0 : null == g ? void 0 : g.stockCount,
    P = !0;
  (k || 0 === k) && (P = (Number(m) + 1) * Number(h) <= k);
  var I = a(t, g);
  return x && v && P && !I
};
exports.getOptionDishPriceStyle = function(t) {
  var e = "option-dish-price";
  if (t) {
    var u = t.extraPrice + "";
    return u && u.length > 3 && (e += " column"), e
  }
  return ""
};
exports.getSelected = function(t) {
  var e = !1;
  return t ? (t.count > 0 && t.groupType === u.GROUP_TYPE.OPTIONAL && (e = !0), t.soldOut && (e = !0), e) : e
};
exports.getUnit = function(t, e) {
  var u = "",
    r = e ? !t.canWeight : !e;
  return t && t.unit && r && (u = "/" + t.unit), u
};
exports.initCartSku = function(t, u) {
  var r, n, i = !(null != u && u.methods) || (null == u ? void 0 : u.methods) && 0 === (null == u || null == (r = u.methods) ? void 0 : r.length),
    s = !(null != u && u.tastes) || (null == u ? void 0 : u.tastes) && 0 === (null == u || null == (n = u.tastes) ? void 0 : n.length),
    p = 0;
  if (i && s) return t;
  var a, l, c = [];
  null == u || null == (a = u.methods) || a.forEach((function(t) {
    var u = [];
    t.items.forEach((function(r) {
      r.defaultSelected && (u.push(e(e({}, r), {}, {
        groupId: t.groupId,
        groupName: t.groupName
      })), p += r.price)
    })), c.push(u)
  }));
  var g = [];
  return null == u || null == (l = u.tastes) || l.forEach((function(t) {
    var u = [];
    t.items.forEach((function(r) {
      r.defaultSelected && !r.soldOut && (u.push(e(e({}, r), {}, {
        count: 1,
        groupId: t.groupId,
        groupName: t.groupName
      })), p += r.price)
    })), g.push(u)
  })), o.default.merge(t, {
    methods: c,
    tastes: g,
    extraPrice: p
  })
};
exports.getMultiPanelReportConfig = function(t, e) {
  var r = {};
  return e && Object.keys(t).length && (r = {
    t: Date.now(),
    spuId: t.spuId,
    skuId: t.skuId,
    isRecommend: e === u.DISH_ADD_FROM.BOSS_RECOMMEND,
    fromNetRecommend: e === u.DISH_ADD_FROM.DP_RECOMMEND,
    addFrom: e
  }), r
};
exports.getPackageOptionTitle = function(t) {
  var e = [],
    u = p(t) || 0,
    r = i(t),
    n = r.minCount,
    o = r.maxCount,
    s = (null == t ? void 0 : t.groupHeadDesc) || "",
    a = [],
    l = [];
  return u && (u >= n || u <= o) && a.push({
    type: "sub",
    text: "已选"
  }, {
    type: "num",
    text: " ".concat(u, " ")
  }, {
    type: "sub",
    text: "份"
  }, {
    type: "sub",
    text: ")"
  }), s ? (l.push({
    type: "sub",
    text: "(" + s
  }), a.length ? (a.unshift({
    type: "sub",
    text: "，"
  }), e = l.concat(a)) : (l.push({
    type: "sub",
    text: ")"
  }), e = l)) : a.length && (a.unshift({
    type: "sub",
    text: "("
  }), e = a), e
};
exports.setDishSize = function(t, e) {
  var r = "mini",
    o = !1,
    i = !1,
    p = t.groupId,
    a = t.groupSkus;
  return null == a || a.forEach((function(t) {
    var u, r = s(e, p, t),
      a = (0, n.selectTastes)(r),
      l = ((u = null == t ? void 0 : t.skuName) ? u.replace(/[^\x00-\xff]/g, "01").length : 0) > 16;
    !o && a && (o = !0), !i && l && (i = !0)
  })), (null == t ? void 0 : t.groupType) === u.GROUP_TYPE.FIXED ? (i || o) && (r = "large") : r = "middle", r
};
exports.getMatchedSkuDish = function(t, e, u) {
  var r, n = [];
  return null == t || null == (r = t.packageGroups) || r.forEach((function(t) {
    var r;
    t.groupId === Number(e) && (null == t || null == (r = t.groupSkus) || r.forEach((function(t) {
      t.skuId === u && n.push(t)
    })))
  })), n
};