var e = require("../../../b/helpers/typeof"),
  a = [40, 31, 13, 3, 84, 7, 12, 6, 5, 0, 1, 3, 3, 36, 5, 19, 37, 51, 3, 0, 29, 1, 24, 35, 5, 4, 27, 17, 34, 5, 10, 48, 31, 13, 3, 87, 7, 12, 6, 5, 48, 44, 13, 40, 27, 20, 16, 2, 7, 12, 5, 3, 16383, 18, 5, 55, 42, 39, 22, 10, 0, 13, 10, 0, 14, 31, 21, 0, 19, 3, 10, 84, 8, 12, 32, 4, 23, 10, 0, 6, 16, 2, 29, 4, 24, 5, 4, 26, 4, 28, 9, 20, 1, 16, 33, 20, 0, 23, 20, 0, 43, 13, 20, 256, 11, 8, 18, 13, 3, 8, 17, 8, 9, 20, 0, 1, 8, 13, 20, 256, 11, 8, 22, 6, 8, 17, 8, 32, 5, 40, 0, 2, 31, 14, 21, 7, 35, 12, 16, 24, 45, 0, 23, 40, 14, 19, 17, 34, 37, 2, 26, 9, 32, 25, 4, 35, 44, 22, 13, 7, 4, 27, 1, 7, 15, 8, 1, 31, 1, 3, 1, 28, 7, 15, 10, 8, 1, 31, 1, 3, 1, 43, 33, 1, 0],
  c = "6708050d020413 14617a7071727d7a7170 c1a4b9b1aeb3b5b2 1472617a77607d7b7a 56373b32 a2c4cbccc5c7d0 41203131 dfbbb9afb6bb 46202f2a23322f2b23 5d3b2d2b 204c4f43414c4944 6b1812181f0e06 45312c28203631242835 dfbaa7ab d4a7b1a7a7bdbbba9db0 f8999b9b9d949d8a97959d8c9d8a 66070a04130b2713120e09140f1c0302 8bc9eaffffeef9f2c2e5ede4 3e5c5f4a4a5b4c47725b485b52 480a2d292b27263b 6002050e03080d01120b2c0516050c caa8a6bfafbea5a5bea28fa4aba8a6afae dbb9a9bab5bf 5436263d333c203a312727 6c0f0d01091e0d2d191804031e05160908 b0d3dfddc0d1c3c3 513534273832341e2338343f253025383e3f cbafaebda2a8ae9ba2b3aea799aabfa2a4 c4a1aaa5a6a8a180a1a6b1a3 305542427d4357 cea8a1a0ba9da7b4ab9dabbabaa7a0a9 1c707d727b697d7b79 ce82afbba0ada681bebaa7a1a0bd9db7a0ad 2945464a485d404647685c5d41465b40534c4d 0864676b697c6167664d66696a646d6c 7d11121e1c091412132f1819081e18193c1e1e080f1c1e04 523f3b31203d223a3d3c371327263a3d203b283736 d4b9bbb0b1b8 137d7667647c6178476a6376 d6b8b9a2bfb0bfb5b7a2bfb9b897bab3a4a297a3a2beb9a4bfacb3b2 8ee0e1fae7e8e7edeffae7e1e0cffbfae6e1fce7f4ebea 87e9e8f3eee1eee4e6f3eee8e9c5e6e3e0e2c6f2f3efe8f5eefde2e3 1a74756e737c73797b6e73757449756f747e5b6f6e72756873607f7e a6d6cfdec3caf4c7d2cfc9 84f4e8e5f0e2ebf6e9 d0a3b1b6b591a2b5b1 f586968790909bbd909c929d81 ed9e8e9f888883b9829d 1467776671717a437d70607c 491a0d021f2c3b3a202627 4d3e392c39383e0f2c3f0528242a2539 d0a3a9a3a4b5bd 56203324253f3938 b2c5dbd4dbf7dcd3d0ded7d6 a5f2ccc3cceccbc3ca daadb3b4beb5ad92bfb3bdb2ae c3b4aaada7acb494aaa7b7ab a2d1c1d0c7c7ccf0c7c1cdd0c6 aacfd8d8e7d9cd 721b01311a1300151b1c15 3b575e4d5e57 375b525143 8ffde6e8e7fb dda9b2ad c1a3aeb5b5aeac d0a7b9b4a4b8 a2cac7cbc5cad6 82d1d1cbc6 a1e3f2f2e8e5 650410110a2f0a0c0b0001 384b515f5659546b4c4a5d565f4c50 7218070106381d1b1c1716 3c4f595f494e59 731501160206161d100a 91e2e5e3f8fff6f8f7e8 d5b1babbb0 90e6f1fce5f5 f5b994809b969dba85819c9a9b86a68c9b96 a7d7c6d5d4c2 7a090e0813141d131c03 e999889d81 c2b1a1a7aca7 1b7a78787e777e6974767e6f7e69 f49d87b58686958d dbb7beb5bcafb3 34505b5a51 d6a0b7baa3b3 9bebeee8f3 cc8eadb8b8a9beb585a2aaa3 baedd3dcd3f3d4dcd5 d7a4b6b1b296a5b2b6 bbc8cfc9d2d5dc a8d8c9dadbcd b9d6dbd3dcdacd 552520263d 4c3c393f24 47030117 abced3dbc4d9dfd8 53362b233c212720 4e2c2b392f3c2b 97aea6d2d5d6a1d3d5d2a3d2a2d6a0d4afd2a1d2a4d6a4d4a6d1a3d6a3d3d1d1aed2ae 692a5c2f5c2f2d2f5c2f5b2f5c2f5a2f5c2f592f5c2f582f5c2f5f2f5c2f5e2f5c2f5d 7f131a11180b17 f79b929990839f 9aaae2 8ffcfaedfcfbfd c7f7bf 16757e77645762 9dfef5fcefdce9 6b0d19040628030a1928040f0e 2050555348 54373b303137 d8adacbee08bacaab1b6bf 73071c311a0700 3f5c505b5a5c 82f7f6e4bad1f6f0ebece5 21554e63485552 0e6d677e666b7c a4c5c1d7 a2cfcdc6c7 85e6e7e6 6d08030e1f141d19 9af9f5fefff9 77151604124143 2543574a48674c5156 0d3c233a233f ba8b948d9488 c3b3b1aca7 86eef2f2f6f5a3b5c7a3b4c0a3b4c0e7f6f6f5e3e5abebe9e4efeae3a8ebe3eff2f3e7e8a8e5e9eb 2450415750 e68e92929695c3d5a7c3d4a0c3d4a0879696958385cb8b89848f8a83c8958385c892839592c89587888d93878fc885898b 33565d45 fb8b89949f cdaeacaea5a886a8b4 deeaeebfefeebabbec ccbcbea3a8 45202b33 e292908d86 2f5b4a5c5b 80f3f9f3f4e5ed 197f696f f1a6a9aeae879483c0dfc3dfc1aeb2b2b2b2ae 741a1b03 e589808b82918d caa9a2abb889a5aeaf8bbe 46252e2734052922230732 91f7e3fefcd2f9f0e3d2fef5f4 f486959a909b99 ddb0b2b9b8b1 6d1e141e190800 c7aaa8a3a2ab 0e7d777d7a6b63 26555f5552434b 7e0a17131b0d0a1f130e f6829f9b938582979b86 eb849b8e85828f 94fbe4f1fafdf0 92fff6a7 10636462447f4528 6c1f181e05020b050a15 ddbeb2b3bebca9 b6c5c2c4 35415a6641475c5b52 b1c2ddd8d2d4 eb8f8d9ba28f f7839e9a928483969a87 731f1c10121f3a17 402426300924 bccfd9cecad9cee8d5d1d9f8d5dada 5d3439 dcb8baac95b8 107c7f73717c5974 1064797d756364717d60 e9808d 026b66 88e1ec d7a4b2a5a1b2a583bebab293beb1b1 d8b1bc 790a1c0b0f1c0b2d10141c3d101f1f e1868495a7888d84b2989295848cac808f80868493 3744435643644e5954 2d48435b 63363026313c272237223c3322372b 472b2634330624242234342223132e2a22 2844495b5c65474c414e414d4c7c41454d 274a484342 6a1903100f 8dfdffe2f9e2f9f4fde8 1576747979 28585d5b40 d9a9acaab1 0f7f607f 5e323b30392a36 a1cdc4cfc6d5c9 1c7079727b6874 c4b4b1b7ac 670b020900130f 85e9e0ebe2f1ed d7bbb2b9b0a3bf 6408010a03100c a5c9c0cbc2d1cd 9df1f8f3fae9f5 4e222b20293a26 067673756e f599909b92819d f39f969d94879b 4f232a21283b27 a6cac3c8c1d2ce 2e485d43414a4b 95f4e5e5 7c1d0c0c3518 b0dfc0d5ded9d4 a2cdd2c7ccebc6 bdc8d3d4d2d3d4d9 97e2f9fef8f9def3 167b757e7f72 f39e909bba97 c7a3a1b7aea3 492d2f39002d 9af6f5f9fbf6f3fe e985868a8885a08d fe9897929b8a97939b 34405d59514740555944 58393c3c1d2a2a372a 3156544577585f56544303 94fbfad7fbf9e4f5e7e7d7fcf5faf3f1 7b141d1d3814160b1a080838131a151c1e d8aba1abacbdb5 6e0d01031e0f1d1d abd8d2d8dfcec6 284b474558495b5b 1b6862686f7e76 bcdfd3d1ccddcfcf 5d3138333a2935 4b2824263b2a3838 87f4efeee1f3 c5b6bcb6b1a0a8 3754585a47564444 334346405b 3d59544f585e49545253 a8dcc7eec1d0cdcc 16797070577575737a7364797b73627364557e77787173 05767c76716068 d0b1b3b3b5bcb5a2bfbdb5a4b5a2 4f3c363c3b2a22 6e0f0d0d0b020b1c01030b1a0b1c d9aaa0aaadbcb4 ec8d8f8f8980899e83818998899e f98a808a8d9c94 67060404020b0215080a02130215 53203b3a3527 98ebe1ebecfdf5 cdacaeaea8a1a8bfa2a0a8b9a8bf c6b6b3b5ae 275348614e5f4243 ee9a81a887968b8a 196d765f70617c7d 1c73725b656e736f7f736c795f747d727b79 e28d8484a59b908d91818d9287a18a838c8587 33404a4047565e 62051b100d 6c1f151f180901 3e59474c51 5c2f252f283931 2a4d535845 b1ddd4dfd6c5d9 593e202b36 94e7fcfdf2e0 ef9c969c9b8a82 8ee9f7fce1 88f8fdfbe0 0f7b604966776a6b 8cf8e3cae5f4e9e8 4c38230a25342928 4d2e2c2e2528062834 2e4a4f5a4f 9efaffeaff 3d595b4d 8be5fee6e9eef9 badedbcedb 640d0a100116120508 8befeaffea 3043554246554264595d554344515d40 f59b8098979087 0f6b6e7b6e 6013051216051234090d051314010d10 4125203520 1063756266756244797d756364717d60 c9a7a6be 670301172e03 7115100510 87e3e1f7 7102140307140325181c1435181717 b7d2cfc7dec5d6c3ded8d9e3dedad2 5b3f3a2f3a 452c2b312037332429 eb85849c 7b1f1a0f1a 0e6a687e b5d4d1d1f4c5dc f4909284ab9092849d90 c0aeafb7 0a6d6f7e4c7f6666536f6b78 016664754c6e6f7569 fa9d9f8ebe9b8e9f 4f282a3b07203a3d3c 214644556c484f54554452 1b7c7e6f487e7874757f68 4927263e 375d4450615245445e5859 96f2f7e2f7 096c717d e48297898b8081 fc8f889d9f97 5c3f33323f3d28 4c2f2328292f 2e5b5a48167d5a5c474049 1e6a715c776a6d cbb8bfb9a2a5aca2adb2 2c465f484a5c7a495e5f454342 a1d5c8ccc4 412e32 e28f8f92 730416101b1207 1163746064746265 0a2f384c7c3b2f384c7d726e6c7a636e 5707180403 432233332f2a2022372a2c2d66710529302c2d d2a0b7a2bda0a686bbb1b9 3d4e495c49484e7e525958 b5d1d4c1d4 b2d6d3c6d3 4226233623 55363a3130 c5a1a4b1a4 8cefe3e8e9 accdc8c8eddcc5 701416002f021501 8af9feebfefff9c9e5eeef 0866677f 78191c1c390811 bfdbd9cfe0cddacee0d3dad1d8cbd7 b6c5c2c4dfd8d1dfd0cf e68a838881928e 117075755463637e63 70141f2215001f02043600 0362676742736a 2b4f4d5b74594e5a c1afaeb6 b6d2d0c6e4d3c6d9c4c2d3d2 b7ded3 a7c2dfd7ced5c6d3cec8c9f3cecac2 4f392e233a2a0029 22475a524b5043564b4d4c764b4f47 bbdfddcbe9decbd4c9cfdedf debfadadb7b9b0 96e4f3e6f9e4e2c2fff5fd 8ffcf6fcfbeae2e6e1e9e0 086f6d7c5b717b7c6d6541666e67 582b212b2c3d35 0f616a7b78607d6466616960 9ff8faebd1faebe8f0edf4cbe6effa c5aba0b1b2aab7ae91bcb5a0 7b1909121c130f151e0808 1d7a78694e7e6f7878735f6f747a756973786e6e 5634243f313e2238332525 b5c6c1dac7d4d2d0dcdbd3da 57303223042338253630321e393138 590a2d362b383e3c10373f36 98fafdf9fbf7f6eb 1a7d7f6e587f7b79757469 a4e6c1c5c7cbcad7 ee9d8b828b8d9a8b8a9a8b969a9c8f80898b deb9bbaa8dbbb2bbbdaabbba8abba6aa8cbfb0b9bb 7122141d14120514152514090523101f1614 f29e93879c919a9d82869b9d9c81818b9c91 ee898b9aa28f9b808d86a19e9a8781809dbd97808d afe3cedac1ccc7e0dfdbc6c0c1dcfcd6c1cc 4123203535243338282f272e adcac8d9efccd9d9c8dfd4e4c3cbc2 d99bb8adadbcaba090b7bfb6 1261716077777c4077717d60767b7c754166736677 4027253413233225252e1225232f3224292e271334213425 780b1b0a1d1d162a1d1b170a1c11161f2b0c190c1d 84f4f1f7ec 89fce7edecefe0e7eced 89f9fcfae1 d1bfa4bdbd d3bcb1b9b6b0a7 6c1c191f04 e79493958e89808e819e fc9a938eb99d9f94 a4d4d1d7cc 5724273b3e23 87ebe2e9e0f3ef 99eae9f5f0ed 375b525950435f ee9c8b9e828f8d8b 91fdf4fff6e5f9 730306001b e1948f858487888f8485 2d5d585e45 f28097829e939197 671712140f 83efe6ede4f7eb 51323930231025 fc9f949d8ebd88 afccc7ceddeedb bacacfc9d2 b5c5c0c6dd a2c1cac3d0e1cdc6c7e3d6 fc9099929b8894 780b14111b1d e28e878c85968a 27444f46556653 bdded5dccffcc9 8ffffafce7 fb899e8b979a989e 705542454241 215344514d404244 fbdec9cec9cc f38196839f929096 81a4b3b4b3b9 4436213428252721 eecbdcdbdcd7 ef9d8a9f838e8c8a 624750575023 fc8c898f94 98f2f7f1f6 e38293938f8a8082978a8c8dc6d1a59bce949494ce858c918ece96918f868d808c878687 1879686874717b796c7177763d2a5e726b7776 08636d717b dfb3bab1b8abb7 72111d1c06171c065f060b0217 86f2e9cae9f1e3f4c5e7f5e3 bcc8d3f0d3cbd9ceffddcfd9 790a0d180b0d0a2e100d11 b9d7d6ce ea9f848e8f8c83848f8e 4d3a282f 7f0a111b1a1916111a1b aac7def9cfc9dfd8c3ded3f9c3cdc4 a3ced7f0c6c0d6d1cad7daf0cad6c2 284a10 deb6bbbfbabbac 523f37263a3d36 7a3d3f2e 95e1fac0e5e5f0e7d6f4e6f0 3e797b6a 094e4c5d 0670676a73634960 c0a6a9aea7a5b2 02717666 6015120c f89c998c99 630b0602070611 a7c8c5cdc2c4d3 f39b9692979681 91f9f4f0f5f4e3 d8bda0bdbb 6a2d2f3e e689848c838592 264d435f55 7d1118131a0915 395f564b7c585a51 7b131a08340c152b09140b1e090f02 196a6d6b70777e 513e333b343225 770702041f bfd9d0cdfadedcd7 bbcbcec8d3 355f5a5c5b b5d6dadbd6d4c1 14677b6660 2a4c45586f4b4942 98e8edebf0 9ff5f0f6f1 96d1d3c2 7b080f0912151c d0a0a5a3b8 8aebfafae6f3 1d6d686e75 6d0c1d1d0114 d4a7a0a6bdbab3bdb2ad 0b7b7e7863 eb8a9b9b8792 d7a2b9b3b2b1beb9b2b3 bad6dfd4ddced2 28444d464f5c40 c6b4a9b3b2a3 3d5f0f 8be1e9 bccbdf fb8b98 c8bfb0 d9bcb7af 84e1eaf2 583f3d2c172f36082a37283d2a2c211c3d2b3b2a31282c372a 4e292b3a0f2d2d213b203a072028211d37202d 0671746f7267646a63 e4918a8081828d8a8180 721704131e 75060114161e c1b2b5a0a2aa 630a0d000f16070610 d6b7a6a6fba5b3a4a0bfb5b3 05767164666e a2cbccc1ced7c6c7d1 26475656554354504f4543 3b4f54684f4952555c d2bbbcb1bea7b6b7a1 391c0c7b57584d504f5c1c0b095a565d5c1c0c7d 167c74 116672 c0b7a3 cbbca8 ea8e8f889f8d cabaa9 245447 88feedfafbe1e7e6fb 354556 33455641405a5c5d40 335d5c5756 53242b 9ef9fbead1e9f0ceecf1eefbeceae7dafbedfdecf7eeeaf1ec 1b6f74486f6972757c eb828588879e8f8e98 2e0b1b6c404f5a47584b0b1c1e4d414a4b0b1b6a a2c7ccd4 8eede1e0edeffa 0d606938 f98a8c9b8a8d8b90979e 136366607b 315041415d48 f78782849f ef8e9f9f8396 3040454358 364643455e 7e5b4d3a5b4d3a 641411170c 6802070106 3c5f53525f5d48 214d444f465549 7b171e151c0f13 c5b5b0b6ad 06656e6774456962634772 325f5607665d7a574a 6b080405080a1f 03606c6d606277 335e5243 d2b8bdbbbc 5e3f6f 7f1e4d 02646b6c656770 ea8bd9 18792c 056430 660750 58396f 146c24 cfaefe 9afba8 7e1f4d 452471 87e6b0 d1bcb5e490a3a3b0a8 acd49c 7c044c f692c7 771a134223183f120f c3a2a7a786b1b1acb1 a7c4c6cbc4cad3c0d4cec0 ec9f989e85828b858a95 78101d191c1d0a 2c41584b5f454b 472b222920332f 30515454714059 c9adafb996baa0aea796a5aca7aebda1 6f030a01081b07 e8898c8ca99881 c3a7a5b39cb0aaa4ad 36585941 78191c1c3d0a0a170a ccbfadaaa99fa5aba29ba5b8a49fa5b9ad 1c7d78785d6c75 533735230c203a343d b7d9d8c0 a8dacdd9ddcddbdc 097a7d7b60676e 59353c373e2d31 e3808b8291a08c8786a297 cba7aea5acbfa3 a8c4cdc6cfdcc0 315f5e46 7d1618040e 8be7eee5ecffe3 563461 72141e1d1d00 fb95948c 06756f6168 daa9b3bdb48db3aeb289b3afbb e290879397879196 6210071317071116350b160a310b1703 b7d1ded9d0d2c5 0f696661686a7d 5a37233d2f3b283e 96f1f3e2d7f5f5f9e3f8e2dff8f0f9c5eff8f5 751210013416161a001b013c1b131a260c1b16 e381d2 9ef3f7f0f7ceecf1f9ecfff3 b9d4d0d7d0e9cbd6decbd8d4 a8c9d8d8e1cc 7b1d12151c1e09 f4999d9a9da4869b93869599 741504043d10 771a1e191e2705181005161a 264756566f42 85e4f5f5ece1 badcd3d4dddfc8 86e7f6f6efe2 cdacbdbda4a9 4926392c27202d 741642 d2bda2b7bcbbb6 9bfdf2f5fcfee9 c5aab5a0abaca1 f782999e98999e93 d2b4bbbcb5b7a0 96e3f8fff9f8fff2 c2afa1aaaba6 45232c2b222037 a2cfc1cacbc6 cabfb9afb8a3a4aca5 d8beb1b6bfbdaa dfacaa 7e0b0d1b0c17101811 d2a1aba1a6b7bfbbbcb4bd 03707a7077666e6a6d656c c0aea5b4b7afb2aba9aea6af a0cec5d4d7cfd2cbe9cec6cf 4d2f3f242a253923283e3e c7a5b5aea0afb3a9a2b4b4 f59794818190878c9c9b939a 357754414150474c7c5b535a 7b080f14091a1c1e12151d14 c390b7acb1a2a4a68aada5ac 0b696e6a68646578 d795b2b6b4b8b9a4 3142545d54524554554554494543505f5654 a3f0c6cfc6c0d7c6c7f7c6dbd7f1c2cdc4c6 274b465249444f4857534e484954545e4944 a7ebc6d2c9c4cfe8d7d3cec8c9d4f4dec9c4 0e7967686767606861 91c6f8f7f8d8fff7fe 01766867684d687275 f88f919e91b4918b8c c3a8a6bab0 74121b063115171c 67010e09000215 cbb8af e28d92878c8b86 89faecfddbe8f9fde6fbcae6e7efe0ee 0e617962 e98087809daa889d 18776f74 0167686f666473 c8a7bfa4 86e9f1ea 2a4b4e4e6b5a43654840 3e5f5a5a7f4e57715c54 d9b8bdbd9cababb6ab96bbb3 a2c3c6c6e7d0d0cdd0edc0c8 d5b2b0a186b0a6a6bcbabb9cb1 26404f48414354 90e3e3 34415a5051525d5a5150 abc8c7c2c8c0ffd9cac8c0 1d73724d6f726564 94fdfafde0c4e6fbeced caaeacbaa3ae b5d4c5c5dcd1 722d001302061d00 264f484f52754348554954 eb8d82858c8e99 4b292224 b1d8dfd8c5fcfce1f9dec3df 1876776f 086e61666f6d7a f6919f85 3352575772435a abcfcddbf4c2c5c2df cfa1a0b8 c5abaab2 76101f18111304 71101515300118 a3c7c5d3fcd0cad6c2 81efeef6 eb8a8f8faa9b82 503436200f233925310f3c353e372438 5f383a2b13303c3e2b363031 9df9f8fbf4f3f8cdeff2edf8efe9e4 791e1c0d35161a180d101617 2152544242445252 0d7e786e6e687e7e f99a989595 cbada2a5acaeb9 593829293520 097a607c685d60646c7b 096f60676e6c7b d1b0b5b590a1b8 650103153a0c0b0c11361c0b06 e48a8b93 ceaaa8be8da2a7ada59abcafada5 660f080f123614091e1f".split(" "),
  n = function e(a, n) {
    n = c[a -= 0], void 0 === e.ImcGWb && (e.NxJiNf = function(e) {
      for (var a = "", c = e.length, n = parseInt("0x" + e.substr(0, 2)), t = 2; t < c; t += 2) {
        var f = parseInt("0x" + e.charAt(t) + e.charAt(t + 1));
        a += String.fromCharCode(f ^ n)
      }
      return decodeURIComponent(a)
    }, e.PFEpvF = {}, e.ImcGWb = !0);
    var t = e.PFEpvF[a];
    return void 0 === t ? (void 0 === e.kIuJcP && (e.kIuJcP = !0), n = e.NxJiNf(n), e.PFEpvF[a] = n) : n = t, n
  };
! function(a, c) {
  n(0) == ("undefined" == typeof exports ? "undefined" : e(exports)) && n(1) != ("undefined" == typeof module ? "undefined" : e(module)) ? module[n(2)] = c() : n(3) == ("undefined" == typeof define ? "undefined" : e(define)) && define[n(4)] ? define(c) : (a = a || self)[n(5)] = c()
}(void 0, (function() {
  function c(e, a) {
    var c = e[0],
      n = e[1],
      t = e[2],
      i = e[3];
    n = o(n = o(n = o(n = o(n = d(n = d(n = d(n = d(n = r(n = r(n = r(n = r(n = f(n = f(n = f(n = f(n, t = f(t, i = f(i, c = f(c, n, t, i, a[0], 7, -680876936), n, t, a[1], 12, -389564586), c, n, a[2], 17, 606105819), i, c, a[3], 22, -1044525330), t = f(t, i = f(i, c = f(c, n, t, i, a[4], 7, -176418897), n, t, a[5], 12, 1200080426), c, n, a[6], 17, -1473231341), i, c, a[7], 22, -45705983), t = f(t, i = f(i, c = f(c, n, t, i, a[8], 7, 1770035416), n, t, a[9], 12, -1958414417), c, n, a[10], 17, -42063), i, c, a[11], 22, -1990404162), t = f(t, i = f(i, c = f(c, n, t, i, a[12], 7, 1804603682), n, t, a[13], 12, -40341101), c, n, a[14], 17, -1502002290), i, c, a[15], 22, 1236535329), t = r(t, i = r(i, c = r(c, n, t, i, a[1], 5, -165796510), n, t, a[6], 9, -1069501632), c, n, a[11], 14, 643717713), i, c, a[0], 20, -373897302), t = r(t, i = r(i, c = r(c, n, t, i, a[5], 5, -701558691), n, t, a[10], 9, 38016083), c, n, a[15], 14, -660478335), i, c, a[4], 20, -405537848), t = r(t, i = r(i, c = r(c, n, t, i, a[9], 5, 568446438), n, t, a[14], 9, -1019803690), c, n, a[3], 14, -187363961), i, c, a[8], 20, 1163531501), t = r(t, i = r(i, c = r(c, n, t, i, a[13], 5, -1444681467), n, t, a[2], 9, -51403784), c, n, a[7], 14, 1735328473), i, c, a[12], 20, -1926607734), t = d(t, i = d(i, c = d(c, n, t, i, a[5], 4, -378558), n, t, a[8], 11, -2022574463), c, n, a[11], 16, 1839030562), i, c, a[14], 23, -35309556), t = d(t, i = d(i, c = d(c, n, t, i, a[1], 4, -1530992060), n, t, a[4], 11, 1272893353), c, n, a[7], 16, -155497632), i, c, a[10], 23, -1094730640), t = d(t, i = d(i, c = d(c, n, t, i, a[13], 4, 681279174), n, t, a[0], 11, -358537222), c, n, a[3], 16, -722521979), i, c, a[6], 23, 76029189), t = d(t, i = d(i, c = d(c, n, t, i, a[9], 4, -640364487), n, t, a[12], 11, -421815835), c, n, a[15], 16, 530742520), i, c, a[2], 23, -995338651), t = o(t, i = o(i, c = o(c, n, t, i, a[0], 6, -198630844), n, t, a[7], 10, 1126891415), c, n, a[14], 15, -1416354905), i, c, a[5], 21, -57434055), t = o(t, i = o(i, c = o(c, n, t, i, a[12], 6, 1700485571), n, t, a[3], 10, -1894986606), c, n, a[10], 15, -1051523), i, c, a[1], 21, -2054922799), t = o(t, i = o(i, c = o(c, n, t, i, a[8], 6, 1873313359), n, t, a[15], 10, -30611744), c, n, a[6], 15, -1560198380), i, c, a[13], 21, 1309151649), t = o(t, i = o(i, c = o(c, n, t, i, a[4], 6, -145523070), n, t, a[11], 10, -1120210379), c, n, a[2], 15, 718787259), i, c, a[9], 21, -343485551), e[0] = c + e[0] & 4294967295, e[1] = n + e[1] & 4294967295, e[2] = t + e[2] & 4294967295, e[3] = i + e[3] & 4294967295
  }

  function t(e, a, c, n, t, f) {
    return ((a = (a + e & 4294967295) + (n + f & 4294967295) & 4294967295) << t | a >>> 32 - t) + c & 4294967295
  }

  function f(e, a, c, n, f, r, d) {
    return t(a & c | ~a & n, e, a, f, r, d)
  }

  function r(e, a, c, n, f, r, d) {
    return t(a & n | c & ~n, e, a, f, r, d)
  }

  function d(e, a, c, n, f, r, d) {
    return t(a ^ c ^ n, e, a, f, r, d)
  }

  function o(e, a, c, n, f, r, d) {
    return t(c ^ (a | ~n), e, a, f, r, d)
  }

  function i(e) {
    var a, n = e.length,
      t = [1732584193, -271733879, -1732584194, 271733878];
    for (a = 64; a <= e.length; a += 64) {
      var f, r = e.subarray(a - 64, a),
        d = [];
      for (f = 0; 64 > f; f += 4) d[f >> 2] = r[f] + (r[f + 1] << 8) + (r[f + 2] << 16) + (r[f + 3] << 24);
      c(t, d)
    }
    for (e = e.subarray(a - 64), f = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], a = 0; a < e.length; a++) f[a >> 2] |= e[a] << (a % 4 << 3);
    if (f[a >> 2] |= 128 << (a % 4 << 3), 55 < a)
      for (c(t, f), a = 0; 16 > a; a++) f[a] = 0;
    return f[14] = 8 * n, c(t, f), t
  }

  function b(e) {
    for (var a = 0; a < e.length; a++) {
      for (var c = a, n = e[a], t = "", f = 0; 4 > f; f++) t += ye[n >> 8 * f + 4 & 15] + ye[n >> 8 * f & 15];
      e[c] = t
    }
    return e.join("")
  }

  function s() {
    return "undefined" != typeof mmp
  }

  function u(e) {
    if ((e = !xe && !0 === Se) && (je.biocode = 9, xe = !0, O("1|2|3|4"), A(), e = Ne), e) try {
      clearTimeout(Ne)
    } catch (e) {}
  }

  function h(e, a) {
    var c = "https://portal-portm.meituan.com/horn/v1/modules" + ("prod" === Je.env ? "/JSGuard_Bioanalysis/" : "/JSGuard_Bioanalysis_Test/") + Je.env;
    try {
      var n, t = Date.now();
      wx.request({
        url: c,
        method: "GET",
        data: (n = {}, n.jsguardApp = e, n.uuid = a, n.jsguardV = Je.ver, n.os = Te.pid, n.ox = s() ? "2" : "1", n),
        header: {
          "content-type": "application/json"
        },
        success: function(e) {
          try {
            var a = 0;
            if (200 === e.statusCode) {
              var c = e.data.raptor_sample;
              pe && pe.updatePatioRule && pe.updatePatioRule(c);
              var n = e.data.jsguard_dynamic_bio_keys;
              if (n) {
                var f = JSON.parse(n) || n;
                f ? Object.assign(Te.config, f) : a = 9402
              } else a = 9401
            }
            s() || l(), pe && pe.addApi("dfp_bio_horn", e.statusCode, a, Date.now() - t, .1)
          } catch (e) {
            pe && pe.addApi("dfp_bio_horn", 200, 9403, Date.now() - t)
          }
        },
        fail: function(e) {
          e = e.errno ? e.errno : 200, pe && pe.addApi("dfp_bio_horn", e, 9405, Date.now() - t), s() || l()
        }
      })
    } catch (e) {
      pe && pe.addError("initHorn", e)
    }
  }

  function l() {
    try {
      wx.getPrivacySetting ? wx.getPrivacySetting({
        success: function(e) {
          e.needAuthorization || p()
        }
      }) : p()
    } catch (e) {}
  }

  function p() {
    1 == Te.config.valid && 0 <= Te.config.start_delay && 0 < Te.config.duration && setTimeout((function() {
      xe = !1, setTimeout((function() {
        x()
      }), 1e3 * Te.config.click_delay)
    }), 1e3 * Te.config.start_delay)
  }

  function g(e) {
    var a, c = ke.mp_hook,
      n = [];
    for (a in e) "function" != typeof e[a] || c[a] || n.push(a);
    for (c = n.length, a = 0; a < c; a++) y(e, n[a])
  }

  function v(e) {
    return null != e && "[object Object]" == toString.call(e)
  }

  function y(e, a) {
    var c = e[a];
    e[a] = function() {
      try {
        var e = c.apply(this, arguments),
          a = arguments[0];
        return v(a) && (1 != Te.config.valid || xe || m(a)), e
      } catch (e) {
        return c.apply(this, arguments)
      }
    }
  }

  function m(e) {
    try {
      var a = e.type,
        c = {};
      if (a) {
        var n = I();
        if (je.click.length > Te.config.max_click) return void(xe = !0);
        var t = e.touches || [],
          f = e.target || {};
        if (0 < t.length && ke.mp_taps[a]) {
          x();
          var r = w(d = t[0], n, a, f);
          c.start = r, c.trail = [], c.end = [0, 0, 0, 0, 0], C(c)
        }
        if (ke.mp_touchs[a]) {
          x();
          var d = t[0];
          e = n - we, we = n, e <= Te.config.groupTime ? Te.touch.trail.length <= Te.config.max_trail && (r = w(d, e, a, f), Te.touch.trail.push(r)) : (S(), r = w(d, n, a, f), Te.touch.start = r, Te.touch.trail = [])
        }
      }
    } catch (e) {}
  }

  function w(e, a, c, n) {
    return c = "tap longpress longtap touchstart touchmove touchend touchcancel".split(" ").indexOf(c), e ? (n = n.id || "", [D(e.clientX), D(e.clientY), D(e.force), a, c, n]) : [0, 0, 0, a, c, ""]
  }

  function x() {
    var e;
    !1 === Se && (Se = !0, function() {
      try {
        var e = Te.config.type || "";
        0 <= e.indexOf("1") && wx.onAccelerometerChange && (wx.startAccelerometer(_()), wx.onAccelerometerChange(N)), 0 <= e.indexOf("2") && wx.onCompassChange && (wx.startCompass({
          success: function(e) {},
          fail: function(e) {}
        }), wx.onCompassChange(j)), 0 <= e.indexOf("3") && wx.onDeviceMotionChange && (wx.startDeviceMotionListening(_()), wx.onDeviceMotionChange(T)), 0 <= e.indexOf("4") && wx.onGyroscopeChange && (wx.startGyroscope(_()), wx.onGyroscopeChange(k))
      } catch (e) {
        pe && pe.addError("startSensor", e)
      }
    }(), e = Te.config.duration || 60, Ne = setTimeout((function() {
      9 != je.biocode && (xe = !0, O("1|2|3|4"), A())
    }), 1e3 * e))
  }

  function S() {
    var e = Te.touch.trail.length,
      a = {};
    if (e || Te.touch.start.length) {
      if (a.start = Te.touch.start, e) {
        var c = Te.touch.trail,
          n = Te.touch.trail[e - 1];
        c.length = e - 1, a.trail = c, a.end = n
      } else a.trail = [], a.end = [0, 0, 0, 0, 0];
      C(a)
    }
  }

  function C(e) {
    je.click.length > Te.config.max_click ? xe = !0 : je.click.push(e)
  }

  function A(e) {
    S(), e = {}, Object.assign(e, je), e.click = JSON.stringify(je.click), e.sensor = JSON.stringify(je.sensor), je.click = [], Te.touch.start = [], Te.touch.trail = [], je.sensor = {
      acc: [],
      com: [],
      mot: [],
      gyro: []
    }, Ie = _e = Oe = Ae = 0;
    var a = "";
    if ("undefined" != typeof getCurrentPages) {
      var c = getCurrentPages();
      try {
        c && (a = 0 === c.length ? "" : c[c.length - 1].route || "")
      } catch (e) {}
    }
    e.url = a, le && (le(e, ++De), 1 == Te.config.valid && 0 < Te.config.interval_in_min && 0 <= Te.config.max_count && !(1 >= De) && De < Te.config.max_count + 2 && setTimeout((function() {
      Se = xe = !1, je.biocode = 0, setTimeout((function() {
        x()
      }), 1e3 * Te.config.click_delay)
    }), 6e4 * Te.config.interval_in_min))
  }

  function O(e) {
    try {
      0 <= e.indexOf("1") && wx.offAccelerometerChange && wx.offAccelerometerChange(N), 0 <= e.indexOf("2") && wx.offCompassChange && wx.offCompassChange(j), 0 <= e.indexOf("3") && wx.offDeviceMotionChange && wx.offDeviceMotionChange(T), 0 <= e.indexOf("4") && wx.offGyroscopeChange && wx.offGyroscopeChange(k)
    } catch (e) {}
  }

  function _() {
    var e = Te.config.freq;
    e = 1 === e ? "game" : 2 === e ? "ui" : "normal";
    var a = {
      success: function(e) {},
      fail: function(e) {}
    };
    return a.interval = e, a
  }

  function I() {
    return (new Date).valueOf()
  }

  function D(e) {
    var a = 0;
    return "[object Number]" == toString.call(e) && /[\d\.]+/.test(String(e)) ? a = Number(e).toFixed(3) : "[object String]" == toString.call(e) && (a = e), a
  }

  function N(e) {
    try {
      if (je.sensor.acc.length < Te.config.max_sensor) {
        var a = I(),
          c = a - Ae;
        Ae = a, je.sensor.acc.push([c, D(e.x), D(e.y), D(e.z)])
      } else O("1")
    } catch (e) {}
  }

  function j(e) {
    try {
      if (je.sensor.com.length < Te.config.max_sensor) {
        var a = I(),
          c = a - Oe;
        Oe = a, je.sensor.com.push([c, D(e.direction), D(e.accuracy)])
      } else O("2")
    } catch (e) {}
  }

  function T(e) {
    try {
      if (je.sensor.mot.length < Te.config.max_sensor) {
        var a = I(),
          c = a - _e;
        _e = a, je.sensor.mot.push([c, D(e.alpha), D(e.beta), D(e.gamma)])
      } else O("3")
    } catch (e) {}
  }

  function k(e) {
    try {
      if (je.sensor.gyro.length < Te.config.max_sensor) {
        var a = I(),
          c = a - Ie;
        Ie = a, je.sensor.gyro.push([c, D(e.x), D(e.y), D(e.z)])
      } else O("4")
    } catch (e) {}
  }

  function J(e, a) {
    try {
      var c = "";
      a && "[object String]" == toString.call(a) ? c = a : a.stack && "[object String]" == toString.call(a.stack) && (c = a.stack), ve && ve.error.pushError({
        sec_category: e,
        content: c,
        category: "jsError",
        level: "warn"
      }, !0)
    } catch (e) {}
  }

  function P(e, a, c, n, t) {
    try {
      var f = Re[e];
      (void 0 === f ? R(t) : f) && ve && ve.resource.addApi({
        name: e,
        networkCode: a,
        statusCode: c,
        responseTime: n
      })
    } catch (e) {}
  }

  function M(e, a) {
    void 0 === a && (a = !1);
    try {
      if (a && (e = wx.getStorageSync("guardSample")), e)
        for (var c in !a && wx.setStorage({
            key: "guardSample",
            data: e
          }), e = JSON.parse(e) || e)
          if (e.hasOwnProperty(c)) {
            var n = e[c],
              t = 0 < n && R(1 / n);
            Re[c] = t
          }
    } catch (e) {}
  }

  function R(e) {
    void 0 === e && (e = 1);
    try {
      return 0, a = e = 1 / e, Math.floor(Math.random() * (a - 0 + 1)) + 0 + 1 == e || 1 === e
    } catch (e) {
      return !0
    }
    var a
  }

  function L(e, a) {
    (null == a || a > e.length) && (a = e.length);
    for (var c = 0, n = Array(a); c < a; c++) n[c] = e[c];
    return n
  }

  function E(e, a) {
    var c;
    if ("undefined" == typeof Symbol || null == e[Symbol.iterator]) {
      if (Array.isArray(e) || (c = function(e, a) {
          if (e) {
            if ("string" == typeof e) return L(e, a);
            var c = Object.prototype.toString.call(e).slice(8, -1);
            return "Object" === c && e.constructor && (c = e.constructor.name), "Map" === c || "Set" === c ? Array.from(e) : "Arguments" === c || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(c) ? L(e, a) : void 0
          }
        }(e)) || a && e && "number" == typeof e.length) {
        c && (e = c);
        var n = 0;
        return function() {
          return n >= e.length ? {
            done: !0
          } : {
            done: !1,
            value: e[n++]
          }
        }
      }
      throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
    }
    return (c = e[Symbol.iterator]()).next.bind(c)
  }

  function U(e, a) {
    return e(a = {
      exports: {}
    }, a[n(2)]), a[n(2)]
  }

  function B(e, a) {
    void 0 === a && (a = {});
    var c = xa(),
      n = e.length;
    c.p(e);
    var t = (e = Sa(e, a, 10 + (a.filename && a.filename.length + 1 || 0), 8)).length,
      f = a;
    if (a = f.filename, e[0] = 31, e[1] = 139, e[2] = 8, e[8] = 2 > f.level ? 4 : 9 == f.level ? 2 : 0, e[9] = 3, 0 != f.mtime && Ca(e, 4, Math.floor(new Date(f.mtime || Date.now()) / 1e3)), a)
      for (e[3] = 8, f = 0; f <= a.length; ++f) e[f + 10] = a.charCodeAt(f);
    return Ca(e, t - 8, c.d()), Ca(e, t - 4, n), e
  }

  function F(e) {
    function a() {
      for (var e, a = [n(100), n(101)], c = [], t = 0; t < a[n(84)]; t++) {
        e = "";
        for (var f = a[t], r = f[n(84)], d = parseInt(n(104) + f[n(105)](0, 2)), o = 2; o < r; o += 2) {
          var i = parseInt(n(104) + f[n(107)](o) + f[n(107)](o + 1));
          e += String[n(109)](i ^ d)
        }
        c[n(87)](e)
      }
      return c
    }
    var c = Be[n(111)][n(112)][n(113)](a()[0]),
      t = Be[n(111)][n(112)][n(113)](a()[1]);
    return c = new(Be[n(117)][n(118)])(c), e = Be[n(119)][n(120)][n(121)](c, e, t), Be[n(111)][n(123)][n(124)](e)
  }

  function z(e, a) {
    return e && (a.id && (e.id || (e.id = {}), a.id = Object.assign(e.id, a.id)), a = Object.assign(e, a)), a
  }

  function G(e, a) {
    var c = {};
    try {
      Ia || (c = wx.getStorageSync(Ma[n(133)])), c.id && (c = {
        id: c.id
      }), Ia = !0
    } catch (e) {
      try {
        Oa && Oa.addError("getFpCache", e)
      } catch (e) {}
    }
    _a = e = z(z(c, _a), e), 0 < Object.keys(e).length && a && wx.setStorage({
      key: Ma[n(133)],
      data: e
    })
  }

  function W() {
    try {
      Ga--, wx[n(225)](q)
    } catch (e) {}
  }

  function q(e) {
    try {
      wx[n(226)](q), La[n(11)][n(25)] || (La[n(11)][n(25)] = []), 20 < La[n(11)][n(25)][n(84)] && La[n(11)][n(25)][n(235)](), La[n(11)][n(25)][n(87)](Number(e[n(239)])[n(240)](3)), 0 === Ga && (setTimeout(W, 5e3), Ga++)
    } catch (e) {}
  }

  function H() {
    try {
      Wa--, wx.onAccelerometerChange(V)
    } catch (e) {}
  }

  function V(e) {
    try {
      wx[n(241)](V), La[n(11)][n(15)] || (La[n(11)][n(15)] = []), 20 < La[n(11)][n(15)][n(84)] && La[n(11)][n(15)][n(235)](), La[n(11)][n(15)][n(87)]({
        x: Number(e.x)[n(240)](3),
        y: Number(e.y)[n(240)](3),
        z: Number(e.z)[n(240)](3)
      }), 0 === Wa && (setTimeout(H, 5e3), Wa++)
    } catch (e) {}
  }

  function Z() {
    try {
      qa--, wx[n(257)](X)
    } catch (e) {}
  }

  function X(e) {
    try {
      wx[n(258)](X), La[n(11)][n(260)] || (La[n(11)][n(260)] = []), 10 < La[n(11)][n(260)][n(84)] && La[n(11)][n(260)][n(235)](), La[n(11)][n(260)][n(87)]({
        x: Number(e.x)[n(240)](6),
        y: Number(e.y)[n(240)](6),
        z: Number(e.z)[n(240)](6)
      }), 0 === qa && (setTimeout(Z, 5e3), qa++)
    } catch (e) {}
  }

  function Y() {
    try {
      var e = Math.round((new Date).getTime() / 1e3);
      La.timestamp = e
    } catch (e) {
      La.timestamp = ""
    }
  }

  function K(e) {
    "start" != e.state && "on" != e.state || (e = (new Date).valueOf() + Fa(), La.system.screenRecord.push(e), 5 < La.system.screenRecord.length && La.system.screenRecord.shift())
  }

  function Q(a, c, t) {
    if (void 0 === t && (t = !1), t)
      for (var f in c) void 0 === (t = c[f]) ? a[n(87)]([te(f), n(1)]) : null === t ? a[n(87)]([te(f), n(387)]) : n(0) == e(t) ? a[n(87)]([te(f), te(JSON[n(74)](c[f]))]) : a[n(87)]([te(f), te(c[f])]);
    else c[n(391)]((function(e) {
      a[n(87)]([te(e[0]), te(e[1])])
    }))
  }

  function $(e, a) {
    void 0 === a && (a = !1);
    var c = [];
    e = e[n(393)]("&");
    for (var t = 0; t < e[n(84)]; t++) {
      var f = e[t][n(393)]("=");
      if (!(1 > f[n(84)])) {
        var r = f[0];
        r = r[n(397)](/\+/g, " "), 1 === f[n(84)] ? a ? c[n(87)]([decodeURIComponent(r), n(1)]) : c[n(87)]([decodeURIComponent(r), ""]) : (f = f[1][n(397)](/\+/g, " "), c[n(87)]([decodeURIComponent(r), decodeURIComponent(f)]))
      }
    }
    return c
  }

  function ee(e) {
    e = encodeURIComponent(e);
    for (var a = [], c = 0; c < e[n(84)]; c++) {
      var t = e[n(107)](c);
      "%" === t ? (t = e[n(107)](c + 1) + e[n(107)](c + 2), t = parseInt(t, 16), a[n(87)](t), c += 2) : a[n(87)](t[n(144)](0))
    }
    return a
  }

  function ae(e) {
    return 16200 < e[n(84)] && (e = e[n(163)](0, 16200)), e
  }

  function ce(e) {
    for (var a = [], c = 0; c < e[n(84)]; c += 2) {
      var t = e[n(107)](c) + e[n(107)](c + 1);
      t = parseInt(t, 16), a[n(87)](t)
    }
    return a
  }

  function ne(e) {
    var a = [];
    return a[0] = e >>> 24 & 255, a[1] = e >>> 16 & 255, a[2] = e >>> 8 & 255, a[3] = 255 & e, a
  }

  function te(e) {
    return encodeURIComponent(e)[n(397)](/!/g, n(418))[n(397)](/'/g, n(420))[n(397)](/\(/g, n(422))[n(397)](/\)/g, n(424))[n(397)](/\*/g, n(426))
  }

  function fe(e, a, c) {
    for (var t, f = [], r = a; r < c; r += 3) a = (e[r] << 16 & 16711680) + (e[r + 1] << 8 & 65280) + (255 & e[r + 2]), f[n(87)](cc[(t = a) >> 18 & 63] + cc[t >> 12 & 63] + cc[t >> 6 & 63] + cc[63 & t]);
    return f[n(428)]("")
  }

  function re(e, a) {
    return e[0] < a[0] ? -1 : e[0] > a[0] ? 1 : e[1] < a[1] ? -1 : e[1] > a[1] ? 1 : 0
  }

  function de(e, a) {
    for (var c = !1, t = 0, f = Object[n(431)](e); t < f[n(84)]; t++) {
      var r = f[t];
      if (n(433) === r[n(434)]() && (c = !0, e[r] && e[r][n(434)]()[n(436)](a))) return !0
    }
    return a === ic && !c
  }

  function oe(c, t) {
    void 0 === t && (t = !0);
    try {
      var f = Date[n(142)](),
        r = 0;
      switch (n(1) != ("undefined" == typeof mmp_env ? "undefined" : e(mmp_env)) ? n(439) === mmp_env && (r = 1) : n(1) != ("undefined" == typeof mmp ? "undefined" : e(mmp)) && (r = 2), r) {
        case 2:
          c[n(441)] = !0, c[n(442)] = !0;
          break;
        default:
          c = function(c, t) {
            if (void 0 === t && (t = !1), rc += 1, Qa[n(443)] = rc, c) {
              var r = c[n(444)] || {},
                d = (c[n(445)] || n(446))[n(447)](),
                o = n(446) !== d && de(r, oc),
                i = (n(446) !== d && de(r, ic), (new Date)[n(352)]() + ec[n(5)][n(452)]());
              r = c[n(453)] || "";
              var b = c[n(275)];
              c[n(444)] && n(0) == e(c[n(444)]) || (c[n(444)] = {});
              var s = "/",
                u = [];
              (r = /^(?:([A-Za-z]+):)?(\/{0,3})([0-9.\-A-Za-z]+)(?::(\d+))?(?:\/([^?#]*))?(?:\?([^#]*))?(?:#(.*))?$/ [n(459)](r)) && (r[5] && (s += r[5]), r[6] && (u = $(r[6])));
              var h = [],
                l = "",
                p = [];
              if (n(446) === d)
                if (n(0) == e(b) && 0 < Object[n(431)](b)[n(84)]) {
                  if (Q(h, b, !0), r && r[6] && 0 < u[n(84)]) {
                    var g = {};
                    (u = $(r[6], !0))[n(391)]((function(e) {
                      b[n(465)](e[0]) || (g[e[0]] = e[1])
                    })), Q(h, g, !0)
                  }
                } else Q(h, u);
              else if (Q(h, u), o)
                if (n(91) == e(b)) l = b;
                else if (n(0) == e(b)) {
                ! function(e, a) {
                  for (var c in a) e[n(87)]([encodeURIComponent(c), encodeURIComponent(a[c])])
                }(p, b);
                var v = [];
                p[n(391)]((function(e) {
                  v[n(87)](e[0] + "=" + e[1])
                })), l = v[n(428)]("&")
              }
              var y = "";
              t && (y = $a), [][n(160)](h), h[n(473)](re);
              var m = [];
              h[n(391)]((function(e) {
                m[n(87)](e[0] + "=" + e[1])
              }));
              var w = ee(d + " " + s + " " + m[n(428)]("&"));
              if (o || n(446) === d || null == b || (n(91) == e(b) ? w[n(87)][n(480)](w, ae(ee(b))) : w[n(87)][n(480)](w, ae(ee(JSON[n(74)](b))))), 0 < l[n(84)] && w[n(87)][n(480)](w, ae(ee(l))), t = "", n(1) != ("undefined" == typeof getCurrentPages ? "undefined" : e(getCurrentPages))) {
                d = getCurrentPages();
                try {
                  d && (t = 0 === d[n(84)] ? "" : d[d[n(84)] - 1][n(489)] || "")
                } catch (e) {}
              }
              Qa[n(490)] = t, t = "", void 0 !== (d = function() {
                for (var c, t = 183;;) switch (a[t++]) {
                  case 0:
                    return;
                  case 1:
                    try {
                      var f = 0;
                      try {
                        ac[n(491)] = WeixinJSBridge
                      } catch (e) {}
                      try {
                        ac[n(492)] = __wxConfig
                      } catch (e) {}
                      try {
                        ac[n(493)] = process, ac[n(494)] = wx
                      } catch (e) {}
                      if (ac.e = Error, void 0 !== ac[n(131)]) f = ac[n(131)];
                      else {
                        var r = Object[n(497)](wx, n(498));
                        r && r[n(499)] && (f = 1);
                        var d = 0;
                        window && (d = 1);
                        var o = 0;
                        n(1) != ("undefined" == typeof globalThis ? "undefined" : e(globalThis)) && globalThis[n(501)] && (o = 1);
                        var b = 0;
                        if (ac.e) {
                          var s = new ac.e;
                          s && s[n(313)] && !s[n(313)][n(504)](n(505)) && !s[n(313)][n(504)](n(508)) && (b = 1), ac.e[n(162)]()[n(504)](n(511)) || (b = 1)
                        }
                        var u = 0;
                        ac[n(491)] || (u = 1);
                        var h = 0;
                        (!ac[n(492)] || ac[n(492)] && !0 === ac[n(492)][n(516)]) && (h = 1);
                        var l = 0;
                        void 0 !== ac[n(493)] && null != ac[n(493)][n(519)] && null != ac[n(493)][n(519)][n(522)] && (l = 1), ac[n(494)] === wx && (l = 1), f |= (Object[n(497)][n(162)]()[n(504)](n(511)) ? 0 : 1) << 7 | l << 2 | h << 5 | b << 4 | d << 3 | u << 6 | o << 1, ac[n(131)] = f
                      }
                      var p = ne(d = 4294967295 & i),
                        g = new Uint8Array(ee(y)[n(160)](p)),
                        v = me[n(157)](g),
                        m = ce(v[n(531)](0, 15));
                      m[7] = 255 & (f ^ bc(p)), m[n(87)][n(480)](m, p), m[n(87)][n(480)](m, ne(4294967295 & bc(m)));
                      var x = function(e) {
                          for (var c, t = [], f = Function.prototype.call, r = 0;;) switch (a[r++]) {
                            case 0:
                              var d = t.pop();
                              continue;
                            case 1:
                              t.push(d);
                              continue;
                            case 2:
                              t.length -= 4;
                              continue;
                            case 3:
                              t.push(a[r++]);
                              continue;
                            case 4:
                              var o = t.pop();
                              continue;
                            case 5:
                              t.pop();
                              continue;
                            case 6:
                              t[t.length - 2] = t[t.length - 2][t[t.length - 1]];
                              continue;
                            case 7:
                              t[t.length - 3] = f.call(t[t.length - 3], t[t.length - 2], t[t.length - 1]);
                              continue;
                            case 10:
                              !t.pop() && (r += 25);
                              continue;
                            case 12:
                              t.length -= 2;
                              continue;
                            case 13:
                              t.push(null);
                              continue;
                            case 16:
                              t[t.length - 5] = f.call(t[t.length - 5], t[t.length - 4], t[t.length - 3], t[t.length - 2], t[t.length - 1]);
                              continue;
                            case 17:
                              t.push(o);
                              continue;
                            case 18:
                              b += t[t.length - 1];
                              continue;
                            case 19:
                              var i = t.pop();
                              continue;
                            case 20:
                              t.push(b + 16383 > o ? o : b + 16383);
                              continue;
                            case 22:
                              return;
                            case 24:
                              t.push(i);
                              continue;
                            case 27:
                              t.push(b);
                              continue;
                            case 29:
                              var b = t.pop();
                              continue;
                            case 31:
                              t.push(n);
                              continue;
                            case 34:
                              t[t.length - 2] = t[t.length - 2] < t[t.length - 1];
                              continue;
                            case 35:
                              t[t.length - 2] -= t[t.length - 1];
                              continue;
                            case 36:
                              t[t.length - 2] %= t[t.length - 1];
                              continue;
                            case 37:
                              t[t.length - 0] = [];
                              continue;
                            case 39:
                              return t.pop();
                            case 40:
                              t.push(e);
                              continue;
                            case 42:
                              t.push((1 === i ? (c = e[d - 1], s[n(87)](cc[c >> 2] + cc[c << 4 & 63] + n(538))) : 2 === i && (c = (e[d - 2] << 8) + e[d - 1], s[n(87)](cc[c >> 10] + cc[c >> 4 & 63] + cc[c << 2 & 63] + "=")), s[n(428)]("")));
                              continue;
                            case 44:
                              t.push(fe);
                              continue;
                            case 48:
                              t.push(s);
                              continue;
                            case 51:
                              var s = t.pop();
                              continue;
                            case 55:
                              r -= 30
                          }
                        }(m[n(160)](function(e, c) {
                          for (var t, f, r = [], d = Function.prototype.call, o = 93;;) switch (a[o++]) {
                            case 0:
                              r.push(b);
                              continue;
                            case 1:
                              var i = r[r.length - 1];
                              continue;
                            case 2:
                              r.push(t);
                              continue;
                            case 3:
                              b[i] = r[r.length - 1];
                              continue;
                            case 5:
                              r.push((function(e, c, t) {
                                for (var f, r, d = [], o = Function.prototype.call, i = 59;;) switch (a[i++]) {
                                  case 0:
                                    d.push(t);
                                    continue;
                                  case 1:
                                    return;
                                  case 2:
                                    d.push(u);
                                    continue;
                                  case 3:
                                    d.push(null);
                                    continue;
                                  case 4:
                                    d.pop();
                                    continue;
                                  case 5:
                                    d.push((r = (r + e[f = (f + 1) % 256]) % 256, c = e[f], e[f] = e[r], e[r] = c, s[n(87)](t[n(144)](b) ^ e[(e[f] + e[r]) % 256])));
                                    continue;
                                  case 6:
                                    var b = d.pop();
                                    continue;
                                  case 8:
                                    d[d.length - 3] = o.call(d[d.length - 3], d[d.length - 2], d[d.length - 1]);
                                    continue;
                                  case 9:
                                    d.push(s);
                                    continue;
                                  case 10:
                                    d.push(a[i++]);
                                    continue;
                                  case 12:
                                    d.length -= 2;
                                    continue;
                                  case 13:
                                    f = d.pop();
                                    continue;
                                  case 14:
                                    r = d.pop();
                                    continue;
                                  case 16:
                                    d.push(b);
                                    continue;
                                  case 19:
                                    d.push(n);
                                    continue;
                                  case 20:
                                    return d.pop();
                                  case 21:
                                    var s = d.pop();
                                    continue;
                                  case 23:
                                    var u = d.pop();
                                    continue;
                                  case 24:
                                    !d.pop() && (i += 5);
                                    continue;
                                  case 26:
                                    d.push(b++);
                                    continue;
                                  case 28:
                                    i -= 10;
                                    continue;
                                  case 29:
                                    d[d.length - 2] = d[d.length - 2] < d[d.length - 1];
                                    continue;
                                  case 31:
                                    d[d.length - 0] = [];
                                    continue;
                                  case 32:
                                    d[d.length - 2] = d[d.length - 2][d[d.length - 1]]
                                }
                              }));
                              continue;
                            case 6:
                              r.push((f = (f + b[i] + e[i % e[n(84)]] + 31) % 256, t = b[i], b[i] = b[f], b[f] = t));
                              continue;
                            case 7:
                              return r.pop();
                            case 8:
                              r.pop();
                              continue;
                            case 9:
                              o -= 12;
                              continue;
                            case 11:
                              r[r.length - 2] = r[r.length - 2] < r[r.length - 1];
                              continue;
                            case 13:
                              r.push(i);
                              continue;
                            case 14:
                              r[r.length - 5] = d.call(r[r.length - 5], r[r.length - 4], r[r.length - 3], r[r.length - 2], r[r.length - 1]);
                              continue;
                            case 16:
                              r[r.length - 0] = [];
                              continue;
                            case 17:
                              r.push(i++);
                              continue;
                            case 18:
                              !r.pop() && (o += 6);
                              continue;
                            case 20:
                              r.push(a[o++]);
                              continue;
                            case 21:
                              r.length -= 4;
                              continue;
                            case 22:
                              !r.pop() && (o += 5);
                              continue;
                            case 23:
                              f = r.pop();
                              continue;
                            case 31:
                              r.push(c);
                              continue;
                            case 32:
                              o -= 11;
                              continue;
                            case 33:
                              var b = r.pop();
                              continue;
                            case 35:
                              return;
                            case 40:
                              r.push(null);
                              continue;
                            case 43:
                              i = r.pop()
                          }
                        }(m, JSON[n(74)](Qa)))),
                        S = be(w, i),
                        C = ne(S),
                        A = be(new Uint8Array(ee(x)), i),
                        O = ne(A),
                        _ = ce(me[n(546)]([S, A, S ^ d, S ^ A ^ d])),
                        I = (void 0 === (c = C[n(160)](O)[n(160)](_)) && (c = []), c[n(549)]((function(e) {
                          for (var c = [], n = 137;;) switch (a[n++]) {
                            case 0:
                              c.push("3");
                              continue;
                            case 1:
                              c.pop();
                              continue;
                            case 2:
                              c.push("b");
                              continue;
                            case 3:
                              c[c.length - 2] += c[c.length - 1];
                              continue;
                            case 4:
                              c[c.length - 16] = [c[c.length - 16], c[c.length - 15], c[c.length - 14], c[c.length - 13], c[c.length - 12], c[c.length - 11], c[c.length - 10], c[c.length - 9], c[c.length - 8], c[c.length - 7], c[c.length - 6], c[c.length - 5], c[c.length - 4], c[c.length - 3], c[c.length - 2], c[c.length - 1]];
                              continue;
                            case 7:
                              c.push(a[n++]);
                              continue;
                            case 8:
                              c[c.length - 2] &= c[c.length - 1];
                              continue;
                            case 9:
                              c.push("d");
                              continue;
                            case 10:
                              c.push(t);
                              continue;
                            case 12:
                              c.push("");
                              continue;
                            case 13:
                              var t = c[c.length - 1];
                              continue;
                            case 14:
                              c.push("6");
                              continue;
                            case 16:
                              c.push("0");
                              continue;
                            case 17:
                              c.push("8");
                              continue;
                            case 19:
                              c.push("7");
                              continue;
                            case 22:
                              c.push(e);
                              continue;
                            case 23:
                              c.push("4");
                              continue;
                            case 24:
                              c.push("1");
                              continue;
                            case 25:
                              c.push("f");
                              continue;
                            case 26:
                              c.push("c");
                              continue;
                            case 27:
                              c[c.length - 2] >>>= c[c.length - 1];
                              continue;
                            case 28:
                              c.push(f);
                              continue;
                            case 31:
                              c[c.length - 2] = c[c.length - 2][c[c.length - 1]];
                              continue;
                            case 32:
                              c.push("e");
                              continue;
                            case 33:
                              return;
                            case 34:
                              c.push("9");
                              continue;
                            case 35:
                              c.length -= 15;
                              continue;
                            case 37:
                              c.push("a");
                              continue;
                            case 40:
                              c.push("5");
                              continue;
                            case 43:
                              return c.pop();
                            case 44:
                              var f = c[c.length - 1];
                              continue;
                            case 45:
                              c.push("2")
                          }
                        }))[n(428)](""));
                      (f = {})[n(551)] = nc, f[n(552)] = i, tc || (tc = ec[n(5)].d()), f[n(554)] = tc, f[n(555)] = I, f[n(556)] = x, f[n(557)] = y, f[n(558)] = fc, f[n(559)] = 3, o = A >>> 0;
                      var D = f[n(551)] + f[n(552)] + f[n(554)] + f[n(555)] + o + v + f[n(558)],
                        N = me[n(565)](new Uint8Array(ee(D))),
                        j = d << f[n(559)] | d << 32 - f[n(559)];
                      return N[0] ^= j, N[1] ^= o, N[2] = N[2] ^ o ^ j, N[3] ^= N[0], f[n(568)] = me[n(546)](N), f
                    } catch (e) {
                      try {
                        Ee && Ee[n(223)](n(571), e)
                      } catch (e) {}
                    }
                }
              }()) && (t = JSON[n(74)](d), c[n(444)][n(574)] = t);
              try {
                d = 200, 0 === t[n(84)] && (d = 9401), Ee && Ee[n(299)](n(577), 200, d, t[n(84)], .001), Ee && Ee[n(299)](n(580), 200, d, Date[n(142)]() - f, .001)
              } catch (e) {}
            }
            return c
          }(c, t)
      }
    } catch (e) {
      try {
        Ee && Ee[n(223)](n(583), e), Ee && Ee[n(299)](n(580), 200, 9402, Date[n(142)]() - f, .001)
      } catch (e) {}
    }
    return c
  }

  function ie(e, a) {
    return e = oe(e), a ? a(e) : wx[n(324)](e)
  }

  function be(e, a) {
    var c = e[n(84)];
    a ^= c;
    for (var t = 0; 4 <= c;) {
      var f = 1540483477 * (65535 & (f = 255 & e[t] | (255 & e[++t]) << 8 | (255 & e[++t]) << 16 | (255 & e[++t]) << 24)) + ((1540483477 * (f >>> 16) & 65535) << 16);
      a = 1540483477 * (65535 & a) + ((1540483477 * (a >>> 16) & 65535) << 16) ^ (f = 1540483477 * (65535 & (f ^= f >>> 24)) + ((1540483477 * (f >>> 16) & 65535) << 16)), c -= 4, ++t
    }
    switch (c) {
      case 3:
        a ^= (255 & e[t + 2]) << 16;
      case 2:
        a ^= (255 & e[t + 1]) << 8;
      case 1:
        a = 1540483477 * (65535 & (a ^= 255 & e[t])) + ((1540483477 * (a >>> 16) & 65535) << 16)
    }
    return ((a = 1540483477 * (65535 & (a ^= a >>> 13)) + ((1540483477 * (a >>> 16) & 65535) << 16)) ^ a >>> 15) >>> 0 ^ 1540483477
  }

  function se(a, c, t) {
    var f = Date[n(142)](),
      r = !1;
    if (0 == Object[n(431)](ec)[n(84)]) {
      var d;
      if (r = !0, Qa[n(596)] = Math[n(597)](Date[n(142)]() / 1e3), ec[n(599)] = oe, ec[n(600)] = oe, ec[n(324)] = ie, ec[n(602)] = ie, ec[n(5)] = Ka, ec[n(5)][n(605)] = ec, wx[n(498)]) {
        var o = wx[n(498)]();
        o && (Qa[n(608)] = o, o[n(609)] && o[n(609)][n(210)] && (ec[n(5)].s(o[n(609)][n(210)]), fc = o[n(609)][n(210)]))
      }!fc && a[n(617)] && (ec[n(5)].s(a[n(617)]), fc = a[n(617)]), a[n(155)] && (Qa[n(622)] = a[n(155)], ec[n(5)].o(a[n(155)])), a[n(213)] && ec[n(5)].u(a[n(213)]), a[n(215)] && ec[n(5)].m(a[n(215)]), a[n(632)] && ec[n(5)][n(634)](a[n(632)]);
      var i = ((d = {})[n(357)] = n(357), d[n(360)] = n(639), d[n(23)] = n(23), d[n(378)] = n(17), d[n(366)] = n(368), d[n(369)] = n(19), d[n(372)] = n(374), d[n(375)] = n(32), d[n(652)] = n(54), d[n(654)] = n(654), d);
      Object[n(431)](i)[n(391)]((function(e) {
        a[e] && ec[n(5)][n(659)](a[e], i[e])
      })), d = ec[n(5)].d(), o = {
        unionId: a[n(155)] || "",
        dfpid: d || "",
        appid: fc
      }, Ee[n(661)](o), a[n(662)] && Ee[n(663)](a[n(662)]), ec[n(5)][n(662)](a[n(662)], Ee, f), ec[n(668)] = Ee[n(668)], ec[n(670)] = Ee[n(670)], (o = Pe[n(672)]()) && ec[n(5)][n(674)](o), n(1) == ("undefined" == typeof mmp ? "undefined" : e(mmp)) ? (ec[n(676)] = ue, 1 == a[n(677)] || Pe[n(678)](), (o = {})[n(7)] = d, o[n(617)] = fc, o[n(681)] = Ee, Pe[n(682)](o, (function(e, a) {
        ec[n(5)][n(684)](e, a, ec)
      }))) : Pe[n(685)](fc, d, Ee), Date[n(142)](), ec[n(5)][n(688)](a), Ee && Ee[n(299)](n(690), 200, 200, Date[n(142)]() - f, .1)
    }
    c && t(ec), c = function() {
      var e = Date[n(142)]();
      $a = ec[n(5)].i(), Ee && Ee[n(299)](n(695), 200, 200, Date[n(142)]() - e, 1e-4), Ee && Ee[n(299)](n(698), 200, 200, $a[n(84)], 1e-4)
    };
    var b = wx[n(699)];
    Object[n(700)](wx, n(699), {
      configurable: !0,
      enumerable: !0,
      writable: !0,
      value: function(e) {
        var a = arguments,
          c = arguments[0][n(702)];
        return c && (a[0][n(702)] = function(e) {
          c[n(188)](a[0], e), ec[n(5)].l(e)
        }), b[n(480)](this, a)
      }
    }), c(), ec[n(707)] = setInterval(c, 1e4), setTimeout((function() {
      ec[n(5)].t(ec, {})
    }), 0), r && Ee && Ee[n(299)](n(710), 200, 200, Date[n(142)]() - f, .1)
  }

  function ue(e) {
    Pe[n(712)](e)
  }
  var he, le, pe, ge, ve, ye = "0123456789abcdef".split(""),
    me = {
      md5: function(e) {
        return b(i(e))
      },
      md5Array: i,
      md5ToHex: b
    },
    we = 0,
    xe = !0,
    Se = !1,
    Ce = !1,
    Ae = 0,
    Oe = 0,
    _e = 0,
    Ie = 0,
    De = 0,
    Ne = void 0,
    je = {
      biocode: 0,
      sensor: {
        acc: [],
        com: [],
        mot: [],
        gyro: []
      },
      click: []
    },
    Te = {
      pid: 9,
      touch: {
        start: [],
        trail: [],
        end: []
      },
      config: {
        valid: 1,
        type: "1|2|3|4",
        freq: 1,
        start_delay: 10,
        click_delay: 10,
        duration: 10,
        groupTime: 100,
        max_sensor: 500,
        max_click: 100,
        max_trail: 100,
        interval_in_min: 5,
        max_count: 5
      }
    },
    ke = {
      mp_touchs: {
        touchstart: 1,
        touchmove: 1,
        touchend: 1,
        touchcancel: 1
      },
      mp_taps: {
        tap: 1,
        longpress: 1,
        longtap: 1
      },
      mp_hook: {
        data: 1,
        onLoad: 1,
        onShow: 1,
        onReady: 1,
        onPullDownRefresh: 1,
        onShareAppMessage: 1,
        onShareTimeline: 1,
        onReachBottom: 1,
        onPageScroll: 1,
        onResize: 1,
        onTabItemTap: 1,
        onHide: 1,
        onUnload: 1
      }
    },
    Je = ((he = {}).env = "prod", he.ver = "1.7.2", he),
    Pe = {
      initSensor: function(e, a) {
        je.dfpid = e.dfpid, je.appid = e.appid, pe = e._raptor, le = a, setTimeout((function() {
          try {
            h(je.appid, je.dfpid), wx.onAppHide && wx.onAppHide(u), A()
          } catch (e) {}
        }), 0)
      },
      getSessionId: function() {
        for (var e = [], a = 0; 36 > a; a++) e[a] = "0123456789abcdef".substr(Math.floor(16 * Math.random()), 1);
        return e[14] = "4", e[19] = "0123456789abcdef".substr(3 & e[19] | 8, 1), e[8] = e[13] = e[18] = e[23] = "", e = e.join(""), a = "", s() ? a = e + "55" : (function() {
          try {
            wx.getSystemInfo({
              success: function(e) {
                je.resolution = JSON.stringify([e.screenWidth, e.screenHeight]), e = e.platform.toLowerCase(), e = ["android", "ios", "devtools", "windows", "mac"].indexOf(e), Te.pid = -1 === e ? 9 : e
              }
            })
          } catch (e) {}
        }(), a = e + "0" + Te.pid), a
      },
      initProxy: function() {
        s() || Ce || (Ce = !0, function() {
          var e = Page;
          Page = function(a) {
            try {
              a || (a = {}), g(a), e.apply(this, arguments)
            } catch (a) {
              e.apply(this, arguments)
            }
          };
          var a = Component;
          Component = function(e) {
            try {
              e || (e = {}), e.methods || (e.methods = {}), g(e.methods), a.apply(this, arguments)
            } catch (e) {
              a.apply(this, arguments)
            }
          }
        }())
      },
      dfpClickTrack: function(e) {
        try {
          v(e) && Te.config.valid && !xe && m(e)
        } catch (e) {}
      },
      initMMPHorn: function(e, a, c) {
        pe = c, setTimeout((function() {
          h(e, a)
        }), 0)
      }
    },
    Me = ((ge = {}).env = "prod", ge.ver = "1.7.2", ge),
    Re = {},
    Le = {
      devMode: "prod" === Me.env ? 0 : 1,
      version: {
        appVersion: Me.ver
      },
      resource: {
        sample: 1
      }
    },
    Ee = {
      initCat: function(e) {
        try {
          e && (ve = new e.OWL(Le))
        } catch (e) {
          ve = void 0
        }
      },
      addError: J,
      addApi: P,
      jsgowl: function() {
        return ve
      },
      setRaptorConfig: function(e) {
        e.unionId && (Le.unionId = e.unionId), e.appid && (Le.pageUrl = e.appid), Le.project = "undefined" != typeof mmp ? "com.sankuai.jsprotect.jsguardmmp" : "com.sankuai.jsprotect.jsguard", M(null, !0)
      },
      addApiObj: function(e) {
        e && e.name && (e.sample || (e.sample = 1), P(e.name, e.ncode, e.scode, e.dur, e.sample))
      },
      addErrorObj: function(e) {
        e && e.name && e.error && J(e.name, e.error)
      },
      updatePatioRule: M
    },
    Ue = {
      DFP: [n(6), n(7), n(8), n(9), n(10), n(11), n(12), n(13), n(14)],
      system: [n(15), n(16), n(17), n(18), n(19), n(20), n(21), n(22), n(23), n(24), n(25), n(26), n(27), n(28), n(29), n(30), n(31), n(32), n(33), n(34), n(35), n(36), n(37), n(38), n(39), n(40), n(41), n(42), n(43), n(44), n(45), n(46), n(47), n(48), n(49), n(50), n(11), n(52), n(53), n(54), n(55), n(56), n(57)],
      BatteryInfo: [n(29), n(59), n(60)],
      safeArea: [n(61), n(62), n(63), n(64), n(65), n(66)],
      WifiInfo: [n(67), n(68), n(69), n(70), n(71), n(72), n(73)]
    },
    Be = U((function(e) {
      function a(e, a, n) {
        if (4 !== a.length) throw new c.exception.invalid("11");
        var t = e.g[n],
          f = a[0] ^ t[0],
          r = a[n ? 3 : 1] ^ t[1],
          d = a[2] ^ t[2];
        a = a[n ? 1 : 3] ^ t[3];
        var o, i, b = t.length / 4 - 2,
          s = 4,
          u = [0, 0, 0, 0];
        e = (o = e.a[n])[0];
        var h = o[1],
          l = o[2],
          p = o[3],
          g = o[4];
        for (i = 0; i < b; i++) {
          o = e[f >>> 24] ^ h[r >> 16 & 255] ^ l[d >> 8 & 255] ^ p[255 & a] ^ t[s];
          var v = e[r >>> 24] ^ h[d >> 16 & 255] ^ l[a >> 8 & 255] ^ p[255 & f] ^ t[s + 1],
            y = e[d >>> 24] ^ h[a >> 16 & 255] ^ l[f >> 8 & 255] ^ p[255 & r] ^ t[s + 2];
          a = e[a >>> 24] ^ h[f >> 16 & 255] ^ l[r >> 8 & 255] ^ p[255 & d] ^ t[s + 3], s += 4, f = o, r = v, d = y
        }
        for (i = 0; 4 > i; i++) u[n ? 3 & -i : i] = g[f >>> 24] << 24 ^ g[r >> 16 & 255] << 16 ^ g[d >> 8 & 255] << 8 ^ g[255 & a] ^ t[s++], o = f, f = r, r = d, d = a, a = o;
        return u
      }
      var c = {
        cipher: {},
        hash: {},
        keyexchange: {},
        mode: {},
        misc: {},
        codec: {},
        exception: {
          corrupt: function(e) {
            this.toString = function() {
              return "CORRUPT: " + this.message
            }, this.message = e
          },
          invalid: function(e) {
            this.toString = function() {
              return "INVALID: " + this.message
            }, this.message = e
          },
          bug: function(e) {
            this.toString = function() {
              return "BUG: " + this.message
            }, this.message = e
          },
          notReady: function(e) {
            this.toString = function() {
              return "NOT READY: " + this.message
            }, this.message = e
          }
        }
      };
      c.cipher.aes = function(e) {
        if (!this.a[0][0][0]) {
          var a, n, t, f, r = this.a[0],
            d = this.a[1],
            o = r[4],
            i = d[4],
            b = [],
            s = [];
          for (a = 0; 256 > a; a++) s[(b[a] = a << 1 ^ 283 * (a >> 7)) ^ a] = a;
          for (n = t = 0; !o[n]; n ^= f || 1, t = s[t] || 1) {
            var u = (u = t ^ t << 1 ^ t << 2 ^ t << 3 ^ t << 4) >> 8 ^ 255 & u ^ 99;
            o[n] = u, i[u] = n;
            var h = 16843009 * b[a = b[f = b[n]]] ^ 65537 * a ^ 257 * f ^ 16843008 * n,
              l = 257 * b[u] ^ 16843008 * u;
            for (a = 0; 4 > a; a++) r[a][n] = l = l << 24 ^ l >>> 8, d[a][u] = h = h << 24 ^ h >>> 8
          }
          for (a = 0; 5 > a; a++) r[a] = r[a].slice(0), d[a] = d[a].slice(0)
        }
        if (r = this.a[0][4], d = this.a[1], b = 1, 4 !== (t = e.length) && 6 !== t && 8 !== t) throw new c.exception.invalid("10");
        for (this.g = [i = e.slice(0), n = []], e = t; e < 4 * t + 28; e++) o = i[e - 1], (0 == e % t || 8 === t && 4 == e % t) && (o = r[o >>> 24] << 24 ^ r[o >> 16 & 255] << 16 ^ r[o >> 8 & 255] << 8 ^ r[255 & o], 0 == e % t && (o = o << 8 ^ o >>> 24 ^ b << 24, b = b << 1 ^ 283 * (b >> 7))), i[e] = i[e - t] ^ o;
        for (t = 0; e; t++, e--) o = i[3 & t ? e : e - 4], n[t] = 4 >= e || 4 > t ? o : d[0][r[o >>> 24]] ^ d[1][r[o >> 16 & 255]] ^ d[2][r[o >> 8 & 255]] ^ d[3][r[255 & o]]
      }, c.cipher.aes.prototype = {
        encrypt: function(e) {
          return a(this, e, 0)
        },
        decrypt: function(e) {
          return a(this, e, 1)
        },
        a: [
          [
            [],
            [],
            [],
            [],
            []
          ],
          [
            [],
            [],
            [],
            [],
            []
          ]
        ]
      }, c.bitArray = {
        bitSlice: function(e, a, n) {
          return e = c.bitArray.c(e.slice(a / 32), 32 - (31 & a)).slice(1), void 0 === n ? e : c.bitArray.clamp(e, n - a)
        },
        extract: function(e, a, c) {
          var n = Math.floor(-a - c & 31);
          return (-32 & (a + c - 1 ^ a) ? e[a / 32 | 0] << 32 - n ^ e[a / 32 + 1 | 0] >>> n : e[a / 32 | 0] >>> n) & (1 << c) - 1
        },
        concat: function(e, a) {
          if (0 === e.length || 0 === a.length) return e.concat(a);
          var n = e[e.length - 1],
            t = c.bitArray.getPartial(n);
          return 32 === t ? e.concat(a) : c.bitArray.c(a, t, 0 | n, e.slice(0, e.length - 1))
        },
        bitLength: function(e) {
          var a = e.length;
          return 0 === a ? 0 : 32 * (a - 1) + c.bitArray.getPartial(e[a - 1])
        },
        clamp: function(e, a) {
          if (32 * e.length < a) return e;
          var n = (e = e.slice(0, Math.ceil(a / 32))).length;
          return a &= 31, 0 < n && a && (e[n - 1] = c.bitArray.partial(a, e[n - 1] & 2147483648 >> a - 1, 1)), e
        },
        partial: function(e, a, c) {
          return 32 === e ? a : (c ? 0 | a : a << 32 - e) + 1099511627776 * e
        },
        getPartial: function(e) {
          return Math.round(e / 1099511627776) || 32
        },
        equal: function(e, a) {
          if (c.bitArray.bitLength(e) !== c.bitArray.bitLength(a)) return !1;
          var n, t = 0;
          for (n = 0; n < e.length; n++) t |= e[n] ^ a[n];
          return 0 === t
        },
        c: function(e, a, n, t) {
          var f;
          for (void 0 === t && (t = []); 32 <= a; a -= 32) t.push(n), n = 0;
          if (0 === a) return t.concat(e);
          for (f = 0; f < e.length; f++) t.push(n | e[f] >>> a), n = e[f] << 32 - a;
          return f = e.length ? e[e.length - 1] : 0, e = c.bitArray.getPartial(f), t.push(c.bitArray.partial(a + e & 31, 32 < a + e ? n : t.pop(), 1)), t
        },
        f: function(e, a) {
          return [e[0] ^ a[0], e[1] ^ a[1], e[2] ^ a[2], e[3] ^ a[3]]
        },
        byteswapM: function(e) {
          var a;
          for (a = 0; a < e.length; ++a) {
            var c = e[a];
            e[a] = c >>> 24 | c >>> 8 & 65280 | (65280 & c) << 8 | c << 24
          }
          return e
        }
      }, c.codec.utf8String = {
        fromBits: function(e) {
          var a, n, t = "",
            f = c.bitArray.bitLength(e);
          for (a = 0; a < f / 8; a++) 0 == (3 & a) && (n = e[a / 4]), t += String.fromCharCode(n >>> 8 >>> 8 >>> 8), n <<= 8;
          return decodeURIComponent(escape(t))
        },
        toBits: function(e) {
          e = unescape(encodeURIComponent(e));
          var a, n = [],
            t = 0;
          for (a = 0; a < e.length; a++) t = t << 8 | e.charCodeAt(a), 3 == (3 & a) && (n.push(t), t = 0);
          return 3 & a && n.push(c.bitArray.partial(8 * (3 & a), t)), n
        }
      }, c.codec.base64 = {
        b: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",
        fromBits: function(e, a, n) {
          var t = "",
            f = 0,
            r = c.codec.base64.b,
            d = 0,
            o = c.bitArray.bitLength(e);
          for (n && (r = r.substr(0, 62) + "-_"), n = 0; 6 * t.length < o;) t += r.charAt((d ^ e[n] >>> f) >>> 26), 6 > f ? (d = e[n] << 6 - f, f += 26, n++) : (d <<= 6, f -= 6);
          for (; 3 & t.length && !a;) t += "=";
          return t
        },
        toBits: function(e, a) {
          e = e.replace(/\s|=/g, "");
          var n, t = [],
            f = 0,
            r = c.codec.base64.b,
            d = 0;
          for (a && (r = r.substr(0, 62) + "-_"), a = 0; a < e.length; a++) {
            if (0 > (n = r.indexOf(e.charAt(a)))) throw new c.exception.invalid("12");
            26 < f ? (f -= 26, t.push(d ^ n >>> f), d = n << 32 - f) : d ^= n << 32 - (f += 6)
          }
          return 56 & f && t.push(c.bitArray.partial(56 & f, d, 1)), t
        }
      }, c.codec.base64url = {
        fromBits: function(e) {
          return c.codec.base64.fromBits(e, 1, 1)
        },
        toBits: function(e) {
          return c.codec.base64.toBits(e, 1)
        }
      }, c.codec.bytes = {
        fromBits: function(e) {
          var a, n, t = [],
            f = c.bitArray.bitLength(e);
          for (a = 0; a < f / 8; a++) 0 == (3 & a) && (n = e[a / 4]), t.push(n >>> 24), n <<= 8;
          return t
        },
        toBits: function(e) {
          var a, n = [],
            t = 0;
          for (a = 0; a < e.length; a++) t = t << 8 | e[a], 3 == (3 & a) && (n.push(t), t = 0);
          return 3 & a && n.push(c.bitArray.partial(8 * (3 & a), t)), n
        }
      }, void 0 === c.beware && (c.beware = {}), c.beware.o = function() {
        c.mode.cbc = {
          name: "cbc",
          encrypt: function(e, a, n, t) {
            if (t && t.length) throw new c.exception.invalid("1");
            if (128 !== c.bitArray.bitLength(n)) throw new c.exception.invalid("2");
            var f = c.bitArray,
              r = f.f,
              d = f.bitLength(a),
              o = 0,
              i = [];
            if (7 & d) throw new c.exception.invalid("3");
            for (t = 0; o + 128 <= d; t += 4, o += 128) n = e.encrypt(r(n, a.slice(t, t + 4))), i.splice(t, 0, n[0], n[1], n[2], n[3]);
            return d = 16843009 * (16 - (d >> 3 & 15)), n = e.encrypt(r(n, f.concat(a, [d, d, d, d]).slice(t, t + 4))), i.splice(t, 0, n[0], n[1], n[2], n[3]), i
          },
          decrypt: function(e, a, n, t) {
            if (t && t.length) throw new c.exception.invalid("4");
            if (128 !== c.bitArray.bitLength(n)) throw new c.exception.invalid("5");
            if (127 & c.bitArray.bitLength(a) || !a.length) throw new c.exception.corrupt("6");
            var f = c.bitArray,
              r = f.f,
              d = [];
            for (t = 0; t < a.length; t += 4) {
              var o = a.slice(t, t + 4);
              n = r(n, e.decrypt(o)), d.splice(t, 0, n[0], n[1], n[2], n[3]), n = o
            }
            if (0 == (o = 255 & d[t - 1]) || 16 < o) throw new c.exception.corrupt("7");
            if (n = 16843009 * o, !f.equal(f.bitSlice([n, n, n, n], 0, 8 * o), f.bitSlice(d, 32 * d.length - 8 * o, 32 * d.length))) throw new c.exception.corrupt("9");
            return f.bitSlice(d, 0, 32 * d.length - 8 * o)
          }
        }
      }, e.exports && (e.exports = c)
    })),
    Fe = U((function(e, a) {
      e = function(e) {
        e.version = "1.2.0";
        var a = function() {
          for (var e = 0, a = Array(256), c = 0; 256 != c; ++c) e = 1 & (e = 1 & (e = 1 & (e = 1 & (e = 1 & (e = 1 & (e = 1 & (e = 1 & (e = c) ? -306674912 ^ e >>> 1 : e >>> 1) ? -306674912 ^ e >>> 1 : e >>> 1) ? -306674912 ^ e >>> 1 : e >>> 1) ? -306674912 ^ e >>> 1 : e >>> 1) ? -306674912 ^ e >>> 1 : e >>> 1) ? -306674912 ^ e >>> 1 : e >>> 1) ? -306674912 ^ e >>> 1 : e >>> 1) ? -306674912 ^ e >>> 1 : e >>> 1, a[c] = e;
          return "undefined" != typeof Int32Array ? new Int32Array(a) : a
        }();
        e.table = a, e.bstr = function(e, c) {
          c ^= -1;
          for (var n = e.length - 1, t = 0; t < n;) c = (c = c >>> 8 ^ a[255 & (c ^ e.charCodeAt(t++))]) >>> 8 ^ a[255 & (c ^ e.charCodeAt(t++))];
          return t === n && (c = c >>> 8 ^ a[255 & (c ^ e.charCodeAt(t))]), -1 ^ c
        }, e.buf = function(e, c) {
          if (1e4 < e.length) {
            c ^= -1;
            for (var n = e.length - 7, t = 0; t < n;) c = (c = (c = (c = (c = (c = (c = (c = c >>> 8 ^ a[255 & (c ^ e[t++])]) >>> 8 ^ a[255 & (c ^ e[t++])]) >>> 8 ^ a[255 & (c ^ e[t++])]) >>> 8 ^ a[255 & (c ^ e[t++])]) >>> 8 ^ a[255 & (c ^ e[t++])]) >>> 8 ^ a[255 & (c ^ e[t++])]) >>> 8 ^ a[255 & (c ^ e[t++])]) >>> 8 ^ a[255 & (c ^ e[t++])];
            for (; t < n + 7;) c = c >>> 8 ^ a[255 & (c ^ e[t++])];
            return -1 ^ c
          }
          for (c ^= -1, n = e.length - 3, t = 0; t < n;) c = (c = (c = (c = c >>> 8 ^ a[255 & (c ^ e[t++])]) >>> 8 ^ a[255 & (c ^ e[t++])]) >>> 8 ^ a[255 & (c ^ e[t++])]) >>> 8 ^ a[255 & (c ^ e[t++])];
          for (; t < n + 3;) c = c >>> 8 ^ a[255 & (c ^ e[t++])];
          return -1 ^ c
        }, e.str = function(e, c) {
          var n, t;
          c ^= -1;
          for (var f = 0, r = e.length; f < r;) 128 > (n = e.charCodeAt(f++)) ? c = c >>> 8 ^ a[255 & (c ^ n)] : 2048 > n ? c = (c = c >>> 8 ^ a[255 & (c ^ (192 | n >> 6 & 31))]) >>> 8 ^ a[255 & (c ^ (128 | 63 & n))] : 55296 <= n && 57344 > n ? (n = 64 + (1023 & n), t = 1023 & e.charCodeAt(f++), c = (c = (c = (c = c >>> 8 ^ a[255 & (c ^ (240 | n >> 8 & 7))]) >>> 8 ^ a[255 & (c ^ (128 | n >> 2 & 63))]) >>> 8 ^ a[255 & (c ^ (128 | t >> 6 & 15 | (3 & n) << 4))]) >>> 8 ^ a[255 & (c ^ (128 | 63 & t))]) : c = (c = (c = c >>> 8 ^ a[255 & (c ^ (224 | n >> 12 & 15))]) >>> 8 ^ a[255 & (c ^ (128 | n >> 6 & 63))]) >>> 8 ^ a[255 & (c ^ (128 | 63 & n))];
          return -1 ^ c
        }
      }, "undefined" == typeof DO_NOT_EXPORT_CRC ? e(a) : e({})
    })),
    ze = Uint8Array,
    Ge = Uint16Array,
    We = Uint32Array,
    qe = new ze([0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0, 0, 0, 0]),
    He = new ze([0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13, 0, 0]),
    Ve = new ze([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]),
    Ze = function(e, a) {
      for (var c = new Ge(31), n = 0; 31 > n; ++n) c[n] = a += 1 << e[n - 1];
      for (e = new We(c[30]), n = 1; 30 > n; ++n)
        for (a = c[n]; a < c[n + 1]; ++a) e[a] = a - c[n] << 5 | n;
      return [c, e]
    },
    Xe = Ze(qe, 2),
    Ye = Xe[1];
  Xe[0][28] = 258, Ye[258] = 28;
  for (var Ke = Ze(He, 0)[1], Qe = new Ge(32768), $e = 0; 32768 > $e; ++$e) {
    var ea = (43690 & $e) >>> 1 | (21845 & $e) << 1;
    ea = (61680 & (ea = (52428 & ea) >>> 2 | (13107 & ea) << 2)) >>> 4 | (3855 & ea) << 4, Qe[$e] = ((65280 & ea) >>> 8 | (255 & ea) << 8) >>> 1
  }
  var aa = function(e, a, c) {
      for (var n = e.length, t = 0, f = new Ge(a); t < n; ++t) ++f[e[t] - 1];
      var r = new Ge(a);
      for (t = 0; t < a; ++t) r[t] = r[t - 1] + f[t - 1] << 1;
      if (c) {
        for (c = new Ge(1 << a), f = 15 - a, t = 0; t < n; ++t)
          if (e[t]) {
            var d = t << 4 | e[t],
              o = a - e[t],
              i = r[e[t] - 1]++ << o;
            for (o = i | (1 << o) - 1; i <= o; ++i) c[Qe[i] >>> f] = d
          }
      } else
        for (c = new Ge(n), t = 0; t < n; ++t) c[t] = Qe[r[e[t] - 1]++] >>> 15 - e[t];
      return c
    },
    ca = new ze(288);
  for ($e = 0; 144 > $e; ++$e) ca[$e] = 8;
  for ($e = 144; 256 > $e; ++$e) ca[$e] = 9;
  for ($e = 256; 280 > $e; ++$e) ca[$e] = 7;
  for ($e = 280; 288 > $e; ++$e) ca[$e] = 8;
  var na = new ze(32);
  for ($e = 0; 32 > $e; ++$e) na[$e] = 5;
  var ta, fa, ra, da = aa(ca, 9, 0),
    oa = aa(na, 5, 0),
    ia = function(e, a, c) {
      (null == a || 0 > a) && (a = 0), (null == c || c > e.length) && (c = e.length);
      var n = new(e instanceof Ge ? Ge : e instanceof We ? We : ze)(c - a);
      return n.set(e.subarray(a, c)), n
    },
    ba = function(e, a, c) {
      c <<= 7 & a, e[a = a / 8 >> 0] |= c, e[a + 1] |= c >>> 8
    },
    sa = function(e, a, c) {
      c <<= 7 & a, e[a = a / 8 >> 0] |= c, e[a + 1] |= c >>> 8, e[a + 2] |= c >>> 16
    },
    ua = function(e, a) {
      for (var c = [], n = 0; n < e.length; ++n) e[n] && c.push({
        s: n,
        f: e[n]
      });
      var t = c.length;
      if (e = c.slice(), !t) return [new ze(0), 0];
      if (1 == t) return (a = new ze(c[0].s + 1))[c[0].s] = 1, [a, 1];
      c.sort((function(e, a) {
        return e.f - a.f
      })), c.push({
        s: -1,
        f: 25001
      }), n = c[0];
      var f = c[1],
        r = 0,
        d = 1,
        o = 2;
      for (c[0] = {
          s: -1,
          f: n.f + f.f,
          l: n,
          r: f
        }; d != t - 1;) n = c[c[r].f < c[o].f ? r++ : o++], f = c[r != d && c[r].f < c[o].f ? r++ : o++], c[d++] = {
        s: -1,
        f: n.f + f.f,
        l: n,
        r: f
      };
      for (f = e[0].s, n = 1; n < t; ++n) e[n].s > f && (f = e[n].s);
      var i = new Ge(f + 1);
      if ((d = ha(c[d - 1], i, 0)) > a) {
        for (c = n = 0, r = 1 << (f = d - a), e.sort((function(e, a) {
            return i[a.s] - i[e.s] || e.f - a.f
          })); n < t && (o = e[n].s, i[o] > a); ++n) c += r - (1 << d - i[o]), i[o] = a;
        for (c >>>= f; 0 < c;) t = e[n].s, i[t] < a ? c -= 1 << a - i[t]++ - 1 : ++n;
        for (; 0 <= n && c; --n) t = e[n].s, i[t] == a && (--i[t], ++c);
        d = a
      }
      return [new ze(i), d]
    },
    ha = function e(a, c, n) {
      return -1 == a.s ? Math.max(e(a.l, c, n + 1), e(a.r, c, n + 1)) : c[a.s] = n
    },
    la = function(e) {
      for (var a = e.length; a && !e[--a];);
      for (var c = new Ge(++a), n = 0, t = e[0], f = 1, r = function(e) {
          c[n++] = e
        }, d = 1; d <= a; ++d)
        if (e[d] == t && d != a) ++f;
        else {
          if (!t && 2 < f) {
            for (; 138 < f; f -= 138) r(32754);
            2 < f && (r(10 < f ? f - 11 << 5 | 28690 : f - 3 << 5 | 12305), f = 0)
          } else if (3 < f) {
            for (r(t), --f; 6 < f; f -= 6) r(8304);
            2 < f && (r(f - 3 << 5 | 8208), f = 0)
          }
          for (; f--;) r(t);
          f = 1, t = e[d]
        } return [c.subarray(0, n), a]
    },
    pa = function(e, a) {
      for (var c = 0, n = 0; n < a.length; ++n) c += e[n] * a[n];
      return c
    },
    ga = function(e, a, c) {
      var n = c.length;
      e[a = ((a += 2) / 8 >> 0) + (7 & a && 1)] = 255 & n, e[a + 1] = n >>> 8, e[a + 2] = 255 ^ e[a], e[a + 3] = 255 ^ e[a + 1];
      for (var t = 0; t < n; ++t) e[a + t + 4] = c[t];
      return 8 * (a + 4 + n)
    },
    va = function(e, a, c, n, t, f, r, d, o, i, b) {
      ba(a, b++, c), ++t[256];
      for (var s = (c = ua(t, 15))[0], u = c[1], h = (c = ua(f, 15))[0], l = c[1], p = (c = la(s))[0], g = c[1], v = (c = la(h))[0], y = c[1], m = new Ge(19), w = 0; w < p.length; ++w) m[31 & p[w]]++;
      for (w = 0; w < v.length; ++w) m[31 & v[w]]++;
      c = (w = ua(m, 7))[0], w = w[1];
      for (var x = 19; 4 < x && !c[Ve[x - 1]]; --x);
      var S = i + 5 << 3,
        C = pa(t, ca) + pa(f, na) + r;
      if (t = pa(t, s) + pa(f, h) + r + 14 + 3 * x + pa(m, c) + (2 * m[16] + 3 * m[17] + 7 * m[18]), S <= C && S <= t) return ga(a, b, e.subarray(o, o + i));
      if (ba(a, b, 1 + (t < C)), b += 2, t < C) {
        for (e = aa(s, u, 0), o = s, i = aa(h, l, 0), s = aa(c, w, 0), ba(a, b, g - 257), ba(a, b + 5, y - 1), ba(a, b + 10, x - 4), b += 14, w = 0; w < x; ++w) ba(a, b + 3 * w, c[Ve[w]]);
        for (b += 3 * x, p = [p, v], g = 0; 2 > g; ++g)
          for (v = p[g], w = 0; w < v.length; ++w) y = 31 & v[w], ba(a, b, s[y]), b += c[y], 15 < y && (ba(a, b, v[w] >>> 5 & 127), b += v[w] >>> 12)
      } else e = da, o = ca, i = oa, h = na;
      for (w = 0; w < d; ++w) 255 < n[w] ? (y = n[w] >>> 18 & 31, sa(a, b, e[y + 257]), b += o[y + 257], 7 < y && (ba(a, b, n[w] >>> 23 & 31), b += qe[y]), c = 31 & n[w], sa(a, b, i[c]), b += h[c], 3 < c && (sa(a, b, n[w] >>> 5 & 8191), b += He[c])) : (sa(a, b, e[n[w]]), b += o[n[w]]);
      return sa(a, b, e[256]), b + o[256]
    },
    ya = new We([65540, 131080, 131088, 131104, 262176, 1048704, 1048832, 2114560, 2117632]),
    ma = new ze(0),
    wa = function() {
      for (var e = new We(256), a = 0; 256 > a; ++a) {
        for (var c = a, n = 9; --n;) c = (1 & c && 3988292384) ^ c >>> 1;
        e[a] = c
      }
      return e
    }(),
    xa = function() {
      var e = 4294967295;
      return {
        p: function(a) {
          for (var c = e, n = 0; n < a.length; ++n) c = wa[255 & c ^ a[n]] ^ c >>> 8;
          e = c
        },
        d: function() {
          return 4294967295 ^ e
        }
      }
    },
    Sa = function(e, a, c, n, t) {
      return function(e, a, c, n, t, f) {
        var r = e.length,
          d = new ze(n + r + 5 * (1 + Math.floor(r / 7e3)) + t),
          o = d.subarray(n, d.length - t),
          i = 0;
        if (!a || 8 > r)
          for (c = 0; c <= r; c += 65535)(a = c + 65535) < r ? i = ga(o, i, e.subarray(c, a)) : (o[c] = f, i = ga(o, i, e.subarray(c, r)));
        else {
          var b = ya[a - 1];
          a = b >>> 13, b &= 8191;
          for (var s = (1 << c) - 1, u = new Ge(32768), h = new Ge(s + 1), l = Math.ceil(c / 3), p = 2 * l, g = function(a) {
              return (e[a] ^ e[a + 1] << l ^ e[a + 2] << p) & s
            }, v = new We(25e3), y = new Ge(288), m = new Ge(32), w = 0, x = 0, S = (c = 0, 0), C = 0, A = 0; c < r; ++c) {
            var O = g(c),
              _ = 32767 & c,
              I = h[O];
            if (u[_] = I, h[O] = _, C <= c) {
              var D = r - c;
              if ((7e3 < w || 24576 < S) && 423 < D) {
                i = va(e, o, 0, v, y, m, x, S, A, c - A, i), S = w = x = 0, A = c;
                for (var N = 0; 286 > N; ++N) y[N] = 0;
                for (N = 0; 30 > N; ++N) m[N] = 0
              }
              var j = 2,
                T = 0,
                k = b,
                J = _ - I & 32767;
              if (2 < D && O == g(c - J)) {
                O = Math.min(a, D) - 1;
                var P = Math.min(32767, c);
                for (D = Math.min(258, D); J <= P && --k && _ != I;) {
                  if (e[c + j] == e[c + j - J]) {
                    for (N = 0; N < D && e[c + N] == e[c + N - J]; ++N);
                    if (N > j) {
                      if (j = N, T = J, N > O) break;
                      var M = Math.min(J, N - 2),
                        R = 0;
                      for (N = 0; N < M; ++N) {
                        var L = c - J + N + 32768 & 32767,
                          E = L - u[L] + 32768 & 32767;
                        E > R && (R = E, I = L)
                      }
                    }
                  }
                  J += (_ = I) - (I = u[_]) + 32768 & 32767
                }
              }
              T ? (v[S++] = 268435456 | Ye[j] << 18 | Ke[T], C = 31 & Ye[j], T = 31 & Ke[T], x += qe[C] + He[T], ++y[257 + C], ++m[T], C = c + j, ++w) : (v[S++] = e[c], ++y[e[c]])
            }
          }
          i = va(e, o, f, v, y, m, x, S, A, c - A, i), f || (i = ga(o, i, ma))
        }
        return ia(d, 0, n + ((i / 8 >> 0) + (7 & i && 1)) + t)
      }(e, null == a.level ? 6 : a.level, null == a.mem ? Math.ceil(1.5 * Math.max(8, Math.min(13, Math.log(e.length)))) : 12 + a.mem, c, n, !t)
    },
    Ca = function(e, a, c) {
      for (; c; ++a) e[a] = c, c >>>= 8
    },
    Aa = {
      gzipSync: B,
      compressSync: B,
      strToU8: function(e, a) {
        var c = e.length;
        if (!a && "undefined" != typeof TextEncoder) return (new TextEncoder).encode(e);
        for (var n = new ze(e.length + (e.length >>> 1)), t = 0, f = function(e) {
            n[t++] = e
          }, r = 0; r < c; ++r) {
          if (t + 5 > n.length) {
            var d = new ze(t + 8 + (c - r << 1));
            d.set(n), n = d
          }
          128 > (d = e.charCodeAt(r)) || a ? f(d) : 2048 > d ? (f(192 | d >>> 6), f(128 | 63 & d)) : 55295 < d && 57344 > d ? (f(240 | (d = 65536 + (1047552 & d) | 1023 & e.charCodeAt(++r)) >>> 18), f(128 | d >>> 12 & 63), f(128 | d >>> 6 & 63), f(128 | 63 & d)) : (f(224 | d >>> 12), f(128 | d >>> 6 & 63), f(128 | 63 & d))
        }
        return ia(n, 0, t)
      }
    };
  Be[n(99)].o();
  for (var Oa, _a = {}, Ia = !1, Da = !1, Na = {}, ja = [], Ta = [], ka = 0, Ja = void 0, Pa = !1, Ma = ((ta = {})[n(127)] = n(128), ta[n(129)] = n(130), ta[n(131)] = n(127), ta[n(133)] = n(134), ta), Ra = function(e) {
      return n(127) === e[n(131)] ? e[n(127)] : e[n(129)]
    }, La = ((fa = {})[n(11)] = {}, fa[n(9)] = n(125), fa), Ea = n(141), Ua = function(e) {
      for (var a, c, t, f, r, d = Date[n(142)](), o = ""; 7 > o[n(84)];) o += (f = "A" [n(144)](0), r = "Z" [n(144)](0), String[n(109)](Math[n(147)]() * (r - f) | 0 + f));
      f = (f = "" + d + o + ((c = {})[n(37)] = La[n(11)][n(37)], c[n(11)] = La[n(11)], c[n(12)] = La[n(12)], c[n(155)] = La[n(155)], me[n(157)](Aa[n(158)](JSON[n(74)](c)))))[n(160)]((t = f, (Fe[n(161)](t) >>> 0)[n(162)]()[n(163)](0, 4))), e = e ? e[n(164)] : void 0, (a = {})[n(12)] = d, a[n(166)] = f, a[n(164)] = e || f, a[n(168)] = 0, d = a;
      try {
        G({
          id: d
        })
      } catch (e) {}
      return d
    }, Ba = function() {
      var e = _a[n(169)];
      return e && e[n(164)] && e[n(166)] && e[n(12)] ? e : Ua(_a[n(169)])
    }, Fa = function() {
      return _a[n(169)] && _a[n(169)][n(168)] ? _a[n(169)][n(168)] : 0
    }, za = function(e) {
      try {
        Y(), Ia || G(_a);
        try {
          var a = wx[n(179)]()[n(180)](wx[n(131)][n(182)]),
            c = (a[n(183)], a[n(184)]),
            t = a[n(119)],
            f = a[n(186)],
            r = [16, 16, 5, 4, 10, 4, 6, 1, 14, 4, 2, 2, 6, 1, 5, 4, 7, 4, 20, 4, 19, 4, 15];
          ! function() {
            for (var e = [], a = (Function[n(187)][n(188)], 0);;) switch (r[a++]) {
              case 1:
                e[n(87)](t);
                continue;
              case 2:
                e[n(87)](r[a++]);
                continue;
              case 4:
                e[n(191)]();
                continue;
              case 5:
                e[e[n(84)] - 2] = e[e[n(84)] - 2] & e[e[n(84)] - 1];
                continue;
              case 6:
                e[n(87)](c);
                continue;
              case 7:
                e[e[n(84)] - 2] = e[e[n(84)] - 2] * e[e[n(84)] - 1];
                continue;
              case 10:
                Ta[0] = e[e[n(84)] - 1];
                continue;
              case 14:
                e[e[n(84)] - 2] = e[e[n(84)] - 2] ^ e[e[n(84)] - 1];
                continue;
              case 15:
                return;
              case 16:
                e[n(87)](~(~c + t));
                continue;
              case 19:
                Ta[1] = e[e[n(84)] - 1];
                continue;
              case 20:
                e[e[n(84)] - 2] = e[e[n(84)] - 2] + e[e[n(84)] - 1]
            }
          }(), Ta[2] = t, Ta[3] = f
        } catch (e) {}
        La[n(208)] = Ta, La[n(6)] = Na[n(210)], La[n(155)] = Na[n(212)], La[n(213)] = Na[n(214)], La[n(215)] = Na[n(216)];
        var d = Ba();
        La[n(7)] = d[n(164)], La[n(10)] = d[n(166)], La[n(8)] = d[n(12)], e && setTimeout((function() {
          e(La)
        }), 200)
      } catch (a) {
        e && e(La);
        try {
          Oa && Oa[n(223)](n(224), a)
        } catch (e) {}
      }
    }, Ga = 0, Wa = 0, qa = 0, Ha = function() {
      try {
        wx.onCompassChange && wx.offCompassChange && wx.onCompassChange(q), wx.onAccelerometerChange && wx.offAccelerometerChange && wx.onAccelerometerChange(V), wx.startGyroscope({
          interval: "normal",
          success: function(e) {}
        }), wx.onGyroscopeChange && wx.offGyroscopeChange && wx.onGyroscopeChange(X)
      } catch (e) {}
    }, Va = function(e) {
      return (10 > e ? "0" : "") + e
    }, Za = function() {
      var e = new Date;
      return e[n(302)]() + "-" + Va(e[n(303)]() + 1) + "-" + Va(e[n(304)]()) + " " + Va(e[n(305)]()) + ":" + Va(e[n(306)]()) + ":" + Va(e[n(307)]())
    }, Xa = function(a, c, t) {
      function f(c) {
        try {
          var t, f = Date[n(142)](),
            r = ((t = {})[n(309)] = n(125), t[n(275)] = ((d = c)[n(13)] = ja, d[n(208)] = Ta, d.e = Error()[n(313)], Ea[n(160)](F(Be[n(111)][n(112)][n(113)](JSON[n(74)](d))))), t[n(319)] = n(125), t[n(320)] = Za(), t[n(321)] = n(1) != ("undefined" == typeof mmp ? "undefined" : e(mmp)) ? n(322) : n(323), t);
          a[n(324)]({
            url: Ra(Ma) + n(325),
            method: n(326),
            data: r,
            header: {
              "content-type": n(327)
            },
            success: function(a) {
              La[n(328)]++;
              var c = 200;
              if (200 === a[n(329)]) {
                var t = a[n(275)];
                if (t[n(275)] && t[n(275)][n(277)] && n(278) == e(t[n(275)][n(280)])) {
                  var d, o = 0;
                  t[n(275)][n(282)] && n(278) == e(t[n(275)][n(282)]) && (o = t[n(275)][n(282)] - Date[n(142)]()), G({
                    id: (d = {}, d[n(164)] = t[n(275)][n(277)], d[n(168)] = o, d[n(293)] = 36e5 * t[n(275)][n(280)] + Date[n(142)]() + o, d)
                  }, !0), t[n(275)][n(277)] && Oa && Oa[n(299)](n(300), 200, 200, Date[n(142)]() - ka, .1)
                }
                a[n(275)] && 200 !== a[n(275)][n(333)] && (c = a[n(275)][n(333)])
              }
              Oa && Oa[n(299)](n(337), a[n(329)], c, Date[n(142)]() - f, .1), Oa && Oa[n(299)](n(341), 200, 200, JSON[n(74)](r)[n(84)], .1)
            }
          })
        } catch (d) {
          try {
            Oa && Oa[n(223)](n(345), d), Oa && Oa[n(299)](n(337), 200, 9403, Date[n(142)]() - f, .1)
          } catch (e) {}
        }
        var d
      }
      void 0 === t && (t = !1), t ? za(f) : a[n(349)] || ((t = _a[n(169)]) && t[n(293)] && (new Date)[n(352)]() < t[n(293)] || (a[n(349)] = !0, Ja || (Ja = a), Ma = Object[n(355)](Ma, c), La[n(328)] = 0, za(f)))
    }, Ya = ((ra = {})[n(357)] = {
      api: n(358),
      fingerData: n(11)
    }, ra[n(360)] = {
      api: n(361),
      fingerData: n(38)
    }, ra[n(23)] = {
      api: n(364),
      fingerData: n(23)
    }, ra[n(366)] = {
      api: n(367),
      fingerData: n(368)
    }, ra[n(369)] = {
      api: n(370),
      fingerData: n(19)
    }, ra[n(372)] = {
      api: n(373),
      fingerData: n(374)
    }, ra[n(375)] = {
      api: n(376),
      fingerData: n(32)
    }, ra[n(378)] = {
      api: n(379),
      fingerData: n(17)
    }, ra[n(381)] = {
      api: n(382),
      fingerData: n(381)
    }, ra), Ka = {
      d: function() {
        Ia || G(_a);
        var e = _a.id;
        return e && e.dfpId ? e.dfpId : Ua(e).dfpId
      },
      s: function(e) {
        Na.appId = e
      },
      o: function(e) {
        Na.openId = e
      },
      u: function(e) {
        Na.unionId = e
      },
      m: function(e) {
        Na.mchId = e
      },
      su: function(a) {
        "object" == e(a) && (La.userInfo = a)
      },
      g: function(e) {
        var a = Date.now();
        za((function(c) {
          var n = Ea;
          try {
            var t = JSON.parse(JSON.stringify(c));
            if (delete t.fsmode, delete t.e, delete t.ext, delete t.system.gyro, delete t.dp, delete t.sessionId, delete t.system.screenRecord, delete t.system.wifiList, void 0 !== t.system.StorageInfo) {
              var f = JSON.parse(t.system.StorageInfo);
              f.keys = [], t.system.StorageInfo = JSON.stringify(f)
            }
            var r = JSON.stringify(t);
            n += F(Be.codec.utf8String.toBits(r)), e && e(n), Oa && Oa.addApi("dfp_finger", 200, 200, Date.now() - a, .01), Oa && Oa.addApi("dfp_finger_length", 200, 200, n.length, .01)
          } catch (c) {
            e && e(n);
            try {
              Oa && Oa.addError("getFinger", c), Oa && Oa.addApi("dfp_finger", 200, 9401, Date.now() - a, .01)
            } catch (e) {}
          }
        }))
      },
      i: function() {
        var a = "w1.3";
        if (Y(), Ia || G(_a), !Da) try {
          Date.now(),
            function() {
              try {
                ja[0] = "undefined" == typeof NativeClient ? 0 : 1, ja[1] = "undefined" == typeof addEventListener ? 0 : 1;
                try {
                  var e = wx.getPublicLibVersion(),
                    a = 0 < Object.keys(e).length ? e.system == La.system.platform ? 1 : 0 : 2
                } catch (e) {}
                ja[2] = a, ja[3] = "undefined" == typeof __WeixinJSBridge ? 0 : 1;
                var c = 4;
                if (wx.canIUse("getNFCAdapter")) {
                  var n, t = wx.getNFCAdapter(),
                    f = ((n = {}).not_open = 13001, n.no_nfc = 13e3, n);
                  t.startDiscovery({
                    success: function(e) {
                      void 0 === e.errCode ? (c = 1, ja[4] = c, t.stopDiscovery({
                        success: function(e) {},
                        fail: function(e) {}
                      })) : (e.errCode == f.no_nfc && (c = 3, ja[4] = c), e.errCode == f.not_open && (c = 2, ja[4] = c))
                    },
                    fail: function(e) {
                      c = 0, ja[4] = c
                    }
                  })
                }
                ja[4] = c
              } catch (e) {
                try {
                  Oa && Oa.addError("ext", e)
                } catch (e) {}
              }
            }(), Da = !0
        } catch (e) {
          try {
            Oa && Oa.addError("getFingerExt", e)
          } catch (e) {}
        }
        La.ext = ja, La.app = Na.appId, La.openid = Na.openId, La.unionid = Na.unionId, La.mchid = Na.mchId, La.sessionId = Na.sessionId;
        var c, t = Ba();
        La.dfpid = t.dfpId, La.localid = t.localId, La.filetime = t.timestamp;
        try {
          var f = (c = La, JSON[n(74)](function a(c, t) {
            var f, r = [];
            for (t = E(t); !(f = t())[n(75)];) {
              var d = c[f = f[n(76)]];
              if (n(32) === f && d && (d = JSON[n(78)](d), d = JSON[n(74)]({
                  path: d[n(80)],
                  scene: d[n(81)]
                })), n(15) === f && d && Array[n(83)](d) && 0 < d[n(84)]) {
                var o, i = [];
                for (d = E(d); !(o = d())[n(75)];)(o = o[n(76)]).x && o.y && o.z && i[n(87)]([o.x, o.y, o.z]);
                d = i
              }
              n(17) !== f && n(54) !== f && n(45) !== f || d && n(91) == e(d) && (d = JSON[n(78)](d)), n(0) == e(d) && f in Ue ? r[n(87)](a(d, Ue[f])) : r[n(87)](d)
            }
            return r
          }(c, Ue[n(96)])));
          f = Aa.gzipSync(Aa.strToU8(f)), a += F(Be.codec.bytes.toBits(f))
        } catch (e) {
          try {
            Oa && Oa.addError("getSiua", e)
          } catch (e) {}
        }
        return a
      },
      t: Xa,
      std: Fa,
      l: function(a) {
        "object" == e(a) && (a._factitious = !0, Na.factitiouslocation = !0, La.location = a)
      },
      sd: function(a, c) {
        "object" == e(a) && ("systeminfo" == c ? Object.assign(La.system, a) : La.system[c] = "batteryinfo" == c || "storageinfo" == c || "LaunchOptionsSync" == c || "wifiList" == c ? JSON.stringify(a) : a)
      },
      gis: function(e) {
        Object.keys(Ya).forEach((function(a) {
          ! function(e, a) {
            try {
              if (!e[a]) try {
                var c = Ya[a].api,
                  n = Ya[a].fingerData;
                "getLaunchOptionsSync" == c && (La.system[n] = JSON.stringify(wx.getLaunchOptionsSync())), wx[c]({
                  success: function(e) {
                    if ("getSystemInfo" == c) Object.assign(La.system, e);
                    else if ("getNetworkType" == c) {
                      La.system.networkType = e.networkType;
                      try {
                        wx.onNetworkStatusChange((function(e) {
                          La.system.networkType = e.networkType
                        }))
                      } catch (e) {}
                    } else "getScreenBrightness" == c ? La.system.brightness = e.value : "getBeacons" == c ? La.system.Beacons = JSON.stringify(e.beacons) : "getScreenRecordingState" == c ? (La.system.screenRecord = [], K(e), function() {
                      try {
                        wx.onScreenRecordingStateChanged((function(e) {
                          K(e)
                        }))
                      } catch (e) {}
                    }()) : La.system[n] = JSON.stringify(e)
                  }
                })
              } catch (e) {}
            } catch (e) {}
          }(e, a)
        }));
        try {
          wx.getPrivacySetting ? wx.getPrivacySetting({
            success: function(e) {
              e.needAuthorization || Ha()
            }
          }) : Ha()
        } catch (e) {}! function(e) {
          try {
            e.wifiinfo || wx.getSetting({
              success: function(a) {
                try {
                  a.authSetting && a.authSetting["scope.userLocation"] && wx.startWifi({
                    success: function() {
                      wx.getConnectedWifi({
                        success: function(e) {
                          La.system.WifiInfo = JSON.stringify(e.wifi)
                        }
                      });
                      try {
                        e.wifiList || "android" != La.system.platform || wx.getWifiList({
                          success: function(e) {
                            try {
                              wx.onGetWifiList((function(e) {
                                La.system.wifiList = JSON.stringify(e.wifiList), !Pa && Ja && (Pa = !0, Xa(Ja, {}, !0))
                              }))
                            } catch (e) {}
                          }
                        })
                      } catch (e) {}
                    }
                  })
                } catch (e) {}
              }
            })
          } catch (e) {}
        }(e)
      },
      ss: function(e) {
        Na.sessionId = e
      },
      bio: function(e, a, c) {
        delete e.appid, delete e.dfpid, za((function(t) {
          t = JSON.stringify(t), t = JSON.parse(t), Object.assign(t, e), e = {},
            function(e, a, c) {
              try {
                var t, f = Aa.gzipSync(Aa.strToU8(JSON.stringify(e))),
                  r = Ea.concat(F(Be.codec.bytes.toBits(f)));
                e = {};
                var d = Ra(Ma) + "/fingerprint/v1/notapp/bio/info/report",
                  o = Date.now(),
                  i = ((t = {}).jsgVersion = n(125), t.fingerPrintData = r, t.encryptVersion = 1, t.jsdfpVersion = n(125), t.time = Za(), t.src = "2", t.index = a, t);
                c.request({
                  url: d,
                  method: "POST",
                  data: i,
                  header: {
                    "content-type": "application/json"
                  },
                  success: function(e) {
                    try {
                      var a = 0;
                      200 === e.statusCode && e.data && 0 !== e.data.code && (a = e.data.code), Oa && Oa.addApi("dfp_bio_req", e.statusCode, a, Date.now() - o, .1), Oa && Oa.addApi("dfp_bio_req_length", 200, 200, JSON.stringify(i).length, .1)
                    } catch (e) {
                      try {
                        Oa && Oa.addError("sendBio", e), Oa && Oa.addApi("dfp_bio_req", 200, 9403, Date.now() - o, .1)
                      } catch (e) {}
                    }
                  }
                })
              } catch (e) {
                try {
                  Oa && Oa.addError("sendBio", e), Oa && Oa.addApi("dfp_bio_req", 200, 9404, Date.now() - o, .1)
                } catch (e) {}
              }
            }(t, a, c)
        }))
      },
      owl: function(e, a, c) {
        a && c ? (Oa = a, ka = c || Date.now()) : Oa && Oa.jsgowl() || Oa && e && Oa.initCat(e)
      },
      myguard: {}
    }, Qa = {}, $a = "", ec = {}, ac = {}, cc = [], nc = "1.2", tc = "", fc = "", rc = 0, dc = 0; 64 > dc; ++dc) cc[dc] = "ZmserbBoHQtNP+wOcza/LpngG8yJq42KWYj0DSfdikx3VT16IlUAFM97hECvuRX5" [dc];
  var oc = n(429),
    ic = n(327),
    bc = function() {
      for (var a, c, t = 256, f = []; t--; f[t] = a >>> 0)
        for (c = 8, a = t; c--;) a = 1 & a ? a >>> 1 ^ 3988292384 : a >>> 1;
      return function(a) {
        if (n(91) == e(a)) {
          for (var c = 0, t = -1; c < a[n(84)]; ++c) t = f[255 & t ^ a[n(144)](c)] ^ t >>> 8;
          return 306674911 ^ t
        }
        for (c = 0, t = -1; c < a[n(84)]; ++c) t = f[255 & t ^ a[c]] ^ t >>> 8;
        return 306674911 ^ t
      }
    }();
  return {
    init: function(e) {
      return a = e, new Promise((function(e, c) {
        se(a, !0, e)
      }));
      var a
    },
    initSync: function(e) {
      return se(e, !1), ec
    },
    finger: Ka,
    doInitProxy: function() {
      Pe[n(678)]()
    },
    clickTrack: ue
  }
}));