var t = require("../../../../b/helpers/interopRequireDefault"),
  e = require("../../../../b/helpers/slicedToArray");
require("../../../../b/helpers/Objectentries");
var a = require("../../../../b/helpers/objectSpread2"),
  s = require("../../../@limo/container/behaviors/index"),
  i = t(require("../../../../api/rmsStorage")),
  n = require("../../../../modules/panel/spec/specPanelData"),
  r = require("../../../../modules/panel/spec/util"),
  o = require("../../../../modules/panel/mp-spec/util"),
  u = require("../../../../modules/panel/panelTransaction"),
  h = require("../../../../modules/panel/spec/mutex"),
  l = require("../../../../modules/cartHelper"),
  d = require("../../../../constants/menu"),
  D = t(require("../../../../modules/menu/I18n/I18nService"));
Component({
  behaviors: [s.commonBehavior, s.limoShim],
  properties: {
    shopId: {
      type: String
    },
    specSpuId: {
      type: String
    },
    showMultiPanel: {
      type: Boolean,
      value: !1
    },
    multiVisible: {
      type: Boolean,
      value: !1
    },
    customHandleOperationEvent: {
      type: Boolean,
      value: !1
    },
    optionsDishData: {
      type: Object,
      value: {}
    },
    isNativeTabbarPage: {
      type: Boolean,
      value: !1
    },
    refactorCartDishMap: {
      type: Object,
      value: {}
    },
    canClickCountNum: {
      type: Boolean,
      value: !1
    },
    hidePrice: {
      type: Boolean,
      value: !1
    },
    btnTitle: {
      type: String,
      value: ""
    }
  },
  data: {
    panelHeaderDish: {},
    attrsGroups: {},
    methodGroups: {},
    tasteGroups: {},
    panelFooterData: {},
    operationData: {
      count: 0
    },
    selectedDishData: {
      selectedManualCampaigns: {}
    },
    enableClick: !1,
    remarkText: "",
    showDishRemark: !0,
    showRemarkPanel: !1,
    panelPromoData: void 0,
    detailDescription: ""
  },
  attached: function() {
    this.limoAttached()
  },
  observers: {
    "shopId, specSpuId, optionsDishData.**, showMultiPanel": function() {
      this.handlePropertiesChange()
    },
    "selectedDishData.**": function() {
      this.handleSelectedDishData()
    }
  },
  methods: {
    limoAttached: function() {
      var t;
      this.handlePropertiesChange(), this.handleSelectedDishData();
      var e = D.default.getCurrency();
      this.setData({
        currency: e
      }), null != (t = this.data.optionsDishData) && t.hiddenAddDishButton || this.triggerEvent("reportMultiPanel")
    },
    handlePropertiesChange: function() {
      var t = this.data,
        e = t.shopId,
        a = t.specSpuId,
        s = t.optionsDishData,
        n = t.showMultiPanel,
        r = i.default.getDishList(e, !1),
        u = s.selectedDishData,
        D = s.dish,
        p = s.discount,
        c = this.data.refactorCartDishMap,
        m = D || r[a];
      if (this.spuDish = p === d.POINT_DISH_TYPE ? (0, l.getPointPurchaseSpu)(m).pointDish : m, this.spuDish && n)
        if (this.attrsMatrix = (0, h.initAttrsMatrix)(this.spuDish), u) this.setData({
          selectedDishData: u
        });
        else {
          var g = (0, o.getSelectedDishDataFromOrigin)(this.spuDish, c, s, this.attrsMatrix);
          this.setData({
            selectedDishData: g
          })
        } n || this.clearPanelData()
    },
    handleSelectedDishData: function() {
      var t, e, s = this.data.selectedDishData;
      if (Object.keys(s).length && this.spuDish) {
        var i = this.data,
          h = i.optionsDishData,
          l = i.refactorCartDishMap,
          D = h.fromPackagePanel,
          p = void 0 !== D && D,
          c = h.editDishGoodsNo,
          m = void 0 === c ? "" : c,
          g = h.hidePromotion,
          v = void 0 !== g && g,
          f = h.discount,
          P = (0, n.transSpecData)(s, this.spuDish, this.attrsMatrix),
          k = P.attrsGroups,
          C = P.methodGroups,
          I = P.tasteGroups,
          M = (0, o.getPanelHeaderDish)(this.spuDish, s.skuId, "", f),
          b = p || v || f === d.POINT_DISH_TYPE ? null : (0, o.getPanelPromoData)(this.spuDish, s),
          S = (0, o.getPanelFooterData)(this.spuDish, s, p, f),
          T = (0, o.getOperationData)(this.spuDish, s, l, null == (t = this.spuDish) ? void 0 : t.showMultipleInput, m),
          y = (0, r.checkPanelGroupValid)(this.spuDish, s, !1);
        this.setData({
          attrsGroups: k,
          methodGroups: C,
          tasteGroups: I,
          panelHeaderDish: a(a({}, M), {}, {
            fromPackagePanel: p
          }),
          panelPromoData: b,
          panelFooterData: S,
          operationData: T,
          enableClick: y,
          remarkText: (null == s || null == (e = s.remark) ? void 0 : e.customRemark) || "",
          detailDescription: this.spuDish.detailDescription || ""
        }, (function() {
          u.PanelTransaction.success(u.PANEL_TYPE.MULTI_PANEL)
        }))
      }
    },
    clearPanelData: function() {
      this.setData({
        attrsGroups: {},
        methodGroups: {},
        tasteGroups: {},
        panelHeaderDish: {},
        panelFooterData: {},
        selectedDishData: {}
      })
    },
    closePanel: function() {
      this.triggerEvent("closeMultiPanel")
    },
    selectedSpec: function(t) {
      var e = this.data,
        a = e.selectedDishData,
        s = e.refactorCartDishMap,
        i = t.detail.id,
        n = this.spuDish.skuMenuItems.find((function(t) {
          return t.skuId === i
        }));
      if (n && !n.soldOut) {
        var r, o = -1 === this.spuDish.minBoughtCount ? this.spuDish.incBoughtCount : this.spuDish.minBoughtCount,
          u = s[this.spuDish.spuId.toString()];
        u && (r = u.find((function(t) {
          return t.skuId === i
        })));
        var h = r ? this.spuDish.incBoughtCount : o,
          l = JSON.parse(JSON.stringify(a));
        l.skuId = i, l.count = h, l.memberPrice = n.memberPrice, l.selectedManualCampaigns = {}, this.setData({
          selectedDishData: l
        })
      }
    },
    changeMethods: function(t) {
      var e = t.detail,
        a = e.id,
        s = e.groupId,
        i = this.data.selectedDishData,
        n = (0, o.updateSkuDishMethods)(this.spuDish, i, s, a);
      n && this.setData({
        selectedDishData: n
      })
    },
    changeTastes: function(t) {
      var e, a = t.detail,
        s = a.id,
        i = a.groupId,
        n = a.selected,
        r = this.data.selectedDishData;
      (e = n ? (0, o.minusMultiTaste)(this.spuDish, r, i, s) : (0, o.addMultiTaste)(this.spuDish, r, i, s)) && this.setData({
        selectedDishData: e
      })
    },
    addMultiTaste: function(t) {
      var e = t.detail,
        a = e.id,
        s = e.groupId,
        i = this.data.selectedDishData,
        n = (0, o.addMultiTaste)(this.spuDish, i, s, a);
      n && this.setData({
        selectedDishData: n
      })
    },
    minusTaste: function(t) {
      var e = t.detail,
        a = e.id,
        s = e.groupId,
        i = this.data.selectedDishData,
        n = (0, o.minusMultiTaste)(this.spuDish, i, s, a);
      n && this.setData({
        selectedDishData: n
      })
    },
    handleMutex: function(t) {
      var e = t.detail,
        a = e.id,
        s = e.groupId,
        i = e.type;
      if (!this.attrsMatrix) return !1;
      var n = this.data.selectedDishData;
      (0, h.dealAttrMutexConfirm)(n, this.attrsMatrix, {
        id: a,
        groupId: s,
        type: i
      })
    },
    operationCountFn: function(t) {
      var e = t.detail,
        a = e.type,
        s = e.showCal,
        i = void 0 !== s && s,
        n = this.data,
        r = n.selectedDishData,
        u = n.optionsDishData,
        h = n.refactorCartDishMap,
        l = u.editDishGoodsNo,
        d = void 0 === l ? "" : l;
      if (i) this.triggerEvent("showClaPanel", {
        selectedDishData: r
      });
      else {
        if ("plus" === a) {
          var D = (0, o.addPanelSkuDish)(this.spuDish, r, h, d, !0);
          D && this.setData({
            selectedDishData: D
          })
        }
        if ("minus" === a) {
          var p = (0, o.addPanelSkuDish)(this.spuDish, r, h, d, !1);
          p && this.setData({
            selectedDishData: p
          })
        }
      }
    },
    operationBtnClickFn: function(t) {
      var e = t.detail.operation,
        a = this.data,
        s = a.customHandleOperationEvent,
        i = a.selectedDishData;
      s && this.triggerEvent("multiOperationBtnClick", {
        operation: e,
        selectedDishData: i
      })
    },
    clickAddCart: function() {
      var t = this.data,
        e = t.selectedDishData;
      if (t.enableClick) {
        var a = this.getManualCampaigns();
        this.triggerEvent("multiPanelClickAddCart", {
          selectedDishData: e,
          manualCampaigns: a
        })
      } else(0, r.checkPanelGroupValid)(this.spuDish, e, !0)
    },
    setToggleDishRemarkPanel: function() {
      var t = this.data.showRemarkPanel;
      this.setData({
        showRemarkPanel: !t
      })
    },
    updateDishRemark: function(t) {
      var e = t.detail.remarkText,
        a = void 0 === e ? "" : e;
      this.setToggleDishRemarkPanel(), this.setData({
        "selectedDishData.remark": {
          customRemark: a
        }
      })
    },
    operationCount: function(t) {
      var e, s = t.currentTarget.dataset.campaign,
        i = t.detail.count,
        n = s.skuId,
        r = s.campaignId,
        o = this.data.selectedDishData.selectedManualCampaigns,
        u = void 0 === o ? {} : o,
        h = null != (e = u[r]) ? e : {};
      i ? h[n] = a(a({}, s), {}, {
        count: i
      }) : delete h[n], u[r] = h, this.setData({
        "selectedDishData.selectedManualCampaigns": u
      })
    },
    getManualCampaigns: function() {
      var t = this.data,
        a = t.panelPromoData,
        s = t.selectedDishData;
      if (!a) return [];
      var i = s.selectedManualCampaigns || {};
      return Object.entries(i).map((function(t) {
        var a, s = e(t, 2),
          i = s[0],
          n = s[1],
          r = null == (a = Object.keys(n)) ? void 0 : a.map((function(t) {
            var e = n[t],
              a = e.spuId,
              s = e.skuName;
            return {
              skuId: t,
              spuId: a,
              skuName: void 0 === s ? "" : s,
              count: e.count
            }
          })).sort((function(t, e) {
            return Number(t.skuId) - Number(e.skuId)
          }));
        return {
          campaignType: 6,
          campaignId: Number(i),
          campaignSkus: r
        }
      })).filter((function(t) {
        return !!t
      })).sort((function(t, e) {
        return t.campaignId - e.campaignId
      }))
    },
    prevent: function() {}
  }
});