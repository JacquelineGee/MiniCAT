var A = require("../../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.PanelTransaction = exports.PANEL_TYPE = void 0;
var r, e = require("../../miniprogram_npm/@mtfe/rms-sdk/index.js"),
  E = A(require("../../lib/mix/log")),
  _ = ((r = _ || {}).PACKAGE_PANEL = "PACKAGE_PANEL", r.MULTI_PANEL = "MULTI_PANEL", r.CALCULATOR_PANEL = "CALCULATOR_PANEL", r.DISH_DETAIL_PANEL = "DISH_DETAIL_PANEL", r.CART_PANEL = "CART_PANEL", r.MUST_DISH_PANEL = "MUST_DISH_PANEL", r.ADD_ON_PANEL = "ADD_ON_PANEL", r.DISH_REMARK_PANEL = "DISH_REMARK_PANEL", r.PACKAGE_DETAILS_PANEL = "PACKAGE_DETAILS_PANEL", r.TAKE_COUPON_PANEL = "TAKE_COUPON_PANEL", r);
exports.PANEL_TYPE = _;
var t = E.default,
  s = {
    transactions: {},
    init: function(A) {
      try {
        this.transactions[A] = new e.Transaction(A + "_SET_DATA")
      } catch (r) {
        t.addError("Panel-Transaction-Init-" + A, r)
      }
    },
    success: function(A) {
      try {
        var r = this.transactions[A];
        r && (r.success(), delete this.transactions[A])
      } catch (r) {
        t.addError("Panel-Transaction-Success-" + A, r)
      }
    }
  };
exports.PanelTransaction = s;