var e = require("../../../../b/helpers/interopRequireDefault"),
  t = require("../../../../b/helpers/toConsumableArray"),
  i = require("../../../../b/helpers/objectSpread2"),
  a = require("../../../../miniprogram_npm/@limo/container/behaviors/index"),
  o = e(require("../../../../miniprogram_npm/seamless-immutable/index.js")),
  r = require("../../../../modules/collocation/collocation"),
  s = e(require("../../../../api/rmsStorage")),
  n = require("../../../../modules/collocation/lx"),
  l = e(require("../../../../store/menu")),
  u = require("../../../../constants/menu"),
  h = e(require("../../../../store/helpers/storeBehavior"));
Component({
  behaviors: [h.default, a.commonBehavior, a.limoShim],
  options: {
    addGlobalClass: !0
  },
  properties: {
    collocationSingleDish: {
      type: Object,
      value: {},
      observer: function(e) {
        e && Object.keys(e).length && this.setData(i({}, e))
      }
    },
    options: {
      type: Object,
      value: {}
    }
  },
  data: {
    DGFStyles: u.DGFStyles,
    isLogin: !1
  },
  observers: {
    "cartDishList.**": function(e) {
      var t = this.data,
        i = t.spuId,
        a = t.skuId,
        o = (t.options || {}).shopId,
        n = s.default.getDishList(o, !1);
      if (n) {
        var l = n[i];
        i && a && l && this.setData({
          showOperationData: (0, r.setDishOperationData)(l, e, u.DISH_ITEM_TYPE_VAL.COLLOCATION, a)
        })
      }
    }
  },
  created: function() {
    this.store = l.default
  },
  attached: function() {
    this.limoAttached()
  },
  methods: {
    limoAttached: function() {
      this.dealDGfStyle()
    },
    limoReady: function() {
      this.helpersStoreBehavior_limoReady()
    },
    mapToState: function(e) {
      return {
        cartDishList: o.default.getIn(e, ["cart", "cartDishList"]) || (0, o.default)({})
      }
    },
    operateDish: function(e) {
      var t = this.data,
        a = t.skuId,
        o = t.__newReportConfig__,
        r = t.showOperationData,
        s = e.detail,
        l = s.type,
        u = s.count;
      if ("plus" === l) {
        var h = u - r.count;
        (0, n.collocationDishAddMC)(o, h)
      }
      this.triggerEvent("operateDishFn", i(i({}, e.detail), {}, {
        skuId: a
      }))
    },
    dealPanelData: function() {
      var e = this.data,
        t = e.skuId,
        i = e.showOperationData,
        a = e.__newReportConfig__;
      this.triggerEvent("dealPanelDataFn", {
        operationData: i,
        skuId: t,
        __newReportConfig__: a
      })
    },
    dealDGfStyle: function() {
      var e, i;
      if (null != (e = this.data.tagList) && e.length) {
        var a = u.DGFStyleTypeEnum["collocation-dish-item"],
          o = !(null == (i = this.store.getState().extraInfo) || null == (i = i.headInfo) || null == (i = i.memberInfo) || !i.memberId),
          r = this.data.tagList || [],
          s = [],
          n = r.reduce((function(e, i) {
            if (16 !== i.colorType) return [].concat(t(e), [i]);
            s = [i]
          }), []);
        this.setData({
          isLogin: o,
          DGFStyleType: a,
          tagListOnlyMemberPrice: s,
          tagListWithoutMemberPrice: n
        })
      }
    }
  },
  ready: function() {
    this.limoReady()
  }
});