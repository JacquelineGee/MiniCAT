var e = require("../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.default = void 0;
var r = require("../b/helpers/objectSpread2"),
  t = require("../b/helpers/slicedToArray");
require("../b/helpers/Objectentries");
var o = e(require("../constants/storage")),
  a = {
    DINING_STYLE_VO: {
      key: "DINING_STYLE_VO",
      storeTime: 1 * require("../constants/time").HOURS
    }
  };
o.default[Symbol.for("ADDED_MENU_KEYS")] || (o.default[Symbol.for("ADDED_MENU_KEYS")] = !0, Object.entries(a).forEach((function(e) {
  var a = t(e, 2),
    s = a[0],
    i = a[1];
  if (o.default[s]) throw Error("Conflicted storage key ".concat(s, ", please choose another key name."));
  o.default[s] = r(r({}, i), {}, {
    key: s
  })
})));
var s = o.default;
exports.default = s;