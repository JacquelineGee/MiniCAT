var e = require("../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.default = void 0;
var t = e(require("../lib/mix/request")),
  r = require("../lib/mix/util"),
  a = t.default,
  u = {
    requestFmpData: function(e) {
      return a.get((0, r.getHost)() + "/diancan/menu/api/loadFMPInfo", {
        params: e,
        withCredentials: !0,
        timeout: 1e4,
        openShark: !0
      })
    },
    requestSpu: function(e) {
      return a.get((0, r.getHost)() + "/diancan/menu/api/pageSpuInfo", {
        params: e,
        withCredentials: !0,
        timeout: 1e4,
        openShark: !0
      })
    },
    requestMenuExtra: function(e) {
      return a.get((0, r.getHost)() + "/diancan/menu/api/menuExtra", {
        params: e,
        timeout: 4e3
      })
    },
    requestAddress: function(e) {
      return a.get((0, r.getTakeAwayHost)() + "/api/rmstakeaway/queryAddressByGeo", {
        params: e,
        timeout: 4e3
      })
    }
  };
exports.default = u;