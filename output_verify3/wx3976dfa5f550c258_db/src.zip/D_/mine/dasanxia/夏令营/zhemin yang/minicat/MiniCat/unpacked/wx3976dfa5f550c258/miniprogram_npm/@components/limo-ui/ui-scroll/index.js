var e = require("../../../@limo/container/behaviors/index"),
  t = require("../ui-constant/enum");
Component({
  behaviors: [e.commonBehavior, e.limoShim],
  options: {
    multipleSlots: !0
  },
  properties: {
    listStatus: {
      type: Number,
      value: 0,
      observer: function(e) {
        this.setText(e)
      }
    },
    threshold: {
      type: Number,
      value: 100
    },
    offset: {
      type: Number,
      value: 3
    },
    loadingText: {
      type: String,
      value: "加载中..."
    },
    endText: {
      type: String,
      value: "没有更多订单了~"
    }
  },
  data: {
    statusText: ""
  },
  methods: {
    setText: function(e) {
      var i = this.properties,
        o = i.loadingText,
        s = i.endText,
        r = "";
      switch (e) {
        case t.LOADING.DOING:
          r = o;
          break;
        case t.LOADING.END:
          r = s
      }
      this.setData({
        statusText: r
      })
    },
    onReachBottom: function() {
      this.triggerEvent("reachBottom")
    }
  }
});