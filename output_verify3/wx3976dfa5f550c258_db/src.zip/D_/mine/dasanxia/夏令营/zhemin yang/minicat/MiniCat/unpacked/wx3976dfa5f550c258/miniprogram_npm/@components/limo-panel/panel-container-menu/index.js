var e = require("../../../../b/helpers/interopRequireDefault"),
  i = require("../../../@limo/container/behaviors/index"),
  o = e(require("../panel-behaviors/panelContainerBehavior"));
Component({
  behaviors: [o.default, i.commonBehavior, i.limoShim],
  properties: {},
  data: {},
  methods: {
    limoAttached: function() {
      this.panelBehaviorsPanelContainerBehavior_limoAttached()
    },
    toThirdLogin: function() {
      this.triggerEvent("gotoThirdLogin")
    }
  },
  attached: function() {
    this.limoAttached()
  }
});