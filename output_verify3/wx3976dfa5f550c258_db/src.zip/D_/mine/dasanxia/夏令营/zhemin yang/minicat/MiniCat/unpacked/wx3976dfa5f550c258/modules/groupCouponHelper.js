Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.isGroupCoupon = void 0, require("../b/helpers/Arrayincludes");
var e = require("../constants/bizConstants");
exports.isGroupCoupon = function(r) {
  return [e.ACTIVITY_SRC.GROUPON, e.ACTIVITY_SRC.KOU_BEI_GROUP, e.ACTIVITY_SRC.DOU_YIN, e.ACTIVITY_SRC.KS].includes(r)
};