var t = require("../../../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.transMutexMatrix = exports.initAttrsMatrix = exports.dealDefaultMutex = exports.dealAttrMutexConfirm = void 0;
var r, n = require("../../../b/helpers/toConsumableArray"),
  e = t(require("../../../lib/mix/confirm")),
  u = ((r = {})[r.METHOD = 1] = "METHOD", r[r.TASTE = 2] = "TASTE", r);
exports.initAttrsMatrix = function(t) {
  var r = t.methods,
    n = t.tastes;
  return (r || []).concat(n || []).map((function(t) {
    return (t.items || []).map((function(r) {
      return {
        type: t.type,
        groupId: t.groupId,
        id: r.id,
        mutexCodes: r.mutexCodes,
        name: r.name
      }
    }))
  }))
};
var o = function(t, r) {
    return t.find((function(t) {
      return t.type === r.type && t.groupId === r.groupId && t.id === r.id
    }))
  },
  i = function(t, r, n) {
    var e;
    if (t.forEach((function(t) {
        e || (e = o(t, r))
      })), e && e.mutexCodes) return e.mutexCodes.forEach((function(r, e) {
      var u = r.toString(2).padStart(t[e].length, "0").split("").map((function(t) {
        return +t
      }));
      n && n(u, e)
    })), e
  },
  a = function(t) {
    var r = t || {},
      e = r.methods,
      o = r.tastes,
      i = function(t, r) {
        var e, u = t.map((function(t) {
          return t.items.map((function(n) {
            var e = n.id;
            return {
              groupId: t.groupId,
              id: e,
              type: r
            }
          }))
        }));
        return (e = []).concat.apply(e, n(u))
      };
    return [].concat(n(i(e || [], u.METHOD)), n(i(o || [], u.TASTE)))
  };
exports.transMutexMatrix = function(t, r) {
  if (!r) return [];
  var n = r.map((function(t) {
      return Array(t.length).fill(0)
    })),
    e = function(t, r) {
      t.forEach((function(t, e) {
        n[r][e] = t || n[r][e]
      }))
    };
  return a(t).forEach((function(t) {
    i(r, t, e)
  })), n
};
exports.dealAttrMutexConfirm = function(t, r, n) {
  var u = [],
    c = i(r, n, (function(t, n) {
      t.forEach((function(t, e) {
        t && u.push(r[n][e])
      }))
    }));
  if (u.length && c) {
    var f = a(t),
      p = u.filter((function(t) {
        return !!o(f, t)
      })).map((function(t) {
        return t.name
      })).join("、");
    (0, e.default)({
      body: "".concat(c.name, "不可与").concat(p, "同时选择"),
      buttons: [{
        text: "我知道了",
        type: "submit",
        callback: function() {}
      }]
    })
  }
};
exports.dealDefaultMutex = function(t, r, n) {
  var e = n || t.map((function(t) {
      return Array(t.length).fill(0)
    })),
    u = !0;
  return t.forEach((function(t, n) {
    var o = t.findIndex((function(t) {
      return r.type === t.type && r.groupId === t.groupId && r.id === t.id
    }));
    o > -1 && 1 === e[n][o] && (u = !1)
  })), u && i(t, r, (function(t, r) {
    t.forEach((function(t, n) {
      t && (e[r][n] = 1)
    }))
  })), {
    mutexMatrix: e,
    success: u
  }
};