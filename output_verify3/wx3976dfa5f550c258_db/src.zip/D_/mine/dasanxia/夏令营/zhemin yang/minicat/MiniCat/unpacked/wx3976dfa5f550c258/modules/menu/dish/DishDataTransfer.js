var e = require("../../../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.transferSkuData = exports.transferItemData = exports.sliceDataTransfer = exports.getSetObj = exports.getCloudSaveDataCartDishList = exports.generateDishList = exports.checkBizType = void 0;
var t = require("../../../b/helpers/objectSpread2"),
  a = e(require("../../../miniprogram_npm/seamless-immutable/index.js")),
  i = e(require("../../../miniprogram_npm/@mtfe/rms-triangle-c/index.js")),
  r = require("../../../constants/bizConstants"),
  n = require("../../../constants/menu"),
  o = e(require("../../MustDishSdk")),
  d = e(require("../../../api/rmsStorage")),
  s = require("./util"),
  c = require("./PropertyUtil"),
  l = e(require("../I18n/I18nService")),
  u = e(require("../shop/shopService")),
  g = require("../../../types/newMenu/MenuData"),
  p = {
    DEFAULT: {
      marginTop: 0,
      marginBottom: 40,
      paddingTop: 18,
      paddingBottom: 10,
      borderTop: 0,
      borderBottom: 0,
      height: 182
    },
    LARGE: {
      marginTop: 0,
      marginBottom: 22,
      paddingTop: 0,
      paddingBottom: 0,
      borderTop: 0,
      borderBottom: 0,
      height: 442
    },
    SMALL: {
      marginTop: 0,
      marginBottom: 20,
      paddingTop: 0,
      paddingBottom: 0,
      borderTop: 0,
      borderBottom: 0,
      height: 352
    },
    SUPER_LARGE: {
      marginTop: 0,
      marginBottom: 35,
      paddingTop: 0,
      paddingBottom: 0,
      borderTop: 0,
      borderBottom: 0,
      height: 563
    },
    ORDERED: {
      marginTop: 0,
      marginBottom: 0,
      paddingTop: 0,
      paddingBottom: 0,
      borderTop: 0,
      borderBottom: 0,
      height: 100
    },
    RIGHT_LARGE: {
      marginTop: 0,
      marginBottom: 30,
      paddingTop: 0,
      paddingBottom: 0,
      borderTop: 0,
      borderBottom: 0,
      height: 526
    }
  },
  h = i.default.MPInfo.getSystemInfo().windowWidth || 375;

function T(e, t) {
  var a = 0;
  return Object.keys(e).forEach((function(i) {
    a += Math.floor(e[i] / 750 * t)
  })), a = a / t * 750
}
var m = function(e, t) {
    var a, i, o, d, s = e.item,
      p = e.cartCount,
      h = void 0 === p ? 0 : p,
      T = e.cartWeight,
      m = void 0 === T ? 0 : T,
      I = e.mustCount,
      y = void 0 === I ? -1 : I,
      f = e.hotRankFromIndex,
      D = void 0 !== f && f,
      S = e.itemIndex,
      v = void 0 === S ? 0 : S,
      E = e.dishType,
      L = void 0 === E ? "DEFAULT" : E,
      C = e.dishFrom,
      _ = void 0 === C ? "" : C,
      P = e.categoryId,
      b = void 0 === P ? -1 : P;
    if (s) {
      var R = s.recommendTags && s.recommendTags.length > 0 && (null == (a = s.recommendTags[0]) || null == (a = a.tagDesc) ? void 0 : a.match(/\d/g)) || [],
        k = Number(R.join("")) || 0,
        O = b === r.DISH_CATEGORY_ID.POINT_PURCHASE,
        B = l.default.getCurrency(),
        A = u.default.getShopServiceData().fmpBizData,
        H = {
          id: s.spuId,
          rank: (0, c.dealHotRank)(D, v),
          picTag: (0, c.dealPicTag)(s.dishTag && s.dishTag[0]),
          picUrl: (0, c.dealPicUrl)(s.dishPicUrls, L),
          picLabel: (0, c.dealPicLabel)({
            ordered: s.ordered,
            stockCount: s.stockCount,
            unit: s.unit,
            hotRankFromIndex: D,
            recommendCount: k,
            dishType: L,
            picLabelStyleType: null != (i = null == A ? void 0 : A.picLabelStyleType) ? i : g.PIC_LABEL_STYLE_TYPE.DEFAULT
          }),
          currency: B,
          name: O ? (0, c.dealPointDishInfo)(s, t).name : s.spuName,
          desc: (0, c.dealHiddenDishDesc)(s, L) ? "" : (0, c.dealDescription)(s.spicy, s.description),
          ordered: s.ordered,
          recommendTags: "SUPER_LARGE" !== L ? s.recommendTags : [],
          saleQuantity: null != (o = s.saleQuantityStr) && o.length ? s.saleQuantityStr : (0, c.dealSaleQuantity)(s.saleQuantity),
          tagList: (0, c.dealTagList)(s, !1, s.sampleTagList, L, O),
          sampleTagList: (0, c.dealTagList)(s, !1, s.sampleTagList, L, O),
          currentPrice: O ? (0, c.dealPointDishInfo)(s, t).currentPrice : (0, c.dealCurrentPrice)(s),
          originalPrice: (0, c.dealOriginalPrice)(s, O),
          unit: (0, c.dealUnit)(s),
          preventSale: (0, c.dealPreventSale)(s),
          operationData: (0, c.dealOperationData)(s, h, m, y, _, L, b),
          orderedSize: (0, c.dealOrderedSize)(L),
          hotSellingTag: O ? void 0 : (0, c.dealHotSellingTag)(s.hotSellingImgTag, "" + s.currentPrice, L),
          mustCount: y,
          skuMenuItems: s.skuMenuItems,
          tagListSize: (0, c.dealTagListSize)(L),
          dishDescribeTag: s.dishDescribeTag || [],
          hiddenCurrency: (0, c.dealCurrency)(s, O, t),
          isPointPurchaseCategory: O,
          estimatedPrice: b === r.DISH_CATEGORY_ID.ORDERED ? void 0 : s.estimatedPrice
        };
      return Object.keys(H).forEach((function(e) {
        H[e] || delete H[e]
      })), H.hiddenDish = null == s ? void 0 : s.hiddenDish, s.canWeight ? H.weight = m : H.count = h, H.currentPrice && (null == (d = H.currentPrice) ? void 0 : d.length) > 5 && -1 !== n.SMALL_FONT_TYPE.indexOf(L) && (H.priceSmallFont = !0), H
    }
  },
  I = function(e, t, a) {
    var i = n.DISH_ITEM_ROW_NUMBER[a],
      o = 0;
    if (e && e.length) {
      if (-10 === t) return 100 * (e && e.length || 0);
      if (t === r.PLUGIN_CATEGORY) return 30;
      for (var d = 0; d < e.length; d++) e[d].isSpread && o++;
      return Math.ceil(o / i) * T(p[a], h) || 1
    }
    return 100
  },
  y = function(e, t) {
    var a = n.DISH_ITEM_ROW_NUMBER[t];
    return "number" == typeof e ? Math.ceil(e / a) * T(p[t], h) || 1 : 100
  };
exports.checkBizType = function(e) {
  var t;
  switch (e) {
    case 0:
      t = 1;
      break;
    case 1:
      t = 2;
      break;
    default:
      t = e || 1
  }
  return t
}, exports.getCloudSaveDataCartDishList = function(e, t) {
  var i;
  if (!e || !t) return {};
  var r = e;
  return null == (i = Object.keys(e)) || i.forEach((function(i) {
    var n = t[i],
      o = e[i];
    n && o && (null == o || o.forEach((function(e, t) {
      var o, d, s, c = a.default.setIn(e, ["parentCategoryId"], (null == n || null == (o = n.parentCategoryId) ? void 0 : o[0]) || "");
      c = a.default.setIn(c, ["parentBaseCategoryId"], (null == n || null == (d = n.parentBaseCategoryId) ? void 0 : d[0]) || ""), c = a.default.setIn(c, ["picUrls"], (null == n || null == (s = n.dishPicUrls) ? void 0 : s[0]) || ""), c = a.default.setIn(c, ["unit"], (null == n ? void 0 : n.unit) || ""), c = a.default.setIn(c, ["allDiscount"], null), c = a.default.setIn(c, ["allBuyFreeDiscount"], null), r = a.default.setIn(r, [i, t], c)
    })))
  })), r
}, exports.getSetObj = function(e, t, a) {
  var i = {};
  return e.forEach((function(r, n) {
    if (r && r.categoryId === t)
      if (r.dishInfo)
        for (var o = !1, d = 0; d < r.dishInfo.length; d++) {
          for (var s = 0, c = 0; c < r.dishInfo[d].content.length; c++) {
            var l = e[n].dishInfo[d].content[c];
            l.isNotValidity && (o ? (l.isSpread && s++, i["allDishList[".concat(n, "].dishInfo[").concat(d, "].content[").concat(c, "].isSpread")] = !l.isSpread) : o = !0)
          }
          i["allDishList[".concat(n, "].dishInfo[").concat(d, "].minHeight")] = y(r.dishInfo[d].content.length - s, a)
        } else i["allDishList[".concat(n, "].isSpread")] = !e[n].isSpread
  })), i
}, exports.transferSkuData = function(e) {
  var t, a, i = e.item,
    r = e.sku,
    n = e.dishType,
    d = void 0 === n ? "DEFAULT" : n;
  if (i) {
    var s = l.default.getCurrency(),
      p = u.default.getShopServiceData().fmpBizData,
      h = {
        id: i.spuId,
        skuId: r.skuId,
        picTag: (0, c.dealPicTag)(i.dishTag && i.dishTag[0]),
        picUrl: (0, c.dealPicUrl)(i.dishPicUrls, d),
        picLabel: (0, c.dealPicLabel)({
          ordered: i.ordered,
          stockCount: r.stockCount,
          unit: r.unit,
          picLabelStyleType: null != (t = null == p ? void 0 : p.picLabelStyleType) ? t : g.PIC_LABEL_STYLE_TYPE.DEFAULT
        }),
        currency: s,
        name: (0, c.dealSkuName)(r),
        desc: (0, c.dealHiddenDishDesc)(i, d) ? "" : (0, c.dealDescription)(i.spicy, i.description),
        recommendTags: i.recommendTags,
        saleQuantity: null != (a = i.saleQuantityStr) && a.length ? i.saleQuantityStr : (0, c.dealSaleQuantity)(i.saleQuantity),
        tagList: (0, c.dealTagList)(r),
        currentPrice: (0, c.dealCurrentPrice)(r),
        originalPrice: (0, c.dealOriginalPrice)(r),
        unit: (0, c.dealUnit)(r),
        mustCount: o.default.getMustCount(r),
        sampleTagList: (0, c.dealTagList)(r),
        dishDescribeTag: i.dishDescribeTag || [],
        tagListSize: (0, c.dealTagListSize)(d),
        hotSellingTag: (0, c.dealHotSellingTag)(i.hotSellingImgTag, "" + i.currentPrice, d)
      };
    return Object.keys(h).forEach((function(e) {
      h[e] || delete h[e]
    })), h
  }
}, exports.sliceDataTransfer = function(e) {
  var a = d.default.getSliceStep(),
    i = 0,
    r = {},
    n = [],
    o = function() {
      if (0 !== Object.keys(r).length) {
        var e = t({}, r);
        n.push(e), r = {}
      }
    };
  return e.forEach((function(t, n) {
    t.dishInfo ? function(t, n) {
      if (t.dishCount < a) i <= a && i + t.dishCount > a ? (o(), i = t.dishCount) : i += t.dishCount, r["allDishList[".concat(n, "]")] = t, n === e.length - 1 && o();
      else {
        var d = t.categoryId,
          s = t.categoryName,
          c = t.categoryType,
          l = t.dishInfo,
          u = t.iconType,
          g = t.key,
          p = t.parentId,
          h = t.dishCount;
        r["allDishList[".concat(n, "]")] = {
          categoryId: d,
          categoryName: s,
          categoryType: c,
          iconType: u,
          key: g,
          parentId: p,
          dishCount: h,
          dishInfo: [l[0]]
        }, o();
        for (var T = 1; T < t.dishInfo.length; T++) r["allDishList[".concat(n, "].dishInfo[").concat(T, "]")] = t.dishInfo[T], o()
      }
    }(t, n) : (r["allDishList[".concat(n, "]")] = t, n === e.length - 1 && o())
  })), n
}, exports.generateDishList = function(e, i) {
  var c = i.categories,
    l = i.list,
    u = i.cartList,
    g = i.menuStyle,
    p = i.pointBuyCampaign,
    h = a.default.getIn(g, ["dishShowType"]) || 0,
    T = n.DISH_ITEM_TYPE_MAP[h] || n.DISH_ITEM_TYPE_VAL.DEFAULT,
    y = (0, s.computeItemCount)(u),
    f = [],
    D = 0,
    S = Object.keys(l).length,
    v = e ? 48 : 24 * Math.ceil(S / 200),
    E = v > 120 ? 120 : v;
  d.default.setSliceStep(E);
  return function a(i) {
    var d = i.parentName,
      c = void 0 === d ? "" : d,
      u = i.parentId,
      g = void 0 === u ? 0 : u,
      S = i.recursionCategories;
    (void 0 === S ? [] : S).forEach((function(i) {
      var d = i.spuIds,
        u = void 0 === d ? [] : d,
        S = i.childDishCategories,
        v = i.categoryId,
        L = i.iconType,
        C = i.categoryName,
        _ = (0, s.categoryDisplay)(e, S, u, l),
        P = _.display,
        b = void 0 === P || P,
        R = _.spuIdArr,
        k = void 0 === R ? [] : R;
      if (e || null != k && k.length && b) {
        var O = {
          categoryId: 0,
          categoryName: "",
          categoryType: "",
          dishCount: 0,
          dishInfo: [],
          iconType: 0,
          key: "",
          parentId: 0,
          parentName: ""
        };
        C && v && (v === r.DISH_CATEGORY_ID.DISCOUNT && (C = "".concat(C).concat(r.OVER_PRICE_TITLE)), O = t(t({}, O), {}, {
          categoryId: v,
          categoryName: C,
          parentName: c,
          categoryType: (0, s.getCategoryType)(v),
          parentId: g,
          iconType: L,
          key: g ? "".concat(g, "-").concat(v) : v
        }));
        for (var B = 0, A = [], H = h === r.DISH_SHOW_TYPE.DEFAULT || h === r.DISH_SHOW_TYPE.RIGHT_LARGE, M = 0; M < k.length; M++) {
          var U = M,
            x = k[U],
            N = g ? "".concat(g, "-").concat(v, "-").concat(x) : "".concat(v, "-").concat(x),
            Y = l && l[x],
            F = y[x] || 0,
            G = y[x] || 0,
            q = o.default.getMustCount(null == Y ? void 0 : Y.skuMenuItems[0]),
            j = Y && m({
              item: Y,
              cartCount: F,
              cartWeight: G,
              mustCount: q,
              dishType: T,
              hotRankFromIndex: i.categoryId === r.DISH_CATEGORY_ID.HOT,
              itemIndex: U,
              categoryId: v
            }, p),
            z = O.categoryId === r.DISH_CATEGORY_ID.ORDERED ? "".concat(n.DISH_ITEM_TYPE_VAL.ORDERED, "_").concat(T) : T;
          j && (j = (0, s.filterItemKeys)(z, j, n.EXTRA_FILTER_KEYS));
          var Q = !(null != Y && Y.canSaleNow) && !(null != Y && Y.validity) || (null == Y ? void 0 : Y.soldOut);
          if (j && Q && (B += 1), j) {
            var W = !0;
            Y && Q && B > 1 && H && (W = !1), v === r.DISH_CATEGORY_ID.ORDERED ? D < 6 && (A.push(t(t({}, j), {}, {
              categoryId: v,
              parentId: g,
              key: N,
              isSpread: W
            })), D++) : A.push(t(t({}, j), {}, {
              isSpread: W,
              isNotValidity: Q,
              categoryId: v,
              parentId: g,
              key: N
            }))
          }
        }
        if (A.length > 0) {
          for (var w = E, V = 0, K = [], X = 0; X <= Math.ceil(A.length / w - 1); X++) {
            var J = A.slice(V, V + w);
            K.push({
              key: "".concat(v, "-").concat(X),
              minHeight: I(J, v, T),
              content: J
            }), V += w
          }
          O.dishCount = A.length, O.dishInfo = K, f.push(O)
        }
        B > 1 && H && f.push({
          categoryId: v,
          key: v + "-spread",
          isNotValidity: !0,
          isSpread: !1,
          notValidityDishCount: B - 1,
          parentId: g
        })
      } else S && a({
        parentName: C,
        recursionCategories: S,
        parentId: v
      })
    }))
  }({
    recursionCategories: c
  }), f
}, exports.transferItemData = m;