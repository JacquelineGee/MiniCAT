var e = require("../../../b/helpers/interopRequireDefault"),
  t = require("../../../miniprogram_npm/@limo/container/behaviors/index"),
  o = e(require("../../../miniprogram_npm/seamless-immutable/index.js")),
  a = e(require("../../../api/rmsStorage")),
  r = require("../../../miniprogram_npm/@components/limo-ui/member-label/type"),
  i = require("../../../store/actions/panel"),
  l = e(require("../../../store/menu")),
  n = e(require("../../../store/helpers/storeBehavior")),
  s = require("../../../modules/yellowStripHelper"),
  u = require("../../../types/common/misc"),
  d = require("../../../lib/navigator");
Component({
  behaviors: [n.default, t.commonBehavior, t.limoShim],
  options: {
    addGlobalClass: !0
  },
  properties: {
    options: {
      type: Object,
      value: {}
    },
    showCartPanel: {
      type: Boolean,
      value: !1
    },
    needBuyFreeBtn: {
      type: Boolean,
      value: !0
    },
    isDishDetail: {
      type: Boolean,
      value: !1
    }
  },
  data: {
    excutedText: [],
    showBuyFreeBtn: !1,
    memberLabelCustomClass: "yellow-strip-label-middle",
    memberLabelType: r.MEMBER_LABEL_TYPE.CART,
    svipCardPromotionTip: [],
    svipTextView: [],
    svipCardDetailUrlView: "",
    yellowStripClass: ""
  },
  observers: {
    "shopPromotions.**, cartPrice.**, cartDiscountData.**, svipCardPromotionTip.**, posOrderId.**": function(e, t, o, r) {
      var i, l, n, d = this.data,
        c = d.posOrderId,
        p = d.memberTexts,
        m = a.default.getDishList(this.data.options.shopId, !1),
        h = t || {},
        f = h.discountAmount,
        v = h.fullCutPrediction,
        T = void 0 === v ? {} : v,
        g = h.fullGiftPrediction,
        y = void 0 === g ? {} : g,
        x = h.fullDiscountPrediction,
        C = void 0 === x ? {} : x,
        I = !1,
        b = !e || e.length <= 0,
        w = !p || p.length <= 0,
        P = r.length <= 0;
      if ((b && w || c) && P) this.setData({
        excutedText: []
      });
      else {
        var D = (0, s.getYellowTextArray)(20, f, e, m, T, y, C),
          B = null == o || null == (i = o.cartYellowText) || null == (i = i[0]) ? void 0 : i.discountText,
          q = null == o || null == (l = o.cartYellowText) || null == (l = l[0]) ? void 0 : l.additionGoods,
          A = r.length > 0 ? "with-svip-text" : "",
          R = r,
          U = [];
        D.length ? U = (0, s.convertYellowTextArrayToRichText)(D) : B ? (U = (0, s.convertYellowTextArrayToRichText)(B), null != q && q.length && this.data.needBuyFreeBtn && (I = !0)) : r.length && (U = r, R = [{
          text: "立即省钱",
          type: u.RICH_ITEM_TEXT_TYPE.NORMAL
        }], A = "only-svip-text");
        var k = "yellow-strip-label";
        null != (n = U) && n.length || (k = "yellow-strip-label-middle"), this.data.showCartPanel && (k += " label-border-radius"), this.setData({
          excutedText: U,
          showBuyFreeBtn: I,
          memberLabelCustomClass: k,
          svipTextView: R,
          yellowStripClass: A
        })
      }
    },
    svipCardDetailUrl: function(e) {
      var t = this.data.options;
      this.setData({
        svipCardDetailUrlView: (0, d.concatUrlWithCallbackUrl)({
          callBackUrlPageName: "menu",
          distUrl: e,
          callBackUrlPageQuery: t
        })
      })
    }
  },
  created: function() {
    this.store = l.default
  },
  methods: {
    limoReady: function() {
      this.helpersStoreBehavior_limoReady()
    },
    mapToState: function(e) {
      return {
        shopPromotions: o.default.getIn(e, ["extraInfo", "headInfo", "shopInfo", "shopPromotions"]),
        posOrderId: o.default.getIn(e, ["extraInfo", "headInfo", "orderInfo", "posOrderId"]) || "",
        svipCardPromotionTip: o.default.getIn(e, ["extraInfo", "headInfo", "memberInfo", "svipCardPromotionTip"]) || (0, o.default)([]),
        svipCardDetailUrl: o.default.getIn(e, ["extraInfo", "headInfo", "memberInfo", "svipCardDetailUrl"]) || "",
        cartPrice: o.default.getIn(e, ["cart", "cartPrice"]) || (0, o.default)({}),
        cartDiscountData: o.default.getIn(e, ["cart", "cartDiscountData"]) || (0, o.default)({}),
        memberTexts: o.default.getIn(e, ["panel", "registerActivity", "richTextTag"]) || (0, o.default)([])
      }
    },
    showTakeCouponPanelAction: function(e) {
      this.store.dispatch((0, i.showTakeCouponPanelAction)(e))
    },
    checkedBuyFreeFn: function() {
      var e, t = this.data.cartDiscountData,
        o = null == t || null == (e = t.cartYellowText) || null == (e = e[0]) ? void 0 : e.campaignId;
      this.triggerEvent("checkedBuyFree", {
        campaignId: o
      })
    },
    collectCouponAction: function() {
      this.showTakeCouponPanelAction({
        takeCouponPanelTag: !0,
        sourceType: "cart"
      })
    }
  },
  ready: function() {
    this.limoReady()
  }
});