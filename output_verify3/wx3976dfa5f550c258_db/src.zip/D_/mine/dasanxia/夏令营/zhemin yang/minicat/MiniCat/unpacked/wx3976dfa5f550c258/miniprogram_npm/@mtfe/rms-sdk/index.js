var e = require("../../../b/helpers/interopRequireDefault"),
  t = require("../../../b/helpers/interopRequireWildcard");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.initHeaderVersion = exports.initEnv = exports.getTakeAwayHost = exports.getReviewHost = exports.getMemberHost = exports.getLoginHost = exports.getEnvHeader = exports.getEnv = exports.getDefaultHost = exports.advertiseReporter = exports.Transaction = exports.ThemeModel = exports.ThemeControl = exports.Theme = exports.Shark = exports.Observer = exports.Log = exports.LazyLoad = exports.LXReporter = exports.LOCALE = void 0, exports.isAppMockEnable = we, exports.request = void 0, exports.standardDate = function(e, t) {
  var r = t || {},
    a = r.locale,
    i = void 0 === a ? st.DEFAULT : a,
    o = r.time,
    s = void 0 !== o && o,
    u = n(e || [], 2),
    c = u[0],
    d = u[1],
    l = dt(c, i, s),
    f = dt(d, i, s);
  return l + (f ? ut[i].connector + f : "")
}, exports.standardPoint = function(e) {
  var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
    n = e || 0;
  if ((n + "").includes("+") || (n + "").includes(".")) return n;
  if (t) {
    var r = Number(e);
    r >= 0 && r <= 100 ? n = r.toFixed(2) : r > 100 && r <= 1e3 ? n = r.toFixed(1) : r > 1e3 && r <= 1e4 ? n = r.toFixed(0) : r > 1e4 && (n = "9999+")
  }
  return n
}, exports.standardPrice = function(e, t) {
  var r = t || {},
    a = r.unitType,
    i = void 0 === a ? 1 : a,
    o = r.displayType,
    s = void 0 === o ? 1 : o,
    u = r.split,
    c = void 0 !== u && u,
    d = Number(e) / ot[i];
  if (s === at.Billing && (d = d.toFixed(2)), c) {
    var l = (d + "").split("."),
      f = n(l, 2),
      p = f[0],
      h = f[1];
    return [p, h]
  }
  return d + ""
}, exports.switchMock = function(e) {
  v.default.setStorageSync("RMS_APP_MOCK", e)
}, exports.updateApp = exports.transactionOnce = exports.transaction = void 0, require("../../../b/helpers/Arrayincludes");
var n = require("../../../b/helpers/slicedToArray");
require("../../../b/helpers/Objectentries");
var r, a, i, o, s, u, c = require("../../../b/helpers/defineProperty"),
  d = e(require("../../../b/regenerator")),
  l = require("../../../b/helpers/classCallCheck"),
  f = require("../../../b/helpers/createClass"),
  p = require("../../@dp/owl-wxapp/index.js"),
  h = e(require("../rms-triangle-c/index.js")),
  g = require("../weapp-safety-request/index.js"),
  v = e(require("../../@limo/core/index.js")),
  m = t(require("../saas-user-auth/index.js")),
  y = new(function() {
    function e() {
      l(this, e)
    }
    return f(e, [{
      key: "init",
      value: function(e, t) {
        t && (this.loganInstance = t, this.loganInstance.startWithOptions({
          topic: e.topic,
          devMode: e.devMode || !1,
          owl: p.owl,
          userConfig: e.userConfig
        }))
      }
    }, {
      key: "getLoganInstance",
      value: function() {
        return this.loganInstance
      }
    }, {
      key: "addError",
      value: function(e, t) {
        var n, r, a = {
          sec_category: "",
          content: "",
          category: (null == t ? void 0 : t.category) || "jsError",
          level: (null == t ? void 0 : t.level) || "error",
          tags: Object.assign({
            tenantId: (null === (r = null === (n = v.default.getExtConfigSync) || void 0 === n ? void 0 : n.call(v.default)) || void 0 === r ? void 0 : r.tenantId) || ""
          }, (null == t ? void 0 : t.tags) || {})
        };
        "string" == typeof e ? a.sec_category = e : e instanceof Error ? (a.sec_category = e.message || "", a.content = e.stack || "") : (a.sec_category = e.name || "", a.content = e.msg || "");
        var i = !(null == t ? void 0 : t.comb);
        p.owl.error.pushError(a, i)
      }
    }, {
      key: "addLog",
      value: function(e, t) {
        if (this.loganInstance) try {
          var n = (null == t ? void 0 : t.level) || "INFO",
            r = (null == t ? void 0 : t.extraInfo) || JSON.stringify(t),
            a = (null == t ? void 0 : t.tags) || [],
            i = (null == t ? void 0 : t.isImmediate) || !1;
          this.loganInstance.log(n, e, {
            extraInfo: r,
            openId: m.default.getOpenId()
          }, a), i && this.loganInstance.onHide()
        } catch (e) {
          p.owl.error.pushError({
            sec_category: "logan-rtl上报失败",
            content: (null == e ? void 0 : e.message) || "",
            category: "jsError",
            level: "error"
          })
        }
      }
    }, {
      key: "addPerf",
      value: function(e, t, n) {
        p.owl.pageSpeed.addPoint({
          position: e,
          duration: t
        }, n)
      }
    }, {
      key: "addApi",
      value: function(e, t, n, r) {
        p.owl.resource.addApi({
          name: e,
          networkCode: t,
          statusCode: n,
          responseTime: r
        })
      }
    }, {
      key: "addCustom",
      value: function(e, t, n) {
        var r, a;
        p.owl.setMetric(e, t, Object.assign({
          tenantId: (null === (a = null === (r = v.default.getExtConfigSync) || void 0 === r ? void 0 : r.call(v.default)) || void 0 === a ? void 0 : a.tenantId) || ""
        }, n || {}))
      }
    }]), e
  }());
exports.Log = y, (u = o || (o = {})).WX = "1", u.MT = "2", u.DP = "3", u.AP = "4", u.CP = "5", u.PAB = "6", u.CMB = "7", u.TT = "8", u.OTHER = "99",
  function(e) {
    e.MP = "1", e.WEBVIEW = "2", e.WEB = "3"
  }(s || (s = {}));
var x = "",
  b = "",
  P = "",
  C = "",
  k = function(e) {
    var t = "";
    return e === s.MP ? P ? t = P : (t = h.default.MPInfo.getAppId(), P = t) : s.WEBVIEW, t
  },
  I = function(e) {
    var t = e.header || e.headers || {};
    t["app-container"] !== s.WEB && ("string" == typeof t["app-id"] && t["app-id"] || y.addError({
      name: "请求header缺少app-id字段或者字段类型有误！！！",
      msg: JSON.stringify(e)
    }, {
      category: "ajaxError"
    }), "string" == typeof t["app-version"] && t["app-version"] || y.addError({
      name: "请求header缺少app-version字段或者字段类型有误！！！",
      msg: JSON.stringify(e)
    }, {
      category: "ajaxError"
    })), "string" == typeof t.versionCode && t.versionCode || y.addError({
      name: "请求header缺少versionCode字段或者字段类型有误！！！",
      msg: JSON.stringify(e)
    }, {
      category: "ajaxError"
    })
  },
  M = function() {
    try {
      var e = h.default.isNativeMp ? s.MP : h.default.isMpWebview || h.default.isAliPayWebview || h.default.isByteDanceMicroAppWebview ? s.WEBVIEW : s.WEB,
        t = {
          "app-platform": h.default.isWX ? o.WX : h.default.isMTApp ? o.MT : h.default.isDPApp ? o.DP : h.default.isAliPay ? o.AP : h.default.h5Ua.indexOf("cloudpay") > -1 ? o.CP : h.default.h5Ua.indexOf("pabank") > -1 ? o.PAB : h.default.h5Ua.indexOf("cmblife") > -1 ? o.CMB : h.default.isByteDance ? o.TT : o.OTHER,
          "app-container": e,
          "app-id": k(e),
          "app-template": ""
        };
      return b && (t.versionCode = b), e === s.WEB ? t["app-version"] = "" : e !== s.WEBVIEW && (x && (t["app-version"] = x), C && (t["app-template"] = C)), t
    } catch (e) {
      return y.addError({
        name: "设置通用环境上下文异常",
        msg: JSON.stringify(e)
      }), {}
    }
  },
  L = function() {
    var e = "undefined" != typeof getCurrentPages && getCurrentPages() || [];
    return e.length > 0 ? (e[e.length - 1] || {}).route : ""
  },
  S = function() {
    var e = "undefined" != typeof getCurrentPages && getCurrentPages() || [];
    return e.length > 0 && e[e.length - 1] || {}
  },
  w = function(e) {
    var t = S().options || {};
    return e ? decodeURIComponent(t[e] || "") : t
  },
  O = {
    getLxBizParams: function() {
      try {
        var e = v.default.getStorageSync("RMS_APP_LX_PARAMS");
        return e && JSON.parse(e)
      } catch (e) {
        return null
      }
    },
    setLxBizParams: function(e) {
      v.default.setStorageSync("RMS_APP_LX_PARAMS", JSON.stringify(e))
    },
    getLxBizParams_v2: function() {
      try {
        var e = v.default.getStorageSync("RMS_APP_LX_PARAMS_V2");
        return e && JSON.parse(e)
      } catch (e) {
        return null
      }
    },
    setLxBizParams_v2: function(e) {
      v.default.setStorageSync("RMS_APP_LX_PARAMS_V2", JSON.stringify(e || {}))
    }
  },
  E = function() {
    return getApp({
      allowDefault: !0
    })
  };
exports.initHeaderVersion = function(e, t, n) {
  b = e || "", x = t || "", C = n || "1"
}, exports.getEnvHeader = M;
var _ = h.default.isAliPay,
  q = h.default.isDPApp,
  T = h.default.isIOS,
  j = h.default.isMTApp,
  A = h.default.isNativeMp,
  N = h.default.isWX,
  B = null,
  D = null,
  z = null,
  R = null,
  F = null,
  J = function() {
    return E().rmsGlobalLxBizParams || {}
  },
  H = function(e) {
    var t = E();
    A && !t.rmsGlobalLxBizParams && (t.rmsGlobalLxBizParams = {});
    var n = ["account_id", "request_id"];
    e && (O && O.getLxBizParams(), Object.keys(e).forEach((function(r) {
      !e[r] && 0 !== e[r] && !1 !== e[r] || "null" === e[r] || J()[r] && !(n.indexOf(r) < 0) || (t.rmsGlobalLxBizParams[r] = e[r])
    })))
  },
  W = function(e, t) {
    e || (e = {});
    var n = J();
    return e.custom = Object.assign(Object.assign(Object.assign(Object.assign({}, e.custom), {
      common: n
    }), t || {}), {
      channel_id: (null == D ? void 0 : D()) || "",
      tenant_id: (null == z ? void 0 : z()) || ""
    }), e
  };

function U(e, t, n, r) {
  return new(n || (n = Promise))((function(a, i) {
    function o(e) {
      try {
        u(r.next(e))
      } catch (e) {
        i(e)
      }
    }

    function s(e) {
      try {
        u(r.throw(e))
      } catch (e) {
        i(e)
      }
    }

    function u(e) {
      var t;
      e.done ? a(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
        e(t)
      }))).then(o, s)
    }
    u((r = r.apply(e, t || [])).next())
  }))
}
var V = h.default.isAliPay,
  G = h.default.isDPApp,
  K = h.default.isWXH5,
  X = h.default.isWxNative,
  $ = h.default.isMpWebview,
  Z = h.default.isMTApp,
  Y = h.default.isNativeMp,
  Q = h.default.isWX,
  ee = h.default.isAliPayNative,
  te = h.default.isAliPayWebview,
  ne = h.default.isByteDance,
  re = h.default.isByteDanceMicroApp,
  ae = h.default.isByteDanceMicroAppWebview,
  ie = h.default.isUnionPay,
  oe = null,
  se = null,
  ue = function() {
    var e = "",
      t = "";
    return {
      set: function(t) {
        e = t || L()
      },
      setPreview: function() {
        t = e
      },
      get: function() {
        return t
      },
      clear: function() {
        e = ""
      }
    }
  }(),
  ce = function() {
    return E().rmsGlobalLxBizParams_v2 || {}
  },
  de = function(e) {
    var t = E();
    Y && !t.rmsGlobalLxBizParams_v2 && (t.rmsGlobalLxBizParams_v2 = {});
    var n = [];
    e && (O && O.getLxBizParams_v2(), Object.keys(e).forEach((function(r) {
      !e[r] && 0 !== e[r] && !1 !== e[r] || "null" === e[r] || ce()[r] && !(n.indexOf(r) < 0) || (t.rmsGlobalLxBizParams_v2[r] = e[r])
    })))
  },
  le = function(e, t) {
    var n;
    return n = t ? t[e] : w(e), !oe || n && "null" !== n && "undefined" !== n || (n = (oe({}, S().route) || {})[e] || n), n
  },
  fe = function(e, t) {
    ["refer_page", "tenant_Id", "shop_Id"].forEach((function(e) {
      ! function(e) {
        var t = E();
        t.rmsGlobalLxBizParams_v2 && t.rmsGlobalLxBizParams_v2[e] && delete t.rmsGlobalLxBizParams_v2[e]
      }(e)
    })), ue.setPreview(), oe = oe || (null == t ? void 0 : t.getTabbarPageOptions), se = se || (null == t ? void 0 : t.getMemberId);
    var n, r, a, i, o = {};
    ce().app_platform || (o.app_platform = Q || K || X || $ ? 1 : Z ? 2 : G ? 3 : V || ee || te ? 4 : h.default.h5Ua.indexOf("pabank") > -1 ? 6 : h.default.h5Ua.indexOf("cmblife") > -1 ? 7 : ie ? 5 : ne || re || ae ? 8 : "其他", o.app_container = Y ? 1 : $ || ae || te ? 2 : 3, o.app_id = h.default.MPInfo.getAppId() || ""), o.promotion_monitoring = getApp({
      allowDefault: !0
    }).promotionMonitoring || "", o.source_type = function() {
      var e, t, n, r, a, i = (null === (n = null === (t = (e = v.default).getEnterOptionsSync) || void 0 === t ? void 0 : t.call(e)) || void 0 === n ? void 0 : n.scene) || "";
      return h.default.isAliPayNative ? (a = "ali", i = i || (null === (r = null === my || void 0 === my ? void 0 : my.getLaunchOptionsSync()) || void 0 === r ? void 0 : r.scene)) : h.default.isByteDanceMicroApp ? a = "tt" : h.default.isNativeMp && (a = "wx"), "".concat(a, "-").concat(i)
    }(), o.qrcode_url = (null === (r = null === (n = v.default.getEnterOptionsSync) || void 0 === n ? void 0 : n.query) || void 0 === r ? void 0 : r.q) || (null === (i = null === (a = v.default.getEnterOptionsSync) || void 0 === a ? void 0 : a.query) || void 0 === i ? void 0 : i.p), o.refer_page = ue.get(), o.tenant_id = function(e) {
      var t;
      return h.default.MPInfo.isMerchant() && (t = function(e) {
        var t, n = (null === (t = null == v.default ? void 0 : v.default.getExtConfigSync) || void 0 === t ? void 0 : t.call(v.default)) || {};
        return n[e]
      }("tenantId")), t || le("tenantId", e) || le("tenantid", e)
    }(), o.shop_id = function(e) {
      return le("shopId", e) || le("shopid", e) || le("poiid", e) || le("poiId", e)
    }(), o.member_id = se && se(), U(void 0, void 0, void 0, d.default.mark((function e() {
      return d.default.wrap((function(e) {
        for (;;) switch (e.prev = e.next) {
          case 0:
            return e.abrupt("return", new Promise((function(e, t) {
              h.default.isNativeMp ? m.default.getUserInfoSync().then((function(t) {
                e(t.userToken)
              })) : e(h.default.Cookie.getCookie("RMS-USER"))
            })));
          case 1:
          case "end":
            return e.stop()
        }
      }), e)
    }))).then((function(e) {
      de({
        account_token: null == e ? void 0 : e.token
      })
    })), U(void 0, void 0, void 0, d.default.mark((function e() {
      return d.default.wrap((function(e) {
        for (;;) switch (e.prev = e.next) {
          case 0:
            return e.abrupt("return", new Promise((function(e, t) {
              h.default.isNativeMp ? m.default.getUserInfoSync().then((function(t) {
                e(t.openId)
              })) : e(h.default.Cookie.getCookie("RMS-USER"))
            })));
          case 1:
          case "end":
            return e.stop()
        }
      }), e)
    }))).then((function(e) {
      de({
        account_id: e
      })
    })), de(o)
  },
  pe = function(e, t) {
    e || (e = {});
    var n = ce();
    return e.custom = Object.assign(Object.assign(Object.assign({}, e.custom), t || {}), {
      common_v2: n
    }), e
  },
  he = ue.set,
  ge = ue.clear,
  ve = {
    cid: "",
    sendPV: function(e) {
      var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
        n = arguments.length > 2 ? arguments[2] : void 0;
      this.cid = e, n.pageView(e, t)
    },
    sendPD: function() {
      var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null,
        t = arguments.length > 1 ? arguments[1] : void 0;
      t.pageDisappear(e)
    },
    sendMC: function(e) {
      var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
        n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
        r = arguments.length > 3 ? arguments[3] : void 0;
      this.cid && (n = Object.assign({
        cid: this.cid
      }, n), r.moduleClick(e, t, n))
    },
    sendMV: function(e) {
      var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
        n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
        r = arguments.length > 3 ? arguments[3] : void 0;
      this.cid && (n = Object.assign({
        cid: this.cid
      }, n), r.moduleView(e, t, n))
    },
    sendME: function(e) {
      var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
        n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
        r = arguments.length > 3 ? arguments[3] : void 0;
      this.cid && (n = Object.assign({
        cid: this.cid
      }, n), r.moduleEdit(e, t, n))
    }
  },
  me = ve.sendPV.bind(ve),
  ye = ve.sendMV.bind(ve),
  xe = ve.sendMC.bind(ve),
  be = ve.sendME.bind(ve),
  Pe = ve.sendPD.bind(ve),
  Ce = function() {
    var e = {};
    return {
      checkPvReport: function(t) {
        try {
          if (void 0 === e[L()]) return void y.addError({
            name: "pv 上报异常",
            msg: "页面 ".concat(L(), ", cid: ").concat(t, " pv上报前未正常进行初始化")
          });
          if (0 === e[L()]) return void y.addError({
            name: "pv 上报异常",
            msg: "页面 ".concat(L(), ", cid: ").concat(t, " 存在重复上报")
          });
          e[L()] = 0
        } catch (e) {}
      },
      checkPageShow: function() {
        try {
          var t = L();
          e[t] = 1, setTimeout((function() {
            1 === e[t] && y.addError({
              name: "page lost pv send",
              msg: t
            }, {
              level: "info"
            })
          }), 0)
        } catch (e) {}
      }
    }
  }(),
  ke = new(function() {
    function e() {
      l(this, e), this._getMixRMSGlobalLxBizParams = J, this.getMixRMSGlobalLxBizParams = ce, this.sendPV = this.sendPV.bind(this), this.sendPD = this.sendPD.bind(this), this.sendMC = this.sendMC.bind(this), this.sendMV = this.sendMV.bind(this), this.sendME = this.sendME.bind(this), this.clearLxBizParams = this.clearLxBizParams.bind(this), this.appendCommonParam = this.appendCommonParam.bind(this), this.pageShowInit = this.pageShowInit.bind(this), this.pageLoadInit = this.pageLoadInit.bind(this), this._getMixRMSGlobalLxBizParams = this._getMixRMSGlobalLxBizParams.bind(this)
    }
    return f(e, [{
      key: "mpOnLaunch",
      value: function(e) {
        this.lx = null == e ? void 0 : e.lx
      }
    }, {
      key: "pageLoadInit",
      value: function(e, t, n) {
        try {
          this.initAppPromotionMonitoring(), this.lx = this.lx || (null == t ? void 0 : t.lx), n && function(e, t) {
            B = B || (null == t ? void 0 : t.lx), D = D || (null == t ? void 0 : t.getCustomChannel), z = z || (null == t ? void 0 : t.getTenantId), R = R || (null == t ? void 0 : t.getUserIdWithPlatform), F = F || (null == t ? void 0 : t.getTabbarPageOptions);
            var n = {},
              r = function(t) {
                var n;
                return n = e ? e[t] : w(t), !F || n && "null" !== n && "undefined" !== n || (n = (F({}, S().route) || {})[t] || n), n
              },
              a = r("payOpenId"),
              i = r("tableNum"),
              o = r("shopId"),
              s = r("funcMode"),
              u = null == R ? void 0 : R();
            if (n.qrUUid = r("uuid"), n.bizMode = r("bizMode"), n.payMode = r("payMode"), n.bizType = r("bizType"), n.newBizType = r("dishSource"), n.autoTakeOrder = r("autoTakeOrder"), n.accountMode = r("accountMode"), n.is_login = "", n.tenantId = r("tenantId"), n.qrcodeType = r("qrcodeType"), n.mtShopId = o, n.tableNum = i, n.funcMode = s, n.page_type = A ? 2 : 1, n.os = T ? 1 : 2, n.mp_type = h.default.MPInfo.isMerchant() ? 0 : 1, A) {
              var c = h.default.MPInfo.getSystemInfo().system;
              n.os = c && c.toLocaleLowerCase().indexOf("android") < 0 ? 1 : 2
            }
            n.account_type = "", n.account_id = "", n.request_id = "".concat(function(e) {
              var t = "";
              try {
                t = null == e ? void 0 : e.get("lxcuid")
              } catch (e) {}
              return t
            }(B) || u, "-").concat(Date.now()), N || A ? (n.account_type = 1, A ? m.default.getUserInfoSync().then((function(e) {
              var t = e.openId;
              n.account_id = t, H(n)
            })) : n.account_id = u || "") : (q || j) && window.KNB ? (n.account_type = q ? 4 : 3, function(e) {
              try {
                window.KNB && window.KNB.ready(e)
              } catch (t) {
                e()
              }
            }((function() {
              window.KNB.getUserInfo({
                success: function(e) {
                  n.account_id = e.userId, H(n)
                }
              })
            }))) : _ ? (n.account_id = a || u, n.account_type = 2) : (n.account_id = u, n.account_type = 5), H(n)
          }(e, Object.assign(Object.assign({}, t), n)), fe(0, Object.assign({}, t)), h.default.isNativeMp || this.pageShowInit()
        } catch (e) {
          y.addError({
            name: "pageLoadInit error",
            msg: JSON.stringify(e)
          })
        }
      }
    }, {
      key: "initAppPromotionMonitoring",
      value: function(e) {
        h.default.isNativeMp && getApp && (getApp({
          allowDefault: !0
        }).promotionMonitoring = e || w("promotionMonitoring") || getApp({
          allowDefault: !0
        }).promotionMonitoring)
      }
    }, {
      key: "getPromotionMonitoring",
      value: function() {
        return h.default.isNativeMp && getApp && getApp({
          allowDefault: !0
        }).promotionMonitoring || ""
      }
    }, {
      key: "pageShowInit",
      value: function() {
        try {
          (function() {
            var e, t, n, r, a;
            if (Y) he();
            else if ($ || te || ae) try {
              var i = {
                data: {
                  action: "setCurrentViewH5Page",
                  data: document.location.href
                }
              };
              $ ? null === (t = null === (e = null === wx || void 0 === wx ? void 0 : wx.miniProgram) || void 0 === e ? void 0 : e.postMessage) || void 0 === t || t.call(e, i) : te ? null === (n = null === my || void 0 === my ? void 0 : my.postMessage) || void 0 === n || n.call(my, i) : ae && (null === (a = null === tt || void 0 === tt ? void 0 : (r = tt.miniProgram).postMessage) || void 0 === a || a.call(r, i))
            } catch (e) {}
          })(), Ce.checkPageShow()
        } catch (e) {
          y.addError({
            name: "pageShowInit error",
            msg: JSON.stringify(e)
          })
        }
      }
    }, {
      key: "appendCommonParam",
      value: function(e) {
        try {
          de(e), H(e)
        } catch (e) {
          y.addError({
            name: "appendCommonParam error",
            msg: JSON.stringify(e)
          })
        }
      }
    }, {
      key: "clearLxBizParams",
      value: function() {
        try {
          (function() {
            var e = E();
            e.rmsGlobalLxBizParams_v2 = {
              request_id: e.rmsGlobalLxBizParams_v2 && e.rmsGlobalLxBizParams_v2.request_id || ""
            }
          })(),
          function() {
            var e = E();
            e.rmsGlobalLxBizParams = {
              request_id: e.rmsGlobalLxBizParams && e.rmsGlobalLxBizParams.request_id || ""
            }
          }()
        } catch (e) {
          y.addError({
            name: "clearLxBizParams error",
            msg: JSON.stringify(e)
          })
        }
      }
    }, {
      key: "clearCurrentVisitPage",
      value: function() {
        try {
          ge()
        } catch (e) {
          y.addError({
            name: "clearCurrentVisitPage error",
            msg: JSON.stringify(e)
          })
        }
      }
    }, {
      key: "setCurrentVisitPage",
      value: function(e) {
        try {
          he(e)
        } catch (e) {
          y.addError({
            name: "setCurrentVisitPage error",
            msg: JSON.stringify(e)
          })
        }
      }
    }, {
      key: "sendPV",
      value: function(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
          n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
          r = arguments.length > 3 ? arguments[3] : void 0;
        try {
          var a = W(t, n);
          a = pe(a, n), me(e, a, this.lx), r && r.ignoreCheck || Ce.checkPvReport(e)
        } catch (e) {
          y.addError({
            name: "sendPV error",
            msg: JSON.stringify(e)
          })
        }
      }
    }, {
      key: "sendPD",
      value: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
        try {
          var t = W(e);
          t = pe(t), Pe(t, this.lx)
        } catch (e) {
          y.addError({
            name: "sendPD error",
            msg: JSON.stringify(e)
          })
        }
      }
    }, {
      key: "sendMC",
      value: function(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
          n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
          r = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null;
        try {
          var a = W(t, r);
          a = pe(a, r), xe(e, a, n, this.lx)
        } catch (e) {
          y.addError({
            name: "sendMC error",
            msg: JSON.stringify(e)
          })
        }
      }
    }, {
      key: "sendMV",
      value: function(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
          n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
          r = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null;
        try {
          var a = W(t, r);
          a = pe(a, r), ye(e, a, n, this.lx)
        } catch (e) {
          y.addError({
            name: "sendMV error",
            msg: JSON.stringify(e)
          })
        }
      }
    }, {
      key: "sendME",
      value: function(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
          n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
          r = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null;
        try {
          var a = W(t, r);
          a = pe(a, r), be(e, a, n, this.lx)
        } catch (e) {
          y.addError({
            name: "sendME error",
            msg: JSON.stringify(e)
          })
        }
      }
    }]), e
  }());
exports.LXReporter = ke;
var Ie = function(e) {
    return Object.assign(Object.assign(Object.assign({}, M()), {
      "promotion-monitoring": ke.getPromotionMonitoring()
    }), function() {
      var e, t, n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
        r = n.tenantId,
        a = void 0 === r ? "" : r;
      return a ? {
        "x-cardId": null !== (t = null === (e = m.default.getCardId) || void 0 === e ? void 0 : e.call(m.default, a)) && void 0 !== t ? t : ""
      } : {}
    }(e))
  },
  Me = h.default.isNativeMp,
  Le = h.default.isAliPayNative,
  Se = new(function() {
    function e() {
      l(this, e), this.requestConfig = {}
    }
    return f(e, [{
      key: "init",
      value: function(e) {
        return this.requestConfig = e, Me ? Le ? this.alipayRequest() : this.mpRequest() : this.webRequest()
      }
    }, {
      key: "mpRequest",
      value: function() {
        var e = this.requestConfig,
          t = e.method,
          n = e.header;
        return this.requestConfig = Object.assign(Object.assign({}, this.requestConfig), {
          method: t ? t.toUpperCase() : "GET",
          header: Object.assign(Object.assign({}, n), Ie(n))
        }), I(this.requestConfig), this.requestConfig
      }
    }, {
      key: "alipayRequest",
      value: function() {
        var e = this.requestConfig,
          t = e.method,
          n = e.header,
          r = e.fail,
          a = e.reportError;
        return this.requestConfig = Object.assign(Object.assign({}, this.requestConfig), {
          method: t ? t.toUpperCase() : "GET",
          headers: Object.assign(Object.assign({}, n), Ie(n)),
          fail: function(e) {
            e && e.errorMessage && (e.errMsg = e.errorMessage), r(e)
          }
        }), a && (this.requestConfig.reportError = function(e) {
          return e && (e.errMsg = e.errorMessage || ""), a(e)
        }), delete this.requestConfig.header, I(this.requestConfig), this.requestConfig
      }
    }, {
      key: "webRequest",
      value: function() {
        var e = this.requestConfig,
          t = e.method,
          n = e.header,
          r = e.data,
          a = e.headers,
          i = e.params,
          o = Object.assign({}, n, a);
        return this.requestConfig = Object.assign(Object.assign({}, this.requestConfig), {
          method: t ? t.toLowerCase() : "get",
          headers: Object.assign(Object.assign({}, o), Ie(o))
        }), "get" === this.requestConfig.method ? this.requestConfig.params = i || r : (i && (this.requestConfig.params = i), this.requestConfig.data = r), delete this.requestConfig.header, I(this.requestConfig), this.requestConfig
      }
    }]), e
  }());

function we() {
  return v.default.getStorageSync("RMS_APP_MOCK") || !1
}
var Oe = new(function() {
  function e() {
    l(this, e)
  }
  return f(e, [{
    key: "init",
    value: function(e, t) {
      if (h.default.isWxNative && t) try {
        this.sharkInstance = new t({
          bizToken: e.appKey,
          env: e.env || "product",
          awaitConnectTime: e.awaitConnectTime || 700,
          logLevel: e.logLevel || "warn",
          owl: p.owl,
          isOwlReport: !e.ignoreOwlReport
        })
      } catch (e) {
        y.addError({
          name: "shark实例初始化异常",
          msg: JSON.stringify(e)
        })
      }
    }
  }, {
    key: "request",
    value: function(e, t) {
      return U(this, void 0, void 0, d.default.mark((function n() {
        return d.default.wrap((function(n) {
          for (;;) switch (n.prev = n.next) {
            case 0:
              if (!h.default.isWxNative || !this.sharkInstance) {
                n.next = 2;
                break
              }
              return n.abrupt("return", this.sharkInstance.isOpen() ? this.sharkInstance.request(e, t) : Promise.resolve());
            case 2:
              return n.abrupt("return", Promise.resolve());
            case 3:
            case "end":
              return n.stop()
          }
        }), n, this)
      })))
    }
  }]), e
}());

function Ee(e) {
  return "function" == typeof e
}
exports.Shark = Oe;
var _e = function(e, t) {
  return new Promise((function(n, r) {
    if (we()) {
      var a = function(e, t, n, r) {
        var a = null;
        if (!e) return null;
        var i = "https://appmock.sankuai.com/";
        try {
          var o, s = /https?:\/\/?(.+com)\//i,
            u = "",
            c = "",
            d = e.match(s),
            l = i.match(s);
          if (d && (u = d[1] || "", c = d[2] || ""), !l || !l[1]) throw Error("Invalid Mock Domain");
          o = l[1];
          var f = e.match(/^(https?):\/\//),
            p = f && f[1] || "https",
            g = {
              MKOriginHost: u,
              MKOriginPort: c,
              MKUnionId: m.default.getOpenId(),
              MKScheme: p,
              MKAppID: h.default.MPInfo.getAppId()
            };
          u !== o && (e = e.replace(u, o)), a = {
            url: e,
            header: g
          }
        } catch (e) {}
        return a
      }(e.url);
      a && (e.url = a.url, e.header = Object.assign(Object.assign({}, a.header), e.header))
    }
    var i = e.complete && Ee(e.complete),
      o = {},
      s = Object.assign(Object.assign({}, e), {
        isRequest: !0,
        enableHttp2: !0,
        success: function(t) {
          var r = (null == t ? void 0 : t.statusCode) || (null == t ? void 0 : t.status);
          200 !== r && y.addError({
            name: "[".concat(r, "]请求statusCode异常"),
            msg: JSON.stringify({
              method: o.method || "",
              url: o.url || "",
              header: o.header || "",
              response: JSON.stringify(t)
            })
          }, {
            category: "ajaxError"
          }), !i && e.success && Ee(e.success) && e.success(t), n(t)
        },
        fail: function(t) {
          !i && e.fail && Ee(e.fail) ? (e.fail(t), n(t)) : r(t)
        },
        complete: function(t) {
          i && e.complete(t)
        }
      });
    t && (s.reportError = function(e) {
      return t(e)
    }), o = Se.init(s);
    var u = h.default.isWxNative ? (0, g.getSaftyRequest)(p.request) : p.request;
    e.openShark ? Oe.request(o).then((function(e) {
      e && e.req ? e.req.isFailover && y.addError({
        name: "[shark降级-".concat(e.req.failoverReason || "", "]").concat(o.url || ""),
        msg: JSON.stringify(e)
      }, {
        category: "ajaxError",
        level: "info"
      }) : u(o)
    })).catch((function(e) {
      y.addError({
        name: "[shark异常]" + (o.url || ""),
        msg: JSON.stringify(e)
      }, {
        category: "ajaxError",
        level: "info"
      }), u(o)
    })) : u(o)
  }))
};
exports.request = _e;
var qe, Te = {
  clearThemeCache: function(e) {
    var t = e.options;
    if (e.forceClear || (null == t ? void 0 : t.q) || (null == t ? void 0 : t.p) || (null == t ? void 0 : t.s)) try {
      ((v.default.getStorageInfoSync() || {}).keys || []).forEach((function(e) {
        e.includes("rms_decor") && v.default.removeStorageSync(e)
      }))
    } catch (e) {}
  }
};
exports.Theme = Te,
  function(e) {
    e.LIGHT = "1", e.DARK = "2"
  }(qe || (qe = {}));
var je = (c(r = {}, qe.LIGHT, "#333333"), c(r, qe.DARK, "#ffffff"), r),
  Ae = (c(a = {}, qe.LIGHT, "#222222"), c(a, qe.DARK, "#ffffff"), a),
  Ne = "https://p0.meituan.net/scarlett/932659e7a41db4a4c1f52a87b0dce2be157687.gif",
  Be = "https://p1.meituan.net/travelcube/1575d69653e044c55d828c18502c648012181.png",
  De = "linear-gradient(to right bottom, #FFD100 0%, #FFC60C 100%)",
  ze = {
    themeColor: [6, 10, 20, 30, 50, 70],
    themeFontColor: [30]
  },
  Re = ["themeColor"];

function Fe(e) {
  for (var t, r = [], a = function() {
      var e = n(o[i], 2),
        a = e[0],
        s = e[1],
        u = (t = a) ? "--" + t.replace(/[A-Z]+/g, (function(e) {
          return "-" + e.toLowerCase()
        })) : "";
      "themeColor" !== a && "themeFontColor" !== a || ze[a].forEach((function(e) {
        r.push("".concat(u, "-transparent-").concat(e, ": ").concat(function(e) {
          var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 100;
          return "rgba(".concat([e.slice(1, 3), e.slice(3, 5), e.slice(5)].map((function(e) {
            return parseInt("0x" + e, 16)
          })).join(", "), ", ").concat(t / 100, ")")
        }(s, e)))
      })), "themeBgColor" === a && r.push("--theme-bg:" + s), "themeLoadingIcon" !== a ? r.push("".concat(u, ":").concat(s)) : r.push("".concat(u, ":url(").concat(s, ")"))
    }, i = 0, o = Object.entries(e); i < o.length; i++) a();
  return r
}

function Je(e) {
  return !e || Re.find((function(t) {
    return !e[t]
  }))
}
var He = function() {
  function e() {
    l(this, e), this.brand = {
      brandColor: "#FFD100",
      brandColorBorder: "#FFD100",
      brandColorBg: "#FFF8D9",
      brandColorBgLinear: De,
      brandColorText: Ae[qe.LIGHT],
      themeLoadingIcon: Ne
    }, this.orderDish = {
      themeColor: "#ffc700",
      themeBgColor: "linear-gradient(134deg, #ffde87 0%, #ffc400 100%)",
      themeFontColor: je[qe.LIGHT],
      themeLoadingIcon: Ne
    }, this.member = {
      defaultHeadImg: Be
    }, this.cssVar = "", this.updateCssVar()
  }
  return f(e, [{
    key: "update",
    value: function(e) {
      var t = e || {},
        n = t.themeColor,
        r = t.suitType,
        a = t.loadingIcon,
        i = t.lightColor,
        o = t.defaultHeadImg;
      Je(e) || (this.brand = {
        brandColor: n,
        brandColorBorder: n,
        brandColorBg: i,
        brandColorText: Ae[r],
        brandColorBgLinear: "FFD100" === n ? De : "linear-gradient(to right bottom, ".concat(n, " 0%, ").concat(n, " 100%)"),
        themeLoadingIcon: a
      }, this.orderDish = {
        themeColor: n,
        themeBgColor: n,
        themeFontColor: je[r],
        themeLoadingIcon: a
      }, this.member = {
        defaultHeadImg: null != o ? o : Be
      }), this.updateCssVar()
    }
  }, {
    key: "updateCssVar",
    value: function() {
      var e = Fe(this.orderDish),
        t = Fe(this.brand);
      this.cssVar = e.concat(t).join(";")
    }
  }, {
    key: "getTheme",
    value: function() {
      return this.cssVar
    }
  }, {
    key: "getOldShopTheme",
    value: function(e) {
      var t = e || {},
        n = t.themeColor,
        r = t.suitType,
        a = t.loadingIcon,
        i = {
          themeColor: n,
          themeBgColor: n,
          themeFontColor: je[r],
          themeLoadingIcon: a
        };
      return Fe(Je(i) ? this.orderDish : i).join(";")
    }
  }], [{
    key: "getInstance",
    value: function() {
      return e.instance || (e.instance = new e), e.instance
    }
  }]), e
}();
exports.ThemeModel = He;
var We = new(function() {
  function e() {
    l(this, e), this.model = He.getInstance()
  }
  return f(e, [{
    key: "initTheme",
    value: function(e) {
      var t = (e || {}).fail,
        n = v.default.getExtConfigSync && v.default.getExtConfigSync() || {},
        r = (n.extConfig ? n.extConfig : n).decorationConfig,
        a = void 0 === r ? {} : r;
      this.model.update(a), !a && t("全局装修配置读取失败")
    }
  }]), e
}());
exports.ThemeControl = We;
var Ue = function() {
  function e() {
    l(this, e), this.topics = {}
  }
  return f(e, [{
    key: "subscribe",
    value: function(e, t) {
      this.topics[e] || (this.topics[e] = []), this.topics[e].push(t)
    }
  }, {
    key: "unsubscribe",
    value: function(e, t) {
      if (this.topics[e]) {
        var n = this.topics[e].findIndex((function(e) {
          return e === t
        }));
        n >= 0 && this.topics[e].splice(n, 1)
      }
    }
  }, {
    key: "publish",
    value: function(e) {
      for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
      this.topics[e] && this.topics[e].forEach((function(e) {
        e && e.apply(void 0, n)
      }))
    }
  }], [{
    key: "getInstance",
    value: function() {
      return e.instance || (e.instance = new e), e.instance
    }
  }]), e
}();
exports.Observer = Ue;
var Ve = y,
  Ge = function() {
    function e(t, n) {
      l(this, e), this.name = t, this.status = 0, this.startTime = Date.now(), this.isFinish = !1, this.silence = !!n
    }
    return f(e, [{
      key: "success",
      value: function() {
        this.report(200)
      }
    }, {
      key: "fail",
      value: function(e) {
        this.report(e)
      }
    }, {
      key: "report",
      value: function(e) {
        if (this.isFinish) return !1;
        if (this.status = e, this.isFinish = !0, !this.silence) {
          var t = Date.now() - this.startTime;
          Ve.addApi("Transaction-" + this.name, 200, this.status, t)
        }
        return !0
      }
    }]), e
  }();
exports.Transaction = Ge;
var Ke = function(e, t, n, r) {
    return U(this, void 0, void 0, d.default.mark((function a() {
      var i, o;
      return d.default.wrap((function(a) {
        for (;;) switch (a.prev = a.next) {
          case 0:
            return i = new Ge(e, !!r), a.prev = 1, a.next = 4, t(i);
          case 4:
            return o = a.sent, a.abrupt("return", (n ? setTimeout((function() {
              i.fail(451)
            }), 1e4) : i.success(), o));
          case 8:
            return a.prev = 8, a.t0 = a.catch(1), a.abrupt("return", (Ve.addError("Transaction-".concat(e, "-").concat((null == a.t0 ? void 0 : a.t0.message) || (null == a.t0 ? void 0 : a.t0.name) || ""), a.t0), i.fail(450), null));
          case 11:
          case "end":
            return a.stop()
        }
      }), a, null, [
        [1, 8]
      ])
    })))
  },
  Xe = function() {
    return h.default.MPEnv.get()
  },
  $e = function() {
    return (0, m.getMenuOrderHost)(Xe())
  },
  Ze = function() {
    var e = "undefined" != typeof getCurrentPages && getCurrentPages() || [];
    return e.length > 0 ? e[e.length - 1] || {} : {
      route: "app",
      options: v.default.getEnterOptionsSync && v.default.getEnterOptionsSync() && v.default.getEnterOptionsSync().query || {}
    }
  },
  Ye = function() {
    return Ze().route || "Unknown"
  },
  Qe = function(e) {
    var t = Ze().options || {};
    return e ? decodeURIComponent(t[e] || "") : t
  },
  et = function() {
    var e = +Qe("bizType") || 0,
      t = 51;
    return 3 === e ? t = 61 : 4 === e && (t = 67), t
  };
exports.updateApp = function(e, t) {
  try {
    var n = v.default.getUpdateManager();
    n.onUpdateReady((function() {
      y.addLog("forceUpdateWxAppSuccess", {
        extraInfo: "".concat(e ? "强制" : "", "更新小程序成功,logOptions:").concat(JSON.stringify(t))
      }), e ? n.applyUpdate() : v.default.showModal({
        title: "更新提示",
        content: "新版本已经准备好，是否重启应用？",
        success: function(e) {
          e.confirm ? n.applyUpdate() : e.cancel && y.addLog("cancel_update", {
            extraInfo: "用户取消更新,logOptions:" + JSON.stringify(t)
          })
        }
      })
    })), n.onUpdateFailed((function() {
      y.addError({
        name: "更新小程序失败",
        msg: JSON.stringify(t)
      })
    }))
  } catch (e) {
    y.addError(e)
  }
}, exports.getReviewHost = function() {
  var e = "https://canyin-openapi.meituan.com";
  switch (Xe()) {
    case "production":
      break;
    case "ST":
    case "staging":
      e = "https://rmsreview.st.meituan.com";
      break;
    default:
      e = "https://rmsreview.test.meituan.com"
  }
  return e
}, exports.getLoginHost = function() {
  var e = Xe(),
    t = "https://rms.sjst.test.meituan.com";
  switch (e) {
    case "production":
      t = "https://pos.meituan.com";
      break;
    case "development":
    case "test":
      t = "https://rms.sjst.test.meituan.com";
      break;
    case "ST":
    case "staging":
      t = "https://rms.sjst.st.meituan.com";
      break;
    default:
      t = t.replace(/^(.*\/\/)?(.*?)\./, "$1".concat(e, "-sl-$2."))
  }
  return t
}, exports.getMemberHost = function() {
  return (0, m.getLoginHost)(Xe())
}, exports.getTakeAwayHost = function() {
  var e = Xe(),
    t = "https://canting.sjst.test.meituan.com";
  switch (e) {
    case "production":
      t = "https://rmstakeaway.meituan.com";
      break;
    case "test":
      t = "https://canting.sjst.test.meituan.com";
      break;
    case "ST":
    case "staging":
      t = "https://canting.sjst.st.meituan.com";
      break;
    default:
      t = t.replace(/^(.*\/\/)?(.*?)\./, "$1".concat(e, "-sl-$2."))
  }
  return t
}, exports.getDefaultHost = $e, exports.getEnv = Xe, exports.initEnv = function(e) {
  h.default.MPEnv.set(e || "production");
  var t = Xe();
  p.owl.config({
    devMode: "production" !== t
  })
}, exports.transactionOnce = function(e) {
  return e.__transactionCache || (e.__transactionCache = {}),
    function(t, n, r) {
      return U(this, void 0, void 0, d.default.mark((function a() {
        var i;
        return d.default.wrap((function(a) {
          for (;;) switch (a.prev = a.next) {
            case 0:
              return i = Ke(t, n, r, !!e.__transactionCache[t]), e.__transactionCache[t] = !0, a.next = 4, i;
            case 4:
              return a.abrupt("return", a.sent);
            case 5:
            case "end":
              return a.stop()
          }
        }), a)
      })))
    }
}, exports.transaction = Ke;
var nt = new(function() {
  function e() {
    l(this, e), this.stack = [], this.timer = null, this.maxSize = 2, this.maxRetryTimes = 3, this.source = 0
  }
  return f(e, [{
    key: "init",
    value: function(e) {
      this.stack = [], this.timeout = e.timeout || 2e3, this.maxSize = e.maxSize || 2, this.source = e.source
    }
  }, {
    key: "startTimer",
    value: function() {
      var e = this;
      this.timer = setTimeout((function() {
        e.clearStuck()
      }), this.timeout)
    }
  }, {
    key: "clearStuck",
    value: function() {
      this.stack.length && (this.request(), this.timer && clearTimeout(this.timer))
    }
  }, {
    key: "report",
    value: function(e) {
      var t = e.moduleId,
        n = void 0 === t ? "" : t,
        r = e.eventType,
        a = void 0 === r ? 1 : r,
        i = e.extend,
        o = void 0 === i ? {} : i;
      this.stack.length >= this.maxSize ? this.clearStuck() : (this.timer && clearTimeout(this.timer), this.stack.push({
        ts: Date.now(),
        moduleId: n,
        eventType: a,
        extend: JSON.stringify(o)
      }), this.startTimer())
    }
  }, {
    key: "request",
    value: function() {
      return U(this, void 0, void 0, d.default.mark((function e() {
        var t, n, r, a;
        return d.default.wrap((function(e) {
          for (;;) switch (e.prev = e.next) {
            case 0:
              return t = this.stack.concat([]), this.stack = [], n = {
                source: this.source,
                events: t
              }, e.next = 5, m.default.getUserInfoSync();
            case 5:
              r = e.sent, a = r.userTokenStr, _e({
                method: "POST",
                url: $e() + "/api/v1/rmsmina/c/useraction/upload",
                header: {
                  poiId: Qe("shopId") || "",
                  tenantId: Qe("tenantId") || "",
                  "X-appId": h.default.MPInfo.getAppId(),
                  "X-user": a,
                  appCode: et()
                },
                data: n
              });
            case 8:
            case "end":
              return e.stop()
          }
        }), e, this)
      })))
    }
  }]), e
}());
exports.advertiseReporter = nt;
var rt, at, it = new(function() {
  function e() {
    l(this, e), this.listener = function(e) {
      var t = e.errMsg.includes("timeout") ? "异步组件分包下载超时" : "异步组件分包下载失败";
      y.addError({
        name: t,
        msg: JSON.stringify(e)
      }, {
        category: "resourceError"
      })
    }, this.componentLoadInfo = {}, this.jsLoadInfo = {}, this.hasLoadPackageList = [], this.requireAsync = this.requireAsync.bind(this), this.loadJS = this.loadJS.bind(this)
  }
  return f(e, [{
    key: "onError",
    value: function() {
      h.default.isWxNative && wx.onLazyLoadError && wx.onLazyLoadError(this.listener)
    }
  }, {
    key: "offError",
    value: function() {
      h.default.isWxNative && wx.offLazyLoadError && wx.offLazyLoadError(this.listener)
    }
  }, {
    key: "reportComponentMountedTotal",
    value: function(e) {
      var t = this;
      if (h.default.isWxNative) try {
        var n = Ye(),
          r = Date.now();
        e && e.length && e.forEach((function(e) {
          var a = {
            page: n,
            start: r,
            isPackageFirst: !t.hasLoadPackageList.includes("async-main")
          };
          t.componentLoadInfo[e] ? (t.componentLoadInfo[e] = t.componentLoadInfo[e].filter((function(e) {
            return e.page !== n
          })), t.componentLoadInfo[e].push(a)) : t.componentLoadInfo[e] = [a], y.addCustom("asyncComponentMountedTotalCount", 1, {
            component: e,
            page: n,
            isPackageFirst: a.isPackageFirst
          })
        }))
      } catch (e) {
        y.addError({
          name: "上报小程序异步组件挂载方法异常",
          msg: JSON.stringify(e)
        })
      }
    }
  }, {
    key: "reportComponentMountedSuccess",
    value: function(e) {
      if (h.default.isWxNative) try {
        var t = Ye(),
          n = Date.now();
        if (this.componentLoadInfo[e]) {
          var r = this.componentLoadInfo[e].find((function(e) {
            return e.page === t
          }));
          r && (y.addCustom("asyncComponentMountedSuccessCount", n - r.start, {
            component: e,
            page: t,
            isPackageFirst: r.isPackageFirst
          }), this.componentLoadInfo[e] = this.componentLoadInfo[e].filter((function(e) {
            return e.page !== t
          })))
        }
      } catch (e) {
        y.addError({
          name: "上报小程序异步组件挂载success方法异常",
          msg: JSON.stringify(e)
        })
      }
    }
  }, {
    key: "requireAsync",
    value: function(e) {
      return U(this, void 0, void 0, d.default.mark((function t() {
        var n, r, a, i;
        return d.default.wrap((function(t) {
          for (;;) switch (t.prev = t.next) {
            case 0:
              if (h.default.isWxNative, n = Date.now(), r = e.match(/^(\.\.\/)+(\S[^/]+)\/(\S+\/)*(.+)\.js$/)[2], a = {
                  start: n,
                  retry: 0
                }, !this.hasLoadPackageList.includes(r)) {
                t.next = 5;
                break
              }
              return i = require(e), t.abrupt("return", (y.addCustom("asyncPackageLoadSuccess", Date.now() - a.start, {
                packageName: r,
                retry: 0,
                isPackageFirst: !1
              }), i));
            case 5:
              return this.jsLoadInfo[r] && this.jsLoadInfo[r].requirePromise || (a.requirePromise = this.loadJS(r, e), this.jsLoadInfo[r] = a), t.prev = 6, t.next = 9, this.jsLoadInfo[r].requirePromise;
            case 9:
              return t.abrupt("return", require(e));
            case 12:
              return t.prev = 12, t.t0 = t.catch(6), t.abrupt("return", Promise.reject(t.t0));
            case 15:
            case "end":
              return t.stop()
          }
        }), t, this, [
          [6, 12]
        ])
      })))
    }
  }, {
    key: "loadJS",
    value: function(e, t) {
      return U(this, void 0, void 0, d.default.mark((function n() {
        var r;
        return d.default.wrap((function(n) {
          for (;;) switch (n.prev = n.next) {
            case 0:
              return n.prev = 0, n.next = 3, require.async(t);
            case 3:
              return r = n.sent, n.abrupt("return", (y.addCustom("asyncPackageLoadSuccess", Date.now() - this.jsLoadInfo[e].start, {
                packageName: e,
                retry: this.jsLoadInfo[e].retry,
                isPackageFirst: !0
              }), this.hasLoadPackageList.push(e), delete this.jsLoadInfo[e], r));
            case 7:
              return n.prev = 7, n.t0 = n.catch(0), n.abrupt("return", this.jsLoadInfo[e].retry < 3 ? (this.jsLoadInfo[e].retry += 1, this.loadJS(e, t)) : (y.addError({
                name: e + "分包加载失败",
                msg: JSON.stringify(n.t0)
              }, {
                category: "resourceError"
              }), y.addCustom("asyncPackageLoadFail", Date.now() - this.jsLoadInfo[e].start, {
                packageName: e,
                isPackageFirst: !0
              }), delete this.jsLoadInfo[e], Promise.reject(n.t0)));
            case 10:
            case "end":
              return n.stop()
          }
        }), n, this, [
          [0, 7]
        ])
      })))
    }
  }]), e
}());
exports.LazyLoad = it,
  function(e) {
    e[e.Normal = 1] = "Normal", e[e.Hundredth = 2] = "Hundredth"
  }(rt || (rt = {})),
  function(e) {
    e[e.Common = 1] = "Common", e[e.Billing = 2] = "Billing"
  }(at || (at = {}));
var ot = (c(i = {}, rt.Normal, 1), c(i, rt.Hundredth, 100), i);
var st, ut = {
  default: {
    year: "-",
    month: "-",
    day: "",
    connector: " 至 "
  },
  "zh-cn": {
    year: "年",
    month: "月",
    day: "日",
    connector: " - "
  }
};

function ct(e, t) {
  return t !== st.ZH_CN && e < 10 ? "0" + e : e
}

function dt(e, t, n) {
  if (!e) return "";
  var r = new Date(e),
    a = r.getFullYear(),
    i = ct(r.getMonth() + 1, t),
    o = ct(r.getDate(), t),
    s = ct(r.getHours(), st.DEFAULT),
    u = ct(r.getMinutes(), st.DEFAULT),
    c = ct(r.getSeconds(), st.DEFAULT),
    d = ut[t];
  return a + d.year + i + d.month + o + d.day + (n ? " ".concat(s, ":").concat(u, ":").concat(c) : "")
}
exports.LOCALE = st,
  function(e) {
    e.DEFAULT = "default", e.ZH_CN = "zh-cn"
  }(st || (exports.LOCALE = st = {}));