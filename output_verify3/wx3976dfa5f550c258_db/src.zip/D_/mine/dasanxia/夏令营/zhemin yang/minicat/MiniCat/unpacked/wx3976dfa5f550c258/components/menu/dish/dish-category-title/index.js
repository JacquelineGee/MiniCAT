var e = require("../../../../b/helpers/interopRequireDefault"),
  t = require("../../../../miniprogram_npm/@limo/container/behaviors/index"),
  o = require("../../../../constants/bizConstants"),
  a = e(require("../../../../modules/menu/shop/shopService"));
Component({
  behaviors: [t.commonBehavior, t.limoShim],
  options: {
    addGlobalClass: !0
  },
  properties: {
    hasMtLogin: {
      type: Boolean,
      value: !1
    },
    category: {
      type: Object,
      value: {
        categoryId: 0
      },
      observer: function(e, t) {
        if (e && e !== t) {
          var a = "",
            i = "";
          switch (e.iconType) {
            case o.DISH_CATEGORY_ICON_TYPE.ORDERED_DISH:
              i = "" + (e.categoryName || ""), a = o.DISH_CATEGORY_CLASS_MAP[o.DISH_CATEGORY_ICON_TYPE.ORDERED_DISH];
              break;
            case o.DISH_CATEGORY_ICON_TYPE.HOT:
              a = o.DISH_CATEGORY_CLASS_MAP[o.DISH_CATEGORY_ICON_TYPE.HOT], i = "";
              break;
            case o.DISH_CATEGORY_ICON_TYPE.DISCOUNT:
              a = o.DISH_CATEGORY_CLASS_MAP[o.DISH_CATEGORY_ICON_TYPE.DISCOUNT], i = "折扣";
              break;
            case o.DISH_CATEGORY_ICON_TYPE.RECOMMEND:
              a = o.DISH_CATEGORY_CLASS_MAP[o.DISH_CATEGORY_ICON_TYPE.RECOMMEND], i = "";
              break;
            case o.DISH_CATEGORY_ICON_TYPE.MT_SPECIAL_DISCOUNT:
              a = o.DISH_CATEGORY_CLASS_MAP[o.DISH_CATEGORY_ICON_TYPE.MT_SPECIAL_DISCOUNT], i = "";
              break;
            default:
              a = "", i = "" + (e.categoryName || "")
          }
          this.setData({
            picClassName: a,
            titleTxt: i
          }), this.getPointText(e.categoryId)
        }
      }
    },
    customClass: {
      type: String,
      value: ""
    },
    showCouponPackage: {
      type: Boolean,
      value: !1
    }
  },
  data: {
    DISH_CATEGORY_ID: o.DISH_CATEGORY_ID,
    LOGIN_IN_TEXT: "立即登录",
    picClassName: "",
    titleTxt: "",
    pointText: "",
    showMemberLogin: !1
  },
  methods: {
    dishPanelOrderd: function() {
      this.triggerEvent("moreTap")
    },
    gotoThirdLogin: function() {
      this.triggerEvent("gotoThirdLogin", null, {
        bubbles: !0,
        composed: !0
      })
    },
    getPointText: function(e) {
      if (e === o.DISH_CATEGORY_ID.POINT_PURCHASE) {
        var t = a.default.getShopServiceData().memberInfo,
          i = 0;
        null != t && t.memberId ? (i = (null == t ? void 0 : t.totalPoint) || 0, this.setData({
          pointText: "可用积分 " + i,
          showMemberLogin: !1
        })) : this.setData({
          showMemberLogin: !0
        })
      } else this.setData({
        pointText: "",
        showMemberLogin: !1
      })
    }
  }
});