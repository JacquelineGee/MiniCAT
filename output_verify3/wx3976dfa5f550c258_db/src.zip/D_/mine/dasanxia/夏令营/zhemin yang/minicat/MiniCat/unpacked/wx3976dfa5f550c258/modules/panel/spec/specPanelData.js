Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.transSpecData = void 0;
var e = require("../../../constants/bizConstants"),
  t = require("../../../constants/menu"),
  i = require("./util"),
  r = require("./mutex"),
  o = function(r) {
    var o = r.cartGroups,
      n = r.groups,
      u = r.groupSettings,
      l = r.panelGroupType,
      s = r.mutexMatrix;
    if (!n || !n.length) return null;
    var a = !!u,
      E = {
        title: a && n.length > 1 ? l : "",
        subTitle: [],
        maxChoice: (null == u ? void 0 : u.maxChoice) || e.NO_LIMIT_CHOICE,
        minChoice: (null == u ? void 0 : u.minChoice) || e.NO_LIMIT_CHOICE,
        repeatChoice: (null == u ? void 0 : u.repeatChoice) || e.TASTE_REPEAT_CHOICE.SINGLE,
        list: []
      },
      C = !1,
      p = 0,
      c = 0;
    if (n.forEach((function(r, n) {
        var h = r.groupName,
          T = r.items,
          I = r.maxChoice,
          _ = r.minChoice,
          m = r.groupId,
          S = r.type,
          d = !r.repeatChoice && l === t.PANEL_GROUP_TYPE_VAL.METHOD || r.repeatChoice === e.TASTE_REPEAT_CHOICE.SINGLE || (null == u ? void 0 : u.repeatChoice) === e.TASTE_REPEAT_CHOICE.SINGLE || I === e.SINGLE_CHOICE || (null == u ? void 0 : u.maxChoice) === e.SINGLE_CHOICE ? e.TASTE_REPEAT_CHOICE.SINGLE : e.TASTE_REPEAT_CHOICE.MULTI,
          G = (0, i.transGroupItem)(T, o, d, I, s[n]) || [],
          g = G.list,
          A = G.groupTotalCount;
        C = C || (0, i.calculateItemWholeLine)(g), p += A, c += g.length, E.list.push({
          title: h,
          groupId: m,
          subTitle: a ? [] : (0, i.transMethodTasteSubTitle)(I, _, g.length, A, d || e.TASTE_REPEAT_CHOICE.SINGLE),
          list: g,
          maxChoice: I,
          minChoice: _,
          index: n,
          repeatChoice: d,
          type: S
        })
      })), E.list.forEach((function(t) {
        t.itemWholeLine = C, t.disablePlus = p >= E.maxChoice && E.maxChoice !== e.NO_LIMIT_CHOICE
      })), a) {
      var h = (0, i.transMethodTasteSubTitle)(E.maxChoice, E.minChoice, c, p, E.repeatChoice);
      E.list.length > 1 ? E.subTitle = h : E.list[0].subTitle = h
    }
    return E
  },
  n = function(t) {
    var r, o = t.cartAttrs,
      n = t.attrs,
      u = t.skuMenuItems;
    if (null == n || !n.length) return null;
    var l = n[0],
      s = null == (r = (0, i.transAttrItem)(o, null == l ? void 0 : l.specValues, u)) ? void 0 : r.filter((function(e) {
        var t;
        return null == (t = e.name) ? void 0 : t.length
      }));
    return null != s && s.length ? {
      title: "规格",
      maxChoice: e.SINGLE_CHOICE,
      minChoice: e.SINGLE_CHOICE,
      repeatChoice: e.TASTE_REPEAT_CHOICE.SINGLE,
      list: [{
        list: s,
        groupId: "",
        index: 0,
        minChoice: e.SINGLE_CHOICE,
        maxChoice: e.SINGLE_CHOICE,
        repeatChoice: e.TASTE_REPEAT_CHOICE.SINGLE
      }]
    } : null
  };
exports.transSpecData = function(e, u, l) {
  var s, a, E = u || {},
    C = E.methods,
    p = E.tastes,
    c = (0, r.transMutexMatrix)(e, l);
  return {
    attrsGroups: n({
      cartAttrs: (0, i.getPanelTempDishSpec)(e, u),
      attrs: u.specAttrs,
      skuMenuItems: u.skuMenuItems
    }),
    methodGroups: o({
      cartGroups: null == e ? void 0 : e.methods,
      groups: null == u ? void 0 : u.methods,
      groupSettings: null == (s = u.spuGroupSetting) ? void 0 : s.methodGroupSetting,
      panelGroupType: t.PANEL_GROUP_TYPE_VAL.METHOD,
      mutexMatrix: c.slice(0, (C || []).length)
    }),
    tasteGroups: o({
      cartGroups: null == e ? void 0 : e.tastes,
      groups: null == u ? void 0 : u.tastes,
      groupSettings: null == (a = u.spuGroupSetting) ? void 0 : a.tasteGroupSetting,
      panelGroupType: t.PANEL_GROUP_TYPE_VAL.TASTE,
      mutexMatrix: c.slice(-(p || []).length)
    })
  }
};