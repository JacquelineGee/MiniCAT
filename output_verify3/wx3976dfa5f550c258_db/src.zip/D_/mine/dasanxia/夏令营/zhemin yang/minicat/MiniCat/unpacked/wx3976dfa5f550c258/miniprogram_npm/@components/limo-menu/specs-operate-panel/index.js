var e = require("../../../../b/helpers/interopRequireDefault"),
  t = require("../../../@limo/container/behaviors/index"),
  n = e(require("../../../../modules/menu/I18n/I18nService"));
Component({
  behaviors: [t.commonBehavior, t.limoShim],
  properties: {
    specsOperatePanelData: {
      type: Object,
      value: null
    },
    isNativeTabbarPage: {
      type: Boolean,
      value: !1
    }
  },
  data: {},
  attached: function() {
    this.limoAttached()
  },
  methods: {
    limoAttached: function() {
      var e = n.default.getCurrency();
      this.setData({
        currency: e
      })
    },
    closePanelFunc: function() {
      this.triggerEvent("closeSpecsOperatePanel")
    },
    minusSkuDishWithSameSpecFunc: function(e) {
      this.triggerEvent("minusSkuDishWithSameSpec", e.currentTarget.dataset)
    },
    toggleSpecPanelFunc: function(e) {
      this.triggerEvent("toggleSpecPanel", e.currentTarget.dataset)
    },
    prevent: function() {},
    scroll: function(e) {
      e.stopPropagation && e.stopPropagation()
    }
  }
});