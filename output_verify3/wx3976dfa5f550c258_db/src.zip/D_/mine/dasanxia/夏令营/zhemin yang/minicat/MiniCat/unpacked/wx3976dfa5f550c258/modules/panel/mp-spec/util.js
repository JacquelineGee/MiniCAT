var e = require("../../../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.updateSkuDishMethods = exports.minusMultiTaste = exports.getSelectedDishDataFromSimpleCartDish = exports.getSelectedDishDataFromOrigin = exports.getPanelPromoData = exports.getPanelHeaderDish = exports.getPanelFooterData = exports.getOperationData = exports.addPanelSkuDish = exports.addMultiTaste = void 0, require("../../../b/helpers/Objectvalues");
var t = require("../../../b/helpers/toConsumableArray"),
  n = require("../../../b/helpers/objectSpread2"),
  u = require("../../menu/dish/PropertyUtil"),
  i = require("../../../constants/bizConstants"),
  r = require("../../cartHelper"),
  o = require("../../../lib/number"),
  s = require("../../../constants/menu"),
  l = require("../../../store/actions/cart"),
  a = e(require("../../../lib/mix/toast")),
  c = require("../../../miniprogram_npm/@components/limo-ui/ui-constant/enum"),
  d = require("./specPanelHelper"),
  m = require("../../dishHelper"),
  p = e(require("../../menu/shop/shopService")),
  f = require("../../menu/dish/DishSdk"),
  I = require("../../../lib/mix/util"),
  g = require("../spec/mutex"),
  h = require("../../../types/newMenu/MenuData"),
  v = e(require("../../menu/I18n/I18nService")),
  C = function(e, t) {
    var n, u = p.default.getShopServiceData().fmpBizData.pointBuyCampaign,
      i = null == u ? void 0 : u.pointDishList,
      r = null == i ? void 0 : i.find((function(t) {
        return t.spuId === e
      }));
    return null == r || null == (n = r.pointDishItems) ? void 0 : n.find((function(e) {
      return e.skuId === t
    }))
  };
exports.getPanelHeaderDish = function(e, t, o, s) {
  var l = (null == e ? void 0 : e.skuMenuItems.find((function(e) {
    return e.skuId === t
  }))) || (null == e ? void 0 : e.skuMenuItems[0]);
  if (l) {
    var a, d, m, f = null != l && l.stockCount ? null == l ? void 0 : l.stockCount : -1,
      I = (null == (a = l.tagList) ? void 0 : a.filter((function(e) {
        return e.colorType !== c.LABEL_TYPE.BKG_PRICE_1 && 16 !== e.colorType
      }))) || [];
    I = (0, u.dealTagList)(l, !1, I, "DEFAULT", !!s && !!C(e.spuId, t));
    var g = l.skuImg || (null == e || null == (d = e.dishPicUrls) ? void 0 : d[i.PICTURE_RATIO.ONE_TO_ONE]) || i.PLACEHOLDER_DISH_PIC.ONE_TO_ONE,
      v = p.default.getShopServiceData().fmpBizData,
      k = (0, u.dealPicLabelStyleType)(null != (m = null == v ? void 0 : v.picLabelStyleType) ? m : h.PIC_LABEL_STYLE_TYPE.DEFAULT),
      S = (0, r.getLimitDescList)(n(n({}, e), {}, {
        stockCount: f
      }), null);
    return {
      picUrl: g,
      name: l.skuName,
      hotSellingTag: (0, u.dealHotSellingTag)(e.hotSellingImgTag, "" + e.currentPrice, "DEFAULT"),
      picTag: e.dishTag && e.dishTag[0] || "",
      picLabel: S,
      picLabelClass: k,
      tagList: I,
      desc: e.description,
      packageDishCountText: o,
      recommendTags: e.recommendTags || [],
      dishDescribeTag: e.dishDescribeTag || []
    }
  }
  return null
};
exports.getPanelPromoData = function(e, t) {
  var n, r = t.skuId,
    o = t.selectedManualCampaigns,
    s = void 0 === o ? {} : o,
    l = (0, f.GetDishSdkSingleton)((0, I.getShopId)()),
    a = (l.findOriginalSkuDetail(e.spuId, r) || {}).promoCampaignIds;
  if (null == a || !a.length) return null;
  var c = ((null == (n = p.default.getShopServiceData()) ? void 0 : n.shopInfo) || {}).actId2Promotion;
  return c && Object.keys(c).length ? a.map((function(e) {
    var t, n = null == (t = c[e]) ? void 0 : t.rule;
    if (n) {
      var r = n.manualCampaignSkuInfo,
        o = void 0 === r ? [] : r,
        a = n.title,
        d = n.subTitle,
        p = o.map((function(t) {
          var n, r = t.spuId,
            o = t.skuId,
            a = t.currentPrice,
            c = void 0 === a ? 0 : a,
            d = t.quantity,
            p = l.findOriginalSpuDetail(r);
          if (p) {
            var f = p.spuName,
              I = p.dishPicUrls,
              g = p.description,
              h = p.skuMenuItems.find((function(e) {
                return e.skuId === o
              })),
              C = ((null == (n = s[e]) ? void 0 : n[o]) || {}).count,
              k = void 0 === C ? 0 : C,
              S = (0, m.convertComplexSpuToSimpleSpu)(p, o),
              D = (0, u.dealSkuOperationData)(null != S ? S : p, o, k, 0, 0) || {};
            D && (D.promoDishLimitCount = d, D.temporaryDishCount = !0);
            var O = v.default.getCurrency();
            return {
              dish: {
                spuId: r,
                skuId: o,
                name: f,
                picUrl: (null == I ? void 0 : I[i.PICTURE_RATIO.ONE_TO_ONE]) || i.PLACEHOLDER_DISH_PIC.ONE_TO_ONE,
                ifPropertyRender: !0,
                currentPrice: "" + c,
                cssType: "multi-promo",
                currency: O,
                desc: g,
                operationData: D
              },
              manualCampaignsItem: {
                spuId: r,
                campaignId: e,
                skuId: o,
                skuName: null == h ? void 0 : h.skuName,
                currentPrice: c,
                count: k
              }
            }
          }
        }));
      return {
        campaignId: e,
        title: a,
        subTitle: d,
        skuMenuItems: p.filter((function(e) {
          return !!e
        }))
      }
    }
  })).filter((function(e) {
    return !!e
  })) : null
};
exports.getPanelFooterData = function(e, n, i, r) {
  var s, l = null == e || null == (s = e.skuMenuItems) ? void 0 : s.find((function(e) {
    return e.skuId === n.skuId
  }));
  if (l) {
    var a, m = l.unit && !l.canWeight ? "/" + l.unit : "",
      p = n.count > 1 ? "每份:" : "",
      f = (0, d.getDishDesc)(n, e) ? p + (0, d.getDishDesc)(n, e) : "",
      I = !(null == l || null == (a = l.tagList) || !a.some((function(e) {
        return e.colorType === c.LABEL_TYPE.BKG_PRICE_1 || 16 === e.colorType
      })) || r),
      g = 0,
      h = (0, d.computeDishAddPrice)(n);
    n.extraPrice = h;
    var v = I ? (0, d.getMemberTag)(n, e.canWeight) : -1,
      k = (0, u.dealMemberPriceTag)(l),
      S = (0, o.plusFloat)(l.originalPrice, h);
    if (g = i ? h : (0, o.plusFloat)(l.currentPrice, h), n.selectedManualCampaigns && Object.keys(n.selectedManualCampaigns).length) {
      var D = Object.values(n.selectedManualCampaigns).reduce((function(e, n) {
        return [].concat(t(e), t(Object.values(n)))
      }), []).reduce((function(e, t) {
        var n = t.currentPrice,
          u = t.count;
        return (0, o.plusFloat)(e, (0, o.multiFloat)(n, u))
      }), 0);
      g = (0, o.plusFloat)(g, D), S = (0, o.plusFloat)(S, D)
    }
    var O = "";
    if (r) {
      var P = C(e.spuId, n.skuId);
      if (P) {
        var T = (0, o.minusFloat)(l.originalPrice, P.currentPrice);
        g = (0, o.minusFloat)(g, T), O = "已用 ".concat(P.pointCount, " 积分抵扣￥").concat(T)
      }
    }
    return {
      currentPrice: g,
      originalPrice: S,
      unit: m,
      memberPrice: v,
      dishDesc: f,
      memberPriceTag: k,
      pointDiscountText: O,
      estimatedPrice: l.estimatedPrice
    }
  }
  return null
};
exports.getOperationData = function(e, t, n, u, i) {
  var r, o, l = null == e || null == (r = e.skuMenuItems) ? void 0 : r.find((function(e) {
    return e.skuId === t.skuId
  }));
  if (l) {
    var a, c = n[e.spuId.toString()],
      d = null != l && l.stockCount ? null == l ? void 0 : l.stockCount : -1,
      m = 0;
    c && !i && c.map((function(e) {
      return e.skuId === l.skuId && e.count && (m += e.count), null
    })), c && i && c.map((function(e) {
      return e.skuId === l.skuId && e.itemNo !== i && e.count && (m += e.count), null
    })), a = -1 === d ? -1 : d - m > 1 ? d - m : 1, o = {
      id: e.spuId,
      skuId: l.skuId,
      temporaryDishCount: !0,
      type: s.DISH_OPERATION_TYPE_VAL.NUMBER,
      count: t.count,
      incCount: e.incBoughtCount,
      maxCount: a,
      showMultipleInput: u && 1 === e.incBoughtCount
    }
  }
  return o
};
exports.updateSkuDishMethods = function(e, t, n, u) {
  var o, s, l, c = JSON.parse(JSON.stringify(t)),
    d = null == e || null == (o = e.methods) ? void 0 : o.find((function(e) {
      return e.groupId === n
    }));
  if (!d) return null;
  var m = d.items.find((function(e) {
    return e.id === u
  }));
  if (!m || m.soldOut) return null;
  var p = {
      count: 1,
      id: u,
      name: m.name,
      price: m.price
    },
    f = null == c || null == (s = c.methods) ? void 0 : s.find((function(e) {
      return e.groupId === n
    })),
    I = function(e) {
      e && (c.methods = []), c.methods.push({
        groupId: d.groupId,
        groupName: d.groupName,
        items: [p]
      })
    },
    g = null == (l = e.spuGroupSetting) || null == (l = l.methodGroupSetting) ? void 0 : l.maxChoice,
    h = d.maxChoice || i.NO_LIMIT_CHOICE;
  if (f) {
    var v, C, k = null == f || null == (v = f.items) ? void 0 : v.find((function(e) {
      return e.id === u
    }));
    k ? f.items = null == f || null == (C = f.items) ? void 0 : C.filter((function(e) {
      return e !== k
    })) : g ? g === i.SINGLE_CHOICE ? I(!0) : g === i.NO_LIMIT_CHOICE ? f.items.push(p) : g < (0, r.calculateMethodsCount)(c.methods) + 1 ? a.default.show({
      content: "最多".concat(g, "份，已达到上限~")
    }) : f.items.push(p) : h === i.NO_LIMIT_CHOICE ? f.items.push(p) : h === i.SINGLE_CHOICE ? f.items = [p] : h < Number(f.items.length) + 1 ? a.default.show({
      content: "最多".concat(h, "份，已达到上限~")
    }) : f.items.push(p)
  } else g && g !== i.NO_LIMIT_CHOICE ? g === i.SINGLE_CHOICE ? I(!0) : g < (0, r.calculateMethodsCount)(null == c ? void 0 : c.methods) + 1 ? a.default.show({
    content: "最多".concat(g, "份，已达到上限~")
  }) : I(!1) : I(!1);
  return c
};
exports.addMultiTaste = function(e, t, n, u) {
  var r, o, s, c, d = JSON.parse(JSON.stringify(t)),
    m = null == d || null == (r = d.tastes) ? void 0 : r.find((function(e) {
      return e.groupId === n
    })),
    p = null == (o = e.tastes) ? void 0 : o.find((function(e) {
      return e.groupId === n
    })),
    f = null == p ? void 0 : p.items.find((function(e) {
      return e.id === u
    }));
  if (!f || !p) return null;
  var I = null == (s = e.spuGroupSetting) || null == (s = s.tasteGroupSetting) ? void 0 : s.maxChoice,
    g = (I = -1 === I ? 1 / 0 : I) || (0, l.calculateTotalMaxChoice)(e.tastes) || 1 / 0,
    h = -1 !== (null == p ? void 0 : p.maxChoice) ? null == p ? void 0 : p.maxChoice : 1 / 0;
  h = h || 1 / 0;
  var v = -1 !== f.stockCount ? f.stockCount : 1 / 0,
    C = g === i.SINGLE_CHOICE,
    k = h === i.SINGLE_CHOICE,
    S = 0;
  null == d || null == (c = d.tastes) || c.map((function(e) {
    var t;
    return null == e || null == (t = e.items) || t.map((function(e) {
      return S += e.count, null
    })), null
  }));
  var D = 0,
    O = 0;
  if (m && m.items.map((function(e) {
      return D += e.count, e.id === u && (O = e.count), null
    })), O + 1 > v && !C) return a.default.show({
    content: "库存不足，请选择其他加料~"
  }), null;
  if (D + 1 > h && !C && !k) return a.default.show({
    content: "最多".concat(h, "份，已达到上限~")
  }), null;
  if (S + 1 > g && !C && !k) return a.default.show({
    content: "最多".concat(g, "份，已达到上限~")
  }), null;
  var P = {
    groupId: p.groupId,
    groupName: p.groupName,
    items: [{
      count: 1,
      id: u,
      name: f.name,
      price: f.price
    }]
  };
  if (m) {
    var T = m.items.find((function(e) {
      return e.id === u
    }));
    C ? d.tastes = [P] : k ? m.items = [{
      count: 1,
      id: u,
      name: f.name,
      price: f.price
    }] : T ? T.count = O + 1 : m.items.push({
      count: 1,
      id: u,
      name: f.name,
      price: f.price
    })
  } else C ? d.tastes = [P] : d.tastes.push(P);
  return d
};
exports.minusMultiTaste = function(e, t, n, u) {
  var i, r, o = JSON.parse(JSON.stringify(t)),
    s = null == o || null == (i = o.tastes) ? void 0 : i.find((function(e) {
      return e.groupId === n
    })),
    l = null == s ? void 0 : s.items.find((function(e) {
      return e.id === u
    }));
  return s && l && l.count ? (l.count > 1 ? l.count -= 1 : s.items = null == s || null == (r = s.items) ? void 0 : r.filter((function(e) {
    return e.id !== u
  })), o) : null
};
exports.addPanelSkuDish = function(e, t, n, u, i) {
  var r = JSON.parse(JSON.stringify(t)),
    o = null == n ? void 0 : n[e.spuId.toString()],
    s = e.skuMenuItems.find((function(e) {
      return e.skuId === r.skuId
    }));
  if (!s) return null;
  var l = s.orderedCount,
    c = e.spuName,
    d = -1 === e.minBoughtCount ? 0 : e.minBoughtCount,
    p = e.incBoughtCount,
    f = -1 === s.stockCount ? 1 / 0 : s.stockCount,
    I = -1 === s.limitCount ? 1 / 0 : s.limitCount,
    g = r.count,
    h = 0;
  if (o && o.map((function(e) {
      return e.skuId === r.skuId && e.count && (h += e.count), null
    })), u) {
    var v = null == o ? void 0 : o.find((function(e) {
      return e.itemNo === u && e.skuId === s.skuId
    }));
    v && v.count && (h -= v.count)
  }
  if (i) {
    var C = g + p;
    if (!(0, m.verifyLimitCount)({
        delta: C,
        usedCount: h + l,
        limitCount: I
      })) return a.default.show({
      content: (0, m.jointExceedLimitCountMessage)({
        dishName: c,
        limitCount: I,
        orderedCount: l
      }),
      duration: m.LIMIT_COUNT_MESSAGE_DURATION
    }), null;
    if (C + h > f) return a.default.show({
      content: "当前库存不足"
    }), null;
    r.count = C
  } else {
    var k = g - p,
      S = (null == r ? void 0 : r.mustCount) || -1;
    if (k <= 0 || k < S) return a.default.show({
      content: "不能小于".concat(g, "份")
    }), null;
    if (!(k + h >= d)) return a.default.show({
      content: d + "份起售，不能再少啦"
    }), null;
    r.count = k
  }
  return r
};
exports.getSelectedDishDataFromOrigin = function(e, t, n, u) {
  var i, r = n.optionsDishParams,
    o = n.fromPackagePanel,
    s = r || {},
    l = s.selectedSkuId,
    c = void 0 === l ? "" : l,
    d = s.dishWeight,
    m = void 0 === d ? 0 : d,
    p = s.dishCount,
    f = void 0 === p ? 0 : p,
    I = 0,
    h = e.skuMenuItems && e.skuMenuItems.findIndex((function(e) {
      return !0 === e.defaultSelected
    }));
  if (I = -1 !== h ? h : 0, null != e && null != (i = e.skuMenuItems[I]) && i.soldOut) {
    for (I = 0; null != e && null != (v = e.skuMenuItems[I]) && v.soldOut;) {
      var v;
      I++
    }
    I >= e.skuMenuItems.length && a.default.show({
      content: "该菜品已售罄~",
      duration: 1e3
    })
  }
  var C, k = (null == e ? void 0 : e.skuMenuItems.find((function(e) {
    return e.skuId === c
  }))) || e.skuMenuItems[I];
  if (!k) return {};
  var S = function(e) {
      return e ? e.map((function(e) {
        var t = e.items,
          n = e.groupId,
          i = e.groupName,
          r = e.type,
          o = [];
        return t.forEach((function(e) {
          var t = e.defaultSelected,
            i = e.id,
            s = e.price,
            l = e.name,
            a = e.soldOut;
          if (t && !a) {
            var c = (0, g.dealDefaultMutex)(u, {
              groupId: n,
              type: r,
              id: i
            }, C);
            C = c.mutexMatrix, c.success && o.push({
              id: i,
              price: s,
              name: l,
              count: 1
            })
          }
        })), {
          groupId: n,
          groupName: i,
          items: o
        }
      })) : []
    },
    D = S(e.methods),
    O = S(e.tastes),
    P = f || 0,
    T = m || 0;
  if (!T && !P && !o) {
    var E, N = -1 === e.minBoughtCount ? e.incBoughtCount : e.minBoughtCount,
      _ = null == t ? void 0 : t[e.spuId.toString()];
    _ && (E = _.find((function(e) {
      return e.skuId === k.skuId
    }))), P = E ? e.incBoughtCount : N
  }
  return T && (P = 1), {
    skuName: k.skuName,
    memberPrice: k.memberPrice,
    extraPrice: 0,
    count: P,
    weight: T,
    skuId: k.skuId,
    spuId: e.spuId,
    methods: D,
    tastes: O,
    packages: []
  }
};
exports.getSelectedDishDataFromSimpleCartDish = function(e, t) {
  var u, i, r, o = n({}, t),
    s = null == e || null == (u = e.skuMenuItems) ? void 0 : u.find((function(e) {
      return e.skuId === o.skuId
    }));
  return s ? (o.memberPrice = s.memberPrice, null == (i = e.methods) || i.forEach((function(e) {
    var t = o.methods.find((function(t) {
      return t.groupId === e.groupId
    }));
    t && e.items.forEach((function(e) {
      var n = t.items.find((function(t) {
        return t.id === e.id
      }));
      n && (n.price = e.price)
    }))
  })), null == (r = e.tastes) || r.forEach((function(e) {
    var t = o.tastes.find((function(t) {
      return t.groupId === e.groupId
    }));
    t && e.items.forEach((function(e) {
      var n = t.items.find((function(t) {
        return t.id === e.id
      }));
      n && (n.price = e.price)
    }))
  })), o.remark = {
    customRemark: t.remark
  }, o) : null
};