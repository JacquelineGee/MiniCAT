var i = require("../../../@limo/container/behaviors/index");
Component({
  behaviors: [i.commonBehavior, i.limoShim],
  properties: {
    isPadding: {
      type: Boolean,
      value: !1
    },
    imageUrl: {
      type: String,
      value: ""
    },
    customClass: {
      type: String,
      value: ""
    }
  },
  data: {},
  attached: function() {
    this.limoAttached()
  },
  methods: {
    limoAttached: function() {},
    toThirdLogin: function() {
      this.triggerEvent("gotoThirdLogin")
    }
  }
});