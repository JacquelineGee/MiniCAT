var e = require("../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.convertYellowTextArrayToRichText = function(e) {
  var t;
  return null != (t = null == e ? void 0 : e.map((function(e) {
    return {
      type: Number.isNaN(Number(e)) ? u.RICH_ITEM_TEXT_TYPE.NORMAL : u.RICH_ITEM_TEXT_TYPE.IMPORTANT,
      text: e + ""
    }
  }))) ? t : []
}, exports.getYellowTextArray = function(e, u, o, i, l, s, f) {
  var d = [];
  u > 0 && d.push("已减 ".concat(u, " 元"));
  var h = l.nearestGap,
    p = s.nearestGap,
    T = f.nearestGap,
    I = s.currentAdditionSkuIds;
  if (I && I.length > 0) {
    var _ = s.currentAdditionCount || 1;
    d.push("".concat(d.length ? "" : "下单", "赠").concat(c(i, I, _)))
  }
  if (T > 0 && T <= e) {
    var m = f.nearestThresholdDiscount;
    d.push("再买 ".concat(T, " 元享 ").concat(m, " 折"))
  } else if (h > 0 && h <= e) {
    var O = l.nearestThresholdDiscount,
      v = l.currentThresholdDiscount || 0,
      E = l.repeatable ? O : (0, n.minusFloat)(O, v);
    d.push("再买 ".concat(h, " 元减 ").concat((0, n.plusFloat)(u, E), " 元"))
  } else if (p > 0 && p <= e) {
    var P = s.additionSkuIds,
      b = s.maxAdditionCount || 1;
    d.push("再买 ".concat(p, " 元赠").concat(c(i, P, b)))
  }
  var g, N, R, x = o ? o.find((function(e) {
      return e.type === r.SHOP_PROMOTION_TYPE.FULL_CUT
    })) : [],
    y = o ? o.find((function(e) {
      return e.type === r.SHOP_PROMOTION_TYPE.FULL_GIFT
    })) : [],
    C = o ? o.find((function(e) {
      return e.type === r.SHOP_PROMOTION_TYPE.FULL_DISCOUNT
    })) : [];
  return d.length || (C && (null == (g = a(C)) || g.forEach((function(e) {
    return d.push("满 ".concat(e.threshold, " 元享").concat(e.discountRate / 10, "折")), !0
  }))), x && (null == (N = a(x)) || N.forEach((function(e) {
    return t.default.getIn(x, ["rule", "repeatable"]) ? (d.push("每满 ".concat(e.full, " 元减 ").concat(e.reduceValue, " 元")), !1) : (d.push("满 ".concat(e.full, " 元减 ").concat(e.reduceValue, " 元")), !0)
  }))), y && (null == (R = a(y)) || R.forEach((function(e) {
    return t.default.getIn(y, ["rule", "repeatable"]) ? (d.push("每满 ".concat(e.full, " 元赠").concat(c(i, e.freeSkuIdList, e.freeCount || 1))), !1) : (d.push("满 ".concat(e.full, " 元赠").concat(c(i, e.freeSkuIdList, e.freeCount || 1))), !0)
  })))), d && d.length && d.join("，").split(" ") || []
};
var t = e(require("../miniprogram_npm/seamless-immutable/index.js")),
  n = require("../lib/number"),
  r = require("../constants/bizConstants"),
  u = require("../types/common/misc");

function c(e, t) {
  var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1;
  if (t && t.length > 1) return n + "份菜品";
  if (1 === t.length && e) {
    var r = "";
    return Object.keys(e).forEach((function(n) {
      return e[n].skuMenuItems.forEach((function(e) {
        return e.skuId === t[0] && (r = e.skuName), !r
      })), !r
    })), "".concat(n, "份").concat(r || "菜品")
  }
  return ""
}

function a(e) {
  return e ? t.default.getIn(e, ["rule", "rules"]) || [] : [(0, t.default)([])]
}