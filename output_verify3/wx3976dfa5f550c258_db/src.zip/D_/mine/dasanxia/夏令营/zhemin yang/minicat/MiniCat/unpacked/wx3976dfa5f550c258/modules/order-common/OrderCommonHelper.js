var e = require("../../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.fetchUrgeOrder = exports.fetchInvoice = void 0;
var t = e(require("../../b/regenerator")),
  r = require("../../b/helpers/asyncToGenerator"),
  n = e(require("../../miniprogram_npm/@limo/core/index.js")),
  a = require("../../constants/orderConstants"),
  u = require("../../constants/invoice"),
  c = require("../../constants/ajaxResCode"),
  i = e(require("../../api/order")),
  s = e(require("../../lib/mix/toast")),
  o = e(require("../../lib/mix/loading")),
  E = e(require("../../lib/mix/log")),
  d = require("../LXHelper"),
  p = require("../../lib/env"),
  f = require("../../lib/navigator"),
  l = (require("../../lib/number"), require("../../constants/bizConstants"), require("../coupon/util"), s.default),
  b = E.default,
  I = function() {
    var e = r(t.default.mark((function e(r, n, a) {
      var u;
      return t.default.wrap((function(e) {
        for (;;) switch (e.prev = e.next) {
          case 0:
            if (!(Date.now() - n < 1e4)) {
              e.next = 2;
              break
            }
            return e.abrupt("return", void l.show("操作过于频繁，请稍后重试"));
          case 2:
            return o.default.show(), u = {}, e.prev = 4, e.next = 7, i.default.urgeOrder({
              orderViewId: r
            });
          case 7:
            if (e.t0 = e.sent, e.t0) {
              e.next = 10;
              break
            }
            e.t0 = {};
          case 10:
            u = e.t0, e.next = 16;
            break;
          case 13:
            e.prev = 13, e.t1 = e.catch(4), b.addError("催单异常", e.t1);
          case 16:
            o.default.close(), u.code === c.RES_CODE.SUCCESS ? (l.show({
              content: u.msg || "催单成功"
            }), a && a()) : l.show({
              content: u.msg || "网络出错，请重试～"
            });
          case 17:
          case "end":
            return e.stop()
        }
      }), e, null, [
        [4, 13]
      ])
    })));
    return function(t, r, n) {
      return e.apply(this, arguments)
    }
  }();
exports.fetchUrgeOrder = I;
var T = function(e) {
    e ? ((0, d.sendMV)("b_saaspay_4h8qt288_mv"), p.isNativeMp ? (0, f.mixNavigateToByName)("webview", {
      url: e,
      webviewType: "URL_DIRECT"
    }, !0) : window.location.href = e) : l.show({
      content: "无法获取开票地址~"
    })
  },
  x = function() {
    var e = r(t.default.mark((function e(r, n) {
      var s, E, d, p, f, I, x, R, _;
      return t.default.wrap((function(e) {
        for (;;) switch (e.prev = e.next) {
          case 0:
            if (s = r.invoiceStatus, E = r.orderViewId, d = r.shopId, p = r.type, s) {
              e.next = 3;
              break
            }
            return e.abrupt("return");
          case 3:
            if (f = s.expireTime, I = s.url, (x = s.status) !== u.INVOICE_STATUS.ENABLE && x !== u.INVOICE_STATUS.INVOICE_PREPARE && x !== u.INVOICE_STATUS.INVOICE_WAITING) {
              e.next = 28;
              break
            }
            R = {
              orderViewId: E,
              mtShopId: d
            }, f && (R.expireTime = f), I && (R.url = I), n && (R.amount = n), o.default.show(""), e.prev = 7, e.t0 = p, e.next = e.t0 === a.ORDER_TYPE.ZT || e.t0 === a.ORDER_TYPE.WM || e.t0 === a.ORDER_TYPE.SC || e.t0 === a.ORDER_TYPE.JH ? 11 : e.t0 === a.ORDER_TYPE.TAKEAWAY || e.t0 === a.ORDER_TYPE.SELF_PICKUP ? 15 : 19;
            break;
          case 11:
            return e.next = 13, i.default.invoiceWriteSubtype(a.ORDER_BIZ_TYPE_KEY[p], R);
          case 13:
            return _ = e.sent, e.abrupt("break", 22);
          case 15:
            return e.next = 17, i.default.invoiceWriteTakeAway(R);
          case 17:
            return _ = e.sent, e.abrupt("break", 22);
          case 19:
            return e.next = 21, i.default.invoiceWrite(R);
          case 21:
            _ = e.sent;
          case 22:
            e.next = 27;
            break;
          case 24:
            e.prev = 24, e.t1 = e.catch(7), b.addError("开发票异常", e.t1);
          case 27:
            o.default.close(), _ && _.data && _.code === c.RES_CODE.SUCCESS ? T(_.data.url) : l.show({
              content: _ && _.msg || "开票接口请求失败~"
            });
          case 28:
          case "end":
            return e.stop()
        }
      }), e, null, [
        [7, 24]
      ])
    })));
    return function(t, r) {
      return e.apply(this, arguments)
    }
  }(),
  R = function() {
    var e = r(t.default.mark((function e(s, E) {
      var d, p, I, R, _, v, O, S, m, h, w, C, P, k, A, D;
      return t.default.wrap((function(e) {
        for (;;) switch (e.prev = e.next) {
          case 0:
            if (d = s.orderViewId, p = s.type, I = s.invoiceStatus, R = s.shopId, I) {
              e.next = 3;
              break
            }
            return e.abrupt("return", void l.show({
              content: "未获取到发票状态"
            }));
          case 3:
            if (_ = I.status, v = I.invoiceType, O = I.expireTime, S = I.url, m = I.applySource, o.default.show(""), _ !== u.INVOICE_STATUS.ENABLE && _ !== u.INVOICE_STATUS.INVOICE_PREPARE) {
              e.next = 31;
              break
            }
            if (5 !== m || _ !== u.INVOICE_STATUS.ENABLE) {
              e.next = 7;
              break
            }
            return e.abrupt("return", (E && E("ui-confirm", {
              body: "商户正在为您手工开票，如果疑问请联系商户",
              buttons: [{
                text: "知道了",
                type: "submit"
              }]
            }), void o.default.close()));
          case 7:
            h = {
              orderViewId: d,
              mtShopId: R
            }, e.prev = 8, e.t0 = p, e.next = e.t0 === a.ORDER_TYPE.ZT || e.t0 === a.ORDER_TYPE.WM || e.t0 === a.ORDER_TYPE.SC || e.t0 === a.ORDER_TYPE.JH ? 12 : e.t0 === a.ORDER_TYPE.TAKEAWAY || e.t0 === a.ORDER_TYPE.SELF_PICKUP ? 16 : 20;
            break;
          case 12:
            return e.next = 14,
              function() {
                var e = r(t.default.mark((function e(r, a, u) {
                  var c, s, o;
                  return t.default.wrap((function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return c = n.default.getLimoRuntime().getExtConfigSync() || {}, s = c.tenantId, o = Object.assign(a, {
                          tenantId: s || "",
                          poiId: u
                        }), e.next = 3, i.default.calculateSubtype(r, o);
                      case 3:
                        return e.abrupt("return", e.sent);
                      case 4:
                      case "end":
                        return e.stop()
                    }
                  }), e)
                })));
                return function(t, r, n) {
                  return e.apply(this, arguments)
                }
              }()(a.ORDER_BIZ_TYPE_KEY[p], h, R);
          case 14:
            return w = e.sent, e.abrupt("break", 23);
          case 16:
            return e.next = 18, i.default.calculateTakeAway(h);
          case 18:
            return w = e.sent, e.abrupt("break", 23);
          case 20:
            return e.next = 22, i.default.calculate(h);
          case 22:
            w = e.sent;
          case 23:
            e.next = 28;
            break;
          case 25:
            e.prev = 25, e.t1 = e.catch(8), b.addError("获取发票金额异常", e.t1);
          case 28:
            w && w.code === c.RES_CODE.SUCCESS ? (C = w.data.amount) ? (N = C, P = (y = p) === a.ORDER_TYPE.ZT || y === a.ORDER_TYPE.WM || y === a.ORDER_TYPE.SC || y === a.ORDER_TYPE.JH ? N : Number(N / 100).toFixed(2), E && E("invoice-confirm", {
              amount: P,
              buttons: [{
                text: "取消",
                type: "cancel"
              }, {
                text: "确定",
                type: "submit",
                callback: function() {
                  var e = r(t.default.mark((function e() {
                    return t.default.wrap((function(e) {
                      for (;;) switch (e.prev = e.next) {
                        case 0:
                          return e.next = 2, x(s, C);
                        case 2:
                        case "end":
                          return e.stop()
                      }
                    }), e)
                  })));
                  return function() {
                    return e.apply(this, arguments)
                  }
                }()
              }]
            })) : l.show({
              content: "未获取发票金额"
            }) : (k = w && w.msg || "获取发票金额接口请求失败~", A = w && w.code, E && E("ui-confirm", {
              body: k,
              buttons: [{
                text: "知道了",
                type: "submit",
                callback: function() {
                  var e = r(t.default.mark((function e() {
                    return t.default.wrap((function(e) {
                      for (;;) switch (e.prev = e.next) {
                        case 0:
                          -2 !== A && -4 !== A || (0, f.mixReload)();
                        case 1:
                        case "end":
                          return e.stop()
                      }
                    }), e)
                  })));
                  return function() {
                    return e.apply(this, arguments)
                  }
                }()
              }]
            })), e.next = 42;
            break;
          case 31:
            if (_ !== u.INVOICE_STATUS.INVOICE_WAITING) {
              e.next = 41;
              break
            }
            if (D = Date.now(), !(O && O < D)) {
              e.next = 38;
              break
            }
            return e.next = 36, x(s);
          case 36:
            e.next = 39;
            break;
          case 38:
            T(S);
          case 39:
            e.next = 42;
            break;
          case 41:
            _ === u.INVOICE_STATUS.COMPLETED && v === u.INVOICE_TYPE.PAPER_INVOICE ? l.show({
              content: "已线下开具纸质发票~"
            }) : _ !== u.INVOICE_STATUS.COMPLETED && _ !== u.INVOICE_STATUS.INVOICE_FAILURE || T(S);
          case 42:
            o.default.close();
          case 43:
          case "end":
            return e.stop()
        }
        var y, N
      }), e, null, [
        [8, 25]
      ])
    })));
    return function(t, r) {
      return e.apply(this, arguments)
    }
  }();
exports.fetchInvoice = R;