var e = require("../../../miniprogram_npm/@limo/container/behaviors/index");
Component({
  behaviors: [e.commonBehavior, e.limoShim],
  properties: {
    showTotalPrice: {
      type: Boolean,
      value: !0
    },
    cartPriceInfo: {
      type: Object,
      value: {}
    },
    deliveryFee: {
      type: Number,
      value: 0
    },
    userSelectedAddress: {
      type: Object,
      value: {},
      observer: function(e) {
        e && Object.keys(e).length && this.setData({
          addressTextShow: !!e.id
        })
      }
    },
    bizType: {
      type: Number,
      value: 0
    }
  },
  data: {
    addressTextShow: !1,
    bizTypeTakeaway: 3
  },
  observers: {},
  methods: {
    toggleCartPanel: function() {
      this.triggerEvent("toggle")
    }
  }
});