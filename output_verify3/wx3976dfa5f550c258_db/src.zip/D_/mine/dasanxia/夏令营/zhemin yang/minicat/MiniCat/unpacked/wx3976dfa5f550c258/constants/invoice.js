Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.INVOICE_TYPE = exports.INVOICE_STATUS = void 0;
exports.INVOICE_STATUS = {
  EXPIRE: -3,
  NONE: -2,
  DISABLE: 1,
  ENABLE: 2,
  INVOICE_PREPARE: 3,
  INVOICE_WAITING: 4,
  COMPLETED: 5,
  INVOICE_FAILURE: 6
};
exports.INVOICE_TYPE = {
  PAPER_INVOICE: 1,
  ELECTRONIC_INVOICE: 2
};