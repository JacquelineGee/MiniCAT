var e = require("../../../b/helpers/interopRequireDefault"),
  t = require("../../../miniprogram_npm/@limo/container/behaviors/index"),
  i = require("../../../modules/LXHelper"),
  s = require("../../../modules/menu/dish/expose"),
  r = e(require("../../../lib/mix/confirm")),
  a = require("../../../store/actions/cart"),
  n = require("../../../store/cart/PointPurchaseService"),
  o = e(require("../../../modules/menu/cart/cartSdk")),
  u = require("../../../constants/bizConstants"),
  c = require("../../../constants/lxConstants"),
  d = require("../../../store/actions/newCart"),
  l = e(require("../../../store/menu")),
  h = e(require("../../../store/helpers/storeBehavior")),
  m = require("../../../constants/menu");
Component({
  behaviors: [h.default, t.commonBehavior, t.limoShim],
  options: {
    addGlobalClass: !0
  },
  properties: {
    newCartDishList: {
      type: Array
    },
    avatarPicsData: {
      type: Array
    },
    isShowBigBtn: {
      type: Boolean,
      value: !1
    },
    customClass: {
      type: String,
      value: ""
    },
    needBuyFreeBtn: {
      type: Boolean,
      value: !0
    }
  },
  created: function() {
    this.store = l.default
  },
  methods: {
    limoReady: function() {
      this.helpersStoreBehavior_limoReady()
    },
    mapToState: function(e) {
      return {
        miniCartVisible: e.cart && e.cart.miniCartVisible,
        cartDiscountData: e.cart && e.cart.cartDiscountData
      }
    },
    addDish: function(e) {
      e.detail.discount === m.POINT_DISH_TYPE ? this.store.dispatch(n.PointPurchase.addDish(e.detail)) : this.store.dispatch((0, d.transOriginCartFromSimple)(e.detail, a.addDish))
    },
    minusDish: function(e) {
      this.store.dispatch((0, d.transOriginCartFromSimple)(e.detail, a.minusDish))
    },
    closeCartPanel: function() {
      this.store.dispatch((0, a.closeCartPanel)())
    },
    editWeightSkuDish: function(e) {
      this.store.dispatch((0, d.transOriginCartFromSimple)(e.detail, a.editWeightSkuDish))
    },
    showCalcPanel: function(e) {
      this.store.dispatch((0, d.transOriginCartFromSimple)(e.detail, a.showCalcPanel))
    },
    editSkuDish: function(e) {
      this.store.dispatch((0, d.transOriginCartFromSimple)(e.detail, a.editSkuDish)), (0, i.sendMC)("b_saaspay_qiyfkbpy_mc")
    },
    clearCart: function() {
      var e, t = this;
      e = function() {
        t.store.dispatch(o.default.clearCart()), (0, i.sendMC)("b_saaspay_lxmzp99s_mc")
      }, (0, r.default)({
        body: "确认清空已选菜品吗？",
        buttons: [{
          text: "取消",
          type: "cancel"
        }, {
          text: "确定",
          type: "submit",
          callback: function() {
            e && e()
          }
        }]
      })
    },
    exposeDish: function(e) {
      var t = e.currentTarget.dataset,
        i = t.dish,
        r = t.index;
      i && ((0, s.appendExposeDishItem)(s.EXPOSE_DISH_TYPE.CART, {
        item: i,
        index: r
      }), (0, s.exposeDishItemNew)({
        op_type: c.OP_TYPE.CART,
        op_name: c.OP_NAME.OTHER,
        sn: r,
        dish_details_func_area: u.DISH_DETAIL.MAIN_DISH,
        algorithm: "",
        show_title: u.TITLE_CONTENT.CART,
        sku_id_list: i.skuId,
        spu_id_list: i.spuId,
        dish_name_list: i.skuName,
        dish_type: ""
      }))
    },
    checkedBuyFree: function(e) {
      this.triggerEvent("checkedBuyFree", e.detail)
    }
  },
  ready: function() {
    this.limoReady()
  }
});