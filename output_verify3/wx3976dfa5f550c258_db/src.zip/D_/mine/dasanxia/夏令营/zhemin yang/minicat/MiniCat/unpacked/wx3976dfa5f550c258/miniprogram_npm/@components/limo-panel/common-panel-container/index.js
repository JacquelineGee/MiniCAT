var e = require("../../../../b/helpers/interopRequireDefault"),
  i = require("../../../@limo/container/behaviors/index"),
  t = e(require("../panel-behaviors/panelBehavior"));
Component({
  behaviors: [t.default, i.commonBehavior, i.limoShim],
  properties: {},
  data: {},
  methods: {
    limoAttached: function() {
      this.panelBehaviorsPanelBehavior_limoAttached()
    },
    prevent: function() {}
  },
  attached: function() {
    this.limoAttached()
  }
});