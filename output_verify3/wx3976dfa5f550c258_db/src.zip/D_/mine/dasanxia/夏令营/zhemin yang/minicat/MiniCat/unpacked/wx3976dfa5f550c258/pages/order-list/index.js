var e = require("../../b/helpers/interopRequireDefault"),
  t = e(require("../../b/regenerator")),
  i = require("../../b/helpers/asyncToGenerator"),
  a = e(require("../../miniprogram_npm/@limo/core/index.js")),
  r = require("../../lib/wx/page"),
  n = require("../../miniprogram_npm/@mtfe/rms-sdk/index.js"),
  o = require("../../lib/wx/plugin/default"),
  s = require("../../lib/wx/util"),
  u = e(require("./model/MpPageViewModel")),
  d = require("../../modules/LXHelper");
(0, r.ProxyPage)({
  pageViewModel: u.default,
  data: {
    renderData: {
      modules: []
    }
  },
  isHide: !1,
  onLoad: function(e) {
    this.__limoCore = a.default.LimoCoreFactory(), (0, r.initPageOnLoad)(), e = (0, s.getTabbarPageOptions)(e, this.route), this.options = e, this.initData({
      urlParams: e
    }), n.LazyLoad.reportComponentMountedTotal(["tab-bar"])
  },
  onShow: function() {
    (0, d.sendPV)("c_saaspay_954q9pjb"), this.isHide && this.pageViewModel.resetPage()
  },
  onHide: function() {
    this.isHide = !0
  },
  initData: function(e) {
    var t = e.urlParams;
    this.pageViewModel = new u.default({
      pageInstance: this,
      Limo: a.default.getLimoRuntime(),
      options: t
    }), this.pageViewModel.pageLoad()
  },
  renderPage: function(e) {
    var a = this;
    return i(t.default.mark((function r() {
      return t.default.wrap((function(r) {
        for (;;) switch (r.prev = r.next) {
          case 0:
            if (r.t0 = e, !r.t0) {
              r.next = 4;
              break
            }
            return r.next = 4, (0, n.transaction)("ORDER_LIST.SET_DATA_RATE", function() {
              var r = i(t.default.mark((function i(r) {
                return t.default.wrap((function(t) {
                  for (;;) switch (t.prev = t.next) {
                    case 0:
                      a.setData({
                        renderData: e
                      }, (function() {
                        a.loadSuccess(), r.success()
                      }));
                    case 1:
                    case "end":
                      return t.stop()
                  }
                }), i)
              })));
              return function(e) {
                return r.apply(this, arguments)
              }
            }(), !0);
          case 4:
          case "end":
            return r.stop()
        }
      }), r)
    })))()
  },
  tabBarRenderEvent: function(e) {
    this.pageViewModel.tabBarRenderCallback(e.detail), a.default.getLimoRuntime().hideHomeButton({
      success: function() {},
      fail: function() {}
    })
  },
  requestList: function() {
    this.pageViewModel.onReachBottom()
  },
  btnClick: function(e) {
    this.pageViewModel.btnClick(e.detail)
  },
  refreshPage: function() {
    this.pageViewModel.resetPage()
  }
}, o.plugins);