var e = require("../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.default = void 0;
var t = e(require("../lib/mix/request")),
  r = require("../lib/mix/util"),
  a = {
    getCloudData: function(e) {
      return t.default.post("/cart/getCartInfo", e, {
        timeout: 8e3,
        openShark: !0
      })
    },
    checkDish: function(e) {
      var a = (0, r.getHost)() + "/diancan/api/";
      return (0, r.isUnitePage)() && (a = (0, r.getTakeAwayHost)() + "/api/rmstakeaway/"), t.default.post(a + "checkDish", e, {
        openShark: !0
      })
    },
    checkCartId: function(e) {
      return t.default.get("/cart/checkCartId", {
        params: e,
        openShark: !0
      })
    }
  };
exports.default = a;