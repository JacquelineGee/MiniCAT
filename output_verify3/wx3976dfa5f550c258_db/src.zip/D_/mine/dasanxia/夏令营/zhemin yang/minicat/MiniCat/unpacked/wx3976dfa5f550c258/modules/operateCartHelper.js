var e = require("../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.addCloudCartFields = m, exports.getUniqueKey = f, exports.initPackageGroups = h, exports.isValidDish = function(e, t) {
  var u = function(e, u, r) {
      if (!e || !u) return !1;
      var n = e.skuId,
        a = e.methods,
        i = e.tastes,
        o = e.number,
        s = u.skuId,
        d = u.number,
        l = r ? u.methods : t.methods,
        c = r ? u.tastes : t.tastes;
      return n === s && (!r || o === d) && (a || []).every((function(e) {
        return (l || []).find((function(t) {
          return t.id === e.id
        }))
      })) && (i || []).every((function(e) {
        return (c || []).find((function(t) {
          return t.id === e.id
        }))
      }))
    },
    r = e.skuId,
    n = t.skuMenuItems.find((function(e) {
      return e.skuId === r
    }));
  if (!n) return !1;
  if (t.dishType === a.DISH_TYPE.NORMAL) return u(e, n);
  var i = e.packages,
    o = n.packageGroups,
    s = i.find((function(e) {
      var t = o.find((function(t) {
        return t.groupId === e.groupId
      }));
      return !t || e.groupSkus.find((function(e) {
        var r = t.groupSkus.find((function(t) {
          return t.skuId === e.skuId
        }));
        return !u(e, r, !0)
      }))
    }));
  return u(e, n) && !s
}, exports.transToCartDish = function(e, u) {
  var n, o = e.spuId,
    d = e.skuId,
    l = (null == u || null == (n = u.skuMenuItems) ? void 0 : n.find((function(e) {
      return e.skuId + "" == d + ""
    }))) || {},
    c = (0, r.default)({
      spuId: o,
      skuId: d,
      skuName: e.skuName,
      hiddenDish: (null == u ? void 0 : u.hiddenDish) || !1,
      canWeight: "boolean" == typeof e.canWeight ? e.canWeight : e.weight > 0,
      weight: e.weight || null,
      count: e.count,
      manualCampaigns: e.manualCampaigns,
      specAttrs: l.specAttrs || null,
      remark: r.default.getIn(e, ["remark", "customRemark"]) || null,
      mustCount: e.mustCount,
      createTime: e.createTime,
      recommendType: e.recommendType || null,
      categoryId: r.default.getIn(u, ["parentCategoryId", 0]),
      unit: l.unit,
      dishType: l.dishType,
      currentPrice: l.currentPrice,
      originalPrice: l.originalPrice,
      memberPrice: l.memberPrice,
      soldOut: l.soldOut,
      validity: l.validity,
      stockCount: l.stockCount,
      saleTimeDesc: l.saleTimeDesc,
      showRemark: l.showRemark,
      promotionTag: l.promotionTag,
      promotionRule: l.promotionRule,
      tagList: l.tagList,
      defaultSelected: l.defaultSelected,
      packageGroups: l.packageGroups,
      includeMethodPrice: l.includeMethodPrice,
      includeTastePrice: l.includeTastePrice,
      dishBoxVO: l.dishBoxVO,
      minFeeding: l.minFeeding,
      maxFeeding: l.maxFeeding,
      allowManualDiscount: l.allowManualDiscount,
      discount: e.discount
    }),
    p = l.dishType;
  if (p === a.DISH_TYPE.NORMAL) {
    var g = v(e, u),
      m = P(e, u);
    c = r.default.merge(c, {
      methods: g,
      tastes: m
    }), c = (0, s.computeAddPrice)(c)
  } else if (p === a.DISH_TYPE.PACKAGE) {
    var I = function(e, u) {
      var n = e.packages,
        o = u.packageGroups,
        s = h(o, a.INIT_PACKAGE.RECOVER),
        d = s;
      return s.map((function(e, u) {
        var s = n.find((function(t) {
          return t.groupId === e.groupId
        }));
        return s ? (s.groupSkus.map((function(n) {
          var s = r.default.getIn(d, [u, "groupSkus"]),
            l = e.groupSkus.find((function(e) {
              return e.skuId === n.skuId
            })),
            c = r.default.getIn(o, [u, "groupSkus"]).find((function(e) {
              return e.skuId === n.skuId
            }));
          if (l) {
            var p = n.sum,
              g = n.count,
              m = l.number,
              h = p || g;
            if (h % m != 0) return null;
            var I = (0, r.default)({
                spuId: n.spuId,
                skuId: n.skuId,
                skuName: n.skuName,
                number: l.number,
                unit: l.unit,
                count: h / m,
                extraPrice: l.extraPrice,
                addPrice: l.addPrice || 0,
                defaultSelected: l.defaultSelected,
                dishType: l.dishType || a.DISH_TYPE.NORMAL,
                canWeight: l.canWeight,
                weight: l.weight,
                offShelf: l.offShelf,
                required: l.required,
                soldOut: l.soldOut,
                groupId: l.groupId,
                groupType: l.groupType,
                groupChoiceType: l.groupChoiceType,
                specAttrs: l.specAttrs,
                parentCategoryId: l.parentCategoryId,
                parentBaseCategoryId: l.parentBaseCategoryId,
                methods: v(n, c),
                tastes: P(n, c),
                allowManualDiscount: l.allowManualDiscount
              }),
              k = f(I);
            I = r.default.set(I, "goodsNo", k);
            var y = i.default.findLastIndex(s, (function(e) {
              return e.skuId === I.skuId
            }));
            s = s[y].init ? r.default.set(s, y, I) : (0, r.default)([].concat(t(s.slice(0, y + 1)), [I], t(s.slice(y + 1)))), d = r.default.setIn(d, [u, "groupSkus"], s)
          }
          return null
        })), null) : (0 === e.groupLimit && (d = r.default.set(d, u, e)), null)
      })), d
    }(e, l);
    c = r.default.merge(c, {
      methods: e.methods,
      tastes: e.tastes,
      includeMethodPrice: l.includeMethodPrice,
      includeTastePrice: l.includeTastePrice,
      packageGroups: I
    }), c = (0, s.computePackageAddPrice)(c)
  }
  return c
}, exports.transToCloudCartDishList = function(e, t, u) {
  var n = (0, r.default)([]),
    a = {};
  return t.forEach((function(t) {
    var r = t.spuId,
      i = u[r],
      o = e[r];
    if (o) {
      var s = o.find((function(e) {
        return e.goodsNo === t.goodsNo
      }));
      if (s) {
        var d = C(s, i);
        return void(n = n.concat([d]))
      }
    }
    a[t.goodsNo] = {
      menuSpu: i,
      cartSpu: o
    }
  })), Object.keys(a).length > 0 && o.default.sendInfo({
    name: "[CloudCartTransform]",
    content: {
      cartDishList: e,
      cartDishSortMapList: t,
      cloudCartDishList: n,
      filterDishes: a
    }
  }), n
}, exports.transToSkuDish = function(e) {
  var t, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
    a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "",
    i = arguments.length > 3 ? arguments[3] : void 0,
    d = null == e ? void 0 : e.spuId,
    l = (null == e || null == (t = e.skuMenuItems) ? void 0 : t.find((function(e) {
      return e.skuId === a
    }))) || r.default.getIn(e, ["skuMenuItems", 0]) || {};
  (0, s.judgeFixedPackage)(e) && (l = function(e) {
    if (!e.packageGroups) return e;
    try {
      var t = e.packageGroups.map((function(e) {
        var t = e.groupSkus.map((function(e) {
          return u(u({}, e), {}, {
            number: e.count
          })
        }));
        return u(u({}, e), {}, {
          groupSkus: t
        })
      }));
      return u(u({}, e), {}, {
        packageGroups: t
      })
    } catch (t) {
      return o.default.addError("transFixedPackageSkuDish", t), e
    }
  }(l));
  var c, m = r.default.merge(l, {
      __newReportConfig__: null == e ? void 0 : e.__newReportConfig__
    }) || {},
    h = n && n[d.toString()],
    I = i ? f(l, {
      discount: p.POINT_DISH_TYPE
    }) : f(l);
  return Array.isArray(h) && (c = h.find((function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return e.goodsNo === I
  }))) || (c = g(m, e, i)), c
};
var t = require("../b/helpers/toConsumableArray"),
  u = require("../b/helpers/objectSpread2"),
  r = e(require("../miniprogram_npm/seamless-immutable/index.js")),
  n = e(require("../miniprogram_npm/@dp/md5/index.js")),
  a = require("../constants/bizConstants"),
  i = e(require("../miniprogram_npm/@mtfe/rms-triangle-c/index.js")),
  o = e(require("../lib/mix/log")),
  s = require("./cartHelper"),
  d = require("./menu/dish/DishSdk"),
  l = require("../lib/mix/util"),
  c = require("./campaign"),
  p = require("../constants/menu");

function f(e, t) {
  var i, o, s, d, l = r.default.asMutable(e, {
    deep: !0
  });
  switch (l.dishType) {
    case a.DISH_TYPE.NORMAL:
      var p = [],
        f = [];
      (null == l || null == (i = l.methods) ? void 0 : i.length) > 0 && l.methods.forEach((function(e) {
        e.sort && (null == e || e.sort((function(e, t) {
          return e.id - t.id
        })));
        var t = [];
        e.forEach && (null == e || e.forEach((function(e) {
          t.push(e.id)
        }))), p.push(t)
      })), (null == l || null == (o = l.tastes) ? void 0 : o.length) > 0 && l.tastes.forEach((function(e) {
        e.sort && (null == e || e.sort((function(e, t) {
          return e.id - t.id
        })));
        var t = [];
        e.forEach && (null == e || e.forEach((function(e) {
          t.push({
            id: e.id,
            count: e.count
          })
        }))), f.push(t)
      })), d = u({
        skuId: l.skuId,
        methods: p,
        tastes: f
      }, t), l.remark && (d.remark = l.remark), null != (s = l.manualCampaigns) && s.length && (d.manualCampaigns = (0, c.transManualCampaignsToSimple)(l.manualCampaigns));
      break;
    case a.DISH_TYPE.PACKAGE:
      var g = [];
      l.packageGroups.forEach((function(e) {
        e.groupSkus.forEach((function(t) {
          var u, r, n = [],
            a = [];
          (null == t || null == (u = t.methods) ? void 0 : u.length) > 0 && t.methods.forEach((function(e) {
            e.sort && (null == e || e.sort((function(e, t) {
              return e.id - t.id
            })));
            var t = [];
            e.forEach && (null == e || e.forEach((function(e) {
              t.push(e.id)
            }))), n.push(t)
          })), (null == t || null == (r = t.tastes) ? void 0 : r.length) > 0 && t.tastes.forEach((function(e) {
            e.sort && (null == e || e.sort((function(e, t) {
              return e.id - t.id
            })));
            var t = [];
            e.forEach && (null == e || e.forEach((function(e) {
              t.push({
                id: e.id,
                count: e.count
              })
            }))), a.push(t)
          }));
          var i = {
            groupId: e.groupId,
            skuId: t.skuId,
            number: t.number,
            count: t.count,
            methods: n,
            tastes: a
          };
          g.push(i)
        }))
      })), d = l.remark ? u({
        skuId: l.skuId,
        packages: g,
        remark: l.remark
      }, t) : u({
        skuId: l.skuId,
        packages: g
      }, t)
  }
  return (0, n.default)(JSON.stringify(d))
}

function g(e, t, u) {
  var n = r.default.merge(e, {
      count: 0,
      categoryId: r.default.getIn(t, ["parentCategoryId", 0]),
      methods: (0, r.default)([]),
      tastes: (0, r.default)([])
    }),
    a = u ? f(n, {
      discount: p.POINT_DISH_TYPE
    }) : f(n);
  return n = r.default.set(n, "goodsNo", a)
}

function m(e) {
  var t = e || {};
  return r.default.merge(t, {
    weight: t.weight || null,
    remark: t.remark || null,
    mustCount: void 0 !== t.mustCount ? t.mustCount : -1,
    recommendType: t.recommendType || null,
    extraPrice: t.extraPrice || 0,
    userAvatars: t.userAvatars || null,
    manualCampaigns: t.manualCampaigns || null
  })
}

function h(e, t) {
  var u = (0, r.default)([]);
  return e && e.map((function(e) {
    var n = (0, r.default)([]),
      i = e.groupId,
      o = e.groupType,
      d = e.groupChoiceType;
    e.groupSkus.map((function(e) {
      var u = (0, s.setCartSkuAttrs)(e),
        l = u.newMethods,
        c = u.newTastes,
        p = 0,
        g = -1 === e.stockCount ? 1 / 0 : e.stockCount;
      !e.soldOut && g >= e.count && (o === a.GROUP_TYPE.FIXED || e.defaultSelected && t === a.INIT_PACKAGE.ADD) && (p = 1);
      var m = r.default.merge(e, {
          groupId: i,
          groupType: o,
          groupChoiceType: d,
          methods: l,
          tastes: c,
          number: e.count,
          count: p,
          init: !0
        }),
        h = f(m = (0, s.computeAddPrice)(m));
      return m = r.default.set(m, "goodsNo", h), n = n.concat([m]), null
    }));
    var l = r.default.set(e, "groupSkus", n);
    return u = u.concat([l]), null
  })), u
}

function I(e) {
  var t = e.methods;
  if (!(0, s.judgeFeedingExist)(t)) return null;
  var u = (0, r.default)([]);
  return t.map((function(e) {
    if ((null == e ? void 0 : e.length) > 0) {
      var t = (0, r.default)({
          groupId: r.default.getIn(e, [0, "groupId"]),
          groupName: r.default.getIn(e, [0, "groupName"])
        }),
        n = (0, r.default)([]);
      e.map((function(e) {
        return n = n.concat([{
          id: e.id,
          name: e.name,
          count: 1,
          unitPrice: e.price,
          unitOrgPrice: void 0 !== e.unitOrgPrice ? e.unitOrgPrice : e.price,
          priceType: e.priceType
        }]), null
      })), t = r.default.set(t, "items", n), u = u.concat([t])
    }
    return null
  })), u
}

function k(e) {
  var t = e.tastes;
  if (!(0, s.judgeFeedingExist)(t)) return null;
  var u = (0, r.default)([]);
  return t.map((function(t) {
    if (t.length > 0) {
      var n = (0, r.default)({
          groupId: r.default.getIn(t, [0, "groupId"]),
          groupName: r.default.getIn(t, [0, "groupName"])
        }),
        a = (0, r.default)([]);
      t.map((function(t) {
        return a = a.concat([{
          id: t.id,
          name: t.name,
          count: t.count,
          unitPrice: t.price,
          totalPrice: e.totalPrice,
          spuId: t.spuId,
          skuId: t.skuId,
          cateId: t.parentBaseCategoryId,
          parentCategoryId: t.parentBaseCategoryId,
          allowManualDiscount: t.allowManualDiscount
        }]), null
      })), n = r.default.set(n, "items", a), u = u.concat([n])
    }
    return null
  })), u
}

function v(e, t) {
  var u = e.methods,
    n = t.methods,
    a = (0, r.default)([]);
  return n && 0 !== n.length ? (a = (0, r.default)(Array.from({
    length: n.length
  }, (function() {
    return []
  }))), u && u.length > 0 && u.map((function(e) {
    var t = e.groupId,
      u = n.find((function(e) {
        return e.groupId === t
      }));
    if (!u) return null;
    var i = e.items;
    if (!i || 0 === i.length) return null;
    var o = (0, r.default)([]);
    i.map((function(n) {
      var a = u.items.find((function(e) {
        return e.id === n.id
      }));
      if (a) {
        var i = (0, r.default)({
          groupId: t,
          groupName: e.groupName,
          id: a.id,
          name: a.name,
          price: a.price,
          priceType: a.priceType,
          soldOut: a.soldOut,
          defaultSelected: a.defaultSelected
        });
        o = o.concat([i])
      }
      return null
    }));
    var s = n.findIndex((function(t) {
      return e.groupId === t.groupId
    }));
    return a = r.default.set(a, s, o), null
  })), a) : a
}

function P(e, t) {
  var u = e.tastes,
    n = t.tastes,
    a = (0, r.default)([]);
  return n && 0 !== n.length ? (a = (0, r.default)(Array.from({
    length: n.length
  }, (function() {
    return []
  }))), u && u.length > 0 && u.map((function(e) {
    var t = e.groupId,
      u = n.find((function(e) {
        return e.groupId === t
      }));
    if (!u) return null;
    var i = e.items;
    if (!i || 0 === i.length) return null;
    var o = (0, r.default)([]);
    i.map((function(n) {
      var a = u.items.find((function(e) {
        return e.id === n.id
      }));
      if (a) {
        var i = (0, r.default)({
          groupId: t,
          groupName: e.groupName,
          count: n.count,
          id: a.id,
          name: a.name,
          price: a.price,
          priceType: a.priceType,
          soldOut: a.soldOut,
          repeatable: a.repeatable,
          minBoughtCount: a.minBoughtCount,
          maxBoughtCount: a.maxBoughtCount,
          incBoughtCount: a.incBoughtCount,
          stockCount: a.stockCount,
          memberPrice: a.memberPrice,
          spuId: a.spuId,
          skuId: a.skuId,
          parentCategoryId: a.parentCategoryId,
          parentBaseCategoryId: a.parentBaseCategoryId,
          allowManualDiscount: a.allowManualDiscount
        });
        o = o.concat([i])
      }
      return null
    }));
    var s = n.findIndex((function(t) {
      return e.groupId === t.groupId
    }));
    return a = r.default.set(a, s, o), null
  })), a) : a
}

function y(e) {
  return e.remark ? (0, r.default)({
    customRemark: e.remark,
    opts: []
  }) : null
}

function C(e) {
  var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : (0, r.default)({}),
    u = (0, r.default)({
      cateId: t.parentBaseCategoryId && t.parentBaseCategoryId[0] || null,
      displayCategoryId: t.parentCategoryId && t.parentCategoryId[0] || null,
      skuImg: t.dishPicUrls && t.dishPicUrls[0] || null,
      unit: t.unit || "",
      skuId: e.skuId,
      spuId: e.spuId,
      skuName: e.skuName,
      dishType: e.dishType,
      canWeight: e.canWeight,
      weight: e.weight,
      unitBasePrice: e.originalPrice,
      unitRawPrice: e.originalPrice,
      unitPrice: e.unitPrice,
      totalPrice: e.totalPrice,
      boxInfoVO: e.boxInfoVO,
      memberPrice: e.memberPrice,
      count: e.count,
      itemNo: e.goodsNo,
      specAttrs: e.specAttrs,
      remark: y(e),
      extraPrice: e.extraPrice,
      mustCount: e.mustCount,
      initCount: e.initCount,
      createTime: e.createTime,
      recommendType: e.recommendType,
      categoryId: e.categoryId,
      allowManualDiscount: e.allowManualDiscount,
      manualCampaigns: T(e.manualCampaigns, e.count),
      discount: e.discount
    }),
    n = e.dishType;
  if (n === a.DISH_TYPE.NORMAL) {
    var i = I(e),
      o = k(e);
    u = r.default.merge(u, {
      methods: i,
      tastes: o
    })
  } else if (n === a.DISH_TYPE.PACKAGE) {
    var s = function(e) {
      var t = e.packageGroups,
        u = (0, r.default)([]);
      return t.map((function(t) {
        var n = (0, r.default)({
            groupId: t.groupId,
            groupName: t.groupName,
            groupType: t.groupType,
            groupChoiceType: t.groupChoiceType,
            groupLimit: t.groupLimit,
            optionType: t.optionType,
            lowerCount: t.lowerCount,
            upperCount: t.upperCount
          }),
          a = (0, r.default)([]);
        return t.groupSkus.map((function(t) {
          var u = (0, r.default)({
            spuId: t.spuId,
            skuId: t.skuId,
            skuName: t.skuName,
            unit: t.unit,
            number: t.number,
            count: t.number * t.count,
            specAttrs: t.specAttrs,
            dishType: t.dishType,
            addPrice: t.addPrice || 0,
            cateId: t.parentBaseCategoryId,
            canWeight: t.canWeight,
            weight: t.weight,
            unitBasePrice: null,
            methods: I(t),
            tastes: k(t),
            unitPrice: e.unitPrice,
            totalPrice: e.totalPrice,
            allowManualDiscount: t.allowManualDiscount
          });
          return u.count > 0 && (a = a.concat([u])), null
        })), n = r.default.set(n, "groupSkus", a), u = u.concat([n]), null
      })), u
    }(e);
    u = r.default.merge(u, {
      methods: e.methods,
      tastes: e.tastes,
      includeMethodPrice: e.includeMethodPrice,
      includeTastePrice: e.includeTastePrice,
      packages: s
    })
  }
  return u
}
var T = function(e, t) {
  if (Array.isArray(e)) {
    var n = (0, d.GetDishSdkSingleton)((0, l.getShopId)());
    return e.map((function(e) {
      var a = e.campaignSkus;
      return u(u({}, e), {}, {
        campaignSkus: null == a ? void 0 : a.map((function(e) {
          var u = e.spuId,
            a = e.skuId,
            i = n ? n.findOriginalSpuDetail(u) : {},
            o = n ? n.findOriginalSkuDetail(u, a) : {},
            s = r.default.merge(o, e);
          return s = m(s), C(s = r.default.set(s, "count", s.count * t), i)
        }))
      })
    }))
  }
};