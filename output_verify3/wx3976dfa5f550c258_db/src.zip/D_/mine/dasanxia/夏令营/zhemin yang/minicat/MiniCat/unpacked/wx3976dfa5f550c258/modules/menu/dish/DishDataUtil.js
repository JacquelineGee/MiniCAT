var e = require("../../../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.verifyLimitCountRuleInOperation = exports.getLimitCountData = exports.dealOperationCountStyle = void 0, exports.verifyMemberLogin = function() {
  var e = a.default.getShopServiceData().memberInfo || {},
    t = e.cardId,
    i = e.actionUrl;
  return !!t || ((0, l.default)({
    body: "请登录后再加购积分换购商品",
    buttons: [{
      text: d.CONFIRM_TEXT,
      type: "submit",
      callback: function() {
        /dish-detail/.test((0, r.getMixPathName)()) && s.default.setUseMenuCacheForNonMenuPage((0, r.getShopId)(), !1), m.default.navigateTo({
          url: i
        })
      }
    }]
  }), !1)
}, require("../../../b/helpers/Arrayincludes");
var t = require("../../../b/helpers/createForOfIteratorHelper"),
  i = require("../../../b/helpers/objectSpread2"),
  r = require("../../../lib/mix/util"),
  u = e(require("../cart/cartSdk")),
  n = require("./DishSdk"),
  o = require("../../dishHelper"),
  a = e(require("../shop/shopService")),
  s = e(require("../../../api/rmsStorage")),
  l = e(require("../../../lib/mix/confirm")),
  d = require("../../../constants/bizConstants"),
  m = e(require("../../../miniprogram_npm/@mtfe/rms-triangle-c/index.js")),
  p = function(e, t) {
    var i, r = u.default.getRefactorCartDishMap(),
      n = u.default.computeSkuDishCountInCart(t.spuId, t.skuId, r),
      o = t.limitCount,
      a = t.orderedCount,
      s = t.skuName,
      l = t.specAttrs,
      d = e.incBoughtCount,
      m = e.minBoughtCount,
      p = s;
    return Array.isArray(l) && null != (i = l[0]) && i.value && (p += "-" + l[0].value), {
      limitCount: o,
      orderedCount: a,
      skuName: p,
      skuIdDishCountInCart: n,
      incBoughtCount: d,
      minBoughtCount: m
    }
  };
exports.getLimitCountData = p, exports.dealOperationCountStyle = function(e, t) {
  var i = (0, n.GetDishSdkSingleton)((0, r.getShopId)()),
    u = null == i || null == i.findOriginalSpuDetail ? void 0 : i.findOriginalSpuDetail(e);
  return t && !(null == u || !u.showMultipleInput)
};
exports.verifyLimitCountRuleInOperation = function(e) {
  var u = e.spuDishId,
    l = e.skuDishId,
    d = void 0 === l ? "" : l,
    m = e.showCount,
    C = void 0 === m ? 0 : m,
    h = e.temporaryDishCount,
    f = void 0 !== h && h,
    c = e.promoDishLimitCount,
    g = void 0 === c ? -1 : c,
    v = (0, n.GetDishSdkSingleton)((0, r.getShopId)()),
    I = null == v || null == v.findOriginalSpuDetail ? void 0 : v.findOriginalSpuDetail(u);
  if (!I) return {
    passVerification: !0
  };
  var k = I.skuMenuItems.find((function(e) {
      return e.skuId === d
    })) || I.skuMenuItems[0],
    S = p(I, k),
    D = i(i({}, S), {}, {
      skuIdDishCountInCart: S.skuIdDishCountInCart + (f ? C : 0)
    });
  if (!(0, o.verifySimpleSkuLimitCount)(D)) {
    var y = D.skuName,
      M = D.orderedCount,
      x = D.limitCount;
    return {
      passVerification: !1,
      errorMessage: (0, o.jointExceedLimitCountMessage)({
        dishName: y,
        limitCount: x,
        orderedCount: M
      })
    }
  }
  if (!(0, o.verifySimpleSkuLimitCount)({
      limitCount: g,
      incBoughtCount: D.incBoughtCount,
      minBoughtCount: D.minBoughtCount,
      skuIdDishCountInCart: f ? C : 0,
      orderedCount: 0
    })) {
    var b = D.skuName;
    return {
      passVerification: !1,
      errorMessage: (0, o.jointExceedLimitCountMessage)({
        dishName: b,
        limitCount: g,
        orderedCount: 0
      })
    }
  }
  var L = a.default.getShopServiceData(),
    N = L.fmpBizData,
    q = L.shopConfig,
    B = null == N ? void 0 : N.promoLimitActivityVO,
    O = q;
  if (null != O && O.mtShopId && B && k.skuId) {
    var V, P, T = s.default.getCartDishList(O.mtShopId, O.tableNum),
      A = t(null == B ? void 0 : B.limitRuleTag);
    try {
      for (A.s(); !(P = A.n()).done;) {
        var j = P.value,
          R = j.skuIdList,
          E = j.limitValue,
          _ = j.limitActivityType,
          F = j.limitValuePerPerson;
        if (R.includes(+k.skuId)) {
          var w = (0, o.computeSkuDishListInCart)(R, T),
            z = w.skusCountInCart,
            G = w.skuNames;
          if (-1 === G.indexOf(S.skuName) && G.unshift(S.skuName), !(0, o.verifyLimitCount)((0, o.convertAssociatedSkuLimitData)({
              limitCount: E,
              isSkuIdDishInCart: !!(z + (f ? C : 0)),
              incBoughtCount: D.incBoughtCount,
              minBoughtCount: D.minBoughtCount,
              skusCountInCart: z
            }))) {
            var H;
            V = {
              limitValue: E,
              limitMessageTpl: null == B || null == (H = B.limitTextMode) ? void 0 : H["" + _],
              skuNames: G,
              limitValuePerPerson: F
            };
            break
          }
        }
      }
    } catch (e) {
      A.e(e)
    } finally {
      A.f()
    }
    if (V) {
      var U = {
        dishName: V.skuNames,
        limitCount: V.limitValue,
        orderedCount: 0,
        limitValuePerPerson: V.limitValuePerPerson,
        limitMessageTpl: V.limitMessageTpl
      };
      return {
        promptType: "confirm",
        passVerification: !1,
        errorMessage: (0, o.jointExceedLimitCountMessage)(U)
      }
    }
  }
  return {
    passVerification: !0
  }
};