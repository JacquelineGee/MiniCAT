var e = require("../../../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.ComponentsViewModel = void 0;
var t = require("../../../b/helpers/toConsumableArray"),
  o = require("../../../b/helpers/objectSpread2"),
  n = require("../../../b/helpers/classCallCheck"),
  a = require("../../../b/helpers/createClass"),
  r = e(require("../../../api/rmsStorage")),
  u = e(require("../../../miniprogram_npm/@mtfe/rms-triangle-c/index.js")),
  i = require("../../../constants/bizConstants"),
  l = require("../../../constants/path"),
  s = require("../../../miniprogram_npm/@components/limo-menu/menu-constants/actionItem"),
  p = require("../../../lib/env"),
  d = e(require("../../../store/menu")),
  f = require("../viewModel"),
  c = e(require("../grouponCoupon/GrouponCouponSdk")),
  m = function() {
    function e() {
      n(this, e)
    }
    return a(e, [{
      key: "formatShopInfoData",
      value: function(e, t) {
        if (!e) return null;
        var n = e.headActionList,
          a = e.tableName,
          d = e.peopleCountText,
          f = t.shopId,
          c = t.tableNum,
          m = r.default.getPreorderInfo(f);
        if (Number(null == t ? void 0 : t.reserveMode) === i.DISH_SOURCE.RESERVE && null != m && m.peopleCount && (d = (null == m ? void 0 : m.peopleCount) + "人点餐"), n) {
          var v = u.default.stringify(t, !0);
          n.forEach((function(e) {
            switch (e.type) {
              case s.ACTION_ITEM_TYPE.SEARCH:
                var t = "".concat(l.PATH.search, "?").concat(v);
                e.actionUrl = p.isNativeMp ? t : "./search?" + v;
                break;
              case s.ACTION_ITEM_TYPE.ORDER:
                p.isUnionPay && (e.actionUrl = "./order-list?bizDataType=20&" + v);
                break;
              case s.ACTION_ITEM_TYPE.PERSONAL_CENTER:
                e.showToastText = !e.showToastText && r.default.getIsToastFromMTLoginOnce()
            }
          }))
        }
        return o(o({}, e), {}, {
          headActionList: n,
          peopleCountText: d,
          shopId: f,
          tableNum: c,
          tableName: a
        })
      }
    }, {
      key: "formatMemberInfoData",
      value: function(e) {
        if (!e) return null;
        var t = e.theme,
          n = e.layout;
        return o(o({}, e), {}, t ? {
          animationStyle: ""
        } : {
          theme: {
            preset: 1,
            custom: {
              backgroundColor: null,
              buttonColor: null,
              buttonTextColor: null,
              textColor: null
            }
          },
          layout: n || {
            radius: 16
          },
          animationStyle: ""
        })
      }
    }, {
      key: "formatAdCarouselData",
      value: function(e, o) {
        if (!e || !o) return null;
        var n = o.shopId,
          a = e.banners,
          r = e.heightImg,
          u = e.layout,
          i = e.bannerInterval,
          l = e.advId,
          s = e.autoplay;
        return Array.isArray(a) ? {
          banners: t(a),
          heightImg: r || 210,
          layout: u || {},
          shopId: n,
          bannerInterval: i,
          advId: l,
          autoplay: s
        } : null
      }
    }, {
      key: "formatPopupWindowsData",
      value: function(e, t) {
        (0, f.saveActivityTypeList)(e);
        var n = t.spuId,
          a = t.shopId,
          u = e.adPopupDecoration,
          l = e.takeCoupon,
          s = e.buffetLimitMealTips;
        if ((n || !e) && (null == s || !s.length)) return null;
        if (u && (u.advId || !r.default.getHasShowAdBoardAtMenu(a))) return {
          adPopupDecoration: o(o({}, u), {}, {
            show: !0
          }),
          takeCoupon: l,
          shopId: a,
          buffetLimitMealTips: s
        };
        if (!l) return {
          buffetLimitMealTips: s,
          shopId: a
        };
        var p = l.resultCode,
          d = l.couponListURL,
          c = l.buttonText,
          m = l.loginURL,
          v = l.failMainCause,
          C = l.failSubCauseList,
          h = void 0 === C ? [] : C,
          I = l.partFailCause,
          T = l.activityTypeList,
          b = l.givePointInfo,
          g = l.couponDisplayInfos;
        return p === i.TAKE_COUPON_RESULT.NO_DATA ? {
          buffetLimitMealTips: s,
          shopId: a
        } : {
          takeCoupon: {
            resultCode: p,
            couponListURL: d,
            buttonText: c,
            loginURL: m,
            failMainCause: v,
            failSubCauseList: h,
            partFailCause: I,
            activityTypeList: T,
            givePointInfo: b,
            show: !0,
            couponDisplayInfos: g
          },
          adPopupDecoration: void 0,
          shopId: a,
          buffetLimitMealTips: s
        }
      }
    }, {
      key: "formatRecommendationInfoData",
      value: function(e, t) {
        var n;
        return null != e && null != (n = e.recommendTabs) && n.length ? o(o({
          urlParams: t
        }, e), {}, {
          menuUpdateTime: Date.now()
        }) : null
      }
    }, {
      key: "formatGrouponCouponLoginData",
      value: function() {
        var e, t = d.default.getState();
        return (null == t || null == (e = t.extraInfo) || null == (e = e.headInfo) || null == (e = e.shopInfo) || null == (e = e.groupCouponInfo) ? void 0 : e.showMTBind) ? {
          customClass: "groupon-coupon-login-menu"
        } : null
      }
    }, {
      key: "formatGrouponCouponSwiperData",
      value: function(e, t) {
        var n, a = e.mtUserName,
          u = e.grouponCouponList,
          i = void 0 === u ? [] : u,
          l = t.shopId,
          s = r.default.getDealCoupons(l);
        return c.default.grouponCouponModel = e, {
          shopId: l,
          mtUserName: a,
          grouponCouponList: null == i || null == (n = i.map((function(e) {
            var t, n = e.discountTempIdList;
            return o(o({}, e), {}, {
              couponStatusList: null == n || null == (t = n.map((function(e) {
                var t;
                return {
                  discountTempId: e,
                  selectStatus: null == s || null == (t = s.find((function(t) {
                    return t.discountTempId === e
                  }))) ? void 0 : t.selectStatus
                }
              }))) ? void 0 : t.filter((function(e) {
                return void 0 !== e.selectStatus
              }))
            })
          }))) ? void 0 : n.filter((function(e) {
            var t;
            return null == (t = e.couponStatusList) ? void 0 : t.length
          }))
        }
      }
    }, {
      key: "formatRegisterPanelData",
      value: function(e) {
        return {
          actionUrl: e.actionUrl
        }
      }
    }, {
      key: "formatNoticeConfigData",
      value: function(e) {
        return o({}, e)
      }
    }, {
      key: "formatAddressListModalData",
      value: function(e) {
        var t = !0;
        return r.default.getUserSelectedAddressFlag() ? t = !1 : r.default.setUserSelectedAddressFlag(!0), o(o({}, e), {}, {
          show: t
        })
      }
    }]), e
  }();
exports.ComponentsViewModel = m;