var e = require("../../../../../b/helpers/interopRequireDefault"),
  t = require("../../../../../miniprogram_npm/@limo/container/behaviors/index"),
  r = require("../../../../../constants/bizConstants"),
  o = require("../../../../../lib/wx/transfer-rpx"),
  a = e(require("../../behaviors/nav-behavior"));
Component({
  behaviors: [a.default, t.commonBehavior, t.limoShim],
  options: {
    addGlobalClass: !0
  },
  data: {
    showMoreCategory: !0,
    categoryLines: [],
    currentExpendCategory: 0,
    DISH_CATEGORY_ID: r.DISH_CATEGORY_ID
  },
  attached: function() {
    this.limoAttached()
  },
  methods: {
    limoAttached: function() {
      this.behaviorsNavBehavior_limoAttached(), this.categoryWidth = Math.floor((0, o.transformRpxToNumber)(196))
    },
    catchTouchMove: function() {},
    showMoreCategory: function() {
      for (var e, t = this.data, r = t.categoryLines, o = t.curCategoryId, a = {
          showMoreCategory: !0
        }, n = -1, i = 0; i < r.length; i += 1) {
        var c = r[i];
        c.secondCategory && c.secondCategory.length > 0 && (a["categoryLines[".concat(i, "].secondCategory")] = []), e || (e = Array.isArray(c) ? c.find((function(e) {
          return e.categoryId === o
        })) : null, n = i)
      }
      e && (a["categoryLines[".concat(n + 1, "].secondCategory")] = e.childDishCategories, a.currentExpendCategory = o), this.setData(a), this.triggerEvent("showMoreCategory", {
        showMoreCategory: !0
      })
    },
    hideMoreCategory: function() {
      this.setData({
        showMoreCategory: !1,
        currentExpendCategory: 0
      }), this.triggerEvent("showMoreCategory", {
        showMoreCategory: !1
      })
    },
    expendSecondCategory: function(e) {
      for (var t = e.currentTarget.dataset || {}, r = t.categoryId, o = t.index, a = this.data, n = a.categoriesList, i = a.categoryLines, c = a.currentExpendCategory, s = {}, g = 0; g < i.length; g += 1) i[g].secondCategory && i[g].secondCategory.length > 0 && (s["categoryLines[".concat(g, "].secondCategory")] = []);
      var h = i[o + 1] && i[o + 1].secondCategory && i[o + 1].secondCategory.length;
      if (c === r && h) s["categoryLines[".concat(o + 1, "].secondCategory")] = [], s.currentExpendCategory = "";
      else {
        var d = n.find((function(e) {
          return e.categoryId === r
        }));
        s["categoryLines[".concat(o + 1, "].secondCategory")] = d.childDishCategories, s.currentExpendCategory = r
      }
      this.setData(s)
    },
    calcCategoryScrollOffset: function(e, t) {
      var r = this.data,
        o = r.categoriesList,
        a = r.winWidth,
        n = r.categoryScrollOffset;
      return t || (t = o.findIndex((function(t) {
        return t.categoryId === e
      }))), t > -1 ? t * this.categoryWidth - (a / 2 - this.categoryWidth / 2) : n
    }
  }
});