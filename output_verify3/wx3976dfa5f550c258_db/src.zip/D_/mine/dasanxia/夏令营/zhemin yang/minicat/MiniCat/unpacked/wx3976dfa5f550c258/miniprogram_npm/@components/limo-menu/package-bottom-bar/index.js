var e = require("../../../../b/helpers/interopRequireDefault"),
  t = require("../../../@limo/container/behaviors/index"),
  a = e(require("../../../../modules/menu/I18n/I18nService"));
Component({
  behaviors: [t.commonBehavior, t.limoShim],
  properties: {
    panelDishData: {
      type: Object,
      value: {}
    },
    applyCouponId: {
      type: String,
      value: ""
    },
    enableClick: {
      type: Boolean,
      value: !1
    },
    isModifyMode: {
      type: Boolean,
      value: !1
    },
    isPackageDetailOpen: {
      type: Boolean,
      value: !1
    },
    hidePrice: {
      type: Boolean,
      value: !1
    },
    btnTitle: {
      type: String,
      value: ""
    }
  },
  data: {},
  attached: function() {
    this.limoAttached()
  },
  methods: {
    limoAttached: function() {
      var e = a.default.getCurrency();
      this.setData({
        currency: e
      })
    },
    togglePackageDetailsPanelEvent: function() {
      this.triggerEvent("togglePackageDetailsPanel")
    },
    addToCart: function() {
      this.triggerEvent("clickAddCart")
    },
    operationCountFn: function(e) {
      this.triggerEvent("operationCount", e.detail)
    }
  }
});