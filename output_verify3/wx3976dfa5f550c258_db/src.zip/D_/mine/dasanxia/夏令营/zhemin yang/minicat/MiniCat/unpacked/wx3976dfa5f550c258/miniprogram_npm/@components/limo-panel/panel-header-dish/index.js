Object.defineProperty(exports, "__esModule", {
  value: !0
});
var e = require("../../../../b/helpers/objectSpread2"),
  a = require("../../../@limo/container/behaviors/index");
Component({
  behaviors: [a.commonBehavior, a.limoShim],
  properties: {
    panelHeaderDish: {
      type: Object,
      value: {},
      observer: function(e) {
        this.initData(e)
      }
    }
  },
  data: {
    picUrl: "",
    name: "",
    hotSellingTag: {},
    packageDishCountText: "",
    picTag: "",
    picLabel: "",
    picLabelClass: "",
    desc: "",
    tagList: [],
    hasRecommendTags: !1,
    dishTagList: [],
    fromPackagePanel: !1
  },
  attached: function() {
    this.limoAttached()
  },
  methods: {
    limoAttached: function() {
      var e = this.data.panelHeaderDish;
      this.initData(e)
    },
    initData: function(a) {
      if (Object.keys(a).length) {
        var i = a.recommendTags,
          t = a.dishDescribeTag,
          s = Array.isArray(i) && i.length > 0,
          r = s ? i : t || [];
        this.setData(e(e({}, a), {}, {
          hasRecommendTags: s,
          dishTagList: r
        }))
      }
    }
  }
});