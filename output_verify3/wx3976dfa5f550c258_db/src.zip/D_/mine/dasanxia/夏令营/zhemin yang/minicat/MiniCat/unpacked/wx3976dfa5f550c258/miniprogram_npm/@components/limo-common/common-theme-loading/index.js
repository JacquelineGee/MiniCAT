var i = require("../../../@limo/container/behaviors/index.js");
Component({
  behaviors: [i.commonBehavior, i.limoShim],
  properties: {},
  data: {},
  attached: function() {
    this.limoAttached()
  },
  methods: {
    limoAttached: function() {}
  }
});