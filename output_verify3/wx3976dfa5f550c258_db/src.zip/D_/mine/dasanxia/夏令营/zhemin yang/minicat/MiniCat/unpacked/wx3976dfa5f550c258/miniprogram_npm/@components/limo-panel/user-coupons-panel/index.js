var e = require("../../../../b/helpers/interopRequireDefault"),
  o = e(require("../../../@limo/core/index.js")),
  a = require("../../../@limo/container/behaviors/index"),
  t = e(require("../panel-behaviors/panelBehavior")),
  n = require("../panel-tools/panelEnum"),
  i = require("../../../../constants/bizConstants"),
  r = require("../../../../lib/mix/util");
Component({
  behaviors: [t.default, a.commonBehavior, a.limoShim],
  properties: {
    urlParams: {
      type: Object,
      value: {}
    },
    grouponCouponData: {
      type: Object,
      value: {}
    }
  },
  data: {
    noDataTag: !1,
    loadingRules: !0,
    couponList: [],
    couponRequestHost: (0, r.getLoginHost)()
  },
  attached: function() {
    this.limoAttached()
  },
  methods: {
    limoAttached: function() {
      this.panelBehaviorsPanelBehavior_limoAttached(), this.getUserCouponData()
    },
    getUserCouponData: function() {
      var e = this;
      this.setData({
        noDataTag: !1
      });
      var a = this.data,
        t = a.urlParams,
        n = a.grouponCouponData,
        s = (null == n ? void 0 : n.groupCouponDisplayInfos) || [],
        u = Number(t.bizType) === i.BIZ_TYPE_MAP.TAKEAWAY || Number(t.bizType) === i.BIZ_TYPE_MAP.PICKUP ? t.bizType : t.reserveMode || 0;
      o.default.getLimoRuntime().request({
        url: (0, r.getHost)() + "/diancan/menu/api/queryMemberCoupons",
        method: "GET",
        data: {
          mtShopId: t.shopId,
          reserveMode: u
        },
        header: {
          withCredentials: !0
        },
        complete: function(o) {
          var a, t;
          e.setData({
            loadingRules: !1
          });
          var n = ((null == o || null == (a = o.data) ? void 0 : a.data) || {}).couponDisplayInfos;
          200 === (null == o || null == (t = o.data) ? void 0 : t.code) ? e.setData({
            couponList: (s || []).concat(n || [])
          }) : e.setData({
            noDataTag: !0
          })
        },
        fail: function() {
          e.setData({
            noDataTag: !0,
            loadingRules: !1
          })
        }
      })
    },
    closeUserCouponsPanel: function() {
      this.closePanel(n.PanelType.USER_COUPONS_PANEL)
    },
    gotoThirdLoginFn: function() {
      this.triggerEvent("toThirdLoginFn"), this.closeUserCouponsPanel()
    }
  }
});