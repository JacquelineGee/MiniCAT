var e = require("../../../b/helpers/interopRequireDefault"),
  t = require("../../../miniprogram_npm/@limo/container/behaviors/index"),
  a = require("../../../constants/bizConstants"),
  i = e(require("../../../lib/mix/toast")),
  n = e(require("../../../store/menu")),
  s = e(require("../../../store/helpers/storeBehavior")),
  r = require("../../../modules/panel/panelTransaction");
Component({
  behaviors: [s.default, t.commonBehavior, t.limoShim],
  options: {
    addGlobalClass: !0
  },
  properties: {
    spuDish: {
      type: Object,
      value: {}
    },
    menuPackageSku: {
      type: Object,
      value: {}
    },
    menuSkuDish: {
      type: Object,
      value: {}
    },
    originCalcValue: {
      type: Number,
      value: 0
    },
    showCalculatorPanel: {
      type: Boolean,
      value: !1
    },
    calcStatus: {
      type: Number,
      value: 1
    },
    isNativeTabbarPage: {
      type: Boolean,
      value: !1
    }
  },
  data: {
    numbers: ["1", "2", "3", "4", "5", "6", "7", "8", "9", ".", "0", "00"],
    calcValue: 0,
    firstEnterCalc: !0
  },
  observers: {
    spuDish: function() {
      var e = this.data,
        t = e.spuDish,
        i = e.menuPackageSku,
        n = e.menuSkuDish,
        s = t.dishType === a.DISH_TYPE.PACKAGE ? i : n;
      this.setData({
        skuDish: s
      }, (function() {
        r.PanelTransaction.success(r.PANEL_TYPE.CALCULATOR_PANEL)
      }))
    },
    originCalcValue: function(e) {
      this.setData({
        calcValue: e
      })
    }
  },
  created: function() {
    this.store = n.default
  },
  attached: function() {
    this.limoAttached()
  },
  methods: {
    limoAttached: function() {
      this.setData({
        calcValue: this.data.originCalcValue
      })
    },
    limoReady: function() {
      this.helpersStoreBehavior_limoReady()
    },
    inputValue: function(e) {
      var t = e.currentTarget.dataset.num;
      switch (this.data.calcStatus) {
        case a.CALCULATOR_STATUS.WEIGHT:
          this.processWeight(t);
          break;
        case a.CALCULATOR_STATUS.ADD:
          this.processAddDish(t)
      }
    },
    deleteCalcValue: function() {
      var e = this.data.calcValue.toString();
      e.length > 0 && this.setData({
        calcValue: e.substr(0, e.length - 1)
      })
    },
    processWeight: function(e) {
      var t, a = this.data.firstEnterCalc,
        i = this.data.calcValue.toString();
      if (a) t = "0" === e || "00" === e ? "0" : "" === e ? "0." : e, this.setData({
        firstEnterCalc: !1
      });
      else {
        if (-1 !== i.indexOf(".")) {
          if (Number(i.indexOf(".")) + 3 === i.length) return;
          if ("." === e) return
        } else {
          if (4 === i.length) return;
          if (3 === i.length && "00" === e) return
        }
        t = "" === i && "." === e ? "0." : "" === i && "00" === e ? "0" : -1 !== Number(i.indexOf(".")) && Number(i.indexOf(".")) + 2 === i.length && "00" === e ? i + "0" : "".concat(i).concat(e)
      }
      this.setData({
        calcValue: t
      })
    },
    processAddDish: function(e) {
      var t, a = this.data.firstEnterCalc,
        n = this.data.calcValue.toString();
      if ("." !== e) {
        if (a) t = "00" === e ? "0" : e, this.setData({
          firstEnterCalc: !1
        });
        else {
          if (2 === n.length && "00" === e) return void i.default.show({
            content: "最多选择999份～"
          });
          if (3 === n.length) return void i.default.show({
            content: "最多选择999份～"
          });
          t = 0 == +n ? "" + +e : "".concat(n).concat(e)
        }
        this.setData({
          calcValue: t
        })
      }
    },
    nextCalc: function() {
      var e = this.data.calcValue;
      this.triggerEvent("nextInCalcFn", {
        calcValue: e
      })
    },
    closeCalcPanel: function() {
      this.triggerEvent("closeCalcPanelFn")
    },
    prevent: function() {}
  },
  ready: function() {
    this.limoReady()
  }
});