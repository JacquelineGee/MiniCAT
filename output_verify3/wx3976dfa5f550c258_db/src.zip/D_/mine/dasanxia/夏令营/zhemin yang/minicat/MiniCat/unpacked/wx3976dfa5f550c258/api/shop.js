var e = require("../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.default = void 0;
var r = e(require("../b/regenerator")),
  t = require("../b/helpers/asyncToGenerator"),
  a = require("../constants/ajaxResCode"),
  s = require("./portal"),
  u = {
    getShopHomeShare: function(e) {
      return t(r.default.mark((function t() {
        var u, n, c, i, o, h, l, p, d;
        return r.default.wrap((function(r) {
          for (;;) switch (r.prev = r.next) {
            case 0:
              return r.prev = 0, r.next = 3, (0, s.queryPageInfo)(e);
            case 3:
              return u = r.sent, n = {}, u && u.code === a.RES_CODE.SUCCESS && ((c = u.data.modules || []) && c.length > 0 ? (i = c[0].data, o = i.title, h = i.desc, l = i.imgUrl, p = i.redirectUrl, d = i.shareSwitch, n = {
                shareMsg: {
                  title: o,
                  desc: h,
                  path: p,
                  imageUrl: l
                },
                shareSwitch: d
              }) : n = {
                shareMsg: {},
                shareSwitch: !1
              }), r.abrupt("return", n);
            case 9:
              return r.prev = 9, r.t0 = r.catch(0), r.abrupt("return", {
                shareMsg: {},
                shareSwitch: !1
              });
            case 12:
            case "end":
              return r.stop()
          }
        }), t, null, [
          [0, 9]
        ])
      })))()
    }
  };
exports.default = u;