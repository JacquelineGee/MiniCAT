var e = require("../../../../b/helpers/interopRequireDefault"),
  a = require("../../../@limo/container/behaviors/index"),
  t = e(require("../../../../modules/menu/I18n/I18nService"));
Component({
  behaviors: [a.commonBehavior, a.limoShim],
  properties: {
    packageDetailList: {
      type: Array,
      value: []
    },
    ifInPackagePanle: {
      type: Boolean,
      value: !1
    },
    isNativeTabbarPage: {
      type: Boolean,
      value: !1
    }
  },
  data: {
    placeholderClass: "placeholder-in-page"
  },
  ready: function() {
    this.limoReady()
  },
  methods: {
    limoReady: function() {
      this.data.ifInPackagePanle && (this.isH5 ? this.setData({
        placeholderClass: "placeholder-in-h5-panel"
      }) : this.setData({
        placeholderClass: "placeholder-in-panel"
      }));
      var e = t.default.getCurrency();
      this.setData({
        currency: e
      })
    },
    closePanelFunc: function() {
      this.triggerEvent("closePackageDetailsPanel"), this.setData({
        packageDetailList: []
      })
    },
    scroll: function(e) {
      e.stopPropagation && e.stopPropagation()
    },
    prevent: function() {}
  }
});