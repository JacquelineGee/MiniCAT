var e = require("../../../b/helpers/interopRequireDefault"),
  a = require("../../../b/helpers/objectSpread2"),
  t = require("../../../miniprogram_npm/@limo/container/behaviors/index"),
  i = require("../../../modules/cartHelper"),
  s = require("../../../modules/panel/panelHelper"),
  n = require("../../../modules/panel/panelDataUtil"),
  r = require("../../../constants/bizConstants"),
  u = require("../../../modules/LXHelper"),
  l = e(require("../../../modules/menu/grouponCoupon/GrouponCouponSdk")),
  o = require("../../../modules/panel/mp-spec/util"),
  p = require("../../../modules/panel/panelTransaction");
Component({
  behaviors: [t.commonBehavior, t.limoShim],
  options: {
    addGlobalClass: !0
  },
  properties: {
    spuDish: {
      type: Object,
      value: {}
    },
    options: {
      type: Object,
      value: {}
    },
    menuPackageSku: {
      type: Object,
      value: {}
    },
    cartPackageSku: {
      type: Object,
      value: {}
    },
    packageVisible: {
      type: Boolean,
      value: !1
    },
    refactorLocalCart: {
      type: Object,
      value: {}
    },
    editDishGoodsNo: {
      type: String,
      value: ""
    },
    spuComboShowType: {
      type: Number,
      value: 0,
      observer: function(e) {
        e === r.PACKAGE_TEMPLATE_TYPE.NO_PIC && this.setData({
          maxLen: 6
        })
      }
    },
    shopId: {
      type: String,
      value: ""
    },
    showDishRemark: {
      type: Boolean,
      value: !1
    },
    isNativeTabbarPage: {
      type: Boolean,
      value: !1
    },
    hidePrice: {
      type: Boolean,
      value: !1
    },
    btnTitle: {
      type: String,
      value: ""
    },
    discount: {
      type: Number,
      value: 0
    }
  },
  data: {
    enableClick: !1,
    packages: [],
    panelDishData: {},
    isShowDetailPanel: !1,
    packageDetailList: [],
    isShowSpecsOperatePanel: !1,
    specsOperatePanelData: {},
    panelHeaderDish: {},
    maxLen: 9,
    remarkText: "",
    showRemarkPanel: !1,
    detailDescription: ""
  },
  specsOperateSkuInfo: {},
  observers: {
    "menuPackageSku.**, cartPackageSku.**": function(e, t) {
      var r = (new Date).getTime(),
        c = (0, i.judgePackageEnableAdd)(t).enableClick,
        d = (0, n.TransPackageDishData)(e, t),
        h = this.data,
        g = h.spuDish,
        k = h.refactorLocalCart,
        m = h.editDishGoodsNo,
        D = h.discount,
        P = this.data.isShowSpecsOperatePanel,
        S = (0, n.TransPanelHeaderData)(g, t, !1, !1, k, m, !0, e, D),
        v = (0, o.getPanelHeaderDish)(g, t.skuId, "", D),
        T = null;
      if (P) {
        var b, f = this.specsOperateSkuInfo || {},
          E = f.skuId,
          C = f.groupId,
          O = (0, s.getMatchedSkuDish)(t, C, E);
        P = !(null == (b = T = (0, n.TransSpecsOperateData)(O)) || null == (b = b.skusList) || !b.length)
      }
      this.setData({
        enableClick: c,
        packages: d,
        panelDishData: a(a({}, S), {}, {
          statement: (0, n.dealPackageStatement)(null == e ? void 0 : e.packageGroups, null == t ? void 0 : t.packageGroups)
        }),
        applyCouponId: l.default.getApplyCouponId(),
        panelHeaderDish: v,
        isShowSpecsOperatePanel: P,
        specsOperatePanelData: T,
        remarkText: t.remark,
        detailDescription: (null == g ? void 0 : g.detailDescription) || ""
      }, (function() {
        r && (0, u.sendMV)("b_saaspay_rts2p1tm_mv", null, null, {
          duration: (new Date).getTime() - r
        }), p.PanelTransaction.success(p.PANEL_TYPE.PACKAGE_PANEL)
      }))
    }
  },
  methods: {
    addTastes: function(e) {
      this.triggerEvent("addTastesFn", e.detail)
    },
    minusSkuDishFunc: function(e) {
      this.triggerEvent("minusPackageSkuDishFn", e.detail)
    },
    minusSkuDishWithSameSpecFunc: function(e) {
      var a = (null == e ? void 0 : e.detail) || {},
        t = a.goodsNo,
        i = a.skuId,
        n = a.groupId,
        r = (0, s.getMatchedSkuDish)(this.data.menuPackageSku, n, i)[0],
        u = (0, s.getMatchedSkuDish)(this.data.cartPackageSku, n, i).find((function(e) {
          return e.goodsNo === t
        }));
      this.triggerEvent("minusPackageSkuDishFn", {
        cartSku: u,
        menuSku: r
      })
    },
    toggleSpecPanelFunc: function(e) {
      var a = (null == e ? void 0 : e.detail) || {},
        t = a.goodsNo,
        i = a.skuId,
        n = a.groupId,
        u = (0, s.getMatchedSkuDish)(this.data.menuPackageSku, n, i)[0],
        l = (0, s.getMatchedSkuDish)(this.data.cartPackageSku, n, i).find((function(e) {
          return e.goodsNo === t
        }));
      this.triggerEvent("addTastesFn", {
        cartSku: l,
        menuSku: u,
        type: r.OPERATE_PACKAGE_TASTE_TYPE.MODIFY
      })
    },
    closePanelFunc: function() {
      this.triggerEvent("closePackagePanel")
    },
    clickAddCart: function() {
      this.triggerEvent("packagePanelClickAddCart")
    },
    togglePackageDetailsPanel: function() {
      var e = this.data,
        a = e.cartPackageSku,
        t = e.isShowDetailPanel,
        i = t ? [] : (0, n.TransPanelDetailsData)(a);
      this.setData({
        isShowDetailPanel: !t,
        packageDetailList: i
      })
    },
    toggleSpecs: function(e) {
      var a = (null == e ? void 0 : e.detail) || {},
        t = a.cartSkuList,
        i = a.groupId,
        s = a.skuId,
        r = !this.data.isShowSpecsOperatePanel,
        u = r ? (0, n.TransSpecsOperateData)(t) : null;
      this.specsOperateSkuInfo = r && i && s ? {
        skuId: s,
        groupId: i
      } : {}, this.setData({
        isShowSpecsOperatePanel: r,
        specsOperatePanelData: u
      })
    },
    operationCountFn: function(e) {
      var a = e.detail.type;
      "plus" === a ? this.triggerEvent("addPanelSkuDishFn", e.detail) : "minus" === a && this.triggerEvent("minusPanelSkuDishFn")
    },
    setToggleDishRemarkPanel: function() {
      var e = this.data.showRemarkPanel;
      this.setData({
        showRemarkPanel: !e
      })
    },
    updateDishRemark: function(e) {
      var a = e.detail.remarkText,
        t = void 0 === a ? "" : a;
      this.setToggleDishRemarkPanel(), this.triggerEvent("updateDishRemarkFn", {
        remarkText: t
      })
    }
  }
});