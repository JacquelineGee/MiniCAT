var t = require("../../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.dealPackageStatement = exports.dealPackageDetail = exports.TransSpecsOperateData = exports.TransPanelHeaderData = exports.TransPanelDetailsData = exports.TransPackageDishData = void 0;
var e = require("../../b/helpers/toConsumableArray"),
  n = require("../../b/helpers/objectSpread2"),
  r = require("../../constants/bizConstants"),
  u = require("../../constants/menu"),
  a = require("../cartHelper"),
  o = require("../menu/dish/PropertyUtil"),
  i = require("../../lib/number"),
  s = t(require("../../miniprogram_npm/@mtfe/rms-triangle-c/index.js")),
  c = require("./panelHelper"),
  l = t(require("../menu/shop/shopService")),
  p = require("../../types/newMenu/MenuData"),
  d = function(t) {
    var e = t.methods,
      n = t.tastes,
      r = function(t) {
        var e, n = Array.isArray(e = t) && e.length > 0 ? null == t ? void 0 : t.map((function(t) {
          return t || []
        })) : [];
        return (null == n ? void 0 : n.length) > 0 ? s.default.flatDeep(n, 1) : []
      };
    return {
      allMethods: r(e),
      allTastes: r(n)
    }
  },
  g = function(t) {
    var e = t.specAttrs,
      n = t.count,
      r = e || [],
      u = d(t),
      a = u.allMethods,
      o = u.allTastes,
      i = [];
    r.length && r.forEach((function(t) {
      return t.value && i.push(t.value)
    })), a.length && a.forEach((function(t) {
      return t.name && i.push(t.name)
    })), o.length && o.forEach((function(t) {
      return t.name && i.push("".concat(t.name, "*").concat(t.count))
    }));
    var s = i.length > 0 ? i.join("、") : "";
    return n && n > 1 && s && (s = "每份：" + s), s
  },
  h = function(t) {
    var e = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
      n = [];
    return null == t || t.forEach((function(t) {
      var r;
      null == t || null == (r = t.items) || r.forEach((function(t) {
        t.name && n.push(e && null != t && t.count ? "".concat(t.name, "x").concat(t.count) : t.name)
      }))
    })), n
  },
  f = function(t, n, r) {
    if (!t || !n) return "";
    var u = [];
    return n.forEach((function(n) {
      var a = n.groupSkus,
        o = t.find((function(t) {
          return t.groupId === n.groupId
        }));
      null == a || a.forEach((function(t) {
        var n, a, i = null == o || null == (n = o.groupSkus) ? void 0 : n.find((function(e) {
            return e.skuId === t.skuId
          })),
          s = t.count,
          c = t.number,
          l = (null == i || null == (a = i.specAttrs) || null == (a = a[0]) ? void 0 : a.value) || "",
          p = l.length > 0 ? [l] : [],
          d = r(t, i),
          g = d.methodArr,
          h = d.tasteArr,
          f = [].concat(p, e(g), e(h)).join("，");
        if (i) {
          var m = t.skuName;
          f.length > 0 && (m = "".concat(m, "（").concat(f, "）"));
          var v;
          v = i.canWeight ? "".concat(m, "x").concat(t.weight).concat(i.unit) : c > 1 ? "".concat(m, "x").concat(c).concat(i.unit) : m, 1 === s ? u.push(v) : s > 1 && u.push.apply(u, e(Array(s).fill(v)))
        }
      }))
    })), u.join("+").slice(0, 50)
  };
exports.dealPackageStatement = function(t, e) {
  return f(t, e, (function(t) {
    var e = d(t),
      n = e.allMethods,
      r = e.allTastes;
    return {
      methodArr: null == n ? void 0 : n.map((function(t) {
        return t.name
      })),
      tasteArr: null == r ? void 0 : r.map((function(t) {
        return "".concat(t.name, "x").concat(t.count)
      }))
    }
  }))
}, exports.dealPackageDetail = function(t, e) {
  return f(t, e, (function(t) {
    return {
      methodArr: h(t.methods),
      tasteArr: h(t.tastes, !0)
    }
  }))
}, exports.TransPanelHeaderData = function(t, e) {
  var n, s, d = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
    h = arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
    f = arguments.length > 4 ? arguments[4] : void 0,
    m = arguments.length > 5 ? arguments[5] : void 0,
    v = !(arguments.length > 6 && void 0 !== arguments[6]) || arguments[6],
    P = arguments.length > 7 ? arguments[7] : void 0,
    T = arguments.length > 8 ? arguments[8] : void 0,
    k = t.skuMenuItems && t.skuMenuItems.find((function(t) {
      return t.skuId === e.skuId
    })),
    I = k && k.stockCount ? k.stockCount : -1,
    E = (0, o.dealTagList)(e, h),
    x = l.default.getShopServiceData(),
    D = x.fmpBizData,
    S = 0,
    O = 0,
    A = e ? !!e.grouponCouponInfo && e.grouponCouponInfo.length > 0 : null;
  !d && e && (h ? (S = (0, i.plusFloat)((0, i.multiFloat)(e.currentPrice, e.weight), e.extraPrice), O = (0, i.plusFloat)((0, i.multiFloat)(e.originalPrice, e.weight), e.extraPrice)) : (S = (0, i.plusFloat)(e.currentPrice, e.extraPrice), O = (0, i.plusFloat)(e.originalPrice, e.extraPrice))), A && e && (S = (0, i.plusFloat)(0, e.extraPrice), e.packageGroups && e.packageGroups.length && (e.packageGroups.forEach((function(t) {
    t.groupSkus && t.groupSkus.length && t.groupSkus.forEach((function(t) {
      t.count > 0 && (S -= t.number * t.count * t.addPrice)
    }))
  })), S = (0, i.plusFloat)(0, S))), v || (S = (0, i.plusFloat)(+e.currentPrice, +e.extraPrice), O = (0, i.plusFloat)(+e.originalPrice, +e.extraPrice));
  var b = S ? (0, i.roundFloat)(S, 2) : 0,
    _ = O ? (0, i.roundFloat)(O, 2) : 0,
    C = "";
  if (T) {
    var L, N = D.pointBuyCampaign,
      y = null == N ? void 0 : N.pointDishList,
      F = null == y ? void 0 : y.find((function(e) {
        return e.spuId === t.spuId
      })),
      R = null == F || null == (L = F.pointDishItems) ? void 0 : L.find((function(t) {
        return t.skuId === e.skuId
      }));
    if (R) {
      b = (0, i.plusFloat)(R.currentPrice, +e.extraPrice);
      var U = (0, i.minusFloat)(e.originalPrice, R.currentPrice);
      C = "已用 ".concat(R.pointCount, " 积分抵扣￥").concat(U)
    }
  }
  var M = t.description;
  if (P && !M) {
    var w = (P.packageGroups || []).map((function(t) {
      if (t.groupType === r.GROUP_TYPE.FIXED) return "".concat(t.groupName, " ").concat(t.groupLimit, "份");
      var e = t.optionType === u.PACKAGE_OPTION_TYPE.RANGE ? "".concat(t.lowerCount, "~").concat(t.upperCount) : t.groupLimit;
      return "".concat(t.groupName).concat(t.groupSkus.length, "选").concat(e)
    }));
    M = w.length > 0 ? w.join("， ") : ""
  }
  var q, G = "",
    H = "";
  d ? (G = (null == e || null == (q = e.dishPicUrls) ? void 0 : q[r.PICTURE_RATIO.ONE_TO_ONE]) || r.PLACEHOLDER_DISH_PIC.ONE_TO_ONE, e.canWeight && e.weight && e.weight > 0 ? H = "".concat(e.weight).concat(e.unit) : e.number > 0 && (H = "".concat(e.number).concat(e.unit))) : G = t.dishPicUrls[r.PICTURE_RATIO.ONE_TO_ONE] || r.PLACEHOLDER_DISH_PIC.ONE_TO_ONE;
  var j, Y = (0, c.getUnit)(e, v),
    B = (0, o.dealPicLabelStyleType)(null != (n = null == D ? void 0 : D.picLabelStyleType) ? n : p.PIC_LABEL_STYLE_TYPE.DEFAULT),
    W = (0, a.getLimitDescList)(t, e, !0),
    z = null == f ? void 0 : f.refactorCartDishMap[t.spuId.toString()],
    X = 0;
  z && !m && z.map((function(t) {
    return t.skuId === e.skuId && t.count && (X += t.count), null
  })), z && m && z.map((function(t) {
    return t.skuId === e.skuId && t.itemNo !== m && t.count && (X += t.count), null
  })), j = -1 === e.stockCount ? -1 : e.stockCount - X > 1 ? e.stockCount - X : 1;
  var K = {
    id: t.spuId,
    type: u.DISH_OPERATION_TYPE_VAL.NUMBER,
    preventMinus: !0,
    count: e.count,
    incCount: t.incBoughtCount,
    maxCount: j,
    showMultipleInput: t.showMultipleInput,
    temporaryDishCount: !0,
    showDishOperation: null == (s = null == D ? void 0 : D.showDishOperation) || s
  };
  return {
    isPackageGroups: !!e.packageGroups,
    name: e.skuName,
    count: e.count,
    dishNum: H,
    stockCount: I,
    packageDescText: M,
    dishUnit: Y,
    tagList: E,
    picLabelClass: B,
    picLabel: W,
    currentPrice: b,
    originalPrice: _,
    picUrl: G,
    operationData: K,
    hotSellingTag: (0, o.dealHotSellingTag)(t.hotSellingImgTag, "" + t.currentPrice, "DEFAULT"),
    picTag: t.dishTag && t.dishTag[0] || "",
    desc: t.description,
    orderDishInfoText: g(e),
    pointDiscountText: C,
    estimatedPrice: null == k ? void 0 : k.estimatedPrice
  }
}, exports.TransPackageDishData = function(t, e) {
  var n = null == t ? void 0 : t.packageGroups,
    u = null == e ? void 0 : e.packageGroups;
  return n && u ? u.map((function(t) {
    for (var e = t.groupType === r.GROUP_TYPE.FIXED, u = (t.groupSkus || []).map((function(e) {
        var u, s, d, g, h = (0, c.getMatchedMenuSku)(n, t.groupId, e),
          f = !(0, a.selectTastes)(h),
          m = (0, c.getSpecAttrsStyle)(e, !0),
          v = e.specAttrs && e.specAttrs[0].value || "",
          P = (0, c.getTastesText)(e),
          T = "",
          k = 0;
        e.canWeight && e.weight && e.weight > 0 ? (T = "".concat(e.weight, " ").concat(e.unit), k = e.weight * e.addPrice, k = (0, i.roundFloat)(k, 2)) : e.number > 0 && (T = "".concat(e.number, " ").concat(e.unit), k = e.number * e.addPrice);
        var I = (0, c.enablePlusSku)(t, e, n),
          E = t.groupChoiceType === r.GROUP_CHOICE_TYPE.REPEATABLE,
          x = (0, c.getOptionDishPriceStyle)(e),
          D = (0, c.getSelected)(e),
          S = l.default.getShopServiceData().fmpBizData,
          O = (0, o.dealPicLabelStyleType)(null != (u = null == S ? void 0 : S.picLabelStyleType) ? u : p.PIC_LABEL_STYLE_TYPE.DEFAULT),
          A = (0, a.getLimitDescList)(h, null, !0),
          b = (0, a.judgeComplexSpuDish)(e) || (0, a.judgeMultiDish)(e),
          _ = !(!(null == h || null == (s = h.tastes) ? void 0 : s.length) && !(null == h || null == (d = h.methods) ? void 0 : d.length));
        return {
          skuId: e.skuId,
          name: e.skuNameAndSpecAttr || e.skuName,
          count: e.count,
          picUrl: (null == h || null == (g = h.dishPicUrls) ? void 0 : g[r.PICTURE_RATIO.FOUR_TO_THREE]) || r.PLACEHOLDER_DISH_PIC.FOUR_TO_THREE,
          required: e.required,
          addPrice: k,
          selected: D,
          dishNum: T,
          enablePlus: I,
          enableRepeatPlus: E,
          specText: v,
          isDefaultTastes: f,
          specAttrsStyle: m,
          tastesText: P,
          optionDishPriceStyle: x,
          stockCount: h.stockCount,
          soldOut: e.soldOut,
          picLabelClass: O,
          picLabel: A,
          preventPlus: b,
          hasMethodsOrTastes: _
        }
      })), s = (0, c.setDishSize)(t, n), d = 0; d < u.length; d++)
      for (var g = d + 1; g < u.length;) {
        var h = u[g],
          f = h.selected,
          m = h.preventPlus,
          v = f && m ? "标准" : "",
          P = u[d].preventPlus,
          T = u[d].selected && P ? "标准" : "";
        if (u[d].skuId === u[g].skuId) {
          if (u[d].count += u[g].count, u[d].tastesText) u[d].tastesText += ";" + (u[g].tastesText || v);
          else {
            u[d].tastesText = u[d].tastesText || T;
            var k = u[g].tastesText;
            k && (u[d].tastesText += ";" + k)
          }
          u.splice(g, 1)
        } else {
          var I;
          u[d].tastesText = (null == (I = u[d]) ? void 0 : I.tastesText) || T, u[g].tastesText = u[g].tastesText || v, g++
        }
      }
    u.forEach((function(t) {
      if (t.tastesText) {
        var e, n = t.tastesText.split(";"),
          r = null == (e = Array.from(new Set(n))) ? void 0 : e.filter((function(t) {
            return !!t
          }));
        t.tastesText = r.join("; ")
      }
    }));
    var E = {
      groupId: t.groupId,
      groupType: t.groupType,
      titleList: [{
        type: "main",
        text: t.groupName
      }],
      list: u,
      size: s,
      isFixed: e
    };
    return t.groupType === r.GROUP_TYPE.OPTIONAL && (E.titleList = E.titleList.concat((0, c.getPackageOptionTitle)(t))), E
  })) : []
}, exports.TransSpecsOperateData = function(t) {
  if (!t.length) return null;
  var e = t[0],
    n = e.skuId,
    r = e.skuName,
    u = e.spuId,
    a = e.groupId,
    o = e.dishPicUrls,
    s = void 0 === o ? [] : o,
    c = [];
  return t.forEach((function(t) {
    if (t.count) {
      var e = d(t),
        n = e.allMethods,
        r = e.allTastes,
        u = [];
      n.length && n.forEach((function(t) {
        return t.name && u.push(t.name)
      })), r.length && r.forEach((function(t) {
        return t.name && u.push("".concat(t.name, "x").concat(t.count))
      }));
      for (var a = u.length > 0 ? u.join("，") : "", o = (Number(t.extraPrice) + Number(t.addPrice)) * (t.canWeight ? t.weight : t.number), s = 0; s < t.count; s++) c.push({
        goodsNo: t.goodsNo,
        totalPrice: (0, i.roundFloat)(o, 2),
        number: t.number,
        unit: t.unit,
        tastesAndMethodsText: a
      })
    }
  })), {
    groupId: a,
    skuId: n,
    skuName: r,
    spuId: u,
    dishPicUrl: s[0],
    skusList: c
  }
}, exports.TransPanelDetailsData = function(t) {
  var e = [],
    r = null == t ? void 0 : t.packageGroups;
  return r ? (r.forEach((function(t) {
    var r = (t.groupSkus || []).filter((function(t) {
      return t.count
    }));
    if (r.length) {
      var u = r.map((function(t) {
        var e = Number(t.extraPrice) + Number(t.addPrice) * (t.canWeight ? t.weight : t.number),
          r = "number" == typeof t.count && "number" == typeof t.number && t.number ? (0, i.multiFloat)(t.count, t.number) : t.count;
        return n({
          skuId: t.skuId,
          skuName: t.skuName,
          spuId: t.spuId,
          count: r,
          totalPrice: (0, i.roundFloat)(e, 2)
        }, function(t) {
          var e = t.specAttrs,
            n = t.canWeight,
            r = e || [],
            u = d(t),
            a = u.allMethods,
            o = u.allTastes,
            i = [],
            s = [];
          if (n) {
            var c = t.weight,
              l = t.unit;
            i.push("".concat(c).concat(l))
          }
          return r.length && r.forEach((function(t) {
            return t.value && i.push(t.value)
          })), a.length && a.forEach((function(t) {
            return t.name && i.push(t.name)
          })), o.length && o.forEach((function(t) {
            return t.name && s.push("".concat(t.name, "x").concat(t.count))
          })), {
            specAndMethods: i.length > 0 ? i.join("，") : "",
            tastes: s.length > 0 ? s.join("，") : ""
          }
        }(t))
      }));
      e.push({
        groupId: t.groupId,
        groupName: t.groupName,
        groupSkus: u
      })
    }
  })), e) : []
};