var e = require("../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.unBindThirdAccount = exports.queryPageInfo = exports.queryBindStatus = exports.getSortCodeByUserId = exports.getShareInfo = exports.getNaviBar = exports.getIndividualitySelfCenterInfo = exports.getDecoratePortalInfo = exports.getCardWithoutVip = void 0;
var t = require("../b/helpers/objectSpread2"),
  r = e(require("../lib/mix/request")),
  a = require("../lib/mix/util"),
  n = e(require("../miniprogram_npm/@mtfe/rms-triangle-c/index.js")),
  o = e(require("./rmsStorage-main"));
exports.getNaviBar = function(e) {
  return (0, r.default)({
    method: "get",
    url: "/queryNaviBar",
    params: e
  })
};
exports.getShareInfo = function(e) {
  return (0, r.default)({
    method: "get",
    url: (0, a.getHost)() + "/api/v1/rmsmina/c/queryShareInfo",
    params: e
  })
};
exports.getIndividualitySelfCenterInfo = function(e) {
  return e.ts = Date.now(), (0, r.default)({
    method: "get",
    url: (0, a.getHost)() + "/api/v1/rmsmina/c/querySelfcenterInfo",
    params: e,
    openShark: !0
  })
};
exports.getCardWithoutVip = function(e, t) {
  return r.default.post((0, a.getLoginHost)() + "/api/v1/crm/frontend/card/add-wct-card", e, {
    withCredentials: !0,
    headers: t || {}
  })
};
exports.unBindThirdAccount = function(e) {
  return r.default.post((0, a.getHost)() + "/diancan/api/relate/unbind", e, {
    withCredentials: !0
  })
};
exports.getSortCodeByUserId = function(e) {
  return (0, r.default)({
    method: "get",
    url: (0, a.getHost)() + "/diancan/api/token/require",
    params: e,
    withCredentials: !0
  })
};
exports.queryBindStatus = function() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
  return e.ts = Date.now(), r.default.post((0, a.getHost)() + "/diancan/api/relate/queryBindDetail", e, {
    withCredentials: !0
  })
};
exports.getDecoratePortalInfo = function(e) {
  return (0, r.default)({
    method: "get",
    url: (0, a.getHost)() + "/api/v1/rmsmina/c/queryPortalInfo",
    params: e,
    timeout: 1e4
  })
};
exports.queryPageInfo = function(e) {
  return (0, r.default)({
    method: "get",
    url: n.default.isByteDance ? (0, a.getHost)() + "/api/v1/rmsmina/c/queryPageInfo" : (0, a.getHost)() + "/diancan/api/decoration/queryPageInfo",
    params: t(t({}, e), {}, {
      customChannel: o.default.getCustomChannel()
    })
  })
};