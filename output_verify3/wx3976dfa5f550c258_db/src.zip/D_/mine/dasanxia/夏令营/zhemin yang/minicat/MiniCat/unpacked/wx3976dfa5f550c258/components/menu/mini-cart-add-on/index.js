var e = require("../../../b/helpers/interopRequireDefault"),
  t = require("../../../b/helpers/objectSpread2"),
  i = require("../../../miniprogram_npm/@limo/container/behaviors/index"),
  r = require("../../../modules/menu/dish/expose"),
  o = e(require("../../../miniprogram_npm/seamless-immutable/index.js")),
  s = require("../../../store/actions/add-on"),
  a = e(require("../../../store/menu")),
  n = e(require("../../../store/helpers/storeBehavior"));
Component({
  behaviors: [n.default, i.commonBehavior, i.limoShim],
  properties: {
    addOnList: {
      type: Array,
      value: []
    },
    isShowAddOn: {
      type: Boolean,
      value: !1
    }
  },
  created: function() {
    this.store = a.default
  },
  methods: {
    limoReady: function() {
      this.helpersStoreBehavior_limoReady()
    },
    mapToState: function(e) {
      return {
        addOnTips: o.default.getIn(e, ["addOn", "tips"]) || "",
        shopId: o.default.getIn(e, ["cart", "shopId"])
      }
    },
    setAddOnShow: function(e) {
      this.store.dispatch((0, s.setAddOnShowAction)(e))
    },
    closeAddOnPanel: function() {
      this.setAddOnShow(!1)
    },
    dealPanelData: function(e) {
      var i = e.currentTarget.dataset.skuid;
      this.triggerEvent("operationPanel", t(t({}, e.detail), {}, {
        skuId: i,
        exposeDishType: r.EXPOSE_DISH_TYPE.ADDON
      }), {
        bubbles: !0,
        composed: !0
      })
    },
    operateDish: function(e) {
      var i = e.currentTarget.dataset.skuid;
      this.triggerEvent("operateDish", t(t({}, e.detail), {}, {
        skuId: i
      }), {
        bubbles: !0,
        composed: !0
      })
    },
    openDetail: function(e) {
      var t = e.detail.dish;
      this.triggerEvent("openDishDetail", {
        dish: t
      }, {
        bubbles: !0,
        composed: !0
      })
    }
  },
  ready: function() {
    this.limoReady()
  }
});