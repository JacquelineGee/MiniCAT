var t = require("../../../@limo/container/behaviors/index"),
  e = require("../../limo-ui/ui-constant/enum");
Component({
  behaviors: [t.commonBehavior, t.limoShim],
  properties: {
    orderList: {
      type: Array,
      value: []
    },
    status: {
      type: Number,
      value: 0,
      observer: function(t) {
        this.setData({
          listStatus: t
        })
      }
    }
  },
  data: {
    listStatus: 0
  },
  methods: {
    reachBottom: function() {
      this.data.status === e.LOADING.DONE && (this.setData({
        listStatus: e.LOADING.DOING
      }), this.triggerEvent("requestList"))
    },
    orderItemClick: function(t) {
      var e = t.detail,
        r = e.type,
        i = e.orderData;
      this.triggerEvent("btnClick", {
        order: i,
        type: r
      })
    },
    refreshPage: function() {
      this.triggerEvent("refreshPage")
    }
  }
});