var e = require("../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.default = void 0;
var t = e(require("../lib/mix/request")),
  a = require("../lib/mix/util"),
  r = {
    getTakeawayInfoReq: function(e) {
      return t.default.get((0, a.getTakeAwayHost)() + "/api/rmstakeaway/queryWmConfig", {
        params: e
      })
    },
    getUserAddressList: function(e) {
      return t.default.get((0, a.getTakeAwayHost)() + "/api/rmstakeaway/pullAddress", {
        params: e
      })
    },
    getClosestShop: function(e) {
      return t.default.get((0, a.getTakeAwayHost)() + "/api/rmstakeaway/v2/preferredShop", {
        params: e
      })
    },
    matchShop: function(e) {
      return t.default.post((0, a.getHost)() + "/diancan/api/shopList/matchShop", e, {
        withCredentials: !0
      })
    }
  };
exports.default = r;