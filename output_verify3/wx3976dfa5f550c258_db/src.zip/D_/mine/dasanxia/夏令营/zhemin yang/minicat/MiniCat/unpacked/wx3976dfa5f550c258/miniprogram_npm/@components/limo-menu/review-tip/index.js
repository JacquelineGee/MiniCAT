var e = require("../../../@limo/container/behaviors/index");
Component({
  behaviors: [e.commonBehavior, e.limoShim],
  properties: {
    rewardType: {
      type: Number,
      value: 0,
      observer: function(e) {
        this.initData(e)
      }
    }
  },
  data: {
    dealBg: ""
  },
  methods: {
    initData: function(e) {
      var t = "";
      switch (e) {
        case 1:
          t = "https://p0.meituan.net/ingee/88332d8643389908b1475a7402842c9120408.png";
          break;
        case 2:
          t = "https://p0.meituan.net/scarlett/f41b0f1e31c23ece01380474fa868a367854.png"
      }
      t && this.setData({
        dealBg: t
      })
    }
  }
});