var e = require("../../../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.updateDishListSingleton = exports.getChangedMaps = exports.getCategoryType = exports.filterItemKeys = exports.dealHotSaleTag = exports.computePointItemCount = exports.computeItemCount = exports.categoryDisplay = exports.GetDishListSingleton = void 0;
require("../../../b/helpers/defineProperty");
var t = require("../../../b/helpers/typeof"),
  r = require("../../../constants/bizConstants"),
  n = require("../../../constants/menu"),
  i = (require("../../../lib/wx/transfer-rpx"), require("../../dishHelper"), require("../../../miniprogram_npm/@components/limo-ui/ui-constant/enum")),
  o = e(require("../../../api/rmsStorage")),
  s = e(require("../../../store/menu")),
  u = e(require("../../../lib/mix/log")),
  a = ["cssType", "rank", "picTag", "picUrl", "picLabel", "hotSellingTag", "name", "desc", "recommendTags", "saleQuantity", "saleQuantityStr", "sampleTagList", "currency", "currentPrice", "priceSmallFont", "originalPrice", "unit", "orderedSize", "preventSale", "tagListSize", "dishDescribeTag", "hiddenCurrency", "isPointPurchaseCategory", "estimatedPrice"],
  c = u.default;
exports.categoryDisplay = function(e, t, r, n) {
  if (e) {
    var i = [];
    return null == t || t.forEach((function(e) {
      e.spuIds && e.spuIds.length > 0 && (i = Array.prototype.concat(i, e.spuIds))
    })), {
      display: !0,
      spuIdArr: Array.prototype.concat(r || [], i)
    }
  }
  var o = null == r ? void 0 : r.filter((function(e) {
    return n && n[e]
  }));
  return t && t.length ? {
    display: !0,
    spuIdArr: r || []
  } : o && 0 !== o.length ? {
    display: !0,
    spuIdArr: o
  } : {
    display: !1,
    spuIdArr: []
  }
}, exports.dealHotSaleTag = function(e) {
  return void 0 === e ? "" : i.HOT_SELLING_TYPE.PRICE_WITH_PIC.some((function(t) {
    return t === e
  })) ? "priceTag" : "recTag"
}, exports.getCategoryType = function(e) {
  var t = "text";
  return e !== r.DISH_CATEGORY_ID.HOT && e !== r.DISH_CATEGORY_ID.RECOMMEND || (t = "icon"), t
}, exports.getChangedMaps = function(e, t) {
  var r = {};
  return e && Object.keys(e).forEach((function(n) {
    t && t[n] && e[n] === t[n] || (r[n] = e[n])
  })), t && Object.keys(t).forEach((function(t) {
    e[t] || (r[t] = 0)
  })), r
}, exports.computePointItemCount = function(e) {
  var r = {};
  return e && "object" == t(e) && Object.keys(e).forEach((function(t) {
    e[t].forEach((function(e) {
      e.discount === n.POINT_DISH_TYPE && (e.canWeight || e.weight ? r[+e.spuId] = e.weight : r[e.spuId] ? r[+e.spuId] += e.count : r[+e.spuId] = e.count)
    }))
  })), r
}, exports.computeItemCount = function(e) {
  var r = {};
  return e && "object" == t(e) && Object.keys(e).forEach((function(t) {
    e[t].forEach((function(e) {
      e.canWeight || e.weight ? r[+e.spuId] = e.weight : r[e.spuId] ? r[+e.spuId] += e.count : r[+e.spuId] = e.count
    }))
  })), r
};
var p = function(e) {
  return this.instance || (this.instance = function(e) {
    var t, r = o.default.getDishList(e);
    if (r && Object.keys(r).length) return r;
    c.addError("获取rmsStorage菜品里的菜品数据为空");
    var n = s.default.getState();
    return r = (null == n || null == (t = n.dish) ? void 0 : t.dishList) || {}
  }(e)), this.instance
};
exports.filterItemKeys = function(e, t) {
  var r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : [],
    i = {
      cssType: n.DISH_ITEM_CSS_TYPE_VAL[e]
    };
  return (r.length ? a.concat(r) : a).forEach((function(e) {
    t && t[e] && (i[e] = t[e])
  })), i
}, exports.updateDishListSingleton = function(e, t) {
  new p(e);
  return t
}, exports.GetDishListSingleton = p;