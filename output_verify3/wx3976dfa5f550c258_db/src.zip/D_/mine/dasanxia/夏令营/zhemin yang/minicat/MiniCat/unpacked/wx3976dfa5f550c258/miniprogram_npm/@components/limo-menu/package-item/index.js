var e = require("../../../../b/helpers/interopRequireDefault"),
  t = require("../../../@limo/container/behaviors/index"),
  i = require("../../../../constants/bizConstants"),
  s = e(require("../../../../modules/menu/shop/shopService")),
  a = e(require("../../../../modules/menu/I18n/I18nService"));
Component({
  behaviors: [t.commonBehavior, t.limoShim],
  properties: {
    isDefaultTastes: {
      type: Boolean,
      value: !0
    },
    spuComboShowType: {
      type: Number,
      value: 0,
      observer: function() {
        this.setActiveBorder()
      }
    },
    isFixed: {
      type: Boolean,
      value: !1,
      observer: function() {
        this.setActiveBorder()
      }
    },
    size: {
      type: String,
      value: ""
    },
    enablePlus: {
      type: Boolean,
      value: !0,
      observer: function() {
        this.setOperation()
      }
    },
    enableRepeatPlus: {
      type: Boolean,
      value: !1,
      observer: function() {
        this.setOperation()
      }
    },
    selected: {
      type: Boolean,
      value: !1,
      observer: function() {
        this.setActiveBorder()
      }
    },
    tastesText: {
      type: String,
      value: ""
    },
    addPrice: {
      type: Number,
      value: 0
    },
    specText: {
      type: String,
      value: ""
    },
    specAttrsStyle: {
      type: String,
      value: "specAttrs ellipsis"
    },
    dishNum: {
      type: String,
      value: ""
    },
    required: {
      type: Boolean,
      value: !1
    },
    optionDishPriceStyle: {
      type: String,
      value: "option-dish-price "
    },
    picUrl: {
      type: String,
      value: ""
    },
    picLabel: {
      type: String,
      value: ""
    },
    picLabelClass: {
      type: String,
      value: ""
    },
    soldOut: {
      type: Boolean,
      value: !1,
      observer: function() {
        this.setActiveBorder()
      }
    },
    stockCount: {
      type: Number,
      value: 1e4
    },
    name: {
      type: String,
      value: ""
    },
    count: {
      type: Number,
      value: 0,
      observer: function() {
        this.setOperation(), this.setActiveBorder()
      }
    },
    preventPlus: {
      type: Boolean,
      value: !1,
      observer: function() {
        this.setOperation()
      }
    },
    isDetail: {
      type: Boolean,
      value: !1
    }
  },
  data: {
    tagShow: !1,
    isNoPic: !1,
    remText: "",
    borderClass: "",
    cardNumClass: "",
    operationData: {},
    SOLD_OUT_TEXT: i.SOLD_OUT_TEXT,
    isNewLineOperation: !1
  },
  attached: function() {
    this.limoAttached()
  },
  methods: {
    limoAttached: function() {
      this.setTagShow(), this.setOperationStyle(), this.setCardNum(), this.setActiveBorder();
      var e = a.default.getCurrency();
      this.setData({
        currency: e
      })
    },
    setCardNum: function() {
      var e = this.data,
        t = e.spuComboShowType,
        s = e.isFixed,
        a = e.enableRepeatPlus,
        n = "card-num ellipsis ";
      t === i.PACKAGE_TEMPLATE_TYPE.NO_PIC ? n += "num-bottom" : s || a || (n += "num-bottom"), this.setData({
        cardNumClass: n
      })
    },
    setActiveBorder: function() {
      var e = this.data,
        t = e.count,
        s = e.selected,
        a = e.isFixed,
        n = e.soldOut,
        o = e.spuComboShowType === i.PACKAGE_TEMPLATE_TYPE.NO_PIC,
        r = o ? "no-pic-dish " : "";
      a || !(t > 0 || s) || n ? !o && (r += "inner-default") : r += "inner-active", this.setData({
        borderClass: r
      })
    },
    setTagShow: function() {
      var e = !1,
        t = "",
        s = this.data,
        a = s.isFixed,
        n = s.required,
        o = s.picLabel,
        r = s.spuComboShowType === i.PACKAGE_TEMPLATE_TYPE.NO_PIC;
      r && (t = o), a || !n && !t || (e = !0), this.setData({
        tagShow: e,
        isNoPic: r,
        remText: t
      })
    },
    setOperation: function() {
      var e, t = this.data,
        i = t.count,
        a = t.enablePlus,
        n = t.preventPlus,
        o = s.default.getShopServiceData().fmpBizData;
      this.setData({
        operationData: {
          type: "NUMBER",
          count: i,
          disablePlus: !a,
          preventPlus: n,
          showDishOperation: null == (e = null == o ? void 0 : o.showDishOperation) || e
        }
      })
    },
    checkRadio: function() {
      this.data.selected ? this.minusSkuDishFunc() : this.selectTastesFunc()
    },
    addPanelSku: function() {
      this.triggerEvent("addToCart")
    },
    selectTastesFunc: function() {
      this.triggerEvent("addToCart")
    },
    dishHandleFn: function(e) {
      var t = e.detail.operation;
      "plus" === t ? this.selectTastesFunc() : "minus" === t && this.minusSkuDishFunc()
    },
    minusSkuDishFunc: function() {
      this.triggerEvent("minusPackageSkuDish")
    },
    setOperationStyle: function() {
      var e = this.data,
        t = e.isNoPic,
        i = e.isDefaultTastes,
        s = e.isFixed,
        a = e.enableRepeatPlus;
      this.setData({
        isNewLineOperation: !t && (s && !i || a)
      })
    },
    clickSpecInfoFn: function() {
      this.data.selected && this.triggerEvent("clickSpecInfo")
    },
    onTapPanelDish: function() {
      var e = this.data,
        t = e.isFixed,
        i = e.isDefaultTastes,
        s = e.enableRepeatPlus,
        a = e.soldOut;
      i && t || a || (!i && t ? this.addPanelSku() : s || this.checkRadio())
    }
  }
});