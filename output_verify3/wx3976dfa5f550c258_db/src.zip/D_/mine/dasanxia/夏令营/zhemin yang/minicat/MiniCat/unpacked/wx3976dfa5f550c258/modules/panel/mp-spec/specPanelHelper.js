Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.computeDishAddPrice = void 0, exports.getDishDesc = function(e, r) {
  return function(e, t) {
    var r, u, n = t && t.skuMenuItems && t.skuMenuItems.find((function(t) {
      return t.skuId === e.skuId
    }));
    return (u = (null == n || null == (r = n.specAttrs) || null == (r = r[0]) ? void 0 : r.value) || "") && t.skuMenuItems.length > 1 ? [u] : []
  }(e, r).concat((0, t.getDishMethodDesc)((null == e ? void 0 : e.methods) || [], null == r ? void 0 : r.methods)).concat((0, t.getDishTasteDesc)((null == e ? void 0 : e.tastes) || [])).join("/")
}, exports.getMemberTag = void 0;
var e = require("../../../lib/number"),
  t = require("../spec/util");
exports.getMemberTag = function(t, r) {
  var u = t.memberPrice;
  return -1 === u ? -1 : (void 0 !== r && (u = r ? t.memberPrice ? (0, e.plusFloat)((0, e.multiFloat)(t.memberPrice, t.weight), t.extraPrice) : void 0 : t.memberPrice ? (0, e.plusFloat)(t.memberPrice, t.extraPrice) : void 0), u)
};
exports.computeDishAddPrice = function(t) {
  var r = t.methods,
    u = t.tastes,
    n = 0;
  return r && r.length > 0 && (null == r || r.map((function(t) {
    var r;
    return null == t || null == (r = t.items) || r.map((function(t) {
      return n = (0, e.plusFloat)(n, t.price), null
    })), null
  }))), u && u.length > 0 && u.map((function(t) {
    return t.items.map((function(t) {
      var r = (0, e.multiFloat)(t.price, t.count);
      return n = (0, e.plusFloat)(n, r), null
    })), null
  })), n
};