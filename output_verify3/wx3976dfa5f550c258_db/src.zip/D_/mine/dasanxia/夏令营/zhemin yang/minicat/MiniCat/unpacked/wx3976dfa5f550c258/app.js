var e = require("b/helpers/interopRequireDefault"),
  r = require("b/helpers/objectSpread2"),
  n = e(require("./miniprogram_npm/@limo/core/index.js")),
  t = e(require("./miniprogram_npm/@analytics/wechat-sdk/index.js")),
  i = require("./miniprogram_npm/@dp/owl-wxapp/index.js"),
  o = require("./lib/wx/app-info"),
  a = e(require("./miniprogram_npm/@mtfe/rms-triangle-c/index.js")),
  u = e(require("./lib/wx/log")),
  p = require("./lib/env"),
  s = require("./modules/menu/dataSource/PreLoadDataSource"),
  d = require("./modules/pointReport"),
  c = require("./lib/wx/init"),
  m = require("./lib/wx/pike"),
  l = require("./lib/wx/logan"),
  f = require("./lib/wx/shark"),
  h = require("./lib/wx/safety"),
  g = require("./lib/wx/privacy"),
  q = require("./lib/wx/logConfig"),
  v = e(require("./miniprogram_npm/@mtfe/saas-user-auth/index.js")),
  L = e(require("./api/rmsStorage-main")),
  x = require("./miniprogram_npm/@mtfe/rms-sdk/index.js"),
  R = require("./config/index.js"),
  b = require("./pages/user/common"),
  C = require("./prefetch/order-list"),
  y = require("./pages/custom-page/common"),
  O = a.default.Reporter(q.TRIANGLE_INIT_CONFIG);
(0, i.app)({
  report: {
    reportLaunch: !1,
    launchTimeFromScan: 0,
    launchStartTime: 0
  },
  isHide: !1,
  cache: {},
  spuCache: {},
  userInfo: void 0,
  appTemplate: "1",
  onLaunch: function(e) {
    var n, w = this;
    (0, x.initEnv)("production");
    var I, S, E = (0, x.getEnv)();
    (0, m.initPike)(), (0, l.initLogan)(), (0, f.initShark)(), (0, h.initSafetyRequest)(E), (0, g.initPrivacy)(), I = E, t.default.init("https://report.meituan.com", {
        appnm: "rms_smdc",
        category: "saaspay"
      }), "production" !== I && t.default.dev(!0), t.default.start(), x.LXReporter.mpOnLaunch({
        lx: t.default
      }), null != e && null != (n = e.query) && n.promotionMonitoring && x.LXReporter.initAppPromotionMonitoring(null == e || null == (S = e.query) ? void 0 : S.promotionMonitoring), (0, c.initApp)(this), (0, x.initHeaderVersion)(R.VERSION_CODE, R.VERSION, "1"), this.miniProgramData.setTabbarPageInfo(), u.default.reportMetric("appLaunch"),
      function(e, r) {
        var n = r.scene;
        1011 !== n && 1012 !== n && 1013 !== n || (e.report.launchTimeFromScan = Date.now())
      }(this, e), this.performanceObserver = (0, d.performanceObserver)(this), "release" === (0, p.getWxEnvVersion)() && (0, x.updateApp)(!0, {
        scene: "appOnLaunch"
      }),
      function(e, n) {
        1129 !== e.scene && (i.owl.start(r(r({}, q.OWL_INIT_CONFIG), {}, {
          devMode: "production" !== n
        })), q.OWL_SUBPKG_INFO.forEach((function(e) {
          return (0, i.registerProject)(e)
        })))
      }(e, E), x.advertiseReporter.init({
        timeout: 2e3,
        maxSize: 2,
        source: 1e3
      }), O.sendInfo({
        name: "appOnLaunch",
        content: {
          options: e
        }
      }), v.default.handleWxPrefetch({
        env: E,
        LXReporter: x.LXReporter,
        getEnvHeader: x.getEnvHeader,
        Log: u.default,
        sendLxHelper: {
          sendMV: x.LXReporter.sendMV
        },
        prefetchCallback: function() {
          return (0, s.preloadData)(w, e)
        }
      }), L.default.removeCustomChannel(), x.Theme.clearThemeCache({
        forceClear: !0
      }), a.default.preload.register([{
        path: "/pages/user/index",
        key: "userPageMainRequestData",
        jumpBefore: function(e) {
          return (0, b.createUserInfoRequest)(e)
        }
      }, {
        path: "/pages/order-list/index",
        key: "orderListPageMainRequestData",
        jumpBefore: function(e) {
          return (0, C.createOrderListRequest)(e)
        }
      }, {
        path: "/pages/custom-page/index",
        key: "customPageMainRequestData",
        jumpBefore: function(e) {
          return (0, y.createCustomPageRequest)(e)
        }
      }]), (0, o.isMerchantWxApp)() && x.ThemeControl.initTheme({
        fail: function(e) {
          u.default && u.default.addError(e)
        }
      })
  },
  onShow: function(e) {
    var r, n;
    this.isHide || u.default.addCustom("appColdShowCount", 1, {
      who: 3
    }), this.isHide = !1, u.default.addCustom("appShowCount", 1, {
      who: 3
    }), O.sendInfo({
      name: "appOnShow",
      content: {
        options: e
      }
    }), this.setQrCode(e), x.Theme.clearThemeCache({
      options: e
    }), this.performanceObserver && this.performanceObserver.observe({
      entryTypes: ["navigation", "loadPackage"]
    }), x.LazyLoad.onError(), x.Log.getLoganInstance() || (0, l.initLogan)(), null != e && null != (r = e.query) && r.promotionMonitoring && x.LXReporter.initAppPromotionMonitoring(null == e || null == (n = e.query) ? void 0 : n.promotionMonitoring)
  },
  setQrCode: function(e) {
    e.query && e.query.qrCode && (this.qrCode = e.query.qrCode)
  },
  onHide: function() {
    this.isHide = !0, this.report.launchStartTime = 0, this.performanceObserver && this.performanceObserver.disconnect(), O.sendInfo({
      name: "appOnHide"
    }), x.advertiseReporter.clearStuck(), t.default.quit(), x.LazyLoad.offError()
  },
  onError: function(e) {
    O.sendInfo({
      level: "ERROR",
      name: "app-onError",
      content: {
        error: e
      }
    })
  },
  onPageNotFound: function(e) {
    "release" === (0, p.getWxEnvVersion)() && (0, x.updateApp)(!0, {
      scene: "onPageNotFound"
    }), n.default.getLimoRuntime().redirectTo({
      url: "/diancan-menu/pages/error-tip/index?type=6"
    }), O.sendInfo({
      level: "ERROR",
      name: "onPageNotFound",
      content: {
        options: e
      }
    })
  }
});