Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.REVIEW_STATUS = void 0;
exports.REVIEW_STATUS = {
  WAIT_COMMENT: 1,
  WAIT_PUSH_COMMENT: -5,
  WAIT_REWARD: 4,
  EVALUATED: 3
};