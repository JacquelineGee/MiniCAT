var t = require("../../../../b/helpers/interopRequireDefault")(require("../../../@limo/core/index.js")),
  e = require("../../../@limo/container/behaviors/index"),
  a = require("./orderListHelper"),
  o = require("../../../../constants/review"),
  i = require("../../../../modules/LXHelper"),
  r = ["", "预点餐", "外卖", "自提", "自提", "外卖", ""];
Component({
  behaviors: [e.commonBehavior, e.limoShim],
  properties: {
    orderData: {
      type: Object,
      value: {}
    },
    fromPage: {
      type: String,
      value: ""
    }
  },
  observers: {
    orderData: function(t) {
      this.initData(t), this.initCountdown(t)
    }
  },
  data: {
    orderType: "",
    statusMsgColor: "",
    dishCount: "",
    viewBarCode: "",
    actualCost: "",
    rewardType: 0,
    showReward: !1,
    showBtnPane: !1,
    btnList: [],
    orderViewId: "",
    dishSummaryList: [],
    offset: 10,
    description: "",
    bizType: 0,
    orderGroupId: "",
    totalNum: 0,
    defaultImg: "https://p0.meituan.net/scarlett/ca45859124838c068622a75a818b064a1640.jpg"
  },
  attached: function() {
    this.limoAttached()
  },
  methods: {
    limoAttached: function() {
      var t = this.properties.orderData;
      this.initData(t), this.initCountdown(t)
    },
    initCountdown: function(t) {
      var e, o, i, r, n = this;
      (null == t || null == (e = t.countDownInfo) ? void 0 : e.expireSeconds) > 0 && !this.countdown && (this.countdown = new a.Countdown(t.countDownInfo.expireSeconds || 0, (function() {
        var e;
        n.setData({
          expireSeconds: ""
        }), null != (e = t.countDownInfo) && e.expireSeconds && n.triggerEvent("refreshPage")
      }), (function(t) {
        n.setData({
          expireSeconds: t
        })
      })), null == (i = this.countdown) || i.start()), null != t && null != (o = t.countDownInfo) && o.expireSeconds || (null == (r = this.countdown) || r.clearTimeout(), this.countdown = null, this.setData({
        expireSeconds: ""
      }))
    },
    initData: function(e) {
      var i = e.type,
        n = e.orderStatus,
        s = e.reviewButtonVO,
        d = e.orderViewId,
        u = e.currency,
        l = void 0 === u ? "¥" : u,
        c = e.orderItemExtra || {},
        m = c.showUrgeButton,
        p = c.needCost,
        v = c.dishCount,
        h = c.actualCost,
        w = c.viewBarCode,
        f = c.orderPageLiteOdcDetail,
        g = c.orderGroupIdV2,
        b = r[i] || "",
        T = (0, a.getInvoiceBtn)(e),
        y = (0, a.getStatusMsgColor)(n),
        C = f || {},
        I = C.dishSummaryList,
        S = C.totalNum,
        L = (0, a.showReviewBtn)(n, s),
        D = L.isShowCommentBtn,
        x = L.isShowReviewReward,
        _ = (null == s ? void 0 : s.reviewStatus) === o.REVIEW_STATUS.WAIT_REWARD,
        R = ((null == s ? void 0 : s.reviewStatus) === o.REVIEW_STATUS.EVALUATED || _) && (null == s ? void 0 : s.actionUrl),
        N = m || p || (null == T ? void 0 : T.available) || D || R,
        V = (null == s ? void 0 : s.rewardType) || 0,
        E = [];
      if (D && t.default.getLimoRuntime().sendMV({
          valLab: null,
          bid: "b_saaspay_jyek9qgr_mv",
          options: {}
        }), N) {
        var B = T.available,
          O = T.btnTxt,
          q = "pay-btn",
          M = [{
            state: p,
            btnText: "去支付",
            className: q,
            type: "gotoPay"
          }, {
            state: !_ && D,
            btnText: "去评价",
            className: "invoice-btn",
            type: "goComment"
          }, {
            state: R,
            btnText: "查看评价",
            className: "invoice-btn",
            type: "goComment"
          }];
        "order-list" === this.properties.fromPage && (M.splice(0, 0, {
          state: B,
          btnText: O,
          className: "invoice-btn",
          type: "toInvoice"
        }), M.splice(2, 0, {
          state: m,
          btnText: "催单",
          className: q,
          type: "urgeOrder"
        })), E = M.filter((function(t) {
          return t.state
        }))
      }
      this.setData({
        orderType: b,
        statusMsgColor: y,
        dishCount: v,
        showBtnPane: N,
        rewardType: V,
        btnList: E,
        showReward: !(!x || !D),
        actualCost: h || "",
        viewBarCode: w || "",
        orderViewId: d,
        dishSummaryList: I,
        bizType: i,
        orderGroupId: g,
        totalNum: S,
        currency: l
      })
    },
    gotoDetail: function() {
      var e;
      t.default.getLimoRuntime().sendMC({
        valLab: null,
        bid: "b_saaspay_go2t8s76_mc",
        options: {}
      });
      var a = ((null == (e = this.data) ? void 0 : e.orderData) || {}).redirectSchema;
      a && this.wxNavigateTo(a)
    },
    scrolllower: function() {
      var e = this,
        a = this.data,
        o = a.offset,
        i = a.orderViewId,
        r = a.bizType,
        n = a.orderGroupId,
        s = a.totalNum,
        d = a.dishSummaryList;
      o < s && t.default.getLimoRuntime().request({
        url: "trade/pageLiteOrderDetail",
        method: "POST",
        data: {
          orderViewId: i,
          orderGroupId: n,
          num: 10,
          offset: o,
          bizType: r
        },
        complete: function(t) {
          if (t.data && 200 === t.data.code && t.data.data) {
            var a = t.data.data.dishSummaryList;
            e.setData({
              dishSummaryList: d.concat(a),
              offset: o + 10
            })
          }
        }
      })
    },
    btnClick: function(e) {
      var o = this.data.orderData,
        r = e.currentTarget.dataset || e.currentTarget,
        n = r.type,
        s = r.btnText;
      if ("goComment" !== n) s === a.INVOICETXT.TO_INVOICE && t.default.getLimoRuntime().sendMC && t.default.getLimoRuntime().sendMC({
        valLab: null,
        bid: "b_saaspay_ewpmgjhq_mc",
        options: {}
      }), s === a.INVOICETXT.INVOICE_STATUS && t.default.getLimoRuntime().sendMC && t.default.getLimoRuntime().sendMC({
        valLab: null,
        bid: "b_saaspay_95mr52bi_mc",
        options: {}
      }), this.triggerEvent("orderItemClick", {
        type: n,
        orderData: o
      });
      else {
        var d;
        (0, i.sendMC)("b_saaspay_jyek9qgr_mc");
        var u = null == o || null == (d = o.reviewButtonVO) ? void 0 : d.actionUrl;
        this.wxNavigateTo(u)
      }
    },
    wxNavigateTo: function(e) {
      t.default.getLimoRuntime().navigateTo({
        url: e
      })
    }
  }
});