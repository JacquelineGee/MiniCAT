var t = require("../../../@limo/container/behaviors/index");
Component({
  behaviors: [t.commonBehavior, t.limoShim],
  options: {
    multipleSlots: !0
  },
  properties: {
    hasCloseBtn: {
      type: Boolean,
      value: !1
    },
    title: {
      type: String,
      value: ""
    },
    body: {
      type: String,
      value: ""
    },
    buttons: {
      type: Array,
      value: [{
        text: "取消",
        type: "cancel"
      }, {
        text: "确定",
        type: "submit"
      }]
    }
  },
  data: {},
  methods: {
    btnClick: function(t) {
      this.closeDialog();
      var e = t.currentTarget.type || t.currentTarget.dataset.type,
        i = this.properties.buttons,
        o = null == i ? void 0 : i.find((function(t) {
          return e === t.type
        }));
      o.callback ? o.callback() : this.triggerEvent("confirmBtnClick", e)
    }
  }
});