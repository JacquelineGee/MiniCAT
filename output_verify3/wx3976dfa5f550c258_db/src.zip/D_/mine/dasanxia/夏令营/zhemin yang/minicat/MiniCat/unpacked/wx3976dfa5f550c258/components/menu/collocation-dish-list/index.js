var e = require("../../../b/helpers/interopRequireDefault"),
  t = require("../../../b/helpers/objectSpread2"),
  o = require("../../../miniprogram_npm/@limo/container/behaviors/index"),
  i = require("../../../constants/menu"),
  n = require("../../../store/actions/cart"),
  a = require("../../../modules/collocation/lx"),
  l = e(require("../../../store/menu")),
  r = e(require("../../../store/helpers/storeBehavior"));
Component({
  behaviors: [r.default, o.commonBehavior, o.limoShim],
  options: {
    addGlobalClass: !0
  },
  properties: {
    collocationContainerData: {
      type: Object,
      value: {}
    },
    options: {
      type: Object,
      value: {}
    },
    dishShowType: {
      type: String,
      value: i.DISH_ITEM_TYPE_VAL.DEFAULT,
      observer: function(e) {
        this.setData({
          isDefaultStyle: e === i.DISH_ITEM_TYPE_VAL.DEFAULT || e === i.DISH_ITEM_TYPE_VAL.RIGHT_LARGE
        })
      }
    }
  },
  data: {
    trianglePositionStyle: "collocation-SUPER_LARGE-0",
    isDefaultStyle: !0
  },
  created: function() {
    this.store = l.default
  },
  attached: function() {
    this.limoAttached()
  },
  observers: {
    "dishShowType,dishRowIndex": function(e, t) {
      this.setData({
        trianglePositionStyle: "collocation-".concat(e, "-").concat(t)
      })
    },
    collocationContainerData: function(e) {
      e && Object.keys(e).length && this.setData(t({}, e))
    }
  },
  methods: {
    limoAttached: function() {
      this.collocationMVFn()
    },
    limoReady: function() {
      this.helpersStoreBehavior_limoReady()
    },
    operateCollocationDish: function(e, t, o) {
      this.store.dispatch((0, n.operateCollocationDish)(e, t, o))
    },
    dealPanelDataFunc: function(e) {
      this.triggerEvent("dealCollocationPanelData", e.detail)
    },
    operateDishFunc: function(e) {
      var t = e.detail,
        o = t.id,
        i = t.skuId,
        n = t.type;
      this.operateCollocationDish(o, i, n)
    },
    collocationMVFn: function() {
      var e, t = this.data,
        o = t.list,
        i = void 0 === o ? [] : o,
        n = t.menuIndex,
        l = void 0 === n ? "" : n,
        r = t.spuId,
        s = void 0 === r ? "" : r,
        c = (null == (e = i[0]) || null == (e = e.__newReportConfig__) ? void 0 : e.recommendMode) || 1;
      (0, a.menuCollocationMV)({
        mainSpuId: s,
        spuCnt: i.length,
        menuIndex: l,
        recommendMode: c
      })
    },
    exposeDish: function(e) {
      var t, o = e.currentTarget.dataset,
        i = null == o || null == (t = o.exposeDish) ? void 0 : t.__newReportConfig__;
      i && (0, a.collocationDishMV)(i)
    }
  },
  ready: function() {
    this.limoReady()
  }
});