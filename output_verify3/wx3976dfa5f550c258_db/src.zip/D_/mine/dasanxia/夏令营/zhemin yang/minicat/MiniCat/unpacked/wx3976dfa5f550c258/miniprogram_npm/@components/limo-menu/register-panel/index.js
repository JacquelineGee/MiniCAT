var e = require("../../../../b/helpers/interopRequireDefault"),
  t = e(require("../../../@limo/core/index.js")),
  r = require("../../../@limo/container/behaviors/index"),
  i = e(require("../../../seamless-immutable/index.js")),
  o = e(require("../../../../store/menu")),
  a = e(require("../../../../api/rmsStorage")),
  s = require("../../../../store/asyncActions/cart"),
  n = require("../../../../store/actions/cart"),
  m = require("../common-lib/report"),
  u = e(require("../common-behaviors/storeBehavior"));
Component({
  behaviors: [u.default, r.commonBehavior, r.limoShim],
  properties: {
    actionUrl: {
      type: String,
      value: ""
    }
  },
  data: {},
  created: function() {
    this.store = o.default
  },
  methods: {
    limoReady: function() {
      this.commonBehaviorsStoreBehavior_limoReady()
    },
    mapToState: function(e) {
      var t = i.default.getIn(e, ["cart", "showRegisterPanel"]) || !1;
      return t && (0, m.sendMV)("b_saaspay_5wtvwj42_mv"), {
        showRegisterPanel: t || !1
      }
    },
    gotoLoginPage: function() {
      (0, m.sendMC)("b_saaspay_7wi2mabg_mc"), a.default.setLoginFromRegisterPanelTag(!0), t.default.getLimoRuntime().navigateTo({
        url: this.data.actionUrl
      }), this.store.dispatch((0, n.toggleRegisterPanelAction)(!1))
    },
    toOrderConfirmPage: function() {
      (0, m.sendMC)("b_saaspay_w3pazwju_mc"), this.store.dispatch((0, s.toOrderConfirmPage)()), this.store.dispatch((0, n.toggleRegisterPanelAction)(!1))
    },
    prevent: function() {}
  },
  ready: function() {
    this.limoReady()
  }
});