var e = require("../../../@limo/container/behaviors/index");
Component({
  behaviors: [e.commonBehavior, e.limoShim],
  options: {
    multipleSlots: !0
  },
  properties: {
    btns: {
      type: Array,
      value: []
    },
    content: {
      type: String,
      value: ""
    },
    title: {
      type: String,
      value: ""
    }
  },
  data: {},
  methods: {
    handleTap: function(e) {
      this.closeDialog();
      var t = e.currentTarget.dataset.index,
        i = this.properties.btns[t];
      i && i.callback ? i.callback() : this.triggerEvent("shopDistanceConfirm", {
        index: t
      })
    }
  }
});