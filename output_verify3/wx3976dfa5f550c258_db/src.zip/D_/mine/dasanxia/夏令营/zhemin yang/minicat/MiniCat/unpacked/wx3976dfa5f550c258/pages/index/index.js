var a = require("../../b/helpers/interopRequireDefault"),
  e = require("../../b/helpers/objectSpread2");
require("../../b/helpers/Arrayincludes");
var t = a(require("../../b/regenerator")),
  n = require("../../b/helpers/asyncToGenerator"),
  r = require("../../api/portal"),
  i = require("../../constants/bizConstants-main"),
  o = a(require("../../api/rmsStorage-main")),
  s = a(require("../../miniprogram_npm/@limo/core/index.js")),
  u = require("../../lib/mix/util"),
  c = require("../../constants/ajaxResCode-main"),
  l = require("../../constants/decorate"),
  d = require("../../constants/path"),
  p = require("../../lib/wx/util"),
  f = require("../../lib/wx/app-info"),
  g = require("../../lib/geo"),
  h = require("../../lib/wx/page"),
  m = require("../../miniprogram_npm/@mtfe/rms-sdk/index.js"),
  v = require("../../lib/wx/plugin/default"),
  b = require("../../lib/silentLogin"),
  T = a(require("../../miniprogram_npm/@mtfe/rms-triangle-c/index.js")),
  E = ["shop-list-entry", "notice-config", "manual-slide", "video-module", "dish-production-progress"];
(0, h.ProxyPage)({
  data: {
    previewData: {},
    hasTabBar: !1,
    PORTAL_TAB_TYPE: i.PORTAL_TAB_TYPE,
    titleName: "",
    customOptions: {
      addPoint: {
        MC: "b_saaspay_pjkg0rft_mc",
        MV: "b_saaspay_pjkg0rft_mv"
      }
    },
    options: {},
    isNativeTabbarPage: !1,
    errorTitle: "",
    titleInfo: {},
    titleSwitch: !0
  },
  shareMsg: {},
  isFirstEnterPage: !0,
  hasValidData: !1,
  hasReportModules: !1,
  onLoad: function(a) {
    var e = this;
    return n(t.default.mark((function r() {
      return t.default.wrap((function(r) {
        for (;;) switch (r.prev = r.next) {
          case 0:
            e.__limoCore = s.default.LimoCoreFactory(), (0, h.initPageOnLoad)(), e.handleTabBarVisible(!1), a = (0, p.getTabbarPageOptions)(a, e.route), e.options = a, (0, m.transaction)("INDEX.SILENT_LOGIN", n(t.default.mark((function a() {
              return t.default.wrap((function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    (0, b.silentLogin)((function() {
                      return e.getPageData()
                    }));
                  case 1:
                  case "end":
                    return a.stop()
                }
              }), a)
            })))), e.setData({
              options: a,
              isNativeTabbarPage: !!(0, f.isNativeTabbarPage)(e.route)
            }), s.default.showDialog("common-theme-loading", {}, {
              hideTabBarHeight: !0
            }), (0, p.setPreviewFlag)(a.previewFlag), m.LazyLoad.reportComponentMountedTotal(["tab-bar"]), (0, m.transaction)("INDEX.STORAGE_FIRST_SCREEN", function() {
              var a = n(t.default.mark((function a(n) {
                return t.default.wrap((function(a) {
                  for (;;) switch (a.prev = a.next) {
                    case 0:
                      s.default.getLimoRuntime().getStorage({
                        key: "portal-info",
                        success: function(a) {
                          if (a && a.data) {
                            var t = a.data,
                              r = t.resData,
                              i = t.date;
                            Date.now() - i >= 6048e5 ? n.fail(400) : (e.reportModules(null == r ? void 0 : r.data), r && e.setPageData(r, (function() {
                              s.default.closeDialog("common-theme-loading"), e.hasValidData = !0, n.success(), m.Log.addCustom("indexHasStorageCount", 1)
                            }), !0))
                          } else n.fail(404)
                        }
                      });
                    case 1:
                    case "end":
                      return a.stop()
                  }
                }), a)
              })));
              return function(e) {
                return a.apply(this, arguments)
              }
            }(), !0), s.default.registerEvent("onVideoFullScreen", (function(a) {
              e.setData({
                titleSwitch: !a
              })
            })), s.default.registerEvent("universalLogin-uniLoginSuccess", (function() {
              e.getPageData()
            }));
          case 1:
          case "end":
            return r.stop()
        }
      }), r)
    })))()
  },
  getShareInfo: function() {
    var a = this;
    return n(t.default.mark((function e() {
      var n, i, o, s, u, l;
      return t.default.wrap((function(e) {
        for (;;) switch (e.prev = e.next) {
          case 0:
            return n = a.options, i = n.tenantId, o = n.restaurantViewId, e.prev = 1, e.next = 4, (0, r.getShareInfo)({
              tenantId: i,
              restaurantViewId: o,
              containerName: "portal-index",
              pageCode: "portal-index"
            });
          case 4:
            s = e.sent, u = s.code, l = s.data, u === c.RES_CODE.SUCCESS && (a.shareMsg = l), e.next = 13;
            break;
          case 10:
            e.prev = 10, e.t0 = e.catch(1), m.Log.addError({
              name: "获取小程序首页分享信息异常",
              msg: JSON.stringify(e.t0)
            }, {
              category: "ajaxError"
            });
          case 13:
          case "end":
            return e.stop()
        }
      }), e, null, [
        [1, 10]
      ])
    })))()
  },
  onShareAppMessage: function() {
    return m.LXReporter.sendMC("b_saaspay_ua8kms8y_mc"), this.shareMsg
  },
  onShow: function() {
    if (!this.isFirstEnterPage) {
      var a = Object.assign(this.options, {});
      this.options = (0, p.getTabbarPageOptions)({}, this.route, a), this.setData({
        options: this.options,
        errorTitle: ""
      })
    }
    var e;
    if (this.options.decorateType || (m.LXReporter.sendPV("c_eco_seggwc08", null, {
        env: "wxapp"
      }), this.getPageData(), this.handleTabbar()), +this.options.decorateType) return null == (e = this.loadSuccess) || e.call(this), void T.default.redirectTo({
      url: "".concat(d.PATH["shop-homepage"], "?").concat(T.default.stringify(this.options)),
      fail: function(a) {
        m.Log.addError({
          name: "兜底跳转新门店主页path失败",
          msg: JSON.stringify(a)
        })
      }
    });
    this.isFirstEnterPage && m.Log.addCustom("indexLoadCount", 1)
  },
  onHide: function() {
    this.isFirstEnterPage = !1, (0, f.setTabbarPageParams)(this.route, {})
  },
  silentCacheLocation: function() {
    s.default.getSetting({
      success: function(a) {
        var e;
        null != a && null != (e = a.authSetting) && e["scope.userLocation"] && (0, g.getLocation)({}).then((function(a) {
          m.Log.addLog("首页-静默获取定位成功-" + a)
        })).catch((function(a) {
          m.Log.addError({
            name: "首页-静默获取定位失败",
            msg: JSON.stringify(a)
          })
        }))
      },
      fail: function(a) {
        m.Log.addError({
          name: "首页-获取用户设置失败",
          msg: JSON.stringify(a)
        })
      }
    })
  },
  reportModules: function(a) {
    if (!this.hasReportModules && a && a.modules) {
      var e = a.modules.map((function(a) {
        return a.name
      }));
      m.LazyLoad.reportComponentMountedTotal(E.filter((function(a) {
        return e.includes(a)
      }))), this.hasReportModules = !0
    }
  },
  getPageData: function() {
    var a = this;
    return n(t.default.mark((function e() {
      return t.default.wrap((function(e) {
        for (;;) switch (e.prev = e.next) {
          case 0:
            return e.next = 2, (0, m.transactionOnce)(a)("INDEX.REQUEST_FIRST_SCREEN", function() {
              var e = n(t.default.mark((function e(i) {
                var u, d, p, g, h, v, b, T, E;
                return t.default.wrap((function(e) {
                  for (;;) switch (e.prev = e.next) {
                    case 0:
                      return d = (0, f.getNewApp)(), p = a.options, g = p.restaurantViewId, h = p.tenantId, e.next = 6, (0, m.transactionOnce)(a)("INDEX.PAGE_DATA_REQUEST", function() {
                        var e = n(t.default.mark((function e(n) {
                          var i, s, u, p;
                          return t.default.wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                return e.prev = 0, e.next = 3, (0, r.getDecoratePortalInfo)({
                                  restaurantViewId: g,
                                  tenantId: h,
                                  previewFlag: d.diancanGlobalData.getPreview(l.CONTAINER_NAME.PORTAL),
                                  customChannel: o.default.getCustomChannel()
                                });
                              case 3:
                                s = e.sent, e.next = 9;
                                break;
                              case 6:
                                e.prev = 6, e.t0 = e.catch(0), ((null == e.t0 || null == (u = e.t0.errMsg) ? void 0 : u.indexOf("timeout")) > -1 || (null == e.t0 || null == (p = e.t0.errMsg) ? void 0 : p.indexOf("fail")) > -1) && (s = {
                                  netWorkErr: !0
                                });
                              case 9:
                                return e.abrupt("return", (a.getShareInfo(), s && s.code === c.RES_CODE.SUCCESS || n.fail((null == (i = s) ? void 0 : i.code) || c.RES_CODE.ERROR), s));
                              case 10:
                              case "end":
                                return e.stop()
                            }
                          }), e, null, [
                            [0, 6]
                          ])
                        })));
                        return function(a) {
                          return e.apply(this, arguments)
                        }
                      }());
                    case 6:
                      if (v = e.sent, a.verifyData(v)) {
                        e.next = 9;
                        break
                      }
                      return e.abrupt("return", void s.default.closeDialog("common-theme-loading"));
                    case 9:
                      b = v.data, a.reportModules(b), T = {};
                      try {
                        T = JSON.parse(JSON.stringify(v))
                      } catch (a) {
                        m.Log.addError({
                          name: "首页-深拷贝装修数据失败",
                          msg: JSON.stringify(a)
                        })
                      }
                      a.setData({
                        titleName: (null == b ? void 0 : b.titleName) || ""
                      }), a.setPageData(v, (function() {
                        s.default.closeDialog("common-theme-loading"), i.success(), a.isFirstEnterPage && a.silentCacheLocation()
                      }), !1), E = ((null == (u = T.data) ? void 0 : u.modules) || []).filter((function(a) {
                        return "limo-modal" !== a.name && "open-screen" !== a.name && "member-coupon-pop-up" !== a.name
                      })), T.data && (T.data.modules = E), s.default.getLimoRuntime().setStorage({
                        key: "portal-info",
                        data: {
                          resData: T,
                          date: Date.now()
                        }
                      });
                    case 16:
                    case "end":
                      return e.stop()
                  }
                }), e)
              })));
              return function(a) {
                return e.apply(this, arguments)
              }
            }(), !0);
          case 2:
          case "end":
            return e.stop()
        }
      }), e)
    })))()
  },
  handleTabbar: function() {
    var a, e = (0, f.getNewApp)(),
      t = this.options,
      n = t.restaurantViewId,
      r = {
        params: {
          restaurantViewId: n,
          tenantId: t.tenantId,
          entrance: t.entrance,
          previewFlag: e.diancanGlobalData.getPreview(l.CONTAINER_NAME.TAB_BAR)
        },
        url: (0, u.getTabBarUrl)()
      },
      i = o.default.getTabBarData(n) || [];
    e.diancanGlobalData.getPreview(l.CONTAINER_NAME.TAB_BAR) && (i = [], o.default.setTabBarData(n, [])), null != (a = i) && a.length ? this.setData({
      requestParams: {},
      catchTabBarList: i
    }) : this.setData({
      requestParams: r,
      catchTabBarList: i
    })
  },
  handleBackgroundInfo: function(a) {
    var e = a.bgImgShowType,
      t = a.bgColor,
      n = a.bgImgUrl,
      r = "background-image:url('".concat(n, "');background-color:").concat(t, "; ");
    switch (e) {
      case i.PORTAL_BACKGROUND_TYPE.CONTAIN:
        r += "background-size: 100% auto;background-repeat: no-repeat;";
        break;
      case i.PORTAL_BACKGROUND_TYPE.REPEAT:
        r += "background-repeat: repeat;";
        break;
      case i.PORTAL_BACKGROUND_TYPE.COVER:
        r += "background-size: 100vw 100vh;"
    }
    return r
  },
  verifyData: function(a) {
    return !(!a || a.code !== c.RES_CODE.SUCCESS) || (null != a && a.netWorkErr && this.hasValidData || this.setData({
      errorTitle: (null == a ? void 0 : a.msg) || "页面加载失败，请稍后重试"
    }), !1)
  },
  setPageData: function(a, r, i) {
    var s = this;
    if (a.data) {
      var u = (0, p.getWxPathName)() || "";
      if (/pages\/index\/index/.test(u) && a && a.data) {
        var c = a.data,
          l = c.modules,
          d = void 0 === l ? [] : l,
          h = c.pageBgVO,
          v = !0;
        d.forEach((function(a) {
          var t, n, r, i;
          if ("limo-modal" === a.name && (a.data.limoModalStorage = o.default.getLimoModal(null == (t = s.options) ? void 0 : t.tenantId)), "wx-official-account" === a.name && (a.data.position = null == (n = a.layout) ? void 0 : n.position, a.data.hasTabBar = s.data.hasTabBar, a.data.hasNativeTabBar = !!(0, f.isNativeTabbarPage)(s.route)), "limo-slide" === a.name && (a.data.componentId = a.id), "dish-production-progress" === a.name && (a.data.isMerchantWxApp = (0, f.isMerchantWxApp)(), a.data.shop = {
              tenantId: null == (r = s.options) ? void 0 : r.tenantId,
              poiId: null == (i = s.options) ? void 0 : i.poiId
            }, a.data.locationFun = {
              getLocation: g.getLocation
            }), "accumulate-list" === a.name && (a.data.updateTime = Date.now()), "open-screen" === a.name) {
            var u, c = !o.default.getOpenScreen(null == (u = s.options) ? void 0 : u.tenantId);
            a.data.show = c, v = !c, a.layout = e(e({}, a.layout), {}, {
              zIndex: 2e3,
              position: "relative"
            })
          }
          "basic-canvas" === a.name && (a.data.isMemberCanvas = !1, a.data.loginCanvasConfig = a.data.canvasConfig, a.name = "member-canvas")
        })), this.handleTabBarVisible(v), (0, m.transaction)(i ? "INDEX.SET_PAGE_DATA_STORAGE" : "INDEX.SET_PAGE_DATA", function() {
          var e = n(t.default.mark((function e(n) {
            var i;
            return t.default.wrap((function(e) {
              for (;;) switch (e.prev = e.next) {
                case 0:
                  i = a.data, Array.isArray(i.modules) && i.modules.push({
                    name: "agreement-confirm",
                    data: {},
                    layout: {
                      zIndex: 999
                    }
                  }), s.setData({
                    backgroundInfo: h && s.handleBackgroundInfo(h) || "",
                    previewData: {
                      modules: a.data.modules || []
                    },
                    titleInfo: h || {},
                    titleSwitch: h && h.titleSwitch || !1
                  }, (function() {
                    s.loadSuccess(), n.success(), r && r()
                  }));
                case 2:
                case "end":
                  return e.stop()
              }
            }), e)
          })));
          return function(a) {
            return e.apply(this, arguments)
          }
        }(), !0)
      }
    }
  },
  tabBarRenderFn: function(a) {
    if (!this.data.hasTabBar) {
      this.setData({
        hasTabBar: !0
      });
      var e = this.data.previewData.modules,
        t = void 0 === e ? [] : e;
      t.forEach((function(a) {
        "wx-official-account" === a.name && (a.data.hasTabBar = !0)
      })), this.setData({
        previewData: {
          modules: t
        }
      })
    }
    var n = a.detail.tabBarList,
      r = void 0 === n ? [] : n,
      i = this.data.requestParams.params,
      s = (void 0 === i ? {} : i).restaurantViewId,
      u = void 0 === s ? "" : s;
    u && o.default.setTabBarData(u, r)
  },
  setLimoShowStorage: function() {
    var a, e;
    null != (a = this.options) && a.tenantId && o.default.setLimoModal(null == (e = this.options) ? void 0 : e.tenantId)
  },
  triggerScroll: function(a) {
    s.default.triggerEvent("isScroll", {
      isScroll: a
    })
  },
  touchEnd: function() {
    this.triggerScroll(!1)
  },
  touchMove: function() {
    this.triggerScroll(!0)
  },
  closeFullScreenAd: function() {
    this.handleTabBarVisible(!0)
  },
  handleTabBarVisible: function(a) {
    var e = this.getTabBar && this.getTabBar();
    e && e.setData({
      showNativeTabBar: a
    })
  },
  setOpenScreenStorage: function() {
    var a = (this.options || {}).tenantId;
    a && o.default.setOpenScreen(a)
  }
}, v.plugins);