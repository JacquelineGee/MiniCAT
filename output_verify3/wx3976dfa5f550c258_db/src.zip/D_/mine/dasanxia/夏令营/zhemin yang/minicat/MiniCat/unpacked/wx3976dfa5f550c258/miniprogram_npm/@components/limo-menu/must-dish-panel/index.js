var t = require("../../../../b/helpers/interopRequireDefault"),
  e = require("../../../../b/helpers/objectSpread2"),
  i = require("../../../@limo/container/behaviors/index"),
  s = t(require("../../../seamless-immutable/index.js")),
  a = require("../../../../store/actions/cart"),
  r = require("../../../../store/actions/mustDish"),
  o = require("../../../../constants/cartConstants"),
  n = t(require("../../../../store/menu")),
  u = t(require("../common-behaviors/storeBehavior")),
  h = require("../../../../modules/menu/dish/DishSdk"),
  d = t(require("../../../../modules/MustDishSdk"));
Component({
  behaviors: [u.default, i.commonBehavior, i.limoShim],
  properties: {
    shopId: {
      type: String,
      value: ""
    },
    isNativeTabbarPage: {
      type: Boolean,
      value: !1
    }
  },
  data: {
    MUSTDISH_PANEL_STATUS: o.MUSTDISH_PANEL_STATUS,
    mustDishGroups: [],
    mustDishOperationData: {},
    mustDishPanelStatus: 0,
    multiDishList: {},
    mandatoryInfos: {}
  },
  observers: {
    "refactorCartDishMap.**, multiDishList.**, mandatoryInfos.**, mustDishPanelStatus": function(t, i, s) {
      i && s || this.setData({
        mustDishGroups: [],
        mustDishOperationData: {}
      });
      var a = this.data.shopId,
        r = (0, h.GetDishSdkSingleton)(a).getDishList(),
        o = d.default.formatMustDishRenderGroup(a, r, s).map((function(t) {
          var s = t.groupId,
            a = i[s];
          if (a) {
            var r = a.selected,
              o = void 0 === r ? 0 : r,
              n = a.choice,
              u = void 0 === n ? 0 : n;
            return e(e({}, t), {}, {
              selected: o,
              remain: u - o
            })
          }
        })).filter((function(t) {
          return !!t
        })),
        n = d.default.dealMustDishOperation(a, t, o);
      this.setData({
        mustDishGroups: o,
        mustDishOperationData: n
      })
    }
  },
  created: function() {
    this.store = n.default
  },
  methods: {
    limoReady: function() {
      this.commonBehaviorsStoreBehavior_limoReady()
    },
    mapToState: function(t) {
      return {
        multiDishList: s.default.getIn(t, ["mustDish", "multiDishList"]) || {},
        mustDishPanelStatus: s.default.getIn(t, ["mustDish", "mustDishPanelStatus"]) || 0,
        mandatoryInfos: s.default.getIn(t, ["extraInfo", "headInfo", "shopConfig", "mandatoryInfos"]) || {},
        refactorCartDishMap: s.default.getIn(t, ["cart", "refactorLocalCart", "refactorCartDishMap"]) || {}
      }
    },
    closeMustDishPanel: function() {
      this.store.dispatch((0, a.closeMustDishPanel)())
    },
    updateOperateDishMustGroupId: function(t) {
      this.store.dispatch((0, r.updateMustDishGroupIdAction)(t))
    },
    showDishTimeInfoModal: function(t) {
      this.triggerEvent("showDishTimeInfoModalFn", t.detail)
    },
    operationCountFn: function(t) {
      var i, s, a = (null == t || null == (i = t.currentTarget) ? void 0 : i.operationData) || (null == t || null == (s = t.currentTarget) || null == (s = s.dataset) ? void 0 : s.operationData) || {},
        r = a.groupId,
        o = a.skuId;
      r && this.updateOperateDishMustGroupId(r), this.triggerEvent("operateDish", e(e({}, t.detail), {}, {
        skuId: o
      }))
    },
    operationPanelFn: function(t) {
      var i = t.detail.operationData,
        s = void 0 === i ? {} : i,
        a = s.groupId,
        r = s.skuId;
      a && this.updateOperateDishMustGroupId(a), this.triggerEvent("operationPanel", e(e({}, t.detail), {}, {
        skuId: r
      }))
    },
    prevent: function() {}
  },
  ready: function() {
    this.limoReady()
  }
});