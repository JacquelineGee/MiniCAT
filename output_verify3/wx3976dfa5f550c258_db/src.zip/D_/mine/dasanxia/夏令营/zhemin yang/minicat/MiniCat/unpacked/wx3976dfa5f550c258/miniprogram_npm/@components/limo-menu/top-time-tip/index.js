var e = require("../../../@limo/container/behaviors/index");
Component({
  behaviors: [e.commonBehavior, e.limoShim],
  properties: {
    countDownPrefix: {
      type: String,
      value: ""
    },
    countDownValue: {
      type: String,
      value: ""
    },
    countDownSuffix: {
      type: String,
      value: ""
    },
    shouldCountDown: {
      type: Boolean,
      value: !1
    }
  },
  data: {
    countDownValueView: 0
  },
  lifetimes: {
    attached: function() {
      var e = this,
        t = this.data,
        o = t.shouldCountDown,
        n = t.countDownValue;
      if (this.setData({
          countDownValueView: n
        }), o) var a = Number(n),
        i = setInterval((function() {
          a >= 0 ? e.setData({
            countDownValueView: a--
          }) : clearInterval(i)
        }), 6e4)
    }
  }
});