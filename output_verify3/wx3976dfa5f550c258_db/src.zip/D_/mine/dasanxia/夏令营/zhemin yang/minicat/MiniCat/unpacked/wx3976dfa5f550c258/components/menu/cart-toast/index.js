var e, t = require("../../../b/helpers/interopRequireDefault"),
  o = require("../../../miniprogram_npm/@limo/container/behaviors/index"),
  r = require("../../../store/actions/cartToast"),
  a = t(require("../../../store/menu")),
  i = t(require("../../../store/helpers/storeBehavior"));
Component({
  behaviors: [i.default, o.commonBehavior, o.limoShim],
  options: {
    addGlobalClass: !0
  },
  properties: {
    cartToastImg: {
      type: String,
      value: ""
    },
    cartToastText: {
      type: String,
      value: ""
    },
    cartToastInfo: {
      type: Object,
      value: {}
    },
    isShow: {
      type: Boolean,
      value: !1
    },
    fromOrderConfirm: {
      type: Boolean,
      value: !1,
      observer: function(e) {
        e && this.setData({
          toastClass: "cart-toast order-confirm"
        })
      }
    }
  },
  data: {
    toastClass: "cart-toast"
  },
  observers: {
    isShow: function(t) {
      var o = this;
      clearTimeout(e), t && (e = setTimeout((function() {
        o.hideToast()
      }), 2e3))
    }
  },
  created: function() {
    this.store = a.default
  },
  methods: {
    limoReady: function() {
      this.helpersStoreBehavior_limoReady()
    },
    hideToast: function() {
      this.store.dispatch((0, r.hide)())
    }
  },
  ready: function() {
    this.limoReady()
  }
});