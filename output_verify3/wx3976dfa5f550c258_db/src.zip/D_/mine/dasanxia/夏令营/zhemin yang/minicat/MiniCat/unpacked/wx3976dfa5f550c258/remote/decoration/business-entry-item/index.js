var e = require("../../../b/helpers/interopRequireDefault")(require("../../../miniprogram_npm/@limo/core/index.js")),
  t = require("../../../miniprogram_npm/@limo/container/behaviors/index.js"),
  i = require("../common-helpers/tapActionMap"),
  o = require("../common-helpers/formatStyle"),
  n = {
    1: "img",
    2: "title",
    3: "subTitle",
    4: "desc"
  };
Component({
  behaviors: [t.commonBehavior, t.limoShim],
  properties: {
    item: {
      type: Object,
      value: {}
    },
    themeStyle: {
      type: Object,
      value: {},
      observer: function(e) {
        this.transformThemeStyle(e)
      }
    },
    infoList: {
      type: Array,
      value: [],
      observer: function(e) {
        this.formatInfoList(e)
      }
    }
  },
  data: {
    iconConfig: {},
    showMap: {}
  },
  methods: {
    tapToJump: function() {
      var t = this.properties.item,
        o = t.redirectUrl,
        n = void 0 === o ? "" : o,
        r = t.name,
        a = void 0 === r ? "" : r,
        m = t.action;
      e.default.getLimoRuntime().sendMC("b_eco_2pd00krg_mc", {
        custom: {
          button_name: a
        }
      }), m ? (0, i.tapActionHandler)(m, {
        compInst: this
      }) : n && (e.default.getLimoRuntime().sendMC("b_eco_z1ok8qdw_mc", {
        custom: {
          redirectUrl: n
        }
      }), e.default.getLimoRuntime().navigateTo({
        url: n,
        success: function() {},
        fail: function() {}
      }))
    },
    formatInfoList: function(e) {
      if (e) {
        var t = {};
        e.forEach((function(e) {
          t[n[e]] = !0
        })), this.setData({
          showMap: t
        })
      }
    },
    transformThemeStyle: function(e) {
      if (e && e.iconConfig) {
        var t = e.iconConfig,
          i = t.position,
          n = t.size;
        this.setData({
          iconConfig: {
            position: i,
            style: (0, o.formatStyle)({
              width: n,
              height: n
            })
          }
        })
      }
    }
  }
});