var e = require("../../../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.default = void 0;
var r = require("../../../b/helpers/classCallCheck"),
  t = require("../../../b/helpers/createClass"),
  s = require("../../../b/helpers/inherits"),
  a = require("../../../b/helpers/createSuper"),
  i = require("../../../constants/bizConstants"),
  u = function(e) {
    s(l, e);
    var u = a(l);

    function l(e) {
      var t;
      r(this, l), (t = u.call(this, e)).urlParams = void 0;
      var s = e.options;
      return t.urlParams = s || {}, t
    }
    return t(l, [{
      key: "resetPage",
      value: function() {
        this.offset = "", this.listData = [], this.loadingStatus = i.LOADING.DOING, this.fetchOrderList()
      }
    }]), l
  }(e(require("./AbstractPageViewModel")).default);
exports.default = u;