var t = require("../../../b/helpers/interopRequireDefault"),
  e = require("../../../b/helpers/objectSpread2"),
  a = require("../../../miniprogram_npm/@limo/container/behaviors/index"),
  i = t(require("../../../miniprogram_npm/seamless-immutable/index.js")),
  s = require("../../../modules/dishHelper"),
  n = require("./log"),
  o = require("../../../constants/bizConstants"),
  u = require("../../../constants/lxConstants"),
  r = require("../../../modules/panel/util"),
  l = require("../../../modules/panel/panelDataUtil"),
  d = require("../../../store/actions/baseCart"),
  c = require("../../../store/actions/cart"),
  h = require("../../../store/actions/add-on"),
  p = require("../../../modules/operateCartHelper"),
  D = t(require("../../../lib/mix/toast")),
  S = require("../../../modules/panel/panelHelper"),
  g = require("../../../modules/LXHelper"),
  P = require("../../../modules/menu/dish/expose"),
  m = require("../../../modules/cartHelper"),
  C = require("../../../modules/collocation/lx"),
  k = require("../../../constants/cartConstants"),
  f = require("../../../store/actions/newCart"),
  I = require("../../../modules/menu/cart/cartDataTransfer"),
  _ = require("../../../modules/panel/mp-spec/util"),
  E = t(require("../../../modules/menu/grouponCoupon/GrouponCouponSdk")),
  T = t(require("../../../store/menu")),
  v = t(require("../../../store/helpers/storeBehavior")),
  A = require("../../../modules/panel/package/utils"),
  O = require("../../../constants/menu"),
  w = require("../../../store/cart/PointPurchaseService"),
  M = t(require("../../../api/rmsStorage")),
  N = t(require("../../../modules/menu/shop/shopService"));
Component({
  behaviors: [v.default, a.commonBehavior, a.limoShim],
  options: {
    addGlobalClass: !0
  },
  properties: {
    options: {
      type: Object,
      value: {}
    },
    showContainerPanelTag: {
      type: Boolean,
      value: !1
    },
    isMenu: {
      type: Boolean,
      value: !1
    },
    categoriesList: {
      type: Object,
      value: {}
    },
    spuComboShowType: {
      type: Number,
      value: 0
    },
    isNativeTabbarPage: {
      type: Boolean,
      value: !1
    },
    hidePrice: {
      type: Boolean,
      value: !1
    },
    btnTitle: {
      type: String,
      value: ""
    }
  },
  data: {
    spuDish: {},
    menuSkuDish: {},
    cartSkuDish: {},
    menuPackageSku: {},
    cartPackageSku: {},
    calcValue: "",
    calcStatus: null,
    mustDishCartDiff: 0,
    showMultiPanel: !1,
    showPackagePanel: !1,
    showCalculatorPanel: !1,
    multiVisible: !0,
    packageVisible: !0,
    packageTastes: !1,
    weightTastes: !1,
    specSpuId: "",
    optionsDishData: {},
    isShowDetailPanel: !1,
    packageDetailList: [],
    modifyCartPackageSkuFromSpecsPanel: {
      goodsNo: "",
      operatePackageTasteType: void 0
    },
    detailDescription: ""
  },
  observers: {
    "currentSpuId, editDishGoodsNo": function(t, e) {
      var a = this.data,
        i = a.cartSkuDish,
        n = a.refactorLocalCart,
        u = a.cartDishList,
        l = a.showContainerPanelTag,
        d = a.shopId,
        c = a.isShowCountCalc,
        h = (0, s.getDishListFromStore)(!1, d);
      if (t && l) {
        var p = h[t],
          D = this.getPanelType(),
          S = N.default.getShopServiceData().fmpBizData;
        if (c) {
          var g = (0, r.initAddDishData)(p, u, e),
            P = g.skuDish,
            m = g.menuSkuDish;
          (null == P ? void 0 : P.dishType) === o.DISH_TYPE.PACKAGE ? this.setData({
            cartPackageSku: P,
            menuPackageSku: m
          }) : this.setData({
            menuSkuDish: m,
            cartSkuDish: P
          });
          var C = (null == P ? void 0 : P.count) || 0,
            k = this.data.mustDishCartDiff;
          this.setData({
            spuDish: p,
            calcStatus: o.CALCULATOR_STATUS.ADD,
            calcValue: C - k,
            showCalculatorPanel: !0
          })
        } else {
          if ("SPEC" === D && this.mulPanelHandle(e, t, p, i, n), "PACKAGE" === D && this.packagePanelHandle(e, t, p, n), "WEIGHT" === D && this.weightPanelHandle(t, p, i, n, h), "FIXED_PACKAGE" === D)
            if (null != S && S.needJumpDishPanel && !e) this.packagePanelHandle(e, t, p, n);
            else {
              var f = (0, r.initAddDishData)(p, u, e).skuDish;
              this.togglePackageDetailsPanel(f)
            } if (null != S && S.needJumpDishPanel && !D) {
            if (e) {
              var I, _ = null == u || null == (I = u[t]) ? void 0 : I.find((function(t) {
                return t.goodsNo === e
              }));
              if (null == _ || !_.remark) return
            }
            this.mulPanelHandle(e, t, p, i, n)
          }
        }
      }
    }
  },
  created: function() {
    this.store = T.default
  },
  methods: {
    limoReady: function() {
      this.helpersStoreBehavior_limoReady()
    },
    mapToState: function(t) {
      return {
        shopId: i.default.getIn(t, ["cart", "shopId"]),
        tableNum: i.default.getIn(t, ["cart", "tableNum"]),
        cartDishList: i.default.getIn(t, ["cart", "cartDishList"]),
        refactorLocalCart: i.default.getIn(t, ["cart", "refactorLocalCart"]),
        currentSpuId: i.default.getIn(t, ["cart", "currentSpuId"]),
        editDishGoodsNo: i.default.getIn(t, ["cart", "editDishGoodsNo"]),
        editDishSpuId: i.default.getIn(t, ["cart", "editDishSpuId"]),
        currentSkuId: i.default.getIn(t, ["cart", "currentSkuId"]),
        containerOpenExtraData: i.default.getIn(t, ["cart", "containerOpenExtraData"]),
        showContainerPanelTag: i.default.getIn(t, ["cart", "showContainerPanelTag"]),
        applyCouponId: i.default.getIn(t, ["grouponCoupon", "applyCouponId"]),
        dealCoupons: i.default.getIn(t, ["grouponCoupon", "dealCoupons"]),
        memberInfo: i.default.getIn(t, ["extraInfo", "headInfo", "memberInfo"]),
        dishAddFrom: i.default.getIn(t, ["cart", "dishAddFrom"]),
        isShowCountCalc: i.default.getIn(t, ["cart", "isShowCountCalc"]),
        mustDishCartDiff: i.default.getIn(t, ["mustDish", "mustDishCartDiff"]),
        cartDishSortMapList: i.default.getIn(t, ["cart", "cartDishSortMapList"]),
        operationSkuDish: i.default.getIn(t, ["cart", "cartSkuDish"]),
        __newReportConfig__: i.default.getIn(t, ["cart", "__newReportConfig__"]),
        showDishRemark: i.default.getIn(t, ["extraInfo", "headInfo", "shopConfig", "commonConfig", "showDishRemark"]),
        currentDiscount: i.default.getIn(t, ["cart", "currentDiscount"])
      }
    },
    toggleContainerPanelAction: function(t) {
      this.store.dispatch((0, d.toggleContainerPanelAction)(t))
    },
    addComplexDish: function(t) {
      this.store.dispatch(w.PointPurchase.addComplexDish(t))
    },
    addToCart: function(t) {
      this.store.dispatch((0, c.addToCart)(t))
    },
    updateEditSkuDishAction: function(t) {
      this.store.dispatch((0, d.updateEditSkuDishAction)(t))
    },
    toggleCartVisibleAction: function(t) {
      this.store.dispatch((0, c.toggleCartVisibleAction)(t))
    },
    closeCartPanel: function() {
      this.store.dispatch((0, c.closeCartPanel)())
    },
    closeCalcPanel: function() {
      this.store.dispatch((0, c.closeCalcPanel)())
    },
    updateCart: function(t, e, a, i, s) {
      this.store.dispatch((0, c.updateCart)(t, e, a, i, s))
    },
    updateCalculator: function(t) {
      this.store.dispatch((0, d.updateCalculator)(t))
    },
    operationDispatch: function(t, e) {
      this.store.dispatch((0, f.operationDispatch)(t, e))
    },
    updateCurrentDishId: function(t) {
      this.store.dispatch((0, d.updateCurrentDishId)(t))
    },
    updateAddOnList: function() {
      this.store.dispatch((0, h.updateAddOnList)())
    },
    getPanelType: function() {
      var t = this.data,
        e = t.shopId,
        a = t.currentSpuId,
        i = (0, s.getDishListFromStore)(!1, e)[a];
      return i && Object.keys(i).length ? i.canWeight ? "WEIGHT" : (0, m.judgeMultiDish)(i) || (0, m.judgeComplexSpuDish)(i) ? "SPEC" : (0, m.judgePackageSpuDish)(i) ? (0, m.judgeFixedPackage)(i) ? "FIXED_PACKAGE" : "PACKAGE" : "" : ""
    },
    reportParams: function(t) {
      var e, a, i = t.spuDish,
        s = t.containerOpenExtraData,
        n = (null == s ? void 0 : s.reportConfig) || {},
        r = n.index,
        l = n.sn,
        d = n.fromSearch,
        c = n.adFrom,
        h = n.belongCategory,
        p = this.data.categoriesList,
        D = u.OP_TYPE.OTHER,
        S = u.OP_NAME.OTHER,
        m = (null == h ? void 0 : h.parentName) || "",
        C = (null == t ? void 0 : t.dishAddFrom) || c;
      !m && Object.keys(p || {}).forEach((function(t) {
        var e, a = p[t];
        m = (null == a || null == (e = a.__reportConfig__) ? void 0 : e.categoryName) || ""
      })), C === P.EXPOSE_DISH_TYPE.CATEGORY && (D = u.OP_TYPE.RECOMMEND_CLASS, S = u.OP_NAME.RECOMMEND_CLASS), C === P.EXPOSE_DISH_TYPE.DISHLIST && (D = u.OP_TYPE.RECOMMEND_CLASS, S = u.OP_NAME.RECOMMEND_DISH), C === P.EXPOSE_DISH_TYPE.CART && (D = u.OP_TYPE.CART), C === P.EXPOSE_DISH_TYPE.BANNER && (D = u.OP_TYPE.BANNER, m = ""), C === P.EXPOSE_DISH_TYPE.ADMODE && (D = u.OP_TYPE.AD_MODE, m = ""), (C === P.EXPOSE_DISH_TYPE.SEARCHLIST || d) && (D = u.OP_TYPE.SEARCH_LIST), C === P.EXPOSE_DISH_TYPE.BOSSRECOMMEND && (D = u.OP_TYPE.RECOMMEND_DISH, S = u.OP_NAME.RECOMMEND_BOSS, m = o.TITLE_CONTENT.BOSS), C !== P.EXPOSE_DISH_TYPE.NETRECOMMENDPAGE && C !== o.DISH_ADD_FROM.DP_RECOMMEND || (D = u.OP_TYPE.RECOMMEND_DISH, S = u.OP_NAME.RECOMMEND_NET, m = o.TITLE_CONTENT.NET), (0, g.sendMC)("b_saaspay_bsz9zphw_mc", null, null, {
        clickData: {
          op_type: D,
          dish_details_func_area: o.DISH_DETAIL.MAIN_DISH,
          op_name: S,
          recommend_mode: i.recommendType || "",
          sn: r || l || 0,
          algorithm: "",
          show_title: m,
          sku_id_list: i.skuId || (null == i || null == (e = i.skuMenuItems[0]) ? void 0 : e.skuId),
          spu_id_list: i.spuId,
          dish_name_list: i.skuName || i.spuName,
          dish_type: i.dishType,
          add_dish_quantity: "",
          isFirstScreen: (null == s || null == (a = s.reportConfig) || null == (a = a.firstScreenSpuIds) ? void 0 : a.indexOf(i.spuId)) > -1 ? 1 : 0
        }
      })
    },
    mulPanelHandle: function(t, e, a, i, s) {
      var n = this.data,
        o = n.packageTastes,
        u = n.weightTastes,
        r = n.currentSkuId,
        l = void 0 === r ? "" : r,
        d = n.showDishRemark,
        c = n.currentDiscount;
      if (t) {
        var h, p = null == s || null == (h = s.refactorCartDishMap[e]) ? void 0 : h.find((function(e) {
          return e.itemNo === t
        }));
        if (!p) return void this.initContainer();
        this.setData({
          spuDish: a,
          showMultiPanel: !0,
          specSpuId: a.spuId,
          optionsDishData: {
            editDishGoodsNo: t,
            selectedDishData: (0, _.getSelectedDishDataFromSimpleCartDish)(a, p),
            showDishRemark: d,
            discount: c
          }
        })
      } else {
        var D, S = a.skuMenuItems && a.skuMenuItems.find((function(t) {
          return t.grouponCouponInfo && t.grouponCouponInfo.length > 0
        }));
        D = l || (S ? S.skuId : ""), this.setData({
          showMultiPanel: !0,
          spuDish: a,
          specSpuId: a.spuId,
          optionsDishData: {
            optionsDishParams: {
              selectedSkuId: D
            },
            hiddenSpec: !!l,
            fromPackagePanel: o,
            fromWeightPanel: u,
            hiddenAddDishButton: o || u,
            showDishRemark: d,
            discount: c
          }
        })
      }
    },
    packagePanelHandle: function(t, a, i, s) {
      var n = this.data.cartDishList;
      if (t) {
        var o, u = null == n || null == (o = n[a]) ? void 0 : o.find((function(e) {
          return e.goodsNo === t
        }));
        if (!u) return this.initContainer(), void this.toggleCartVisibleAction(!0);
        var r = i.skuMenuItems.find((function(t) {
          return t.skuId === u.skuId
        }));
        this.setData({
          spuDish: i,
          menuPackageSku: r,
          cartPackageSku: u,
          showPackagePanel: !0
        })
      } else {
        var l = (0, A.initPackage)(i, s);
        this.setData(e({
          spuDish: i,
          showPackagePanel: !0
        }, l))
      }
    },
    weightPanelHandle: function(t, a, i, s, n) {
      var u, l = null == (u = this.data.cartDishList[t]) ? void 0 : u[0];
      if (l) {
        var d = (0, r.editWeightSkuDish)(l, n);
        this.setData({
          calcStatus: d.calcStatus,
          spuDish: d.spuDish,
          menuSkuDish: d.menuSkuDish,
          cartSkuDish: d.cartSkuDish,
          calcValue: d.calcValue,
          showCalculatorPanel: d.showCalculatorPanel
        }), this.updateEditSkuDishAction({
          editDishSpuId: d.editDishSpuId,
          editDishGoodsNo: d.editDishGoodsNo
        })
      } else {
        var c = (0, r.selectSkuDish)(a, -1, i, s);
        this.setData(e({
          spuDish: a,
          calcStatus: o.CALCULATOR_STATUS.WEIGHT,
          showCalculatorPanel: !0
        }, c))
      }
    },
    operationDish: function(t) {
      var a, i = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
        s = this.data,
        n = s.spuDish,
        u = s.refactorLocalCart,
        l = s.cartSkuDish,
        d = s.cartPackageSku,
        c = s.editDishSpuId,
        h = s.editDishGoodsNo,
        p = s.currentDiscount;
      a = n.dishType === o.DISH_TYPE.NORMAL ? l : d;
      var D = p.toString() === O.POINT_DISH_TYPE ? {
          discount: p
        } : {},
        S = (0, r.addPanelSkuDish)(n, t, u, a, c, h, i, e({}, D));
      this.setData(e({}, S))
    },
    addPanelSkuDishFn: function(t) {
      var e = t.detail.showCal,
        a = void 0 !== e && e;
      this.operationDish(!0, a)
    },
    minusPanelSkuDishFn: function() {
      this.operationDish(!1)
    },
    multiPanelClickAddCart: function(t) {
      var a = this.data,
        i = a.spuDish,
        o = a.cartSkuDish,
        u = a.cartPackageSku,
        l = a.menuPackageSku,
        d = a.packageTastes,
        c = a.dishAddFrom,
        h = a.currentSkuId,
        D = a.containerOpenExtraData,
        P = a.__newReportConfig__,
        m = a.specSpuId,
        k = a.shopId,
        f = a.menuSku,
        I = a.currentDiscount,
        _ = t.detail,
        E = _.selectedDishData,
        T = _.manualCampaigns,
        v = (0, s.getDishListFromStore)(!1, k),
        A = d ? e(e({}, f), {}, {
          skuMenuItems: [f]
        }) : v[m];
      if (A) {
        E.canWeight = null == o ? void 0 : o.canWeight, I === O.POINT_DISH_TYPE && (E.discount = I);
        var w = (0, p.transToCartDish)(E, A);
        if (null != T && T.length && (w.manualCampaigns = T), d) {
          o.methods = w.methods, o.tastes = w.tastes;
          var N = this.data.modifyCartPackageSkuFromSpecsPanel;
          this.setData({
            cartPackageSku: (0, r.addTastesToPackage)(o, u, l, N),
            packageVisible: !0,
            packageTastes: !1,
            showMultiPanel: !1,
            specSpuId: "",
            optionsDishData: {}
          })
        } else this.setData({
          showMultiPanel: !1,
          showCalculatorPanel: !1,
          showPackagePanel: !1
        }), M.default.getHasOpenTogether(k) || M.default.getNewAdvanceFlag(k) || (0, n.logAddedMultiplesSpecDish)(w), (0, g.sendMC)("b_saaspay_e68irt3n_mc", null, null, {
          clickData: (0, S.getMultiPanelReportConfig)(w, c)
        }), P ? (0, C.collocationDishAddMC)(P, w.count) : (this.reportParams({
          spuDish: i,
          dishAddFrom: c,
          containerOpenExtraData: D
        }), this.reportMultiPanel(1)), this.data.isMenu && !h && I !== O.POINT_DISH_TYPE ? this.triggerEvent("addToCartCoupon", {
          dish: w
        }) : I === O.POINT_DISH_TYPE ? this.addComplexDish(w) : this.addToCart(w), this.toggleContainerPanelAction(!1), this.updateCurrentDishId({
          currentSpuId: "",
          currentSkuId: "",
          __newReportConfig__: null,
          currentDiscount: ""
        })
      }
    },
    packagePanelClickAddCart: function() {
      var t = this.data,
        e = t.spuDish,
        a = t.cartPackageSku,
        i = t.dishAddFrom,
        s = t.containerOpenExtraData,
        o = t.__newReportConfig__,
        u = t.currentDiscount,
        r = t.shopId,
        l = (0, m.judgePackageEnableAdd)(a);
      if (a && Object.keys(l).length) {
        var d = l.enableClick,
          c = l.mustChildDishs,
          h = l.notFullGroup,
          p = l.mustDishGroup;
        if (d) this.setData({
          showMultiPanel: !1,
          showCalculatorPanel: !1,
          showPackagePanel: !1
        }), this.toggleContainerPanelAction(!1), this.updateCurrentDishId({
          currentSpuId: "",
          currentDiscount: ""
        }), this.data.isMenu && u !== O.POINT_DISH_TYPE ? this.triggerEvent("addToCartCoupon", {
          dish: a
        }) : u === O.POINT_DISH_TYPE ? this.addComplexDish(a) : this.addToCart(a), M.default.getHasOpenTogether(r) || M.default.getNewAdvanceFlag(r) || (0, n.logCartPackageSku)(a), o ? (0, C.collocationDishAddMC)(o, a.count) : this.reportParams({
          spuDish: e,
          dishAddFrom: i,
          containerOpenExtraData: s
        });
        else {
          if (c.length > 0 && p.length > 0) return void D.default.show({
            content: c.join("、") + "必须选择",
            duration: 1e3
          });
          h.length > 0 && D.default.show({
            content: "".concat(h[0].groupName, "请选").concat(h[0].limitText, "份，继续选择后再加入购物车~"),
            duration: 1e3
          })
        }
      }
    },
    closeMultiPanel: function() {
      var t = E.default.getApplyCouponId();
      t && E.default.recoverCouponStatus(t), this.data.packageTastes || this.toggleCartVisibleAction(!0), this.data.showPackagePanel || this.initContainer(), this.setData({
        showMultiPanel: !1,
        packageVisible: !0,
        weightTastes: !1,
        packageTastes: !1,
        menuSkuDish: null,
        cartSkuDish: null,
        currentSpuId: "",
        currentSkuId: "",
        specSpuId: "",
        optionsDishData: {}
      })
    },
    closePackagePanel: function() {
      var t = E.default.getApplyCouponId();
      t && E.default.recoverCouponStatus(t), this.initContainer(), this.toggleCartVisibleAction(!0), this.setData({
        showPackagePanel: !1,
        packageVisible: !1,
        weightTastes: !1,
        menuSkuDish: null,
        cartSkuDish: null,
        currentSpuId: "",
        currentSkuId: ""
      }), this.updateEditSkuDishAction({
        editDishSpuId: null,
        editDishGoodsNo: null
      })
    },
    addTastesFn: function(t) {
      var a = t.detail,
        i = a.cartSku,
        n = a.menuSku,
        u = a.type,
        l = void 0 === u ? o.OPERATE_PACKAGE_TASTE_TYPE.ADD : u,
        d = i.goodsNo,
        c = this.data,
        h = c.cartPackageSku,
        p = c.menuPackageSku,
        D = c.showDishRemark,
        S = c.shopId,
        g = c.discount,
        P = (0, r.selectPackageTastes)(h, p, i, n, l);
      if (this.setData(e(e({}, P), {}, {
          modifyCartPackageSkuFromSpecsPanel: {
            multiOperateType: l,
            goodsNo: d
          }
        })), P.showMultiPanel) {
        var m = P.cartSkuDish,
          C = (0, I._transferToRefactorCartDishInfo)(m);
        if (null != m && m.spuId) {
          var k, f, E, T = e(e({}, n), {}, {
              skuMenuItems: [n]
            }),
            v = (0, s.getDishListFromStore)(!1, S),
            A = v[(null == T ? void 0 : T.spuId) || ""] || {},
            O = (null == m ? void 0 : m.count) || 0,
            w = (null == m ? void 0 : m.weight) || 0,
            M = (null == m ? void 0 : m.skuId) || "",
            N = null != (k = null == (f = A.specAttrs) ? void 0 : f.map((function(t) {
              var e = t.specKeys,
                a = t.specValues;
              return {
                specKeys: e,
                specValues: null == a ? void 0 : a.filter((function(t) {
                  var e;
                  return t.key === (null == n || null == (e = n.specAttrs) || null == (e = e[0]) ? void 0 : e.valueId) + ""
                }))
              }
            }))) ? k : [];
          this.setData({
            specSpuId: m.spuId,
            menuSku: n,
            optionsDishData: {
              optionsDishParams: {
                selectedSkuId: M,
                dishCount: O,
                dishWeight: w
              },
              hiddenSpec: !1,
              selectedDishData: m.groupType === o.GROUP_TYPE.FIXED || l === o.OPERATE_PACKAGE_TASTE_TYPE.MODIFY ? (0, _.getSelectedDishDataFromSimpleCartDish)(T, C) : null,
              fromPackagePanel: !0,
              hiddenAddDishButton: !0,
              showDishRemark: D,
              discount: g,
              dish: e(e(e({}, n), N.length ? {
                specAttrs: N
              } : {}), {}, {
                skuMenuItems: [n],
                recommendTags: A.recommendTags || [],
                dishDescribeTag: A.dishDescribeTag || [],
                detailDescription: null == (E = v[n.spuId]) ? void 0 : E.detailDescription
              })
            }
          })
        }
      }
    },
    minusPackageSkuDishFn: function(t) {
      var a = t.detail,
        i = a.cartSku,
        s = a.menuSku,
        n = this.data.cartPackageSku,
        o = (0, r.minusPackageSkuDish)(n, i, s);
      this.setData(e({}, o))
    },
    nextInCalcFn: function(t) {
      var a, i = t.detail.calcValue,
        s = this.data,
        n = s.spuDish,
        u = s.refactorLocalCart,
        l = s.cartSkuDish,
        d = s.cartPackageSku,
        c = s.calcStatus,
        h = s.showMultiPanel,
        p = s.showPackagePanel,
        D = s.cartDishList,
        S = s.cartDishSortMapList,
        g = s.shopId,
        P = s.tableNum,
        m = s.dishAddFrom,
        C = s.mustDishCartDiff,
        f = s.operationSkuDish,
        E = s.containerOpenExtraData,
        T = s.currentSpuId,
        v = s.currentSkuId,
        A = s.editDishGoodsNo,
        O = s.showDishRemark,
        w = s.currentDiscount;
      a = n.dishType === o.DISH_TYPE.NORMAL ? l || f : d;
      var M = (0, r.nextInCalc)(n, u, a, c, i, h, p, C, D);
      if (M.calcValue && this.setData({
          calcValue: M.calcValue
        }), "weight" === M.updateDish) {
        var N = (0, r.addWeightDish)(n, i, l);
        if (N.showMultiPanel) {
          var b, R, y = null == (b = N.cartSkuDish) ? void 0 : b.weight,
            L = null == u || null == (R = u.refactorCartDishMap[T]) ? void 0 : R.find((function(t) {
              return t.itemNo === A
            }));
          L && (L.weight = y || L.weight), this.setData({
            specSpuId: n.spuId,
            optionsDishData: {
              fromWeightPanel: !0,
              optionsDishParams: {
                dishWeight: y,
                dishCount: 0
              },
              selectedDishData: L ? (0, _.getSelectedDishDataFromSimpleCartDish)(n, L) : null,
              hiddenAddDishButton: !0,
              showDishRemark: O,
              discount: w
            }
          })
        } else this.toggleContainerPanelAction(!1), this.updateCurrentDishId({
          currentSpuId: "",
          currentDiscount: ""
        }), this.addToCart(N.cartSkuDish), this.reportParams({
          spuDish: n,
          dishAddFrom: m,
          containerOpenExtraData: E
        });
        this.setData(e({}, N))
      } else if ("count" === M.updateDish) {
        var H = (0, r.updateDishCount)(p, h, i, a, S, D, C);
        if (h) {
          var F = (0, I._transferToRefactorCartDishInfo)(H.cartSkuDish);
          this.setData({
            cartSkuDish: H.cartSkuDish,
            optionsDishData: {
              hiddenSpec: !!v,
              selectedDishData: (0, _.getSelectedDishDataFromSimpleCartDish)(n, F),
              showDishRemark: !0,
              discount: w
            }
          }), this.setData({})
        } else if (p) this.setData({
          cartPackageSku: H.cartPackageSku
        });
        else {
          var q;
          this.setData({
            cartSkuDish: null
          }), this.operationDispatch(k.OPERATE_TYPE.SET, H.cartSkuDish), this.updateCart(g, P, H.cartDishList, H.cartDishSortMapList, {
            type: k.UPDATE_CART_TYPE.ADD_DISH,
            skuId: null == (q = H.cartSkuDish) ? void 0 : q.skuId
          }), this.updateAddOnList(), 0 === Object.keys(H.cartDishList).length && this.closeCartPanel()
        }
        this.closeCalcPanelFn()
      }
    },
    closeCalcPanelFn: function() {
      var t = this.data,
        e = t.showMultiPanel,
        a = t.showPackagePanel;
      this.setData({
        calcValue: 0,
        multiVisible: !0,
        packageVisible: !0,
        showCalculatorPanel: !1,
        currentSkuId: ""
      }), e || a || this.initContainer(), this.closeCalcPanel(), this.updateCalculator({
        isShowCountCalc: !1
      })
    },
    initContainer: function() {
      this.toggleContainerPanelAction(!1), this.updateEditSkuDishAction({
        editDishSpuId: null,
        editDishGoodsNo: null
      }), this.updateCurrentDishId({
        currentSpuId: "",
        currentSkuId: "",
        __newReportConfig__: null,
        currentDiscount: ""
      })
    },
    showClaPanel: function(t) {
      var e = this.data,
        a = e.shopId,
        i = e.specSpuId,
        n = t.detail.selectedDishData,
        u = (0, s.getDishListFromStore)(!1, a)[i],
        r = (0, p.transToCartDish)(n, u);
      this.setData({
        cartSkuDish: r,
        calcValue: n.count,
        calcStatus: o.CALCULATOR_STATUS.ADD,
        showCalculatorPanel: !0,
        multiVisible: !1
      })
    },
    togglePackageDetailsPanel: function(t) {
      var e = this.data.isShowDetailPanel,
        a = e ? [] : (0, l.TransPanelDetailsData)(t);
      e && (this.initContainer(), this.setData({
        isShowDetailPanel: !1
      })), a.length && this.setData({
        isShowDetailPanel: !e,
        packageDetailList: a
      })
    },
    updateDishRemarkFn: function(t) {
      var a = this.data.cartPackageSku,
        i = t.detail.remarkText,
        s = void 0 === i ? "" : i,
        n = e(e({}, a), {}, {
          remark: s
        });
      this.setData({
        cartPackageSku: n
      })
    },
    reportMultiPanel: function(t) {
      var e = this.data,
        a = e.shopId,
        i = e.specSpuId,
        s = e.containerOpenExtraData,
        n = M.default.getDishList(a, !1)[i];
      if (n && Object.keys(n).length) {
        var o = (null == s ? void 0 : s.reportConfig) || {};
        if (o.fromSearch) {
          var u = o.index,
            r = {
              dished_id: n.spuId,
              dishes_name: n.spuName,
              dishes_index: u,
              dishes_price: n.currentPrice,
              dishes_status: 0
            };
          1 === t ? (0, g.sendMC)("b_saaspay_uzban5cg_mc", null, null, r) : (0, g.sendMV)("b_saaspay_bsz9zphw_mv", null, null, r)
        }
        if (o.fromDishList) {
          var l = o.categoryId,
            d = o.belongCategory,
            c = o.index,
            h = {
              tab_id: l,
              tab_name: null == d ? void 0 : d.parentName,
              dished_id: n.spuId,
              dishes_name: n.spuName,
              dishes_index: c,
              dishes_price: n.currentPrice,
              dishes_status: 0
            };
          1 === t ? (0, g.sendMC)("b_saaspay_bsz9zphw_mc", null, null, h) : (0, g.sendMV)("b_saaspay_bsz9zphw_mv", null, null, h)
        }
      }
    }
  },
  ready: function() {
    this.limoReady()
  }
});