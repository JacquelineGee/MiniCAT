var e = require("../../../b/helpers/interopRequireDefault")(require("../../../miniprogram_npm/@limo/core/index.js")),
  t = require("../../../miniprogram_npm/@limo/container/behaviors/index");
Component({
  behaviors: [t.commonBehavior, t.limoShim],
  properties: {
    toUseRequestData: {
      type: Object,
      value: {}
    },
    applicableChannelList: {
      type: Array,
      value: []
    },
    isUseMenuCache: {
      type: Boolean,
      value: !1
    }
  },
  methods: {
    closeChannelPanel: function() {
      this.closeDialog("applicable-channel-panel")
    },
    checkWeiQian: function(e) {
      return e.indexOf("tenantId=11103980") > 0
    },
    jumpToOrder: function(t) {
      var i = this,
        a = t.currentTarget.dataset.redirectUrl || t.currentTarget.redirectUrl,
        r = t.currentTarget.dataset.biztype || t.currentTarget.biztype;
      if (this.properties.isUseMenuCache && 1 === r && a && this.checkWeiQian(a)) {
        var n = e.default.getLimoRuntime().getStorageSync("new_rms_menuorder_MENU_OPTIONS");
        if (n && e.default.getLimoRuntime().isWxNative && e.default.getLimoRuntime().switchTab) return void e.default.getLimoRuntime().switchTab({
          url: "/pages/menu/index?" + n,
          fail: function() {
            i.defaultJump()
          }
        });
        if (n && my && my.switchTab) return void my.switchTab({
          url: "/pages/menu/index?" + n,
          fail: function() {
            i.defaultJump()
          }
        })
      }
      a && this.defaultJump(a)
    },
    defaultJump: function(t) {
      e.default.getLimoRuntime().navigateTo({
        url: t
      })
    }
  }
});