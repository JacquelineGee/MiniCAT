Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.default = void 0;
var e = require("../../../../b/helpers/objectSpread2"),
  s = require("../../../../modules/LXHelper"),
  a = require("../../../../modules/menu/dish/expose"),
  t = require("../../../../constants/bizConstants"),
  d = require("../../../../constants/lxConstants"),
  n = Behavior({
    properties: {
      mpUserInfo: {
        type: Object,
        value: {}
      },
      reportConfig: {
        type: Object
      },
      addFrom: {
        type: String,
        value: ""
      }
    },
    data: {
      CLICKTYPE: {
        ADD: "ADD",
        MINUS: "MINUS",
        SELECT: "SELECT"
      }
    },
    methods: {
      commonBehaviorsCommon_limoAttached: function() {},
      doAction: function(e) {
        "number" === e && this.addDish()
      },
      clickReport: function(n, i, o) {
        var _, r, u = this;
        if (i) {
          var l = [],
            m = n || {},
            p = m.fromRecommend,
            E = m.fromDishList,
            c = m.fromSearch,
            T = m.addFrom,
            I = m.recommendReportParams;
          if (E || p || T) {
            var h = {
              ADD: "b_saaspay_q03j1tqs_mc",
              MINUS: "b_saaspay_9tpv3ev7_mc",
              SELECT: "b_saaspay_bj6jkfqo_mc"
            };
            h[o] && l.push(h[o])
          } else if (c) {
            var D = {
              ADD: "b_saaspay_uzban5cg_mc",
              MINUS: "b_saaspay_fv86ah1e_mc",
              SELECT: "b_saaspay_tdqn41gx_mc"
            };
            D[o] && l.push(D[o])
          }
          var S = i.skuMenuItems || [];
          l.forEach((function(a) {
            var t;
            (0, s.sendMC)(a, null, null, {
              clickData: e(e({
                isRecommend: !!p
              }, n || {}), {}, {
                spuId: i.spuId,
                skuId: o !== u.data.CLICKTYPE.SELECT && S[0] ? S[0].skuId : "",
                spuName: i.spuName,
                addFrom: u.data.addFrom,
                isFirstScreen: (null == I || null == (t = I.firstScreenSpuIds) ? void 0 : t.indexOf(null == i ? void 0 : i.spuId)) > -1 ? 1 : 0
              })
            })
          }));
          var C = d.OP_TYPE.OTHER,
            y = d.OP_NAME.OTHER,
            N = "",
            O = (null == n ? void 0 : n.index) || 0;
          n && n.addFrom === a.EXPOSE_DISH_TYPE.CART && (C = d.OP_TYPE.CART), n && 1 === n.fromNetRecommend && (C = d.OP_TYPE.RECOMMEND_DISH, y = d.OP_NAME.RECOMMEND_NET, N = t.TITLE_CONTENT.NET, O = null == n ? void 0 : n.index, (0, s.sendMC)("b_saaspay_psxksd3d_mc", null, null, {
            clickData: {
              recommend_type: t.RECOMMEND_CATEGORY.NET,
              show_type: I && I.recommendShowType,
              show_title: N,
              dish_quantity: I && I.dish_quantity,
              sn: O,
              spu_id: i.spuId
            }
          })), n && 0 === n.fromNetRecommend && (C = d.OP_TYPE.RECOMMEND_DISH, y = d.OP_NAME.RECOMMEND_BOSS, N = t.TITLE_CONTENT.BOSS, O = null == n ? void 0 : n.index, (0, s.sendMC)("b_saaspay_psxksd3d_mc", null, null, {
            clickData: {
              recommend_type: t.RECOMMEND_CATEGORY.BOSS,
              is_defined_title: I && I.bossRecommendText ? t.DEFINED_TITLE.DEFINED : t.DEFINED_TITLE.DEFAULT,
              show_type: I && I.recommendShowType,
              show_title: N,
              dish_quantity: I && I.dish_quantity,
              sn: O,
              spu_id: i.spuId
            }
          })), n && n.fromSearch && (C = d.OP_TYPE.SEARCH_LIST);
          var f = e({}, {
            op_type: C,
            dish_details_func_area: t.DISH_DETAIL.MAIN_DISH,
            op_name: y,
            recommend_mode: i.recommendType,
            sn: O,
            algorithm: "",
            sku_id_list: i.skuId || (null == (_ = i.skuMenuItems) || null == (_ = _[0]) ? void 0 : _.skuId) || "",
            spu_id_list: i.spuId,
            dish_name_list: i.spuName || i.skuName,
            dish_type: i.dishType,
            add_dish_quantity: "",
            isFirstScreen: (null == I || null == (r = I.firstScreenSpuIds) ? void 0 : r.indexOf(null == i ? void 0 : i.spuId)) > -1 ? 1 : 0
          });
          N && (f = e({
            show_title: N
          }, f)), o === this.data.CLICKTYPE.ADD && (0, s.sendMC)("b_saaspay_bsz9zphw_mc", null, null, {
            clickData: e({}, f)
          })
        }
      },
      onTapHandle: function(e) {
        (null == e ? void 0 : e.stopPropagation) && e.stopPropagation(), this.doAction(e.currentTarget.type || e.currentTarget.dataset.type || "")
      }
    }
  });
exports.default = n;