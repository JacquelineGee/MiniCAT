var t = require("../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports._transferToSimpleCartDishInfo = k, exports.calculateCartDishListDiff = function(t, u) {
  var n = [],
    r = Object.keys(u),
    o = Object.keys(t);
  return e(new Set(r.concat(o))).forEach((function(r) {
    var o = u[r],
      a = t[r];
    if (o && a) {
      var s = o.map((function(t) {
          return t.goodsNo
        })),
        i = a.map((function(t) {
          return t.goodsNo
        }));
      e(new Set(s.concat(i))).forEach((function(t) {
        var e = o.find((function(e) {
            return e.goodsNo === t
          })),
          u = a.find((function(e) {
            return e.goodsNo === t
          }));
        if (e && u) {
          var r = (e.count || 0) - (u.count || 0);
          r && n.push(I(e, r))
        } else if (e && !u) n.push(I(e, e.count));
        else if (!e && u) {
          var s = u.canWeight ? u.weight : u.count;
          n.push(I(u, -s))
        }
      }))
    } else o && !a ? o.forEach((function(t) {
      n.push(I(t, t.count))
    })) : !o && a && a.forEach((function(t) {
      var e = t.canWeight ? t.weight : t.count;
      n.push(I(t, -e))
    }))
  })), n
}, exports.calculateMethodsCount = function(t) {
  var e = 0;
  return null != t && t.length ? (t.forEach((function(t) {
    var u;
    e += (null == t || null == (u = t.items) ? void 0 : u.length) || 0
  })), e) : e
}, exports.calculateTastesCount = function(t) {
  var e = 0;
  return null != t && t.length ? (t.forEach((function(t) {
    t.items.forEach((function(t) {
      e += (null == t ? void 0 : t.count) || 0
    }))
  })), e) : e
}, exports.computeAddPrice = f, exports.computePackageAddPrice = function(t) {
  var e = t.packageGroups,
    u = (0, n.default)([]),
    r = 0;
  return e.map((function(t) {
    var e = t.groupSkus,
      o = (0, n.default)([]);
    e.map((function(t) {
      var e;
      if (t.count > 0)
        if (e = f(t), t.canWeight) r += (0, i.plusFloat)((0, i.multiFloat)(e.addPrice, e.weight * e.count) + e.extraPrice);
        else {
          var u = e.count * e.number;
          r += (0, i.multiFloat)((0, i.plusFloat)(e.extraPrice, e.addPrice), u)
        }
      else e = t.number > 0 ? f(t) : n.default.set(t, "extraPrice", function(t) {
        if (!t.length) return 0;
        var e = 0;
        return t.forEach((function(t) {
          null == t || t.forEach((function(t) {
            e += (null == t ? void 0 : t.price) || 0
          }))
        })), e
      }(null == t ? void 0 : t.methods) || 0);
      return o = o.concat([e]), null
    }));
    var a = n.default.set(t, "groupSkus", o);
    return u = u.concat([a]), null
  })), n.default.merge(t, {
    packageGroups: u,
    extraPrice: r
  })
}, exports.computeSkuCount = function(t, e) {
  var u = e[t.spuId.toString()],
    n = 0;
  return u && u.forEach((function(e) {
    e.skuId === t.skuId && (n += e.count)
  })), n
}, exports.getGrouponTip = function(t, e) {
  var u = "",
    r = !1,
    o = t.goodsNo || t.itemNo;
  return n.default.getIn(e, [o, "count"]) > 0 && (u = "已使用".concat(n.default.getIn(e, [o, "count"]), "张团购券"), r = !0), {
    grouponTip: u,
    isCouponDish: r
  }
}, exports.getLimitDescList = function(t, e) {
  var u = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
    n = t.minBoughtCount,
    r = t.stockCount;
  e && (r = e.stockCount);
  var o = t.unit || "份";
  return r && r > -1 && r < a.MAX_SHOW_STOCK_COUNT ? "仅剩 ".concat(r, " ").concat(o) : n && n > 1 && !u ? "".concat(n, " ").concat(o, "起售") : ""
}, exports.getPointPurchaseSpu = void 0, exports.getSingleSpu = g, exports.getUnveriedDishText = function(t) {
  var u = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
    n = new Set;
  t.forEach((function(t) {
    n = n.add(t.skuName)
  }));
  var r = e(n).join("、");
  return r += u ? "的菜品信息发生变化，已为您自动更新" : "的菜品信息发生变化，将为您从购物车删除"
}, exports.judgeComplexSpuDish = function(t) {
  return !!(t.methods && t.methods.length > 0 || t.tastes && t.tastes.length > 0)
}, exports.judgeFeedingExist = p, exports.judgeFixedPackage = function(t) {
  var e;
  return m(t) && (null == t || null == (e = t.skuMenuItems) || null == (e = e[0]) ? void 0 : e.noNeedChoosePackageGroups)
}, exports.judgeMultiDish = d, exports.judgePackageEnableAdd = function(t) {
  var e = !0,
    u = [],
    n = [],
    r = [];
  if (t) return t.packageGroups ? (t.packageGroups.map((function(t) {
    if (t.groupSkus.reduce((function(t, e) {
        return t + e.count
      }), 0) < (0, s.getPackageGroupLimitNum)(t).minCount) {
      e = !1;
      var o = (0, s.getPackageGroupLimitText)(t);
      n.push({
        groupId: t.groupId,
        groupName: t.groupName,
        limitText: o
      })
    }
    return t.groupSkus.map((function(t) {
      return t.required && !t.count && (e = !1, u.push(t.skuName), r.push(t.groupId)), null
    })), null
  })), {
    enableClick: e,
    mustChildDishs: u,
    notFullGroup: n,
    mustDishGroup: r
  }) : {
    enableClick: e,
    mustChildDishs: u,
    notFullGroup: n,
    mustDishGroup: r
  };
  return {
    enableClick: e,
    mustChildDishs: u,
    notFullGroup: n,
    mustDishGroup: r
  }
}, exports.judgePackageSpuDish = m, exports.selectTastes = function(t) {
  var e = t.methods,
    u = t.tastes,
    n = !1;
  return e && e.length > 0 && e.map((function(t) {
    var e = t.items;
    return e && e.length > 0 && e.map((function(t) {
      return t.defaultSelected || (n = !0), null
    })), null
  })), u && u.length > 0 && u.map((function(t) {
    var e = t.items;
    return e && e.length > 0 && (n = !0), null
  })), n
}, exports.setCartSkuAttrs = function(t) {
  var e, r = n.default.asMutable(t, {
      deep: !0
    }),
    o = (0, l.initAttrsMatrix)(r),
    a = function(t) {
      if (!t) return [];
      var r = t.map((function(t) {
        var n = t.items,
          r = t.groupId,
          a = t.groupName,
          s = t.type,
          i = [];
        return n.forEach((function(t) {
          var n = t.defaultSelected,
            c = t.id,
            p = t.soldOut;
          if (n && !p) {
            var d = (0, l.dealDefaultMutex)(o, {
              groupId: r,
              type: s,
              id: c
            }, e);
            e = d.mutexMatrix;
            var f = u(u({}, t), {}, {
              groupId: r,
              groupName: a
            });
            2 === s && (f.count = 1), d.success && i.push(f)
          }
        })), i
      }));
      return (0, n.default)(r)
    };
  return {
    newMethods: a(r.methods),
    newTastes: a(r.tastes)
  }
}, exports.stopPollTask = void 0, exports.transferToOperateDish = I;
var e = require("../b/helpers/toConsumableArray"),
  u = require("../b/helpers/objectSpread2"),
  n = t(require("../miniprogram_npm/seamless-immutable/index.js")),
  r = t(require("../api/rmsStorage")),
  o = t(require("../lib/mix/log")),
  a = require("../constants/bizConstants"),
  s = require("./panel/panelHelper"),
  i = require("../lib/number"),
  l = require("./panel/spec/mutex"),
  c = t(require("./menu/shop/shopService"));

function p(t) {
  if (!t || 0 === t.length) return !1;
  var e = !1;
  return t.map((function(t) {
    return t && t.length > 0 && (e = !0), null
  })), e
}

function d(t) {
  var e = t.specAttrs;
  if (!e || 0 === e.length) return !1;
  var u = n.default.getIn(e, [0, "specValues"]);
  return !!(u && u.length > 1)
}

function f(t) {
  var e = t.weight || 1,
    u = t.methods,
    r = t.tastes,
    o = 0;
  return u && u.length > 0 && u.map((function(t) {
    return t && t.length > 0 && (null == t || t.map((function(t) {
      var u = t.priceType;
      return o = u === a.PRICE_TYPE.PRO_PORTION ? (0, i.plusFloat)(o, (0, i.multiFloat)(t.price, e)) : (0, i.plusFloat)(o, t.price), null
    }))), null
  })), r && r.length > 0 && r.map((function(t) {
    return t && t.length > 0 && (null == t || t.map((function(t) {
      var e = (0, i.multiFloat)(t.price, t.count);
      return o = (0, i.plusFloat)(o, e), null
    }))), null
  })), n.default.set(t, "extraPrice", o)
}

function m(t) {
  return !!t && !(!t.skuMenuItems || !t.skuMenuItems.length) && t.skuMenuItems.some((function(t) {
    return t.packageGroups && t.packageGroups.length > 0
  }))
}

function g(t, e) {
  var u = t.skuMenuItems.find((function(t) {
    return t.skuId === e.skuId
  }));
  return n.default.merge(t, {
    specAttrs: (0, n.default)([]),
    skuMenuItems: (0, n.default)([u])
  })
}
exports.getPointPurchaseSpu = function(t) {
  var e, r = c.default.getShopServiceData().fmpBizData,
    o = (null == r || null == (e = r.pointBuyCampaign) ? void 0 : e.pointDishList) || [],
    a = null == o ? void 0 : o.find((function(e) {
      return e.spuId === t.spuId
    }));
  if (!a) return {
    pointDish: t,
    currentSkuId: ""
  };
  var s = null == a ? void 0 : a.pointDishItems,
    i = t,
    l = "";
  if (d(t) && null != s && s.length) {
    if (1 === s.length) i = g(t, s[0]), l = s[0].skuId;
    else {
      var p;
      i = t;
      var f = [],
        m = [];
      t.skuMenuItems.forEach((function(t) {
        s.find((function(e) {
          return e.skuId === t.skuId
        })) && t.specAttrs && (m.push(t), f.push({
          key: t.specAttrs[0].valueId + "",
          value: t.specAttrs[0].value
        }))
      })), i = n.default.merge(t, {
        specAttrs: (0, n.default)([{
          specKeys: null == t || null == (p = t.specAttrs) ? void 0 : p[0].specKeys,
          specValues: f
        }]),
        skuMenuItems: (0, n.default)(m)
      })
    }
    var h = i.skuMenuItems[0],
      v = h.stockCount,
      k = h.soldOut,
      I = h.validity;
    i = u(u({}, i), {}, {
      stockCount: v || i.stockCount,
      soldOut: k,
      validity: I
    })
  }
  return {
    pointDish: i,
    currentSkuId: l
  }
};

function h(t) {
  var e = (0, n.default)([]);
  return p(t) ? (t.map((function(t) {
    if (t.length > 0) {
      var u = (0, n.default)({
          groupId: n.default.getIn(t, [0, "groupId"]),
          groupName: n.default.getIn(t, [0, "groupName"])
        }),
        r = (0, n.default)([]);
      t.map((function(t) {
        return r = r.concat([{
          id: t.id,
          name: t.name,
          count: t.count || 1
        }]), null
      })), u = n.default.set(u, "items", r), e = e.concat([u])
    }
    return null
  })), e) : e
}

function v(t) {
  var e = (0, n.default)([]);
  return Array.isArray(t) && 0 !== t.length ? (t.map((function(t) {
    var u = (0, n.default)({
        groupId: t.groupId,
        groupName: t.groupName
      }),
      r = (0, n.default)([]);
    return t.groupSkus.map((function(t) {
      var e = (0, n.default)({
        spuId: t.spuId,
        skuId: t.skuId,
        skuName: t.skuName,
        number: t.number,
        count: t.count,
        sum: t.number * t.count,
        weight: t.weight,
        methods: h(t.methods),
        tastes: h(t.tastes)
      });
      return e.count > 0 && (r = r.concat([e])), null
    })), u = n.default.set(u, "groupSkus", r), e = e.concat([u]), null
  })), e) : e
}

function k(t) {
  var e = t.goodsNo,
    u = t.tastes,
    n = t.methods,
    r = t.packageGroups,
    o = t.spuId,
    a = t.skuId,
    s = t.skuName,
    i = t.mustCount,
    l = t.createTime,
    c = t.remark,
    p = t.manualCampaigns,
    d = t.campaignId,
    f = t.discount;
  return {
    itemNo: e,
    tastes: h(u),
    methods: h(n),
    packages: v(r),
    spuId: o,
    skuId: a,
    skuName: s,
    mustCount: i,
    createTime: l,
    remark: c,
    manualCampaigns: p,
    campaignId: d,
    discount: f
  }
}

function I(t, e) {
  var u = k(t),
    r = void 0 !== e;
  if (t.canWeight) {
    var o = r ? e : t.weight;
    return n.default.merge(u, {
      operateWeight: o
    })
  }
  var a = r ? e : t.count;
  return n.default.merge(u, {
    operateCount: a
  })
}
exports.stopPollTask = function() {
  var t = Number(r.default.getTimeOutId() || 0);
  try {
    t && (clearTimeout(t), r.default.setTimeOutId({}))
  } catch (e) {
    o.default.addError("轮询停止失败", t)
  }
};