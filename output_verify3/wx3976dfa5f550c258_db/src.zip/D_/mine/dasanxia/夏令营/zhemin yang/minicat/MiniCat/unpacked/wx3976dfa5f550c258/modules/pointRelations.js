var e = require("../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.getCampaignRelationsToCart = void 0;
var t = require("../constants/menu"),
  i = e(require("../store/menu")),
  r = e(require("../miniprogram_npm/@mtfe/rms-triangle-c/index.js"));
exports.getCampaignRelationsToCart = function(e) {
  var a = {},
    o = [];
  if (r.default.isWxNative || r.default.isAliPayNative)
    for (var n in e.forEach((function(e) {
        if (e.discount === t.POINT_DISH_TYPE) {
          var r, o = null == (r = i.default.getState()) ? void 0 : r.pointRelations[e.skuId];
          a[o] ? a[o].push(e.goodsNo) : a[o] = [e.goodsNo]
        }
      })), a) o.push({
      campaignId: n,
      itemNos: a[n]
    });
  return {
    campaignAndGoodsRelations: o
  }
};