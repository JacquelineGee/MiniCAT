var e = require("../../../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.initPackage = function(e, n) {
  var i, o = r.default.getIn(e, ["skuMenuItems", 0]);
  i = n && n.refactorCartDishMap[o.spuId] || -1 === e.minBoughtCount ? e.incBoughtCount : e.minBoughtCount;
  var s = r.default.set(o, "count", i),
    c = o.packageGroups,
    p = (0, u.initPackageGroups)(c, t.INIT_PACKAGE.ADD);
  return s = r.default.merge(s, {
    packageGroups: p,
    categoryId: r.default.getIn(e, ["parentCategoryId", 0])
  }), s = (0, a.computePackageAddPrice)(s), {
    menuPackageSku: o,
    cartPackageSku: s
  }
};
var r = e(require("../../../miniprogram_npm/seamless-immutable/index.js")),
  t = require("../../../constants/bizConstants"),
  a = require("../../cartHelper"),
  u = require("../../operateCartHelper");