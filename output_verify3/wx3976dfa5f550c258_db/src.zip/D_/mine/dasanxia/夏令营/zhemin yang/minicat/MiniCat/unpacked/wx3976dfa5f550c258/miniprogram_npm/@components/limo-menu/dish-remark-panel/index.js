var t = require("../../../../b/helpers/interopRequireDefault"),
  e = t(require("../../../@limo/core/index.js")),
  a = require("../../../@limo/container/behaviors/index"),
  i = t(require("../../../../api/rmsStorage")),
  n = t(require("../../../../lib/mix/log")),
  o = require("../../../../lib/mix/util"),
  r = require("../../limo-ui/ui-constant/enum"),
  u = require("../../../../constants/ajaxResCode"),
  s = /[^\u0020-\u007E\u00A0-\u00BE\u2E80-\uA4CF\uF900-\uFAFF\uFE30-\uFE4F\uFF00-\uFFEF\u0080-\u009F\u2000-\u201f\u2026\u2022\u20ac\r\n]/gi,
  l = n.default;
Component({
  behaviors: [a.commonBehavior, a.limoShim],
  properties: {
    shopId: {
      type: String,
      value: ""
    },
    remarkText: {
      type: String,
      value: "",
      observer: function(t) {
        t && this.setData({
          inputValue: t
        })
      }
    },
    name: {
      type: String,
      value: ""
    },
    orderRemarkDefaultWord: {
      type: String,
      value: ""
    },
    isNativeTabbarPage: {
      type: Boolean,
      value: !1
    }
  },
  data: {
    maxInputLength: 50,
    btnType: r.BUTTON_TYPE.DEFAULT,
    uiSize: r.UI_SIZE.LARGE,
    remarkButtonText: "确定",
    inputValue: "",
    historyRemakList: [],
    spaceHeight: 300,
    textColorStyle: ""
  },
  attached: function() {
    this.limoAttached()
  },
  methods: {
    limoAttached: function() {
      var t = this.data.shopId,
        e = i.default.getHistoryRemarkList(t) || [];
      null != e && e.length ? this.setData({
        historyRemakList: e
      }) : this.getDishHistoryRemark()
    },
    getDishHistoryRemark: function() {
      var t = this,
        a = this.data.shopId;
      e.default.getLimoRuntime().request({
        url: (0, o.getHost)() + "/diancan/api/queryUserDishTags",
        method: "GET",
        data: {
          mtShopId: a
        },
        complete: function(e) {
          var n;
          if (null != e && null != (n = e.data) && n.data) {
            var o = e.data.data.quickTagList,
              r = void 0 === o ? [] : o;
            i.default.setHistoryRemarkList(a, r), t.setData({
              historyRemakList: r
            })
          }
        },
        fail: function(t) {
          l.addError("获取历史标签失败", t)
        }
      })
    },
    handleInput: function(t) {
      var a = t.detail.value,
        i = this.data.maxInputLength,
        n = "grey";
      a.length >= i ? (e.default.getLimoRuntime().showToast({
        title: "最多输入".concat(i, "字"),
        icon: "none",
        duration: 2e3
      }), a = a.slice(0, i), n = "red") : a.length && (n = "black"), this.setData({
        inputValue: a,
        textColorStyle: n
      })
    },
    onConfirm: function() {
      var t = this,
        a = this.data,
        i = a.inputValue,
        n = a.shopId,
        r = i.replace(s, "");
      e.default.getLimoRuntime().request({
        url: (0, o.getHost)() + "/diancan/api/remark/confirm",
        method: "POST",
        data: {
          shopId: n,
          dishRemarks: [r]
        },
        complete: function(a) {
          a && ((a.data || {}).code === u.RES_CODE.PORSCHE_FAIL ? e.default.getLimoRuntime().showToast({
            title: "备注含有敏感词，请修改后保存",
            icon: "none"
          }) : t.triggerEvent("remarkConfirm", {
            remarkText: r
          }))
        },
        fail: function(t) {
          e.default.getLimoRuntime().showToast({
            title: "备注失败，请稍后再试",
            icon: "none"
          }), l.addError("备注失败", t)
        }
      })
    },
    checkedHistoryRemark: function(t) {
      var a = t.currentTarget.dataset.val,
        i = this.data,
        n = i.inputValue,
        o = i.maxInputLength,
        r = n ? "".concat(n, "，").concat(a) : a;
      r.length > o ? e.default.getLimoRuntime().showToast({
        title: "最多输入".concat(o, "字"),
        icon: "none",
        duration: 2e3
      }) : this.setData({
        inputValue: r
      })
    },
    closePanel: function() {
      this.triggerEvent("closeDishRemarkPanel")
    },
    onTextFocus: function(t) {
      if (this.isH5) {
        var e = t.target;
        setTimeout((function() {
          e.scrollIntoView(!0)
        }), 300)
      }
    }
  }
});