var e = require("../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.default = void 0;
var t = e(require("../lib/mix/request")),
  r = require("../lib/mix/util"),
  i = {
    getDishMoreDetail: function(e) {
      return t.default.post((0, r.getHost)() + "/diancan/menu/api/dishMoreDetail", e, {
        withCredentials: !0
      })
    },
    getRelatedSpuRecommend: function(e) {
      return t.default.post("/relatedSpuRecommend", e)
    },
    getShareDish: function(e) {
      return t.default.post((0, r.getHost)() + "/diancan/api/dish/queryShareInfo", e)
    }
  };
exports.default = i;