var e = require("../../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.getTakeawayPageUrl = exports.getParamsFromCookie = void 0;
e(require("../../lib/wx/log"));
var r, i = require("../../lib/env"),
  t = require("../../lib/mix/util"),
  a = e(require("../../api/rmsStorage")),
  o = e(require("../../miniprogram_npm/@mtfe/rms-triangle-c/index.js")),
  n = (require("../../config/index.js"), require("../../lib/wx/app-info")),
  s = require("../../constants/bizConstants"),
  u = require("../../constants/path");
r = "";
exports.getParamsFromCookie = function(e) {
  var r = +(0, t.getMixUrlParam)("bizType");
  return r !== s.BIZ_TYPE_MAP.TAKEAWAY && r !== s.BIZ_TYPE_MAP.PICKUP || !i.isWxNative ? "" : ((0, n.getCookieInfo)() || {})[e] || ""
};
exports.getTakeawayPageUrl = function(e, r, i, t) {
  var a = {
    shopId: e || "",
    tenantId: r || "",
    redirectUrl: encodeURIComponent(i),
    type: t
  };
  return o.default.appendQuery(u.PATH.takeaway + "?", a)
};