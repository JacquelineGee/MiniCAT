var e = require("../../../@limo/container/behaviors/index");
Component({
  behaviors: [e.commonBehavior, e.limoShim],
  properties: {
    offsetTop: {
      type: Number,
      value: 0
    },
    fixed: {
      type: Boolean,
      value: !1
    },
    announcementCarousel: {
      type: Object,
      value: {}
    },
    topTimeTip: {
      type: Object,
      value: {}
    }
  }
});