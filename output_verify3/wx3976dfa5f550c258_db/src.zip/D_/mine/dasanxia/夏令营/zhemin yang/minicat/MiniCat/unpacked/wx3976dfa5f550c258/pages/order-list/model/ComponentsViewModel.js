Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.default = void 0;
var e = require("../../../b/helpers/classCallCheck"),
  r = require("../../../b/helpers/createClass"),
  t = require("../../../lib/mix/util"),
  a = require("../../../constants/bizConstants"),
  n = function() {
    function n() {
      e(this, n)
    }
    return r(n, [{
      key: "formatTabBar",
      value: function(e, r) {
        var n = e.restaurantViewId,
          s = e.tenantId,
          i = e.minaId,
          u = e.entrance,
          o = void 0 === u ? 0 : u,
          l = e.shopId,
          d = {
            params: {
              restaurantViewId: n,
              tenantId: s,
              entrance: o,
              minaId: i,
              mtShopId: void 0 === l ? 0 : l
            },
            url: (0, t.getTabBarUrl)()
          };
        return {
          requestParams: (null == r ? void 0 : r.length) > 0 ? {} : d,
          selectedPageType: a.PORTAL_TAB_TYPE.ORDER,
          tabBarList: r || []
        }
      }
    }, {
      key: "formatOrderList",
      value: function(e, r, t) {
        return {
          orderList: e,
          status: r,
          errorMes: t
        }
      }
    }]), n
  }();
exports.default = n;