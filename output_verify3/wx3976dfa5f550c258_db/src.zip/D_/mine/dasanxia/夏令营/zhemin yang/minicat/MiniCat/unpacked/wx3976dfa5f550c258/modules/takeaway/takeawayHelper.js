var e = require("../../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.viewOtherShop = exports.switchBiz = exports.pullCloudData = exports.getTakeawayUrlParams = exports.getTakeawayParams = exports.getErrPageInfo = void 0;
var r = require("../../b/helpers/objectSpread2"),
  a = e(require("../../b/regenerator")),
  t = require("../../b/helpers/asyncToGenerator"),
  n = e(require("../../miniprogram_npm/@limo/core/index.js")),
  i = e(require("../../api/takeaway")),
  u = require("../../lib/mix/util"),
  o = require("../../constants/bizConstants"),
  s = require("../../constants/ajaxResCode"),
  d = e(require("../../lib/mix/loading")),
  l = e(require("../../lib/mix/toast")),
  c = require("../../lib/geo"),
  p = e(require("../../api/rmsStorage")),
  h = require("../LXHelper"),
  f = e(require("../../miniprogram_npm/@mtfe/rms-triangle-c/index.js")),
  m = require("../../lib/navigator"),
  b = e(require("../../lib/mix/log")),
  g = require("../../lib/env"),
  I = require("../../constants/path"),
  P = require("./util"),
  x = e(require("../../api/cloudDataApi")),
  v = e(require("../menu/cart/cartSdk")),
  w = require("../menu/dish/DishDataTransfer"),
  A = require("../../lib/wx/app-info"),
  T = require("../../constants/errorTip"),
  y = require("../menu/dataSource/point"),
  M = function() {
    var e = (0, u.getMixUrlParam)("restaurantViewId") || (0, P.getParamsFromCookie)("restaurantViewId"),
      r = +(0, u.getMixUrlParam)("multiShop") || +(0, P.getParamsFromCookie)("multiShop"),
      a = (0, u.getMixUrlParam)("shopId"),
      t = (0, u.getMixUrlParam)("wxAppVersion") || "",
      n = (0, u.getMixUrlParam)("tenantId") || (0, P.getParamsFromCookie)("tenantId"),
      i = (0, u.getMixUrlParam)("brandId") || (0, P.getParamsFromCookie)("brandId"),
      o = (0, u.getMixUrlParam)("orderChannel") || (0, P.getParamsFromCookie)("orderChannel"),
      s = (0, u.getMixUrlParam)("publicAccountAppId") || void 0;
    return {
      restaurantViewId: e,
      multiShop: r,
      shopId: a,
      wxAppVersion: t,
      tenantId: n,
      brandId: i,
      orderChannel: o,
      couponId: (0, u.getMixUrlParam)("couponId") || "",
      spuId: (0, u.getMixUrlParam)("spuId") || "",
      publicAccountAppId: s,
      cacheKey: (0, u.getMixUrlParam)("cacheKey") || "",
      forbidSwitchTakeAway: (0, u.getMixUrlParam)("forbidSwitchTakeAway") || !1,
      bizType: +(0, u.getMixUrlParam)("bizType"),
      launchReserveTime: (0, u.getMixUrlParam)("launchReserveTime")
    }
  };
exports.getTakeawayUrlParams = M;
var k = "1",
  _ = function() {
    var e = t(a.default.mark((function e() {
      var r, t, n, i, s, d, l, c, h, f;
      return a.default.wrap((function(e) {
        for (;;) switch (e.prev = e.next) {
          case 0:
            if (r = M(), t = r.bizType, n = r.forbidSwitchTakeAway, i = r.cacheKey, s = r.shopId, d = void 0 === s ? "" : s, t !== o.BIZ_TYPE_MAP.TAKEAWAY && t !== o.BIZ_TYPE_MAP.PICKUP) {
              e.next = 16;
              break
            }
            if (l = p.default.getUserSelectedAddress(), !g.isWxNative) {
              e.next = 15;
              break
            }
            return e.prev = 4, h = i || (0, A.getCloudDataCacheKey)() || "", e.next = 8, x.default.queryLocalData({
              cacheKey: h,
              fields: ["cartDishList"]
            });
          case 8:
            null != (f = e.sent) && null != (c = f.data) && c.cartDishList || !(0, u.isInMenuPage)() || v.default.clearLocalCartAndRelatedInfos(d + "", ""), e.next = 15;
            break;
          case 12:
            e.prev = 12, e.t0 = e.catch(4), b.default.addError("menu拉取云端数据-address-失败", e.t0);
          case 15:
            return e.abrupt("return", {
              addressId: (null == l ? void 0 : l.id) || 0,
              forbidSwitchTakeAway: n,
              bizType: t
            });
          case 16:
            return e.abrupt("return", {});
          case 17:
          case "end":
            return e.stop()
        }
      }), e, null, [
        [4, 12]
      ])
    })));
    return function() {
      return e.apply(this, arguments)
    }
  }();
exports.getTakeawayParams = _;
var C = function() {
  var e = t(a.default.mark((function e(r) {
    var u, l, I, P, x, v = arguments;
    return a.default.wrap((function(e) {
      for (;;) switch (e.prev = e.next) {
        case 0:
          if (u = v.length > 1 && void 0 !== v[1] ? v[1] : "", (0, h.sendMC)("b_saaspay_y8j3aux3_mc"), l = M(), I = (l || {}).multiShop, P = r ? o.BIZ_TYPE_MAP.TAKEAWAY : o.BIZ_TYPE_MAP.PICKUP, !I) {
            e.next = 15;
            break
          }
          if (P !== o.BIZ_TYPE_MAP.PICKUP) {
            e.next = 12;
            break
          }
          return e.next = 7,
            function() {
              var e = t(a.default.mark((function e(r) {
                var t, n, i, u, s;
                return a.default.wrap((function(e) {
                  for (;;) switch (e.prev = e.next) {
                    case 0:
                      if (t = p.default.getUserSelectedAddress(), r !== o.BIZ_TYPE_MAP.TAKEAWAY || null == t || !t.id) {
                        e.next = 3;
                        break
                      }
                      return e.abrupt("return", t);
                    case 3:
                      return n = {
                        lng: "",
                        lat: ""
                      }, e.prev = 4, e.next = 7, (0, c.getLocation)({});
                    case 7:
                      n = e.sent, e.next = 12;
                      break;
                    case 10:
                      e.prev = 10, e.t0 = e.catch(4);
                    case 12:
                      return u = (i = n).lng, s = i.lat, e.abrupt("return", {
                        longitude: u,
                        latitude: s
                      });
                    case 14:
                    case "end":
                      return e.stop()
                  }
                }), e, null, [
                  [4, 10]
                ])
              })));
              return function(r) {
                return e.apply(this, arguments)
              }
            }()(P);
        case 7:
          return x = e.sent, e.next = 10,
            function() {
              var e = t(a.default.mark((function e(r, t) {
                var u, o, l, c, p, h, I, P, x, v, w, T, y, _, C;
                return a.default.wrap((function(e) {
                  for (;;) switch (e.prev = e.next) {
                    case 0:
                      return u = M(), l = (o = u || {}).spuId, c = o.publicAccountAppId, p = o.multiShop, h = o.shopId, I = o.tenantId, P = o.restaurantViewId, x = o.orderChannel, v = o.brandId, d.default.show(""), e.prev = 2, w = {
                        tenantId: I,
                        mtShopId: h,
                        restaurantViewId: P,
                        brandId: v,
                        longitude: (null == r ? void 0 : r.longitude) || 0,
                        latitude: (null == r ? void 0 : r.latitude) || 0,
                        bizType: t,
                        publicAccountAppId: c,
                        spuId: l,
                        orderChannel: x,
                        multiShop: p,
                        switchBiz: !0
                      }, e.next = 6, i.default.matchShop(w);
                    case 6:
                      (null == (T = e.sent) ? void 0 : T.code) === s.RES_CODE.SUCCESS ? (y = (null == T ? void 0 : T.data) || {}, _ = y.schema, C = y.extraInfo, _ && (g.isNativeMp ? ((0, A.setCookieInfo)(C), n.default.getLimoRuntime().reLaunch({
                        url: _
                      })) : f.default.redirectTo({
                        url: _
                      }))) : (0, m.jumpToPage)("shop-list", {
                        bizType: t,
                        noMatchPrefer: k,
                        shopId: ""
                      }), e.next = 13;
                      break;
                    case 10:
                      e.prev = 10, e.t0 = e.catch(2), (0, m.jumpToPage)("shop-list", {
                        bizType: t,
                        noMatchPrefer: k,
                        shopId: ""
                      }), b.default.addError("matchShop失败", e.t0);
                    case 13:
                      d.default.close();
                    case 14:
                    case "end":
                      return e.stop()
                  }
                }), e, null, [
                  [2, 10]
                ])
              })));
              return function(r, a) {
                return e.apply(this, arguments)
              }
            }()(x, P);
        case 10:
          e.next = 13;
          break;
        case 12:
          S(u);
        case 13:
          e.next = 16;
          break;
        case 15:
          g.isWxNative ? (0, m.customReLaunch)("menu", {
            bizType: P,
            multiShop: I
          }) : (0, m.jumpToPage)("menu", {
            bizType: P,
            multiShop: I
          });
        case 16:
        case "end":
          return e.stop()
      }
    }), e)
  })));
  return function(r) {
    return e.apply(this, arguments)
  }
}();
exports.switchBiz = C;
exports.viewOtherShop = function(e) {
  var r = M() || {},
    a = r.multiShop,
    t = r.restaurantViewId,
    n = r.tenantId,
    i = r.brandId,
    u = r.orderChannel,
    o = r.wxAppVersion;
  if (a) {
    (0, h.sendMC)("b_saaspay_t3y4j914_mc");
    var s = {
      bizType: e,
      pageFrom: "MENU",
      restaurantViewId: t,
      noMatchPrefer: k,
      tenantId: n,
      brandId: i,
      orderChannel: u
    };
    if (g.isMpWebview && 1 === f.default.compareVersion(o, "5.22.60")) {
      var d = f.default.appendQuery(window.location.search, s);
      f.default.navigateTo("".concat(I.PATH["shop-list"]).concat(d))
    } else(0, m.jumpToPage)("shop-list", s)
  }
};
var S = function() {
    var e = t(a.default.mark((function e(r) {
      var t, n, u, s, d, l, c;
      return a.default.wrap((function(e) {
        for (;;) switch (e.prev = e.next) {
          case 0:
            if (!r) {
              e.next = 2;
              break
            }
            return e.abrupt("return", void f.default.navigateTo({
              url: r
            }));
          case 2:
            return t = M(), u = (n = t || {}).shopId, s = n.restaurantViewId, d = n.publicAccountAppId, l = "".concat(window.location.origin, "/rmstakeaway/web/address?shopId=").concat(u, "&pageFrom=MENU&restaurantViewId=").concat(s, "&bizType=").concat(o.BIZ_TYPE_MAP.TAKEAWAY, "&publicAccountAppId=").concat(d || ""), e.prev = 3, e.next = 6, i.default.getUserAddressList({});
          case 6:
            ((c = e.sent) && Array.isArray(c.data) && c.data.length ? c.data : []).length ? window.location.href = l : window.location.href = l + "#/edit", e.next = 13;
            break;
          case 10:
            e.prev = 10, e.t0 = e.catch(3), window.location.href = l;
          case 13:
          case "end":
            return e.stop()
        }
      }), e, null, [
        [3, 10]
      ])
    })));
    return function(r) {
      return e.apply(this, arguments)
    }
  }(),
  E = function() {
    var e = t(a.default.mark((function e(t, n, i, s, c) {
      var h, m, I, v, T, y, k, _, C, S, E, U, q, D;
      return a.default.wrap((function(e) {
        for (;;) switch (e.prev = e.next) {
          case 0:
            return d.default.show(), h = (0, w.getCloudSaveDataCartDishList)(t, i), m = M(), v = (I = m || {}).multiShop, T = I.cacheKey, y = I.launchReserveTime, k = p.default.getUserSelectedAddress() || {}, _ = T || (0, A.getCloudDataCacheKey)() || "", C = {
              launchReserveTime: y + "",
              cartDishList: JSON.stringify(h),
              cartDishSortMapList: JSON.stringify(n),
              multiShop: v + "",
              firstEnterOrderConfirm: s
            }, Number(c.bizType) === o.BIZ_TYPE_MAP.TAKEAWAY && (C.address = ((null == k ? void 0 : k.id) || 0) + ""), E = 0, g.isNativeMp && (U = getCurrentPages(), E = (null == U ? void 0 : U.length) || 0), e.prev = 5, e.next = 8, x.default.saveLocalData({
              cacheKey: _,
              localData: C
            });
          case 8:
            if (!(S = e.sent) || !S.data) {
              e.next = 14;
              break
            }
            q = f.default.appendQuery((0, u.getTakeAwayHost)() + "/rmstakeaway/web/order-confirm?", r(r({}, c), {}, {
              cacheKey: _,
              wxPagesLength: E
            })), D = (0, P.getTakeawayPageUrl)(c.shopId, c.tenantId, q, o.RE_API_TYPE.CACHE_TYPE), f.default.navigateTo(D), d.default.close(), e.next = 15;
            break;
          case 14:
            d.default.close(), l.default.show({
              content: "云端数据上传失败请重试"
            }), b.default.addError("云端数据上传失败-menuPage", S);
          case 15:
            e.next = 20;
            break;
          case 17:
            e.prev = 17, e.t0 = e.catch(5), d.default.close(), l.default.show({
              content: "云端数据上传失败请重试"
            }), b.default.addError("云端数据上传失败-menuPage", e.t0);
          case 20:
          case "end":
            return e.stop()
        }
      }), e, null, [
        [5, 17]
      ])
    })));
    return function(r, a, t, n, i) {
      return e.apply(this, arguments)
    }
  }();
exports.pullCloudData = E;
exports.getErrPageInfo = function(e) {
  var a = {
    type: 0,
    url: "",
    btnText: ""
  };
  if (e !== y.FAIL_REASON.CAN_NOT_ORDER_DISH) return a;
  var t = M() || {},
    n = t.multiShop,
    i = t.shopId,
    s = t.restaurantViewId,
    d = t.tenantId,
    l = t.brandId,
    c = t.orderChannel,
    p = t.bizType,
    m = t.wxAppVersion;
  if (n && (p === o.BIZ_TYPE_MAP.TAKEAWAY || p === o.BIZ_TYPE_MAP.PICKUP)) {
    (0, h.sendMC)("b_saaspay_t3y4j914_mc");
    var b, P = {
      bizType: p,
      shopId: i,
      pageFrom: "MENU",
      restaurantViewId: s,
      noMatchPrefer: k,
      tenantId: d,
      brandId: l,
      orderChannel: c
    };
    b = g.isNativeMp || 1 === f.default.compareVersion(m, "5.22.60") && g.isMpWebview ? f.default.appendQuery(I.PATH["shop-list"] + "?", P) : f.default.appendQuery((0, u.getTakeAwayHost)() + "/rmstakeaway/web/shop-list?", r({}, P)), a.url = b, a.type = T.ERROR_TYPE.CUSTOM_JUMP, a.btnText = "切换门店"
  }
  return a
};