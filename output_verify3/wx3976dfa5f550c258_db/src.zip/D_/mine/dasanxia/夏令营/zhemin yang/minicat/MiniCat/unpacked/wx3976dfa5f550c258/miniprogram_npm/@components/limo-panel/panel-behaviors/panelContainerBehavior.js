Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.default = void 0;
var e = require("../../../../b/helpers/toConsumableArray");
require("../../../../b/helpers/Objectvalues");
var a = require("../panel-tools/panelEnum"),
  t = Behavior({
    data: {
      panelStack: []
    },
    methods: {
      panelBehaviorsPanelContainerBehavior_limoAttached: function() {
        var e = this;
        [{
          name: a.PanelEvents.OPEN_PANEL_EVENT,
          callback: function(a) {
            e.openPanel(a)
          }
        }, {
          name: a.PanelEvents.CLOSE_PANEL_EVENT,
          callback: function(a) {
            e.closePanel(a)
          }
        }, {
          name: a.PanelEvents.CLICK_PANEL_MASK,
          callback: function() {
            e.clickPanelMask()
          }
        }, {
          name: a.PanelEvents.CLOSE_ALL_PANEL,
          callback: function() {
            e.closeAllPanel()
          }
        }].forEach((function(a) {
          e.registerEvent(a.name, a.callback)
        }))
      },
      openPanel: function(t) {
        if (null != t && t.type && Object.values(a.PanelType).indexOf(t.type) > -1) {
          var n = this.data.panelStack,
            l = n.findIndex((function(e) {
              return e.type === t.type
            })),
            c = e(n);
          l > -1 && c.splice(l, 1), this.setData({
            panelStack: c.concat([t])
          })
        } else null == t || t.type
      },
      closePanel: function(a) {
        var t;
        if (0 !== (null == (t = this.data.panelStack) ? void 0 : t.length))
          if (a) {
            var n = this.data.panelStack,
              l = this.data.panelStack.findIndex((function(e) {
                return e.type === a
              })),
              c = e(n);
            l > -1 && (c.splice(l, 1), this.setData({
              panelStack: c
            }))
          } else this.setData({
            panelStack: this.data.panelStack.slice(0, -1)
          })
      },
      clickPanelMask: function() {
        var e;
        if (0 !== (null == (e = this.data.panelStack) ? void 0 : e.length)) {
          var a = this.data.panelStack;
          a[a.length - 1].maskClosable && this.closePanel()
        }
      },
      closeAllPanel: function() {
        this.setData({
          panelStack: []
        })
      }
    }
  });
exports.default = t;