Object.defineProperty(exports, "__esModule", {
  value: !0
});
var t = require("../../../miniprogram_npm/@limo/container/behaviors/index");
Component({
  behaviors: [t.commonBehavior, t.limoShim],
  properties: {
    cartDisCountStripData: {
      type: Object,
      value: {},
      observer: function(t) {
        Object.keys(t).length && this.setCartDiscountStrip(t)
      }
    },
    needBuyFreeBtn: {
      type: Boolean,
      value: !0
    }
  },
  data: {
    isBuyFree: !1,
    discountContent: [],
    labelData: {},
    buyFreeRenderData: null
  },
  methods: {
    setCartDiscountStrip: function(t) {
      var e, n = this,
        a = t.renderFullCountDiscountData,
        i = t.cartDiscountData;
      null != a && a.discountType && (a.campaignId ? null == i || null == (e = i.buyFreeSuit) || e.forEach((function(t) {
        if (t.campaignId === a.campaignId) {
          var e = {
            text: 103 === t.src ? "会员买免" : "买免活动",
            colorType: 103 === t.src ? 1 : 0
          };
          n.setData({
            isBuyFree: !0,
            discountContent: n.getRenderDisCountText(t.discountText || []),
            buyFreeRenderData: n.getBuyFreeDiscountData(t.additionType),
            labelData: e
          })
        }
      })) : this.setData({
        discountContent: a.discountContent || [],
        labelData: {
          text: a.discountType,
          colorType: 0
        }
      }))
    },
    getRenderDisCountText: function(t) {
      var e = [];
      return t.forEach((function(t) {
        Number.isNaN(+t) ? e.push({
          text: t,
          highlight: !1
        }) : e.push({
          text: t,
          highlight: !0
        })
      })), e
    },
    getBuyFreeDiscountData: function(t) {
      var e = null;
      return 0 === t ? e = {
        customClass: "btn-color",
        imgUrl: "https://p0.meituan.net/travelcube/1cf174ebfd3db05be185eee6e405311a442.png",
        text: "去凑单"
      } : 1 === t && (e = {
        customClass: "",
        imgUrl: "https://p1.meituan.net/travelcube/59c267b3d08e0a1e7e3fab0e6013ef1a899.png",
        text: "继续选购"
      }), e
    },
    checkedBuyFreeEvent: function() {
      var t = this.data.cartDisCountStripData.renderFullCountDiscountData;
      this.triggerEvent("checkedBuyFreeFn", {
        campaignId: t.campaignId
      })
    }
  }
});