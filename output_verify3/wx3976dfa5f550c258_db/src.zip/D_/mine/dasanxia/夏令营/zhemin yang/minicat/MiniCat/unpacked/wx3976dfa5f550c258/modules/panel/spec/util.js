var e = require("../../../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.calculateItemWholeLine = function(e) {
  var n = !1;
  return e && e.length ? n = n || e.some((function(e) {
    return (e.originalPrice ? c("" + e.originalPrice) + 1 : 0) + (e.name ? c(e.name) : 0) > 20
  })) : n
}, exports.checkPanelGroupValid = function(e, t, r) {
  var c, a, s = function(e, t, r) {
      var c = arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
        a = 0,
        s = {
          groupName: "",
          maxChoice: 1 / 0,
          minChoice: 1 / 0
        },
        m = !1;
      if (null != r && r.maxChoice && r.maxChoice !== o.NO_LIMIT_CHOICE) a = (0, u.calculateMethodsCount)(t), (r.minChoice && a < r.minChoice || a > r.maxChoice) && (s = n(n({}, s), {}, {
        minChoice: r.minChoice,
        maxChoice: r.maxChoice
      }), 1 === (null == e ? void 0 : e.length) ? s.groupName = e[0].groupName : s.groupName = r.groupName, m = !0);
      else {
        var h, d, f = null == e ? void 0 : e.find((function(e) {
          var n, u, i = e.groupId;
          return !(null != (n = d = null == t ? void 0 : t.find((function(e) {
            return e.groupId === i
          }))) && null != (n = n.items) && n.length) && e.minChoice !== o.NO_LIMIT_CHOICE || (null == (u = d) || null == (u = u.items) ? void 0 : u.length) < e.minChoice
        }));
        a = (null == (h = d) || null == (h = h.items) ? void 0 : h.length) || 0, f && (s = {
          groupName: f.groupName,
          minChoice: f.minChoice,
          maxChoice: f.maxChoice
        }, m = !0)
      }
      var C = s,
        p = C.minChoice,
        v = C.maxChoice,
        g = C.groupName;
      if (m && c) {
        var I = l(g),
          x = p !== v ? "".concat(I, "最少选").concat(p, "份，已选").concat(a, "份~") : "".concat(I, "请选").concat(v, "份，已选").concat(a, "份，还差").concat(v - a, "份~");
        i.default.show({
          content: x
        })
      }
      return m
    }(e.methods, t.methods, n(n({}, null == e || null == (c = e.spuGroupSetting) ? void 0 : c.methodGroupSetting), {}, {
      groupName: "做法"
    }), r),
    m = !1;
  return s || (m = function(e, t, r) {
    var c = arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
      a = 0,
      s = {
        groupName: "",
        maxChoice: 1 / 0,
        minChoice: 1 / 0
      },
      m = !1;
    if (null != r && r.maxChoice && r.maxChoice !== o.NO_LIMIT_CHOICE) a = (0, u.calculateTastesCount)(t), (r.minChoice && a < r.minChoice || a > (null == r ? void 0 : r.maxChoice)) && (s = n(n({}, s), {}, {
      minChoice: r.minChoice,
      maxChoice: r.maxChoice
    }), 1 === (null == e ? void 0 : e.length) ? s.groupName = e[0].groupName : s.groupName = r.groupName, m = !0);
    else {
      var h = null == e ? void 0 : e.find((function(e) {
        var n = e.groupId,
          o = e.minChoice,
          u = 0;
        return null == t || t.forEach((function(e) {
          var t;
          e.groupId === n && (null == e || null == (t = e.items) || t.forEach((function(e) {
            u += e.count
          })))
        })), a = u, u < o
      }));
      if (h) {
        var d = h.groupName,
          f = h.minChoice,
          C = h.maxChoice;
        s = {
          groupName: d,
          minChoice: f,
          maxChoice: C
        }, m = !0
      }
    }
    var p = s,
      v = p.minChoice,
      g = p.maxChoice,
      I = p.groupName;
    if (m && c) {
      var x = l(I),
        E = v !== g ? "".concat(x, "最少选").concat(v, "份，已选").concat(a, "份~") : "".concat(x, "请选").concat(g, "份，已选").concat(a, "份，还差").concat(g - a, "份~");
      i.default.show({
        content: E
      })
    }
    return m
  }(e.tastes, t.tastes, n(n({}, null == e || null == (a = e.spuGroupSetting) ? void 0 : a.tasteGroupSetting), {}, {
    groupName: "加料"
  }), r)), !s && !m
}, exports.getDishMethodDesc = function(e, n) {
  var t = [];
  return null == n || n.forEach((function(n) {
    null == n || n.items.forEach((function(n) {
      null == e || e.forEach((function(e) {
        var o;
        null != e && null != (o = e.items) && o.find((function(e) {
          return (null == e ? void 0 : e.id) === n.id
        })) && (t = t.concat(n.name).filter((function(e) {
          return e
        })))
      }))
    }))
  })), t
}, exports.getDishSpecDesc = function(e, n) {
  var o, u, i = "",
    r = t.default.getIn(e, ["specAttrs", "0", "valueId"]);
  return null == n || null == (o = n.specAttrs) || o.forEach((function(e) {
    var n;
    return null == e || null == (n = e.specValues) ? void 0 : n.forEach((function(e) {
      r && +e.key == +r && (i = e.value)
    }))
  })), i && (null == (u = n.skuMenuItems) ? void 0 : u.length) > 1 ? [i] : []
}, exports.getDishTasteDesc = function(e) {
  var n = [];
  return null == e || e.forEach((function(e) {
    var t;
    null == e || null == (t = e.items) || t.forEach((function(e) {
      null != e && e.count && n.push("".concat(e.name, "*").concat(e.count))
    }))
  })), n.filter((function(e) {
    return e
  }))
}, exports.getPanelTempDishSpec = function(e, n) {
  var t = n.skuMenuItems,
    o = void 0 === t ? [] : t,
    u = null == o ? void 0 : o.find((function(n) {
      return n.skuId === (null == e ? void 0 : e.skuId)
    }));
  return null == u ? void 0 : u.specAttrs
}, exports.transAttrItem = function(e, n, u) {
  if (null == n || !n.length) return null;
  var i = t.default.getIn(e, ["0", "valueId"]) || "",
    r = [],
    c = [];
  return n.forEach((function(e, n) {
    var l = function(e, n) {
        if (null == n || !n.length) return;
        var o;
        return n.forEach((function(n) {
          +t.default.getIn(n, ["specAttrs", 0, "valueId"]) == +e && (o = n)
        })), o
      }(e.key, u),
      a = {
        id: (null == l ? void 0 : l.skuId) || e.key,
        name: e.value,
        selected: +e.key === i || !i && 0 === n,
        defaultSelected: !1,
        count: 0,
        itemIndex: n,
        maxBoughtCount: o.SINGLE_CHOICE,
        repeatChoice: o.TASTE_REPEAT_CHOICE.SINGLE,
        soldOut: null == l ? void 0 : l.soldOut
      };
    null != l && l.soldOut ? c.push(a) : r.push(a)
  })), r.concat(c)
}, exports.transGroupItem = function(e, n, t, u, i) {
  if (!Array.isArray(e)) return {
    list: [],
    groupTotalCount: 0
  };
  var r = [],
    c = 0;
  return e.forEach((function(e, u) {
    var l = function(e, n) {
      var t = 0;
      return null == n || n.filter((function(n) {
        var u;
        return null == n || null == (u = n.items) ? void 0 : u.filter((function(n) {
          n && n.id === e && (t = n.count || o.SINGLE_CHOICE)
        }))
      })), t
    }(e.id, n);
    c += l;
    var a = {
      id: e.id,
      name: e.name,
      selected: !e.soldOut && !!l,
      defaultSelected: !e.soldOut && e.defaultSelected,
      originalPrice: e.originPrice,
      price: e.price,
      soldOut: e.soldOut || !1,
      count: l,
      repeatChoice: t,
      maxBoughtCount: e.maxBoughtCount || o.SINGLE_CHOICE,
      stockCount: e.stockCount || o.NO_LIMIT_CHOICE,
      itemIndex: u,
      mutex: 1 === (null == i ? void 0 : i[u])
    };
    r.push(a)
  })), r.forEach((function(e) {
    var n = e.count >= Number(e.stockCount) && e.stockCount !== o.NO_LIMIT_CHOICE,
      t = c >= u && u !== o.NO_LIMIT_CHOICE;
    e.disablePlus = n || t
  })), {
    groupTotalCount: c,
    list: r
  }
}, exports.transMethodTasteSubTitle = function(e, n, t, u, i) {
  return n === e ? n === o.NO_LIMIT_CHOICE ? (0, r.noLimitChoice)() : (0, r.mustSelectedAndPermanent)(n, u) : n === o.NO_LIMIT_CHOICE ? (0, r.noLimitAndMax)(e, u, i, t) : e === o.NO_LIMIT_CHOICE ? (0, r.mustSelectedAndPermanent)(n, u) : (0, r.mustAndMax)(e, n, u, i, t)
};
var n = require("../../../b/helpers/objectSpread2"),
  t = e(require("../../../miniprogram_npm/seamless-immutable/index.js")),
  o = require("../../../constants/bizConstants"),
  u = require("../../cartHelper"),
  i = e(require("../../../lib/mix/toast")),
  r = require("./subTitle");

function c(e) {
  for (var n = 0, t = 0; t < (null == e ? void 0 : e.length); t++) {
    var o = e.charCodeAt(t);
    o >= 1 && o <= 126 || o >= 65376 && o <= 65439 ? n++ : n += 2
  }
  return n
}

function l(e) {
  return e ? (null == e ? void 0 : e.length) > 13 ? "[".concat(e.slice(0, 13), "...]") : "[".concat(e, "]") : ""
}