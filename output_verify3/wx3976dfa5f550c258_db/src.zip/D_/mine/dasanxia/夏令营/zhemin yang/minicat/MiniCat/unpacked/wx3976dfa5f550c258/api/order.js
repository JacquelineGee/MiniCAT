var e = require("../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.default = void 0;
var r, t, n, a = e(require("../b/regenerator")),
  u = require("../b/helpers/asyncToGenerator"),
  o = e(require("../lib/mix/request")),
  c = require("../lib/mix/util"),
  i = require("../lib/env"),
  s = function(e) {
    if (i.isWXH5 && e && e.indexOf("http") > -1) {
      var r = (e || "").replace("WXAUTH", encodeURIComponent(encodeURIComponent(encodeURIComponent(window.location.href))));
      r && window.location.replace(r)
    }
  },
  d = {
    getOrderDetailInfo: function(e) {
      return o.default.get("/order/orderDetail", {
        params: e,
        openShark: !0
      })
    },
    getOrderDetailPool: (n = u(a.default.mark((function e(r) {
      return a.default.wrap((function(e) {
        for (;;) switch (e.prev = e.next) {
          case 0:
            return e.abrupt("return", o.default.get("/order/orderDetailPoll", {
              params: r,
              openShark: !0
            }));
          case 1:
          case "end":
            return e.stop()
        }
      }), e)
    }))), function(e) {
      return n.apply(this, arguments)
    }),
    cancelOrder: function(e) {
      return o.default.get("/order/cancelOrder", {
        params: e
      })
    },
    urgeOrder: function(e) {
      return o.default.get("/order/urgeOrder", {
        params: e
      })
    },
    checkTable: function(e) {
      var r = e.shopId,
        t = e.tableNum,
        n = e.entranceChannel;
      return o.default.get("/checkTable", {
        params: {
          shopId: r,
          tableNum: t,
          entranceChannel: n
        }
      })
    },
    judgePayConfirmPage: function(e) {
      var r = e.mtShopId,
        t = e.tableNum,
        n = e.posOrderId,
        a = e.paySource;
      return o.default.get("/judgePayConfirmPage", {
        params: {
          mtShopId: r,
          tableNum: t,
          posOrderId: n || "",
          paySource: a
        }
      })
    },
    getRestaurantOrderList: function(e) {
      return u(a.default.mark((function r() {
        var t, n;
        return a.default.wrap((function(r) {
          for (;;) switch (r.prev = r.next) {
            case 0:
              return r.next = 2, o.default.get("/personalcenter/orderList", {
                params: e
              });
            case 2:
              return t = r.sent, i.isWXH5 && 800 === t.code && (n = (t.data || "").replace("WXAUTH", encodeURIComponent(encodeURIComponent(encodeURIComponent(window.location.href))))) && window.location.replace(n), r.abrupt("return", t);
            case 5:
            case "end":
              return r.stop()
          }
        }), r)
      })))()
    },
    getOrderCenterData: function(e) {
      return o.default.get("/portal/orderList", {
        params: e
      })
    },
    syncOrder: function(e) {
      return o.default.get("/order/syncOrder", {
        params: {
          orderViewId: e
        }
      })
    },
    calculate: function(e) {
      return u(a.default.mark((function r() {
        var t, n;
        return a.default.wrap((function(r) {
          for (;;) switch (r.prev = r.next) {
            case 0:
              return r.next = 2, o.default.post("/invoice/calculate", e, {
                withCredentials: !0
              });
            case 2:
              return 800 === (t = r.sent).code && t.data && (n = t.data, s(n)), r.abrupt("return", t);
            case 5:
            case "end":
              return r.stop()
          }
        }), r)
      })))()
    },
    invoiceWrite: function(e) {
      return u(a.default.mark((function r() {
        var t, n;
        return a.default.wrap((function(r) {
          for (;;) switch (r.prev = r.next) {
            case 0:
              return r.next = 2, o.default.post("/invoice/write", e, {
                withCredentials: !0
              });
            case 2:
              return 800 === (t = r.sent).code && t.data && (n = t.data, s(n)), r.abrupt("return", t);
            case 5:
            case "end":
              return r.stop()
          }
        }), r)
      })))()
    },
    calculateTakeAway: function(e) {
      return u(a.default.mark((function r() {
        var t, n, u;
        return a.default.wrap((function(r) {
          for (;;) switch (r.prev = r.next) {
            case 0:
              return t = (0, c.getTakeAwayHost)(), r.next = 3, o.default.post("/api/rmstakeaway/invoice/calculate", e, {
                baseURL: t,
                withCredentials: !0
              });
            case 3:
              return 302 === (n = r.sent).code && n.message && (u = n.message, s(u)), r.abrupt("return", n);
            case 6:
            case "end":
              return r.stop()
          }
        }), r)
      })))()
    },
    invoiceWriteTakeAway: function(e) {
      return u(a.default.mark((function r() {
        var t, n, u;
        return a.default.wrap((function(r) {
          for (;;) switch (r.prev = r.next) {
            case 0:
              return t = (0, c.getTakeAwayHost)(), r.next = 3, o.default.post("/api/rmstakeaway/invoice/write", e, {
                baseURL: t,
                withCredentials: !0
              });
            case 3:
              return 302 === (n = r.sent).code && n.message && (u = n.message, s(u)), r.abrupt("return", n);
            case 6:
            case "end":
              return r.stop()
          }
        }), r)
      })))()
    },
    calculateSubtype: (t = u(a.default.mark((function e(r, t) {
      return a.default.wrap((function(e) {
        for (;;) switch (e.prev = e.next) {
          case 0:
            return e.next = 2, o.default.post("/".concat(r, "/invoice/calculate"), t, {
              withCredentials: !0
            });
          case 2:
            return e.abrupt("return", e.sent);
          case 3:
          case "end":
            return e.stop()
        }
      }), e)
    }))), function(e, r) {
      return t.apply(this, arguments)
    }),
    invoiceWriteSubtype: (r = u(a.default.mark((function e(r, t) {
      return a.default.wrap((function(e) {
        for (;;) switch (e.prev = e.next) {
          case 0:
            return e.next = 2, o.default.post("/".concat(r, "/invoice/write"), t, {
              withCredentials: !0
            });
          case 2:
            return e.abrupt("return", e.sent);
          case 3:
          case "end":
            return e.stop()
        }
      }), e)
    }))), function(e, t) {
      return r.apply(this, arguments)
    }),
    servingCall: function(e) {
      return o.default.post("/serving-call", e)
    }
  };
exports.default = d;