var e = require("../../../@limo/container/behaviors/index");
Component({
  behaviors: [e.commonBehavior, e.limoShim],
  properties: {
    bizType: {
      type: Number,
      value: 0,
      observer: function(e) {
        this.setData({
          bizTypeStatus: 4 === e
        })
      }
    }
  },
  data: {
    bizTypeStatus: 3
  },
  methods: {
    handelClick: function() {
      var e = this.data.bizTypeStatus;
      this.triggerEvent("switchBizFn", {
        bizTypeStatus: e
      }, {
        bubbles: !0,
        composed: !0
      })
    }
  }
});