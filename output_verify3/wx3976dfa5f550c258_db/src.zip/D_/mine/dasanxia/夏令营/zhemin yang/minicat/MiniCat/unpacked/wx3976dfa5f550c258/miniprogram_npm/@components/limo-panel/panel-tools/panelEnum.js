Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.RECHARGE_GIFT_TYPE = exports.PanelType = exports.PanelEvents = exports.COUPON_TYPE = void 0;
var E, _ = ((E = {}).OPEN_PANEL_EVENT = "openPanelEvent", E.CLOSE_PANEL_EVENT = "closePanelEvent", E.CLICK_PANEL_MASK = "clickPanelMask", E.CLOSE_ALL_PANEL = "closeAllPanel", E);
exports.PanelEvents = _;
var e = function(E) {
  return E.AUTH_PROMPT_PANEL = "auth-prompt-panel", E.RECHARGE_PLAN_PANEL = "recharge-plan-panel", E.USER_COUPONS_PANEL = "user-coupons-panel", E
}({});
exports.PanelType = e;
var P = function(E) {
  return E[E.GIFT_ASSET = 0] = "GIFT_ASSET", E[E.GIFT_COUPON = 1] = "GIFT_COUPON", E[E.GIFT_POINT = 2] = "GIFT_POINT", E[E.GIFT_MEMBER = 3] = "GIFT_MEMBER", E
}({});
exports.RECHARGE_GIFT_TYPE = P;
var O = function(E) {
  return E[E.MEMBER_DISH_COUPON = 30] = "MEMBER_DISH_COUPON", E[E.MEMBER_ORDER_COUPON = 31] = "MEMBER_ORDER_COUPON", E[E.MEMBER_DISCOUNT_COUPON = 36] = "MEMBER_DISCOUNT_COUPON", E[E.MEMBER_DELIVERY = 38] = "MEMBER_DELIVERY", E
}({});
exports.COUPON_TYPE = O;