var e = require("../../../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.logCartPackageSku = exports.logAddedMultiplesSpecDish = void 0;
var t = e(require("../../../lib/mix/log"));
exports.logAddedMultiplesSpecDish = function(e) {
  try {
    var a = {
      skuId: e.skuId,
      skuname: e.skuName,
      spuId: e.spuId,
      weight: e.weight,
      count: e.count,
      mustCount: e.mustCount,
      manualCampaigns: e.manualCampaigns,
      methods: e.methods,
      originalPrice: e.originalPrice,
      specAttrs: e.specAttrs,
      tastes: e.tastes
    };
    t.default.sendInfo({
      name: "[cart-operation][multi-spec-panel-click-add-cart]",
      content: {
        addedMultiplesSpecDish: a
      }
    })
  } catch (e) {}
};
exports.logCartPackageSku = function(e) {
  try {
    var a = {
      skuId: e.skuId,
      skuname: e.skuName,
      spuId: e.spuId,
      count: e.count
    };
    t.default.sendInfo({
      name: "[cart-operation][package-panel-click-add-cart]",
      content: {
        cartPackageSku: a
      }
    })
  } catch (e) {}
};