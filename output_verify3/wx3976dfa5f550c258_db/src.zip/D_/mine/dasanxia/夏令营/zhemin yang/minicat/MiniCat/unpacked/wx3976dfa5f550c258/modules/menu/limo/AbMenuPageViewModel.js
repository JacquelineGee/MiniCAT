var o = require("../../../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.AbMenuPageViewModel = void 0;
var e = require("../../../b/helpers/objectSpread2"),
  n = require("../../../b/helpers/classCallCheck"),
  a = require("../../../b/helpers/createClass"),
  t = require("../../../miniprogram_npm/seamless-immutable/index.js"),
  r = require("../../../lib/accountBindUtil"),
  i = require("../../../constants/bizConstants"),
  u = o(require("../../../api/rmsStorage")),
  s = require("./ComponentsViewModel"),
  l = require("../pageViewModel"),
  d = o(require("../grouponCoupon/GrouponCouponSdk")),
  m = o(require("../../../miniprogram_npm/@mtfe/rms-triangle-c/index.js")),
  p = function() {
    function o(e) {
      n(this, o), this.pageInstance = void 0, this.Limo = void 0, this.menuComponentsModel = new s.ComponentsViewModel, this.urlParams = void 0, this.formatFunctionCollection = {
        "menu-shop-info": this.menuComponentsModel.formatShopInfoData,
        "member-info": this.menuComponentsModel.formatMemberInfoData,
        "advertising-carousel": this.menuComponentsModel.formatAdCarouselData,
        "menu-popup-windows": this.menuComponentsModel.formatPopupWindowsData,
        "address-list-modal": this.menuComponentsModel.formatAddressListModalData,
        "recommendation-module": this.menuComponentsModel.formatRecommendationInfoData,
        "groupon-coupon-login": this.menuComponentsModel.formatGrouponCouponLoginData,
        "groupon-coupon-swiper": this.menuComponentsModel.formatGrouponCouponSwiperData,
        "notice-config": this.menuComponentsModel.formatNoticeConfigData,
        "register-panel": this.menuComponentsModel.formatRegisterPanelData
      };
      var a = e.pageInstance,
        t = e.Limo;
      this.pageInstance = a, this.Limo = t
    }
    return a(o, [{
      key: "getMenuViewModel",
      value: function(o) {
        for (var n, a, r, i, s = [], l = (0, t.asMutable)(o, {
            deep: !0
          }), d = l.moduleSortList, m = void 0 === d ? [] : d, p = l.moduleData, c = o.progressInfo, h = 0; h < m.length; h++) {
          var f = m[h];
          if (this.formatFunctionCollection[f]) {
            var g, C, M = e(e({}, null == (g = p[f]) ? void 0 : g.layout), {}, {
              zIndex: "auto"
            });
            switch (f) {
              case "register-panel":
                M = {
                  zIndex: 96
                };
                break;
              case "menu-popup-windows":
                M = {
                  zIndex: 97
                };
                break;
              case "address-list-modal":
                M = {
                  zIndex: 98
                };
                break;
              case "member-info":
                null != (n = p[f]) && n.layout || (M = {
                  marginHorizontal: 30,
                  zIndex: "auto"
                });
                break;
              case "menu-shop-info":
                var v, b;
                null != (a = p[f]) && a.data && c && !u.default.getOrderProgress(null == (r = this.urlParams) ? void 0 : r.shopId) && (p[f].data.progressInfo = c), null != (i = p[f]) && i.data && (p[f].data.grouponCouponData = {
                  showMTBind: (null == p || null == (v = p["groupon-coupon-login"]) || null == (v = v.data) ? void 0 : v.showMTBind) || !1,
                  groupCouponDisplayInfos: (null == p || null == (b = p["groupon-coupon-swiper"]) || null == (b = b.data) ? void 0 : b.couponDisplayInfos) || []
                }, p[f].data.urlParams = this.urlParams)
            }
            s.push({
              name: f,
              data: this.formatFunctionCollection[f](null == (C = p[f]) ? void 0 : C.data, this.urlParams),
              layout: M
            })
          } else {
            var w, I, D = (null == (w = p[f]) ? void 0 : w.layout) || {},
              y = (null == (I = p[f]) ? void 0 : I.data) || {};
            switch (f) {
              case "top-sticky-container":
                D = e(e({}, D), {}, {
                  zIndex: 3
                });
                break;
              case "basic-canvas":
                y.isMemberCanvas = !1, y.loginCanvasConfig = y.canvasConfig, f = "member-canvas"
            }
            s.push({
              name: f,
              data: y,
              layout: D
            })
          }
        }
        s.push({
          name: "panel-container-menu",
          data: {},
          layout: {
            zIndex: 1e3
          }
        });
        var x = {
          modules: s
        };
        return x = this.updateMenuLimoModules({
          limoMenuData: x
        })
      }
    }, {
      key: "updateMenuLimoModules",
      value: function(o) {
        var e = o.limoMenuData,
          n = [];
        return m.default.isWxNative || n.push({
          name: "agreement-confirm",
          data: {
            shopId: this.urlParams.shopId,
            fromMenu: !0
          },
          layout: {
            zIndex: 999
          }
        }), n.reduce((function(o, e) {
          return (0, l.addCustomLimoModule)(o, e.name, e.data, e.layout)
        }), e || []), (0, t.asMutable)(e, {
          deep: !0
        })
      }
    }, {
      key: "gotoThirdLoginClick",
      value: function() {
        (0, r.gotoThirdLoginPath)(i.ACCOUNT_BIND_CODE.MT, !1)
      }
    }, {
      key: "updateGrouponCouponSwiperModule",
      value: function() {
        d.default.grouponCouponModel && this.Limo.setModuleData("groupon-coupon-swiper", this.menuComponentsModel.formatGrouponCouponSwiperData(d.default.grouponCouponModel, this.urlParams))
      }
    }]), o
  }();
exports.AbMenuPageViewModel = p;