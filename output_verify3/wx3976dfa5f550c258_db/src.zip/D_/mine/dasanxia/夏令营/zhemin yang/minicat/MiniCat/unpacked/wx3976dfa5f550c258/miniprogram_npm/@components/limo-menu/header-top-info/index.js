var e = require("../../../../b/helpers/interopRequireDefault"),
  t = e(require("../../../../b/regenerator")),
  a = require("../../../../b/helpers/asyncToGenerator"),
  i = e(require("../../../@limo/core/index.js")),
  n = require("../../../@limo/container/behaviors/index"),
  o = e(require("../../../../api/rmsStorage")),
  r = require("../menu-constants/actionItem"),
  s = require("../common-lib/utils"),
  u = require("../../../../lib/wx/app-info"),
  l = e(require("../../../@mtfe/rms-triangle-c/index.js"));
Component({
  behaviors: [n.commonBehavior, n.limoShim],
  options: {
    addGlobalClass: !0
  },
  properties: {
    backgroundImgUrl: {
      type: String,
      value: "",
      observer: function(e) {
        this.setHeaderStyle(e)
      }
    },
    pageTitle: {
      type: String,
      value: "欢迎点餐"
    },
    shopLogo: {
      type: String,
      value: ""
    },
    peopleCountText: {
      type: String,
      value: ""
    },
    tableName: {
      type: String,
      value: ""
    },
    headActionList: {
      type: Array,
      value: [],
      observer: function(e, t) {
        if (e !== t && Array.isArray(e)) {
          var a = e.find((function(e) {
            return e.type === r.ACTION_ITEM_TYPE.SEARCH
          })) || {};
          e.find((function(e) {
            return e.type === r.ACTION_ITEM_TYPE.MEMBER_COUPON
          })) && i.default.getLimoRuntime().sendMC && i.default.getLimoRuntime().sendMC({
            valLab: null,
            bid: "b_saaspay_i65ce0ox_mv",
            options: {}
          }), this.setData({
            hasSearchIcon: a.showItem
          })
        }
      }
    },
    shopId: {
      type: String,
      value: ""
    },
    tableNum: {
      type: Number
    },
    searchBannerOpacity: {
      type: Number,
      value: 0,
      observer: function(e) {
        var t = this,
          a = !!e;
        a !== this.data.showFixedHeader && this.setData({
          showFixedHeader: a
        }), 1 === e ? setTimeout((function() {
          t.setData({
            showCouponIcon: !0
          })
        }), 300) : 0 === e && this.setData({
          showCouponIcon: !1
        })
      }
    },
    hideSearch: {
      type: Boolean,
      value: !1
    },
    takeawayTips: {
      type: String,
      value: "",
      observer: function() {
        this.getTopHeadTxt()
      }
    },
    multiShop: {
      type: Number,
      value: 0
    },
    progressInfo: {
      type: Object,
      value: {}
    },
    progressType: {
      type: Number,
      value: 0
    },
    isVirtualTabbar: {
      type: Boolean,
      value: !1,
      observer: function(e) {
        this.initTabPage(e)
      }
    }
  },
  data: {
    ACTION_ITEM_TYPE: r.ACTION_ITEM_TYPE,
    isH5Page: !1,
    isTT: i.default.getLimoRuntime().isByteDanceMicroApp,
    isPreviewPage: !1,
    commonHeadStyle: "",
    disableVipDiamondAnimation: !1,
    commonTitleOverflow: !1,
    topHeadTxt: "",
    showCouponIcon: !1,
    iconType: "",
    isTabPage: !1,
    peopleCount: 1
  },
  ready: function() {
    this.limoReady()
  },
  attached: function() {
    this.limoAttached()
  },
  methods: {
    limoReady: function() {
      this.setData({
        isH5Page: i.default.getLimoRuntime().isH5,
        isPreviewPage: this.isPreview
      }), this.initShopTitleFormat(), this.getTopHeadTxt()
    },
    limoAttached: function() {
      if (this.setHeaderStyle(this.data.backgroundImgUrl), this.isPreview || (this.setData({
          disableVipDiamondAnimation: o.default.getDisableVipDiamondAnimation()
        }), o.default.setDisableVipDiamondAnimation()), this.data.shopId) {
        var e, t, a = this.data.shopId,
          i = ((null == o.default || null == (e = o.default.getExtraInfo(a)) ? void 0 : e.shopConfig) || {}).fastFoodCanSelectNumOfCustomer,
          n = void 0 !== i && i,
          r = (null == (t = o.default.getPreorderInfo(a)) ? void 0 : t.peopleCount) || 1;
        n && (r = o.default.getMenuOrderPeopleCount(a) || 1), this.setData({
          peopleCount: r,
          fastFoodCanSelectNumOfCustomer: n
        })
      }
      var s = this.data.isVirtualTabbar,
        u = void 0 !== s && s;
      u || this.initTabPage(u)
    },
    getTopHeadTxt: function() {
      var e, t = this.data,
        a = t.pageTitle,
        n = t.shopLogo,
        o = t.takeawayTips;
      e = i.default.getLimoRuntime().isH5 || this.isPreview || !o ? o && this.isPreview ? "" : n ? "欢迎点餐" : a : "", this.setData({
        topHeadTxt: e
      })
    },
    initShopTitleFormat: function() {
      var e = i.default.getLimoRuntime().isH5 ? [] : getCurrentPages(),
        t = this.data,
        a = t.pageTitle,
        n = t.shopLogo,
        o = (0, s.getStrCount)(a);
      this.setData({
        iconType: e[e.length - 2] ? "back-light" : "home-light",
        commonTitleOverflow: o > 14 && !n
      })
    },
    initTabPage: function(e) {
      var t = !1;
      this.getTabBar && this.getTabBar() && (t = !!this.getTabBar()), this.setData({
        isTabPage: t || e
      })
    },
    setHeaderStyle: function(e) {
      var t = i.default.getLimoRuntime().getSystemInfoSync().statusBarHeight,
        a = void 0 === t ? 44 : t,
        n = 2 * a + "rpx";
      i.default.getLimoRuntime().isByteDanceMicroApp || this.isPreview ? n = "40rpx" : i.default.getLimoRuntime().isH5 ? n = "30rpx" : i.default.getLimoRuntime().isIOS && (n = a + "px"), this.setData({
        commonHeadStyle: e ? "background-image:url(".concat(e, "); padding-top:").concat(n) : "padding-top:" + n
      })
    },
    onHeadIconClick: function(e) {
      var i = this;
      return a(t.default.mark((function a() {
        var n;
        return t.default.wrap((function(t) {
          for (;;) switch (t.prev = t.next) {
            case 0:
              n = e.currentTarget.item || e.currentTarget.dataset.item, i.headActionItemClickHandler(n);
            case 2:
            case "end":
              return t.stop()
          }
        }), a)
      })))()
    },
    headActionItemClickHandler: function(e) {
      var n = this;
      return a(t.default.mark((function a() {
        var o, s, u, d, c, p, m;
        return t.default.wrap((function(t) {
          for (;;) switch (t.prev = t.next) {
            case 0:
              o = e.type, s = e.actionUrl, t.t0 = (i.default.getLimoRuntime().sendMC({
                valLab: {
                  clickData: {
                    type: o,
                    actionUrl: s
                  }
                },
                bid: "b_saaspay_z1lp1tn0_mc",
                options: {}
              }), o), t.next = t.t0 === r.ACTION_ITEM_TYPE.BELLS ? 4 : t.t0 === r.ACTION_ITEM_TYPE.MEMBER_LOGIN ? 7 : t.t0 === r.ACTION_ITEM_TYPE.SEARCH ? 10 : 11;
              break;
            case 4:
              return t.next = 6, n.callWaiter();
            case 6:
              return t.abrupt("break", 12);
            case 7:
              return u = l.default.parse(s), d = u.tenantId, c = u.poiId, p = u.poiType, m = u.orgId, n.showDialog("universal-login", {
                isDialog: !0,
                useNewAuthVersion: !0,
                commonHeaders: {
                  tenantId: d,
                  poiId: c,
                  poiType: p,
                  orgId: m
                },
                agreementParams: [{
                  sceneType: 10
                }],
                useRevoke: !0,
                revokePrefix: "universalLogin"
              }, {
                position: "bottom"
              }), t.abrupt("break", 12);
            case 10:
              i.default.getLimoRuntime().sendMC && i.default.getLimoRuntime().sendMC({
                valLab: null,
                bid: "b_saaspay_vkmkhsdx_mc",
                options: {}
              });
            case 11:
              s && i.default.getLimoRuntime().navigateTo({
                url: s
              });
            case 12:
            case "end":
              return t.stop()
          }
        }), a)
      })))()
    },
    callWaiter: function() {
      var e = this;
      return a(t.default.mark((function n() {
        var o, r, s;
        return t.default.wrap((function(n) {
          for (;;) switch (n.prev = n.next) {
            case 0:
              o = e.data, r = o.shopId, s = o.tableNum, i.default.getLimoRuntime().showModal({
                title: "",
                content: "呼叫服务员小姐姐吗？",
                success: function(e) {
                  return a(t.default.mark((function a() {
                    return t.default.wrap((function(t) {
                      for (;;) switch (t.prev = t.next) {
                        case 0:
                          e.confirm && i.default.getLimoRuntime().request({
                            url: "callWaiter",
                            data: {
                              mtShopId: r,
                              tableNum: s
                            },
                            complete: function(e) {
                              if (e) {
                                var t = e.data || {},
                                  a = t.code,
                                  n = t.msg;
                                200 === a ? i.default.getLimoRuntime().showToast({
                                  title: n || "呼叫成功",
                                  icon: "none"
                                }) : i.default.getLimoRuntime().showToast({
                                  title: "呼叫失败，请稍后再试",
                                  icon: "none"
                                })
                              }
                            },
                            fail: function(e) {
                              i.default.getLimoRuntime().showToast({
                                title: "呼叫失败，请稍后再试",
                                icon: "none"
                              })
                            }
                          });
                        case 2:
                        case "end":
                          return t.stop()
                      }
                    }), a)
                  })))()
                }
              });
            case 2:
            case "end":
              return n.stop()
          }
        }), n)
      })))()
    },
    jumpToSearch: function() {
      var e = this.data.headActionList.find((function(e) {
        return e.type === r.ACTION_ITEM_TYPE.SEARCH
      })) || {};
      this.headActionItemClickHandler(e)
    },
    changeShopFunc: function() {
      this.triggerEvent("changeShopFunc")
    },
    openUserCouponPanel: function() {
      i.default.getLimoRuntime().sendMC && i.default.getLimoRuntime().sendMC({
        valLab: null,
        bid: "b_saaspay_i65ce0ox_mc",
        options: {}
      }), this.triggerEvent("openUserCouponsPanelEvent")
    },
    closeOrderProgress: function() {
      this.triggerEvent("closeProgress")
    },
    goBackHome: function() {
      if ("back-light" === this.data.iconType) i.default.getLimoRuntime().navigateBack({
        delta: 1
      });
      else {
        var e = getCurrentPages(),
          t = e[e.length - 1].options,
          a = "/pages/index/index?&shopId=" + t.shopId;
        (0, u.isMerchantWxApp)() ? a += "&tenantId=".concat(t.tenantId, "&restaurantViewId=").concat(t.restaurantViewId): a += "&decorateType=1", l.default.redirectTo({
          url: a
        })
      }
    }
  }
});