var o = require("../../../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.default = void 0;
var e, n = o(require("../../../b/regenerator")),
  t = require("../../../b/helpers/asyncToGenerator"),
  u = require("../../../b/helpers/classCallCheck"),
  s = require("../../../b/helpers/createClass"),
  i = o(require("../../../api/rmsStorage")),
  l = o(require("../../../lib/mix/toast")),
  a = require("../../cartHelper"),
  r = ((e = r || {})[e.NOT_SELECTED = 0] = "NOT_SELECTED", e[e.SELECTED = 1] = "SELECTED", e),
  p = new(function() {
    function o() {
      u(this, o), this.grouponCouponModel = void 0, this.dealCoupons = [], this.applyCouponId = null, this.cancelCouponId = null, this.autoUseDealCoupon = !1, this.grouponDishInfo = {}, this.shopId = "", this.isFirstShowToast = !0, this.pageService = void 0
    }
    var e;
    return s(o, [{
      key: "setDealCoupons",
      value: function(o) {
        var e;
        this.applyCouponId = null, this.cancelCouponId = null, this.dealCoupons = JSON.parse(JSON.stringify(o)), this.shopId && i.default.setDealCoupons(this.shopId, o), null == (e = this.pageService) || e.updateGrouponCouponSwiperModule()
      }
    }, {
      key: "getDealCoupons",
      value: function() {
        return this.dealCoupons
      }
    }, {
      key: "setGrouponDishInfo",
      value: function(o) {
        this.grouponDishInfo = o, this.shopId && i.default.setGrouponDishInfo(this.shopId, o)
      }
    }, {
      key: "checkGrouponDishInfo",
      value: function(o) {
        return !("{}" !== JSON.stringify(this.grouponDishInfo) || !o.hiddenDish)
      }
    }, {
      key: "setGrouponDishInfoById",
      value: function(o, e) {
        this.grouponDishInfo[o] = e, this.setGrouponDishInfo(this.grouponDishInfo)
      }
    }, {
      key: "getApplyCouponId",
      value: function() {
        return this.applyCouponId
      }
    }, {
      key: "setApplyCouponId",
      value: function(o) {
        this.applyCouponId = o
      }
    }, {
      key: "getCancelCouponId",
      value: function() {
        return this.cancelCouponId
      }
    }, {
      key: "setCancelCouponId",
      value: function(o) {
        this.cancelCouponId = o
      }
    }, {
      key: "getAutoUseDealCoupon",
      value: function() {
        return this.autoUseDealCoupon
      }
    }, {
      key: "setAutoUseDealCoupon",
      value: function(o) {
        this.autoUseDealCoupon = o
      }
    }, {
      key: "updateGrouponDishInfo",
      value: function(o) {
        var e, n = this,
          t = {};
        null == o || null == (e = o.filter((function(o) {
          return o.selectStatus === r.SELECTED
        }))) || e.forEach((function(o) {
          var e = o.discountTempId;
          n.grouponDishInfo[e] && (t[e] = n.grouponDishInfo[e])
        })), this.setGrouponDishInfo(t)
      }
    }, {
      key: "initDealCoupons",
      value: (e = t(n.default.mark((function o(e, t, u) {
        var s, l, a, p;
        return n.default.wrap((function(o) {
          for (;;) switch (o.prev = o.next) {
            case 0:
              this.shopId = e, this.pageService = t, this.applyCouponId = null, this.cancelCouponId = null, this.isFirstShowToast = !0, this.grouponDishInfo = {};
              try {
                s = i.default.getDealCoupons(e), l = i.default.getGrouponDishInfo(e), null != s && s.length && null != u && u.length ? (a = null == s ? void 0 : s.filter((function(o) {
                  return o.selectStatus === r.SELECTED && !!l[o.discountTempId]
                })).map((function(o) {
                  return o.discountTempId
                })), p = u.map((function(o) {
                  return a.indexOf(o.discountTempId) > -1 && (o.selectStatus = r.SELECTED), o
                })), this.setDealCoupons(p), this.setGrouponDishInfo(l)) : this.setDealCoupons(u || [])
              } catch (o) {
                this.setDealCoupons([])
              }
            case 2:
            case "end":
              return o.stop()
          }
        }), o, this)
      }))), function(o, n, t) {
        return e.apply(this, arguments)
      })
    }, {
      key: "addGrouponCouponDishToCart",
      value: function(o, e, n, t, u) {
        var s = this;
        if (e && n && o.length) {
          var i = (0, a.getSingleSpu)(e, n);
          this.setAutoUseDealCoupon(t), this.applyCouponId = o[0], t && o.forEach((function(o) {
            var e = s.dealCoupons.findIndex((function(e) {
              return e.discountTempId === o
            }));
            s.dealCoupons[e].selectStatus = r.SELECTED
          })), u && u(i)
        }
      }
    }, {
      key: "autoUseCouponAddToCart",
      value: function(o, e, n, t, u) {
        var s, a, p = null == (s = this.dealCoupons) ? void 0 : s.filter((function(o) {
          var n;
          return "" + (null == o || null == (n = o.dishDTOS) || null == (n = n[0]) ? void 0 : n.skuId) === e
        }));
        if (!p || !p.length) return this.setAutoUseDealCoupon(!1), void(t && t());
        var h = i.default.getDishList(this.shopId);
        if (h) {
          var d = h[o],
            c = null == d || null == (a = d.skuMenuItems) ? void 0 : a.find((function(o) {
              return o.skuId === e
            })),
            f = null == p ? void 0 : p.filter((function(o) {
              return o.selectStatus === r.NOT_SELECTED
            }));
          if (0 === f.length) this.showGrouponCountExceedToast(p.length), t && t();
          else {
            var C = f.map((function(o) {
              return o.discountTempId
            })).splice(0, n);
            C.length < n && this.showGrouponCountExceedToast(p.length), this.addGrouponCouponDishToCart(C, d, c, !0, u)
          }
        } else l.default.show({
          content: "抱歉，该券暂不可用"
        })
      }
    }, {
      key: "cancelDealCoupon",
      value: function(o) {
        var e = this.dealCoupons.findIndex((function(e) {
            return e.discountTempId === o
          })),
          n = this.dealCoupons;
        return n[e].selectStatus = 0, this.setCancelCouponId(o), this.setDealCoupons(n), this.grouponDishInfo[o]
      }
    }, {
      key: "recoverCouponStatus",
      value: function(o) {
        var e, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
        if (null != (e = this.dealCoupons) && e.length) {
          var t = this.dealCoupons.map((function(e) {
            return e.discountTempId === o ? e.selectStatus = r.NOT_SELECTED : e.discountTempId === n && (e.selectStatus = r.SELECTED), e
          }));
          this.setDealCoupons(t)
        }
      }
    }, {
      key: "showMTAccountToast",
      value: function(o, e) {
        var n, t = i.default.getIsToastFromMTLoginOnce();
        i.default.setIsToastFromMTLoginOnce(!1), !t || null != o && null != (n = o.groupCouponInfo) && n.showMTBind || e && !(e.length <= 0) || l.default.show({
          content: "您还没有可用的团购券哦",
          duration: 3e3
        })
      }
    }, {
      key: "showGrouponCountExceedToast",
      value: function(o) {
        this.isFirstShowToast && l.default.show({
          content: "团购券限".concat(o, "份，超出后该菜品会按菜品售卖价计算"),
          duration: 3e3,
          icon: "none"
        }), this.isFirstShowToast = !1
      }
    }]), o
  }());
exports.default = p;