var e = require("../../../../b/helpers/interopRequireDefault"),
  t = e(require("../../../@limo/core/index.js")),
  i = require("../../../@limo/container/behaviors/index"),
  a = e(require("../../../../lib/mix/log")),
  n = require("../../../../lib/mix/util"),
  o = require("../../limo-ui/ui-constant/enum"),
  r = a.default,
  u = "MT_AGREEMENT";
Component({
  behaviors: [i.commonBehavior, i.limoShim],
  properties: {
    shopId: {
      type: String,
      value: ""
    },
    fromMenu: {
      type: Boolean,
      value: !1
    }
  },
  data: {
    type: 1,
    isShowModal: !1,
    title: "温馨提示",
    buttons: [],
    agreements: []
  },
  ready: function() {
    this.limoReady()
  },
  methods: {
    limoReady: function() {
      this.getAgreement()
    },
    shopDistanceConfirm: function(e) {
      var t = (e.detail || 0).index,
        i = this.data.buttons[t];
      i && i.callback && i.callback()
    },
    onCancel: function() {
      var e = this.data.type;
      if (this.setData({
          isShowModal: !1
        }), 2 === e) wx.exitMiniProgram();
      else {
        var i = t.default.getLimoRuntime().isNativeMp || t.default.getLimoRuntime().isAliPayMp ? "/diancan-menu/pages/error-tip/index" : (0, n.getHost)() + "/diancan/web/error-tip";
        t.default.getLimoRuntime().redirectTo({
          url: i
        })
      }
    },
    onSubmit: function() {
      var e = this,
        i = this.data,
        a = i.templateIds,
        o = i.type;
      t.default.getLimoRuntime().request({
        url: (0, n.getHost)() + "/diancan/api/agreement/signAgreements",
        method: "POST",
        data: {
          sceneId: 3,
          signPlatform: t.default.getLimoRuntime().isWeb ? 3 : 4,
          agreementTemplateIds: a
        },
        complete: function(i) {
          var a;
          e.setData({
            isShowModal: !1
          }), 200 === (null == i || null == (a = i.data) ? void 0 : a.code) && (t.default.getLimoRuntime().showToast({
            icon: "none",
            title: "签署成功",
            duration: 2e3
          }), 2 === o && t.default.getLimoRuntime().setStorageSync(u, 1))
        },
        fail: function(t) {
          r.addError("签署隐私协议失败", t), e.setData({
            isShowModal: !1
          })
        }
      })
    },
    getAgreement: function() {
      var e = this,
        i = this.data.fromMenu,
        a = t.default.getLimoRuntime().getStorageSync(u);
      t.default.getLimoRuntime().request({
        url: (0, n.getHost)() + "/diancan/api/agreement/queryNeedSignAgreements",
        method: "POST",
        data: {
          bizLine: 600,
          sceneId: 3,
          isCacheUser: !!a,
          fromMenu: !!i
        },
        complete: function(t) {
          var i, a = [],
            n = [],
            r = (null == t || null == (i = t.data) ? void 0 : i.data) || {},
            u = r.popUpWindowsType,
            l = void 0 === u ? 1 : u,
            d = r.agreementVOs;
          if (null == d || d.forEach((function(e) {
              var t = e.agreementTemplateVO,
                i = null == t ? void 0 : t.id;
              i && (a.push(i), n.push(t))
            })), a.length > 0) {
            var s = [{
              text: "不同意",
              type: o.BUTTON_TYPE.SECONDARY,
              callback: function() {
                e.onCancel()
              }
            }, {
              text: 2 === l ? "同意并继续" : "同意",
              type: o.BUTTON_TYPE.PRIMARY,
              callback: function() {
                e.onSubmit()
              }
            }];
            e.setData({
              agreements: n,
              templateIds: a,
              isShowModal: !0,
              type: l,
              buttons: s
            })
          }
        },
        fail: function(e) {
          r.addError("获取隐私协议失败", e)
        }
      })
    },
    onAgreementClick: function(e) {
      var i, a = null == e || null == (i = e.currentTarget) || null == (i = i.dataset) ? void 0 : i.tempid,
        o = this.data.shopId;
      if (a) {
        var r = t.default.getLimoRuntime().isNativeMp || t.default.getLimoRuntime().isAliPayMp ? "/diancan-menu/pages/agreements-page/index" : (0, n.getHost)() + "/diancan/web/agreements-content";
        t.default.getLimoRuntime().navigateTo({
          url: "".concat(r, "?tempId=").concat(a, "&shopId=").concat(o)
        })
      }
    },
    prevent: function() {}
  }
});