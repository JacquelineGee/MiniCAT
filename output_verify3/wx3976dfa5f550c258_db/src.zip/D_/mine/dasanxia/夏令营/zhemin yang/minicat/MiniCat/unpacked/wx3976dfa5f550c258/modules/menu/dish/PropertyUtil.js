var e = require("../../../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.dealPicLabel = exports.dealOriginalPrice = exports.dealOrderedSize = exports.dealOperationUnitStr = exports.dealOperationData = exports.dealMemberPriceTag = exports.dealHotSellingTag = exports.dealHotRank = exports.dealHiddenDishDesc = exports.dealDescription = exports.dealCurrentPrice = exports.dealCurrency = void 0, exports.dealPicLabelStyleType = _, exports.dealUnit = exports.dealTagListSize = exports.dealTagList = exports.dealSkuOperationData = exports.dealSkuName = exports.dealSaleQuantity = exports.dealReportConfig = exports.dealPreventSale = exports.dealPointDishInfo = exports.dealPicUrl = exports.dealPicTag = void 0;
var t = require("../../../b/helpers/objectSpread2"),
  n = require("../../../constants/bizConstants"),
  r = require("../../dishHelper"),
  i = require("../../../miniprogram_npm/@components/limo-ui/ui-constant/enum"),
  o = require("../../../constants/menu"),
  a = require("./expose"),
  u = e(require("../shop/shopService")),
  l = require("../../cartHelper"),
  s = require("./util"),
  c = e(require("../cart/cartSdk")),
  d = require("../../../types/newMenu/MenuData"),
  p = e(require("../I18n/I18nService")),
  E = {
    DEFAULT: 0,
    LARGE: 1,
    SMALL: 1,
    DETAIL: 1,
    SUPER_LARGE: 2,
    ADD_ON: 0,
    RECOMMEND_DEFAULT: 1,
    RECOMMEND_LARGE: 2,
    SEARCH: 0,
    RIGHT_LARGE: 2
  },
  T = function(e) {
    return null == e ? "" : e && e > 9999 ? "月售 9999+" : "月售 " + e
  };

function _(e) {
  return e === d.PIC_LABEL_STYLE_TYPE.THEME ? "theme" : ""
}
exports.dealPicLabel = function(e) {
  var t = e.ordered,
    r = e.stockCount,
    i = void 0 === r ? 0 : r,
    o = e.unit,
    a = e.picLabelStyleType;
  return t ? {
    text: "已点",
    styleClass: _(a)
  } : i < n.MAX_SHOW_STOCK_COUNT && i > 0 ? {
    text: "仅剩".concat(i).concat(o),
    styleClass: _(a)
  } : void 0
}, exports.dealDescription = function() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
    t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "",
    n = "";
  return e && (n += e), t && (n += e ? "；" + t : t), n
}, exports.dealSaleQuantity = T, exports.dealPicUrl = function(e) {
  var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : o.DISH_ITEM_TYPE_VAL.DEFAULT;
  return e[E[t]] || n.PLACEHOLDER_DISH_PIC[t]
}, exports.dealPicTag = function(e) {
  return e
};
var I = function(e, n, a) {
    var u, l, s = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "DEFAULT",
      c = arguments.length > 4 ? arguments[4] : void 0,
      d = [];
    if (c) return l = [{
      colorType: i.LABEL_TYPE.POINT_PURCHASE,
      tagDesc: "积分换购"
    }];
    a ? l = a : e && e.tagList && (l = e.tagList);
    var p = (null == e ? void 0 : e.recommendTags) || [];
    return null != (u = l) && u.length || s !== o.DISH_ITEM_TYPE_VAL.RIGHT_LARGE && s !== o.DISH_ITEM_TYPE_VAL.SUPER_LARGE && s !== o.DISH_ITEM_TYPE_VAL.RECOMMEND_LARGE && s !== o.DISH_ITEM_TYPE_VAL.RECOMMEND_DEFAULT || !(p.length > 0) || (l = Array.isArray(l) ? l.concat(p) : p), l && 0 !== l.length ? d = l.map((function(o) {
      var a = o.tagDesc,
        u = o.tagLabel;
      switch (o.colorType) {
        case 16:
        case i.LABEL_TYPE.BKG_PRICE_1:
          var l = (0, r.getMemberTagNew)(e, n);
          return {
            colorType: o.colorType, tagDesc: l || o.tagDesc, tagLabel: o.tagLabel
          };
        case i.LABEL_TYPE.BKG_PRICE_2:
          return a || u ? t(t({}, o), {}, {
            tagLabel: null != u ? u : "",
            tagDesc: null != a ? a : ""
          }) : {
            colorType: o.colorType,
            tagDesc: ""
          };
        default:
          return o
      }
    })) || [] : d
  },
  P = function(e) {
    return "" + (0, r.getPriceText)(!1, e, e.grouponCouponCount && e.grouponCouponCount > 0)
  },
  D = function(e) {
    var t = {
      text: "",
      start: ""
    };
    return e.unit && (t.text += "/" + e.unit), (0, r.isAddPrice)(e) && (t.start = "起"), t
  },
  g = function(e) {
    return (null == e ? void 0 : e.length) > 4 ? (e + "").substring(0, 4).concat("…") : e
  },
  L = function(e, r, i, a) {
    var s, d = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : "",
      p = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : "DEFAULT",
      E = arguments.length > 6 ? arguments[6] : void 0;
    if (e) {
      var T = E === n.DISH_CATEGORY_ID.POINT_PURCHASE,
        _ = "";
      if (E === n.DISH_CATEGORY_ID.POINT_PURCHASE) {
        var I = (0, l.getPointPurchaseSpu)(e),
          P = I.pointDish,
          L = I.currentSkuId;
        e = t({}, P), _ = L
      }
      var A = c.default.getRefactorCartDishMap(),
        S = c.default.computePointPurchaseDishCountInCart(e.spuId, A),
        v = u.default.getShopServiceData(),
        x = v.fmpBizData,
        C = {
          id: e.spuId,
          count: r,
          mustCount: a,
          unit: D(e),
          maxCount: e.stockCount,
          minCount: e.minBoughtCount,
          incCount: e.incBoughtCount,
          showMultipleInput: e.showMultipleInput,
          mini: -1 !== [o.DISH_ITEM_TYPE_VAL.SMALL, o.DISH_ITEM_TYPE_VAL.COLLOCATION].indexOf(p) && E !== n.DISH_CATEGORY_ID.ORDERED,
          showDishOperation: null == (s = null == x ? void 0 : x.showDishOperation) || s,
          discount: T ? o.POINT_DISH_TYPE : "",
          pointPurchaseCount: S,
          skuId: _
        };
      if ((0, l.judgeMultiDish)(e) || (0, l.judgeComplexSpuDish)(e)) C.type = o.DISH_OPERATION_TYPE_VAL.BUTTON, C.panelType = o.PANEL_TYPE_VAL.SPEC, C.text = "选规格";
      else if ((0, l.judgePackageSpuDish)(e)) {
        var h = (0, l.judgeFixedPackage)(e);
        C.type = h ? o.DISH_OPERATION_TYPE_VAL.NUMBER : o.DISH_OPERATION_TYPE_VAL.BUTTON, h || (C.text = "选套餐", C.panelType = o.PANEL_TYPE_VAL.PACKAGE)
      } else C.type = o.DISH_OPERATION_TYPE_VAL.NUMBER;
      return e.canWeight && (C.type = o.DISH_OPERATION_TYPE_VAL.BUTTON, C.weight = i, C.panelType = o.PANEL_TYPE_VAL.WEIGHT, C.text = i ? "".concat(i).concat(g(e.unit)) : "选重量", delete C.count), e.minBoughtCount > 1 && 0 === r && (C.type = "ADDON" === d && r > 0 ? o.DISH_OPERATION_TYPE_VAL.NUMBER : o.DISH_OPERATION_TYPE_VAL.BUTTON, C.text = "".concat(e.minBoughtCount).concat(e.unit || "份", "起售"), e.canWeight && r && (C.text = "".concat(r).concat(e.unit))), e.soldOut && (C.type = o.DISH_OPERATION_TYPE_VAL.TEXT, C.text = n.SOLD_OUT_TEXT), e.canSaleNow || e.validity || (C.type = o.DISH_OPERATION_TYPE_VAL.TEXT, C.text = n.NOT_CAN_SALE, C.needHelp = !0), C
    }
  };
exports.dealHiddenDishDesc = function(e, t) {
  var n = !1;
  if (t !== o.DISH_ITEM_TYPE_VAL.DEFAULT && t !== o.DISH_ITEM_TYPE_VAL.SEARCH) return n;
  var r = e.estimatedPrice,
    i = e.dishDescribeTag,
    a = e.recommendTags,
    u = I(e);
  return T(e.saleQuantity) && r && (a && a.length || i && i.length) && u && u.length && (n = !0), n
}, exports.dealReportConfig = function(e) {
  var t, n = e.itemDetail,
    r = e.skuId,
    i = e.index,
    o = e.dishType,
    u = e.isLogin,
    l = e.parentName,
    c = e.categoryName,
    d = e.parentIndex,
    p = e.categoryId;
  return {
    dishShowType: o,
    dishType: o,
    index: i,
    spuId: n && n.id,
    spuName: n && n.name,
    belongCategory: {
      parentName: l || c,
      parentIndex: l ? d : i,
      name: l ? c : "",
      index: l ? i : ""
    },
    fromDishList: 1,
    hotSaleTag: (0, s.dealHotSaleTag)(null == n || null == (t = n.hotSellingTag) ? void 0 : t.type),
    categoryId: p,
    addFrom: p < 0 ? a.EXPOSE_DISH_TYPE.DISHLIST : a.EXPOSE_DISH_TYPE.CATEGORY,
    skuId: r,
    isLogin: u
  }
}, exports.dealMemberPriceTag = function(e) {
  var t;
  return null == (t = I(e)) ? void 0 : t.find((function(e) {
    return e.colorType === i.LABEL_TYPE.BKG_PRICE_1 || 16 === e.colorType
  }))
}, exports.dealSkuName = function(e) {
  var t;
  if (e) {
    var n = e.specAttrs,
      r = null == n || null == (t = n[0]) ? void 0 : t.value;
    return r ? "".concat(e.skuName, "(").concat(r, ")") : e.skuName
  }
}, exports.dealHotSellingTag = function(e, t, n) {
  if (e) {
    var r = "",
      a = 1,
      u = [],
      l = i.HOT_SELLING_TYPE.PRICE_WITH_PIC.some((function(t) {
        return t === (null == e ? void 0 : e.type)
      })),
      s = p.default.getCurrency();
    return l && t ? (r = e.tagDesc, u = [s, t], (a = t.split(".").join("").length) < 2 && (a = 2)) : a = (r = e.tagDesc).length, {
      type: e.type,
      textCount: a,
      text: r,
      prices: u,
      size: n === o.DISH_ITEM_TYPE_VAL.SEARCH ? o.DISH_ITEM_TYPE_VAL.DEFAULT : n
    }
  }
}, exports.dealOrderedSize = function(e) {
  return e
}, exports.dealSkuOperationData = function(e, n, r, i, a) {
  var u = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : o.DISH_ITEM_TYPE_VAL.DEFAULT;
  if (e) {
    var s = e.skuMenuItems.find((function(e) {
      return e.skuId === n
    }));
    if (s) {
      var c = (0, l.getSingleSpu)(e, s),
        d = s.stockCount,
        p = s.soldOut,
        E = s.validity;
      return c = t(t({}, c), {}, {
        stockCount: d || c.stockCount,
        soldOut: p,
        validity: E
      }), t(t({}, L(c, r, i, a, "", u) || {}), {}, {
        skuId: n
      })
    }
  }
}, exports.dealOperationData = L, exports.dealOperationUnitStr = g, exports.dealHotRank = function(e, t) {
  return e && t < 3 ? (0, r.getRankIcon)(t + 1) : ""
}, exports.dealPreventSale = function(e) {
  return !(!e || e.validity && !e.soldOut)
}, exports.dealOriginalPrice = function(e, t) {
  return e.grouponCouponCount && e.grouponCouponCount > 0 ? "" + (0, r.getPriceText)(!1, e, !1) : e.originalPrice && (e.originalPrice !== e.currentPrice || t) ? "" + e.originalPrice : void 0
}, exports.dealUnit = D, exports.dealCurrency = function(e, t, n) {
  var r, i;
  if (!t) return !1;
  var o = e.spuId,
    a = null == n || null == (r = n.pointDishList) ? void 0 : r.find((function(e) {
      return e.spuId === o
    })),
    u = null == a || null == (i = a.pointDishItems) ? void 0 : i[0];
  return !!u && !u.currentPrice
}, exports.dealPointDishInfo = function(e, t) {
  var n, r, i, o = e.spuId,
    a = null == (n = t.pointDishList) ? void 0 : n.find((function(e) {
      return e.spuId === o
    })),
    u = null == a || null == (r = a.pointDishItems) ? void 0 : r[0];
  u && (null == a || null == (i = a.pointDishItems) || i.forEach((function(e) {
    var t;
    Number(e.pointCount) < Number(null == (t = u) ? void 0 : t.pointCount) && (u = e)
  })));
  var s = "",
    c = null == e ? void 0 : e.spuName;
  if (u) {
    var d;
    if (s = u.currentPrice ? "".concat(u.currentPrice, "+").concat(u.pointCount) : "" + u.pointCount, (0, l.judgeMultiDish)(e) && 1 === (null == a || null == (d = a.pointDishItems) ? void 0 : d.length) && c) {
      var p, E = e.skuMenuItems.find((function(e) {
          var t;
          return e.skuId === (null == (t = u) ? void 0 : t.skuId)
        })),
        T = (null == E || null == (p = E.specAttrs) || null == (p = p[0]) ? void 0 : p.value) || "";
      c = T ? "".concat(c, "(").concat(T, ")") : c
    }
    return {
      currentPrice: s,
      name: c
    }
  }
  return {
    currentPrice: P(e),
    name: c
  }
}, exports.dealCurrentPrice = P, exports.dealTagListSize = function(e) {
  switch (e) {
    case o.DISH_ITEM_TYPE_VAL.SUPER_LARGE:
    case o.DISH_ITEM_TYPE_VAL.RECOMMEND_LARGE:
    case o.DISH_ITEM_TYPE_VAL.RIGHT_LARGE:
      return i.UI_SIZE.MIDDLE;
    default:
      return i.UI_SIZE.SMALL
  }
}, exports.dealTagList = I;