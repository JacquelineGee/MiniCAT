var e = require("../../../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.default = void 0;
var t = require("../../../b/helpers/objectSpread2"),
  r = e(require("../../../b/regenerator")),
  a = require("../../../b/helpers/asyncToGenerator"),
  n = require("../../../b/helpers/classCallCheck"),
  s = require("../../../b/helpers/createClass"),
  i = require("../../../constants/path"),
  o = e(require("../../../api/rmsStorage")),
  u = require("../../../constants/bizConstants"),
  c = require("../../../constants/ajaxResCode"),
  d = e(require("../../../miniprogram_npm/@mtfe/rms-triangle-c/index.js")),
  l = e(require("../../../lib/mix/toast")),
  h = require("../../../constants/orderConstants"),
  f = require("../../../modules/order-common/OrderCommonHelper"),
  p = require("../../../miniprogram_npm/@mtfe/rms-sdk/index.js"),
  v = e(require("./ComponentsViewModel")),
  m = require("../../../prefetch/order-list"),
  g = require("../../../lib/navigator"),
  y = require("../../../lib/env"),
  D = l.default,
  I = function() {
    function e(t) {
      var r = this;
      n(this, e), this.pageInstance = void 0, this.Limo = void 0, this.componentsModel = new v.default, this.offset = "", this.listData = [], this.loadingStatus = u.LOADING.DOING, this.errorMes = "", this.lastUrgeTime = -1, this.cachedTabBarList = [], this.urlParams = void 0, this.isRequesting = void 0, this.showDialog = function(e, t, a) {
        r.Limo.showDialog(e, t, a)
      };
      var a = t.pageInstance,
        s = t.Limo;
      this.pageInstance = a, this.Limo = s
    }
    var l, I, R, b, O, k;
    return s(e, [{
      key: "pageLoad",
      value: function() {
        var e = this.urlParams.tenantId;
        e && o.default.setTenantId(e), this.loadCachedTabBar(), this.fetchOrderList()
      }
    }, {
      key: "onReachBottom",
      value: function() {
        this.fetchOrderList()
      }
    }, {
      key: "urgeOrder",
      value: (k = a(r.default.mark((function e(t) {
        var n, s, i = this;
        return r.default.wrap((function(e) {
          for (;;) switch (e.prev = e.next) {
            case 0:
              if (n = t.type, s = t.orderViewId, e.t0 = n !== h.ORDER_TYPE.TAKEAWAY, !e.t0) {
                e.next = 5;
                break
              }
              return e.next = 5, (0, p.transaction)("ORDER_LIST.URGE_ORDER", function() {
                var e = a(r.default.mark((function e(t) {
                  return r.default.wrap((function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        (0, f.fetchUrgeOrder)(s, i.lastUrgeTime, (function() {
                          i.lastUrgeTime = Date.now(), t.success()
                        }));
                      case 1:
                      case "end":
                        return e.stop()
                    }
                  }), e)
                })));
                return function(t) {
                  return e.apply(this, arguments)
                }
              }(), !0);
            case 5:
            case "end":
              return e.stop()
          }
        }), e)
      }))), function(e) {
        return k.apply(this, arguments)
      })
    }, {
      key: "toInvoice",
      value: function(e) {
        var t = e.shopId,
          r = e.invoiceStatus,
          a = e.type,
          n = e.orderViewId;
        (0, f.fetchInvoice)({
          shopId: t,
          invoiceStatus: r,
          type: a,
          orderViewId: n
        }, this.showDialog)
      }
    }, {
      key: "gotoPay",
      value: (O = a(r.default.mark((function e(t) {
        var a, n, s, o, u, c, l, f, p, v, m, D, I, R, b;
        return r.default.wrap((function(e) {
          for (;;) switch (e.prev = e.next) {
            case 0:
              if (a = t.type, n = t.showCallWaiter, s = t.orderItemExtra, o = t.shopId, a !== h.ORDER_TYPE.TAKEAWAY) {
                e.next = 3;
                break
              }
              return e.abrupt("return");
            case 3:
              c = (u = s || {}).tableNum, l = u.posOrderId, f = u.posOrderVersion, u.postPayTips, p = this.urlParams, v = p.entranceChannel, m = void 0 === v ? 0 : v, D = p.paySource, I = void 0 === D ? 0 : D, R = p.posDeviceId, b = p.payOpenId, (0, g.mixNavigateTo)("".concat(y.isNativeMp ? i.PATH["pay-confirm"] : "pay-confirm", "?").concat(d.default.stringify({
                shopId: o,
                tableNum: c,
                entranceChannel: m,
                posOrderId: l,
                paySource: I,
                posDeviceId: R,
                showCallWaiter: n,
                payOpenId: b,
                posOrderVersion: f
              })), !1);
            case 5:
            case "end":
              return e.stop()
          }
        }), e, this)
      }))), function(e) {
        return O.apply(this, arguments)
      })
    }, {
      key: "getOrderListRequest",
      value: (b = a(r.default.mark((function e() {
        return r.default.wrap((function(e) {
          for (;;) switch (e.prev = e.next) {
            case 0:
              return e.abrupt("return", d.default.preload.getPreloadData({
                path: "/pages/order-list/index",
                key: "orderListPageMainRequestData"
              }) || (0, m.createOrderListRequest)(t(t({}, this.urlParams), {}, {
                offset: this.offset
              })));
            case 1:
            case "end":
              return e.stop()
          }
        }), e, this)
      }))), function() {
        return b.apply(this, arguments)
      })
    }, {
      key: "fetchOrderList",
      value: (R = a(r.default.mark((function e() {
        var t = this;
        return r.default.wrap((function(e) {
          for (;;) switch (e.prev = e.next) {
            case 0:
              if (e.t0 = this.isRequesting, e.t0) {
                e.next = 5;
                break
              }
              return this.isRequesting = !0, e.next = 5, (0, p.transaction)("ORDER_LIST.FETCH_ORDER_LIST", function() {
                var e = a(r.default.mark((function e(a) {
                  var n, s, i, o, d, l, h;
                  return r.default.wrap((function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.prev = 0, e.next = 3, t.getOrderListRequest();
                      case 3:
                        n = e.sent, i = (s = n || {}).code, o = s.data, d = s.msg, i === c.RES_CODE.SUCCESS && o ? (a.success(), t.handleResult(o)) : i === c.RES_CODE.SUCCESS && "success" === d ? (t.handleError("暂无订单"), (h = (null == (l = t.listData) ? void 0 : l.length) || 0) && h % 20 == 0 && (t.loadingStatus = u.LOADING.END, t.renderData(t.getRenderModel())), a.fail(i)) : (t.handleError(), a.fail(i)), e.next = 14;
                        break;
                      case 11:
                        e.prev = 11, e.t0 = e.catch(0), t.handleError(), a.fail(500);
                      case 14:
                        t.isRequesting = !1;
                      case 15:
                      case "end":
                        return e.stop()
                    }
                  }), e, null, [
                    [0, 11]
                  ])
                })));
                return function(t) {
                  return e.apply(this, arguments)
                }
              }());
            case 5:
            case "end":
              return e.stop()
          }
        }), e, this)
      }))), function() {
        return R.apply(this, arguments)
      })
    }, {
      key: "tabBarRenderCallback",
      value: function(e) {
        if (e) {
          var t = e.tabBarList,
            r = void 0 === t ? [] : t,
            a = this.urlParams || {},
            n = a.restaurantViewId,
            s = void 0 === n ? "" : n,
            i = a.shopId,
            u = void 0 === i ? "" : i;
          (s || u) && o.default.setTabBarData(s || u, r)
        }
      }
    }, {
      key: "btnClick",
      value: function(e) {
        if (e) {
          var t = e.order,
            r = e.type;
          "function" == typeof this[r] && this[r](t)
        }
      }
    }, {
      key: "getRenderModel",
      value: function() {
        var e = {
          modules: [{
            name: "order-list",
            description: "订单列表",
            data: this.componentsModel.formatOrderList(this.listData, this.loadingStatus, this.errorMes)
          }, {
            name: "tab-bar",
            data: this.componentsModel.formatTabBar(this.urlParams, this.cachedTabBarList)
          }]
        };
        return e.modules = e.modules.filter((function(e) {
          return e.data
        })), e
      }
    }, {
      key: "handleResult",
      value: (I = a(r.default.mark((function e(t) {
        var a, n, s, i, o;
        return r.default.wrap((function(e) {
          for (;;) switch (e.prev = e.next) {
            case 0:
              n = t.orderItems, s = void 0 === n ? [] : n, i = t.nextOffset, o = void 0 === i ? "" : i, (null == s ? void 0 : s.length) > 0 && (this.listData = this.listData.concat(s)), (null == (a = this.listData) ? void 0 : a.length) > 0 ? (this.offset = o, this.loadingStatus = o ? u.LOADING.DONE : u.LOADING.END, this.renderData(this.getRenderModel())) : this.handleError();
            case 2:
            case "end":
              return e.stop()
          }
        }), e, this)
      }))), function(e) {
        return I.apply(this, arguments)
      })
    }, {
      key: "handleError",
      value: (l = a(r.default.mark((function e() {
        var t, n, s = this,
          i = arguments;
        return r.default.wrap((function(e) {
          for (;;) switch (e.prev = e.next) {
            case 0:
              if (t = i.length > 0 && void 0 !== i[0] ? i[0] : "", !((null == (n = this.listData) ? void 0 : n.length) > 0)) {
                e.next = 5;
                break
              }
              D.show({
                content: t || "加载失败"
              }), e.next = 9;
              break;
            case 5:
              return e.next = 7, (0, p.transaction)("ORDER_LIST.TO_ERROR_TIP", function() {
                var e = a(r.default.mark((function e(t) {
                  var a;
                  return r.default.wrap((function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        (null == (a = s.pageInstance) ? void 0 : a.loadSuccess) && s.pageInstance.loadSuccess(), (null == t ? void 0 : t.success) && t.success();
                      case 1:
                      case "end":
                        return e.stop()
                    }
                  }), e)
                })));
                return function(t) {
                  return e.apply(this, arguments)
                }
              }());
            case 7:
              this.errorMes = t || "加载失败", this.renderData(this.getRenderModel());
            case 9:
            case "end":
              return e.stop()
          }
        }), e, this)
      }))), function() {
        return l.apply(this, arguments)
      })
    }, {
      key: "renderData",
      value: function(e) {
        this.pageInstance.renderPage(e)
      }
    }, {
      key: "loadCachedTabBar",
      value: function() {
        var e = this.urlParams,
          t = e.shopId,
          r = e.restaurantViewId;
        this.cachedTabBarList = o.default.getTabBarData(r || t) || []
      }
    }]), e
  }();
exports.default = I;