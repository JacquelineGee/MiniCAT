var e = require("../../../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.updateFmpInfo = exports.saveLocationInfoToCloud = exports.getPageSpu = exports.getMenuFmp = void 0;
var r = require("../../../b/helpers/objectSpread2"),
  t = require("../../../b/helpers/typeof"),
  a = e(require("../../../b/regenerator")),
  n = require("../../../b/helpers/asyncToGenerator"),
  u = e(require("../../../api/menuApi")),
  o = require("../../../types/IResponse"),
  s = e(require("../../../miniprogram_npm/seamless-immutable/index.js")),
  i = require("../../../lib/util"),
  p = require("../../../constants/ajaxResCode"),
  c = require("../../../constants/errorTip"),
  l = e(require("../../../lib/mix/log")),
  d = e(require("../../../api/rmsStorage")),
  f = require("./point"),
  m = require("../../../lib/navigator"),
  b = require("../../../types/common.d.js"),
  E = e(require("../../../api/cloudDataApi")),
  R = e(require("../../../miniprogram_npm/@mtfe/rms-triangle-c/index.js")),
  h = require("../../../miniprogram_npm/@mtfe/rms-sdk/index.js"),
  v = require("../../../lib/wx/weiqian-special"),
  g = l.default,
  I = 0,
  x = function() {
    var e = n(a.default.mark((function e(r) {
      var n, s, i, l, E, g, I, x, D, S, O, _, C, T;
      return a.default.wrap((function(e) {
        for (;;) switch (e.prev = e.next) {
          case 0:
            return "userGeoPoint" in r && "object" == t(r.userGeoPoint) && r.userGeoPoint && (r.userGeoPoint = JSON.stringify(r.userGeoPoint)), e.prev = 1, e.next = 4, u.default.requestFmpData(r);
          case 4:
            if (e.t0 = e.sent, e.t0) {
              e.next = 7;
              break
            }
            e.t0 = void 0;
          case 7:
            s = e.t0, e.next = 13;
            break;
          case 10:
            return e.prev = 10, e.t1 = e.catch(1), e.abrupt("return", {
              errorType: f.FAIL_REASON.NETWORK_ERROR,
              errorMsg: "string" == typeof e.t1 ? e.t1 : "网络异常"
            });
          case 13:
            if (null != (n = s) && null != (n = n.data) && null != (n = n.memberInfo) && n.memberId && h.LXReporter.appendCommonParam({
                member_id: null == (i = s) || null == (i = i.data) || null == (i = i.memberInfo) ? void 0 : i.memberId
              }), s) {
              e.next = 16;
              break
            }
            return e.abrupt("return", {
              errorType: f.FAIL_REASON.NETWORK_ERROR,
              errorMsg: "网络异常，请重试",
              errorIconUrl: "https://p0.meituan.net/travelcube/1ae6a3c371df4b08d7a438bc91a8ddbe64461.png"
            });
          case 16:
            E = (l = s).code, g = l.data, I = l.msg, e.t2 = E, e.next = e.t2 === p.RES_CODE.SUCCESS ? 20 : e.t2 === p.RES_CODE.REDIRECT_CODE ? 21 : 610 === e.t2 ? 22 : e.t2 === c.ERROR_TYPE.NEED_DOWNGRADE_CODE ? 23 : 450 === e.t2 ? 24 : e.t2 === c.ERROR_TYPE.NOT_HAS_USER_ID ? 25 : 1202 === e.t2 ? 26 : 1200 === e.t2 ? 27 : 1201 === e.t2 ? 28 : 34;
            break;
          case 20:
            return e.abrupt("return", g);
          case 21:
            return e.abrupt("return", o.ResponseState.REDIRECT);
          case 22:
            return e.abrupt("return", {
              errorType: f.FAIL_REASON.CAN_NOT_ORDER_DISH,
              errorMsg: I || "暂不支持点餐"
            });
          case 23:
            return e.abrupt("return", {
              errorType: f.FAIL_REASON.NEED_DOWNGRADE_CODE,
              errorMsg: ""
            });
          case 24:
            return e.abrupt("return");
          case 25:
            return e.abrupt("return", {
              errorType: f.FAIL_REASON.NEED_DOWNGRADE_CODE,
              errorMsg: I || "未获取到用户信息"
            });
          case 26:
            return e.abrupt("return", ((0, v.checkWeiQian)() || (0, m.jumpToPage)("shop-list", {
              pageFrom: "MENU",
              shopId: ""
            }), o.ResponseState.REDIRECT));
          case 27:
            return e.abrupt("return", ((0, v.checkWeiQian)() || (0, m.jumpToPage)("shop-list", {
              pageFrom: "MENU",
              noMatchPrefer: "1",
              shopId: ""
            }), o.ResponseState.REDIRECT));
          case 28:
            if (x = s.data, S = (D = null != x ? x : {}).redirectUrl, O = D.fmpBizData, !S || !O) {
              e.next = 33;
              break
            }
            return d.default.setMultiShop(b.MultiShop.MULTIPLE + ""), C = O.recSceneFlag, T = O.shopCache, e.abrupt("return", (null !== C && d.default.setRecSceneFlag(!!C), T && d.default.setShopCache(T), R.default.redirectTo(null == (_ = s.data) ? void 0 : _.redirectUrl), o.ResponseState.REDIRECT));
          case 33:
            return e.abrupt("break", 35);
          case 34:
            return e.abrupt("return", {
              errorType: E,
              errorMsg: I || "网络异常，请重试",
              errorIconUrl: "https://p0.meituan.net/travelcube/1ae6a3c371df4b08d7a438bc91a8ddbe64461.png"
            });
          case 35:
          case "end":
            return e.stop()
        }
      }), e, null, [
        [1, 10]
      ])
    })));
    return function(r) {
      return e.apply(this, arguments)
    }
  }();
exports.getMenuFmp = x;
var D = function() {
  var e = n(a.default.mark((function e(t) {
    var n, o, c, l, d, f, m, b, E, R, h, v, I, x, D;
    return a.default.wrap((function(e) {
      for (;;) switch (e.prev = e.next) {
        case 0:
          return t.userGeoPoint && (t.userGeoPoint = JSON.stringify(t.userGeoPoint)), e.prev = 1, e.next = 4, u.default.requestSpu(t);
        case 4:
          if (e.t0 = e.sent, e.t0) {
            e.next = 7;
            break
          }
          e.t0 = void 0;
        case 7:
          if (o = e.t0) {
            e.next = 10;
            break
          }
          return e.abrupt("return");
        case 10:
          if (c = o.code, l = o.data, c === p.RES_CODE.SUCCESS && l) {
            e.next = 13;
            break
          }
          return e.abrupt("return");
        case 13:
          if (d = l.spuDetail, f = l.totalCount, m = l.cacheId, b = l.pageSize, E = l.mtShopId, n = s.default.merge(l), !(f <= b)) {
            e.next = 16;
            break
          }
          return e.abrupt("return", n);
        case 16:
          for (f > 900 && E && g.sendInfo({
              name: "超过900道菜的门店",
              content: {
                shopId: E,
                totalCount: f
              }
            }), R = d, h = Math.ceil(f / b), v = [], I = 2; I <= h; I++) v.push(u.default.requestSpu(r(r({}, t), {}, {
            pageNum: I,
            cacheId: m
          })));
          return e.next = 21, Promise.all(v);
        case 21:
          return x = e.sent, D = !1, e.abrupt("return", (x.every((function(e) {
            var r = (0, i.getIn)(e, ["data", "spuDetail"]);
            return 200 === (null == e ? void 0 : e.code) && r ? (Object.assign(R, r), !0) : (D = !0, !1)
          })), D ? void g.addError("获取菜单页数据失败", "菜品数据不全") : s.default.setIn(n, ["spuDetail"], R)));
        case 26:
          e.prev = 26, e.t1 = e.catch(1);
        case 28:
        case "end":
          return e.stop()
      }
    }), e, null, [
      [1, 26]
    ])
  })));
  return function(r) {
    return e.apply(this, arguments)
  }
}();
exports.getPageSpu = D;
var S = function() {
  var e = n(a.default.mark((function e(t, n) {
    var o, i, p, c, l, d, f, m, b, E, R, h, v, x, D, O;
    return a.default.wrap((function(e) {
      for (;;) switch (e.prev = e.next) {
        case 0:
          return o = n, e.prev = 1, e.next = 4, u.default.requestMenuExtra(t);
        case 4:
          if ((p = e.sent) && p.data) {
            e.next = 7;
            break
          }
          return e.abrupt("return", n);
        case 7:
          return c = p.data, l = c.openTableInfo, d = c.mandatoryInfos, f = c.fmpBizData, b = (m = null != f ? f : {}).orderBottomVO, E = m.showDishOperation, o = s.default.setIn(n, ["shopConfig", "mandatoryInfos"], d), o = s.default.setIn(o, ["openTableInfo"], l), R = null != l && l.peopleCount ? (null == l ? void 0 : l.peopleCount) + " 人用餐" : null, e.abrupt("return", (o = s.default.setIn(o, ["moduleData", "menu-shop-info", "data", "peopleCountText"], R), o = s.default.setIn(o, ["fmpBizData"], r(r({}, null != (i = o.fmpBizData) ? i : {}), {}, {
            orderBottomVO: b,
            showDishOperation: E
          }))));
        case 13:
          if (e.prev = 13, e.t0 = e.catch(1), !(I < 2)) {
            e.next = 17;
            break
          }
          return e.abrupt("return", (I++, S(t, n)));
        case 17:
          h = e.t0 || {}, v = h.config, x = h.code, D = h.message, O = {
            url: null == v ? void 0 : v.url,
            timeout: "ECONNABORTED" === x && -1 !== D.indexOf("timeout"),
            message: D
          }, g.addError((null == v ? void 0 : v.url) + "接口连续3次异常", O, {
            category: "ajaxError"
          });
        case 19:
          return e.abrupt("return", o);
        case 20:
        case "end":
          return e.stop()
      }
    }), e, null, [
      [1, 13]
    ])
  })));
  return function(r, t) {
    return e.apply(this, arguments)
  }
}();
exports.updateFmpInfo = S;
var O = function() {
  var e = n(a.default.mark((function e(r) {
    var t, n;
    return a.default.wrap((function(e) {
      for (;;) switch (e.prev = e.next) {
        case 0:
          return t = r.cacheKey, n = r.location, e.prev = 1, e.next = 4, E.default.saveLocalData({
            cacheKey: t,
            localData: {
              cachedLocation: JSON.stringify(n)
            }
          });
        case 4:
          e.next = 8;
          break;
        case 6:
          e.prev = 6, e.t0 = e.catch(1);
        case 8:
        case "end":
          return e.stop()
      }
    }), e, null, [
      [1, 6]
    ])
  })));
  return function(r) {
    return e.apply(this, arguments)
  }
}();
exports.saveLocationInfoToCloud = O;