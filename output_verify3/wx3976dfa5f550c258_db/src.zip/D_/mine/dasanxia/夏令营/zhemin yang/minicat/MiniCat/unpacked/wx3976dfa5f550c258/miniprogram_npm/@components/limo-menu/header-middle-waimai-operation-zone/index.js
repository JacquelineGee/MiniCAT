var e = require("../../../../b/helpers/interopRequireDefault"),
  t = require("../../../@limo/container/behaviors/index"),
  i = e(require("../../../seamless-immutable/index.js")),
  a = e(require("../../../../store/menu")),
  o = e(require("../common-behaviors/storeBehavior"));
Component({
  behaviors: [o.default, t.commonBehavior, t.limoShim],
  properties: {
    bizType: {
      type: Number,
      value: 0
    },
    shopName: {
      type: String,
      value: ""
    },
    shopLogo: {
      type: String,
      value: ""
    },
    waiMaiConfig: {
      type: Object,
      value: {},
      observer: function(e) {
        e && this.updateWMConfig(e)
      }
    },
    pickUpConfig: {
      type: Object,
      value: {},
      observer: function(e) {
        e && Object.keys(e).length && this.setData({
          distanceText: e.distanceText || ""
        })
      }
    },
    showTakeAwaySwitch: {
      type: Boolean,
      value: !0
    },
    wmTitleClassName: {
      type: String,
      value: ""
    },
    wmTitleOverflow: {
      type: Boolean,
      value: !1
    },
    sizeType: {
      type: String,
      value: "normal"
    }
  },
  data: {
    takeAwayDeliveryFeeRule: null,
    selectedAddress: "",
    distanceText: ""
  },
  created: function() {
    this.isPreview || (this.store = a.default)
  },
  methods: {
    limoReady: function() {
      this.commonBehaviorsStoreBehavior_limoReady()
    },
    mapToState: function(e) {
      var t, a = i.default.getIn(e, ["takeaway", "deliveryInfo", "takeAwayDeliveryFeeRule"]) || null,
        o = i.default.getIn(e, ["takeaway", "userSelectedAddress"]) || {},
        s = i.default.getIn(e, ["takeaway", "pickUpDistanceText"]) || "";
      return {
        takeAwayDeliveryFeeRule: a || null,
        selectedAddress: o.blockName || o.recipientAddrDetail || this.data.selectedAddress,
        distanceText: s || (null == (t = this.data.pickUpConfig) ? void 0 : t.distanceText) || ""
      }
    },
    updateWMConfig: function(e) {
      this.setData({
        selectedAddress: e.selectedAddress
      })
    },
    getLocationInfo: function() {
      this.triggerEvent("getLocationInfoFn", {}, {
        bubbles: !0,
        composed: !0
      })
    },
    toggleShop: function() {
      var e, t;
      (null != (e = this.data.waiMaiConfig) && e.multiShop || null != (t = this.data.pickUpConfig) && t.multiShop) && this.triggerEvent("toggleShopFn", {
        bizType: this.data.bizType
      }, {
        bubbles: !0,
        composed: !0
      })
    },
    goToAddressPage: function() {
      this.triggerEvent("goToAddressPageFn", {}, {
        bubbles: !0,
        composed: !0
      })
    }
  },
  ready: function() {
    this.limoReady()
  }
});