var a = require("../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.transManualCampaignsToSimple = exports.transManualCampaignsToRender = exports.dealCampaignDishPrice = void 0;
var e = a(require("../miniprogram_npm/seamless-immutable/index.js")),
  i = require("../ui/constant/enum"),
  n = require("../constants/bizConstants"),
  r = a(require("./menu/shop/shopService")),
  t = require("./dishHelper"),
  u = function(a, e) {
    if (6 === a) return {
      tagDesc: e.tagDesc || "超值换购",
      colorType: i.LABEL_TYPE.BORDER_RED
    }
  };
exports.dealCampaignDishPrice = function(a, i, n) {
  if (!a || !a.length) return n;
  var r = n[i] || {},
    t = r.campaignPrice || 0,
    u = r.campaignOrgPrice || 0;
  return a.forEach((function(a) {
    a && a.campaignSkus && a.campaignSkus.forEach((function(a) {
      var e = a || {},
        i = e.skuId,
        n = e.totalPrice,
        r = e.orgTotalPrice;
      i && void 0 !== n && void 0 !== r && (t += n, u += r)
    }))
  })), n = e.default.setIn(n, [i, "campaignPrice"], t), e.default.setIn(n, [i, "campaignOrgPrice"], u)
};
exports.transManualCampaignsToSimple = function(a) {
  return a.map((function(a) {
    return {
      campaignType: a.campaignType,
      campaignId: a.campaignId,
      campaignSkus: a.campaignSkus.map((function(a) {
        return {
          spuId: a.spuId,
          skuId: a.skuId,
          skuName: a.skuName,
          count: a.count
        }
      }))
    }
  }))
};
exports.transManualCampaignsToRender = function(a, i, o) {
  if (!a || !a.length || !i) return [];
  var s = [],
    c = ((r.default.getShopServiceData() || {}).shopInfo || {}).actId2Promotion;
  return a.forEach((function(a) {
    var r, p = a.campaignType,
      m = a.campaignId,
      l = a.campaignSkus,
      g = null == c || null == (r = c[m]) || null == (r = r.rule) ? void 0 : r.title;
    l.forEach((function(a) {
      var r = a.spuId,
        c = a.skuId,
        m = a.skuName,
        l = a.totalPrice,
        d = a.orgTotalPrice,
        f = a.count,
        I = i[r];
      if (I) {
        var P, h = e.default.getIn(I, ["dishPicUrls", n.PICTURE_RATIO.ONE_TO_ONE]) || n.PLACEHOLDER_DISH_PIC.ONE_TO_ONE;
        void 0 !== l && void 0 !== d && (P = {
          actualPrice: l,
          originPrice: d
        }), s.push({
          skuId: c,
          skuName: m,
          dishImg: h,
          detail: (0, t.dealNormalDetail)(I, a),
          campaignTag: u(p, {
            tagDesc: g
          }),
          itemCount: o && f ? o * f : f,
          itemPrice: P,
          disableModifying: !0,
          disableCounting: !0
        })
      }
    }))
  })), s
};