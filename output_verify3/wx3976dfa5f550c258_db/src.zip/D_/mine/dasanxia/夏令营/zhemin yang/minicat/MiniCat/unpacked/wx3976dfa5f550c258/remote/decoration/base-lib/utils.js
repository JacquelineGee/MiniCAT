Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.appendQuery = function(t, e) {
  if (!t) return "";
  if (!e) return t;
  var n = t.split("#"),
    o = n[0].split("?")[0],
    r = function(t, e) {
      var n = {};
      if (/^(http|https):\/\//.test(t)) t = t.split("?")[1] || "";
      else {
        var o = t.split("?");
        o.length > 1 && (t = o[1])
      }
      return (t = t.split("#")[0]).split("&").forEach((function(t) {
        if (t) {
          var o = t.split("="),
            r = o[1] || "";
          n[o[0]] = e ? decodeURIComponent(r) : r
        }
      })), n
    }(n[0], !0),
    c = n[1],
    i = function() {
      var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
        e = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
      return Object.keys(t).map((function(n) {
        return "".concat(n, "=").concat(e ? encodeURIComponent(t[n]) : t[n])
      })).join("&")
    }(r = Object.assign(r, e), !0);
  return "".concat(o).concat(i ? "?" + i : "").concat(c ? "#" + c : "")
};