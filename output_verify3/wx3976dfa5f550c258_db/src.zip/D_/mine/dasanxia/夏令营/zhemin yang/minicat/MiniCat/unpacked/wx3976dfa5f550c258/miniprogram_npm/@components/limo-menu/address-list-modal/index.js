var e = require("../../../../b/helpers/interopRequireDefault"),
  s = require("../../../@limo/container/behaviors/index"),
  t = e(require("../../../seamless-immutable/index.js")),
  r = e(require("../../../../store/menu")),
  d = e(require("../common-behaviors/storeBehavior"));
Component({
  behaviors: [d.default, s.commonBehavior, s.limoShim],
  properties: {
    title: {
      type: String,
      value: ""
    },
    addressList: {
      type: Array,
      value: [],
      observer: function(e) {
        e && this.updateAddress(e)
      }
    },
    errTips: {
      type: String,
      value: ""
    },
    show: {
      type: Boolean,
      value: !1
    }
  },
  data: {
    GENDER_MAP: {
      male: "先生",
      female: "女士"
    },
    addressListModalflag: !1,
    renderAddressList: []
  },
  created: function() {
    this.store = r.default
  },
  methods: {
    limoReady: function() {
      this.commonBehaviorsStoreBehavior_limoReady()
    },
    mapToState: function(e) {
      var s = t.default.getIn(e, ["takeaway", "addressListModalflag"]) || !1,
        r = t.default.getIn(e, ["takeaway", "userAddressList"]) || [];
      return {
        addressListModalflag: s && this.data.show || !1,
        renderAddressList: r || []
      }
    },
    updateAddress: function(e) {
      this.setData({
        renderAddressList: e
      }), 1 === (null == e ? void 0 : e.length) && this.closePanel(), this.triggerEvent("updateAddressFn", {
        addressList: e
      })
    },
    selectedAddress: function(e) {
      var s = e.currentTarget.dataset.address || e.currentTarget.address;
      this.triggerEvent("selectedAddressFn", {
        address: s
      })
    },
    handleAddNewAddress: function() {
      this.triggerEvent("handleAddNewAddressFn")
    },
    reloadAddressFn: function() {
      this.triggerEvent("reloadAddress")
    },
    closePanel: function() {
      this.setData({
        addressListModalflag: !1
      }), this.triggerEvent("closeAddressListModal")
    }
  },
  ready: function() {
    this.limoReady()
  }
});