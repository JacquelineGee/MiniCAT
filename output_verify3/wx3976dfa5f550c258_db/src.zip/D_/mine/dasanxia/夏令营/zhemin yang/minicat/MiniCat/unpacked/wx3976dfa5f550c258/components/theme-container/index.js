var e = require("../../b/helpers/interopRequireDefault"),
  t = e(require("../../miniprogram_npm/@limo/core/index.js")),
  a = require("../../miniprogram_npm/@limo/container/behaviors/index.js"),
  i = e(require("./utils")),
  r = e(require("../../lib/mix/log")),
  o = require("../../lib/wx/util"),
  s = require("../../miniprogram_npm/@mtfe/rms-sdk/index.js"),
  n = require("../../lib/wx/app-info");
Component({
  behaviors: [a.commonBehavior, a.limoShim],
  properties: {
    options: {
      type: Object,
      value: {},
      observer: function() {
        this.setTheme()
      }
    },
    clearCache: {
      type: Boolean,
      value: !1
    },
    location: {
      type: Object,
      value: {},
      observer: function(e) {
        null != e && e.latitude && (this.setData({
          cacheLocation: e
        }), this.setTheme())
      }
    },
    needLocationCheck: {
      type: Boolean,
      value: !1
    },
    extraRequestParams: {
      type: Object,
      value: {}
    },
    themeType: {
      type: Number,
      value: 1
    },
    beta: {
      type: Boolean,
      value: !1
    }
  },
  data: {
    themes: "",
    located: !1,
    hasReady: !1,
    cacheLocation: null,
    nativeTabbar: !1
  },
  attached: function() {
    this.limoAttached()
  },
  methods: {
    limoAttached: function() {
      var e = this.properties.beta;
      if (this.setThemeByModel(), e && !this.isH5) {
        var t, a = getCurrentPages(),
          i = null == (t = a[a.length - 1]) ? void 0 : t.route;
        (0, n.isNativeTabbarPage)(i) && this.setData({
          nativeTabbar: !0
        })
      }
    },
    setTheme: function() {
      var e = this,
        t = this.properties,
        a = t.needLocationCheck,
        o = t.location,
        s = t.options,
        h = t.themeType,
        u = this.data.cacheLocation,
        l = null != s ? s : {};
      if (Object.keys(l).length) {
        var c = l.shopId;
        !this.isH5 && (0, n.isMerchantWxApp)() && 2 !== Number(h) || (a && !c ? new i.default({
          options: l,
          location: null != u ? u : o,
          needLocationCheck: a,
          extraRequestParams: this.data.extraRequestParams
        }).useTheme().then((function(t) {
          e.setData({
            themes: t
          })
        })).catch((function(e) {
          r.default.addError("装修数据获取失败", e)
        })) : new i.default({
          options: l,
          extraRequestParams: this.data.extraRequestParams
        }).useTheme().then((function(t) {
          e.setData({
            themes: t
          })
        })).catch((function(e) {
          r.default.addError("装修数据获取失败", e)
        })))
      }
    },
    filterOptions: function() {
      if (Object.keys(this.properties.options).length) return this.properties.options;
      var e = t.default.getLimoRuntime().getPageParams();
      if (this.isH5) return e;
      var a, i = getCurrentPages(),
        r = null == (a = i[i.length - 1]) ? void 0 : a.route;
      return (0, o.getTabbarPageOptions)(e, r)
    },
    setThemeByModel: function() {
      if (!this.isH5 && (0, n.isMerchantWxApp)()) {
        var e = s.ThemeModel.getInstance();
        this && this.setData({
          themes: e.getTheme()
        })
      }
    }
  }
});