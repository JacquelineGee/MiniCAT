var t = require("../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.cartViewModelAdapter = void 0, exports.getCartTotalInfo = function(t, e) {
  var i = 0;
  return t && Object.keys(t).forEach((function(n) {
    var r = t[n];
    e[n] && r && r.forEach((function(t) {
      i = (0, c.plusFloat)(i, t.count || 0)
    }))
  })), (0, n.default)({
    cartCount: i
  })
};
var e = require("../b/helpers/objectSpread2");
require("../b/helpers/Arrayincludes");
var n = t(require("../miniprogram_npm/seamless-immutable/index.js")),
  i = t(require("../miniprogram_npm/@dp/md5/index.js")),
  r = require("./cartHelper"),
  o = t(require("../api/rmsStorage")),
  u = require("../miniprogram_npm/reselect/index.js"),
  a = require("../lib/mix/util"),
  c = require("../lib/number"),
  s = require("../constants/bizConstants"),
  l = require("../miniprogram_npm/@components/limo-ui/ui-constant/enum"),
  d = require("./userHelper"),
  f = require("./panel/panelDataUtil"),
  m = require("./coupon/util"),
  p = require("./campaign"),
  g = require("./dishHelper"),
  h = require("../constants/menu");
var I = function(t) {
  var e, n = "",
    i = [];
  if (t && t.meetCondition && 1 === t.discountItemPosi) {
    var r = t || {},
      o = r.conditionCount,
      u = void 0 === o ? "" : o,
      a = r.discountValue,
      c = void 0 === a ? "" : a;
    switch (t.discountType) {
      case s.SHOP_PROMOTION_TYPE.FULL_COUNT_DISCOUNT:
        n = "满量折扣", i = [{
          text: "已享 ".concat(u, " 份")
        }, {
          text: " ".concat(c, " "),
          highlight: !0
        }, {
          text: "折"
        }];
        break;
      case s.SHOP_PROMOTION_TYPE.FULL_COUNT_CUT:
        n = "满量减免", i = [{
          text: "已享每 ".concat(u, " 份减")
        }, {
          text: " ".concat(c, " "),
          highlight: !0
        }, {
          text: "元"
        }];
        break;
      case s.SHOP_PROMOTION_TYPE.FULL_COUNT_FIXED_PRICE:
        n = "满量一口价", i = [{
          text: "已享每 ".concat(u, " 份")
        }, {
          text: " ".concat(c, " "),
          highlight: !0
        }, {
          text: "元"
        }];
        break;
      case s.SHOP_PROMOTION_TYPE.FULL_COUNT_SPEC_PRICE:
        n = "满量特价", i = [{
          text: "已享 ".concat(u, " 份特价")
        }];
        break;
      case s.SHOP_PROMOTION_TYPE.DISH_WITH_FREE:
        n = "买免活动", e = null == t ? void 0 : t.campaignId;
        break;
      default:
        n = "", i = []
    }
  }
  var l, d = !!(t && t.meetCondition && 1 === t.discountItemPosi && t.preMeetCondition),
    f = "";
  return t && t.meetCondition && function(t) {
    return ![s.SHOP_PROMOTION_TYPE.SPECIAL_PRICE].includes(null == t ? void 0 : t.discountType)
  }(t) && (f = t.discountItemPosi === t.discountItemCount ? "discount-bg last-item" : "discount-bg"), (null == t ? void 0 : t.discountType) > 0 && (null == t ? void 0 : t.src) > 0 && (l = (0, m.dealDiscountTag)("".concat(t.discountType, "_").concat(t.src))), {
    showLine: d,
    discountType: n,
    discountContent: i,
    cartItemStyle: f,
    campaignId: e,
    type: null == t ? void 0 : t.discountType,
    discountTag: l
  }
};

function v(t, u, m, v, C, P, T, O) {
  var _ = (0, n.default)([]),
    D = (0, n.default)([]),
    N = 0;
  t && Object.keys(t).forEach((function(e) {
    var i = t[e],
      r = u && u[e];
    return r && i && i.map((function(t) {
      var e = t.skuId,
        i = r.skuMenuItems.find((function(t) {
          return t.skuId === e
        }));
      if (!i) return null;
      var o = t.count || 0,
        u = i.skuImg || n.default.getIn(r, ["dishPicUrls", s.PICTURE_RATIO.ONE_TO_ONE]) || s.PLACEHOLDER_DISH_PIC.ONE_TO_ONE;
      if (t = n.default.set(t, "dishImg", u), t = n.default.set(t, "dishType", null == i ? void 0 : i.dishType), N = (0, c.plusFloat)(N, o), i.dishType === s.DISH_TYPE.NORMAL) {
        var a = n.default.set(t, "detail", (0, g.dealNormalDetail)(r, t, O));
        _ = _.concat([a])
      } else if (i.dishType === s.DISH_TYPE.PACKAGE) {
        var l = (0, f.dealPackageDetail)(i.packageGroups, t.packages),
          d = t.remark ? "备注：" + t.remark : "",
          m = null != d && d.length ? "".concat(l, "，").concat(d) : l,
          p = n.default.set(t, "detail", m);
        _ = _.concat([p])
      }
      return null
    })), null
  })), m && m.map((function(t) {
    var e = _.find((function(e) {
      return e.itemNo === t.goodsNo
    }));
    return e && (D = D.concat([e])), null
  })), D = function(t, e) {
    var r = [];
    if (!e || !e.length) return r;
    var u = function(t) {
        var e = [];
        return t.forEach((function(t) {
          e.unshift(t)
        })), e = (0, n.default)(e)
      }(e),
      a = {},
      c = {};
    u.forEach((function(t, e) {
      a[t.itemNo] = n.default.set(t, "itemCount", t.count), c[t.itemNo] = e + 1
    }));
    var s = [];
    u.forEach((function(e) {
      var u = e.itemNo,
        l = {};
      (e.allDiscount || []).forEach((function(t) {
        var e = t.conditionItems || [];
        if (e.length) {
          var r = [],
            o = "";
          if (e.forEach((function(t) {
              a[t.sourceItemNo] && (r.push(t), o += t.itemNo)
            })), r.length && (o = (0, i.default)(o), -1 === s.indexOf(o))) {
            s.push(o), r = r.sort((function(t, e) {
              return c[t.sourceItemNo] - c[e.sourceItemNo]
            }));
            var u = [],
              d = 0;
            r.forEach((function(e, i) {
              var o = a[e.sourceItemNo];
              d += c[e.sourceItemNo];
              var s = o.itemCount - e.itemCount;
              s < 0 && (s = 0), a[e.sourceItemNo] = n.default.set(o, "itemCount", s);
              var l = n.default.merge(o, {
                itemCount: e.itemCount,
                itemPrice: e.itemPrice,
                allDiscount: [],
                discount: {
                  discountType: t.discountType,
                  conditionCount: t.conditionCount,
                  discountValue: t.discountValue,
                  meetCondition: !0,
                  discountItemCount: r.length,
                  discountItemPosi: i + 1
                },
                campaignDishes: e.campaignDishes || []
              });
              u.push(l)
            })), l[o] = {
              groupSort: d,
              items: u
            }
          }
        }
      }));
      var d = e.allBuyFreeDiscount || [];
      d && d.forEach((function(t) {
        var e = t.discountDishItem || [];
        if (e.length) {
          var o = [],
            u = "";
          if (e.forEach((function(t) {
              a[t.sourceItemNo] && (o.push(t), u += t.itemNo)
            })), o.length && (u = (0, i.default)(u), -1 === s.indexOf(u))) {
            s.push(u), o = o.sort((function(t, e) {
              return c[t.sourceItemNo] - c[e.sourceItemNo]
            }));
            var d = [],
              f = 0;
            o.forEach((function(e, i) {
              var o = a[e.sourceItemNo];
              f += c[e.sourceItemNo];
              var u = o.itemCount - e.itemCount;
              u < 0 && (u = 0), a[e.sourceItemNo] = n.default.set(o, "itemCount", u);
              var s = r.findIndex((function(t) {
                return t.itemNo === e.sourceItemNo
              }));
              s > -1 && (u ? r[s].itemCount = u : r.splice(s, 1));
              var l = n.default.merge(o, {
                itemCount: e.itemCount,
                itemPrice: e.itemPrice,
                allDiscount: [],
                discount: {
                  campaignId: t.campaignId,
                  discountType: t.discountType,
                  src: t.src,
                  meetCondition: !0,
                  discountItemPosi: i + 1
                },
                campaignDishes: e.campaignDishes || []
              });
              d.push(l)
            })), l[u] = {
              groupSort: f,
              items: d
            }
          }
        }
      }));
      var f = a[u];
      if (f && f.itemCount > 0) {
        var m = (0, i.default)(u);
        if (-1 === s.indexOf(m)) {
          var p;
          s.push(m);
          var g = o.default.getCartPrice(t),
            I = (null == g ? void 0 : g.cartItemPrice) || {};
          p = Object.keys(I).length && -1 !== Object.keys(I).indexOf(u) ? {
            originPrice: n.default.getIn(I, [u, "originPrice"]),
            actualPrice: n.default.getIn(I, [u, "actualPrice"])
          } : f.itemPrice;
          var v = JSON.parse(JSON.stringify(f));
          v.itemCount = f.itemCount, v.itemPrice = p, v.allDiscount = [], v.discount !== h.POINT_DISH_TYPE && (v.discount = null), v.campaignDishes = f.campaignDishes, v.pointDiscountText = f.pointDiscountText, l[m] = {
            groupSort: c[u],
            items: [v]
          }
        }
      }
      var C = [];
      Object.keys(l).forEach((function(t) {
        C.push(l[t])
      })), (C = C.sort((function(t, e) {
        return t.groupSort - e.groupSort
      }))).forEach((function(t) {
        t.items.forEach((function(t) {
          r.push(t)
        }))
      }))
    }));
    var l = null;
    return r.map((function(t, e) {
      var i = t;
      return (i = n.default.set(i, "uiIndex", i.itemNo + e)).discount && i.discount.meetCondition && l && l.discount && l.discount.meetCondition && (i = n.default.setIn(i, ["discount", "preMeetCondition"], !0)), l = i, i
    }))
  }(v, D);
  var E = function(t, e) {
      var i, r = "https://s3plus.meituan.net/v1/mss_61ac5135885c44e59bbaa7e9b2f3282e/rms-marketing/menmber/miniapp/default-avatar.png",
        o = [];
      o = !t || t.length <= 1 ? [{
        avatarUrl: (null == (i = (0, d.getThirdUserInfo)()) ? void 0 : i.headimgurl) || r,
        key: "",
        avatarBorderColor: "transparent"
      }] : t.map((function(t) {
        return {
          avatarUrl: t.avatar || r,
          key: t.uid || "",
          avatarBorderColor: t.color || "transparent"
        }
      }));
      var u = {};
      return t && t.length > 1 && e && Object.keys(e).forEach((function(i) {
        var r = (n.default.getIn(e, [i]) || []).map((function(e) {
          return n.default.getIn(t.filter((function(t) {
            return t.uid === e
          })), [0, "color"]) || ""
        })).filter((function(t) {
          return !!t
        }));
        u[i] = r.map((function(t, e) {
          return {
            backgroundColor: t,
            transform: -4 * e / 7.5
          }
        }))
      })), (0, a.isUnitePage)() && (o = [], e = {}), {
        avatarPicsData: o,
        goodsUserColorInfo: u
      }
    }(C, P),
    y = E.goodsUserColorInfo,
    b = E.avatarPicsData;
  return {
    sortRenderList: D.map((function(t) {
      var i, o = u && u[t.spuId],
        a = null == o ? void 0 : o.skuMenuItems.find((function(e) {
          return e.skuId === t.skuId
        })),
        s = function(t, e) {
          var n = (0, r.getGrouponTip)(t, e),
            i = n.grouponTip,
            o = n.isCouponDish,
            u = [];
          return i && u.push(i), {
            tagList: u,
            isCouponDish: o
          }
        }(t, T),
        d = s.tagList,
        f = s.isCouponDish,
        m = t.campaignDishes,
        g = t.manualCampaigns || [];
      g.length && !m && (m = (0, p.transManualCampaignsToRender)(g, u, t.itemCount));
      var h = (m || []).reduce((function(t, e) {
        return (0, c.plusFloat)(t, e.itemCount || 0)
      }), 0);
      return N = (0, c.plusFloat)(N, h), e(e({}, t), {}, {
        renderTagList: d,
        hiddenDish: (null == o ? void 0 : o.hiddenDish) || !1,
        isCouponDish: f || !1,
        renderWeightDesc: a.canWeight ? "".concat(t.weight, " ").concat(a.unit || "斤") : "",
        renderFullCountDiscountData: I(t.discount),
        renderUserColors: (0, n.default)(y[t.itemNo] || []),
        cartTagList: null == a || null == (i = a.tagList) ? void 0 : i.filter((function(t) {
          return t.colorType === l.LABEL_TYPE.BKG_MT_DISCUONT
        })),
        campaignDishes: m,
        disableModifying: g.length > 0
      })
    })),
    totalInfo: (0, n.default)({
      cartCount: N
    }),
    avatarPicsData: b
  }
}
var C = (0, u.createSelector)([function(t) {
  return n.default.getIn(t, ["cart", "refactorLocalCart", "refactorCartDishMap"])
}, function(t) {
  return n.default.getIn(t, ["dish", "dishList"])
}, function(t) {
  return n.default.getIn(t, ["cart", "cartDishSortMapList"])
}, function(t) {
  return n.default.getIn(t, ["cart", "userInfo"])
}, function(t) {
  return n.default.getIn(t, ["cart", "goodsUserInfo"])
}, function(t) {
  return n.default.getIn(t, ["cart", "promotionMap"])
}, function(t, e) {
  return (null == e ? void 0 : e.shopId) || +(0, a.getMixUrlParam)("shopId") || 0
}, function(t) {
  return n.default.getIn(t, ["extraInfo", "headInfo", "shopConfig", "commonConfig", "showDishRemark"]) || !1
}], (function(t, n, i, r, o, u, a, c) {
  return e({}, v(t, n, i, a, r, o, u, c))
}));
exports.cartViewModelAdapter = C;