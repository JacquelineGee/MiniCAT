var e = require("../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.default = void 0;
var r = e(require("../b/regenerator")),
  t = require("../b/helpers/asyncToGenerator"),
  a = e(require("../lib/mix/request")),
  u = require("../lib/mix/util"),
  i = {
    requestPromotionCalculate: function(e) {
      return t(r.default.mark((function t() {
        var i;
        return r.default.wrap((function(r) {
          for (;;) switch (r.prev = r.next) {
            case 0:
              return i = (0, u.getHost)() + "/diancan/api/", r.abrupt("return", ((0, u.isUnitePage)() && (i = (0, u.getTakeAwayHost)() + "/api/rmstakeaway/"), a.default.post(i + "orderCalculate", e)));
            case 2:
            case "end":
              return r.stop()
          }
        }), t)
      })))()
    }
  };
exports.default = i;