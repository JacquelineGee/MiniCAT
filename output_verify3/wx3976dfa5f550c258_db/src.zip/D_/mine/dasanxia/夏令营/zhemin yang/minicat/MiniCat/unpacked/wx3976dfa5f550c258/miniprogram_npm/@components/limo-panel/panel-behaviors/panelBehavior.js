Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.default = void 0, require("../../../../b/helpers/Objectvalues");
var e = require("../panel-tools/panelEnum"),
  n = Behavior({
    properties: {
      panelVisible: {
        type: Boolean,
        value: !1
      }
    },
    methods: {
      panelBehaviorsPanelBehavior_limoAttached: function() {
        this.registerPanelEvents()
      },
      registerPanelEvents: function() {
        var e = this,
          n = this.getRevokedEvents();
        null == n || n.forEach((function(n) {
          e.registerEvent(n.name, n.callback)
        }))
      },
      getRevokedEvents: function() {
        return []
      },
      openPanel: function(n) {
        n.type && n.panelProps && this.revoke(e.PanelEvents.OPEN_PANEL_EVENT, n)
      },
      closePanel: function(n) {
        n && Object.values(e.PanelType).indexOf(n) > -1 ? this.revoke(e.PanelEvents.CLOSE_PANEL_EVENT, n) : this.revoke(e.PanelEvents.CLOSE_PANEL_EVENT)
      },
      clickPanelMask: function() {
        this.revoke(e.PanelEvents.CLICK_PANEL_MASK)
      },
      closeAllPanel: function() {
        this.revoke(e.PanelEvents.CLOSE_ALL_PANEL)
      }
    }
  });
exports.default = n;