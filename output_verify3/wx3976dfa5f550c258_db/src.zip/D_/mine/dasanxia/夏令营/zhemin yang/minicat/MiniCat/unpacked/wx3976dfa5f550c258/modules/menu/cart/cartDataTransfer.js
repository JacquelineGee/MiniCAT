var t = require("../../../b/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports._transferToRefactorCartDishInfo = m, exports.batchDishWithTempCartDishList = void 0, exports.batchUpdateDish = function(t, e) {
  var r = e.cartDishList,
    a = e.cartDishSortMapList;
  return t.forEach((function(t) {
    var e = t.modifySKuDish;
    if (e) {
      var u = r[e.spuId],
        s = null == u ? void 0 : u.find((function(t) {
          return t.goodsNo === e.itemNo
        })),
        o = null == u ? void 0 : u.findIndex((function(t) {
          return t.goodsNo === e.itemNo
        }));
      if (s) {
        var f = n.default.set(s, "remark", e.remark),
          c = (0, i.getUniqueKey)(f);
        f = n.default.set(f, "goodsNo", c);
        var d = null == u ? void 0 : u.findIndex((function(t) {
            return t.goodsNo === c
          })),
          l = a.findIndex((function(t) {
            return t.goodsNo === e.itemNo
          })),
          p = (0, n.default)({
            spuId: e.spuId,
            goodsNo: c,
            skuId: f.skuId
          });
        if (-1 !== d) {
          f = n.default.merge(f, {
            count: Number(n.default.getIn(u, [d, "count"])) + Number(f.count)
          }), r = n.default.setIn(r, [e.spuId, d], f);
          var h = n.default.flatMap(u, (function(t, e) {
            return e === o ? [] : t
          }));
          r = n.default.set(r, e.spuId, h), a = n.default.flatMap(a, (function(t, e) {
            return e === l ? [] : t
          }))
        } else {
          f = n.default.set(f, "createTime", Date.now());
          var m = n.default.flatMap(u, (function(t, e) {
            return e === o ? f : t
          }));
          r = n.default.set(r, [e.spuId], m), a = (a = n.default.flatMap(a, (function(t, e) {
            return e === l ? [] : t
          }))).concat([p])
        }
      }
    }
  })), {
    cartDishList: r,
    cartDishSortMapList: a
  }
}, exports.filterSameRefactorCartDishInfo = function(t) {
  var r = {};
  Array.isArray(t) && t.forEach((function(t) {
    var e = function(t) {
        var e, r = n.default.asMutable(t, {
          deep: !0
        });
        if (Array.isArray(t.packages) && t.packages.length > 0) {
          var a = [];
          r.packages.forEach((function(t) {
            t.groupSkus.forEach((function(e) {
              var r = {
                groupId: t.groupId,
                skuId: e.skuId,
                number: e.number,
                count: e.count,
                methods: g(e.methods),
                tastes: g(e.tastes)
              };
              a.push(r)
            }))
          })), e = {
            skuId: r.skuId,
            packages: a
          }
        } else {
          var i;
          e = {
            skuId: r.skuId,
            methods: g(r.methods),
            tastes: g(r.tastes)
          }, null != (i = r.manualCampaigns) && i.length && (e.manualCampaigns = (0, l.transManualCampaignsToSimple)(r.manualCampaigns))
        }
        return (0, u.default)(JSON.stringify(e))
      }(t),
      a = r[e] || [];
    a.push(t), r[e] = a
  }));
  var a = function(t, e) {
    return void 0 !== t && void 0 !== e ? t + e : void 0
  };
  return Object.values(r).forEach((function(r) {
    if (Array.isArray(r) && 2 === r.length) {
      var n = e(r, 2),
        u = n[0],
        i = n[1],
        s = a(u.operateCount, i.operateCount),
        o = a(u.operateWeight, i.operateWeight);
      (void 0 !== s && 0 === s || void 0 !== o && 0 === o) && (t = t.filter((function(t) {
        return r.indexOf(t) < 0
      })))
    }
  })), t
}, exports.getPartialCloudCartInfoFromStorage = function(t, e) {
  var r = o.default.getPartialCloudCartInfo(t);
  return "string" == typeof e ? r.tableNum === e ? r : null : Object.keys(r).length > 0 ? r : null
}, exports.mergeNewCartDishInfosAndLeftOperation = void 0, exports.transToLocalCartDishList = v, exports.transferCartDishListToRefactorCartDishMap = function(t) {
  var e = (0, n.default)({});
  return Object.keys(t).forEach((function(r) {
    var a = t[r],
      u = n.default.flatMap(a, (function(t) {
        return m(t)
      }));
    e = n.default.setIn(e, [r], u)
  })), e
}, exports.transferRefactorCartDishMapToCartDishList = function(t, e) {
  var r, a = (0, n.default)([]);
  return null == (r = Object.keys(t)) || r.forEach((function(e) {
    var r = t[e];
    a = a.concat(r)
  })), v(a, e)
}, exports.verifyNewCartDishList = function(t, e, r) {
  var a, u = o.default.getCartDishSortMapList(t, e),
    i = (null == (a = o.default.getRefactorLocalCart(t, e)) ? void 0 : a.refactorCartDishMap) || (0, n.default)({}),
    s = (0, f.verifyCartDish)(r, i, u, !1, !1),
    c = o.default.getInvalidDishes(t);
  if (c) {
    o.default.setInvalidDishes(t, void 0);
    var l = (0, d.handleInvalidDishes)(c, s.cartDishList),
      p = h(l, s),
      m = p.cartDishList,
      v = p.cartDishSortMapList;
    s.cartDishList = m, s.cartDishSortMapList = v
  } else(0, f.handleUnverifyDish)(s.unVerfiedDish, s.promptDishes);
  return s
};
var e = require("../../../b/helpers/slicedToArray");
require("../../../b/helpers/Objectvalues");
var r = require("../../../b/helpers/objectSpread2"),
  a = require("../../../constants/cartConstants"),
  n = t(require("../../../miniprogram_npm/seamless-immutable/index.js")),
  u = t(require("../../../miniprogram_npm/@dp/md5/index.js")),
  i = require("../../operateCartHelper"),
  s = require("../../cartHelper"),
  o = t(require("../../../api/rmsStorage")),
  f = require("./cartDishVerify"),
  c = t(require("../../MustDishSdk")),
  d = require("./cartVerify"),
  l = require("../../campaign"),
  p = require("../../../constants/menu");
var h = function(t, e) {
  return null != t && t.length && t.forEach((function(t) {
    null != t && t.addCount && t.skuDish && (e = function(t, e) {
      var r = t.skuDish;
      if (r && r.soldOut) return e;
      var a = e.cartDishList,
        u = e.cartDishSortMapList;
      r = c.default.updateMustCount(r), r = (0, i.addCloudCartFields)(r);
      var s = (0, i.getUniqueKey)(r);
      if (!(r = n.default.set(r, "goodsNo", s))) return e;
      var o = r.spuId.toString(),
        f = a[o],
        d = (0, n.default)({
          spuId: o,
          goodsNo: s,
          skuId: r.skuId
        });
      if (f) {
        var l = f.findIndex((function(t) {
          return t.goodsNo === s
        }));
        if (-1 !== l) {
          var p = Number(n.default.getIn(f, [l, "count"])) + Number(t.addCount);
          if (p > 0) {
            var h = n.default.merge(r, {
              count: p
            });
            a = n.default.setIn(a, [o, l], h)
          } else {
            var m = n.default.flatMap(f, (function(t, e) {
              return e === l ? [] : t
            }));
            a = n.default.set(a, o, m);
            var v = u.findIndex((function(t) {
              return t.goodsNo === s
            }));
            u = n.default.flatMap(u, (function(t, e) {
              return e === v ? [] : t
            }))
          }
        } else {
          var g = n.default.set(r, "count", t.addCount);
          f = f.concat([g]), a = n.default.set(a, o, f), u = u.concat([d])
        }
      } else r = n.default.merge(r, {
        count: t.addCount,
        createTime: Date.now()
      }), a = n.default.set(a, o, [r]), u = u.concat([d]);
      return {
        cartDishList: a,
        cartDishSortMapList: u
      }
    }(t, e))
  })), e
};
exports.batchDishWithTempCartDishList = h;

function m(t) {
  var e = t.weight,
    r = t.count,
    a = t.allDiscount,
    u = t.itemPrice,
    i = t.extraPrice,
    o = t.allBuyFreeDiscount,
    f = t.userAvatars,
    c = t.manualCampaigns,
    d = t.campaignDishes,
    l = t.pointDiscountText,
    p = t.discount,
    h = (0, s._transferToSimpleCartDishInfo)(t);
  return n.default.merge(h, {
    weight: e,
    count: r,
    allDiscount: a,
    allBuyFreeDiscount: o,
    itemPrice: u,
    extraPrice: i,
    userAvatars: f,
    manualCampaigns: c,
    campaignDishes: d,
    pointDiscountText: l,
    discount: p
  })
}

function v(t, e) {
  var a = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
    u = (0, n.default)({}),
    s = (0, n.default)([]),
    o = (0, n.default)([]);
  return t.map((function(t) {
    var f, c = t.spuId,
      d = e && e[c];
    if (!d || a && !(0, i.isValidDish)(t, d)) return o = o.concat([t]), null;
    var l = n.default.setIn(t, ["remark"], {
      customRemark: t.remark,
      opt: null
    });
    l = (0, i.transToCartDish)(l, d);
    var h = (null == (f = t.discount) ? void 0 : f.toString()) === p.POINT_DISH_TYPE ? (0, i.getUniqueKey)(l, {
        discount: p.POINT_DISH_TYPE
      }) : (0, i.getUniqueKey)(l),
      m = t.discount === p.POINT_DISH_TYPE ? {
        discount: p.POINT_DISH_TYPE,
        campaignId: t.campaignId
      } : {};
    l = n.default.merge(l, {
      goodsNo: h,
      userAvatars: t.userAvatars
    });
    var v = u[c];
    return v = v ? v.concat([l]) : (0, n.default)([l]), u = n.default.set(u, c, v), s = s.concat([r({
      spuId: c,
      skuId: l.skuId,
      goodsNo: l.goodsNo
    }, m)]), null
  })), {
    cartDishList: u,
    cartDishSortMapList: s,
    unVerfiedDish: o
  }
}

function g(t) {
  var e = [];
  return t.length > 0 && t.forEach((function(t) {
    t.items.sort((function(t, e) {
      return Number(t.id) - Number(e.id)
    }));
    var r = [];
    t.items.forEach((function(t) {
      r.push(t.id)
    })), e.push(r)
  })), e
}
exports.mergeNewCartDishInfosAndLeftOperation = function(t, e, r) {
  var u = function(t) {
      return t.length ? t.reduce((function(t, e) {
        return t[e.itemNo || e.skuId] = e, t
      }), {}) : []
    },
    i = u(t);
  e.forEach((function(t) {
    var e = t.operaType,
      s = t.operateCartDishList;
    if (e === a.OPERATE_TYPE.CLEAR_CART) i = u(s);
    else {
      if (e === a.OPERATE_TYPE.MODIFY && s.find((function(t) {
          var e = t.operateWeight,
            a = t.operateCount,
            n = t.spuId,
            u = t.itemNo,
            s = r[n];
          return !s || !!(s.canWeight ? e < 0 : a < 0) && !i[u]
        }))) return;
      s.forEach((function(t) {
        var r = t.operateWeight,
          u = t.operateCount,
          s = t.skuId,
          o = t.itemNo;
        switch (i[o] = i[o] || t, e) {
          case a.OPERATE_TYPE.ADD_MINUS:
          case a.OPERATE_TYPE.MODIFY:
            i[o] = n.default.set(i[o], "count", Number(u || 0) + Number(i[o].count || 0));
            break;
          case a.OPERATE_TYPE.SET:
            i[o] = n.default.set(i[o], "count", Number(u || 0));
            break;
          case a.OPERATE_TYPE.WEIGHT_OP:
            Object.keys(i).forEach((function(t) {
              i[t].skuId === s && (i[t] = null)
            })), i[o] = r ? n.default.set(i[o], "weight", Number(r || 0)) : null
        }
      }))
    }
  }));
  var s = [],
    o = Object.keys(i).filter((function(t) {
      return i[t]
    })).map((function(t) {
      return i[t]
    })).filter((function(t) {
      var e = t.spuId,
        a = t.weight,
        n = t.count,
        u = r[e];
      return u ? u.canWeight ? a > 0 : n > 0 : (s.push(t), !1)
    }));
  return {
    filterDishes: s,
    leftDishes: o
  }
};