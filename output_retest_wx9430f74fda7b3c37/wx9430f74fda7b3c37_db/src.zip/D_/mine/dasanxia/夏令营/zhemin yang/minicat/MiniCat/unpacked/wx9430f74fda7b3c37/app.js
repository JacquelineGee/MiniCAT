App({
  globalData: {
    panelDataMap: {
      t_time: "月份",
      unit: "机组",
      power_supply: "供电量",
      heating_capacity: "供热量",
      coal_consumption: "煤消耗量",
      c_emission: "碳排放",
      c_quota: "碳配额",
      generating_capacity: "发电量",
      steam_turbine_heat_rate: "汽机热耗率",
      emission_ratio: "碳排放/碳配额",
      c_consumption_for_power_supply: "供电煤耗",
      c_emission_intensity_of_power_supply: "供电碳排放强度",
      c_consumption_for_heat: "供热煤耗",
      c_emission_intensity_of_heating: "供热碳排放强度",
      c_extra: "碳盈余",
      elec_consumption: "厂用电量",
      heating_ratio: "供热比",
      running_time: "运行小时数",
      load_factor: "负荷率",
      low_cal: "低位发热量"
    },
    targetInfo: [],
    otherIndex: [],
    userType: "",
    changeIndex: !1,
    nowcEmissionIntensitUnit: {
      "供电碳排放强度": {
        unit5: null,
        unit6: null
      },
      "供热碳排放强度": {
        unit5: null,
        unit6: null
      }
    },
    nowcComsuptionUnit: {
      "供电煤耗": {
        unit5: null,
        unit6: null
      },
      "供热煤耗": {
        unit5: null,
        unit6: null
      }
    },
    nowMoniterDataTotal: {
      "碳排放": null,
      "碳配额": null,
      "碳排放/碳配额": null
    },
    platform: "",
    toptarHeight: 0
  },
  getUpdateManager: function() {
    if (wx.canIUse("getUpdateManager")) {
      var n = wx.getUpdateManager();
      n.onCheckForUpdate((function(n) {
        console.log("是否请求到新版本:" + n.hasUpdate)
      })), n.onUpdateReady((function() {
        wx.showModal({
          title: "更新提示",
          content: "新版本已经准备好，是否重启更新？",
          success: function(t) {
            t.confirm && n.applyUpdate()
          }
        })
      })), n.onUpdateFailed((function() {
        wx.showModal({
          title: "更新提示",
          content: "新版本下载失败，请重试",
          showCancel: !1
        })
      }))
    } else wx.showModal({
      title: "提示",
      content: "当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。"
    })
  },
  onLaunch: function() {
    this.getUpdateManager()
  },
  watch: function(n, t) {
    var e = this;
    Object.keys(t).forEach((function(o) {
      e.observer(n.data, o, n.data[o], (function(e) {
        t[o].call(n, e)
      }))
    }))
  },
  observer: function(n, t, e, o) {
    Object.defineProperty(n, t, {
      configurable: !0,
      enumerable: !0,
      get: function() {
        return e
      },
      set: function(n) {
        n !== e && (o && o(n), e = n)
      }
    })
  },
  onShow: function(n) {},
  onHide: function() {},
  onError: function(n) {}
});