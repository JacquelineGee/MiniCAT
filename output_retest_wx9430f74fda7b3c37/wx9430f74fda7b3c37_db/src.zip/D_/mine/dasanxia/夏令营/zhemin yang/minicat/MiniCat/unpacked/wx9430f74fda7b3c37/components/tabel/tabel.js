Component({
  properties: {
    columnNames: {
      type: Array,
      value: []
    },
    tableData: {
      type: Array,
      value: []
    },
    noDataMsg: {
      type: String,
      value: "无"
    },
    stripe: {
      type: Boolean,
      value: !0
    },
    borderline: {
      type: Boolean,
      value: !1
    },
    headerBackground: {
      type: String,
      value: "#2d66cf"
    }
  },
  data: {
    minWidth: 40,
    headerHeight: 50,
    headerScrollLeft: 0
  },
  methods: {
    calcMinWidth: function(e) {
      for (var t = -1, a = 0; a < e.length; a++) e[a].length > t && (t = e[a].length);
      return 10 + 15 * t
    },
    syncScroll: function(e) {
      var t = e.detail.scrollLeft;
      this.setData({
        headerScrollLeft: t
      })
    },
    onCellTap: function(e) {
      this.triggerEvent("celltap", e.currentTarget.dataset)
    }
  },
  ready: function() {
    var e = this.calcMinWidth(this.data.columnNames);
    this.setData({
      minWidth: e
    })
  }
});