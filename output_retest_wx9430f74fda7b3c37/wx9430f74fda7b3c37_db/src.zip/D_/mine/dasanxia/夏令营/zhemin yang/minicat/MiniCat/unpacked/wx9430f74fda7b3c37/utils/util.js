Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.interpolationData = exports.formatTime = void 0;
exports.formatTime = function(e) {
  var o = e.getFullYear(),
    n = e.getMonth() + 1,
    r = e.getDate(),
    a = e.getHours(),
    i = e.getMinutes(),
    c = e.getSeconds();
  return "".concat([o, n, r].map(t).join("/"), " ").concat([a, i, c].map(t).join(":"))
};
var t = function(t) {
  return (t = t.toString())[1] ? t : "0".concat(t)
};
exports.interpolationData = function(t) {
  return t.forEach((function(e, o) {
    null == e && (t[o] = 0)
  })), t
};