var M = require("../../@babel/runtime/helpers/interopRequireWildcard"),
  t = require("../../@babel/runtime/helpers/interopRequireDefault"),
  e = require("../../@babel/runtime/helpers/slicedToArray"),
  i = require("../../@babel/runtime/helpers/objectSpread2"),
  a = t(require("../../@babel/runtime/regenerator")),
  n = require("../../@babel/runtime/helpers/asyncToGenerator"),
  N = require("../../utils/request"),
  j = require("../../utils/util"),
  u = M(require("../../components/ec-canvas/echarts")),
  D = getApp();
Page({
  data: {
    totalEmissionChart: {
      lazyLoad: !0
    },
    currentTab: 0,
    dailyBarChart: {
      lazyLoad: !0
    },
    monthlyBarChart: {
      lazyLoad: !0
    },
    yearlyBarChart: {
      lazyLoad: !0
    },
    barChartData: {
      daily: [],
      monthly: [],
      yearly: []
    },
    lineChartData: {
      daily: [],
      monthly: [],
      yearly: []
    },
    commonOption: {
      grid: [{
        containLabel: !0,
        top: "10%",
        right: "2%",
        height: "40%",
        left: "2%"
      }, {
        containLabel: !0,
        top: "60%",
        right: "2%",
        height: "40%",
        left: "2%"
      }],
      yAxis: {
        nameTextStyle: {
          color: "rgba(0, 0, 0, 1)",
          fontFamily: "Microsoft YaHei",
          fontWeight: "600",
          fontSize: 12
        },
        axisLabel: {
          color: "#09163733",
          fontSize: ".75rem"
        },
        splitLine: {
          lineStyle: {
            color: "rgba(223, 223, 223, 1)",
            type: "dashed"
          }
        }
      }
    },
    warningImg: {
      1: "PHN2ZyB3aWR0aD0iNDgiIGhlaWdodD0iMjAiIHZpZXdCb3g9IjAgMCA0OCAyMCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxnIGNsaXAtcGF0aD0idXJsKCNjbGlwMF80NDJfNDY4KSI+DQo8cGF0aCBkPSJNNCAwSDQ0TDQ4IDVIMEw0IDBaIiBmaWxsPSIjOUEyMjJDIi8+DQo8cGF0aCBkPSJNNCAwSDQ0VjE4QzQ0IDE5LjEwNDYgNDMuMTA0NiAyMCA0MiAyMEg2QzQuODk1NDMgMjAgNCAxOS4xMDQ2IDQgMThWMFoiIGZpbGw9IiNGRjRENUQiLz4NCjxwYXRoIGQ9Ik0xNS40MiA0LjE4NEgxNi42NTZWOC41NzZIMTUuNDJWNC4xODRaTTEzLjIyNCA0LjcxMkgxNC40MzZWOC4yNzZIMTMuMjI0VjQuNzEyWk0xNy42NjQgNS42NDhIMTcuMjMyVjQuNTJIMjIuNjA4VjUuNTc2QzIyLjM1NiA2LjIyNCAyMS44NzYgNi43ODggMjEuMTY4IDcuMjQ0QzIxLjc1NiA3LjQ3MiAyMi40MjggNy42NzYgMjMuMTk2IDcuODU2TDIyLjUyNCA4LjkyNEMyMS41MDQgOC42IDIwLjY0IDguMjQgMTkuOTQ0IDcuODU2QzE5LjM0NCA4LjA4NCAxOC42NzIgOC4yNzYgMTcuOTE2IDguNDQ0TDE4LjQ4IDguODY0QzE3Ljg4IDkuMjcyIDE3LjI1NiA5LjYzMiAxNi42MDggOS45NDRMMTguNjg0IDkuODI0QzE5LjE0IDkuNTcyIDE5LjYwOCA5LjMwOCAyMC4wNzYgOS4wMzJMMjEuMTMyIDkuNzI4QzE5Ljc4OCAxMC40OTYgMTguMyAxMS4xNDQgMTYuNjY4IDExLjY0OEMxOC4wNzIgMTEuNTg4IDE5LjQ1MiAxMS41MTYgMjAuODA4IDExLjQzMkMyMC41OTIgMTEuMjE2IDIwLjM2NCAxMSAyMC4xMzYgMTAuNzk2TDIxLjEwOCAxMC4xOTZDMjIuMDQ0IDExLjAxMiAyMi43NTIgMTEuNzMyIDIzLjI1NiAxMi4zMzJMMjIuMjQ4IDEzLjAxNkMyMi4wNDQgMTIuNzUyIDIxLjgyOCAxMi41IDIxLjU4OCAxMi4yMzZDMjAuNTggMTIuMzA4IDE5LjYwOCAxMi4zNjggMTguNjg0IDEyLjQxNlYxNC4wNzJDMTguNjg0IDE0LjgyOCAxOC4zIDE1LjIxMiAxNy41NDQgMTUuMjEySDE2LjQxNkwxNi4xNTIgMTQuMDM2QzE2LjQ4OCAxNC4wODQgMTYuODEyIDE0LjEyIDE3LjEyNCAxNC4xMkMxNy4zMTYgMTQuMTIgMTcuNDEyIDE0IDE3LjQxMiAxMy43NzJWMTIuNDg4QzE1Ljk3MiAxMi41NiAxNC42MTYgMTIuNjA4IDEzLjM2OCAxMi42NTZMMTMuMTE2IDExLjU0QzEzLjQ3NiAxMS41NjQgMTMuODM2IDExLjU3NiAxNC4xOTYgMTEuNTc2QzE1LjA2IDExLjM4NCAxNS45NzIgMTEuMDg0IDE2LjkzMiAxMC42NzZDMTYuMDA4IDEwLjcyNCAxNS4wOTYgMTAuNzcyIDE0LjE5NiAxMC44MzJMMTMuOTggOS43ODhDMTQuNTA4IDkuNzg4IDE0Ljg5MiA5Ljc0IDE1LjEwOCA5LjY1NkMxNS44MTYgOS4zMiAxNi41NiA4Ljg2NCAxNy4zNCA4LjMxMkwxNi45MDggNy41MkMxNy42MjggNy40IDE4LjI2NCA3LjI1NiAxOC44MTYgNy4wODhDMTguMjg4IDYuNjMyIDE3LjkwNCA2LjE1MiAxNy42NjQgNS42NDhaTTE5Ljk0NCA2LjY1NkMyMC41NjggNi4zNjggMjEuMDI0IDYuMDMyIDIxLjMzNiA1LjY0OEgxOC43OTJDMTkuMDU2IDYuMDIgMTkuNDQgNi4zNTYgMTkuOTQ0IDYuNjU2Wk0xOS44NDggMTIuNjkyQzIxLjA5NiAxMy4wNjQgMjIuMjM2IDEzLjUyIDIzLjI2OCAxNC4wNDhMMjIuNjA4IDE1LjEwNEMyMS41MTYgMTQuNDY4IDIwLjM4OCAxMy45NzYgMTkuMjM2IDEzLjYxNkwxOS44NDggMTIuNjkyWk0xNS44ODggMTIuNzE2TDE2LjYzMiAxMy41NTZDMTUuNjk2IDE0LjE1NiAxNC41NDQgMTQuNjQ4IDEzLjE3NiAxNS4wNTZMMTIuNjM2IDEzLjkyOEMxMy45NTYgMTMuNjE2IDE1LjAzNiAxMy4yMDggMTUuODg4IDEyLjcxNlpNMzMuOTI0IDExLjI4OEgyNS45MlYxMC4xODRIMzIuNzEyVjkuNTcySDI2LjM3NlY4LjUxNkgzMi43MTJWNy45MDRIMjUuOTY4QzI1Ljc0IDguMDcyIDI1LjUxMiA4LjIyOCAyNS4yNzIgOC4zODRMMjQuNDggNy40MjRDMjUuODQ4IDYuNjA4IDI3LjAzNiA1LjQ2OCAyOC4wNTYgMy45OTJMMjkuMzE2IDQuMjhDMjkuMTcyIDQuNDg0IDI5LjA0IDQuNjc2IDI4LjkyIDQuODY4SDMyLjU5MlY1LjcyQzMyLjI5MiA2LjEyOCAzMS45OTIgNi40ODggMzEuNzA0IDYuOEgzMy45MjRWMTEuMjg4Wk0zMC4xOCA2LjhDMzAuNDY4IDYuNTM2IDMwLjc1NiA2LjIzNiAzMS4wNTYgNS45SDI4LjExNkMyNy44NCA2LjIxMiAyNy41NjQgNi41MTIgMjcuMjc2IDYuOEgzMC4xOFpNMjUuNzY0IDExLjgwNEwyNi45ODggMTIuMDU2QzI2LjY3NiAxMy4xNiAyNi4yNDQgMTQuMTIgMjUuNjggMTQuOTM2TDI0LjYgMTQuMjUyQzI1LjE1MiAxMy40ODQgMjUuNTM2IDEyLjY2OCAyNS43NjQgMTEuODA0Wk0zMS42OCAxNS4wOTJIMjguNzY0QzI3LjkyNCAxNS4wOTIgMjcuNTA0IDE0LjY2IDI3LjUwNCAxMy44MlYxMS43NDRIMjguNzUyVjEzLjU0NEMyOC43NTIgMTMuODMyIDI4Ljg3MiAxMy45NzYgMjkuMTI0IDEzLjk3NkgzMS40NTJDMzEuNjQ0IDEzLjk3NiAzMS43ODggMTMuOTE2IDMxLjg4NCAxMy44MkMzMi4wMDQgMTMuNyAzMi4wNzYgMTMuMzI4IDMyLjExMiAxMi43MTZMMzMuMyAxMy4xMTJDMzMuMjA0IDE0LjA3MiAzMy4wMjQgMTQuNjQ4IDMyLjc2IDE0Ljg0QzMyLjUyIDE1LjAwOCAzMi4xNiAxNS4wOTIgMzEuNjggMTUuMDkyWk0zMC4zNiAxMS4zNkMzMC45MTIgMTEuOTEyIDMxLjM0NCAxMi40MDQgMzEuNjQ0IDEyLjgxMkwzMC42IDEzLjUzMkMzMC4yODggMTMuMDc2IDI5Ljg2OCAxMi41NiAyOS4zMjggMTEuOTk2TDMwLjM2IDExLjM2Wk0zMy45IDExLjUxNkMzNC42MiAxMi40NzYgMzUuMTg0IDEzLjMyOCAzNS41OCAxNC4wNDhMMzQuNTM2IDE0Ljc4QzM0LjEyOCAxMy45ODggMzMuNTg4IDEzLjExMiAzMi44OTIgMTIuMTUyTDMzLjkgMTEuNTE2WiIgZmlsbD0id2hpdGUiLz4NCjwvZz4NCjxkZWZzPg0KPGNsaXBQYXRoIGlkPSJjbGlwMF80NDJfNDY4Ij4NCjxyZWN0IHdpZHRoPSI0OCIgaGVpZ2h0PSIyMCIgZmlsbD0id2hpdGUiLz4NCjwvY2xpcFBhdGg+DQo8L2RlZnM+DQo8L3N2Zz4NCg==",
      2: "PHN2ZyB3aWR0aD0iNDgiIGhlaWdodD0iMjAiIHZpZXdCb3g9IjAgMCA0OCAyMCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxnIGNsaXAtcGF0aD0idXJsKCNjbGlwMF8zODZfOTM1KSI+DQo8cGF0aCBkPSJNNCAwSDQ0TDQ4IDVIMEw0IDBaIiBmaWxsPSIjMDU0OThGIi8+DQo8cGF0aCBkPSJNNCAwSDQ0VjE4QzQ0IDE5LjEwNDYgNDMuMTA0NiAyMCA0MiAyMEg2QzQuODk1NDMgMjAgNCAxOS4xMDQ2IDQgMThWMFoiIGZpbGw9IiMwNTc1RTYiLz4NCjxwYXRoIGQ9Ik0xMy45NjggMTUuMTRIMTIuOTEyTDEyLjYzNiAxMy45MjhDMTIuOTQ4IDEzLjk3NiAxMy4yNDggMTQgMTMuNTM2IDE0QzEzLjggMTQgMTMuOTMyIDEzLjg1NiAxMy45MzIgMTMuNTkyVjExLjE4QzEzLjU0OCAxMS4zMjQgMTMuMTUyIDExLjQ2OCAxMi43NDQgMTEuNkwxMi40MzIgMTAuMzI4QzEyLjkzNiAxMC4yMDggMTMuNDQgMTAuMDY0IDEzLjkzMiA5Ljg5NlY3LjUySDEyLjYyNFY2LjMwOEgxMy45MzJWNC4xODRIMTUuMjA0VjYuMzA4SDE2LjI3MlY3LjUySDE1LjIwNFY5LjM2OEMxNS40OTIgOS4yMjQgMTUuNzggOS4wNjggMTYuMDY4IDguOTI0VjEwLjE5NkwxNS4yMDQgMTAuNjI4VjEzLjkxNkMxNS4yMDQgMTQuNzMyIDE0Ljc4NCAxNS4xNCAxMy45NjggMTUuMTRaTTE3LjA1MiA0LjUwOEgyMi41VjguODg4SDE3LjA1MlY0LjUwOFpNMjEuMjc2IDcuODhWNy4xNkgxOC4yNjRWNy44OEgyMS4yNzZaTTE4LjI2NCA2LjIyNEgyMS4yNzZWNS41MTZIMTguMjY0VjYuMjI0Wk0xNi4yODQgOS40NEgyMy4yMDhWMTAuNTU2SDIwLjM3NlYxMS41NTJIMjIuNjY4VjEyLjY1NkgyMC4zNzZWMTMuODJDMjAuODA4IDEzLjg2OCAyMS4zIDEzLjkwNCAyMS44NjQgMTMuOTA0QzIyLjUyNCAxMy45MDQgMjMuMDg4IDEzLjg2OCAyMy41NDQgMTMuODJMMjMuMTk2IDE1LjAzMkMyMi43NCAxNS4wMzIgMjIuMzIgMTUuMDIgMjEuOTQ4IDE1LjAwOEMyMC4zNCAxNC45OTYgMTkuMjQ4IDE0Ljg1MiAxOC42NDggMTQuNTY0QzE4LjI0IDE0LjM2IDE3Ljg4IDE0IDE3LjU0NCAxMy40ODRDMTcuMjggMTQuMTA4IDE2Ljk0NCAxNC42OTYgMTYuNTI0IDE1LjI0OEwxNS41ODggMTQuNDMyQzE2LjQyOCAxMy4zNzYgMTYuODk2IDEyLjIgMTYuOTkyIDEwLjkwNEwxOC4wOTYgMTEuMDM2QzE4LjA3MiAxMS40NjggMTguMDEyIDExLjg3NiAxNy45MjggMTIuMjZDMTguMjg4IDEyLjkwOCAxOC42ODQgMTMuMzI4IDE5LjE0IDEzLjUyQzE5LjE0IDEzLjUyIDE5LjE1MiAxMy41MzIgMTkuMTY0IDEzLjUzMlYxMC41NTZIMTYuMjg0VjkuNDRaTTI5LjMyOCAxNS4xMDRIMjcuNzhMMjcuNTE2IDEzLjg5MkMyNy45OTYgMTMuOTQgMjguNDY0IDEzLjk2NCAyOC44OTYgMTMuOTY0QzI5LjIyIDEzLjk2NCAyOS4zODggMTMuODA4IDI5LjM4OCAxMy41MDhWOC45MjRIMjQuODI4VjcuNjg4SDM1LjE3MlY4LjkyNEgzMC42NlYxMy44MzJDMzAuNjYgMTQuNjcyIDMwLjIxNiAxNS4xMDQgMjkuMzI4IDE1LjEwNFpNMjYuNTIgMTAuMDI4TDI3Ljc1NiAxMC4zMDRDMjcuMjc2IDExLjk2IDI2LjU4IDEzLjQgMjUuNjkyIDE0LjZMMjQuNiAxMy45MTZDMjUuNTEyIDEyLjY5MiAyNi4xNDggMTEuMzk2IDI2LjUyIDEwLjAyOFpNMzMuMjc2IDkuODcyQzM0LjA4IDExLjE1NiAzNC43NzYgMTIuNTI0IDM1LjM1MiAxMy45ODhMMzQuMjEyIDE0LjUwNEMzMy41ODggMTIuODk2IDMyLjg5MiAxMS40OCAzMi4xNDggMTAuMjU2TDMzLjI3NiA5Ljg3MlpNMjUuOTMyIDQuNjY0SDM0LjEwNFY1Ljg4OEgyNS45MzJWNC42NjRaIiBmaWxsPSJ3aGl0ZSIvPg0KPC9nPg0KPGRlZnM+DQo8Y2xpcFBhdGggaWQ9ImNsaXAwXzM4Nl85MzUiPg0KPHJlY3Qgd2lkdGg9IjQ4IiBoZWlnaHQ9IjIwIiBmaWxsPSJ3aGl0ZSIvPg0KPC9jbGlwUGF0aD4NCjwvZGVmcz4NCjwvc3ZnPg0K",
      3: "PHN2ZyB3aWR0aD0iNDgiIGhlaWdodD0iMjAiIHZpZXdCb3g9IjAgMCA0OCAyMCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxnIGNsaXAtcGF0aD0idXJsKCNjbGlwMF8zODZfOTUwKSI+DQo8cGF0aCBkPSJNNCAwSDQ0TDQ4IDVIMEw0IDBaIiBmaWxsPSIjOTY2QTE1Ii8+DQo8cGF0aCBkPSJNNCAwSDQ0VjE4QzQ0IDE5LjEwNDYgNDMuMTA0NiAyMCA0MiAyMEg2QzQuODk1NDMgMjAgNCAxOS4xMDQ2IDQgMThWMFoiIGZpbGw9IiNGRkFBMDUiLz4NCjxwYXRoIGQ9Ik0xMy42OTIgNy42MjhIMTcuMzUyVjcuMTEySDEyLjgwNFY2LjA1NkgxNy4zNTJWNS40OEMxNi4yMTIgNS41MjggMTUuMDI0IDUuNTc2IDEzLjc3NiA1LjYyNEwxMy41NzIgNC42MjhDMTYuNjggNC41NDQgMTkuNDUyIDQuMzg4IDIxLjg3NiA0LjE0OEwyMi4yNDggNS4xNTZDMjEuMTIgNS4yNTIgMTkuODk2IDUuMzM2IDE4LjYgNS40MDhWNi4wNTZIMjMuMTcyVjcuMTEySDE4LjZWNy42MjhIMjIuMjcyVjExLjgwNEgxOC42VjEyLjM2OEgyMi43NTJWMTMuMzUySDE4LjZWMTMuOTRIMjMuMzUyVjE1LjAwOEgxMi42NDhWMTMuOTRIMTcuMzUyVjEzLjM1MkgxMy4yNDhWMTIuMzY4SDE3LjM1MlYxMS44MDRIMTMuNjkyVjcuNjI4Wk0yMS4wNiAxMC44MlYxMC4xNzJIMTguNlYxMC44MkgyMS4wNlpNMTcuMzUyIDEwLjgyVjEwLjE3MkgxNC45MDRWMTAuODJIMTcuMzUyWk0xNC45MDQgOS4yMzZIMTcuMzUyVjguNjEySDE0LjkwNFY5LjIzNlpNMTguNiA4LjYxMlY5LjIzNkgyMS4wNlY4LjYxMkgxOC42Wk0yNC42NDggNC41MkgzNS4zNTJWNS42NDhIMzEuOTQ0VjYuNDRIMzQuNjQ0VjkuNjhIMjkuNzZMMjkuMzI4IDEwLjQzNkgzNS40OTZWMTEuNTg4SDMzLjAxMkMzMi43ODQgMTIuMTg4IDMyLjQxMiAxMi43MDQgMzEuOTA4IDEzLjE2QzMzLjAzNiAxMy40OTYgMzQuMTc2IDEzLjg4IDM1LjM1MiAxNC4zMjRMMzQuNTcyIDE1LjM1NkMzMy4zMTIgMTQuODI4IDMyLjA1MiAxNC4zNDggMzAuNzkyIDEzLjk0QzI5LjY2NCAxNC41MTYgMjcuODI4IDE0Ljk3MiAyNS4yNiAxNS4zMkwyNC43OTIgMTQuMTkyQzI2LjYxNiAxNCAyOC4wNDQgMTMuNzM2IDI5LjEgMTMuNDEyQzI4LjIgMTMuMTQ4IDI3LjMxMiAxMi45MiAyNi40MjQgMTIuNzE2QzI2LjY4OCAxMi4zMzIgMjYuOTQgMTEuOTYgMjcuMTggMTEuNTg4SDI0LjQ5MlYxMC40MzZIMjcuOUMyOC4wNDQgMTAuMTcyIDI4LjIgOS45MiAyOC4zNDQgOS42OEgyNS4zNTZWNi40NEgyOC4wNTZWNS42NDhIMjQuNjQ4VjQuNTJaTTMwLjU2NCAxMi43NzZDMzEuMDkyIDEyLjQ0IDMxLjQ3NiAxMi4wNDQgMzEuNzE2IDExLjU4OEgyOC42MkMyOC40NjQgMTEuODE2IDI4LjMyIDEyLjAyIDI4LjIgMTIuMjEyQzI4Ljk2OCAxMi4zNjggMjkuNzYgMTIuNTYgMzAuNTY0IDEyLjc3NlpNMzAuNzU2IDYuNDRWNS42NDhIMjkuMjQ0VjYuNDRIMzAuNzU2Wk0zMy40NDQgOC42MjRWNy40OTZIMzEuOTQ0VjguNjI0SDMzLjQ0NFpNMzAuNzU2IDguNjI0VjcuNDk2SDI5LjI0NFY4LjYyNEgzMC43NTZaTTI4LjA1NiA4LjYyNFY3LjQ5NkgyNi41NTZWOC42MjRIMjguMDU2WiIgZmlsbD0id2hpdGUiLz4NCjwvZz4NCjxkZWZzPg0KPGNsaXBQYXRoIGlkPSJjbGlwMF8zODZfOTUwIj4NCjxyZWN0IHdpZHRoPSI0OCIgaGVpZ2h0PSIyMCIgZmlsbD0id2hpdGUiLz4NCjwvY2xpcFBhdGg+DQo8L2RlZnM+DQo8L3N2Zz4NCg=="
    },
    toptarHeight: 0,
    topNoticeText: "",
    reportData: {},
    quotaData: {},
    quotaUsed: 0,
    analysisData: [],
    carbonConstituents: {},
    powerReference: 0,
    heatingReference: 0,
    warningCell: [],
    unprocessedWarningCount: 0
  },
  getAnnouncement: function() {
    var M = this;
    return n(a.default.mark((function t() {
      var e;
      return a.default.wrap((function(t) {
        for (;;) switch (t.prev = t.next) {
          case 0:
            return t.prev = 0, t.next = 3, (0, N.requestService)("/management/home/getAnnouncement");
          case 3:
            e = t.sent, M.setData({
              topNoticeText: e[0].title
            }), t.next = 10;
            break;
          case 7:
            t.prev = 7, t.t0 = t.catch(0), console.error(t.t0);
          case 10:
          case "end":
            return t.stop()
        }
      }), t, null, [
        [0, 7]
      ])
    })))()
  },
  getDataBriefing: function() {
    var M = this;
    return n(a.default.mark((function t() {
      var e;
      return a.default.wrap((function(t) {
        for (;;) switch (t.prev = t.next) {
          case 0:
            return t.prev = 0, t.next = 3, (0, N.requestService)("/management/home/dataBriefing");
          case 3:
            (e = t.sent).powerGrowth = parseFloat(e.powerGrowth.toFixed(2)), e.emissionGrowth = parseFloat(e.emissionGrowth.toFixed(2)), e.heatGrowth = parseFloat(e.heatGrowth.toFixed(2)), M.setData({
              reportData: e
            }), t.next = 13;
            break;
          case 10:
            t.prev = 10, t.t0 = t.catch(0), console.error(t.t0);
          case 13:
          case "end":
            return t.stop()
        }
      }), t, null, [
        [0, 10]
      ])
    })))()
  },
  getCarbonQuota: function() {
    var M = this;
    return n(a.default.mark((function t() {
      var e;
      return a.default.wrap((function(t) {
        for (;;) switch (t.prev = t.next) {
          case 0:
            return t.prev = 0, t.next = 3, (0, N.requestService)("/asset/intellectualProperty/carbonIntellectualProperty");
          case 3:
            e = t.sent, M.setData({
              quotaData: e,
              quotaUsed: 100 - (e.carbonBalance / (0 == e.allocatedQuota ? 1 : e.allocatedQuota) * 100).toFixed(2)
            }), t.next = 10;
            break;
          case 7:
            t.prev = 7, t.t0 = t.catch(0), console.error(t.t0);
          case 10:
          case "end":
            return t.stop()
        }
      }), t, null, [
        [0, 7]
      ])
    })))()
  },
  getCurrentMonthRange: function() {
    var M = new Date,
      t = M.getFullYear().toString(),
      e = M.getMonth() + 1 < 10 ? "0" + (M.getMonth() + 1).toString() : (M.getMonth() + 1).toString(),
      i = new Date(M.getFullYear(), e, 0).getDate();
    return i.toString(), [t + "-01", t + "-" + e]
  },
  formatDate: function(M) {
    var t = M.getFullYear(),
      e = ("0" + (M.getMonth() + 1)).slice(-2),
      i = ("0" + M.getDate()).slice(-2);
    return "".concat(t, "-").concat(e, "-").concat(i)
  },
  getCarbonAnalysis: function(M) {
    var t = this;
    return n(a.default.mark((function e() {
      var n, j, u;
      return a.default.wrap((function(e) {
        for (;;) switch (e.prev = e.next) {
          case 0:
            return n = {}, "hour" == M ? n.startDate = t.formatDate(new Date) : "daily" == M ? (n.endDate = t.formatDate(new Date), n.startDate = t.formatDate(new Date((new Date).getFullYear(), (new Date).getMonth(), 1))) : (j = t.getCurrentMonthRange(), n.startDate = j[0], n.endDate = j[1]), e.prev = 2, e.next = 5, (0, N.requestService)("/management/home/carbonAnalysis", i({
              type: M
            }, n));
          case 5:
            u = e.sent, t.setData({
              analysisData: u.analysis,
              powerReference: u.powerReference,
              heatingReference: u.heatingReference
            }), e.next = 12;
            break;
          case 9:
            e.prev = 9, e.t0 = e.catch(2), console.error(e.t0);
          case 12:
          case "end":
            return e.stop()
        }
      }), e, null, [
        [2, 9]
      ])
    })))()
  },
  getWarningInfo: function() {
    var M = this;
    return n(a.default.mark((function t() {
      var e, i;
      return a.default.wrap((function(t) {
        for (;;) switch (t.prev = t.next) {
          case 0:
            return t.prev = 0, t.next = 3, (0, N.requestService)("/management/workOrder/list", {
              orderStatus: 1
            });
          case 3:
            e = t.sent, M.setData({
              warningCell: e.rows
            }), i = e.total, M.setData({
              unprocessedWarningCount: i
            }), wx.setTabBarBadge({
              index: 2,
              text: i > 0 ? i.toString() : ""
            }), t.next = 13;
            break;
          case 10:
            t.prev = 10, t.t0 = t.catch(0), console.error(t.t0);
          case 13:
          case "end":
            return t.stop()
        }
      }), t, null, [
        [0, 10]
      ])
    })))()
  },
  onLoad: function(M) {
    this.setData({
      toptarHeight: D.globalData.toptarHeight
    }), this.fetchGaugeChartData(), this.getAnnouncement(), this.getCarbonQuota(), this.getCarbonAnalysis(), this.getWarningInfo(), this.initChart(this.data.currentTab)
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {},
  onPageScroll: function(M) {
    var t = this.selectComponent("#customComponent");
    t && t.handleScroll(M)
  },
  fetchGaugeChartData: function() {
    var M = this;
    return n(a.default.mark((function t() {
      var e, i;
      return a.default.wrap((function(t) {
        for (;;) switch (t.prev = t.next) {
          case 0:
            return t.next = 2, M.getDataBriefing();
          case 2:
            e = M.data.reportData, i = {
              series: [{
                type: "gauge",
                startAngle: 180,
                endAngle: 0,
                min: 0,
                max: 1002556,
                splitNumber: 12,
                center: ["50%", "65%"],
                radius: "85%",
                itemStyle: {
                  color: "rgba(1, 148, 68, 1)",
                  shadowColor: "rgba(1, 148, 68, 1)",
                  shadowBlur: 5,
                  shadowOffsetX: 2,
                  shadowOffsetY: 2
                },
                progress: {
                  show: !0,
                  roundCap: !0,
                  width: 10
                },
                pointer: {
                  show: !1
                },
                axisLine: {
                  roundCap: !0,
                  lineStyle: {
                    width: 10
                  }
                },
                axisTick: {
                  show: !1
                },
                splitLine: {
                  show: !1
                },
                axisLabel: {
                  show: !1
                },
                title: {
                  offsetCenter: [0, "-10%"],
                  fontSize: 10,
                  color: "gray"
                },
                detail: {
                  fontSize: 10,
                  offsetCenter: [0, "-35%"],
                  valueAnimation: !0,
                  formatter: function(M) {
                    return Math.round(1 * M) + ""
                  },
                  color: "rgba(9, 22, 55, 1)"
                },
                data: [{
                  value: e.totalEmission,
                  name: "tCO₂"
                }]
              }]
            }, M.ecComponent = M.selectComponent("#totalEmissionChart"), M.ecComponent.init((function(t, e, a, n, N) {
              var j = u.init(t, null, {
                width: e,
                height: a,
                devicePixelRatio: N
              });
              return t.setChart(j), M.hideTooltip(j), M.chart = j, j.setOption(i), j
            }));
          case 6:
          case "end":
            return t.stop()
        }
      }), t)
    })))()
  },
  hideTooltip: function(M) {
    M.getZr().on("mouseup", (function(t) {
      M.dispatchAction({
        type: "hideTip"
      }), M.dispatchAction({
        type: "updateAxisPointer",
        currTrigger: "leave"
      })
    }))
  },
  switchTab: function(M) {
    var t = M.detail.index;
    this.setData({
      currentTab: t
    }), this.initChart(t)
  },
  initChart: function(M) {
    var t = this;
    return n(a.default.mark((function e() {
      return a.default.wrap((function(e) {
        for (;;) switch (e.prev = e.next) {
          case 0:
            e.t0 = M, e.next = 0 === e.t0 ? 3 : 1 === e.t0 ? 7 : 2 === e.t0 ? 11 : 15;
            break;
          case 3:
            return e.next = 5, t.getCarbonAnalysis("hour");
          case 5:
            return t.initDailyChart(t.data.analysisData), e.abrupt("break", 16);
          case 7:
            return e.next = 9, t.getCarbonAnalysis("daily");
          case 9:
            return t.initMonthlyChart(t.data.analysisData), e.abrupt("break", 16);
          case 11:
            return e.next = 13, t.getCarbonAnalysis("month");
          case 13:
            return t.initYearlyChart(t.data.analysisData), e.abrupt("break", 16);
          case 15:
            console.error("Unknown tab index:", M);
          case 16:
          case "end":
            return e.stop()
        }
      }), e)
    })))()
  },
  initDailyChart: function(M) {
    var t = this,
      e = this.dataProcess(M);
    this.selectComponent("#dailyBarChart").init((function(M, i, a, n, N) {
      var j = u.init(M, null, {
        width: i,
        height: a,
        devicePixelRatio: N
      });
      M.setChart(j);
      var D = t.getBarChartOption(e);
      return j.setOption(D), j
    }))
  },
  initMonthlyChart: function(M) {
    var t = this,
      e = this.dataProcess(M);
    this.selectComponent("#monthlyBarChart").init((function(M, i, a, n, N) {
      var j = u.init(M, null, {
        width: i,
        height: a,
        devicePixelRatio: N
      });
      M.setChart(j);
      var D = t.getBarChartOption(e);
      return j.setOption(D), j
    }))
  },
  initYearlyChart: function(M) {
    var t = this,
      e = this.dataProcess(M);
    this.selectComponent("#yearlyBarChart").init((function(M, i, a, n, N) {
      var j = u.init(M, null, {
        width: i,
        height: a,
        devicePixelRatio: N
      });
      M.setChart(j);
      var D = t.getBarChartOption(e);
      return j.setOption(D), j.dispatchAction({
        type: "updateAxisPointer",
        currTrigger: "leave"
      }), j
    }))
  },
  dataProcess: function(M) {
    var t = this,
      i = {
        date: [],
        totalEmission: [],
        heatIntensity: [],
        powerIntensity: []
      };
    return M.forEach((function(M) {
      if (0 == t.data.currentTab) {
        var a = M.date.split(" "),
          n = e(a, 2),
          N = (n[0], n[1]);
        i.date.push(N)
      } else i.date.push(M.date);
      i.totalEmission.push(M.totalEmission), i.heatIntensity.push(M.heatIntensity), i.powerIntensity.push(M.powerIntensity)
    })), i
  },
  getBarChartOption: function(M) {
    var t = ["#0575E6", "#FB4B4B", "#FFAA05"],
      e = this.data.commonOption.yAxis,
      a = e.axisLabel,
      n = e.splitLine,
      N = e.nameTextStyle;
    return {
      grid: this.data.commonOption.grid,
      tooltip: {
        trigger: "axis",
        axisPointer: {
          type: "cross"
        },
        borderWidth: .5,
        borderRadius: 5,
        borderColor: "#ccc",
        padding: 10,
        textStyle: {
          color: "#6B7387",
          fontSize: "0.875rem",
          fontFamily: "PingFang Sc"
        }
      },
      axisPointer: {
        link: {
          xAxisIndex: "all"
        },
        label: {
          backgroundColor: "#777"
        }
      },
      xAxis: [{
        gridIndex: 0,
        type: "category",
        data: M.date,
        axisTick: {
          show: !1
        },
        axisLine: {
          show: !0,
          lineStyle: {
            color: "#E5E6EB"
          }
        },
        axisLabel: {
          color: "#09163733",
          fontSize: ".75rem"
        }
      }, {
        gridIndex: 1,
        type: "category",
        data: M.date,
        axisTick: {
          show: !1
        },
        axisLine: {
          show: !0,
          lineStyle: {
            color: "#E5E6EB"
          }
        },
        axisLabel: {
          color: "#09163733",
          fontSize: ".75rem"
        }
      }],
      yAxis: [{
        gridIndex: 0,
        type: "value",
        name: "碳排放总量(t)",
        min: 0,
        axisLabel: a,
        splitLine: n,
        nameTextStyle: N
      }, {
        gridIndex: 1,
        type: "value",
        name: "发电强度(tCO₂/Mwh)",
        position: "right",
        axisTick: {
          alignWithLabel: !0
        },
        splitLine: {
          show: !1
        },
        axisLabel: a,
        nameTextStyle: i({
          padding: [0, 60, 0, 0]
        }, N)
      }, {
        gridIndex: 1,
        type: "value",
        name: "供热强度(tCO₂/GJ)",
        position: "left",
        axisTick: {
          alignWithLabel: !0
        },
        splitLine: n,
        axisLabel: a,
        nameTextStyle: i({
          padding: [0, 0, 0, 50]
        }, N)
      }],
      series: [{
        xAxisIndex: 0,
        yAxisIndex: 0,
        name: "碳排放总量(t)",
        type: "bar",
        barMaxWidth: 20,
        itemStyle: {
          color: new u.graphic.LinearGradient(0, 0, 0, 1, [{
            offset: 0,
            color: "#64A2F8"
          }, {
            offset: 1,
            color: "#3772E9"
          }]),
          borderRadius: [10, 10, 0, 0]
        },
        data: M.totalEmission
      }, {
        xAxisIndex: 1,
        yAxisIndex: 2,
        name: "发电强度(tCO₂/Mwh)",
        type: "line",
        data: (0, j.interpolationData)(M.powerIntensity),
        markLine: {
          data: [{
            yAxis: this.data.powerReference
          }],
          silent: !0,
          lineStyle: {
            type: "dotted",
            color: t[2]
          },
          symbol: "circle",
          symbolSize: 4,
          label: {
            show: !1
          }
        }
      }, {
        type: "line",
        xAxisIndex: 1,
        yAxisIndex: 1,
        name: "供热强度(tCO₂/GJ)",
        data: (0, j.interpolationData)(M.heatIntensity),
        markLine: {
          data: [{
            yAxis: this.data.heatingReference
          }],
          silent: !0,
          lineStyle: {
            type: "dotted",
            color: t[1]
          },
          symbol: "circle",
          symbolSize: 4,
          label: {
            show: !1
          }
        }
      }]
    }
  },
  navigateTo: function() {
    wx.reLaunch({
      url: "/pages/warning/warning?isIndex=true"
    })
  }
});