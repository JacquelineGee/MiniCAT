var t = getApp();
Component({
  properties: {
    title: {
      type: String,
      value: ""
    },
    isIndex: {
      type: Boolean,
      value: !1
    }
  },
  data: {
    menuButtonTop: 0,
    toptarHeight: 0,
    menuButtonHeight: 0,
    navbarTopOpacity: 0
  },
  methods: {
    navigateBack: function() {
      var t = this.data,
        a = t.title,
        e = t.isIndex;
      "预警" == a && e ? wx.switchTab({
        url: "pages/index/index"
      }) : wx.navigateBack({
        delta: 1
      })
    },
    handleScroll: function(t) {
      t.scrollTop > this.data.navBarHeight ? this.setData({
        navbarTopOpacity: 1
      }) : this.setData({
        navbarTopOpacity: 0
      })
    },
    getMenuButtonInfo: function() {
      var a = wx.getMenuButtonBoundingClientRect();
      this.setData({
        menuButtonHeight: 2 * a.height,
        menuButtonTop: 2 * a.top
      }), t.globalData.toptarHeight = 2 * a.height + 2 * a.top
    },
    onBack: function() {
      var t = this.data,
        a = t.title,
        e = t.isIndex;
      "预警" == a && e ? wx.switchTab({
        url: "/pages/index/index"
      }) : wx.navigateBack({
        delta: 1
      })
    }
  },
  lifetimes: {
    attached: function() {
      this.getMenuButtonInfo()
    }
  }
});