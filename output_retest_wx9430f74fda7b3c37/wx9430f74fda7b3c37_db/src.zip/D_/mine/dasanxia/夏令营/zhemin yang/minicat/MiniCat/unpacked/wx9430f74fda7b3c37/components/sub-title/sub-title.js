Component({
  properties: {
    title: ""
  },
  data: {},
  methods: {}
});