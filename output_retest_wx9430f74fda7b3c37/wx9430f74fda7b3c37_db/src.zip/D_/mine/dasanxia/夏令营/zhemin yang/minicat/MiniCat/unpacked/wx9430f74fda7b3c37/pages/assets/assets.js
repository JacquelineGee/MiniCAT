var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")),
  t = require("../../@babel/runtime/helpers/asyncToGenerator"),
  r = require("../../utils/request"),
  a = getApp();
Page({
  data: {
    indexData: {},
    balanceData: {},
    adviseText: "",
    recodeList: []
  },
  carbonIntellectualProperty: function() {
    var a = this;
    return t(e.default.mark((function t() {
      var n;
      return e.default.wrap((function(e) {
        for (;;) switch (e.prev = e.next) {
          case 0:
            return e.prev = 0, e.next = 3, (0, r.requestService)("/asset/intellectualProperty/carbonIntellectualProperty");
          case 3:
            n = e.sent, console.log(n), a.setData({
              indexData: n
            }), e.next = 11;
            break;
          case 8:
            e.prev = 8, e.t0 = e.catch(0), console.error(e.t0);
          case 11:
          case "end":
            return e.stop()
        }
      }), t, null, [
        [0, 8]
      ])
    })))()
  },
  tradeRecordSelectByYear: function() {
    var a = this;
    return t(e.default.mark((function t() {
      var n;
      return e.default.wrap((function(e) {
        for (;;) switch (e.prev = e.next) {
          case 0:
            return e.prev = 0, e.next = 3, (0, r.requestService)("/asset/tradeRecord/selectByYear");
          case 3:
            n = e.sent, a.setData({
              balanceData: n
            }), e.next = 10;
            break;
          case 7:
            e.prev = 7, e.t0 = e.catch(0), console.error(e.t0);
          case 10:
          case "end":
            return e.stop()
        }
      }), t, null, [
        [0, 7]
      ])
    })))()
  },
  advise: function() {
    var a = this;
    return t(e.default.mark((function t() {
      var n;
      return e.default.wrap((function(e) {
        for (;;) switch (e.prev = e.next) {
          case 0:
            return e.prev = 0, e.next = 3, (0, r.requestService)("/asset/realtimePrice/advise");
          case 3:
            n = e.sent, a.setData({
              adviseText: n.msg
            }), e.next = 10;
            break;
          case 7:
            e.prev = 7, e.t0 = e.catch(0), console.error(e.t0);
          case 10:
          case "end":
            return e.stop()
        }
      }), t, null, [
        [0, 7]
      ])
    })))()
  },
  tradeRecord: function() {
    var a = this;
    return t(e.default.mark((function t() {
      var n;
      return e.default.wrap((function(e) {
        for (;;) switch (e.prev = e.next) {
          case 0:
            return e.prev = 0, e.next = 3, (0, r.requestService)("/asset/tradeRecord/list");
          case 3:
            n = e.sent, console.log(n), a.setData({
              recodeList: n.rows
            }), e.next = 11;
            break;
          case 8:
            e.prev = 8, e.t0 = e.catch(0), console.error(e.t0);
          case 11:
          case "end":
            return e.stop()
        }
      }), t, null, [
        [0, 8]
      ])
    })))()
  },
  onLoad: function(e) {
    this.setData({
      toptarHeight: a.globalData.toptarHeight
    }), this.carbonIntellectualProperty(), this.tradeRecordSelectByYear(), this.advise(), this.tradeRecord()
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {}
});