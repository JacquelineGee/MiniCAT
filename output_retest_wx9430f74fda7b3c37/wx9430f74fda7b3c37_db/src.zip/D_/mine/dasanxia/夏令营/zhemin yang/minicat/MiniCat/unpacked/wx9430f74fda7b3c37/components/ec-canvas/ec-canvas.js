var t, e = require("../../@babel/runtime/helpers/interopRequireWildcard"),
  a = require("../../@babel/runtime/helpers/interopRequireDefault"),
  n = require("../../@babel/runtime/helpers/typeof"),
  i = a(require("./wx-canvas")),
  r = e(require("./echarts"));

function o(t, e) {
  t = t.split("."), e = e.split(".");
  for (var a = Math.max(t.length, e.length); t.length < a;) t.push("0");
  for (; e.length < a;) e.push("0");
  for (var n = 0; n < a; n++) {
    var i = parseInt(t[n]),
      r = parseInt(e[n]);
    if (i > r) return 1;
    if (i < r) return -1
  }
  return 0
}

function s(t) {
  for (var e = 0; e < t.touches.length; ++e) {
    var a = t.touches[e];
    a.offsetX = a.x, a.offsetY = a.y
  }
  return t
}
Component({
  properties: {
    canvasId: {
      type: String,
      value: "ec-canvas"
    },
    ec: {
      type: Object
    },
    forceUseOldCanvas: {
      type: Boolean,
      value: !1
    },
    tuData: {
      type: Object
    }
  },
  data: {
    isUseNewCanvas: !1
  },
  ready: function() {
    r.registerPreprocessor((function(t) {
      t && t.series && (t.series.length > 0 ? t.series.forEach((function(t) {
        t.progressive = 0
      })) : "object" === n(t.series) && (t.series.progressive = 0))
    })), this.data.ec ? this.data.ec.lazyLoad || this.init() : console.warn('组件需绑定 ec 变量，例：<ec-canvas id="mychart-dom-bar" canvas-id="mychart-bar" ec="{{ ec }}"></ec-canvas>')
  },
  methods: {
    init: function(t) {
      var e = wx.getSystemInfoSync().SDKVersion,
        a = o(e, "2.9.0") >= 0,
        n = this.data.forceUseOldCanvas,
        i = a && !n;
      if (this.setData({
          isUseNewCanvas: i
        }), n && a && console.warn("开发者强制使用旧canvas,建议关闭"), i) this.initByNewWay(t);
      else {
        if (!(o(e, "1.9.91") >= 0)) return void console.error("微信基础库版本过低，需大于等于 1.9.91。参见：https://github.com/ecomfe/echarts-for-weixin#%E5%BE%AE%E4%BF%A1%E7%89%88%E6%9C%AC%E8%A6%81%E6%B1%82");
        console.warn("建议将微信基础库调整大于等于2.9.0版本。升级后绘图将有更好性能"), this.initByOldWay(t)
      }
    },
    initByOldWay: function(e) {
      var a = this;
      t = wx.createCanvasContext(this.data.canvasId, this);
      var n = new i.default(t, this.data.canvasId, !1);
      r.setCanvasCreator((function() {
        return n
      }));
      wx.createSelectorQuery().in(this).select(".ec-canvas").boundingClientRect((function(t) {
        "function" == typeof e ? a.chart = e(n, t.width, t.height, a.data.tuData, 1) : a.data.ec && "function" == typeof a.data.ec.onInit ? a.chart = a.data.ec.onInit(n, t.width, t.height, a.data.tuData, 1) : a.triggerEvent("init", {
          canvas: n,
          width: t.width,
          height: t.height,
          tuData: a.data.tuData,
          canvasDpr: 1
        })
      })).exec()
    },
    initByNewWay: function(t) {
      var e = this;
      wx.createSelectorQuery().in(this).select(".ec-canvas").fields({
        node: !0,
        size: !0
      }).exec((function(a) {
        var n = a[0].node;
        e.canvasNode = n;
        var o = wx.getSystemInfoSync().pixelRatio,
          s = a[0].width,
          c = a[0].height,
          u = n.getContext("2d"),
          h = new i.default(u, e.data.canvasId, !0, n);
        r.setCanvasCreator((function() {
          return h
        })), "function" == typeof t ? e.chart = t(h, s, c, e.data.tuData, o) : e.data.ec && "function" == typeof e.data.ec.onInit ? e.chart = e.data.ec.onInit(h, s, c, e.data.tuData, o) : e.triggerEvent("init", {
          canvas: h,
          width: s,
          height: c,
          tuData: e.data.tuData,
          dpr: o
        })
      }))
    },
    canvasToTempFilePath: function(e) {
      var a = this;
      this.data.isUseNewCanvas ? wx.createSelectorQuery().in(this).select(".ec-canvas").fields({
        node: !0,
        size: !0
      }).exec((function(t) {
        var a = t[0].node;
        e.canvas = a, wx.canvasToTempFilePath(e)
      })) : (e.canvasId || (e.canvasId = this.data.canvasId), t.draw(!0, (function() {
        wx.canvasToTempFilePath(e, a)
      })))
    },
    touchStart: function(t) {
      if (this.chart && t.touches.length > 0) {
        var e = t.touches[0],
          a = this.chart.getZr().handler;
        a.dispatch("mousedown", {
          zrX: e.x,
          zrY: e.y,
          preventDefault: function() {},
          stopImmediatePropagation: function() {},
          stopPropagation: function() {}
        }), a.dispatch("mousemove", {
          zrX: e.x,
          zrY: e.y,
          preventDefault: function() {},
          stopImmediatePropagation: function() {},
          stopPropagation: function() {}
        }), a.processGesture(s(t), "start")
      }
    },
    touchMove: function(t) {
      if (this.chart && t.touches.length > 0) {
        var e = t.touches[0],
          a = this.chart.getZr().handler;
        a.dispatch("mousemove", {
          zrX: e.x,
          zrY: e.y,
          preventDefault: function() {},
          stopImmediatePropagation: function() {},
          stopPropagation: function() {}
        }), a.processGesture(s(t), "change")
      }
    },
    touchEnd: function(t) {
      if (this.chart) {
        var e = t.changedTouches ? t.changedTouches[0] : {},
          a = this.chart.getZr().handler;
        a.dispatch("mouseup", {
          zrX: e.x,
          zrY: e.y,
          preventDefault: function() {},
          stopImmediatePropagation: function() {},
          stopPropagation: function() {}
        }), a.dispatch("click", {
          zrX: e.x,
          zrY: e.y,
          preventDefault: function() {},
          stopImmediatePropagation: function() {},
          stopPropagation: function() {}
        }), a.processGesture(s(t), "end")
      }
    }
  }
});