var t = require("../../@babel/runtime/helpers/typeof");
! function(e, n) {
  "object" == ("undefined" == typeof exports ? "undefined" : t(exports)) && "undefined" != typeof module ? n(exports) : "function" == typeof define && define.amd ? define(["exports"], n) : n((e = "undefined" != typeof globalThis ? globalThis : e || self).echarts = {})
}(void 0, (function(e) {
  var n = function(t, e) {
    return (n = Object.setPrototypeOf || ({
        __proto__: []
      }
      instanceof Array ? function(t, e) {
        t.__proto__ = e
      } : function(t, e) {
        for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n])
      }))(t, e)
  };

  function i(t, e) {
    if ("function" != typeof e && null !== e) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");

    function i() {
      this.constructor = t
    }
    n(t, e), t.prototype = null === e ? Object.create(e) : (i.prototype = e.prototype, new i)
  }
  var r = function() {
      this.firefox = !1, this.ie = !1, this.edge = !1, this.newEdge = !1, this.weChat = !1
    },
    o = new function() {
      this.browser = new r, this.node = !1, this.wxa = !1, this.worker = !1, this.svgSupported = !1, this.touchEventsSupported = !1, this.pointerEventsSupported = !1, this.domSupported = !1, this.transformSupported = !1, this.transform3dSupported = !1, this.hasGlobalWindow = "undefined" != typeof window
    };
  "object" == ("undefined" == typeof wx ? "undefined" : t(wx)) && "function" == typeof wx.getSystemInfoSync ? (o.wxa = !0, o.touchEventsSupported = !0) : "undefined" == typeof document && "undefined" != typeof self ? o.worker = !0 : "undefined" == typeof navigator || 0 === navigator.userAgent.indexOf("Node.js") ? (o.node = !0, o.svgSupported = !0) : (b = navigator.userAgent, Vt = (St = o).browser, A = b.match(/Firefox\/([\d.]+)/), y = b.match(/MSIE\s([\d.]+)/) || b.match(/Trident\/.+?rv:(([\d.]+))/), w = b.match(/Edge?\/([\d.]+)/), b = /micromessenger/i.test(b), A && (Vt.firefox = !0, Vt.version = A[1]), y && (Vt.ie = !0, Vt.version = y[1]), w && (Vt.edge = !0, Vt.version = w[1], Vt.newEdge = 18 < +w[1].split(".")[0]), b && (Vt.weChat = !0), St.svgSupported = "undefined" != typeof SVGRect, St.touchEventsSupported = "ontouchstart" in window && !Vt.ie && !Vt.edge, St.pointerEventsSupported = "onpointerdown" in window && (Vt.edge || Vt.ie && 11 <= +Vt.version), St.domSupported = "undefined" != typeof document, A = document.documentElement.style, St.transform3dSupported = (Vt.ie && "transition" in A || Vt.edge || "WebKitCSSMatrix" in window && "m11" in new WebKitCSSMatrix || "MozPerspective" in A) && !("OTransition" in A), St.transformSupported = St.transform3dSupported || Vt.ie && 9 <= +Vt.version);
  var a, s, l = "sans-serif",
    u = "12px " + l,
    h = function(t) {
      var e = {};
      if ("undefined" != typeof JSON)
        for (var n = 0; n < t.length; n++) {
          var i = String.fromCharCode(n + 32),
            r = (t.charCodeAt(n) - 20) / 100;
          e[i] = r
        }
      return e
    }("007LLmW'55;N0500LLLLLLLLLL00NNNLzWW\\\\WQb\\0FWLg\\bWb\\WQ\\WrWWQ000CL5LLFLL0LL**F*gLLLL5F0LF\\FFF5.5N"),
    c = {
      createCanvas: function() {
        return "undefined" != typeof document && document.createElement("canvas")
      },
      measureText: function(t, e) {
        if (a || (n = c.createCanvas(), a = n && n.getContext("2d")), a) return s !== e && (s = a.font = e || u), a.measureText(t);
        t = t || "";
        var n = /((?:\d+)?\.?\d*)px/.exec(e = e || u),
          i = n && +n[1] || 12,
          r = 0;
        if (0 <= e.indexOf("mono")) r = i * t.length;
        else
          for (var o = 0; o < t.length; o++) {
            var l = h[t[o]];
            r += null == l ? i : l * i
          }
        return {
          width: r
        }
      },
      loadImage: function(t, e, n) {
        var i = new Image;
        return i.onload = e, i.onerror = n, i.src = t, i
      }
    };

  function p(t) {
    for (var e in c) t[e] && (c[e] = t[e])
  }
  var d = z(["Function", "RegExp", "Date", "Error", "CanvasGradient", "CanvasPattern", "Image", "Canvas"], (function(t, e) {
      return t["[object " + e + "]"] = !0, t
    }), {}),
    f = z(["Int8", "Uint8", "Uint8Clamped", "Int16", "Uint16", "Int32", "Uint32", "Float32", "Float64"], (function(t, e) {
      return t["[object " + e + "Array]"] = !0, t
    }), {}),
    g = Object.prototype.toString,
    y = Array.prototype,
    m = y.forEach,
    v = y.filter,
    _ = y.slice,
    x = y.map,
    w = function() {}.constructor,
    b = w ? w.prototype : null,
    S = "__proto__",
    M = 2311;

  function T() {
    for (var t = [], e = 0; e < arguments.length; e++) t[e] = arguments[e];
    "undefined" != typeof console && console.error.apply(console, t)
  }

  function I(e) {
    if (null == e || "object" != t(e)) return e;
    var n = e,
      i = g.call(e);
    if ("[object Array]" === i) {
      if (!ht(e)) {
        n = [];
        for (var r = 0, o = e.length; r < o; r++) n[r] = I(e[r])
      }
    } else if (f[i]) {
      if (!ht(e)) {
        var a = e.constructor;
        if (a.from) n = a.from(e);
        else
          for (n = new a(e.length), r = 0, o = e.length; r < o; r++) n[r] = e[r]
      }
    } else if (!d[i] && !ht(e) && !K(e))
      for (var s in n = {}, e) e.hasOwnProperty(s) && s !== S && (n[s] = I(e[s]));
    return n
  }

  function C(t, e, n) {
    if (!q(e) || !q(t)) return n ? I(e) : t;
    for (var i in e) {
      var r, o;
      e.hasOwnProperty(i) && i !== S && (r = t[i], !q(o = e[i]) || !q(r) || W(o) || W(r) || K(o) || K(r) || j(o) || j(r) || ht(o) || ht(r) ? !n && i in t || (t[i] = I(e[i])) : C(r, o, n))
    }
    return t
  }

  function k(t, e) {
    if (Object.assign) Object.assign(t, e);
    else
      for (var n in e) e.hasOwnProperty(n) && n !== S && (t[n] = e[n]);
    return t
  }

  function D(t, e, n) {
    for (var i = F(e), r = 0; r < i.length; r++) {
      var o = i[r];
      (n ? null != e[o] : null == t[o]) && (t[o] = e[o])
    }
    return t
  }
  var A = c.createCanvas;

  function L(t, e) {
    if (t) {
      if (t.indexOf) return t.indexOf(e);
      for (var n = 0, i = t.length; n < i; n++)
        if (t[n] === e) return n
    }
    return -1
  }

  function P(t, e) {
    var n, i = t.prototype;

    function r() {}
    for (n in r.prototype = e.prototype, t.prototype = new r, i) i.hasOwnProperty(n) && (t.prototype[n] = i[n]);
    (t.prototype.constructor = t).superClass = e
  }

  function O(t, e, n) {
    if (t = "prototype" in t ? t.prototype : t, e = "prototype" in e ? e.prototype : e, Object.getOwnPropertyNames)
      for (var i = Object.getOwnPropertyNames(e), r = 0; r < i.length; r++) {
        var o = i[r];
        "constructor" !== o && (n ? null != e[o] : null == t[o]) && (t[o] = e[o])
      } else D(t, e, n)
  }

  function R(t) {
    return !!t && "string" != typeof t && "number" == typeof t.length
  }

  function N(t, e, n) {
    if (t && e)
      if (t.forEach && t.forEach === m) t.forEach(e, n);
      else if (t.length === +t.length)
      for (var i = 0, r = t.length; i < r; i++) e.call(n, t[i], i, t);
    else
      for (var o in t) t.hasOwnProperty(o) && e.call(n, t[o], o, t)
  }

  function E(t, e, n) {
    if (!t) return [];
    if (!e) return rt(t);
    if (t.map && t.map === x) return t.map(e, n);
    for (var i = [], r = 0, o = t.length; r < o; r++) i.push(e.call(n, t[r], r, t));
    return i
  }

  function z(t, e, n, i) {
    if (t && e) {
      for (var r = 0, o = t.length; r < o; r++) n = e.call(i, n, t[r], r, t);
      return n
    }
  }

  function B(t, e, n) {
    if (!t) return [];
    if (!e) return rt(t);
    if (t.filter && t.filter === v) return t.filter(e, n);
    for (var i = [], r = 0, o = t.length; r < o; r++) e.call(n, t[r], r, t) && i.push(t[r]);
    return i
  }

  function F(t) {
    if (!t) return [];
    if (Object.keys) return Object.keys(t);
    var e, n = [];
    for (e in t) t.hasOwnProperty(e) && n.push(e);
    return n
  }
  var V = b && G(b.bind) ? b.call.bind(b.bind) : function(t, e) {
    for (var n = [], i = 2; i < arguments.length; i++) n[i - 2] = arguments[i];
    return function() {
      return t.apply(e, n.concat(_.call(arguments)))
    }
  };

  function H(t) {
    for (var e = [], n = 1; n < arguments.length; n++) e[n - 1] = arguments[n];
    return function() {
      return t.apply(this, e.concat(_.call(arguments)))
    }
  }

  function W(t) {
    return Array.isArray ? Array.isArray(t) : "[object Array]" === g.call(t)
  }

  function G(t) {
    return "function" == typeof t
  }

  function U(t) {
    return "string" == typeof t
  }

  function X(t) {
    return "[object String]" === g.call(t)
  }

  function Y(t) {
    return "number" == typeof t
  }

  function q(e) {
    var n = t(e);
    return "function" == n || !!e && "object" == n
  }

  function j(t) {
    return !!d[g.call(t)]
  }

  function Z(t) {
    return !!f[g.call(t)]
  }

  function K(e) {
    return "object" == t(e) && "number" == typeof e.nodeType && "object" == t(e.ownerDocument)
  }

  function $(t) {
    return null != t.colorStops
  }

  function Q(t) {
    return null != t.image
  }

  function J(t) {
    return "[object RegExp]" === g.call(t)
  }

  function tt(t) {
    return t != t
  }

  function et() {
    for (var t = [], e = 0; e < arguments.length; e++) t[e] = arguments[e];
    for (var n = 0, i = t.length; n < i; n++)
      if (null != t[n]) return t[n]
  }

  function nt(t, e) {
    return null != t ? t : e
  }

  function it(t, e, n) {
    return null != t ? t : null != e ? e : n
  }

  function rt(t) {
    for (var e = [], n = 1; n < arguments.length; n++) e[n - 1] = arguments[n];
    return _.apply(t, e)
  }

  function ot(t) {
    var e;
    return "number" == typeof t ? [t, t, t, t] : 2 === (e = t.length) ? [t[0], t[1], t[0], t[1]] : 3 === e ? [t[0], t[1], t[2], t[1]] : t
  }

  function at(t, e) {
    if (!t) throw new Error(e)
  }

  function st(t) {
    return null == t ? null : "function" == typeof t.trim ? t.trim() : t.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "")
  }
  var lt = "__ec_primitive__";

  function ut(t) {
    t[lt] = !0
  }

  function ht(t) {
    return t[lt]
  }
  pt.prototype.delete = function(t) {
    var e = this.has(t);
    return e && delete this.data[t], e
  }, pt.prototype.has = function(t) {
    return this.data.hasOwnProperty(t)
  }, pt.prototype.get = function(t) {
    return this.data[t]
  }, pt.prototype.set = function(t, e) {
    return this.data[t] = e, this
  }, pt.prototype.keys = function() {
    return F(this.data)
  }, pt.prototype.forEach = function(t) {
    var e, n = this.data;
    for (e in n) n.hasOwnProperty(e) && t(n[e], e)
  };
  var ct = pt;

  function pt() {
    this.data = {}
  }
  var dt = "function" == typeof Map;
  gt.prototype.hasKey = function(t) {
    return this.data.has(t)
  }, gt.prototype.get = function(t) {
    return this.data.get(t)
  }, gt.prototype.set = function(t, e) {
    return this.data.set(t, e), e
  }, gt.prototype.each = function(t, e) {
    this.data.forEach((function(n, i) {
      t.call(e, n, i)
    }))
  }, gt.prototype.keys = function() {
    var t = this.data.keys();
    return dt ? Array.from(t) : t
  }, gt.prototype.removeKey = function(t) {
    this.data.delete(t)
  };
  var ft = gt;

  function gt(t) {
    var e = W(t),
      n = (this.data = new(dt ? Map : ct), this);

    function i(t, i) {
      e ? n.set(t, i) : n.set(i, t)
    }
    t instanceof gt ? t.each(i) : t && N(t, i)
  }

  function yt(t) {
    return new ft(t)
  }

  function mt(t, e) {
    for (var n = new t.constructor(t.length + e.length), i = 0; i < t.length; i++) n[i] = t[i];
    var r = t.length;
    for (i = 0; i < e.length; i++) n[i + r] = e[i];
    return n
  }

  function vt(t, e) {
    var n;
    t = Object.create ? Object.create(t) : ((n = function() {}).prototype = t, new n);
    return e && k(t, e), t
  }

  function _t(t) {
    (t = t.style).webkitUserSelect = "none", t.userSelect = "none", t.webkitTapHighlightColor = "rgba(0,0,0,0)", t["-webkit-touch-callout"] = "none"
  }

  function xt(t, e) {
    return t.hasOwnProperty(e)
  }

  function wt() {}
  var bt = 180 / Math.PI,
    St = Object.freeze({
      __proto__: null,
      HashMap: ft,
      RADIAN_TO_DEGREE: bt,
      assert: at,
      bind: V,
      clone: I,
      concatArray: mt,
      createCanvas: A,
      createHashMap: yt,
      createObject: vt,
      curry: H,
      defaults: D,
      disableUserSelect: _t,
      each: N,
      eqNaN: tt,
      extend: k,
      filter: B,
      find: function(t, e, n) {
        if (t && e)
          for (var i = 0, r = t.length; i < r; i++)
            if (e.call(n, t[i], i, t)) return t[i]
      },
      guid: function() {
        return M++
      },
      hasOwn: xt,
      indexOf: L,
      inherits: P,
      isArray: W,
      isArrayLike: R,
      isBuiltInObject: j,
      isDom: K,
      isFunction: G,
      isGradientObject: $,
      isImagePatternObject: Q,
      isNumber: Y,
      isObject: q,
      isPrimitive: ht,
      isRegExp: J,
      isString: U,
      isStringSafe: X,
      isTypedArray: Z,
      keys: F,
      logError: T,
      map: E,
      merge: C,
      mergeAll: function(t, e) {
        for (var n = t[0], i = 1, r = t.length; i < r; i++) n = C(n, t[i], e);
        return n
      },
      mixin: O,
      noop: wt,
      normalizeCssArray: ot,
      reduce: z,
      retrieve: et,
      retrieve2: nt,
      retrieve3: it,
      setAsPrimitive: ut,
      slice: rt,
      trim: st
    });

  function Mt(t, e) {
    return [t = null == t ? 0 : t, e = null == e ? 0 : e]
  }

  function Tt(t) {
    return [t[0], t[1]]
  }

  function It(t, e, n) {
    return t[0] = e[0] + n[0], t[1] = e[1] + n[1], t
  }

  function Ct(t, e, n) {
    return t[0] = e[0] - n[0], t[1] = e[1] - n[1], t
  }

  function kt(t) {
    return Math.sqrt(Dt(t))
  }

  function Dt(t) {
    return t[0] * t[0] + t[1] * t[1]
  }

  function At(t, e, n) {
    return t[0] = e[0] * n, t[1] = e[1] * n, t
  }

  function Lt(t, e) {
    var n = kt(e);
    return 0 === n ? (t[0] = 0, t[1] = 0) : (t[0] = e[0] / n, t[1] = e[1] / n), t
  }

  function Pt(t, e) {
    return Math.sqrt((t[0] - e[0]) * (t[0] - e[0]) + (t[1] - e[1]) * (t[1] - e[1]))
  }
  var Ot = Pt;

  function Rt(t, e) {
    return (t[0] - e[0]) * (t[0] - e[0]) + (t[1] - e[1]) * (t[1] - e[1])
  }
  var Nt = Rt;

  function Et(t, e, n, i) {
    return t[0] = e[0] + i * (n[0] - e[0]), t[1] = e[1] + i * (n[1] - e[1]), t
  }

  function zt(t, e, n) {
    var i = e[0];
    e = e[1];
    return t[0] = n[0] * i + n[2] * e + n[4], t[1] = n[1] * i + n[3] * e + n[5], t
  }

  function Bt(t, e, n) {
    return t[0] = Math.min(e[0], n[0]), t[1] = Math.min(e[1], n[1]), t
  }

  function Ft(t, e, n) {
    return t[0] = Math.max(e[0], n[0]), t[1] = Math.max(e[1], n[1]), t
  }
  var Vt = Object.freeze({
      __proto__: null,
      add: It,
      applyTransform: zt,
      clone: Tt,
      copy: function(t, e) {
        return t[0] = e[0], t[1] = e[1], t
      },
      create: Mt,
      dist: Ot,
      distSquare: Nt,
      distance: Pt,
      distanceSquare: Rt,
      div: function(t, e, n) {
        return t[0] = e[0] / n[0], t[1] = e[1] / n[1], t
      },
      dot: function(t, e) {
        return t[0] * e[0] + t[1] * e[1]
      },
      len: kt,
      lenSquare: Dt,
      length: kt,
      lengthSquare: Dt,
      lerp: Et,
      max: Ft,
      min: Bt,
      mul: function(t, e, n) {
        return t[0] = e[0] * n[0], t[1] = e[1] * n[1], t
      },
      negate: function(t, e) {
        return t[0] = -e[0], t[1] = -e[1], t
      },
      normalize: Lt,
      scale: At,
      scaleAndAdd: function(t, e, n, i) {
        return t[0] = e[0] + n[0] * i, t[1] = e[1] + n[1] * i, t
      },
      set: function(t, e, n) {
        return t[0] = e, t[1] = n, t
      },
      sub: Ct
    }),
    Ht = function(t, e) {
      this.target = t, this.topTarget = e && e.topTarget
    },
    Wt = (Gt.prototype._dragStart = function(t) {
      for (var e = t.target; e && !e.draggable;) e = e.parent || e.__hostTarget;
      e && ((this._draggingTarget = e).dragging = !0, this._x = t.offsetX, this._y = t.offsetY, this.handler.dispatchToElement(new Ht(e, t), "dragstart", t.event))
    }, Gt.prototype._drag = function(t) {
      var e, n, i, r, o = this._draggingTarget;
      o && (e = t.offsetX, n = t.offsetY, i = e - this._x, r = n - this._y, this._x = e, this._y = n, o.drift(i, r, t), this.handler.dispatchToElement(new Ht(o, t), "drag", t.event), i = this.handler.findHover(e, n, o).target, r = this._dropTarget, o !== (this._dropTarget = i)) && (r && i !== r && this.handler.dispatchToElement(new Ht(r, t), "dragleave", t.event), i) && i !== r && this.handler.dispatchToElement(new Ht(i, t), "dragenter", t.event)
    }, Gt.prototype._dragEnd = function(t) {
      var e = this._draggingTarget;
      e && (e.dragging = !1), this.handler.dispatchToElement(new Ht(e, t), "dragend", t.event), this._dropTarget && this.handler.dispatchToElement(new Ht(this._dropTarget, t), "drop", t.event), this._draggingTarget = null, this._dropTarget = null
    }, Gt);

  function Gt(t) {
    (this.handler = t).on("mousedown", this._dragStart, this), t.on("mousemove", this._drag, this), t.on("mouseup", this._dragEnd, this)
  }
  Xt.prototype.on = function(t, e, n, i) {
    this._$handlers || (this._$handlers = {});
    var r = this._$handlers;
    if ("function" == typeof e && (i = n, n = e, e = null), n && t) {
      var o = this._$eventProcessor;
      null != e && o && o.normalizeQuery && (e = o.normalizeQuery(e)), r[t] || (r[t] = []);
      for (var a = 0; a < r[t].length; a++)
        if (r[t][a].h === n) return this;
      o = {
        h: n,
        query: e,
        ctx: i || this,
        callAtLast: n.zrEventfulCallAtLast
      }, e = r[t].length - 1, (i = r[t][e]) && i.callAtLast ? r[t].splice(e, 0, o) : r[t].push(o)
    }
    return this
  }, Xt.prototype.isSilent = function(t) {
    var e = this._$handlers;
    return !e || !e[t] || !e[t].length
  }, Xt.prototype.off = function(t, e) {
    var n = this._$handlers;
    if (n)
      if (t)
        if (e) {
          if (n[t]) {
            for (var i = [], r = 0, o = n[t].length; r < o; r++) n[t][r].h !== e && i.push(n[t][r]);
            n[t] = i
          }
          n[t] && 0 === n[t].length && delete n[t]
        } else delete n[t];
    else this._$handlers = {};
    return this
  }, Xt.prototype.trigger = function(t) {
    for (var e = [], n = 1; n < arguments.length; n++) e[n - 1] = arguments[n];
    if (this._$handlers) {
      var i = this._$handlers[t],
        r = this._$eventProcessor;
      if (i)
        for (var o = e.length, a = i.length, s = 0; s < a; s++) {
          var l = i[s];
          if (!r || !r.filter || null == l.query || r.filter(t, l.query)) switch (o) {
            case 0:
              l.h.call(l.ctx);
              break;
            case 1:
              l.h.call(l.ctx, e[0]);
              break;
            case 2:
              l.h.call(l.ctx, e[0], e[1]);
              break;
            default:
              l.h.apply(l.ctx, e)
          }
        }
      r && r.afterTrigger && r.afterTrigger(t)
    }
    return this
  }, Xt.prototype.triggerWithContext = function(t) {
    for (var e = [], n = 1; n < arguments.length; n++) e[n - 1] = arguments[n];
    if (this._$handlers) {
      var i = this._$handlers[t],
        r = this._$eventProcessor;
      if (i)
        for (var o = e.length, a = e[o - 1], s = i.length, l = 0; l < s; l++) {
          var u = i[l];
          if (!r || !r.filter || null == u.query || r.filter(t, u.query)) switch (o) {
            case 0:
              u.h.call(a);
              break;
            case 1:
              u.h.call(a, e[0]);
              break;
            case 2:
              u.h.call(a, e[0], e[1]);
              break;
            default:
              u.h.apply(a, e.slice(1, o - 1))
          }
        }
      r && r.afterTrigger && r.afterTrigger(t)
    }
    return this
  };
  var Ut = Xt;

  function Xt(t) {
    t && (this._$eventProcessor = t)
  }
  var Yt = Math.log(2);

  function qt(t, e, n, i, r, o) {
    var a, s = i + "-" + r,
      l = t.length;
    if (o.hasOwnProperty(s)) return o[s];
    if (1 === e) return a = Math.round(Math.log((1 << l) - 1 & ~r) / Yt), t[n][a];
    for (var u = i | 1 << n, h = n + 1; i & 1 << h;) h++;
    for (var c = 0, p = 0, d = 0; p < l; p++) {
      var f = 1 << p;
      f & r || (c += (d % 2 ? -1 : 1) * t[n][p] * qt(t, e - 1, h, u, r | f, o), d++)
    }
    return o[s] = c
  }

  function jt(t, e) {
    var n = [
        [t[0], t[1], 1, 0, 0, 0, -e[0] * t[0], -e[0] * t[1]],
        [0, 0, 0, t[0], t[1], 1, -e[1] * t[0], -e[1] * t[1]],
        [t[2], t[3], 1, 0, 0, 0, -e[2] * t[2], -e[2] * t[3]],
        [0, 0, 0, t[2], t[3], 1, -e[3] * t[2], -e[3] * t[3]],
        [t[4], t[5], 1, 0, 0, 0, -e[4] * t[4], -e[4] * t[5]],
        [0, 0, 0, t[4], t[5], 1, -e[5] * t[4], -e[5] * t[5]],
        [t[6], t[7], 1, 0, 0, 0, -e[6] * t[6], -e[6] * t[7]],
        [0, 0, 0, t[6], t[7], 1, -e[7] * t[6], -e[7] * t[7]]
      ],
      i = {},
      r = qt(n, 8, 0, 0, 0, i);
    if (0 !== r) {
      for (var o = [], a = 0; a < 8; a++)
        for (var s = 0; s < 8; s++) null == o[s] && (o[s] = 0), o[s] += ((a + s) % 2 ? -1 : 1) * qt(n, 7, 0 === a ? 1 : 0, 1 << a, 1 << s, i) / r * e[a];
      return function(t, e, n) {
        var i = e * o[6] + n * o[7] + 1;
        t[0] = (e * o[0] + n * o[1] + o[2]) / i, t[1] = (e * o[3] + n * o[4] + o[5]) / i
      }
    }
  }
  var Zt = "___zrEVENTSAVED",
    Kt = [];

  function $t(t, e, n, i, r) {
    if (e.getBoundingClientRect && o.domSupported && !Qt(e)) {
      var a = e[Zt] || (e[Zt] = {});
      if (e = function(t, e, n) {
          for (var i = n ? "invTrans" : "trans", r = e[i], o = e.srcCoords, a = [], s = [], l = !0, u = 0; u < 4; u++) {
            var h = 2 * u,
              c = (p = t[u].getBoundingClientRect()).left,
              p = p.top;
            a.push(c, p), l = l && o && c === o[h] && p === o[1 + h], s.push(t[u].offsetLeft, t[u].offsetTop)
          }
          return l && r ? r : (e.srcCoords = a, e[i] = n ? jt(s, a) : jt(a, s))
        }(function(t, e) {
          var n = e.markers;
          if (!n) {
            n = e.markers = [];
            for (var i = ["left", "right"], r = ["top", "bottom"], o = 0; o < 4; o++) {
              var a = document.createElement("div"),
                s = o % 2,
                l = (o >> 1) % 2;
              a.style.cssText = ["position: absolute", "visibility: hidden", "padding: 0", "margin: 0", "border-width: 0", "user-select: none", "width:0", "height:0", i[s] + ":0", r[l] + ":0", i[1 - s] + ":auto", r[1 - l] + ":auto", ""].join("!important;"), t.appendChild(a), n.push(a)
            }
          }
          return n
        }(e, a), a, r)) return e(t, n, i), !0
    }
    return !1
  }

  function Qt(t) {
    return "CANVAS" === t.nodeName.toUpperCase()
  }
  var Jt = /([&<>"'])/g,
    te = {
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;"
    };

  function ee(t) {
    return null == t ? "" : (t + "").replace(Jt, (function(t, e) {
      return te[e]
    }))
  }
  var ne = /^(?:mouse|pointer|contextmenu|drag|drop)|click/,
    ie = [],
    re = o.browser.firefox && +o.browser.version.split(".")[0] < 39;

  function oe(t, e, n, i) {
    return n = n || {}, i ? ae(t, e, n) : re && null != e.layerX && e.layerX !== e.offsetX ? (n.zrX = e.layerX, n.zrY = e.layerY) : null != e.offsetX ? (n.zrX = e.offsetX, n.zrY = e.offsetY) : ae(t, e, n), n
  }

  function ae(t, e, n) {
    if (o.domSupported && t.getBoundingClientRect) {
      var i, r = e.clientX;
      e = e.clientY;
      if (Qt(t)) return i = t.getBoundingClientRect(), n.zrX = r - i.left, void(n.zrY = e - i.top);
      if ($t(ie, t, r, e)) return n.zrX = ie[0], void(n.zrY = ie[1])
    }
    n.zrX = n.zrY = 0
  }

  function se(t) {
    return t || window.event
  }

  function le(t, e, n) {
    var i;
    return null == (e = se(e)).zrX && ((i = e.type) && 0 <= i.indexOf("touch") ? (i = ("touchend" !== i ? e.targetTouches : e.changedTouches)[0]) && oe(t, i, e, n) : (oe(t, e, e, n), i = function(t) {
      var e = t.wheelDelta;
      if (e) return e;
      var n = t.deltaX;
      t = t.deltaY;
      return null != n && null != t ? 3 * (0 !== t ? Math.abs(t) : Math.abs(n)) * (0 < t || !(t < 0) && 0 < n ? -1 : 1) : e
    }(e), e.zrDelta = i ? i / 120 : -(e.detail || 0) / 3), t = e.button, null == e.which && void 0 !== t && ne.test(e.type)) && (e.which = 1 & t ? 1 : 2 & t ? 3 : 4 & t ? 2 : 0), e
  }
  var ue = function(t) {
      t.preventDefault(), t.stopPropagation(), t.cancelBubble = !0
    },
    he = (ce.prototype.recognize = function(t, e, n) {
      return this._doTrack(t, e, n), this._recognize(t)
    }, ce.prototype.clear = function() {
      return this._track.length = 0, this
    }, ce.prototype._doTrack = function(t, e, n) {
      var i = t.touches;
      if (i) {
        for (var r = {
            points: [],
            touches: [],
            target: e,
            event: t
          }, o = 0, a = i.length; o < a; o++) {
          var s = i[o],
            l = oe(n, s, {});
          r.points.push([l.zrX, l.zrY]), r.touches.push(s)
        }
        this._track.push(r)
      }
    }, ce.prototype._recognize = function(t) {
      for (var e in de)
        if (de.hasOwnProperty(e) && (e = de[e](this._track, t))) return e
    }, ce);

  function ce() {
    this._track = []
  }

  function pe(t) {
    var e = t[1][0] - t[0][0];
    t = t[1][1] - t[0][1];
    return Math.sqrt(e * e + t * t)
  }
  var de = {
    pinch: function(t, e) {
      var n, i = t.length;
      if (i) return n = (t[i - 1] || {}).points, (i = (t[i - 2] || {}).points || n) && 1 < i.length && n && 1 < n.length ? (i = pe(n) / pe(i), isFinite(i) || (i = 1), e.pinchScale = i, i = [(n[0][0] + n[1][0]) / 2, (n[0][1] + n[1][1]) / 2], e.pinchX = i[0], e.pinchY = i[1], {
        type: "pinch",
        target: t[0].target,
        event: e
      }) : void 0
    }
  };

  function fe() {
    return [1, 0, 0, 1, 0, 0]
  }

  function ge(t) {
    return t[0] = 1, t[1] = 0, t[2] = 0, t[3] = 1, t[4] = 0, t[5] = 0, t
  }

  function ye(t, e) {
    return t[0] = e[0], t[1] = e[1], t[2] = e[2], t[3] = e[3], t[4] = e[4], t[5] = e[5], t
  }

  function me(t, e, n) {
    var i = e[0] * n[0] + e[2] * n[1],
      r = e[1] * n[0] + e[3] * n[1],
      o = e[0] * n[2] + e[2] * n[3],
      a = e[1] * n[2] + e[3] * n[3],
      s = e[0] * n[4] + e[2] * n[5] + e[4];
    n = e[1] * n[4] + e[3] * n[5] + e[5];
    return t[0] = i, t[1] = r, t[2] = o, t[3] = a, t[4] = s, t[5] = n, t
  }

  function ve(t, e, n) {
    return t[0] = e[0], t[1] = e[1], t[2] = e[2], t[3] = e[3], t[4] = e[4] + n[0], t[5] = e[5] + n[1], t
  }

  function _e(t, e, n, i) {
    void 0 === i && (i = [0, 0]);
    var r = e[0],
      o = e[2],
      a = e[4],
      s = e[1],
      l = e[3],
      u = (e = e[5], Math.sin(n));
    n = Math.cos(n);
    return t[0] = r * n + s * u, t[1] = -r * u + s * n, t[2] = o * n + l * u, t[3] = -o * u + n * l, t[4] = n * (a - i[0]) + u * (e - i[1]) + i[0], t[5] = n * (e - i[1]) - u * (a - i[0]) + i[1], t
  }

  function xe(t, e, n) {
    var i = n[0];
    n = n[1];
    return t[0] = e[0] * i, t[1] = e[1] * n, t[2] = e[2] * i, t[3] = e[3] * n, t[4] = e[4] * i, t[5] = e[5] * n, t
  }

  function we(t, e) {
    var n = e[0],
      i = e[2],
      r = e[4],
      o = e[1],
      a = e[3],
      s = (e = e[5], n * a - o * i);
    return s ? (t[0] = a * (s = 1 / s), t[1] = -o * s, t[2] = -i * s, t[3] = n * s, t[4] = (i * e - a * r) * s, t[5] = (o * r - n * e) * s, t) : null
  }
  var be = Object.freeze({
      __proto__: null,
      clone: function(t) {
        var e = [1, 0, 0, 1, 0, 0];
        return ye(e, t), e
      },
      copy: ye,
      create: fe,
      identity: ge,
      invert: we,
      mul: me,
      rotate: _e,
      scale: xe,
      translate: ve
    }),
    Se = (Me.prototype.copy = function(t) {
      return this.x = t.x, this.y = t.y, this
    }, Me.prototype.clone = function() {
      return new Me(this.x, this.y)
    }, Me.prototype.set = function(t, e) {
      return this.x = t, this.y = e, this
    }, Me.prototype.equal = function(t) {
      return t.x === this.x && t.y === this.y
    }, Me.prototype.add = function(t) {
      return this.x += t.x, this.y += t.y, this
    }, Me.prototype.scale = function(t) {
      this.x *= t, this.y *= t
    }, Me.prototype.scaleAndAdd = function(t, e) {
      this.x += t.x * e, this.y += t.y * e
    }, Me.prototype.sub = function(t) {
      return this.x -= t.x, this.y -= t.y, this
    }, Me.prototype.dot = function(t) {
      return this.x * t.x + this.y * t.y
    }, Me.prototype.len = function() {
      return Math.sqrt(this.x * this.x + this.y * this.y)
    }, Me.prototype.lenSquare = function() {
      return this.x * this.x + this.y * this.y
    }, Me.prototype.normalize = function() {
      var t = this.len();
      return this.x /= t, this.y /= t, this
    }, Me.prototype.distance = function(t) {
      var e = this.x - t.x;
      t = this.y - t.y;
      return Math.sqrt(e * e + t * t)
    }, Me.prototype.distanceSquare = function(t) {
      var e = this.x - t.x;
      return e * e + (t = this.y - t.y) * t
    }, Me.prototype.negate = function() {
      return this.x = -this.x, this.y = -this.y, this
    }, Me.prototype.transform = function(t) {
      var e, n;
      if (t) return e = this.x, n = this.y, this.x = t[0] * e + t[2] * n + t[4], this.y = t[1] * e + t[3] * n + t[5], this
    }, Me.prototype.toArray = function(t) {
      return t[0] = this.x, t[1] = this.y, t
    }, Me.prototype.fromArray = function(t) {
      this.x = t[0], this.y = t[1]
    }, Me.set = function(t, e, n) {
      t.x = e, t.y = n
    }, Me.copy = function(t, e) {
      t.x = e.x, t.y = e.y
    }, Me.len = function(t) {
      return Math.sqrt(t.x * t.x + t.y * t.y)
    }, Me.lenSquare = function(t) {
      return t.x * t.x + t.y * t.y
    }, Me.dot = function(t, e) {
      return t.x * e.x + t.y * e.y
    }, Me.add = function(t, e, n) {
      t.x = e.x + n.x, t.y = e.y + n.y
    }, Me.sub = function(t, e, n) {
      t.x = e.x - n.x, t.y = e.y - n.y
    }, Me.scale = function(t, e, n) {
      t.x = e.x * n, t.y = e.y * n
    }, Me.scaleAndAdd = function(t, e, n, i) {
      t.x = e.x + n.x * i, t.y = e.y + n.y * i
    }, Me.lerp = function(t, e, n, i) {
      var r = 1 - i;
      t.x = r * e.x + i * n.x, t.y = r * e.y + i * n.y
    }, Me);

  function Me(t, e) {
    this.x = t || 0, this.y = e || 0
  }
  var Te = Math.min,
    Ie = Math.max,
    Ce = new Se,
    ke = new Se,
    De = new Se,
    Ae = new Se,
    Le = new Se,
    Pe = new Se,
    Oe = (Re.prototype.union = function(t) {
      var e = Te(t.x, this.x),
        n = Te(t.y, this.y);
      isFinite(this.x) && isFinite(this.width) ? this.width = Ie(t.x + t.width, this.x + this.width) - e : this.width = t.width, isFinite(this.y) && isFinite(this.height) ? this.height = Ie(t.y + t.height, this.y + this.height) - n : this.height = t.height, this.x = e, this.y = n
    }, Re.prototype.applyTransform = function(t) {
      Re.applyTransform(this, this, t)
    }, Re.prototype.calculateTransform = function(t) {
      var e = t.width / this.width,
        n = t.height / this.height,
        i = [1, 0, 0, 1, 0, 0];
      return ve(i, i, [-this.x, -this.y]), xe(i, i, [e, n]), ve(i, i, [t.x, t.y]), i
    }, Re.prototype.intersect = function(t, e) {
      if (!t) return !1;
      t instanceof Re || (t = Re.create(t));
      var n, i, r, o, a, s, l, u, h = (d = this).x,
        c = d.x + d.width,
        p = d.y,
        d = d.y + d.height,
        f = t.x,
        g = t.x + t.width,
        y = t.y,
        m = (t = t.y + t.height, !(c < f || g < h || d < y || t < p));
      return e && (n = 1 / 0, i = 0, r = Math.abs(c - f), o = Math.abs(g - h), a = Math.abs(d - y), s = Math.abs(t - p), l = Math.min(r, o), u = Math.min(a, s), c < f || g < h ? i < l && (i = l, r < o ? Se.set(Pe, -r, 0) : Se.set(Pe, o, 0)) : l < n && (n = l, r < o ? Se.set(Le, r, 0) : Se.set(Le, -o, 0)), d < y || t < p ? i < u && (i = u, a < s ? Se.set(Pe, 0, -a) : Se.set(Pe, 0, s)) : l < n && (n = l, a < s ? Se.set(Le, 0, a) : Se.set(Le, 0, -s))), e && Se.copy(e, m ? Le : Pe), m
    }, Re.prototype.contain = function(t, e) {
      var n = this;
      return t >= n.x && t <= n.x + n.width && e >= n.y && e <= n.y + n.height
    }, Re.prototype.clone = function() {
      return new Re(this.x, this.y, this.width, this.height)
    }, Re.prototype.copy = function(t) {
      Re.copy(this, t)
    }, Re.prototype.plain = function() {
      return {
        x: this.x,
        y: this.y,
        width: this.width,
        height: this.height
      }
    }, Re.prototype.isFinite = function() {
      return isFinite(this.x) && isFinite(this.y) && isFinite(this.width) && isFinite(this.height)
    }, Re.prototype.isZero = function() {
      return 0 === this.width || 0 === this.height
    }, Re.create = function(t) {
      return new Re(t.x, t.y, t.width, t.height)
    }, Re.copy = function(t, e) {
      t.x = e.x, t.y = e.y, t.width = e.width, t.height = e.height
    }, Re.applyTransform = function(t, e, n) {
      var i, r, o, a;
      n ? n[1] < 1e-5 && -1e-5 < n[1] && n[2] < 1e-5 && -1e-5 < n[2] ? (i = n[0], r = n[3], o = n[4], a = n[5], t.x = e.x * i + o, t.y = e.y * r + a, t.width = e.width * i, t.height = e.height * r, t.width < 0 && (t.x += t.width, t.width = -t.width), t.height < 0 && (t.y += t.height, t.height = -t.height)) : (Ce.x = De.x = e.x, Ce.y = Ae.y = e.y, ke.x = Ae.x = e.x + e.width, ke.y = De.y = e.y + e.height, Ce.transform(n), Ae.transform(n), ke.transform(n), De.transform(n), t.x = Te(Ce.x, ke.x, De.x, Ae.x), t.y = Te(Ce.y, ke.y, De.y, Ae.y), o = Ie(Ce.x, ke.x, De.x, Ae.x), a = Ie(Ce.y, ke.y, De.y, Ae.y), t.width = o - t.x, t.height = a - t.y) : t !== e && Re.copy(t, e)
    }, Re);

  function Re(t, e, n, i) {
    n < 0 && (t += n, n = -n), i < 0 && (e += i, i = -i), this.x = t, this.y = e, this.width = n, this.height = i
  }

  function Ne() {
    ue(this.event)
  }
  i(Be, Ee = Ut), Be.prototype.dispose = function() {}, Be.prototype.setCursor = function() {};
  var Ee, ze = Be;

  function Be() {
    var t = null !== Ee && Ee.apply(this, arguments) || this;
    return t.handler = null, t
  }
  var Fe, Ve = function(t, e) {
      this.x = t, this.y = e
    },
    He = ["click", "dblclick", "mousewheel", "mouseout", "mouseup", "mousedown", "mousemove", "contextmenu"],
    We = new Oe(0, 0, 0, 0),
    Ge = (i(Ue, Fe = Ut), Ue.prototype.setHandlerProxy = function(t) {
      this.proxy && this.proxy.dispose(), t && (N(He, (function(e) {
        t.on && t.on(e, this[e], this)
      }), this), t.handler = this), this.proxy = t
    }, Ue.prototype.mousemove = function(t) {
      var e, n = Ye(this, o = t.zrX, e = t.zrY),
        i = this._hovered,
        r = i.target,
        o = (n = (r && !r.__zr && (r = (i = this.findHover(i.x, i.y)).target), this._hovered = n ? new Ve(o, e) : this.findHover(o, e))).target;
      (e = this.proxy).setCursor && e.setCursor(o ? o.cursor : "default"), r && o !== r && this.dispatchToElement(i, "mouseout", t), this.dispatchToElement(n, "mousemove", t), o && o !== r && this.dispatchToElement(n, "mouseover", t)
    }, Ue.prototype.mouseout = function(t) {
      var e = t.zrEventControl;
      "only_globalout" !== e && this.dispatchToElement(this._hovered, "mouseout", t), "no_globalout" !== e && this.trigger("globalout", {
        type: "globalout",
        event: t
      })
    }, Ue.prototype.resize = function() {
      this._hovered = new Ve(0, 0)
    }, Ue.prototype.dispatch = function(t, e) {
      (t = this[t]) && t.call(this, e)
    }, Ue.prototype.dispose = function() {
      this.proxy.dispose(), this.storage = null, this.proxy = null, this.painter = null
    }, Ue.prototype.setCursorStyle = function(t) {
      var e = this.proxy;
      e.setCursor && e.setCursor(t)
    }, Ue.prototype.dispatchToElement = function(t, e, n) {
      var i = (t = t || {}).target;
      if (!i || !i.silent) {
        for (var r = "on" + e, o = {
            type: e,
            event: n,
            target: (t = t).target,
            topTarget: t.topTarget,
            cancelBubble: !1,
            offsetX: n.zrX,
            offsetY: n.zrY,
            gestureEvent: n.gestureEvent,
            pinchX: n.pinchX,
            pinchY: n.pinchY,
            pinchScale: n.pinchScale,
            wheelDelta: n.zrDelta,
            zrByTouch: n.zrByTouch,
            which: n.which,
            stop: Ne
          }; i && (i[r] && (o.cancelBubble = !!i[r].call(i, o)), i.trigger(e, o), i = i.__hostTarget || i.parent, !o.cancelBubble););
        o.cancelBubble || (this.trigger(e, o), this.painter && this.painter.eachOtherLayer && this.painter.eachOtherLayer((function(t) {
          "function" == typeof t[r] && t[r].call(t, o), t.trigger && t.trigger(e, o)
        })))
      }
    }, Ue.prototype.findHover = function(t, e, n) {
      var i = this.storage.getDisplayList(),
        r = new Ve(t, e);
      if (Xe(i, r, t, e, n), this._pointerSize && !r.target) {
        for (var o = [], a = this._pointerSize, s = a / 2, l = new Oe(t - s, e - s, a, a), u = i.length - 1; 0 <= u; u--) {
          var h = i[u];
          h === n || h.ignore || h.ignoreCoarsePointer || h.parent && h.parent.ignoreCoarsePointer || (We.copy(h.getBoundingRect()), h.transform && We.applyTransform(h.transform), We.intersect(l) && o.push(h))
        }
        if (o.length)
          for (var c = Math.PI / 12, p = 2 * Math.PI, d = 0; d < s; d += 4)
            for (var f = 0; f < p; f += c)
              if (Xe(o, r, t + d * Math.cos(f), e + d * Math.sin(f), n), r.target) return r
      }
      return r
    }, Ue.prototype.processGesture = function(t, e) {
      this._gestureMgr || (this._gestureMgr = new he);
      var n = this._gestureMgr,
        i = ("start" === e && n.clear(), n.recognize(t, this.findHover(t.zrX, t.zrY, null).target, this.proxy.dom));
      "end" === e && n.clear(), i && (e = i.type, t.gestureEvent = e, (n = new Ve).target = i.target, this.dispatchToElement(n, e, i.event))
    }, Ue);

  function Ue(t, e, n, i, r) {
    var o = Fe.call(this) || this;
    return o._hovered = new Ve(0, 0), o.storage = t, o.painter = e, o.painterRoot = i, o._pointerSize = r, n = n || new ze, o.proxy = null, o.setHandlerProxy(n), o._draggingMgr = new Wt(o), o
  }

  function Xe(t, e, n, i, r) {
    for (var o = t.length - 1; 0 <= o; o--) {
      var a = t[o],
        s = void 0;
      if (a !== r && !a.ignore && (s = function(t, e, n) {
          if (t[t.rectHover ? "rectContain" : "contain"](e, n)) {
            for (var i = t, r = void 0, o = !1; i;) {
              if (!(o = !!i.ignoreClip || o)) {
                var a = i.getClipPath();
                if (a && !a.contain(e, n)) return !1
              }
              i.silent && (r = !0), i = (a = i.__hostTarget) || i.parent
            }
            return !r || "silent"
          }
          return !1
        }(a, n, i)) && (e.topTarget || (e.topTarget = a), "silent" !== s)) {
        e.target = a;
        break
      }
    }
  }

  function Ye(t, e, n) {
    return t = t.painter, e < 0 || e > t.getWidth() || n < 0 || n > t.getHeight()
  }
  N(["click", "mousedown", "mouseup", "mousewheel", "dblclick", "contextmenu"], (function(t) {
    Ge.prototype[t] = function(e) {
      var n, i, r = e.zrX,
        o = e.zrY,
        a = Ye(this, r, o);
      if ("mouseup" === t && a || (i = (n = this.findHover(r, o)).target), "mousedown" === t) this._downEl = i, this._downPoint = [e.zrX, e.zrY], this._upEl = i;
      else if ("mouseup" === t) this._upEl = i;
      else if ("click" === t) {
        if (this._downEl !== this._upEl || !this._downPoint || 4 < Ot(this._downPoint, [e.zrX, e.zrY])) return;
        this._downPoint = null
      }
      this.dispatchToElement(n, t, e)
    }
  }));

  function qe(t, e, n, i) {
    var r = e + 1;
    if (r === n) return 1;
    if (i(t[r++], t[e]) < 0) {
      for (; r < n && i(t[r], t[r - 1]) < 0;) r++;
      var o = t,
        a = e,
        s = r;
      for (s--; a < s;) {
        var l = o[a];
        o[a++] = o[s], o[s--] = l
      }
    } else
      for (; r < n && 0 <= i(t[r], t[r - 1]);) r++;
    return r - e
  }

  function je(t, e, n, i, r) {
    for (i === e && i++; i < n; i++) {
      for (var o, a = t[i], s = e, l = i; s < l;) r(a, t[o = s + l >>> 1]) < 0 ? l = o : s = 1 + o;
      var u = i - s;
      switch (u) {
        case 3:
          t[s + 3] = t[s + 2];
        case 2:
          t[s + 2] = t[s + 1];
        case 1:
          t[s + 1] = t[s];
          break;
        default:
          for (; 0 < u;) t[s + u] = t[s + u - 1], u--
      }
      t[s] = a
    }
  }

  function Ze(t, e, n, i, r, o) {
    var a = 0,
      s = 0,
      l = 1;
    if (0 < o(t, e[n + r])) {
      for (s = i - r; l < s && 0 < o(t, e[n + r + l]);)(l = 1 + ((a = l) << 1)) <= 0 && (l = s);
      s < l && (l = s), a += r, l += r
    } else {
      for (s = r + 1; l < s && o(t, e[n + r - l]) <= 0;)(l = 1 + ((a = l) << 1)) <= 0 && (l = s);
      i = a, a = r - (l = s < l ? s : l), l = r - i
    }
    for (a++; a < l;) {
      var u = a + (l - a >>> 1);
      0 < o(t, e[n + u]) ? a = u + 1 : l = u
    }
    return l
  }

  function Ke(t, e, n, i, r, o) {
    var a = 0,
      s = 0,
      l = 1;
    if (o(t, e[n + r]) < 0) {
      for (s = r + 1; l < s && o(t, e[n + r - l]) < 0;)(l = 1 + ((a = l) << 1)) <= 0 && (l = s);
      var u = a;
      a = r - (l = s < l ? s : l), l = r - u
    } else {
      for (s = i - r; l < s && 0 <= o(t, e[n + r + l]);)(l = 1 + ((a = l) << 1)) <= 0 && (l = s);
      s < l && (l = s), a += r, l += r
    }
    for (a++; a < l;) {
      var h = a + (l - a >>> 1);
      o(t, e[n + h]) < 0 ? l = h : a = h + 1
    }
    return l
  }

  function $e(t, e, n, i) {
    var r = (i = i || t.length) - (n = n || 0);
    if (!(r < 2)) {
      var o = 0;
      if (r < 32) je(t, n, i, n + (o = qe(t, n, i, e)), e);
      else {
        var a, s = function(t, e) {
            var n, i, r = 7,
              o = 0,
              a = [];

            function s(s) {
              var l = n[s],
                u = i[s],
                h = n[s + 1],
                c = i[s + 1];
              if (l += s = (i[s] = u + c, s === o - 3 && (n[s + 1] = n[s + 2], i[s + 1] = i[s + 2]), o--, Ke(t[h], t, l, u, 0, e)), 0 != (u -= s) && 0 !== (c = Ze(t[l + u - 1], t, h, c, c - 1, e)))
                if (u <= c) {
                  var p = l,
                    d = u,
                    f = (s = h, c),
                    g = 0;
                  for (g = 0; g < d; g++) a[g] = t[p + g];
                  var y = 0,
                    m = s,
                    v = p;
                  if (t[v++] = t[m++], 0 == --f)
                    for (g = 0; g < d; g++) t[v + g] = a[y + g];
                  else if (1 === d) {
                    for (g = 0; g < f; g++) t[v + g] = t[m + g];
                    t[v + f] = a[y]
                  } else {
                    for (var _, x, w, b = r;;) {
                      x = _ = 0, w = !1;
                      do {
                        if (e(t[m], a[y]) < 0) {
                          if (t[v++] = t[m++], x++, (_ = 0) == --f) {
                            w = !0;
                            break
                          }
                        } else if (t[v++] = a[y++], _++, x = 0, 1 == --d) {
                          w = !0;
                          break
                        }
                      } while ((_ | x) < b);
                      if (w) break;
                      do {
                        if (0 !== (_ = Ke(t[m], a, y, d, 0, e))) {
                          for (g = 0; g < _; g++) t[v + g] = a[y + g];
                          if (v += _, y += _, (d -= _) <= 1) {
                            w = !0;
                            break
                          }
                        }
                        if (t[v++] = t[m++], 0 == --f) {
                          w = !0;
                          break
                        }
                        if (0 !== (x = Ze(a[y], t, m, f, 0, e))) {
                          for (g = 0; g < x; g++) t[v + g] = t[m + g];
                          if (v += x, m += x, 0 == (f -= x)) {
                            w = !0;
                            break
                          }
                        }
                        if (t[v++] = a[y++], 1 == --d) {
                          w = !0;
                          break
                        }
                      } while (b--, 7 <= _ || 7 <= x);
                      if (w) break;
                      b < 0 && (b = 0), b += 2
                    }
                    if ((r = b) < 1 && (r = 1), 1 === d) {
                      for (g = 0; g < f; g++) t[v + g] = t[m + g];
                      t[v + f] = a[y]
                    } else {
                      if (0 === d) throw new Error;
                      for (g = 0; g < d; g++) t[v + g] = a[y + g]
                    }
                  }
                } else {
                  var S = l,
                    M = u,
                    T = h,
                    I = c,
                    C = 0;
                  for (C = 0; C < I; C++) a[C] = t[T + C];
                  var k = S + M - 1,
                    D = I - 1,
                    A = T + I - 1,
                    L = 0,
                    P = 0;
                  if (t[A--] = t[k--], 0 == --M)
                    for (L = A - (I - 1), C = 0; C < I; C++) t[L + C] = a[C];
                  else if (1 === I) {
                    for (P = 1 + (A -= M), L = 1 + (k -= M), C = M - 1; 0 <= C; C--) t[P + C] = t[L + C];
                    t[A] = a[D]
                  } else {
                    for (var O = r;;) {
                      var R = 0,
                        N = 0,
                        E = !1;
                      do {
                        if (e(a[D], t[k]) < 0) {
                          if (t[A--] = t[k--], R++, (N = 0) == --M) {
                            E = !0;
                            break
                          }
                        } else if (t[A--] = a[D--], N++, R = 0, 1 == --I) {
                          E = !0;
                          break
                        }
                      } while ((R | N) < O);
                      if (E) break;
                      do {
                        if (0 != (R = M - Ke(a[D], t, S, M, M - 1, e))) {
                          for (M -= R, P = 1 + (A -= R), L = 1 + (k -= R), C = R - 1; 0 <= C; C--) t[P + C] = t[L + C];
                          if (0 === M) {
                            E = !0;
                            break
                          }
                        }
                        if (t[A--] = a[D--], 1 == --I) {
                          E = !0;
                          break
                        }
                        if (0 != (N = I - Ze(t[k], a, 0, I, I - 1, e))) {
                          for (I -= N, P = 1 + (A -= N), L = 1 + (D -= N), C = 0; C < N; C++) t[P + C] = a[L + C];
                          if (I <= 1) {
                            E = !0;
                            break
                          }
                        }
                        if (t[A--] = t[k--], 0 == --M) {
                          E = !0;
                          break
                        }
                      } while (O--, 7 <= R || 7 <= N);
                      if (E) break;
                      O < 0 && (O = 0), O += 2
                    }
                    if ((r = O) < 1 && (r = 1), 1 === I) {
                      for (P = 1 + (A -= M), L = 1 + (k -= M), C = M - 1; 0 <= C; C--) t[P + C] = t[L + C];
                      t[A] = a[D]
                    } else {
                      if (0 === I) throw new Error;
                      for (L = A - (I - 1), C = 0; C < I; C++) t[L + C] = a[C]
                    }
                  }
                }
            }
            return n = [], i = [], {
              mergeRuns: function() {
                for (; 1 < o;) {
                  var t = o - 2;
                  if (1 <= t && i[t - 1] <= i[t] + i[t + 1] || 2 <= t && i[t - 2] <= i[t] + i[t - 1]) i[t - 1] < i[t + 1] && t--;
                  else if (i[t] > i[t + 1]) break;
                  s(t)
                }
              },
              forceMergeRuns: function() {
                for (; 1 < o;) {
                  var t = o - 2;
                  0 < t && i[t - 1] < i[t + 1] && t--, s(t)
                }
              },
              pushRun: function(t, e) {
                n[o] = t, i[o] = e, o += 1
              }
            }
          }(t, e),
          l = function(t) {
            for (var e = 0; 32 <= t;) e |= 1 & t, t >>= 1;
            return t + e
          }(r);
        do {} while ((o = qe(t, n, i, e)) < l && (je(t, n, n + (a = l < (a = r) ? l : r), n + o, e), o = a), s.pushRun(n, o), s.mergeRuns(), n += o, 0 != (r -= o));
        s.forceMergeRuns()
      }
    }
  }
  var Qe = !1;

  function Je() {
    Qe || (Qe = !0, console.warn("z / z2 / zlevel of displayable is invalid, which may cause unexpected errors"))
  }

  function tn(t, e) {
    return t.zlevel === e.zlevel ? t.z === e.z ? t.z2 - e.z2 : t.z - e.z : t.zlevel - e.zlevel
  }
  nn.prototype.traverse = function(t, e) {
    for (var n = 0; n < this._roots.length; n++) this._roots[n].traverse(t, e)
  }, nn.prototype.getDisplayList = function(t, e) {
    e = e || !1;
    var n = this._displayList;
    return !t && n.length || this.updateDisplayList(e), n
  }, nn.prototype.updateDisplayList = function(t) {
    this._displayListLen = 0;
    for (var e = this._roots, n = this._displayList, i = 0, r = e.length; i < r; i++) this._updateAndAddDisplayable(e[i], null, t);
    n.length = this._displayListLen, $e(n, tn)
  }, nn.prototype._updateAndAddDisplayable = function(t, e, n) {
    if (!t.ignore || n) {
      t.beforeUpdate(), t.update(), t.afterUpdate();
      var i = t.getClipPath();
      if (t.ignoreClip) e = null;
      else if (i) {
        e = e ? e.slice() : [];
        for (var r = i, o = t; r;) r.parent = o, r.updateTransform(), e.push(r), r = (o = r).getClipPath()
      }
      if (t.childrenRef) {
        for (var a = t.childrenRef(), s = 0; s < a.length; s++) {
          var l = a[s];
          t.__dirty && (l.__dirty |= 1), this._updateAndAddDisplayable(l, e, n)
        }
        t.__dirty = 0
      } else i = t, e && e.length ? i.__clipPaths = e : i.__clipPaths && 0 < i.__clipPaths.length && (i.__clipPaths = []), isNaN(i.z) && (Je(), i.z = 0), isNaN(i.z2) && (Je(), i.z2 = 0), isNaN(i.zlevel) && (Je(), i.zlevel = 0), this._displayList[this._displayListLen++] = i;
      (i = t.getDecalElement && t.getDecalElement()) && this._updateAndAddDisplayable(i, e, n), (i = t.getTextGuideLine()) && this._updateAndAddDisplayable(i, e, n), (i = t.getTextContent()) && this._updateAndAddDisplayable(i, e, n)
    }
  }, nn.prototype.addRoot = function(t) {
    t.__zr && t.__zr.storage === this || this._roots.push(t)
  }, nn.prototype.delRoot = function(t) {
    if (t instanceof Array)
      for (var e = 0, n = t.length; e < n; e++) this.delRoot(t[e]);
    else {
      var i = L(this._roots, t);
      0 <= i && this._roots.splice(i, 1)
    }
  }, nn.prototype.delAllRoots = function() {
    this._roots = [], this._displayList = [], this._displayListLen = 0
  }, nn.prototype.getRoots = function() {
    return this._roots
  }, nn.prototype.dispose = function() {
    this._displayList = null, this._roots = null
  };
  var en = nn;

  function nn() {
    this._roots = [], this._displayList = [], this._displayListLen = 0, this.displayableSortFunc = tn
  }
  var rn = o.hasGlobalWindow && (window.requestAnimationFrame && window.requestAnimationFrame.bind(window) || window.msRequestAnimationFrame && window.msRequestAnimationFrame.bind(window) || window.mozRequestAnimationFrame || window.webkitRequestAnimationFrame) || function(t) {
      return setTimeout(t, 16)
    },
    on = {
      linear: function(t) {
        return t
      },
      quadraticIn: function(t) {
        return t * t
      },
      quadraticOut: function(t) {
        return t * (2 - t)
      },
      quadraticInOut: function(t) {
        return (t *= 2) < 1 ? .5 * t * t : -.5 * (--t * (t - 2) - 1)
      },
      cubicIn: function(t) {
        return t * t * t
      },
      cubicOut: function(t) {
        return --t * t * t + 1
      },
      cubicInOut: function(t) {
        return (t *= 2) < 1 ? .5 * t * t * t : .5 * ((t -= 2) * t * t + 2)
      },
      quarticIn: function(t) {
        return t * t * t * t
      },
      quarticOut: function(t) {
        return 1 - --t * t * t * t
      },
      quarticInOut: function(t) {
        return (t *= 2) < 1 ? .5 * t * t * t * t : -.5 * ((t -= 2) * t * t * t - 2)
      },
      quinticIn: function(t) {
        return t * t * t * t * t
      },
      quinticOut: function(t) {
        return --t * t * t * t * t + 1
      },
      quinticInOut: function(t) {
        return (t *= 2) < 1 ? .5 * t * t * t * t * t : .5 * ((t -= 2) * t * t * t * t + 2)
      },
      sinusoidalIn: function(t) {
        return 1 - Math.cos(t * Math.PI / 2)
      },
      sinusoidalOut: function(t) {
        return Math.sin(t * Math.PI / 2)
      },
      sinusoidalInOut: function(t) {
        return .5 * (1 - Math.cos(Math.PI * t))
      },
      exponentialIn: function(t) {
        return 0 === t ? 0 : Math.pow(1024, t - 1)
      },
      exponentialOut: function(t) {
        return 1 === t ? 1 : 1 - Math.pow(2, -10 * t)
      },
      exponentialInOut: function(t) {
        return 0 === t ? 0 : 1 === t ? 1 : (t *= 2) < 1 ? .5 * Math.pow(1024, t - 1) : .5 * (2 - Math.pow(2, -10 * (t - 1)))
      },
      circularIn: function(t) {
        return 1 - Math.sqrt(1 - t * t)
      },
      circularOut: function(t) {
        return Math.sqrt(1 - --t * t)
      },
      circularInOut: function(t) {
        return (t *= 2) < 1 ? -.5 * (Math.sqrt(1 - t * t) - 1) : .5 * (Math.sqrt(1 - (t -= 2) * t) + 1)
      },
      elasticIn: function(t) {
        var e, n = .1;
        return 0 === t ? 0 : 1 === t ? 1 : (e = !n || n < 1 ? (n = 1, .1) : .4 * Math.asin(1 / n) / (2 * Math.PI), -n * Math.pow(2, 10 * --t) * Math.sin((t - e) * (2 * Math.PI) / .4))
      },
      elasticOut: function(t) {
        var e, n = .1;
        return 0 === t ? 0 : 1 === t ? 1 : (e = !n || n < 1 ? (n = 1, .1) : .4 * Math.asin(1 / n) / (2 * Math.PI), n * Math.pow(2, -10 * t) * Math.sin((t - e) * (2 * Math.PI) / .4) + 1)
      },
      elasticInOut: function(t) {
        var e, n = .1;
        return 0 === t ? 0 : 1 === t ? 1 : (e = !n || n < 1 ? (n = 1, .1) : .4 * Math.asin(1 / n) / (2 * Math.PI), (t *= 2) < 1 ? n * Math.pow(2, 10 * --t) * Math.sin((t - e) * (2 * Math.PI) / .4) * -.5 : n * Math.pow(2, -10 * --t) * Math.sin((t - e) * (2 * Math.PI) / .4) * .5 + 1)
      },
      backIn: function(t) {
        return t * t * (2.70158 * t - 1.70158)
      },
      backOut: function(t) {
        return --t * t * (2.70158 * t + 1.70158) + 1
      },
      backInOut: function(t) {
        var e = 2.5949095;
        return (t *= 2) < 1 ? t * t * ((1 + e) * t - e) * .5 : .5 * ((t -= 2) * t * ((1 + e) * t + e) + 2)
      },
      bounceIn: function(t) {
        return 1 - on.bounceOut(1 - t)
      },
      bounceOut: function(t) {
        return t < 1 / 2.75 ? 7.5625 * t * t : t < 2 / 2.75 ? 7.5625 * (t -= 1.5 / 2.75) * t + .75 : t < 2.5 / 2.75 ? 7.5625 * (t -= 2.25 / 2.75) * t + .9375 : 7.5625 * (t -= 2.625 / 2.75) * t + .984375
      },
      bounceInOut: function(t) {
        return t < .5 ? .5 * on.bounceIn(2 * t) : .5 * on.bounceOut(2 * t - 1) + .5
      }
    },
    an = Math.pow,
    sn = Math.sqrt,
    ln = sn(3),
    un = Mt(),
    hn = Mt(),
    cn = Mt();

  function pn(t) {
    return -1e-8 < t && t < 1e-8
  }

  function dn(t) {
    return 1e-8 < t || t < -1e-8
  }

  function fn(t, e, n, i, r) {
    var o = 1 - r;
    return o * o * (o * t + 3 * r * e) + r * r * (r * i + 3 * o * n)
  }

  function gn(t, e, n, i, r) {
    var o = 1 - r;
    return 3 * (((e - t) * o + 2 * (n - e) * r) * o + (i - n) * r * r)
  }

  function yn(t, e, n, i, r, o) {
    i = i + 3 * (e - n) - t;
    var a, s, l = (n = 3 * (n - 2 * e + t)) * (e = 3 * (e - t)) - 9 * i * (t = t - r),
      u = (t = e * e - 3 * n * t, 0);
    return pn(r = n * n - 3 * i * e) && pn(l) ? pn(n) ? o[0] = 0 : 0 <= (a = -e / n) && a <= 1 && (o[u++] = a) : pn(e = l * l - 4 * r * t) ? (s = -(t = l / r) / 2, 0 <= (a = -n / i + t) && a <= 1 && (o[u++] = a), 0 <= s && s <= 1 && (o[u++] = s)) : 0 < e ? (e = r * n + 1.5 * i * (-l - (t = sn(e))), 0 <= (a = (-n - ((t = (t = r * n + 1.5 * i * (-l + t)) < 0 ? -an(-t, 1 / 3) : an(t, 1 / 3)) + (e = e < 0 ? -an(-e, 1 / 3) : an(e, 1 / 3)))) / (3 * i)) && a <= 1 && (o[u++] = a)) : (t = (2 * r * n - 3 * i * l) / (2 * sn(r * r * r)), e = Math.acos(t) / 3, a = (-n - 2 * (l = sn(r)) * (t = Math.cos(e))) / (3 * i), s = (-n + l * (t + ln * Math.sin(e))) / (3 * i), r = (-n + l * (t - ln * Math.sin(e))) / (3 * i), 0 <= a && a <= 1 && (o[u++] = a), 0 <= s && s <= 1 && (o[u++] = s), 0 <= r && r <= 1 && (o[u++] = r)), u
  }

  function mn(t, e, n, i, r) {
    var o, a = 6 * n - 12 * e + 6 * t;
    i = 9 * e + 3 * i - 3 * t - 9 * n, n = 3 * e - 3 * t, e = 0;
    return pn(i) ? dn(a) && 0 <= (o = -n / a) && o <= 1 && (r[e++] = o) : pn(t = a * a - 4 * i * n) ? r[0] = -a / (2 * i) : 0 < t && (t = (-a - (n = sn(t))) / (2 * i), 0 <= (o = (-a + n) / (2 * i)) && o <= 1 && (r[e++] = o), 0 <= t) && t <= 1 && (r[e++] = t), e
  }

  function vn(t, e, n, i, r, o) {
    var a = (e - t) * r + t,
      s = ((e = (n - e) * r + e) - a) * r + a;
    r = ((e = ((n = (i - n) * r + n) - e) * r + e) - s) * r + s;
    o[0] = t, o[1] = a, o[2] = s, o[3] = r, o[4] = r, o[5] = e, o[6] = n, o[7] = i
  }

  function _n(t, e, n, i, r, o, a, s, l, u, h) {
    var c, p, d, f, g = .005,
      y = 1 / 0;
    un[0] = l, un[1] = u;
    for (var m = 0; m < 1; m += .05) hn[0] = fn(t, n, r, a, m), hn[1] = fn(e, i, o, s, m), (d = Nt(un, hn)) < y && (c = m, y = d);
    y = 1 / 0;
    for (var v = 0; v < 32 && !(g < 1e-4); v++) p = c + g, hn[0] = fn(t, n, r, a, f = c - g), hn[1] = fn(e, i, o, s, f), d = Nt(hn, un), 0 <= f && d < y ? (c = f, y = d) : (cn[0] = fn(t, n, r, a, p), cn[1] = fn(e, i, o, s, p), f = Nt(cn, un), p <= 1 && f < y ? (c = p, y = f) : g *= .5);
    return h && (h[0] = fn(t, n, r, a, c), h[1] = fn(e, i, o, s, c)), sn(y)
  }

  function xn(t, e, n, i) {
    var r = 1 - i;
    return r * (r * t + 2 * i * e) + i * i * n
  }

  function wn(t, e, n, i) {
    return 2 * ((1 - i) * (e - t) + i * (n - e))
  }

  function bn(t, e, n) {
    return 0 == (n = t + n - 2 * e) ? .5 : (t - e) / n
  }

  function Sn(t, e, n, i, r) {
    var o = (e - t) * i + t;
    i = ((e = (n - e) * i + e) - o) * i + o;
    r[0] = t, r[1] = o, r[2] = i, r[3] = i, r[4] = e, r[5] = n
  }

  function Mn(t, e, n, i, r, o, a, s, l) {
    var u, h = .005,
      c = 1 / 0;
    un[0] = a, un[1] = s;
    for (var p = 0; p < 1; p += .05) hn[0] = xn(t, n, r, p), hn[1] = xn(e, i, o, p), (y = Nt(un, hn)) < c && (u = p, c = y);
    c = 1 / 0;
    for (var d = 0; d < 32 && !(h < 1e-4); d++) {
      var f = u - h,
        g = u + h,
        y = (hn[0] = xn(t, n, r, f), hn[1] = xn(e, i, o, f), Nt(hn, un));
      0 <= f && y < c ? (u = f, c = y) : (cn[0] = xn(t, n, r, g), cn[1] = xn(e, i, o, g), f = Nt(cn, un), g <= 1 && f < c ? (u = g, c = f) : h *= .5)
    }
    return l && (l[0] = xn(t, n, r, u), l[1] = xn(e, i, o, u)), sn(c)
  }
  var Tn = /cubic-bezier\(([0-9,\.e ]+)\)/;

  function In(t) {
    if (t = t && Tn.exec(t)) {
      var e, n = +st((t = t[1].split(","))[0]),
        i = +st(t[1]),
        r = +st(t[2]),
        o = +st(t[3]);
      if (!isNaN(n + i + r + o)) return e = [],
        function(t) {
          return t <= 0 ? 0 : 1 <= t ? 1 : yn(0, n, r, 1, t, e) && fn(0, i, o, 1, e[0])
        }
    }
  }
  kn.prototype.step = function(t, e) {
    if (this._inited || (this._startTime = t + this._delay, this._inited = !0), !this._paused) {
      var n = this._life,
        i = t - this._startTime - this._pausedTime,
        r = i / n,
        o = (o = (r < 0 && (r = 0), r = Math.min(r, 1), this.easingFunc)) ? o(r) : r;
      if (this.onframe(o), 1 === r) {
        if (!this.loop) return !0;
        this._startTime = t - i % n, this._pausedTime = 0, this.onrestart()
      }
      return !1
    }
    this._pausedTime += e
  }, kn.prototype.pause = function() {
    this._paused = !0
  }, kn.prototype.resume = function() {
    this._paused = !1
  }, kn.prototype.setEasing = function(t) {
    this.easing = t, this.easingFunc = G(t) ? t : on[t] || In(t)
  };
  var Cn = kn;

  function kn(t) {
    this._inited = !1, this._startTime = 0, this._pausedTime = 0, this._paused = !1, this._life = t.life || 1e3, this._delay = t.delay || 0, this.loop = t.loop || !1, this.onframe = t.onframe || wt, this.ondestroy = t.ondestroy || wt, this.onrestart = t.onrestart || wt, t.easing && this.setEasing(t.easing)
  }
  var Dn = function(t) {
      this.value = t
    },
    An = (Ln.prototype.insert = function(t) {
      return t = new Dn(t), this.insertEntry(t), t
    }, Ln.prototype.insertEntry = function(t) {
      this.head ? ((this.tail.next = t).prev = this.tail, t.next = null, this.tail = t) : this.head = this.tail = t, this._len++
    }, Ln.prototype.remove = function(t) {
      var e = t.prev,
        n = t.next;
      e ? e.next = n : this.head = n, n ? n.prev = e : this.tail = e, t.next = t.prev = null, this._len--
    }, Ln.prototype.len = function() {
      return this._len
    }, Ln.prototype.clear = function() {
      this.head = this.tail = null, this._len = 0
    }, Ln);

  function Ln() {
    this._len = 0
  }
  On.prototype.put = function(t, e) {
    var n, i, r = this._list,
      o = this._map,
      a = null;
    return null == o[t] && (i = r.len(), n = this._lastRemovedEntry, i >= this._maxSize && 0 < i && (i = r.head, r.remove(i), delete o[i.key], a = i.value, this._lastRemovedEntry = i), n ? n.value = e : n = new Dn(e), n.key = t, r.insertEntry(n), o[t] = n), a
  }, On.prototype.get = function(t) {
    t = this._map[t];
    var e = this._list;
    if (null != t) return t !== e.tail && (e.remove(t), e.insertEntry(t)), t.value
  }, On.prototype.clear = function() {
    this._list.clear(), this._map = {}
  }, On.prototype.len = function() {
    return this._list.len()
  };
  var Pn = On;

  function On(t) {
    this._list = new An, this._maxSize = 10, this._map = {}, this._maxSize = t
  }
  var Rn = {
    transparent: [0, 0, 0, 0],
    aliceblue: [240, 248, 255, 1],
    antiquewhite: [250, 235, 215, 1],
    aqua: [0, 255, 255, 1],
    aquamarine: [127, 255, 212, 1],
    azure: [240, 255, 255, 1],
    beige: [245, 245, 220, 1],
    bisque: [255, 228, 196, 1],
    black: [0, 0, 0, 1],
    blanchedalmond: [255, 235, 205, 1],
    blue: [0, 0, 255, 1],
    blueviolet: [138, 43, 226, 1],
    brown: [165, 42, 42, 1],
    burlywood: [222, 184, 135, 1],
    cadetblue: [95, 158, 160, 1],
    chartreuse: [127, 255, 0, 1],
    chocolate: [210, 105, 30, 1],
    coral: [255, 127, 80, 1],
    cornflowerblue: [100, 149, 237, 1],
    cornsilk: [255, 248, 220, 1],
    crimson: [220, 20, 60, 1],
    cyan: [0, 255, 255, 1],
    darkblue: [0, 0, 139, 1],
    darkcyan: [0, 139, 139, 1],
    darkgoldenrod: [184, 134, 11, 1],
    darkgray: [169, 169, 169, 1],
    darkgreen: [0, 100, 0, 1],
    darkgrey: [169, 169, 169, 1],
    darkkhaki: [189, 183, 107, 1],
    darkmagenta: [139, 0, 139, 1],
    darkolivegreen: [85, 107, 47, 1],
    darkorange: [255, 140, 0, 1],
    darkorchid: [153, 50, 204, 1],
    darkred: [139, 0, 0, 1],
    darksalmon: [233, 150, 122, 1],
    darkseagreen: [143, 188, 143, 1],
    darkslateblue: [72, 61, 139, 1],
    darkslategray: [47, 79, 79, 1],
    darkslategrey: [47, 79, 79, 1],
    darkturquoise: [0, 206, 209, 1],
    darkviolet: [148, 0, 211, 1],
    deeppink: [255, 20, 147, 1],
    deepskyblue: [0, 191, 255, 1],
    dimgray: [105, 105, 105, 1],
    dimgrey: [105, 105, 105, 1],
    dodgerblue: [30, 144, 255, 1],
    firebrick: [178, 34, 34, 1],
    floralwhite: [255, 250, 240, 1],
    forestgreen: [34, 139, 34, 1],
    fuchsia: [255, 0, 255, 1],
    gainsboro: [220, 220, 220, 1],
    ghostwhite: [248, 248, 255, 1],
    gold: [255, 215, 0, 1],
    goldenrod: [218, 165, 32, 1],
    gray: [128, 128, 128, 1],
    green: [0, 128, 0, 1],
    greenyellow: [173, 255, 47, 1],
    grey: [128, 128, 128, 1],
    honeydew: [240, 255, 240, 1],
    hotpink: [255, 105, 180, 1],
    indianred: [205, 92, 92, 1],
    indigo: [75, 0, 130, 1],
    ivory: [255, 255, 240, 1],
    khaki: [240, 230, 140, 1],
    lavender: [230, 230, 250, 1],
    lavenderblush: [255, 240, 245, 1],
    lawngreen: [124, 252, 0, 1],
    lemonchiffon: [255, 250, 205, 1],
    lightblue: [173, 216, 230, 1],
    lightcoral: [240, 128, 128, 1],
    lightcyan: [224, 255, 255, 1],
    lightgoldenrodyellow: [250, 250, 210, 1],
    lightgray: [211, 211, 211, 1],
    lightgreen: [144, 238, 144, 1],
    lightgrey: [211, 211, 211, 1],
    lightpink: [255, 182, 193, 1],
    lightsalmon: [255, 160, 122, 1],
    lightseagreen: [32, 178, 170, 1],
    lightskyblue: [135, 206, 250, 1],
    lightslategray: [119, 136, 153, 1],
    lightslategrey: [119, 136, 153, 1],
    lightsteelblue: [176, 196, 222, 1],
    lightyellow: [255, 255, 224, 1],
    lime: [0, 255, 0, 1],
    limegreen: [50, 205, 50, 1],
    linen: [250, 240, 230, 1],
    magenta: [255, 0, 255, 1],
    maroon: [128, 0, 0, 1],
    mediumaquamarine: [102, 205, 170, 1],
    mediumblue: [0, 0, 205, 1],
    mediumorchid: [186, 85, 211, 1],
    mediumpurple: [147, 112, 219, 1],
    mediumseagreen: [60, 179, 113, 1],
    mediumslateblue: [123, 104, 238, 1],
    mediumspringgreen: [0, 250, 154, 1],
    mediumturquoise: [72, 209, 204, 1],
    mediumvioletred: [199, 21, 133, 1],
    midnightblue: [25, 25, 112, 1],
    mintcream: [245, 255, 250, 1],
    mistyrose: [255, 228, 225, 1],
    moccasin: [255, 228, 181, 1],
    navajowhite: [255, 222, 173, 1],
    navy: [0, 0, 128, 1],
    oldlace: [253, 245, 230, 1],
    olive: [128, 128, 0, 1],
    olivedrab: [107, 142, 35, 1],
    orange: [255, 165, 0, 1],
    orangered: [255, 69, 0, 1],
    orchid: [218, 112, 214, 1],
    palegoldenrod: [238, 232, 170, 1],
    palegreen: [152, 251, 152, 1],
    paleturquoise: [175, 238, 238, 1],
    palevioletred: [219, 112, 147, 1],
    papayawhip: [255, 239, 213, 1],
    peachpuff: [255, 218, 185, 1],
    peru: [205, 133, 63, 1],
    pink: [255, 192, 203, 1],
    plum: [221, 160, 221, 1],
    powderblue: [176, 224, 230, 1],
    purple: [128, 0, 128, 1],
    red: [255, 0, 0, 1],
    rosybrown: [188, 143, 143, 1],
    royalblue: [65, 105, 225, 1],
    saddlebrown: [139, 69, 19, 1],
    salmon: [250, 128, 114, 1],
    sandybrown: [244, 164, 96, 1],
    seagreen: [46, 139, 87, 1],
    seashell: [255, 245, 238, 1],
    sienna: [160, 82, 45, 1],
    silver: [192, 192, 192, 1],
    skyblue: [135, 206, 235, 1],
    slateblue: [106, 90, 205, 1],
    slategray: [112, 128, 144, 1],
    slategrey: [112, 128, 144, 1],
    snow: [255, 250, 250, 1],
    springgreen: [0, 255, 127, 1],
    steelblue: [70, 130, 180, 1],
    tan: [210, 180, 140, 1],
    teal: [0, 128, 128, 1],
    thistle: [216, 191, 216, 1],
    tomato: [255, 99, 71, 1],
    turquoise: [64, 224, 208, 1],
    violet: [238, 130, 238, 1],
    wheat: [245, 222, 179, 1],
    white: [255, 255, 255, 1],
    whitesmoke: [245, 245, 245, 1],
    yellow: [255, 255, 0, 1],
    yellowgreen: [154, 205, 50, 1]
  };

  function Nn(t) {
    return (t = Math.round(t)) < 0 ? 0 : 255 < t ? 255 : t
  }

  function En(t) {
    return t < 0 ? 0 : 1 < t ? 1 : t
  }

  function zn(t) {
    return t.length && "%" === t.charAt(t.length - 1) ? Nn(parseFloat(t) / 100 * 255) : Nn(parseInt(t, 10))
  }

  function Bn(t) {
    return t.length && "%" === t.charAt(t.length - 1) ? En(parseFloat(t) / 100) : En(parseFloat(t))
  }

  function Fn(t, e, n) {
    return n < 0 ? n += 1 : 1 < n && --n, 6 * n < 1 ? t + (e - t) * n * 6 : 2 * n < 1 ? e : 3 * n < 2 ? t + (e - t) * (2 / 3 - n) * 6 : t
  }

  function Vn(t, e, n) {
    return t + (e - t) * n
  }

  function Hn(t, e, n, i, r) {
    return t[0] = e, t[1] = n, t[2] = i, t[3] = r, t
  }

  function Wn(t, e) {
    return t[0] = e[0], t[1] = e[1], t[2] = e[2], t[3] = e[3], t
  }
  var Gn = new Pn(20),
    Un = null;

  function Xn(t, e) {
    Un && Wn(Un, e), Un = Gn.put(t, Un || e.slice())
  }

  function Yn(t, e) {
    if (t) {
      e = e || [];
      var n = Gn.get(t);
      if (n) return Wn(e, n);
      if ((n = (t += "").replace(/ /g, "").toLowerCase()) in Rn) return Wn(e, Rn[n]), Xn(t, e), e;
      var i = n.length;
      if ("#" === n.charAt(0)) return 4 === i || 5 === i ? 0 <= (r = parseInt(n.slice(1, 4), 16)) && r <= 4095 ? (Hn(e, (3840 & r) >> 4 | (3840 & r) >> 8, 240 & r | (240 & r) >> 4, 15 & r | (15 & r) << 4, 5 === i ? parseInt(n.slice(4), 16) / 15 : 1), Xn(t, e), e) : void Hn(e, 0, 0, 0, 1) : 7 === i || 9 === i ? 0 <= (r = parseInt(n.slice(1, 7), 16)) && r <= 16777215 ? (Hn(e, (16711680 & r) >> 16, (65280 & r) >> 8, 255 & r, 9 === i ? parseInt(n.slice(7), 16) / 255 : 1), Xn(t, e), e) : void Hn(e, 0, 0, 0, 1) : void 0;
      var r = n.indexOf("("),
        o = n.indexOf(")");
      if (-1 !== r && o + 1 === i) {
        i = n.substr(0, r);
        var a = n.substr(r + 1, o - (r + 1)).split(","),
          s = 1;
        switch (i) {
          case "rgba":
            if (4 !== a.length) return 3 === a.length ? Hn(e, +a[0], +a[1], +a[2], 1) : Hn(e, 0, 0, 0, 1);
            s = Bn(a.pop());
          case "rgb":
            return 3 <= a.length ? (Hn(e, zn(a[0]), zn(a[1]), zn(a[2]), 3 === a.length ? s : Bn(a[3])), Xn(t, e), e) : void Hn(e, 0, 0, 0, 1);
          case "hsla":
            return 4 !== a.length ? void Hn(e, 0, 0, 0, 1) : (a[3] = Bn(a[3]), qn(a, e), Xn(t, e), e);
          case "hsl":
            return 3 !== a.length ? void Hn(e, 0, 0, 0, 1) : (qn(a, e), Xn(t, e), e);
          default:
            return
        }
      }
      Hn(e, 0, 0, 0, 1)
    }
  }

  function qn(t, e) {
    var n, i = (parseFloat(t[0]) % 360 + 360) % 360 / 360,
      r = Bn(t[1]);
    return Hn(e = e || [], Nn(255 * Fn(n = 2 * (n = Bn(t[2])) - (r = n <= .5 ? n * (r + 1) : n + r - n * r), r, i + 1 / 3)), Nn(255 * Fn(n, r, i)), Nn(255 * Fn(n, r, i - 1 / 3)), 1), 4 === t.length && (e[3] = t[3]), e
  }

  function jn(t, e) {
    var n = Yn(t);
    if (n) {
      for (var i = 0; i < 3; i++) n[i] = e < 0 ? n[i] * (1 - e) | 0 : (255 - n[i]) * e + n[i] | 0, 255 < n[i] ? n[i] = 255 : n[i] < 0 && (n[i] = 0);
      return Jn(n, 4 === n.length ? "rgba" : "rgb")
    }
  }

  function Zn(t, e, n) {
    var i, r, o;
    if (e && e.length && 0 <= t && t <= 1) return n = n || [], t *= e.length - 1, i = Math.floor(t), o = Math.ceil(t), r = e[i], e = e[o], n[0] = Nn(Vn(r[0], e[0], o = t - i)), n[1] = Nn(Vn(r[1], e[1], o)), n[2] = Nn(Vn(r[2], e[2], o)), n[3] = En(Vn(r[3], e[3], o)), n
  }
  var Kn = Zn;

  function $n(t, e, n) {
    var i, r, o, a;
    if (e && e.length && 0 <= t && t <= 1) return t *= e.length - 1, i = Math.floor(t), r = Math.ceil(t), a = Yn(e[i]), e = Yn(e[r]), a = Jn([Nn(Vn(a[0], e[0], o = t - i)), Nn(Vn(a[1], e[1], o)), Nn(Vn(a[2], e[2], o)), En(Vn(a[3], e[3], o))], "rgba"), n ? {
      color: a,
      leftIndex: i,
      rightIndex: r,
      value: t
    } : a
  }
  var Qn = $n;

  function Jn(t, e) {
    var n;
    if (t && t.length) return n = t[0] + "," + t[1] + "," + t[2], "rgba" !== e && "hsva" !== e && "hsla" !== e || (n += "," + t[3]), e + "(" + n + ")"
  }

  function ti(t, e) {
    return (t = Yn(t)) ? (.299 * t[0] + .587 * t[1] + .114 * t[2]) * t[3] / 255 + (1 - t[3]) * e : 0
  }
  var ei = new Pn(100);

  function ni(t) {
    var e;
    return U(t) ? ((e = ei.get(t)) || (e = jn(t, -.1), ei.put(t, e)), e) : $(t) ? ((e = k({}, t)).colorStops = E(t.colorStops, (function(t) {
      return {
        offset: t.offset,
        color: jn(t.color, -.1)
      }
    })), e) : t
  }
  Kn = Object.freeze({
    __proto__: null,
    fastLerp: Zn,
    fastMapToColor: Kn,
    lerp: $n,
    lift: jn,
    liftColor: ni,
    lum: ti,
    mapToColor: Qn,
    modifyAlpha: function(t, e) {
      if ((t = Yn(t)) && null != e) return t[3] = En(e), Jn(t, "rgba")
    },
    modifyHSL: function(t, e, n, i) {
      var r = Yn(t);
      if (t) return r = function(t) {
        var e, n, i, r, o, a, s, l, u, h;
        if (t) return h = t[0] / 255, e = t[1] / 255, n = t[2] / 255, s = Math.min(h, e, n), r = ((i = Math.max(h, e, n)) + s) / 2, 0 == (u = i - s) ? a = o = 0 : (a = r < .5 ? u / (i + s) : u / (2 - i - s), s = ((i - h) / 6 + u / 2) / u, l = ((i - e) / 6 + u / 2) / u, u = ((i - n) / 6 + u / 2) / u, h === i ? o = u - l : e === i ? o = 1 / 3 + s - u : n === i && (o = 2 / 3 + l - s), o < 0 && (o += 1), 1 < o && --o), h = [360 * o, a, r], null != t[3] && h.push(t[3]), h
      }(r), null != e && (r[0] = (t = e, (t = Math.round(t)) < 0 ? 0 : 360 < t ? 360 : t)), null != n && (r[1] = Bn(n)), null != i && (r[2] = Bn(i)), Jn(qn(r), "rgba")
    },
    parse: Yn,
    random: function() {
      return Jn([Math.round(255 * Math.random()), Math.round(255 * Math.random()), Math.round(255 * Math.random())], "rgb")
    },
    stringify: Jn,
    toHex: function(t) {
      if (t = Yn(t)) return ((1 << 24) + (t[0] << 16) + (t[1] << 8) + +t[2]).toString(16).slice(1)
    }
  });
  var ii = Math.round;

  function ri(t) {
    var e, n;
    return t && "transparent" !== t ? "string" == typeof t && -1 < t.indexOf("rgba") && (n = Yn(t)) && (t = "rgb(" + n[0] + "," + n[1] + "," + n[2] + ")", e = n[3]) : t = "none", {
      color: t,
      opacity: null == e ? 1 : e
    }
  }

  function oi(t) {
    return t < 1e-4 && -1e-4 < t
  }

  function ai(t) {
    return ii(1e3 * t) / 1e3
  }

  function si(t) {
    return ii(1e4 * t) / 1e4
  }
  var li = {
    left: "start",
    right: "end",
    center: "middle",
    middle: "middle"
  };

  function ui(t) {
    return t && !!t.image
  }

  function hi(t) {
    return ui(t) || (t = t) && !!t.svgElement
  }

  function ci(t) {
    return "linear" === t.type
  }

  function pi(t) {
    return "radial" === t.type
  }

  function di(t) {
    return t && ("linear" === t.type || "radial" === t.type)
  }

  function fi(t) {
    return "url(#" + t + ")"
  }

  function gi(t) {
    return t = t.getGlobalScale(), t = Math.max(t[0], t[1]), Math.max(Math.ceil(Math.log(t) / Math.log(10)), 1)
  }

  function yi(t) {
    var e = t.x || 0,
      n = t.y || 0,
      i = (t.rotation || 0) * bt,
      r = nt(t.scaleX, 1),
      o = nt(t.scaleY, 1),
      a = t.skewX || 0,
      s = (t = t.skewY || 0, []);
    return (e || n) && s.push("translate(" + e + "px," + n + "px)"), i && s.push("rotate(" + i + ")"), 1 === r && 1 === o || s.push("scale(" + r + "," + o + ")"), (a || t) && s.push("skew(" + ii(a * bt) + "deg, " + ii(t * bt) + "deg)"), s.join(" ")
  }
  var mi = o.hasGlobalWindow && G(window.btoa) ? function(t) {
      return window.btoa(unescape(encodeURIComponent(t)))
    } : "undefined" != typeof Buffer ? function(t) {
      return Buffer.from(t).toString("base64")
    } : function(t) {
      return null
    },
    vi = Array.prototype.slice;

  function _i(t, e, n) {
    return (e - t) * n + t
  }

  function xi(t, e, n, i) {
    for (var r = e.length, o = 0; o < r; o++) t[o] = _i(e[o], n[o], i);
    return t
  }

  function wi(t, e, n, i) {
    for (var r = e.length, o = 0; o < r; o++) t[o] = e[o] + n[o] * i;
    return t
  }

  function bi(t, e, n, i) {
    for (var r = e.length, o = r && e[0].length, a = 0; a < r; a++) {
      t[a] || (t[a] = []);
      for (var s = 0; s < o; s++) t[a][s] = e[a][s] + n[a][s] * i
    }
    return t
  }

  function Si(t) {
    if (R(t)) {
      var e = t.length;
      if (R(t[0])) {
        for (var n = [], i = 0; i < e; i++) n.push(vi.call(t[i]));
        return n
      }
      return vi.call(t)
    }
    return t
  }

  function Mi(t) {
    return t[0] = Math.floor(t[0]) || 0, t[1] = Math.floor(t[1]) || 0, t[2] = Math.floor(t[2]) || 0, t[3] = null == t[3] ? 1 : t[3], "rgba(" + t.join(",") + ")"
  }

  function Ti(t) {
    return 4 === t || 5 === t
  }

  function Ii(t) {
    return 1 === t || 2 === t
  }
  var Ci = [0, 0, 0, 0],
    ki = (Di.prototype.isFinished = function() {
      return this._finished
    }, Di.prototype.setFinished = function() {
      this._finished = !0, this._additiveTrack && this._additiveTrack.setFinished()
    }, Di.prototype.needsAnimate = function() {
      return 1 <= this.keyframes.length
    }, Di.prototype.getAdditiveTrack = function() {
      return this._additiveTrack
    }, Di.prototype.addKeyframe = function(t, e, n) {
      this._needsSort = !0;
      var i, r = this.keyframes,
        o = r.length,
        a = !1,
        s = 6,
        l = e,
        u = (R(e) ? (1 == (s = i = R((i = e) && i[0]) ? 2 : 1) && !Y(e[0]) || 2 == i && !Y(e[0][0])) && (a = !0) : Y(e) && !tt(e) ? s = 0 : U(e) ? isNaN(+e) ? (i = Yn(e)) && (l = i, s = 3) : s = 0 : $(e) && ((u = k({}, l)).colorStops = E(e.colorStops, (function(t) {
          return {
            offset: t.offset,
            color: Yn(t.color)
          }
        })), ci(e) ? s = 4 : pi(e) && (s = 5), l = u), 0 === o ? this.valType = s : s === this.valType && 6 !== s || (a = !0), this.discrete = this.discrete || a, {
          time: t,
          value: l,
          rawValue: e,
          percent: 0
        });
      return n && (u.easing = n, u.easingFunc = G(n) ? n : on[n] || In(n)), r.push(u), u
    }, Di.prototype.prepare = function(t, e) {
      for (var n = this.keyframes, i = (this._needsSort && n.sort((function(t, e) {
          return t.time - e.time
        })), this.valType), r = n.length, o = n[r - 1], a = this.discrete, s = Ii(i), l = Ti(i), u = 0; u < r; u++) {
        var h = (g = n[u]).value,
          c = o.value;
        if (g.percent = g.time / t, !a)
          if (s && u !== r - 1) {
            _ = v = m = y = d = x = g = void 0;
            var p = i,
              d = g = h,
              f = x = c;
            if (d.push && f.push) {
              var g = d.length,
                y = f.length;
              if (g !== y)
                if (y < g) d.length = y;
                else
                  for (var m = g; m < y; m++) d.push(1 === p ? f[m] : vi.call(f[m]));
              var v = d[0] && d[0].length;
              for (m = 0; m < d.length; m++)
                if (1 === p) isNaN(d[m]) && (d[m] = f[m]);
                else
                  for (var _ = 0; _ < v; _++) isNaN(d[m][_]) && (d[m][_] = f[m][_])
            }
          } else if (l) {
          T = M = S = g = x = void 0;
          for (var x = h.colorStops, w = (g = c.colorStops, x.length), b = g.length, S = b < w ? g : x, M = S[(g = Math.min(w, b)) - 1] || {
              color: [0, 0, 0, 0],
              offset: 0
            }, T = g; T < Math.max(w, b); T++) S.push({
            offset: M.offset,
            color: M.color.slice()
          })
        }
      }
      if (!a && 5 !== i && e && this.needsAnimate() && e.needsAnimate() && i === e.valType && !e._finished) {
        this._additiveTrack = e;
        var I = n[0].value;
        for (u = 0; u < r; u++) 0 === i ? n[u].additiveValue = n[u].value - I : 3 === i ? n[u].additiveValue = wi([], n[u].value, I, -1) : Ii(i) && (n[u].additiveValue = (1 === i ? wi : bi)([], n[u].value, I, -1))
      }
    }, Di.prototype.step = function(t, e) {
      if (!this._finished) {
        this._additiveTrack && this._additiveTrack._finished && (this._additiveTrack = null);
        var n, i, r, o, a = null != this._additiveTrack,
          s = a ? "additiveValue" : "value",
          l = this.valType,
          u = this.keyframes,
          h = u.length,
          c = this.propName,
          p = 3 === l,
          d = this._lastFr,
          f = Math.min;
        if (1 === h) n = i = u[0];
        else {
          if (e < 0) g = 0;
          else if (e < this._lastFrP) {
            for (var g = f(d + 1, h - 1); 0 <= g && !(u[g].percent <= e); g--);
            g = f(g, h - 2)
          } else {
            for (g = d; g < h && !(u[g].percent > e); g++);
            g = f(g - 1, h - 2)
          }
          i = u[g + 1], n = u[g]
        }
        n && i && (this._lastFr = g, this._lastFrP = e, d = i.percent - n.percent, r = 0 == d ? 1 : f((e - n.percent) / d, 1), i.easingFunc && (r = i.easingFunc(r)), f = a ? this._additiveValue : p ? Ci : t[c], (Ii(l) || p) && (f = f || (this._additiveValue = [])), this.discrete ? t[c] = (r < 1 ? n : i).rawValue : Ii(l) ? (1 === l ? xi : function(t, e, n, i) {
          for (var r = e.length, o = r && e[0].length, a = 0; a < r; a++) {
            t[a] || (t[a] = []);
            for (var s = 0; s < o; s++) t[a][s] = _i(e[a][s], n[a][s], i)
          }
        })(f, n[s], i[s], r) : Ti(l) ? (d = n[s], o = i[s], t[c] = {
          type: (l = 4 === l) ? "linear" : "radial",
          x: _i(d.x, o.x, r),
          y: _i(d.y, o.y, r),
          colorStops: E(d.colorStops, (function(t, e) {
            return e = o.colorStops[e], {
              offset: _i(t.offset, e.offset, r),
              color: Mi(xi([], t.color, e.color, r))
            }
          })),
          global: o.global
        }, l ? (t[c].x2 = _i(d.x2, o.x2, r), t[c].y2 = _i(d.y2, o.y2, r)) : t[c].r = _i(d.r, o.r, r)) : p ? (xi(f, n[s], i[s], r), a || (t[c] = Mi(f))) : (l = _i(n[s], i[s], r), a ? this._additiveValue = l : t[c] = l), a) && this._addToTarget(t)
      }
    }, Di.prototype._addToTarget = function(t) {
      var e = this.valType,
        n = this.propName,
        i = this._additiveValue;
      0 === e ? t[n] = t[n] + i : 3 === e ? (Yn(t[n], Ci), wi(Ci, Ci, i, 1), t[n] = Mi(Ci)) : 1 === e ? wi(t[n], t[n], i, 1) : 2 === e && bi(t[n], t[n], i, 1)
    }, Di);

  function Di(t) {
    this.keyframes = [], this.discrete = !1, this._invalid = !1, this._needsSort = !1, this._lastFr = 0, this._lastFrP = 0, this.propName = t
  }
  Li.prototype.getMaxTime = function() {
    return this._maxTime
  }, Li.prototype.getDelay = function() {
    return this._delay
  }, Li.prototype.getLoop = function() {
    return this._loop
  }, Li.prototype.getTarget = function() {
    return this._target
  }, Li.prototype.changeTarget = function(t) {
    this._target = t
  }, Li.prototype.when = function(t, e, n) {
    return this.whenWithKeys(t, e, F(e), n)
  }, Li.prototype.whenWithKeys = function(t, e, n, i) {
    for (var r = this._tracks, o = 0; o < n.length; o++) {
      var a = n[o];
      if (!(l = r[a])) {
        var s, l = r[a] = new ki(a),
          u = void 0,
          h = this._getAdditiveTrack(a);
        if (h ? (u = (s = (s = h.keyframes)[s.length - 1]) && s.value, 3 === h.valType && (u = u && Mi(u))) : u = this._target[a], null == u) continue;
        0 < t && l.addKeyframe(0, Si(u), i), this._trackKeys.push(a)
      }
      l.addKeyframe(t, Si(e[a]), i)
    }
    return this._maxTime = Math.max(this._maxTime, t), this
  }, Li.prototype.pause = function() {
    this._clip.pause(), this._paused = !0
  }, Li.prototype.resume = function() {
    this._clip.resume(), this._paused = !1
  }, Li.prototype.isPaused = function() {
    return !!this._paused
  }, Li.prototype.duration = function(t) {
    return this._maxTime = t, this._force = !0, this
  }, Li.prototype._doneCallback = function() {
    this._setTracksFinished(), this._clip = null;
    var t = this._doneCbs;
    if (t)
      for (var e = t.length, n = 0; n < e; n++) t[n].call(this)
  }, Li.prototype._abortedCallback = function() {
    this._setTracksFinished();
    var t = this.animation,
      e = this._abortedCbs;
    if (t && t.removeClip(this._clip), this._clip = null, e)
      for (var n = 0; n < e.length; n++) e[n].call(this)
  }, Li.prototype._setTracksFinished = function() {
    for (var t = this._tracks, e = this._trackKeys, n = 0; n < e.length; n++) t[e[n]].setFinished()
  }, Li.prototype._getAdditiveTrack = function(t) {
    var e, n = this._additiveAnimators;
    if (n)
      for (var i = 0; i < n.length; i++) {
        var r = n[i].getTrack(t);
        r && (e = r)
      }
    return e
  }, Li.prototype.start = function(t) {
    if (!(0 < this._started)) {
      this._started = 1;
      for (var e, n = this, i = [], r = this._maxTime || 0, o = 0; o < this._trackKeys.length; o++) {
        var a = this._trackKeys[o],
          s = this._tracks[a],
          l = (a = this._getAdditiveTrack(a), s.keyframes),
          u = l.length;
        s.prepare(r, a), s.needsAnimate() && (!this._allowDiscrete && s.discrete ? ((a = l[u - 1]) && (n._target[s.propName] = a.rawValue), s.setFinished()) : i.push(s))
      }
      return i.length || this._force ? (e = new Cn({
        life: r,
        loop: this._loop,
        delay: this._delay || 0,
        onframe: function(t) {
          n._started = 2;
          var e = n._additiveAnimators;
          if (e) {
            for (var r = !1, o = 0; o < e.length; o++)
              if (e[o]._clip) {
                r = !0;
                break
              } r || (n._additiveAnimators = null)
          }
          for (o = 0; o < i.length; o++) i[o].step(n._target, t);
          var a = n._onframeCbs;
          if (a)
            for (o = 0; o < a.length; o++) a[o](n._target, t)
        },
        ondestroy: function() {
          n._doneCallback()
        }
      }), this._clip = e, this.animation && this.animation.addClip(e), t && e.setEasing(t)) : this._doneCallback(), this
    }
  }, Li.prototype.stop = function(t) {
    var e;
    this._clip && (e = this._clip, t && e.onframe(1), this._abortedCallback())
  }, Li.prototype.delay = function(t) {
    return this._delay = t, this
  }, Li.prototype.during = function(t) {
    return t && (this._onframeCbs || (this._onframeCbs = []), this._onframeCbs.push(t)), this
  }, Li.prototype.done = function(t) {
    return t && (this._doneCbs || (this._doneCbs = []), this._doneCbs.push(t)), this
  }, Li.prototype.aborted = function(t) {
    return t && (this._abortedCbs || (this._abortedCbs = []), this._abortedCbs.push(t)), this
  }, Li.prototype.getClip = function() {
    return this._clip
  }, Li.prototype.getTrack = function(t) {
    return this._tracks[t]
  }, Li.prototype.getTracks = function() {
    var t = this;
    return E(this._trackKeys, (function(e) {
      return t._tracks[e]
    }))
  }, Li.prototype.stopTracks = function(t, e) {
    if (!t.length || !this._clip) return !0;
    for (var n = this._tracks, i = this._trackKeys, r = 0; r < t.length; r++) {
      var o = n[t[r]];
      o && !o.isFinished() && (e ? o.step(this._target, 1) : 1 === this._started && o.step(this._target, 0), o.setFinished())
    }
    var a = !0;
    for (r = 0; r < i.length; r++)
      if (!n[i[r]].isFinished()) {
        a = !1;
        break
      } return a && this._abortedCallback(), a
  }, Li.prototype.saveTo = function(t, e, n) {
    if (t) {
      e = e || this._trackKeys;
      for (var i = 0; i < e.length; i++) {
        var r = e[i],
          o = this._tracks[r];
        o && !o.isFinished() && (o = (o = o.keyframes)[n ? 0 : o.length - 1]) && (t[r] = Si(o.rawValue))
      }
    }
  }, Li.prototype.__changeFinalValue = function(t, e) {
    e = e || F(t);
    for (var n = 0; n < e.length; n++) {
      var i, r = e[n],
        o = this._tracks[r];
      o && 1 < (i = o.keyframes).length && (i = i.pop(), o.addKeyframe(i.time, t[r]), o.prepare(this._maxTime, o.getAdditiveTrack()))
    }
  };
  var Ai = Li;

  function Li(t, e, n, i) {
    this._tracks = {}, this._trackKeys = [], this._maxTime = 0, this._started = 0, this._clip = null, this._target = t, (this._loop = e) && i ? T("Can' use additive animation on looped animation.") : (this._additiveAnimators = i, this._allowDiscrete = n)
  }

  function Pi() {
    return (new Date).getTime()
  }
  i(Ni, Oi = Ut), Ni.prototype.addClip = function(t) {
    t.animation && this.removeClip(t), this._head ? ((this._tail.next = t).prev = this._tail, t.next = null, this._tail = t) : this._head = this._tail = t, t.animation = this
  }, Ni.prototype.addAnimator = function(t) {
    t.animation = this, (t = t.getClip()) && this.addClip(t)
  }, Ni.prototype.removeClip = function(t) {
    var e, n;
    t.animation && (e = t.prev, n = t.next, e ? e.next = n : this._head = n, n ? n.prev = e : this._tail = e, t.next = t.prev = t.animation = null)
  }, Ni.prototype.removeAnimator = function(t) {
    var e = t.getClip();
    e && this.removeClip(e), t.animation = null
  }, Ni.prototype.update = function(t) {
    for (var e = Pi() - this._pausedTime, n = e - this._time, i = this._head; i;) {
      var r = i.next;
      i = (i.step(e, n) && (i.ondestroy(), this.removeClip(i)), r)
    }
    this._time = e, t || (this.trigger("frame", n), this.stage.update && this.stage.update())
  }, Ni.prototype._startLoop = function() {
    var t = this;
    this._running = !0, rn((function e() {
      t._running && (rn(e), t._paused || t.update())
    }))
  }, Ni.prototype.start = function() {
    this._running || (this._time = Pi(), this._pausedTime = 0, this._startLoop())
  }, Ni.prototype.stop = function() {
    this._running = !1
  }, Ni.prototype.pause = function() {
    this._paused || (this._pauseStart = Pi(), this._paused = !0)
  }, Ni.prototype.resume = function() {
    this._paused && (this._pausedTime += Pi() - this._pauseStart, this._paused = !1)
  }, Ni.prototype.clear = function() {
    for (var t = this._head; t;) {
      var e = t.next;
      t.prev = t.next = t.animation = null, t = e
    }
    this._head = this._tail = null
  }, Ni.prototype.isFinished = function() {
    return null == this._head
  }, Ni.prototype.animate = function(t, e) {
    return e = e || {}, this.start(), t = new Ai(t, e.loop), this.addAnimator(t), t
  };
  var Oi, Ri = Ni;

  function Ni(t) {
    var e = Oi.call(this) || this;
    return e._running = !1, e._time = 0, e._pausedTime = 0, e._pauseStart = 0, e._paused = !1, e.stage = (t = t || {}).stage || {}, e
  }
  var Ei, zi = o.domSupported,
    Bi = (Ei = {
      pointerdown: 1,
      pointerup: 1,
      pointermove: 1,
      pointerout: 1
    }, {
      mouse: Qn = ["click", "dblclick", "mousewheel", "wheel", "mouseout", "mouseup", "mousedown", "mousemove", "contextmenu"],
      touch: ["touchstart", "touchend", "touchmove"],
      pointer: E(Qn, (function(t) {
        var e = t.replace("mouse", "pointer");
        return Ei.hasOwnProperty(e) ? e : t
      }))
    }),
    Fi = ["mousemove", "mouseup"],
    Vi = ["pointermove", "pointerup"],
    Hi = !1;

  function Wi(t) {
    return "pen" === (t = t.pointerType) || "touch" === t
  }

  function Gi(t) {
    t && (t.zrByTouch = !0)
  }

  function Ui(t, e) {
    for (var n = e, i = !1; n && 9 !== n.nodeType && !(i = n.domBelongToZr || n !== e && n === t.painterRoot);) n = n.parentNode;
    return i
  }
  var Xi = function(t, e) {
      this.stopPropagation = wt, this.stopImmediatePropagation = wt, this.preventDefault = wt, this.type = e.type, this.target = this.currentTarget = t.dom, this.pointerType = e.pointerType, this.clientX = e.clientX, this.clientY = e.clientY
    },
    Yi = {
      mousedown: function(t) {
        t = le(this.dom, t), this.__mayPointerCapture = [t.zrX, t.zrY], this.trigger("mousedown", t)
      },
      mousemove: function(t) {
        t = le(this.dom, t);
        var e = this.__mayPointerCapture;
        !e || t.zrX === e[0] && t.zrY === e[1] || this.__togglePointerCapture(!0), this.trigger("mousemove", t)
      },
      mouseup: function(t) {
        t = le(this.dom, t), this.__togglePointerCapture(!1), this.trigger("mouseup", t)
      },
      mouseout: function(t) {
        Ui(this, (t = le(this.dom, t)).toElement || t.relatedTarget) || (this.__pointerCapturing && (t.zrEventControl = "no_globalout"), this.trigger("mouseout", t))
      },
      wheel: function(t) {
        Hi = !0, t = le(this.dom, t), this.trigger("mousewheel", t)
      },
      mousewheel: function(t) {
        Hi || (t = le(this.dom, t), this.trigger("mousewheel", t))
      },
      touchstart: function(t) {
        Gi(t = le(this.dom, t)), this.__lastTouchMoment = new Date, this.handler.processGesture(t, "start"), Yi.mousemove.call(this, t), Yi.mousedown.call(this, t)
      },
      touchmove: function(t) {
        Gi(t = le(this.dom, t)), this.handler.processGesture(t, "change"), Yi.mousemove.call(this, t)
      },
      touchend: function(t) {
        Gi(t = le(this.dom, t)), this.handler.processGesture(t, "end"), Yi.mouseup.call(this, t), +new Date - +this.__lastTouchMoment < 300 && Yi.click.call(this, t)
      },
      pointerdown: function(t) {
        Yi.mousedown.call(this, t)
      },
      pointermove: function(t) {
        Wi(t) || Yi.mousemove.call(this, t)
      },
      pointerup: function(t) {
        Yi.mouseup.call(this, t)
      },
      pointerout: function(t) {
        Wi(t) || Yi.mouseout.call(this, t)
      }
    },
    qi = (N(["click", "dblclick", "contextmenu"], (function(t) {
      Yi[t] = function(e) {
        e = le(this.dom, e), this.trigger(t, e)
      }
    })), {
      pointermove: function(t) {
        Wi(t) || qi.mousemove.call(this, t)
      },
      pointerup: function(t) {
        qi.mouseup.call(this, t)
      },
      mousemove: function(t) {
        this.trigger("mousemove", t)
      },
      mouseup: function(t) {
        var e = this.__pointerCapturing;
        this.__togglePointerCapture(!1), this.trigger("mouseup", t), e && (t.zrEventControl = "only_globalout", this.trigger("mouseout", t))
      }
    });

  function ji(t, e, n, i) {
    t.mounted[e] = n, t.listenerOpts[e] = i, t.domTarget.addEventListener(e, n, i)
  }

  function Zi(t) {
    var e, n, i, r, o, a = t.mounted;
    for (e in a) a.hasOwnProperty(e) && (n = t.domTarget, r = a[i = e], o = t.listenerOpts[e], n.removeEventListener(i, r, o));
    t.mounted = {}
  }
  var Ki, $i = function(t, e) {
      this.mounted = {}, this.listenerOpts = {}, this.touching = !1, this.domTarget = t, this.domHandlers = e
    },
    Qi = (i(Ji, Ki = Ut), Ji.prototype.dispose = function() {
      Zi(this._localHandlerScope), zi && Zi(this._globalHandlerScope)
    }, Ji.prototype.setCursor = function(t) {
      this.dom.style && (this.dom.style.cursor = t || "default")
    }, Ji.prototype.__togglePointerCapture = function(t) {
      var e;
      this.__mayPointerCapture = null, zi && +this.__pointerCapturing ^ +t && (this.__pointerCapturing = t, e = this._globalHandlerScope, t ? function(t, e) {
        function n(n) {
          ji(e, n, (function(i) {
            var r;
            i = se(i), Ui(t, i.target) || (r = i, i = le(t.dom, new Xi(t, r), !0), e.domHandlers[n].call(t, i))
          }), {
            capture: !0
          })
        }
        o.pointerEventsSupported ? N(Vi, n) : o.touchEventsSupported || N(Fi, n)
      }(this, e) : Zi(e))
    }, Ji);

  function Ji(t, e) {
    var n = Ki.call(this) || this;
    return n.__pointerCapturing = !1, n.dom = t, n.painterRoot = e, n._localHandlerScope = new $i(t, Yi), zi && (n._globalHandlerScope = new $i(document, qi)),
      function(t, e) {
        var n = e.domHandlers;
        o.pointerEventsSupported ? N(Bi.pointer, (function(i) {
          ji(e, i, (function(e) {
            n[i].call(t, e)
          }))
        })) : (o.touchEventsSupported && N(Bi.touch, (function(i) {
          ji(e, i, (function(r) {
            var o;
            n[i].call(t, r), (o = e).touching = !0, null != o.touchTimer && (clearTimeout(o.touchTimer), o.touchTimer = null), o.touchTimer = setTimeout((function() {
              o.touching = !1, o.touchTimer = null
            }), 700)
          }))
        })), N(Bi.mouse, (function(i) {
          ji(e, i, (function(r) {
            r = se(r), e.touching || n[i].call(t, r)
          }))
        })))
      }(n, n._localHandlerScope), n
  }
  Qn = 1;
  var tr = Qn = o.hasGlobalWindow ? Math.max(window.devicePixelRatio || window.screen && window.screen.deviceXDPI / window.screen.logicalXDPI || 1, 1) : Qn,
    er = "#333",
    nr = "#ccc",
    ir = ge;

  function rr(t) {
    return 5e-5 < t || t < -5e-5
  }
  var or = [],
    ar = [],
    sr = [1, 0, 0, 1, 0, 0],
    lr = Math.abs,
    ur = (hr.prototype.getLocalTransform = function(t) {
      return hr.getLocalTransform(this, t)
    }, hr.prototype.setPosition = function(t) {
      this.x = t[0], this.y = t[1]
    }, hr.prototype.setScale = function(t) {
      this.scaleX = t[0], this.scaleY = t[1]
    }, hr.prototype.setSkew = function(t) {
      this.skewX = t[0], this.skewY = t[1]
    }, hr.prototype.setOrigin = function(t) {
      this.originX = t[0], this.originY = t[1]
    }, hr.prototype.needLocalTransform = function() {
      return rr(this.rotation) || rr(this.x) || rr(this.y) || rr(this.scaleX - 1) || rr(this.scaleY - 1) || rr(this.skewX) || rr(this.skewY)
    }, hr.prototype.updateTransform = function() {
      var t = this.parent && this.parent.transform,
        e = this.needLocalTransform(),
        n = this.transform;
      e || t ? (n = n || [1, 0, 0, 1, 0, 0], e ? this.getLocalTransform(n) : ir(n), t && (e ? me(n, t, n) : ye(n, t)), this.transform = n, this._resolveGlobalScaleRatio(n)) : n && (ir(n), this.invTransform = null)
    }, hr.prototype._resolveGlobalScaleRatio = function(t) {
      var e, n, i = this.globalScaleRatio;
      null != i && 1 !== i && (this.getGlobalScale(or), n = ((or[1] - (n = or[1] < 0 ? -1 : 1)) * i + n) / or[1] || 0, t[0] *= i = ((or[0] - (e = or[0] < 0 ? -1 : 1)) * i + e) / or[0] || 0, t[1] *= i, t[2] *= n, t[3] *= n), this.invTransform = this.invTransform || [1, 0, 0, 1, 0, 0], we(this.invTransform, t)
    }, hr.prototype.getComputedTransform = function() {
      for (var t = this, e = []; t;) e.push(t), t = t.parent;
      for (; t = e.pop();) t.updateTransform();
      return this.transform
    }, hr.prototype.setLocalTransform = function(t) {
      var e, n, i, r;
      t && (r = t[0] * t[0] + t[1] * t[1], i = t[2] * t[2] + t[3] * t[3], e = Math.atan2(t[1], t[0]), n = Math.PI / 2 + e - Math.atan2(t[3], t[2]), i = Math.sqrt(i) * Math.cos(n), r = Math.sqrt(r), this.skewX = n, this.skewY = 0, this.rotation = -e, this.x = +t[4], this.y = +t[5], this.scaleX = r, this.scaleY = i, this.originX = 0, this.originY = 0)
    }, hr.prototype.decomposeTransform = function() {
      var t, e, n;
      this.transform && (e = this.parent, t = this.transform, e && e.transform && (e.invTransform = e.invTransform || [1, 0, 0, 1, 0, 0], me(ar, e.invTransform, t), t = ar), e = this.originX, n = this.originY, (e || n) && (sr[4] = e, sr[5] = n, me(ar, t, sr), ar[4] -= e, ar[5] -= n, t = ar), this.setLocalTransform(t))
    }, hr.prototype.getGlobalScale = function(t) {
      var e = this.transform;
      return t = t || [], e ? (t[0] = Math.sqrt(e[0] * e[0] + e[1] * e[1]), t[1] = Math.sqrt(e[2] * e[2] + e[3] * e[3]), e[0] < 0 && (t[0] = -t[0]), e[3] < 0 && (t[1] = -t[1])) : (t[0] = 1, t[1] = 1), t
    }, hr.prototype.transformCoordToLocal = function(t, e) {
      return t = [t, e], (e = this.invTransform) && zt(t, t, e), t
    }, hr.prototype.transformCoordToGlobal = function(t, e) {
      return t = [t, e], (e = this.transform) && zt(t, t, e), t
    }, hr.prototype.getLineScale = function() {
      var t = this.transform;
      return t && 1e-10 < lr(t[0] - 1) && 1e-10 < lr(t[3] - 1) ? Math.sqrt(lr(t[0] * t[3] - t[2] * t[1])) : 1
    }, hr.prototype.copyTransform = function(t) {
      pr(this, t)
    }, hr.getLocalTransform = function(t, e) {
      e = e || [];
      var n = t.originX || 0,
        i = t.originY || 0,
        r = t.scaleX,
        o = t.scaleY,
        a = t.anchorX,
        s = t.anchorY,
        l = t.rotation || 0,
        u = t.x,
        h = t.y,
        c = t.skewX ? Math.tan(t.skewX) : 0;
      t = t.skewY ? Math.tan(-t.skewY) : 0;
      return n || i || a || s ? (e[4] = -(a = n + a) * r - c * (s = i + s) * o, e[5] = -s * o - t * a * r) : e[4] = e[5] = 0, e[0] = r, e[3] = o, e[1] = t * r, e[2] = c * o, l && _e(e, e, l), e[4] += n + u, e[5] += i + h, e
    }, hr.initDefaultProps = ((Qn = hr.prototype).scaleX = Qn.scaleY = Qn.globalScaleRatio = 1, void(Qn.x = Qn.y = Qn.originX = Qn.originY = Qn.skewX = Qn.skewY = Qn.rotation = Qn.anchorX = Qn.anchorY = 0)), hr);

  function hr() {}
  var cr = ["x", "y", "originX", "originY", "anchorX", "anchorY", "rotation", "scaleX", "scaleY", "skewX", "skewY"];

  function pr(t, e) {
    for (var n = 0; n < cr.length; n++) {
      var i = cr[n];
      t[i] = e[i]
    }
  }
  var dr = {};

  function fr(t, e) {
    var n = dr[e = e || u],
      i = (n = n || (dr[e] = new Pn(500))).get(t);
    return null == i && (i = c.measureText(t, e).width, n.put(t, i)), i
  }

  function gr(t, e, n, i) {
    return t = fr(t, e), e = _r(e), n = mr(0, t, n), i = vr(0, e, i), new Oe(n, i, t, e)
  }

  function yr(t, e, n, i) {
    var r = ((t || "") + "").split("\n");
    if (1 === r.length) return gr(r[0], e, n, i);
    for (var o = new Oe(0, 0, 0, 0), a = 0; a < r.length; a++) {
      var s = gr(r[a], e, n, i);
      0 === a ? o.copy(s) : o.union(s)
    }
    return o
  }

  function mr(t, e, n) {
    return "right" === n ? t -= e : "center" === n && (t -= e / 2), t
  }

  function vr(t, e, n) {
    return "middle" === n ? t -= e / 2 : "bottom" === n && (t -= e), t
  }

  function _r(t) {
    return fr("国", t)
  }

  function xr(t, e) {
    return "string" == typeof t ? 0 <= t.lastIndexOf("%") ? parseFloat(t) / 100 * e : parseFloat(t) : t
  }

  function wr(t, e, n) {
    var i = e.position || "inside",
      r = null != e.distance ? e.distance : 5,
      o = n.height,
      a = n.width,
      s = o / 2,
      l = n.x,
      u = n.y,
      h = "left",
      c = "top";
    if (i instanceof Array) l += xr(i[0], n.width), u += xr(i[1], n.height), c = h = null;
    else switch (i) {
      case "left":
        l -= r, u += s, h = "right", c = "middle";
        break;
      case "right":
        l += r + a, u += s, c = "middle";
        break;
      case "top":
        l += a / 2, u -= r, h = "center", c = "bottom";
        break;
      case "bottom":
        l += a / 2, u += o + r, h = "center";
        break;
      case "inside":
        l += a / 2, u += s, h = "center", c = "middle";
        break;
      case "insideLeft":
        l += r, u += s, c = "middle";
        break;
      case "insideRight":
        l += a - r, u += s, h = "right", c = "middle";
        break;
      case "insideTop":
        l += a / 2, u += r, h = "center";
        break;
      case "insideBottom":
        l += a / 2, u += o - r, h = "center", c = "bottom";
        break;
      case "insideTopLeft":
        l += r, u += r;
        break;
      case "insideTopRight":
        l += a - r, u += r, h = "right";
        break;
      case "insideBottomLeft":
        l += r, u += o - r, c = "bottom";
        break;
      case "insideBottomRight":
        l += a - r, u += o - r, h = "right", c = "bottom"
    }
    return (t = t || {}).x = l, t.y = u, t.align = h, t.verticalAlign = c, t
  }
  var br, Sr = "__zr_normal__",
    Mr = cr.concat(["ignore"]),
    Tr = z(cr, (function(t, e) {
      return t[e] = !0, t
    }), {
      ignore: !1
    }),
    Ir = {},
    Cr = new Oe(0, 0, 0, 0);

  function kr(t) {
    this.id = M++, this.animators = [], this.currentStates = [], this.states = {}, this._init(t)
  }

  function Dr(t, e, n, i) {
    function r(t, e) {
      Object.defineProperty(e, 0, {
        get: function() {
          return t[n]
        },
        set: function(e) {
          t[n] = e
        }
      }), Object.defineProperty(e, 1, {
        get: function() {
          return t[i]
        },
        set: function(e) {
          t[i] = e
        }
      })
    }
    Object.defineProperty(br, t, {
      get: function() {
        return this[e] || r(this, this[e] = []), this[e]
      },
      set: function(t) {
        this[n] = t[0], this[i] = t[1], this[e] = t, r(this, t)
      }
    })
  }

  function Ar(t, e, n, i, r) {
    function o() {
      u = !0, --l <= 0 && (u ? h && h() : c && c())
    }

    function a() {
      --l <= 0 && (u ? h && h() : c && c())
    }
    var s = [],
      l = (function t(e, n, i, r, o, a, s, l) {
        for (var u = F(r), h = o.duration, c = o.delay, p = o.additive, d = o.setToFinal, f = !q(a), g = e.animators, y = [], m = 0; m < u.length; m++) {
          var v = u[m],
            _ = r[v];
          null != _ && null != i[v] && (f || a[v]) ? !q(_) || R(_) || $(_) ? y.push(v) : n ? l || (i[v] = _, e.updateDuringAnimation(n)) : t(e, v, i[v], _, o, a && a[v], s, l) : l || (i[v] = _, e.updateDuringAnimation(n), y.push(v))
        }
        var x = y.length;
        if (!p && x)
          for (var w, b = 0; b < g.length; b++)(S = g[b]).targetName === n && S.stopTracks(y) && (w = L(g, S), g.splice(w, 1));
        if (o.force || (x = (y = B(y, (function(t) {
            return ! function(t, e) {
              return t === e || R(t) && R(e) && function(t, e) {
                var n = t.length;
                if (n !== e.length) return !1;
                for (var i = 0; i < n; i++)
                  if (t[i] !== e[i]) return !1;
                return !0
              }(t, e)
            }(r[t], i[t])
          }))).length), 0 < x || o.force && !s.length) {
          var S, M = void 0,
            T = void 0,
            I = void 0;
          if (l)
            for (T = {}, d && (M = {}), b = 0; b < x; b++) T[v = y[b]] = i[v], d ? M[v] = r[v] : i[v] = r[v];
          else if (d)
            for (I = {}, b = 0; b < x; b++) I[v = y[b]] = Si(i[v]), Pr(i, r, v);
          (S = new Ai(i, !1, !1, p ? B(g, (function(t) {
            return t.targetName === n
          })) : null)).targetName = n, o.scope && (S.scope = o.scope), d && M && S.whenWithKeys(0, M, y), I && S.whenWithKeys(0, I, y), S.whenWithKeys(null == h ? 500 : h, l ? T : r, y).delay(c || 0), e.addAnimator(S, n), s.push(S)
        }
      }(t, "", t, e, n = n || {}, i, s, r), s.length),
      u = !1,
      h = n.done,
      c = n.aborted;
    l || h && h(), 0 < s.length && n.during && s[0].during((function(t, e) {
      n.during(e)
    }));
    for (var p = 0; p < s.length; p++) {
      var d = s[p];
      d.done(o), d.aborted(a), n.force && d.duration(n.duration), d.start(n.easing)
    }
    return s
  }

  function Lr(t, e, n) {
    for (var i = 0; i < n; i++) t[i] = e[i]
  }

  function Pr(t, e, n) {
    if (R(e[n]))
      if (R(t[n]) || (t[n] = []), Z(e[n])) {
        var i = e[n].length;
        t[n].length !== i && (t[n] = new e[n].constructor(i), Lr(t[n], e[n], i))
      } else {
        var r = e[n],
          o = t[n],
          a = r.length;
        if (R(r[0]))
          for (var s = r[0].length, l = 0; l < a; l++) o[l] ? Lr(o[l], r[l], s) : o[l] = Array.prototype.slice.call(r[l]);
        else Lr(o, r, a);
        o.length = r.length
      }
    else t[n] = e[n]
  }
  O(Qn = (kr.prototype._init = function(t) {
    this.attr(t)
  }, kr.prototype.drift = function(t, e, n) {
    switch (this.draggable) {
      case "horizontal":
        e = 0;
        break;
      case "vertical":
        t = 0
    }
    var i = this.transform;
    (i = i || (this.transform = [1, 0, 0, 1, 0, 0]))[4] += t, i[5] += e, this.decomposeTransform(), this.markRedraw()
  }, kr.prototype.beforeUpdate = function() {}, kr.prototype.afterUpdate = function() {}, kr.prototype.update = function() {
    this.updateTransform(), this.__dirty && this.updateInnerText()
  }, kr.prototype.updateInnerText = function(t) {
    var e, n, i, r, o, a, s, l, u, h, c = this._textContent;
    !c || c.ignore && !t || (this.textConfig || (this.textConfig = {}), l = (t = this.textConfig).local, i = n = void 0, r = !1, (e = c.innerTransformable).parent = l ? this : null, h = !1, e.copyTransform(c), null != t.position && (u = Cr, t.layoutRect ? u.copy(t.layoutRect) : u.copy(this.getBoundingRect()), l || u.applyTransform(this.transform), this.calculateTextPosition ? this.calculateTextPosition(Ir, t, u) : wr(Ir, t, u), e.x = Ir.x, e.y = Ir.y, n = Ir.align, i = Ir.verticalAlign, o = t.origin) && null != t.rotation && (s = a = void 0, s = "center" === o ? (a = .5 * u.width, .5 * u.height) : (a = xr(o[0], u.width), xr(o[1], u.height)), h = !0, e.originX = -e.x + a + (l ? 0 : u.x), e.originY = -e.y + s + (l ? 0 : u.y)), null != t.rotation && (e.rotation = t.rotation), (o = t.offset) && (e.x += o[0], e.y += o[1], h || (e.originX = -o[0], e.originY = -o[1])), a = null == t.inside ? "string" == typeof t.position && 0 <= t.position.indexOf("inside") : t.inside, s = this._innerTextDefaultStyle || (this._innerTextDefaultStyle = {}), h = u = l = void 0, a && this.canBeInsideText() ? (l = t.insideFill, u = t.insideStroke, null != l && "auto" !== l || (l = this.getInsideTextFill()), null != u && "auto" !== u || (u = this.getInsideTextStroke(l), h = !0)) : (l = t.outsideFill, u = t.outsideStroke, null != l && "auto" !== l || (l = this.getOutsideFill()), null != u && "auto" !== u || (u = this.getOutsideStroke(l), h = !0)), (l = l || "#000") === s.fill && u === s.stroke && h === s.autoStroke && n === s.align && i === s.verticalAlign || (r = !0, s.fill = l, s.stroke = u, s.autoStroke = h, s.align = n, s.verticalAlign = i, c.setDefaultTextStyle(s)), c.__dirty |= 1, r && c.dirtyStyle(!0))
  }, kr.prototype.canBeInsideText = function() {
    return !0
  }, kr.prototype.getInsideTextFill = function() {
    return "#fff"
  }, kr.prototype.getInsideTextStroke = function(t) {
    return "#000"
  }, kr.prototype.getOutsideFill = function() {
    return this.__zr && this.__zr.isDarkMode() ? nr : er
  }, kr.prototype.getOutsideStroke = function(t) {
    for (var e = this.__zr && this.__zr.getBackgroundColor(), n = "string" == typeof e && Yn(e), i = (n = n || [255, 255, 255, 1])[3], r = this.__zr.isDarkMode(), o = 0; o < 3; o++) n[o] = n[o] * i + (r ? 0 : 255) * (1 - i);
    return n[3] = 1, Jn(n, "rgba")
  }, kr.prototype.traverse = function(t, e) {}, kr.prototype.attrKV = function(t, e) {
    "textConfig" === t ? this.setTextConfig(e) : "textContent" === t ? this.setTextContent(e) : "clipPath" === t ? this.setClipPath(e) : "extra" === t ? (this.extra = this.extra || {}, k(this.extra, e)) : this[t] = e
  }, kr.prototype.hide = function() {
    this.ignore = !0, this.markRedraw()
  }, kr.prototype.show = function() {
    this.ignore = !1, this.markRedraw()
  }, kr.prototype.attr = function(t, e) {
    if ("string" == typeof t) this.attrKV(t, e);
    else if (q(t))
      for (var n = F(t), i = 0; i < n.length; i++) {
        var r = n[i];
        this.attrKV(r, t[r])
      }
    return this.markRedraw(), this
  }, kr.prototype.saveCurrentToNormalState = function(t) {
    this._innerSaveToNormal(t);
    for (var e = this._normalState, n = 0; n < this.animators.length; n++) {
      var i = this.animators[n],
        r = i.__fromStateTransition;
      i.getLoop() || r && r !== Sr || (r = (r = i.targetName) ? e[r] : e, i.saveTo(r))
    }
  }, kr.prototype._innerSaveToNormal = function(t) {
    var e = (e = this._normalState) || (this._normalState = {});
    t.textConfig && !e.textConfig && (e.textConfig = this.textConfig), this._savePrimaryToNormal(t, e, Mr)
  }, kr.prototype._savePrimaryToNormal = function(t, e, n) {
    for (var i = 0; i < n.length; i++) {
      var r = n[i];
      null == t[r] || r in e || (e[r] = this[r])
    }
  }, kr.prototype.hasState = function() {
    return 0 < this.currentStates.length
  }, kr.prototype.getState = function(t) {
    return this.states[t]
  }, kr.prototype.ensureState = function(t) {
    var e = this.states;
    return e[t] || (e[t] = {}), e[t]
  }, kr.prototype.clearStates = function(t) {
    this.useState(Sr, !1, t)
  }, kr.prototype.useState = function(t, e, n, i) {
    var r = t === Sr;
    if ((a = this.hasState()) || !r) {
      var o, a = this.currentStates,
        s = this.stateTransition;
      if (!(0 <= L(a, t)) || !e && 1 !== a.length) {
        if ((o = (o = this.stateProxy && !r ? this.stateProxy(t) : o) || this.states && this.states[t]) || r) return r || this.saveCurrentToNormalState(o), (a = !!(o && o.hoverLayer || i)) && this._toggleHoverLayerFlag(!0), this._applyStateObj(t, o, this._normalState, e, !n && !this.__inHover && s && 0 < s.duration, s), i = this._textContent, s = this._textGuide, i && i.useState(t, e, n, a), s && s.useState(t, e, n, a), r ? (this.currentStates = [], this._normalState = {}) : e ? this.currentStates.push(t) : this.currentStates = [t], this._updateAnimationTargets(), this.markRedraw(), !a && this.__inHover && (this._toggleHoverLayerFlag(!1), this.__dirty &= -2), o;
        T("State " + t + " not exists.")
      }
    }
  }, kr.prototype.useStates = function(t, e, n) {
    if (t.length) {
      var i = [],
        r = this.currentStates,
        o = t.length,
        a = o === r.length;
      if (a)
        for (var s = 0; s < o; s++)
          if (t[s] !== r[s]) {
            a = !1;
            break
          } if (!a) {
        for (s = 0; s < o; s++) {
          var l = t[s],
            u = void 0;
          (u = (u = this.stateProxy ? this.stateProxy(l, t) : u) || this.states[l]) && i.push(u)
        }
        n = ((h = !!((h = i[o - 1]) && h.hoverLayer || n)) && this._toggleHoverLayerFlag(!0), this._mergeStates(i));
        var h, c = this.stateTransition;
        n = (this.saveCurrentToNormalState(n), this._applyStateObj(t.join(","), n, this._normalState, !1, !e && !this.__inHover && c && 0 < c.duration, c), this._textContent), c = this._textGuide;
        n && n.useStates(t, e, h), c && c.useStates(t, e, h), this._updateAnimationTargets(), this.currentStates = t.slice(), this.markRedraw(), !h && this.__inHover && (this._toggleHoverLayerFlag(!1), this.__dirty &= -2)
      }
    } else this.clearStates()
  }, kr.prototype.isSilent = function() {
    for (var t = this.silent, e = this.parent; !t && e;) {
      if (e.silent) {
        t = !0;
        break
      }
      e = e.parent
    }
    return t
  }, kr.prototype._updateAnimationTargets = function() {
    for (var t = 0; t < this.animators.length; t++) {
      var e = this.animators[t];
      e.targetName && e.changeTarget(this[e.targetName])
    }
  }, kr.prototype.removeState = function(t) {
    var e;
    0 <= (t = L(this.currentStates, t)) && ((e = this.currentStates.slice()).splice(t, 1), this.useStates(e))
  }, kr.prototype.replaceState = function(t, e, n) {
    var i = this.currentStates.slice(),
      r = (t = L(i, t), 0 <= L(i, e));
    0 <= t ? r ? i.splice(t, 1) : i[t] = e : n && !r && i.push(e), this.useStates(i)
  }, kr.prototype.toggleState = function(t, e) {
    e ? this.useState(t, !0) : this.removeState(t)
  }, kr.prototype._mergeStates = function(t) {
    for (var e, n = {}, i = 0; i < t.length; i++) {
      var r = t[i];
      k(n, r), r.textConfig && k(e = e || {}, r.textConfig)
    }
    return e && (n.textConfig = e), n
  }, kr.prototype._applyStateObj = function(t, e, n, i, r, o) {
    for (var a = !(e && i), s = (e && e.textConfig ? (this.textConfig = k({}, (i ? this : n).textConfig), k(this.textConfig, e.textConfig)) : a && n.textConfig && (this.textConfig = n.textConfig), {}), l = !1, u = 0; u < Mr.length; u++) {
      var h = Mr[u],
        c = r && Tr[h];
      e && null != e[h] ? c ? (l = !0, s[h] = e[h]) : this[h] = e[h] : a && null != n[h] && (c ? (l = !0, s[h] = n[h]) : this[h] = n[h])
    }
    if (!r)
      for (u = 0; u < this.animators.length; u++) {
        var p = this.animators[u],
          d = p.targetName;
        p.getLoop() || p.__changeFinalValue(d ? (e || n)[d] : e || n)
      }
    l && this._transitionState(t, s, o)
  }, kr.prototype._attachComponent = function(t) {
    var e;
    t.__zr && !t.__hostTarget || t !== this && ((e = this.__zr) && t.addSelfToZr(e), t.__zr = e, t.__hostTarget = this)
  }, kr.prototype._detachComponent = function(t) {
    t.__zr && t.removeSelfFromZr(t.__zr), t.__zr = null, t.__hostTarget = null
  }, kr.prototype.getClipPath = function() {
    return this._clipPath
  }, kr.prototype.setClipPath = function(t) {
    this._clipPath && this._clipPath !== t && this.removeClipPath(), this._attachComponent(t), this._clipPath = t, this.markRedraw()
  }, kr.prototype.removeClipPath = function() {
    var t = this._clipPath;
    t && (this._detachComponent(t), this._clipPath = null, this.markRedraw())
  }, kr.prototype.getTextContent = function() {
    return this._textContent
  }, kr.prototype.setTextContent = function(t) {
    var e = this._textContent;
    e !== t && (e && e !== t && this.removeTextContent(), t.innerTransformable = new ur, this._attachComponent(t), this._textContent = t, this.markRedraw())
  }, kr.prototype.setTextConfig = function(t) {
    this.textConfig || (this.textConfig = {}), k(this.textConfig, t), this.markRedraw()
  }, kr.prototype.removeTextConfig = function() {
    this.textConfig = null, this.markRedraw()
  }, kr.prototype.removeTextContent = function() {
    var t = this._textContent;
    t && (t.innerTransformable = null, this._detachComponent(t), this._textContent = null, this._innerTextDefaultStyle = null, this.markRedraw())
  }, kr.prototype.getTextGuideLine = function() {
    return this._textGuide
  }, kr.prototype.setTextGuideLine = function(t) {
    this._textGuide && this._textGuide !== t && this.removeTextGuideLine(), this._attachComponent(t), this._textGuide = t, this.markRedraw()
  }, kr.prototype.removeTextGuideLine = function() {
    var t = this._textGuide;
    t && (this._detachComponent(t), this._textGuide = null, this.markRedraw())
  }, kr.prototype.markRedraw = function() {
    this.__dirty |= 1;
    var t = this.__zr;
    t && (this.__inHover ? t.refreshHover() : t.refresh()), this.__hostTarget && this.__hostTarget.markRedraw()
  }, kr.prototype.dirty = function() {
    this.markRedraw()
  }, kr.prototype._toggleHoverLayerFlag = function(t) {
    this.__inHover = t;
    var e = this._textContent,
      n = this._textGuide;
    e && (e.__inHover = t), n && (n.__inHover = t)
  }, kr.prototype.addSelfToZr = function(t) {
    if (this.__zr !== t) {
      this.__zr = t;
      var e = this.animators;
      if (e)
        for (var n = 0; n < e.length; n++) t.animation.addAnimator(e[n]);
      this._clipPath && this._clipPath.addSelfToZr(t), this._textContent && this._textContent.addSelfToZr(t), this._textGuide && this._textGuide.addSelfToZr(t)
    }
  }, kr.prototype.removeSelfFromZr = function(t) {
    if (this.__zr) {
      this.__zr = null;
      var e = this.animators;
      if (e)
        for (var n = 0; n < e.length; n++) t.animation.removeAnimator(e[n]);
      this._clipPath && this._clipPath.removeSelfFromZr(t), this._textContent && this._textContent.removeSelfFromZr(t), this._textGuide && this._textGuide.removeSelfFromZr(t)
    }
  }, kr.prototype.animate = function(t, e, n) {
    var i = t ? this[t] : this;
    i = new Ai(i, e, n);
    return t && (i.targetName = t), this.addAnimator(i, t), i
  }, kr.prototype.addAnimator = function(t, e) {
    var n = this.__zr,
      i = this;
    t.during((function() {
      i.updateDuringAnimation(e)
    })).done((function() {
      var e = i.animators,
        n = L(e, t);
      0 <= n && e.splice(n, 1)
    })), this.animators.push(t), n && n.animation.addAnimator(t), n && n.wakeUp()
  }, kr.prototype.updateDuringAnimation = function(t) {
    this.markRedraw()
  }, kr.prototype.stopAnimation = function(t, e) {
    for (var n = this.animators, i = n.length, r = [], o = 0; o < i; o++) {
      var a = n[o];
      t && t !== a.scope ? r.push(a) : a.stop(e)
    }
    return this.animators = r, this
  }, kr.prototype.animateTo = function(t, e, n) {
    Ar(this, t, e, n)
  }, kr.prototype.animateFrom = function(t, e, n) {
    Ar(this, t, e, n, !0)
  }, kr.prototype._transitionState = function(t, e, n, i) {
    for (var r = Ar(this, e, n, i), o = 0; o < r.length; o++) r[o].__fromStateTransition = t
  }, kr.prototype.getBoundingRect = function() {
    return null
  }, kr.prototype.getPaintRect = function() {
    return null
  }, kr.initDefaultProps = ((br = kr.prototype).type = "element", br.name = "", br.ignore = br.silent = br.isGroup = br.draggable = br.dragging = br.ignoreClip = br.__inHover = !1, br.__dirty = 1, void(Object.defineProperty && (Dr("position", "_legacyPos", "x", "y"), Dr("scale", "_legacyScale", "scaleX", "scaleY"), Dr("origin", "_legacyOrigin", "originX", "originY")))), kr), Ut), O(Qn, ur), i(Nr, Or = Qn), Nr.prototype.childrenRef = function() {
    return this._children
  }, Nr.prototype.children = function() {
    return this._children.slice()
  }, Nr.prototype.childAt = function(t) {
    return this._children[t]
  }, Nr.prototype.childOfName = function(t) {
    for (var e = this._children, n = 0; n < e.length; n++)
      if (e[n].name === t) return e[n]
  }, Nr.prototype.childCount = function() {
    return this._children.length
  }, Nr.prototype.add = function(t) {
    return t && t !== this && t.parent !== this && (this._children.push(t), this._doAdd(t)), this
  }, Nr.prototype.addBefore = function(t, e) {
    var n;
    return t && t !== this && t.parent !== this && e && e.parent === this && 0 <= (e = (n = this._children).indexOf(e)) && (n.splice(e, 0, t), this._doAdd(t)), this
  }, Nr.prototype.replace = function(t, e) {
    return 0 <= (t = L(this._children, t)) && this.replaceAt(e, t), this
  }, Nr.prototype.replaceAt = function(t, e) {
    var n = this._children,
      i = n[e];
    return t && t !== this && t.parent !== this && t !== i && (n[e] = t, i.parent = null, (n = this.__zr) && i.removeSelfFromZr(n), this._doAdd(t)), this
  }, Nr.prototype._doAdd = function(t) {
    t.parent && t.parent.remove(t);
    var e = (t.parent = this).__zr;
    e && e !== t.__zr && t.addSelfToZr(e), e && e.refresh()
  }, Nr.prototype.remove = function(t) {
    var e = this.__zr,
      n = this._children,
      i = L(n, t);
    return i < 0 || (n.splice(i, 1), t.parent = null, e && t.removeSelfFromZr(e), e && e.refresh()), this
  }, Nr.prototype.removeAll = function() {
    for (var t = this._children, e = this.__zr, n = 0; n < t.length; n++) {
      var i = t[n];
      e && i.removeSelfFromZr(e), i.parent = null
    }
    return t.length = 0, this
  }, Nr.prototype.eachChild = function(t, e) {
    for (var n = this._children, i = 0; i < n.length; i++) {
      var r = n[i];
      t.call(e, r, i)
    }
    return this
  }, Nr.prototype.traverse = function(t, e) {
    for (var n = 0; n < this._children.length; n++) {
      var i = this._children[n],
        r = t.call(e, i);
      i.isGroup && !r && i.traverse(t, e)
    }
    return this
  }, Nr.prototype.addSelfToZr = function(t) {
    Or.prototype.addSelfToZr.call(this, t);
    for (var e = 0; e < this._children.length; e++) this._children[e].addSelfToZr(t)
  }, Nr.prototype.removeSelfFromZr = function(t) {
    Or.prototype.removeSelfFromZr.call(this, t);
    for (var e = 0; e < this._children.length; e++) this._children[e].removeSelfFromZr(t)
  }, Nr.prototype.getBoundingRect = function(t) {
    for (var e = new Oe(0, 0, 0, 0), n = t || this._children, i = [], r = null, o = 0; o < n.length; o++) {
      var a, s = n[o];
      s.ignore || s.invisible || (a = s.getBoundingRect(), (s = s.getLocalTransform(i)) ? (Oe.applyTransform(e, a, s), (r = r || e.clone()).union(e)) : (r = r || a.clone()).union(a))
    }
    return r || e
  };
  var Or, Rr = Nr;

  function Nr(t) {
    var e = Or.call(this) || this;
    return e.isGroup = !0, e._children = [], e.attr(t), e
  }
  Rr.prototype.type = "group";
  var Er = {},
    zr = {};
  Vr.prototype.add = function(t) {
    !this._disposed && t && (this.storage.addRoot(t), t.addSelfToZr(this), this.refresh())
  }, Vr.prototype.remove = function(t) {
    !this._disposed && t && (this.storage.delRoot(t), t.removeSelfFromZr(this), this.refresh())
  }, Vr.prototype.configLayer = function(t, e) {
    this._disposed || (this.painter.configLayer && this.painter.configLayer(t, e), this.refresh())
  }, Vr.prototype.setBackgroundColor = function(t) {
    this._disposed || (this.painter.setBackgroundColor && this.painter.setBackgroundColor(t), this.refresh(), this._backgroundColor = t, this._darkMode = function(t) {
      if (t) {
        if ("string" == typeof t) return ti(t, 1) < .4;
        if (t.colorStops) {
          for (var e = t.colorStops, n = 0, i = e.length, r = 0; r < i; r++) n += ti(e[r].color, 1);
          return (n /= i) < .4
        }
      }
      return !1
    }(t))
  }, Vr.prototype.getBackgroundColor = function() {
    return this._backgroundColor
  }, Vr.prototype.setDarkMode = function(t) {
    this._darkMode = t
  }, Vr.prototype.isDarkMode = function() {
    return this._darkMode
  }, Vr.prototype.refreshImmediately = function(t) {
    this._disposed || (t || this.animation.update(!0), this._needsRefresh = !1, this.painter.refresh(), this._needsRefresh = !1)
  }, Vr.prototype.refresh = function() {
    this._disposed || (this._needsRefresh = !0, this.animation.start())
  }, Vr.prototype.flush = function() {
    this._disposed || this._flush(!1)
  }, Vr.prototype._flush = function(t) {
    var e, n = Pi();
    this._needsRefresh && (e = !0, this.refreshImmediately(t)), this._needsRefreshHover && (e = !0, this.refreshHoverImmediately()), t = Pi();
    e ? (this._stillFrameAccum = 0, this.trigger("rendered", {
      elapsedTime: t - n
    })) : 0 < this._sleepAfterStill && (this._stillFrameAccum++, this._stillFrameAccum > this._sleepAfterStill) && this.animation.stop()
  }, Vr.prototype.setSleepAfterStill = function(t) {
    this._sleepAfterStill = t
  }, Vr.prototype.wakeUp = function() {
    this._disposed || (this.animation.start(), this._stillFrameAccum = 0)
  }, Vr.prototype.refreshHover = function() {
    this._needsRefreshHover = !0
  }, Vr.prototype.refreshHoverImmediately = function() {
    this._disposed || (this._needsRefreshHover = !1, this.painter.refreshHover && "canvas" === this.painter.getType() && this.painter.refreshHover())
  }, Vr.prototype.resize = function(t) {
    this._disposed || (this.painter.resize((t = t || {}).width, t.height), this.handler.resize())
  }, Vr.prototype.clearAnimation = function() {
    this._disposed || this.animation.clear()
  }, Vr.prototype.getWidth = function() {
    if (!this._disposed) return this.painter.getWidth()
  }, Vr.prototype.getHeight = function() {
    if (!this._disposed) return this.painter.getHeight()
  }, Vr.prototype.setCursorStyle = function(t) {
    this._disposed || this.handler.setCursorStyle(t)
  }, Vr.prototype.findHover = function(t, e) {
    if (!this._disposed) return this.handler.findHover(t, e)
  }, Vr.prototype.on = function(t, e, n) {
    return this._disposed || this.handler.on(t, e, n), this
  }, Vr.prototype.off = function(t, e) {
    this._disposed || this.handler.off(t, e)
  }, Vr.prototype.trigger = function(t, e) {
    this._disposed || this.handler.trigger(t, e)
  }, Vr.prototype.clear = function() {
    if (!this._disposed) {
      for (var t = this.storage.getRoots(), e = 0; e < t.length; e++) t[e] instanceof Rr && t[e].removeSelfFromZr(this);
      this.storage.delAllRoots(), this.painter.clear()
    }
  }, Vr.prototype.dispose = function() {
    var t;
    this._disposed || (this.animation.stop(), this.clear(), this.storage.dispose(), this.painter.dispose(), this.handler.dispose(), this.animation = this.storage = this.painter = this.handler = null, this._disposed = !0, t = this.id, delete zr[t])
  };
  var Br, Fr = Vr;

  function Vr(t, e, n) {
    var i, r = this,
      a = (this._sleepAfterStill = 10, this._stillFrameAccum = 0, this._needsRefresh = !0, this._needsRefreshHover = !0, this._darkMode = !1, n = n || {}, this.dom = e, this.id = t, new en),
      s = n.renderer || "canvas",
      l = (s = (Er[s] || (s = F(Er)[0]), n.useDirtyRect = null != n.useDirtyRect && n.useDirtyRect, new Er[s](e, a, n, t)), e = n.ssr || s.ssrOnly, t = (this.storage = a, this.painter = s, o.node || o.worker || e ? null : new Qi(s.getViewportRoot(), s.root)), n.useCoarsePointer);
    (null == l || "auto" === l ? o.touchEventsSupported : !!l) && (i = nt(n.pointerSize, 44)), this.handler = new Ge(a, s, t, s.root, i), this.animation = new Ri({
      stage: {
        update: e ? null : function() {
          return r._flush(!0)
        }
      }
    }), e || this.animation.start()
  }

  function Hr(t, e) {
    return t = new Fr(M++, t, e), zr[t.id] = t
  }

  function Wr(t, e) {
    Er[t] = e
  }

  function Gr(t) {
    if ("function" == typeof Br) return Br(t)
  }

  function Ur(t) {
    Br = t
  }
  var Xr = Object.freeze({
    __proto__: null,
    dispose: function(t) {
      t.dispose()
    },
    disposeAll: function() {
      for (var t in zr) zr.hasOwnProperty(t) && zr[t].dispose();
      zr = {}
    },
    getElementSSRData: Gr,
    getInstance: function(t) {
      return zr[t]
    },
    init: Hr,
    registerPainter: Wr,
    registerSSRDataGetter: Ur,
    version: "5.6.0"
  });

  function Yr(t, e, n, i) {
    var r = e[0],
      o = (e = e[1], n[0]),
      a = e - r,
      s = (n = n[1]) - o;
    if (0 == a) return 0 == s ? o : (o + n) / 2;
    if (i)
      if (0 < a) {
        if (t <= r) return o;
        if (e <= t) return n
      } else {
        if (r <= t) return o;
        if (t <= e) return n
      }
    else {
      if (t === r) return o;
      if (t === e) return n
    }
    return (t - r) / a * s + o
  }

  function qr(t, e) {
    switch (t) {
      case "center":
      case "middle":
        t = "50%";
        break;
      case "left":
      case "top":
        t = "0%";
        break;
      case "right":
      case "bottom":
        t = "100%"
    }
    return U(t) ? t.replace(/^\s+|\s+$/g, "").match(/%$/) ? parseFloat(t) / 100 * e : parseFloat(t) : null == t ? NaN : +t
  }

  function jr(t, e, n) {
    return null == e && (e = 10), e = Math.min(Math.max(0, e), 20), t = (+t).toFixed(e), n ? t : +t
  }

  function Zr(t) {
    if (t = +t, isNaN(t)) return 0;
    if (1e-14 < t)
      for (var e = 1, n = 0; n < 15; n++, e *= 10)
        if (Math.round(t * e) / e === t) return n;
    return Kr(t)
  }

  function Kr(t) {
    var e = 0 < (n = (t = t.toString().toLowerCase()).indexOf("e")) ? +t.slice(n + 1) : 0,
      n = 0 < n ? n : t.length;
    t = t.indexOf(".");
    return Math.max(0, (t < 0 ? 0 : n - 1 - t) - e)
  }

  function $r(t, e) {
    var n = Math.log,
      i = Math.LN10;
    t = Math.floor(n(t[1] - t[0]) / i), n = Math.round(n(Math.abs(e[1] - e[0])) / i), e = Math.min(Math.max(-t + n, 0), 20);
    return isFinite(e) ? e : 20
  }

  function Qr(t) {
    var e = 2 * Math.PI;
    return (t % e + e) % e
  }

  function Jr(t) {
    return -1e-4 < t && t < 1e-4
  }
  var to = /^(?:(\d{4})(?:[-\/](\d{1,2})(?:[-\/](\d{1,2})(?:[T ](\d{1,2})(?::(\d{1,2})(?::(\d{1,2})(?:[.,](\d+))?)?)?(Z|[\+\-]\d\d:?\d\d)?)?)?)?)?$/;

  function eo(t) {
    var e, n;
    return t instanceof Date ? t : U(t) ? (e = to.exec(t)) ? e[8] ? (n = +e[4] || 0, "Z" !== e[8].toUpperCase() && (n -= +e[8].slice(0, 3)), new Date(Date.UTC(+e[1], +(e[2] || 1) - 1, +e[3] || 1, n, +(e[5] || 0), +e[6] || 0, e[7] ? +e[7].substring(0, 3) : 0))) : new Date(+e[1], +(e[2] || 1) - 1, +e[3] || 1, +e[4] || 0, +(e[5] || 0), +e[6] || 0, e[7] ? +e[7].substring(0, 3) : 0) : new Date(NaN) : null == t ? new Date(NaN) : new Date(Math.round(t))
  }

  function no(t) {
    return Math.pow(10, io(t))
  }

  function io(t) {
    var e;
    return 0 === t ? 0 : (e = Math.floor(Math.log(t) / Math.LN10), 10 <= t / Math.pow(10, e) && e++, e)
  }

  function ro(t, e) {
    var n = io(t),
      i = Math.pow(10, n),
      r = t / i;
    return t = (e = e ? r < 1.5 ? 1 : r < 2.5 ? 2 : r < 4 ? 3 : r < 7 ? 5 : 10 : r < 1 ? 1 : r < 2 ? 2 : r < 3 ? 3 : r < 5 ? 5 : 10) * i, -20 <= n ? +t.toFixed(n < 0 ? -n : 0) : t
  }

  function oo(t) {
    var e = parseFloat(t);
    return e == t && (0 !== e || !U(t) || t.indexOf("x") <= 0) ? e : NaN
  }

  function ao(t) {
    return !isNaN(oo(t))
  }

  function so() {
    return Math.round(9 * Math.random())
  }

  function lo(t, e) {
    return null == t ? e : null == e ? t : t * e / function t(e, n) {
      return 0 === n ? e : t(n, e % n)
    }(t, e)
  }

  function uo(t) {
    throw new Error(t)
  }

  function ho(t, e, n) {
    return (e - t) * n + t
  }
  var co = "series\0";

  function po(t) {
    return t instanceof Array ? t : null == t ? [] : [t]
  }

  function fo(t, e, n) {
    if (t) {
      t[e] = t[e] || {}, t.emphasis = t.emphasis || {}, t.emphasis[e] = t.emphasis[e] || {};
      for (var i = 0, r = n.length; i < r; i++) {
        var o = n[i];
        !t.emphasis[e].hasOwnProperty(o) && t[e].hasOwnProperty(o) && (t.emphasis[e][o] = t[e][o])
      }
    }
  }
  var go = ["fontStyle", "fontWeight", "fontSize", "fontFamily", "rich", "tag", "color", "textBorderColor", "textBorderWidth", "width", "height", "lineHeight", "align", "verticalAlign", "baseline", "shadowColor", "shadowBlur", "shadowOffsetX", "shadowOffsetY", "textShadowColor", "textShadowBlur", "textShadowOffsetX", "textShadowOffsetY", "backgroundColor", "borderColor", "borderWidth", "borderRadius", "padding"];

  function yo(t) {
    return !q(t) || W(t) || t instanceof Date ? t : t.value
  }

  function mo(t, e, n) {
    return e = _o(e[t], null), n = _o(n[t], null), null != e && null != n && e === n
  }

  function vo(t) {
    return _o(t, "")
  }

  function _o(t, e) {
    return null == t ? e : U(t) ? t : Y(t) || X(t) ? t + "" : e
  }

  function xo(t) {
    return !(!(t = t.name) || !t.indexOf(co))
  }

  function wo(t) {
    return t && null != t.id && 0 === vo(t.id).indexOf("\0_ec_\0")
  }

  function bo(t, e) {
    return null != e.dataIndexInside ? e.dataIndexInside : null != e.dataIndex ? W(e.dataIndex) ? E(e.dataIndex, (function(e) {
      return t.indexOfRawIndex(e)
    })) : t.indexOfRawIndex(e.dataIndex) : null != e.name ? W(e.name) ? E(e.name, (function(e) {
      return t.indexOfName(e)
    })) : t.indexOfName(e.name) : void 0
  }

  function So() {
    var t = "__ec_inner_" + Mo++;
    return function(e) {
      return e[t] || (e[t] = {})
    }
  }
  var Mo = so();

  function To(t, e, n) {
    var i = (e = Io(e, n)).mainTypeSpecified,
      r = e.queryOptionMap,
      o = e.others,
      a = n ? n.defaultMainType : null;
    return !i && a && r.set(a, {}), r.each((function(e, i) {
      e = ko(t, i, e, {
        useDefault: a === i,
        enableAll: !n || null == n.enableAll || n.enableAll,
        enableNone: !n || null == n.enableNone || n.enableNone
      }), o[i + "Models"] = e.models, o[i + "Model"] = e.models[0]
    })), o
  }

  function Io(t, e) {
    var n = U(t) ? ((n = {})[t + "Index"] = 0, n) : t,
      i = yt(),
      r = {},
      o = !1;
    return N(n, (function(t, n) {
      var a;
      "dataIndex" === n || "dataIndexInside" === n ? r[n] = t : (a = (n = n.match(/^(\w+)(Index|Id|Name)$/) || [])[1], n = (n[2] || "").toLowerCase(), !a || !n || e && e.includeMainTypes && L(e.includeMainTypes, a) < 0 || (o = o || !!a, (i.get(a) || i.set(a, {}))[n] = t))
    })), {
      mainTypeSpecified: o,
      queryOptionMap: i,
      others: r
    }
  }
  var Co = {
    useDefault: !0,
    enableAll: !1,
    enableNone: !1
  };

  function ko(t, e, n, i) {
    i = i || Co;
    var r = n.index,
      o = n.id,
      a = (n = n.name, {
        models: null,
        specified: null != r || null != o || null != n
      });
    return a.specified ? "none" === r || !1 === r ? (at(i.enableNone, '`"none"` or `false` is not a valid value on index option.'), a.models = []) : ("all" === r && (at(i.enableAll, '`"all"` is not a valid value on index option.'), r = o = n = null), a.models = t.queryComponents({
      mainType: e,
      index: r,
      id: o,
      name: n
    })) : (r = void 0, a.models = i.useDefault && (r = t.getComponent(e)) ? [r] : []), a
  }

  function Do(t, e, n) {
    t.setAttribute ? t.setAttribute(e, n) : t[e] = n
  }

  function Ao(t, e, n, i, r) {
    var o = null == e || "auto" === e;
    if (null == i) return i;
    if (Y(i)) return jr(p = ho(n || 0, i, r), o ? Math.max(Zr(n || 0), Zr(i)) : e);
    if (U(i)) return r < 1 ? n : i;
    for (var a = [], s = n, l = i, u = Math.max(s ? s.length : 0, l.length), h = 0; h < u; ++h) {
      var c, p, d = t.getDimensionInfo(h);
      d && "ordinal" === d.type ? a[h] = (r < 1 && s ? s : l)[h] : (p = ho(d = s && s[h] ? s[h] : 0, c = l[h], r), a[h] = jr(p, o ? Math.max(Zr(d), Zr(c)) : e))
    }
    return a
  }
  var Lo = "___EC__COMPONENT__CONTAINER___",
    Po = "___EC__EXTENDED_CLASS___";

  function Oo(t) {
    var e = {
      main: "",
      sub: ""
    };
    return t && (t = t.split("."), e.main = t[0] || "", e.sub = t[1] || ""), e
  }

  function Ro(t) {
    (t.$constructor = t).extend = function(t) {
      var e, n, r, o = this;

      function a() {
        return n.apply(this, arguments) || this
      }
      return G(r = o) && /^class\s/.test(Function.prototype.toString.call(r)) ? (i(a, n = o), e = a) : P(e = function() {
        (t.$constructor || o).apply(this, arguments)
      }, this), k(e.prototype, t), e[Po] = !0, e.extend = this.extend, e.superCall = zo, e.superApply = Bo, e.superClass = o, e
    }
  }

  function No(t, e) {
    t.extend = e.extend
  }
  var Eo = Math.round(10 * Math.random());

  function zo(t, e) {
    for (var n = [], i = 2; i < arguments.length; i++) n[i - 2] = arguments[i];
    return this.superClass.prototype[e].apply(t, n)
  }

  function Bo(t, e, n) {
    return this.superClass.prototype[e].apply(t, n)
  }

  function Fo(t) {
    var e = {};
    t.registerClass = function(t) {
      var n, i = t.type || t.prototype.type;
      return i && (at(/^[a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)?$/.test(n = i), 'componentType "' + n + '" illegal'), (n = Oo(t.prototype.type = i)).sub ? n.sub !== Lo && ((function(t) {
        var n = e[t.main];
        return n && n[Lo] || (n = e[t.main] = {
          ___EC__COMPONENT__CONTAINER___: !0
        }), n
      }(n))[n.sub] = t) : e[n.main] = t), t
    }, t.getClass = function(t, n, i) {
      var r = e[t];
      if (r && r[Lo] && (r = n ? r[n] : null), i && !r) throw new Error(n ? "Component " + t + "." + (n || "") + " is used but not imported." : t + ".type should be specified.");
      return r
    }, t.getClassesByMainType = function(t) {
      t = Oo(t);
      var n = [];
      return (t = e[t.main]) && t[Lo] ? N(t, (function(t, e) {
        e !== Lo && n.push(t)
      })) : n.push(t), n
    }, t.hasClass = function(t) {
      return t = Oo(t), !!e[t.main]
    }, t.getAllClassMainTypes = function() {
      var t = [];
      return N(e, (function(e, n) {
        t.push(n)
      })), t
    }, t.hasSubTypes = function(t) {
      return t = Oo(t), (t = e[t.main]) && t[Lo]
    }
  }

  function Vo(t, e) {
    for (var n = 0; n < t.length; n++) t[n][1] || (t[n][1] = t[n][0]);
    return e = e || !1,
      function(n, i, r) {
        for (var o = {}, a = 0; a < t.length; a++) {
          var s = t[a][1];
          i && 0 <= L(i, s) || r && L(r, s) < 0 || null != (s = n.getShallow(s, e)) && (o[t[a][0]] = s)
        }
        return o
      }
  }
  var Ho = Vo([
      ["fill", "color"],
      ["shadowBlur"],
      ["shadowOffsetX"],
      ["shadowOffsetY"],
      ["opacity"],
      ["shadowColor"]
    ]),
    Wo = (Go.prototype.getAreaStyle = function(t, e) {
      return Ho(this, t, e)
    }, Go);

  function Go() {}
  var Uo = new Pn(50);

  function Xo(t, e, n, i, r) {
    return t ? "string" == typeof t ? (e && e.__zrImageSrc === t || !n || (n = {
      hostEl: n,
      cb: i,
      cbPayload: r
    }, (i = Uo.get(t)) ? qo(e = i.image) || i.pending.push(n) : ((e = c.loadImage(t, Yo, Yo)).__zrImageSrc = t, Uo.put(t, e.__cachedImgObj = {
      image: e,
      pending: [n]
    }))), e) : t : e
  }

  function Yo() {
    var t = this.__cachedImgObj;
    this.onload = this.onerror = this.__cachedImgObj = null;
    for (var e = 0; e < t.pending.length; e++) {
      var n = t.pending[e],
        i = n.cb;
      i && i(this, n.cbPayload), n.hostEl.dirty()
    }
    t.pending.length = 0
  }

  function qo(t) {
    return t && t.width && t.height
  }
  var jo = /\{([a-zA-Z0-9_]+)\|([^}]*)\}/g;

  function Zo(t, e, n, i, r) {
    if (!e) return "";
    var o = (t + "").split("\n");
    r = Ko(e, n, i, r);
    for (var a = 0, s = o.length; a < s; a++) o[a] = $o(o[a], r);
    return o.join("\n")
  }

  function Ko(t, e, n, i) {
    for (var r = k({}, i = i || {}), o = (r.font = e, n = nt(n, "..."), r.maxIterations = nt(i.maxIterations, 2), r.minChar = nt(i.minChar, 0)), a = (r.cnCharWidth = fr("国", e), r.ascCharWidth = fr("a", e)), s = (r.placeholder = nt(i.placeholder, ""), t = Math.max(0, t - 1)), l = 0; l < o && a <= s; l++) s -= a;
    return s < (i = fr(n, e)) && (n = "", i = 0), s = t - i, r.ellipsis = n, r.ellipsisWidth = i, r.contentWidth = s, r.containerWidth = t, r
  }

  function $o(t, e) {
    var n = e.containerWidth,
      i = e.font,
      r = e.contentWidth;
    if (!n) return "";
    if (!((s = fr(t, i)) <= n)) {
      for (var o = 0;; o++) {
        if (s <= r || o >= e.maxIterations) {
          t += e.ellipsis;
          break
        }
        var a = 0 === o ? function(t, e, n, i) {
            for (var r = 0, o = 0, a = t.length; o < a && r < e; o++) {
              var s = t.charCodeAt(o);
              r += 0 <= s && s <= 127 ? n : i
            }
            return o
          }(t, r, e.ascCharWidth, e.cnCharWidth) : 0 < s ? Math.floor(t.length * r / s) : 0,
          s = fr(t = t.substr(0, a), i)
      }
      "" === t && (t = e.placeholder)
    }
    return t
  }
  var Qo = function() {},
    Jo = function(t) {
      this.tokens = [], t && (this.tokens = t)
    },
    ta = function() {
      this.width = 0, this.height = 0, this.contentWidth = 0, this.contentHeight = 0, this.outerWidth = 0, this.outerHeight = 0, this.lines = []
    };

  function ea(t, e, n, i, r) {
    var o, a, s = "" === e,
      l = r && n.rich[r] || {},
      u = t.lines,
      h = l.font || n.font,
      c = !1;
    i ? (n = (t = l.padding) ? t[1] + t[3] : 0, null != l.width && "auto" !== l.width ? (t = xr(l.width, i.width) + n, 0 < u.length && t + i.accumWidth > i.width && (o = e.split("\n"), c = !0), i.accumWidth = t) : (t = ia(e, h, i.width, i.breakAll, i.accumWidth), i.accumWidth = t.accumWidth + n, a = t.linesWidths, o = t.lines)) : o = e.split("\n");
    for (var p = 0; p < o.length; p++) {
      var d, f, g = o[p],
        y = new Qo;
      y.styleName = r, y.text = g, y.isLineHolder = !g && !s, "number" == typeof l.width ? y.width = l.width : y.width = a ? a[p] : fr(g, h), p || c ? u.push(new Jo([y])) : 1 === (f = (d = (u[u.length - 1] || (u[0] = new Jo)).tokens).length) && d[0].isLineHolder ? d[0] = y : !g && f && !s || d.push(y)
    }
  }
  var na = z(",&?/;] ".split(""), (function(t, e) {
    return t[e] = !0, t
  }), {});

  function ia(t, e, n, i, r) {
    for (var o, a = [], s = [], l = "", u = "", h = 0, c = 0, p = 0; p < t.length; p++) {
      var d, f, g = t.charAt(p);
      "\n" === g ? (u && (l += u, c += h), a.push(l), s.push(c), u = l = "", c = h = 0) : (d = fr(g, e), f = !(i || (f = void 0, !(32 <= (f = (f = o = g).charCodeAt(0)) && f <= 591 || 880 <= f && f <= 4351 || 4608 <= f && f <= 5119 || 7680 <= f && f <= 8303)) || na[o]), (a.length ? n < c + d : n < r + c + d) ? c ? (l || u) && (c = f ? (l || (l = u, u = "", c = h = 0), a.push(l), s.push(c - h), u += g, l = "", h += d) : (u && (l += u, u = "", h = 0), a.push(l), s.push(c), l = g, d)) : f ? (a.push(u), s.push(h), u = g, h = d) : (a.push(g), s.push(d)) : (c += d, f ? (u += g, h += d) : (u && (l += u, u = "", h = 0), l += g)))
    }
    return a.length || l || (l = t, u = "", h = 0), u && (l += u), l && (a.push(l), s.push(c)), 1 === a.length && (c += r), {
      accumWidth: c,
      lines: a,
      linesWidths: s
    }
  }
  var ra, oa = "__zr_style_" + Math.round(10 * Math.random()),
    aa = {
      shadowBlur: 0,
      shadowOffsetX: 0,
      shadowOffsetY: 0,
      shadowColor: "#000",
      opacity: 1,
      blend: "source-over"
    },
    sa = {
      style: {
        shadowBlur: !0,
        shadowOffsetX: !0,
        shadowOffsetY: !0,
        shadowColor: !0,
        opacity: !0
      }
    },
    la = (aa[oa] = !0, ["z", "z2", "invisible"]),
    ua = ["invisible"];
  i(ha, ra = Qn), ha.prototype._init = function(t) {
    for (var e = F(t), n = 0; n < e.length; n++) {
      var i = e[n];
      "style" === i ? this.useStyle(t[i]) : ra.prototype.attrKV.call(this, i, t[i])
    }
    this.style || this.useStyle({})
  }, ha.prototype.beforeBrush = function() {}, ha.prototype.afterBrush = function() {}, ha.prototype.innerBeforeBrush = function() {}, ha.prototype.innerAfterBrush = function() {}, ha.prototype.shouldBePainted = function(t, e, n, i) {
    var r = this.transform;
    if (this.ignore || this.invisible || 0 === this.style.opacity || this.culling && function(t, e, n) {
        return ca.copy(t.getBoundingRect()), t.transform && ca.applyTransform(t.transform), pa.width = e, pa.height = n, !ca.intersect(pa)
      }(this, t, e) || r && !r[0] && !r[3]) return !1;
    if (n && this.__clipPaths)
      for (var o = 0; o < this.__clipPaths.length; ++o)
        if (this.__clipPaths[o].isZeroArea()) return !1;
    if (i && this.parent)
      for (var a = this.parent; a;) {
        if (a.ignore) return !1;
        a = a.parent
      }
    return !0
  }, ha.prototype.contain = function(t, e) {
    return this.rectContain(t, e)
  }, ha.prototype.traverse = function(t, e) {
    t.call(e, this)
  }, ha.prototype.rectContain = function(t, e) {
    return t = this.transformCoordToLocal(t, e), this.getBoundingRect().contain(t[0], t[1])
  }, ha.prototype.getPaintRect = function() {
    var t, e, n, i, r, o = this._paintRect;
    return this._paintRect && !this.__dirty || (r = this.transform, t = this.getBoundingRect(), e = (i = this.style).shadowBlur || 0, n = i.shadowOffsetX || 0, i = i.shadowOffsetY || 0, o = this._paintRect || (this._paintRect = new Oe(0, 0, 0, 0)), r ? Oe.applyTransform(o, t, r) : o.copy(t), (e || n || i) && (o.width += 2 * e + Math.abs(n), o.height += 2 * e + Math.abs(i), o.x = Math.min(o.x, o.x + n - e), o.y = Math.min(o.y, o.y + i - e)), r = this.dirtyRectTolerance, o.isZero()) || (o.x = Math.floor(o.x - r), o.y = Math.floor(o.y - r), o.width = Math.ceil(o.width + 1 + 2 * r), o.height = Math.ceil(o.height + 1 + 2 * r)), o
  }, ha.prototype.setPrevPaintRect = function(t) {
    t ? (this._prevPaintRect = this._prevPaintRect || new Oe(0, 0, 0, 0), this._prevPaintRect.copy(t)) : this._prevPaintRect = null
  }, ha.prototype.getPrevPaintRect = function() {
    return this._prevPaintRect
  }, ha.prototype.animateStyle = function(t) {
    return this.animate("style", t)
  }, ha.prototype.updateDuringAnimation = function(t) {
    "style" === t ? this.dirtyStyle() : this.markRedraw()
  }, ha.prototype.attrKV = function(t, e) {
    "style" !== t ? ra.prototype.attrKV.call(this, t, e) : this.style ? this.setStyle(e) : this.useStyle(e)
  }, ha.prototype.setStyle = function(t, e) {
    return "string" == typeof t ? this.style[t] = e : k(this.style, t), this.dirtyStyle(), this
  }, ha.prototype.dirtyStyle = function(t) {
    t || this.markRedraw(), this.__dirty |= 2, this._rect && (this._rect = null)
  }, ha.prototype.dirty = function() {
    this.dirtyStyle()
  }, ha.prototype.styleChanged = function() {
    return !!(2 & this.__dirty)
  }, ha.prototype.styleUpdated = function() {
    this.__dirty &= -3
  }, ha.prototype.createStyle = function(t) {
    return vt(aa, t)
  }, ha.prototype.useStyle = function(t) {
    t[oa] || (t = this.createStyle(t)), this.__inHover ? this.__hoverStyle = t : this.style = t, this.dirtyStyle()
  }, ha.prototype.isStyleObject = function(t) {
    return t[oa]
  }, ha.prototype._innerSaveToNormal = function(t) {
    ra.prototype._innerSaveToNormal.call(this, t);
    var e = this._normalState;
    t.style && !e.style && (e.style = this._mergeStyle(this.createStyle(), this.style)), this._savePrimaryToNormal(t, e, la)
  }, ha.prototype._applyStateObj = function(t, e, n, i, r, o) {
    ra.prototype._applyStateObj.call(this, t, e, n, i, r, o);
    var a, s = !(e && i);
    if (e && e.style ? r ? i ? a = e.style : (a = this._mergeStyle(this.createStyle(), n.style), this._mergeStyle(a, e.style)) : (a = this._mergeStyle(this.createStyle(), (i ? this : n).style), this._mergeStyle(a, e.style)) : s && (a = n.style), a)
      if (r) {
        var l = this.style;
        if (this.style = this.createStyle(s ? {} : l), s)
          for (var u = F(l), h = 0; h < u.length; h++)(p = u[h]) in a && (a[p] = a[p], this.style[p] = l[p]);
        var c = F(a);
        for (h = 0; h < c.length; h++) {
          var p = c[h];
          this.style[p] = this.style[p]
        }
        this._transitionState(t, {
          style: a
        }, o, this.getAnimationStyleProps())
      } else this.useStyle(a);
    var d = this.__inHover ? ua : la;
    for (h = 0; h < d.length; h++) p = d[h], e && null != e[p] ? this[p] = e[p] : s && null != n[p] && (this[p] = n[p])
  }, ha.prototype._mergeStates = function(t) {
    for (var e, n = ra.prototype._mergeStates.call(this, t), i = 0; i < t.length; i++) {
      var r = t[i];
      r.style && this._mergeStyle(e = e || {}, r.style)
    }
    return e && (n.style = e), n
  }, ha.prototype._mergeStyle = function(t, e) {
    return k(t, e), t
  }, ha.prototype.getAnimationStyleProps = function() {
    return sa
  }, ha.initDefaultProps = ((Qn = ha.prototype).type = "displayable", Qn.invisible = !1, Qn.z = 0, Qn.z2 = 0, Qn.zlevel = 0, Qn.culling = !1, Qn.cursor = "pointer", Qn.rectHover = !1, Qn.incremental = !1, Qn._rect = null, Qn.dirtyRectTolerance = 0, void(Qn.__dirty = 3)), Qn = ha;

  function ha(t) {
    return ra.call(this, t) || this
  }
  var ca = new Oe(0, 0, 0, 0),
    pa = new Oe(0, 0, 0, 0),
    da = Math.min,
    fa = Math.max,
    ga = Math.sin,
    ya = Math.cos,
    ma = 2 * Math.PI,
    va = Mt(),
    _a = Mt(),
    xa = Mt();

  function wa(t, e, n, i, r, o) {
    r[0] = da(t, n), r[1] = da(e, i), o[0] = fa(t, n), o[1] = fa(e, i)
  }
  var ba = [],
    Sa = [],
    Ma = {
      M: 1,
      L: 2,
      C: 3,
      Q: 4,
      A: 5,
      Z: 6,
      R: 7
    },
    Ta = [],
    Ia = [],
    Ca = [],
    ka = [],
    Da = [],
    Aa = [],
    La = Math.min,
    Pa = Math.max,
    Oa = Math.cos,
    Ra = Math.sin,
    Na = Math.abs,
    Ea = Math.PI,
    za = 2 * Ea,
    Ba = "undefined" != typeof Float32Array,
    Fa = [];

  function Va(t) {
    return Math.round(t / Ea * 1e8) / 1e8 % 2 * Ea
  }

  function Ha(t, e) {
    var n = Va(t[0]),
      i = (n < 0 && (n += za), n - t[0]),
      r = t[1];
    r += i, !e && za <= r - n ? r = n + za : e && za <= n - r ? r = n - za : !e && r < n ? r = n + (za - Va(n - r)) : e && n < r && (r = n - (za - Va(r - n))), t[0] = n, t[1] = r
  }
  Ga.prototype.increaseVersion = function() {
    this._version++
  }, Ga.prototype.getVersion = function() {
    return this._version
  }, Ga.prototype.setScale = function(t, e, n) {
    0 < (n = n || 0) && (this._ux = Na(n / tr / t) || 0, this._uy = Na(n / tr / e) || 0)
  }, Ga.prototype.setDPR = function(t) {
    this.dpr = t
  }, Ga.prototype.setContext = function(t) {
    this._ctx = t
  }, Ga.prototype.getContext = function() {
    return this._ctx
  }, Ga.prototype.beginPath = function() {
    return this._ctx && this._ctx.beginPath(), this.reset(), this
  }, Ga.prototype.reset = function() {
    this._saveData && (this._len = 0), this._pathSegLen && (this._pathSegLen = null, this._pathLen = 0), this._version++
  }, Ga.prototype.moveTo = function(t, e) {
    return this._drawPendingPt(), this.addData(Ma.M, t, e), this._ctx && this._ctx.moveTo(t, e), this._x0 = t, this._y0 = e, this._xi = t, this._yi = e, this
  }, Ga.prototype.lineTo = function(t, e) {
    var n = Na(t - this._xi),
      i = Na(e - this._yi),
      r = n > this._ux || i > this._uy;
    return this.addData(Ma.L, t, e), this._ctx && r && this._ctx.lineTo(t, e), r ? (this._xi = t, this._yi = e, this._pendingPtDist = 0) : (r = n * n + i * i) > this._pendingPtDist && (this._pendingPtX = t, this._pendingPtY = e, this._pendingPtDist = r), this
  }, Ga.prototype.bezierCurveTo = function(t, e, n, i, r, o) {
    return this._drawPendingPt(), this.addData(Ma.C, t, e, n, i, r, o), this._ctx && this._ctx.bezierCurveTo(t, e, n, i, r, o), this._xi = r, this._yi = o, this
  }, Ga.prototype.quadraticCurveTo = function(t, e, n, i) {
    return this._drawPendingPt(), this.addData(Ma.Q, t, e, n, i), this._ctx && this._ctx.quadraticCurveTo(t, e, n, i), this._xi = n, this._yi = i, this
  }, Ga.prototype.arc = function(t, e, n, i, r, o) {
    return this._drawPendingPt(), Fa[0] = i, Fa[1] = r, Ha(Fa, o), this.addData(Ma.A, t, e, n, n, i = Fa[0], (r = Fa[1]) - i, 0, o ? 0 : 1), this._ctx && this._ctx.arc(t, e, n, i, r, o), this._xi = Oa(r) * n + t, this._yi = Ra(r) * n + e, this
  }, Ga.prototype.arcTo = function(t, e, n, i, r) {
    return this._drawPendingPt(), this._ctx && this._ctx.arcTo(t, e, n, i, r), this
  }, Ga.prototype.rect = function(t, e, n, i) {
    return this._drawPendingPt(), this._ctx && this._ctx.rect(t, e, n, i), this.addData(Ma.R, t, e, n, i), this
  }, Ga.prototype.closePath = function() {
    this._drawPendingPt(), this.addData(Ma.Z);
    var t = this._ctx,
      e = this._x0,
      n = this._y0;
    return t && t.closePath(), this._xi = e, this._yi = n, this
  }, Ga.prototype.fill = function(t) {
    t && t.fill(), this.toStatic()
  }, Ga.prototype.stroke = function(t) {
    t && t.stroke(), this.toStatic()
  }, Ga.prototype.len = function() {
    return this._len
  }, Ga.prototype.setData = function(t) {
    var e = t.length;
    this.data && this.data.length === e || !Ba || (this.data = new Float32Array(e));
    for (var n = 0; n < e; n++) this.data[n] = t[n];
    this._len = e
  }, Ga.prototype.appendPath = function(t) {
    for (var e = (t = t instanceof Array ? t : [t]).length, n = 0, i = this._len, r = 0; r < e; r++) n += t[r].len();
    for (Ba && this.data instanceof Float32Array && (this.data = new Float32Array(i + n)), r = 0; r < e; r++)
      for (var o = t[r].data, a = 0; a < o.length; a++) this.data[i++] = o[a];
    this._len = i
  }, Ga.prototype.addData = function(t, e, n, i, r, o, a, s, l) {
    if (this._saveData) {
      var u = this.data;
      this._len + arguments.length > u.length && (this._expandData(), u = this.data);
      for (var h = 0; h < arguments.length; h++) u[this._len++] = arguments[h]
    }
  }, Ga.prototype._drawPendingPt = function() {
    0 < this._pendingPtDist && (this._ctx && this._ctx.lineTo(this._pendingPtX, this._pendingPtY), this._pendingPtDist = 0)
  }, Ga.prototype._expandData = function() {
    if (!(this.data instanceof Array)) {
      for (var t = [], e = 0; e < this._len; e++) t[e] = this.data[e];
      this.data = t
    }
  }, Ga.prototype.toStatic = function() {
    var t;
    this._saveData && (this._drawPendingPt(), (t = this.data) instanceof Array) && (t.length = this._len, Ba) && 11 < this._len && (this.data = new Float32Array(t))
  }, Ga.prototype.getBoundingRect = function() {
    Ca[0] = Ca[1] = Da[0] = Da[1] = Number.MAX_VALUE, ka[0] = ka[1] = Aa[0] = Aa[1] = -Number.MAX_VALUE;
    for (var t, e = this.data, n = 0, i = 0, r = 0, o = 0, a = 0; a < this._len;) {
      var s = e[a++],
        l = 1 === a;
      switch (l && (r = n = e[a], o = i = e[a + 1]), s) {
        case Ma.M:
          n = r = e[a++], i = o = e[a++], Da[0] = r, Da[1] = o, Aa[0] = r, Aa[1] = o;
          break;
        case Ma.L:
          wa(n, i, e[a], e[a + 1], Da, Aa), n = e[a++], i = e[a++];
          break;
        case Ma.C:
          M = S = b = w = x = _ = v = m = void 0;
          var u = n,
            h = i,
            c = e[a++],
            p = e[a++],
            d = e[a++],
            f = e[a++],
            g = e[a],
            y = e[a + 1],
            m = Da,
            v = Aa,
            _ = mn,
            x = fn,
            w = _(u, c, d, g, ba);
          m[0] = 1 / 0, m[1] = 1 / 0, v[0] = -1 / 0, v[1] = -1 / 0;
          for (var b = 0; b < w; b++) {
            var S = x(u, c, d, g, ba[b]);
            m[0] = da(S, m[0]), v[0] = fa(S, v[0])
          }
          for (w = _(h, p, f, y, Sa), b = 0; b < w; b++) {
            var M = x(h, p, f, y, Sa[b]);
            m[1] = da(M, m[1]), v[1] = fa(M, v[1])
          }
          m[0] = da(u, m[0]), v[0] = fa(u, v[0]), m[0] = da(g, m[0]), v[0] = fa(g, v[0]), m[1] = da(h, m[1]), v[1] = fa(h, v[1]), m[1] = da(y, m[1]), v[1] = fa(y, v[1]), n = e[a++], i = e[a++];
          break;
        case Ma.Q:
          _ = n, F = i, L = e[a++], C = e[a++], A = e[a], T = e[a + 1], D = Da, P = Aa, t = k = t = I = void 0, I = xn, t = fa(da((k = bn)(_, L, A), 1), 0), k = fa(da(k(F, C, T), 1), 0), L = I(_, L, A, t), t = I(F, C, T, k), D[0] = da(_, A, L), D[1] = da(F, T, t), P[0] = fa(_, A, L), P[1] = fa(F, T, t), n = e[a++], i = e[a++];
          break;
        case Ma.A:
          var T, I = e[a++],
            C = e[a++],
            k = e[a++],
            D = e[a++],
            A = e[a++],
            L = e[a++] + A,
            P = (a += 1, !e[a++]),
            O = (l && (r = Oa(A) * k + I, o = Ra(A) * D + C), U = T = G = W = H = V = F = B = z = O = void 0, I),
            R = C,
            N = k,
            E = D,
            z = A,
            B = L,
            F = P,
            V = Da,
            H = Aa,
            W = Bt,
            G = Ft;
          if ((T = Math.abs(z - B)) % ma < 1e-4 && 1e-4 < T) V[0] = O - N, V[1] = R - E, H[0] = O + N, H[1] = R + E;
          else {
            va[0] = ya(z) * N + O, va[1] = ga(z) * E + R, _a[0] = ya(B) * N + O, _a[1] = ga(B) * E + R, W(V, va, _a), G(H, va, _a), (z %= ma) < 0 && (z += ma), (B %= ma) < 0 && (B += ma), B < z && !F ? B += ma : z < B && F && (z += ma), F && (T = B, B = z, z = T);
            for (var U = 0; U < B; U += Math.PI / 2) z < U && (xa[0] = ya(U) * N + O, xa[1] = ga(U) * E + R, W(V, xa, V), G(H, xa, H))
          }
          n = Oa(L) * k + I, i = Ra(L) * D + C;
          break;
        case Ma.R:
          wa(r = n = e[a++], o = i = e[a++], r + e[a++], o + e[a++], Da, Aa);
          break;
        case Ma.Z:
          n = r, i = o
      }
      Bt(Ca, Ca, Da), Ft(ka, ka, Aa)
    }
    return 0 === a && (Ca[0] = Ca[1] = ka[0] = ka[1] = 0), new Oe(Ca[0], Ca[1], ka[0] - Ca[0], ka[1] - Ca[1])
  }, Ga.prototype._calculateLength = function() {
    for (var t = this.data, e = this._len, n = this._ux, i = this._uy, r = 0, o = 0, a = 0, s = 0, l = (this._pathSegLen || (this._pathSegLen = []), this._pathSegLen), u = 0, h = 0, c = 0; c < e;) {
      var p = t[c++],
        d = 1 === c,
        f = (d && (a = r = t[c], s = o = t[c + 1]), -1);
      switch (p) {
        case Ma.M:
          r = a = t[c++], o = s = t[c++];
          break;
        case Ma.L:
          var g = t[c++],
            y = (_ = t[c++]) - o;
          (Na(C = g - r) > n || Na(y) > i || c === e - 1) && (f = Math.sqrt(C * C + y * y), r = g, o = _);
          break;
        case Ma.C:
          var m = t[c++],
            v = t[c++],
            _ = (g = t[c++], t[c++]);
          f = function(t, e, n, i, r, o, a, s, l) {
            for (var u = t, h = e, c = 0, p = 1; p <= 10; p++) {
              var d, f = fn(t, n, r, a, d = .1 * p),
                g = f - u,
                y = (d = fn(e, i, o, s, d)) - h;
              c += Math.sqrt(g * g + y * y), u = f, h = d
            }
            return c
          }(r, o, m, v, g, _, x = t[c++], w = t[c++]), r = x, o = w;
          break;
        case Ma.Q:
          f = function(t, e, n, i, r, o, a) {
            for (var s = t, l = e, u = 0, h = 1; h <= 10; h++) {
              var c, p = xn(t, n, r, c = .1 * h),
                d = p - s,
                f = (c = xn(e, i, o, c)) - l;
              u += Math.sqrt(d * d + f * f), s = p, l = c
            }
            return u
          }(r, o, m = t[c++], v = t[c++], g = t[c++], _ = t[c++]), r = g, o = _;
          break;
        case Ma.A:
          var x = t[c++],
            w = t[c++],
            b = t[c++],
            S = t[c++],
            M = t[c++],
            T = t[c++],
            I = T + M;
          c += 1, d && (a = Oa(M) * b + x, s = Ra(M) * S + w), f = Pa(b, S) * La(za, Math.abs(T)), r = Oa(I) * b + x, o = Ra(I) * S + w;
          break;
        case Ma.R:
          a = r = t[c++], s = o = t[c++], f = 2 * t[c++] + 2 * t[c++];
          break;
        case Ma.Z:
          var C = a - r;
          y = s - o;
          f = Math.sqrt(C * C + y * y), r = a, o = s
      }
      0 <= f && (u += l[h++] = f)
    }
    return this._pathLen = u
  }, Ga.prototype.rebuildPath = function(t, e) {
    var n, i, r, o, a, s, l, u, h = this.data,
      c = this._ux,
      p = this._uy,
      d = this._len,
      f = e < 1,
      g = 0,
      y = 0,
      m = 0;
    if (!f || (this._pathSegLen || this._calculateLength(), a = this._pathSegLen, s = e * this._pathLen)) t: for (var v = 0; v < d;) {
      var _ = h[v++],
        x = 1 === v;
      switch (x && (n = r = h[v], i = o = h[v + 1]), _ !== Ma.L && 0 < m && (t.lineTo(l, u), m = 0), _) {
        case Ma.M:
          n = r = h[v++], i = o = h[v++], t.moveTo(r, o);
          break;
        case Ma.L:
          var w = h[v++],
            b = h[v++],
            S = Na(w - r),
            M = Na(b - o);
          if (c < S || p < M) {
            if (f) {
              if (s < g + (W = a[y++])) {
                var T = (s - g) / W;
                t.lineTo(r * (1 - T) + w * T, o * (1 - T) + b * T);
                break t
              }
              g += W
            }
            t.lineTo(w, b), r = w, o = b, m = 0
          } else m < (S = S * S + M * M) && (l = w, u = b, m = S);
          break;
        case Ma.C:
          var I = h[v++],
            C = h[v++],
            k = h[v++],
            D = h[v++];
          M = h[v++], S = h[v++];
          if (f) {
            if (s < g + (W = a[y++])) {
              vn(r, I, k, M, T = (s - g) / W, Ta), vn(o, C, D, S, T, Ia), t.bezierCurveTo(Ta[1], Ia[1], Ta[2], Ia[2], Ta[3], Ia[3]);
              break t
            }
            g += W
          }
          t.bezierCurveTo(I, C, k, D, M, S), r = M, o = S;
          break;
        case Ma.Q:
          if (I = h[v++], C = h[v++], k = h[v++], D = h[v++], f) {
            if (s < g + (W = a[y++])) {
              Sn(r, I, k, T = (s - g) / W, Ta), Sn(o, C, D, T, Ia), t.quadraticCurveTo(Ta[1], Ia[1], Ta[2], Ia[2]);
              break t
            }
            g += W
          }
          t.quadraticCurveTo(I, C, k, D), r = k, o = D;
          break;
        case Ma.A:
          var A = h[v++],
            L = h[v++],
            P = h[v++],
            O = h[v++],
            R = h[v++],
            N = h[v++],
            E = h[v++],
            z = !h[v++],
            B = O < P ? P : O,
            F = .001 < Na(P - O),
            V = R + N,
            H = !1;
          if (f && (s < g + (W = a[y++]) && (V = R + N * (s - g) / W, H = !0), g += W), F && t.ellipse ? t.ellipse(A, L, P, O, E, R, V, z) : t.arc(A, L, B, R, V, z), H) break t;
          x && (n = Oa(R) * P + A, i = Ra(R) * O + L), r = Oa(V) * P + A, o = Ra(V) * O + L;
          break;
        case Ma.R:
          n = r = h[v], i = o = h[v + 1], w = h[v++], b = h[v++];
          var W;
          N = h[v++], F = h[v++];
          if (f) {
            if (s < g + (W = a[y++])) {
              E = s - g, t.moveTo(w, b), t.lineTo(w + La(E, N), b), 0 < (E -= N) && t.lineTo(w + N, b + La(E, F)), 0 < (E -= F) && t.lineTo(w + Pa(N - E, 0), b + F), 0 < (E -= N) && t.lineTo(w, b + Pa(F - E, 0));
              break t
            }
            g += W
          }
          t.rect(w, b, N, F);
          break;
        case Ma.Z:
          if (f) {
            if (s < g + (W = a[y++])) {
              T = (s - g) / W, t.lineTo(r * (1 - T) + n * T, o * (1 - T) + i * T);
              break t
            }
            g += W
          }
          t.closePath(), r = n, o = i
      }
    }
  }, Ga.prototype.clone = function() {
    var t = new Ga,
      e = this.data;
    return t.data = e.slice ? e.slice() : Array.prototype.slice.call(e), t._len = this._len, t
  }, Ga.CMD = Ma, Ga.initDefaultProps = ((kS = Ga.prototype)._saveData = !0, kS._ux = 0, kS._uy = 0, kS._pendingPtDist = 0, void(kS._version = 0));
  var Wa = Ga;

  function Ga(t) {
    this.dpr = 1, this._xi = 0, this._yi = 0, this._x0 = 0, this._y0 = 0, this._len = 0, t && (this._saveData = !1), this._saveData && (this.data = [])
  }

  function Ua(t, e, n, i, r, o, a) {
    var s;
    if (0 !== r) return s = 0, !(e + (r = r) < a && i + r < a || a < e - r && a < i - r || t + r < o && n + r < o || o < t - r && o < n - r) && (t === n ? Math.abs(o - t) <= r / 2 : (o = (s = (e - i) / (t - n)) * o - a + (t * i - n * e) / (t - n)) * o / (s * s + 1) <= r / 2 * r / 2)
  }
  var Xa = 2 * Math.PI;

  function Ya(t) {
    return (t %= Xa) < 0 && (t += Xa), t
  }
  var qa = 2 * Math.PI;

  function ja(t, e, n, i, r, o) {
    return e < o && i < o || o < e && o < i || i === e ? 0 : (n = (o = (o - e) / (i - e)) * (n - t) + t) === r ? 1 / 0 : r < n ? 1 != o && 0 != o ? i < e ? 1 : -1 : i < e ? .5 : -.5 : 0
  }
  var Za = Wa.CMD,
    Ka = 2 * Math.PI,
    $a = [-1, -1, -1],
    Qa = [-1, -1];

  function Ja(t, e, n, i, r, o, a, s, l, u) {
    if (e < u && i < u && o < u && s < u || u < e && u < i && u < o && u < s) return 0;
    var h = yn(e, i, o, s, u, $a);
    if (0 === h) return 0;
    for (var c, p = 0, d = -1, f = void 0, g = void 0, y = 0; y < h; y++) {
      var m = $a[y],
        v = 0 === m || 1 === m ? .5 : 1;
      fn(t, n, r, a, m) < l || (d < 0 && (d = mn(e, i, o, s, Qa), Qa[1] < Qa[0] && 1 < d && (void 0, c = Qa[0], Qa[0] = Qa[1], Qa[1] = c), f = fn(e, i, o, s, Qa[0]), 1 < d) && (g = fn(e, i, o, s, Qa[1])), 2 === d ? m < Qa[0] ? p += f < e ? v : -v : m < Qa[1] ? p += g < f ? v : -v : p += s < g ? v : -v : m < Qa[0] ? p += f < e ? v : -v : p += s < f ? v : -v)
    }
    return p
  }

  function ts(t, e, n, i, r, o, a, s) {
    if (e < s && i < s && o < s || s < e && s < i && s < o) return 0;
    c = $a, h = (l = e) - 2 * (u = i) + (h = o), u = 2 * (u - l), l -= s = s, s = 0, pn(h) ? dn(u) && 0 <= (p = -l / u) && p <= 1 && (c[s++] = p) : pn(l = u * u - 4 * h * l) ? 0 <= (p = -u / (2 * h)) && p <= 1 && (c[s++] = p) : 0 < l && (d = (-u - (l = sn(l))) / (2 * h), 0 <= (p = (-u + l) / (2 * h)) && p <= 1 && (c[s++] = p), 0 <= d) && d <= 1 && (c[s++] = d);
    var l, u, h, c, p, d, f = s;
    if (0 === f) return 0;
    var g = bn(e, i, o);
    if (0 <= g && g <= 1) {
      for (var y = 0, m = xn(e, i, o, g), v = 0; v < f; v++) {
        var _ = 0 === $a[v] || 1 === $a[v] ? .5 : 1;
        xn(t, n, r, $a[v]) < a || ($a[v] < g ? y += m < e ? _ : -_ : y += o < m ? _ : -_)
      }
      return y
    }
    return _ = 0 === $a[0] || 1 === $a[0] ? .5 : 1, xn(t, n, r, $a[0]) < a ? 0 : o < e ? _ : -_
  }

  function es(t, e, n, i, r) {
    for (var o, a = t.data, s = t.len(), l = 0, u = 0, h = 0, c = 0, p = 0, d = 0; d < s;) {
      var f = a[d++],
        g = 1 === d;
      switch (f === Za.M && 1 < d && (n || (l += ja(u, h, c, p, i, r))), g && (c = u = a[d], p = h = a[d + 1]), f) {
        case Za.M:
          u = c = a[d++], h = p = a[d++];
          break;
        case Za.L:
          if (n) {
            if (Ua(u, h, a[d], a[d + 1], e, i, r)) return !0
          } else l += ja(u, h, a[d], a[d + 1], i, r) || 0;
          u = a[d++], h = a[d++];
          break;
        case Za.C:
          if (n) {
            if (function(t, e, n, i, r, o, a, s, l, u, h) {
                if (0 !== l) return !(e + (l = l) < h && i + l < h && o + l < h && s + l < h || h < e - l && h < i - l && h < o - l && h < s - l || t + l < u && n + l < u && r + l < u && a + l < u || u < t - l && u < n - l && u < r - l && u < a - l) && _n(t, e, n, i, r, o, a, s, u, h, null) <= l / 2
              }(u, h, a[d++], a[d++], a[d++], a[d++], a[d], a[d + 1], e, i, r)) return !0
          } else l += Ja(u, h, a[d++], a[d++], a[d++], a[d++], a[d], a[d + 1], i, r) || 0;
          u = a[d++], h = a[d++];
          break;
        case Za.Q:
          if (n) {
            if (function(t, e, n, i, r, o, a, s, l) {
                if (0 !== a) return !(e + (a = a) < l && i + a < l && o + a < l || l < e - a && l < i - a && l < o - a || t + a < s && n + a < s && r + a < s || s < t - a && s < n - a && s < r - a) && Mn(t, e, n, i, r, o, s, l, null) <= a / 2
              }(u, h, a[d++], a[d++], a[d], a[d + 1], e, i, r)) return !0
          } else l += ts(u, h, a[d++], a[d++], a[d], a[d + 1], i, r) || 0;
          u = a[d++], h = a[d++];
          break;
        case Za.A:
          var y = a[d++],
            m = a[d++],
            v = a[d++],
            _ = a[d++],
            x = a[d++],
            w = a[d++],
            b = (d += 1, !!(1 - a[d++])),
            S = Math.cos(x) * v + y,
            M = Math.sin(x) * _ + m,
            T = (g ? (c = S, p = M) : l += ja(u, h, S, M, i, r), (i - y) * _ / v + y);
          if (n) {
            if (function(t, e, n, i, r, o, a, s, l) {
                if (0 !== a) return a = a, s -= t, l -= e, !(n < (t = Math.sqrt(s * s + l * l)) - a || t + a < n) && (Math.abs(i - r) % qa < 1e-4 || ((r = o ? (e = i, i = Ya(r), Ya(e)) : (i = Ya(i), Ya(r))) < i && (r += qa), (t = Math.atan2(l, s)) < 0 && (t += qa), i <= t && t <= r) || i <= t + qa && t + qa <= r)
              }(y, m, _, x, x + w, b, e, T, r)) return !0
          } else l += function(t, e, n, i, r, o, a, s) {
            if (n < (s -= e) || s < -n) return 0;
            e = Math.sqrt(n * n - s * s);
            if ($a[0] = -e, $a[1] = e, (n = Math.abs(i - r)) < 1e-4) return 0;
            if (Ka - 1e-4 <= n) return r = Ka, h = o ? 1 : -1, a >= $a[i = 0] + t && a <= $a[1] + t ? h : 0;
            r < i && (e = i, i = r, r = e), i < 0 && (i += Ka, r += Ka);
            for (var l = 0, u = 0; u < 2; u++) {
              var h, c = $a[u];
              a < c + t && (h = o ? 1 : -1, i <= (c = (c = Math.atan2(s, c)) < 0 ? Ka + c : c) && c <= r || i <= c + Ka && c + Ka <= r) && (l += h = c > Math.PI / 2 && c < 1.5 * Math.PI ? -h : h)
            }
            return l
          }(y, m, _, x, x + w, b, T, r);
          u = Math.cos(x + w) * v + y, h = Math.sin(x + w) * _ + m;
          break;
        case Za.R:
          if (c = u = a[d++], p = h = a[d++], S = c + a[d++], M = p + a[d++], n) {
            if (Ua(c, p, S, p, e, i, r) || Ua(S, p, S, M, e, i, r) || Ua(S, M, c, M, e, i, r) || Ua(c, M, c, p, e, i, r)) return !0
          } else l = (l += ja(S, p, S, M, i, r)) + ja(c, M, c, p, i, r);
          break;
        case Za.Z:
          if (n) {
            if (Ua(u, h, c, p, e, i, r)) return !0
          } else l += ja(u, h, c, p, i, r);
          u = c, h = p
      }
    }
    return n || (t = h, o = p, Math.abs(t - o) < 1e-4) || (l += ja(u, h, c, p, i, r) || 0), 0 !== l
  }
  var ns, is = D({
      fill: "#000",
      stroke: null,
      strokePercent: 1,
      fillOpacity: 1,
      strokeOpacity: 1,
      lineDashOffset: 0,
      lineWidth: 1,
      lineCap: "butt",
      miterLimit: 10,
      strokeNoScale: !1,
      strokeFirst: !1
    }, aa),
    rs = {
      style: D({
        fill: !0,
        stroke: !0,
        strokePercent: !0,
        fillOpacity: !0,
        strokeOpacity: !0,
        lineDashOffset: !0,
        lineWidth: !0,
        miterLimit: !0
      }, sa.style)
    },
    os = cr.concat(["invisible", "culling", "z", "z2", "zlevel", "parent"]),
    as = (i(ss, ns = Qn), ss.prototype.update = function() {
      var t = this,
        e = (ns.prototype.update.call(this), this.style);
      if (e.decal) {
        var n, i = this._decalEl = this._decalEl || new ss,
          r = (i.buildPath === ss.prototype.buildPath && (i.buildPath = function(e) {
            t.buildPath(e, t.shape)
          }), i.silent = !0, i.style);
        for (n in e) r[n] !== e[n] && (r[n] = e[n]);
        r.fill = e.fill ? e.decal : null, r.decal = null, r.shadowColor = null, e.strokeFirst && (r.stroke = null);
        for (var o = 0; o < os.length; ++o) i[os[o]] = this[os[o]];
        i.__dirty |= 1
      } else this._decalEl && (this._decalEl = null)
    }, ss.prototype.getDecalElement = function() {
      return this._decalEl
    }, ss.prototype._init = function(t) {
      var e = F(t),
        n = (this.shape = this.getDefaultShape(), this.getDefaultStyle());
      n && this.useStyle(n);
      for (var i = 0; i < e.length; i++) {
        var r = e[i],
          o = t[r];
        "style" === r ? this.style ? k(this.style, o) : this.useStyle(o) : "shape" === r ? k(this.shape, o) : ns.prototype.attrKV.call(this, r, o)
      }
      this.style || this.useStyle({})
    }, ss.prototype.getDefaultStyle = function() {
      return null
    }, ss.prototype.getDefaultShape = function() {
      return {}
    }, ss.prototype.canBeInsideText = function() {
      return this.hasFill()
    }, ss.prototype.getInsideTextFill = function() {
      var t, e = this.style.fill;
      if ("none" !== e) {
        if (U(e)) return .5 < (t = ti(e, 0)) ? er : .2 < t ? "#eee" : nr;
        if (e) return nr
      }
      return er
    }, ss.prototype.getInsideTextStroke = function(t) {
      var e = this.style.fill;
      if (U(e)) {
        var n = this.__zr;
        if (!(!n || !n.isDarkMode()) == ti(t, 0) < .4) return e
      }
    }, ss.prototype.buildPath = function(t, e, n) {}, ss.prototype.pathUpdated = function() {
      this.__dirty &= -5
    }, ss.prototype.getUpdatedPathProxy = function(t) {
      return this.path || this.createPathProxy(), this.path.beginPath(), this.buildPath(this.path, this.shape, t), this.path
    }, ss.prototype.createPathProxy = function() {
      this.path = new Wa(!1)
    }, ss.prototype.hasStroke = function() {
      var t = this.style,
        e = t.stroke;
      return !(null == e || "none" === e || !(0 < t.lineWidth))
    }, ss.prototype.hasFill = function() {
      var t = this.style.fill;
      return null != t && "none" !== t
    }, ss.prototype.getBoundingRect = function() {
      var t, e, n = this._rect,
        i = this.style,
        r = !n;
      return r && (t = !1, this.path || (t = !0, this.createPathProxy()), e = this.path, (t || 4 & this.__dirty) && (e.beginPath(), this.buildPath(e, this.shape, !1), this.pathUpdated()), n = e.getBoundingRect()), this._rect = n, this.hasStroke() && this.path && 0 < this.path.len() ? (t = this._rectStroke || (this._rectStroke = n.clone()), (this.__dirty || r) && (t.copy(n), e = i.strokeNoScale ? this.getLineScale() : 1, r = i.lineWidth, this.hasFill() || (i = this.strokeContainThreshold, r = Math.max(r, null == i ? 4 : i)), 1e-10 < e) && (t.width += r / e, t.height += r / e, t.x -= r / e / 2, t.y -= r / e / 2), t) : n
    }, ss.prototype.contain = function(t, e) {
      var n = this.transformCoordToLocal(t, e),
        i = this.getBoundingRect(),
        r = this.style;
      if (t = n[0], e = n[1], i.contain(t, e)) {
        if (n = this.path, this.hasStroke() && (i = r.lineWidth, 1e-10 < (r = r.strokeNoScale ? this.getLineScale() : 1) && (this.hasFill() || (i = Math.max(i, this.strokeContainThreshold)), es(n, i / r, !0, t, e)))) return !0;
        if (this.hasFill()) return es(n, 0, !1, t, e)
      }
      return !1
    }, ss.prototype.dirtyShape = function() {
      this.__dirty |= 4, this._rect && (this._rect = null), this._decalEl && this._decalEl.dirtyShape(), this.markRedraw()
    }, ss.prototype.dirty = function() {
      this.dirtyStyle(), this.dirtyShape()
    }, ss.prototype.animateShape = function(t) {
      return this.animate("shape", t)
    }, ss.prototype.updateDuringAnimation = function(t) {
      "style" === t ? this.dirtyStyle() : "shape" === t ? this.dirtyShape() : this.markRedraw()
    }, ss.prototype.attrKV = function(t, e) {
      "shape" === t ? this.setShape(e) : ns.prototype.attrKV.call(this, t, e)
    }, ss.prototype.setShape = function(t, e) {
      var n = (n = this.shape) || (this.shape = {});
      return "string" == typeof t ? n[t] = e : k(n, t), this.dirtyShape(), this
    }, ss.prototype.shapeChanged = function() {
      return !!(4 & this.__dirty)
    }, ss.prototype.createStyle = function(t) {
      return vt(is, t)
    }, ss.prototype._innerSaveToNormal = function(t) {
      ns.prototype._innerSaveToNormal.call(this, t);
      var e = this._normalState;
      t.shape && !e.shape && (e.shape = k({}, this.shape))
    }, ss.prototype._applyStateObj = function(e, n, i, r, o, a) {
      ns.prototype._applyStateObj.call(this, e, n, i, r, o, a);
      var s, l = !(n && r);
      if (n && n.shape ? o ? r ? s = n.shape : (s = k({}, i.shape), k(s, n.shape)) : (s = k({}, (r ? this : i).shape), k(s, n.shape)) : l && (s = i.shape), s)
        if (o) {
          this.shape = k({}, this.shape);
          for (var u = {}, h = F(s), c = 0; c < h.length; c++) {
            var p = h[c];
            "object" == t(s[p]) ? this.shape[p] = s[p] : u[p] = s[p]
          }
          this._transitionState(e, {
            shape: u
          }, a)
        } else this.shape = s, this.dirtyShape()
    }, ss.prototype._mergeStates = function(t) {
      for (var e, n = ns.prototype._mergeStates.call(this, t), i = 0; i < t.length; i++) {
        var r = t[i];
        r.shape && this._mergeStyle(e = e || {}, r.shape)
      }
      return e && (n.shape = e), n
    }, ss.prototype.getAnimationStyleProps = function() {
      return rs
    }, ss.prototype.isZeroArea = function() {
      return !1
    }, ss.extend = function(t) {
      i(o, e = ss), o.prototype.getDefaultStyle = function() {
        return I(t.style)
      }, o.prototype.getDefaultShape = function() {
        return I(t.shape)
      };
      var e, n, r = o;

      function o(n) {
        var i = e.call(this, n) || this;
        return t.init && t.init.call(i, n), i
      }
      for (n in t) "function" == typeof t[n] && (r.prototype[n] = t[n]);
      return r
    }, ss.initDefaultProps = ((kS = ss.prototype).type = "path", kS.strokeContainThreshold = 5, kS.segmentIgnoreThreshold = 0, kS.subPixelOptimize = !1, kS.autoBatch = !1, void(kS.__dirty = 7)), ss);

  function ss(t) {
    return ns.call(this, t) || this
  }
  var ls, us = D({
      strokeFirst: !0,
      font: u,
      x: 0,
      y: 0,
      textAlign: "left",
      textBaseline: "top",
      miterLimit: 2
    }, is),
    hs = (i(cs, ls = Qn), cs.prototype.hasStroke = function() {
      var t = this.style,
        e = t.stroke;
      return null != e && "none" !== e && 0 < t.lineWidth
    }, cs.prototype.hasFill = function() {
      var t = this.style.fill;
      return null != t && "none" !== t
    }, cs.prototype.createStyle = function(t) {
      return vt(us, t)
    }, cs.prototype.setBoundingRect = function(t) {
      this._rect = t
    }, cs.prototype.getBoundingRect = function() {
      var t, e = this.style;
      return this._rect || (null != (t = e.text) ? t += "" : t = "", (t = yr(t, e.font, e.textAlign, e.textBaseline)).x += e.x || 0, t.y += e.y || 0, this.hasStroke() && (e = e.lineWidth, t.x -= e / 2, t.y -= e / 2, t.width += e, t.height += e), this._rect = t), this._rect
    }, cs.initDefaultProps = void(cs.prototype.dirtyRectTolerance = 10), cs);

  function cs() {
    return null !== ls && ls.apply(this, arguments) || this
  }
  hs.prototype.type = "tspan";
  var ps = D({
      x: 0,
      y: 0
    }, aa),
    ds = {
      style: D({
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        sx: !0,
        sy: !0,
        sWidth: !0,
        sHeight: !0
      }, sa.style)
    };
  i(ys, fs = Qn), ys.prototype.createStyle = function(t) {
    return vt(ps, t)
  }, ys.prototype._getSize = function(t) {
    var e, n = this.style,
      i = n[t];
    return null != i ? i : (i = (i = n.image) && "string" != typeof i && i.width && i.height ? n.image : this.__image) ? null == (e = n[n = "width" === t ? "height" : "width"]) ? i[t] : i[t] / i[n] * e : 0
  }, ys.prototype.getWidth = function() {
    return this._getSize("width")
  }, ys.prototype.getHeight = function() {
    return this._getSize("height")
  }, ys.prototype.getAnimationStyleProps = function() {
    return ds
  }, ys.prototype.getBoundingRect = function() {
    var t = this.style;
    return this._rect || (this._rect = new Oe(t.x || 0, t.y || 0, this.getWidth(), this.getHeight())), this._rect
  };
  var fs, gs = ys;

  function ys() {
    return null !== fs && fs.apply(this, arguments) || this
  }
  gs.prototype.type = "image";
  var ms = Math.round;

  function vs(t, e, n) {
    var i, r, o;
    if (e) return i = e.x1, r = e.x2, o = e.y1, e = e.y2, t.x1 = i, t.x2 = r, t.y1 = o, t.y2 = e, (n = n && n.lineWidth) && (ms(2 * i) === ms(2 * r) && (t.x1 = t.x2 = xs(i, n, !0)), ms(2 * o) === ms(2 * e)) && (t.y1 = t.y2 = xs(o, n, !0)), t
  }

  function _s(t, e, n) {
    var i, r, o;
    if (e) return i = e.x, r = e.y, o = e.width, e = e.height, t.x = i, t.y = r, t.width = o, t.height = e, (n = n && n.lineWidth) && (t.x = xs(i, n, !0), t.y = xs(r, n, !0), t.width = Math.max(xs(i + o, n, !1) - t.x, 0 === o ? 0 : 1), t.height = Math.max(xs(r + e, n, !1) - t.y, 0 === e ? 0 : 1)), t
  }

  function xs(t, e, n) {
    var i;
    return e ? ((i = ms(2 * t)) + ms(e)) % 2 == 0 ? i / 2 : (i + (n ? 1 : -1)) / 2 : t
  }
  var ws, bs = function() {
      this.x = 0, this.y = 0, this.width = 0, this.height = 0
    },
    Ss = {},
    Ms = (i(Ts, ws = as), Ts.prototype.getDefaultShape = function() {
      return new bs
    }, Ts.prototype.buildPath = function(t, e) {
      var n, i, r, o, a, s, l, u, h, c, p, d, f, g;
      this.subPixelOptimize ? (n = (a = _s(Ss, e, this.style)).x, i = a.y, r = a.width, o = a.height, a.r = e.r, e = a) : (n = e.x, i = e.y, r = e.width, o = e.height), e.r ? (a = t, p = (e = e).x, d = e.y, (f = e.width) < 0 && (p += f, f = -f), (g = e.height) < 0 && (d += g, g = -g), "number" == typeof(e = e.r) ? s = l = u = h = e : e instanceof Array ? 1 === e.length ? s = l = u = h = e[0] : 2 === e.length ? (s = u = e[0], l = h = e[1]) : 3 === e.length ? (s = e[0], l = h = e[1], u = e[2]) : (s = e[0], l = e[1], u = e[2], h = e[3]) : s = l = u = h = 0, f < s + l && (s *= f / (c = s + l), l *= f / c), f < u + h && (u *= f / (c = u + h), h *= f / c), g < l + u && (l *= g / (c = l + u), u *= g / c), g < s + h && (s *= g / (c = s + h), h *= g / c), a.moveTo(p + s, d), a.lineTo(p + f - l, d), 0 !== l && a.arc(p + f - l, d + l, l, -Math.PI / 2, 0), a.lineTo(p + f, d + g - u), 0 !== u && a.arc(p + f - u, d + g - u, u, 0, Math.PI / 2), a.lineTo(p + h, d + g), 0 !== h && a.arc(p + h, d + g - h, h, Math.PI / 2, Math.PI), a.lineTo(p, d + s), 0 !== s && a.arc(p + s, d + s, s, Math.PI, 1.5 * Math.PI)) : t.rect(n, i, r, o)
    }, Ts.prototype.isZeroArea = function() {
      return !this.shape.width || !this.shape.height
    }, Ts);

  function Ts(t) {
    return ws.call(this, t) || this
  }
  Ms.prototype.type = "rect";
  var Is, Cs = {
      fill: "#000"
    },
    ks = {
      style: D({
        fill: !0,
        stroke: !0,
        fillOpacity: !0,
        strokeOpacity: !0,
        lineWidth: !0,
        fontSize: !0,
        lineHeight: !0,
        width: !0,
        height: !0,
        textShadowColor: !0,
        textShadowBlur: !0,
        textShadowOffsetX: !0,
        textShadowOffsetY: !0,
        backgroundColor: !0,
        padding: !0,
        borderColor: !0,
        borderWidth: !0,
        borderRadius: !0
      }, sa.style)
    },
    Ds = (i(As, Is = Qn), As.prototype.childrenRef = function() {
      return this._children
    }, As.prototype.update = function() {
      Is.prototype.update.call(this), this.styleChanged() && this._updateSubTexts();
      for (var t = 0; t < this._children.length; t++) {
        var e = this._children[t];
        e.zlevel = this.zlevel, e.z = this.z, e.z2 = this.z2, e.culling = this.culling, e.cursor = this.cursor, e.invisible = this.invisible
      }
    }, As.prototype.updateTransform = function() {
      var t = this.innerTransformable;
      t ? (t.updateTransform(), t.transform && (this.transform = t.transform)) : Is.prototype.updateTransform.call(this)
    }, As.prototype.getLocalTransform = function(t) {
      var e = this.innerTransformable;
      return e ? e.getLocalTransform(t) : Is.prototype.getLocalTransform.call(this, t)
    }, As.prototype.getComputedTransform = function() {
      return this.__hostTarget && (this.__hostTarget.getComputedTransform(), this.__hostTarget.updateInnerText(!0)), Is.prototype.getComputedTransform.call(this)
    }, As.prototype._updateSubTexts = function() {
      var t;
      this._childCursor = 0, zs(t = this.style), N(t.rich, zs), this.style.rich ? this._updateRichTexts() : this._updatePlainTexts(), this._children.length = this._childCursor, this.styleUpdated()
    }, As.prototype.addSelfToZr = function(t) {
      Is.prototype.addSelfToZr.call(this, t);
      for (var e = 0; e < this._children.length; e++) this._children[e].__zr = t
    }, As.prototype.removeSelfFromZr = function(t) {
      Is.prototype.removeSelfFromZr.call(this, t);
      for (var e = 0; e < this._children.length; e++) this._children[e].__zr = null
    }, As.prototype.getBoundingRect = function() {
      if (this.styleChanged() && this._updateSubTexts(), !this._rect) {
        for (var t = new Oe(0, 0, 0, 0), e = this._children, n = [], i = null, r = 0; r < e.length; r++) {
          var o, a = (o = e[r]).getBoundingRect();
          (o = o.getLocalTransform(n)) ? (t.copy(a), t.applyTransform(o), (i = i || t.clone()).union(t)) : (i = i || a.clone()).union(a)
        }
        this._rect = i || t
      }
      return this._rect
    }, As.prototype.setDefaultTextStyle = function(t) {
      this._defaultStyle = t || Cs
    }, As.prototype.setTextContent = function(t) {}, As.prototype._mergeStyle = function(t, e) {
      var n, i;
      return e && (n = e.rich, i = t.rich || n && {}, k(t, e), n && i ? (this._mergeRich(i, n), t.rich = i) : i && (t.rich = i)), t
    }, As.prototype._mergeRich = function(t, e) {
      for (var n = F(e), i = 0; i < n.length; i++) {
        var r = n[i];
        t[r] = t[r] || {}, k(t[r], e[r])
      }
    }, As.prototype.getAnimationStyleProps = function() {
      return ks
    }, As.prototype._getOrCreateChild = function(t) {
      var e = this._children[this._childCursor];
      return e && e instanceof t || (e = new t), (this._children[this._childCursor++] = e).__zr = this.__zr, e.parent = this, e
    }, As.prototype._updatePlainTexts = function() {
      for (var t, e = this.style, n = e.font || u, i = e.padding, r = function(t, e) {
          null != t && (t += "");
          var n, i = e.overflow,
            r = e.padding,
            o = e.font,
            a = "truncate" === i,
            s = _r(o),
            l = nt(e.lineHeight, s),
            u = !!e.backgroundColor,
            h = "truncate" === e.lineOverflow,
            c = e.width,
            p = (i = (n = null == c || "break" !== i && "breakAll" !== i ? t ? t.split("\n") : [] : t ? ia(t, e.font, c, "breakAll" === i, 0).lines : []).length * l, nt(e.height, i));
          if (p < i && h && (h = Math.floor(p / l), n = n.slice(0, h)), t && a && null != c)
            for (var d = Ko(c, o, e.ellipsis, {
                minChar: e.truncateMinChar,
                placeholder: e.placeholder
              }), f = 0; f < n.length; f++) n[f] = $o(n[f], d);
          h = p;
          var g = 0;
          for (f = 0; f < n.length; f++) g = Math.max(fr(n[f], o), g);
          return null == c && (c = g), t = g, r && (h += r[0] + r[2], t += r[1] + r[3], c += r[1] + r[3]), {
            lines: n,
            height: p,
            outerWidth: t = u ? c : t,
            outerHeight: h,
            lineHeight: l,
            calculatedLineHeight: s,
            contentWidth: g,
            contentHeight: i,
            width: c
          }
        }(Hs(e), e), o = Ws(e), a = !!e.backgroundColor, s = r.outerHeight, l = r.outerWidth, h = r.contentWidth, c = r.lines, p = r.lineHeight, d = this._defaultStyle, f = e.x || 0, g = e.y || 0, y = e.align || d.align || "left", m = e.verticalAlign || d.verticalAlign || "top", v = f, _ = vr(g, r.contentHeight, m), x = ((o || i) && (t = mr(f, l, y), g = vr(g, s, m), o) && this._renderBackground(e, e, t, g, l, s), _ += p / 2, i && (v = Vs(f, y, i), "top" === m ? _ += i[0] : "bottom" === m && (_ -= i[2])), 0), w = (o = !1, Fs(("fill" in e ? e : (o = !0, d)).fill)), b = (Bs("stroke" in e ? e.stroke : a || d.autoStroke && !o ? null : (x = 2, d.stroke))), S = 0 < e.textShadowBlur, M = null != e.width && ("truncate" === e.overflow || "break" === e.overflow || "breakAll" === e.overflow), T = r.calculatedLineHeight, I = 0; I < c.length; I++) {
        var C = this._getOrCreateChild(hs),
          k = C.createStyle();
        C.useStyle(k), k.text = c[I], k.x = v, k.y = _, y && (k.textAlign = y), k.textBaseline = "middle", k.opacity = e.opacity, k.strokeFirst = !0, S && (k.shadowBlur = e.textShadowBlur || 0, k.shadowColor = e.textShadowColor || "transparent", k.shadowOffsetX = e.textShadowOffsetX || 0, k.shadowOffsetY = e.textShadowOffsetY || 0), k.stroke = b, k.fill = w, b && (k.lineWidth = e.lineWidth || x, k.lineDash = e.lineDash, k.lineDashOffset = e.lineDashOffset || 0), k.font = n, Ns(k, e), _ += p, M && C.setBoundingRect(new Oe(mr(k.x, e.width, k.textAlign), vr(k.y, T, k.textBaseline), h, T))
      }
    }, As.prototype._updateRichTexts = function() {
      for (var t = this.style, e = function(t, e) {
          var n = new ta;
          if (null != t && (t += ""), t) {
            for (var i, r = e.width, o = e.height, a = e.overflow, s = "break" !== a && "breakAll" !== a || null == r ? null : {
                width: r,
                accumWidth: 0,
                breakAll: "breakAll" === a
              }, l = jo.lastIndex = 0; null != (i = jo.exec(t));) {
              var u = i.index;
              l < u && ea(n, t.substring(l, u), e, s), ea(n, i[2], e, s, i[1]), l = jo.lastIndex
            }
            l < t.length && ea(n, t.substring(l, t.length), e, s);
            var h, c = [],
              p = 0,
              d = 0,
              f = e.padding,
              g = "truncate" === a,
              y = "truncate" === e.lineOverflow;
            t: for (var m = 0; m < n.lines.length; m++) {
              for (var v = n.lines[m], _ = 0, x = 0, w = 0; w < v.tokens.length; w++) {
                var b = (D = v.tokens[w]).styleName && e.rich[D.styleName] || {},
                  S = (C = D.textPadding = b.padding) ? C[1] + C[3] : 0,
                  M = D.font = b.font || e.font,
                  T = (D.contentHeight = _r(M), nt(b.height, D.contentHeight));
                if (D.innerHeight = T, C && (T += C[0] + C[2]), D.height = T, D.lineHeight = it(b.lineHeight, e.lineHeight, T), D.align = b && b.align || e.align, D.verticalAlign = b && b.verticalAlign || "middle", y && null != o && p + D.lineHeight > o) {
                  0 < w ? (v.tokens = v.tokens.slice(0, w), L(v, x, _), n.lines = n.lines.slice(0, m + 1)) : n.lines = n.lines.slice(0, m);
                  break t
                }
                var I, C, k = null == (C = b.width) || "auto" === C;
                "string" == typeof C && "%" === C.charAt(C.length - 1) ? (D.percentWidth = C, c.push(D), D.contentWidth = fr(D.text, M)) : (k && (C = (C = b.backgroundColor) && C.image) && (I = void 0, qo(C = "string" == typeof(h = C) ? (I = Uo.get(h)) && I.image : h)) && (D.width = Math.max(D.width, C.width * T / C.height)), null != (I = g && null != r ? r - x : null) && I < D.width ? !k || I < S ? (D.text = "", D.width = D.contentWidth = 0) : (D.text = Zo(D.text, I - S, M, e.ellipsis, {
                  minChar: e.truncateMinChar
                }), D.width = D.contentWidth = fr(D.text, M)) : D.contentWidth = fr(D.text, M)), D.width += S, x += D.width, b && (_ = Math.max(_, D.lineHeight))
              }
              L(v, x, _)
            }
            for (n.outerWidth = n.width = nt(r, d), n.outerHeight = n.height = nt(o, p), n.contentHeight = p, n.contentWidth = d, f && (n.outerWidth += f[1] + f[3], n.outerHeight += f[0] + f[2]), m = 0; m < c.length; m++) {
              var D, A = (D = c[m]).percentWidth;
              D.width = parseInt(A, 10) / 100 * n.width
            }
          }
          return n;

          function L(t, e, n) {
            t.width = e, t.lineHeight = n, p += n, d = Math.max(d, e)
          }
        }(Hs(t), t), n = e.width, i = e.outerWidth, r = e.outerHeight, o = t.padding, a = t.x || 0, s = t.y || 0, l = this._defaultStyle, u = t.align || l.align, h = (l = t.verticalAlign || l.verticalAlign, a = mr(a, i, u)), c = u = vr(s, r, l), p = (o && (h += o[3], c += o[0]), h + n), d = (Ws(t) && this._renderBackground(t, t, a, u, i, r), !!t.backgroundColor), f = 0; f < e.lines.length; f++) {
        for (var g = e.lines[f], y = g.tokens, m = y.length, v = g.lineHeight, _ = g.width, x = 0, w = h, b = p, S = m - 1, M = void 0; x < m && (!(M = y[x]).align || "left" === M.align);) this._placeToken(M, t, v, c, w, "left", d), _ -= M.width, w += M.width, x++;
        for (; 0 <= S && "right" === (M = y[S]).align;) this._placeToken(M, t, v, c, b, "right", d), _ -= M.width, b -= M.width, S--;
        for (w += (n - (w - h) - (p - b) - _) / 2; x <= S;) M = y[x], this._placeToken(M, t, v, c, w + M.width / 2, "center", d), w += M.width, x++;
        c += v
      }
    }, As.prototype._placeToken = function(t, e, n, i, r, o, a) {
      var s = e.rich[t.styleName] || {},
        l = i + n / 2;
      "top" === (h = (s.text = t.text, t.verticalAlign)) ? l = i + t.height / 2: "bottom" === h && (l = i + n - t.height / 2), !t.isLineHolder && Ws(s) && this._renderBackground(s, e, "right" === o ? r - t.width : "center" === o ? r - t.width / 2 : r, l - t.height / 2, t.width, t.height);
      var h = !!s.backgroundColor,
        c = (i = (n = ((i = t.textPadding) && (r = Vs(r, o, i), l -= t.height / 2 - i[0] - t.innerHeight / 2), this._getOrCreateChild(hs))).createStyle(), n.useStyle(i), this._defaultStyle),
        p = !1,
        d = 0,
        f = Fs(("fill" in s ? s : "fill" in e ? e : (p = !0, c)).fill);
      h = Bs("stroke" in s ? s.stroke : "stroke" in e ? e.stroke : h || a || c.autoStroke && !p ? null : (d = 2, c.stroke)), a = 0 < s.textShadowBlur || 0 < e.textShadowBlur, i.text = t.text, i.x = r, i.y = l, a && (i.shadowBlur = s.textShadowBlur || e.textShadowBlur || 0, i.shadowColor = s.textShadowColor || e.textShadowColor || "transparent", i.shadowOffsetX = s.textShadowOffsetX || e.textShadowOffsetX || 0, i.shadowOffsetY = s.textShadowOffsetY || e.textShadowOffsetY || 0), i.textAlign = o, i.textBaseline = "middle", i.font = t.font || u, i.opacity = it(s.opacity, e.opacity, 1), Ns(i, s), h && (i.lineWidth = it(s.lineWidth, e.lineWidth, d), i.lineDash = nt(s.lineDash, e.lineDash), i.lineDashOffset = e.lineDashOffset || 0, i.stroke = h), f && (i.fill = f), p = t.contentWidth, c = t.contentHeight;
      n.setBoundingRect(new Oe(mr(i.x, p, i.textAlign), vr(i.y, c, i.textBaseline), p, c))
    }, As.prototype._renderBackground = function(t, e, n, i, r, o) {
      var a, s, l, u, h = t.backgroundColor,
        c = t.borderWidth,
        p = t.borderColor,
        d = h && h.image,
        f = h && !d,
        g = t.borderRadius,
        y = this;
      (g = ((f || t.lineHeight || c && p) && ((a = this._getOrCreateChild(Ms)).useStyle(a.createStyle()), a.style.fill = null, (l = a.shape).x = n, l.y = i, l.width = r, l.height = o, l.r = g, a.dirtyShape()), f ? ((u = a.style).fill = h || null, u.fillOpacity = nt(t.fillOpacity, 1)) : d && ((s = this._getOrCreateChild(gs)).onload = function() {
        y.dirtyStyle()
      }, (l = s.style).image = h.image, l.x = n, l.y = i, l.width = r, l.height = o), c && p && ((u = a.style).lineWidth = c, u.stroke = p, u.strokeOpacity = nt(t.strokeOpacity, 1), u.lineDash = t.borderDash, u.lineDashOffset = t.borderDashOffset || 0, a.strokeContainThreshold = 0, a.hasFill()) && a.hasStroke() && (u.strokeFirst = !0, u.lineWidth *= 2), (a || s).style)).shadowBlur = t.shadowBlur || 0, g.shadowColor = t.shadowColor || "transparent", g.shadowOffsetX = t.shadowOffsetX || 0, g.shadowOffsetY = t.shadowOffsetY || 0, g.opacity = it(t.opacity, e.opacity, 1)
    }, As.makeFont = function(t) {
      var e = "";
      return (e = Es(t) ? [t.fontStyle, t.fontWeight, Rs(t.fontSize), t.fontFamily || "sans-serif"].join(" ") : e) && st(e) || t.textFont || t.font
    }, As);

  function As(t) {
    var e = Is.call(this) || this;
    return e.type = "text", e._children = [], e._defaultStyle = Cs, e.attr(t), e
  }
  var Ls = {
      left: !0,
      right: 1,
      center: 1
    },
    Ps = {
      top: 1,
      bottom: 1,
      middle: 1
    },
    Os = ["fontStyle", "fontWeight", "fontSize", "fontFamily"];

  function Rs(t) {
    return "string" != typeof t || -1 === t.indexOf("px") && -1 === t.indexOf("rem") && -1 === t.indexOf("em") ? isNaN(+t) ? "12px" : t + "px" : t
  }

  function Ns(t, e) {
    for (var n = 0; n < Os.length; n++) {
      var i = Os[n],
        r = e[i];
      null != r && (t[i] = r)
    }
  }

  function Es(t) {
    return null != t.fontSize || t.fontFamily || t.fontWeight
  }

  function zs(t) {
    var e;
    t && (t.font = Ds.makeFont(t), e = t.align, t.align = null == (e = "middle" === e ? "center" : e) || Ls[e] ? e : "left", e = t.verticalAlign, t.verticalAlign = null == (e = "center" === e ? "middle" : e) || Ps[e] ? e : "top", t.padding) && (t.padding = ot(t.padding))
  }

  function Bs(t, e) {
    return null == t || e <= 0 || "transparent" === t || "none" === t ? null : t.image || t.colorStops ? "#000" : t
  }

  function Fs(t) {
    return null == t || "none" === t ? null : t.image || t.colorStops ? "#000" : t
  }

  function Vs(t, e, n) {
    return "right" === e ? t - n[1] : "center" === e ? t + n[3] / 2 - n[1] / 2 : t + n[3]
  }

  function Hs(t) {
    return null != (t = t.text) && (t += ""), t
  }

  function Ws(t) {
    return !!(t.backgroundColor || t.lineHeight || t.borderWidth && t.borderColor)
  }

  function Gs(t, e, n, i) {
    var r;
    i && ((r = Us(i)).dataIndex = n, r.dataType = e, r.seriesIndex = t, r.ssrType = "chart", "group" === i.type) && i.traverse((function(i) {
      (i = Us(i)).seriesIndex = t, i.dataIndex = n, i.dataType = e, i.ssrType = "chart"
    }))
  }
  var Us = So(),
    Xs = 1,
    Ys = {},
    qs = So(),
    js = So(),
    Zs = ["emphasis", "blur", "select"],
    Ks = ["normal", "emphasis", "blur", "select"],
    $s = "highlight",
    Qs = "downplay",
    Js = "select",
    tl = "unselect",
    el = "toggleSelect";

  function nl(t) {
    return null != t && "none" !== t
  }

  function il(t, e, n) {
    t.onHoverStateChange && (t.hoverState || 0) !== n && t.onHoverStateChange(e), t.hoverState = n
  }

  function rl(t) {
    il(t, "emphasis", 2)
  }

  function ol(t) {
    2 === t.hoverState && il(t, "normal", 0)
  }

  function al(t) {
    il(t, "blur", 1)
  }

  function sl(t) {
    1 === t.hoverState && il(t, "normal", 0)
  }

  function ll(t) {
    t.selected = !0
  }

  function ul(t) {
    t.selected = !1
  }

  function hl(t, e, n) {
    e(t, n)
  }

  function cl(t, e, n) {
    hl(t, e, n), t.isGroup && t.traverse((function(t) {
      hl(t, e, n)
    }))
  }

  function pl(t, e) {
    switch (e) {
      case "emphasis":
        t.hoverState = 2;
        break;
      case "normal":
        t.hoverState = 0;
        break;
      case "blur":
        t.hoverState = 1;
        break;
      case "select":
        t.selected = !0
    }
  }

  function dl(t, e) {
    var n, i, r, o, a, s = this.states[t];
    if (this.style) {
      if ("emphasis" === t) return n = this, i = s, e = (e = e) && 0 <= L(e, "select"), a = !1, n instanceof as && (r = qs(n), o = e && r.selectFill || r.normalFill, e = e && r.selectStroke || r.normalStroke, nl(o) || nl(e)) && ("inherit" === (r = (i = i || {}).style || {}).fill ? (a = !0, i = k({}, i), (r = k({}, r)).fill = o) : !nl(r.fill) && nl(o) ? (a = !0, i = k({}, i), (r = k({}, r)).fill = ni(o)) : !nl(r.stroke) && nl(e) && (a || (i = k({}, i), r = k({}, r)), r.stroke = ni(e)), i.style = r), i && null == i.z2 && (a || (i = k({}, i)), o = n.z2EmphasisLift, i.z2 = n.z2 + (null != o ? o : 10)), i;
      if ("blur" === t) return function(t, e, n) {
        var i = 0 <= L(t.currentStates, e),
          r = t.style.opacity;
        return t = i ? null : function(t, e, n, i) {
          for (var r = t.style, o = {}, a = 0; a < e.length; a++) {
            var s = e[a],
              l = r[s];
            o[s] = null == l ? i && i[s] : l
          }
          for (a = 0; a < t.animators.length; a++) {
            var u = t.animators[a];
            u.__fromStateTransition && u.__fromStateTransition.indexOf(n) < 0 && "style" === u.targetName && u.saveTo(o, e)
          }
          return o
        }(t, ["opacity"], e, {
          opacity: 1
        }), null == (e = (n = n || {}).style || {}).opacity && (n = k({}, n), e = k({
          opacity: i ? r : .1 * t.opacity
        }, e), n.style = e), n
      }(this, t, s);
      if ("select" === t) return e = this, (r = s) && null == r.z2 && (r = k({}, r), a = e.z2SelectLift, r.z2 = e.z2 + (null != a ? a : 9)), r
    }
    return s
  }

  function fl(t) {
    t.stateProxy = dl;
    var e = t.getTextContent();
    t = t.getTextGuideLine();
    e && (e.stateProxy = dl), t && (t.stateProxy = dl)
  }

  function gl(t, e) {
    Sl(t, e) || t.__highByOuter || cl(t, rl)
  }

  function yl(t, e) {
    Sl(t, e) || t.__highByOuter || cl(t, ol)
  }

  function ml(t, e) {
    t.__highByOuter |= 1 << (e || 0), cl(t, rl)
  }

  function vl(t, e) {
    (t.__highByOuter &= ~(1 << (e || 0))) || cl(t, ol)
  }

  function _l(t) {
    cl(t, al)
  }

  function xl(t) {
    cl(t, sl)
  }

  function wl(t) {
    cl(t, ll)
  }

  function bl(t) {
    cl(t, ul)
  }

  function Sl(t, e) {
    return t.__highDownSilentOnTouch && e.zrByTouch
  }

  function Ml(t) {
    var e = t.getModel(),
      n = [],
      i = [];
    e.eachComponent((function(e, r) {
      var o = js(r),
        a = (e = "series" === e) ? t.getViewOfSeriesModel(r) : t.getViewOfComponentModel(r);
      e || i.push(a), o.isBlured && (a.group.traverse((function(t) {
        sl(t)
      })), e) && n.push(r), o.isBlured = !1
    })), N(i, (function(t) {
      t && t.toggleBlurSeries && t.toggleBlurSeries(n, !1, e)
    }))
  }

  function Tl(t, e, n, i) {
    var r, o, a, s = i.getModel();

    function l(t, e) {
      for (var n = 0; n < e.length; n++) {
        var i = t.getItemGraphicEl(e[n]);
        i && xl(i)
      }
    }
    n = n || "coordinateSystem", null != t && e && "none" !== e && (r = s.getSeriesByIndex(t), (o = r.coordinateSystem) && o.master && (o = o.master), a = [], s.eachSeries((function(t) {
      var s = r === t,
        u = (u = (u = t.coordinateSystem) && u.master ? u.master : u) && o ? u === o : s;
      if (!("series" === n && !s || "coordinateSystem" === n && !u || "series" === e && s)) {
        if (i.getViewOfSeriesModel(t).group.traverse((function(t) {
            t.__highByOuter && s && "self" === e || al(t)
          })), R(e)) l(t.getData(), e);
        else if (q(e))
          for (var h = F(e), c = 0; c < h.length; c++) l(t.getData(h[c]), e[h[c]]);
        a.push(t), js(t).isBlured = !0
      }
    })), s.eachComponent((function(t, e) {
      "series" !== t && (t = i.getViewOfComponentModel(e)) && t.toggleBlurSeries && t.toggleBlurSeries(a, !0, s)
    })))
  }

  function Il(t, e, n) {
    var i;
    null != t && null != e && (t = n.getModel().getComponent(t, e)) && (js(t).isBlured = !0, i = n.getViewOfComponentModel(t)) && i.focusBlurEnabled && i.group.traverse((function(t) {
      al(t)
    }))
  }

  function Cl(t, e, n, i) {
    var r = {
      focusSelf: !1,
      dispatchers: null
    };
    if (null == t || "series" === t || null == e || null == n) return r;
    if (!(t = i.getModel().getComponent(t, e))) return r;
    if (!(e = i.getViewOfComponentModel(t)) || !e.findHighDownDispatchers) return r;
    for (var o, a = e.findHighDownDispatchers(n), s = 0; s < a.length; s++)
      if ("self" === Us(a[s]).focus) {
        o = !0;
        break
      } return {
      focusSelf: o,
      dispatchers: a
    }
  }

  function kl(t) {
    N(t.getAllData(), (function(e) {
      var n = e.data,
        i = e.type;
      n.eachItemGraphicEl((function(e, n) {
        (t.isSelected(n, i) ? wl : bl)(e)
      }))
    }))
  }

  function Dl(t, e, n) {
    Rl(t, !0), cl(t, fl), t = Us(t), null != e ? (t.focus = e, t.blurScope = n) : t.focus && (t.focus = null)
  }

  function Al(t, e, n, i) {
    i ? Rl(t, !1) : Dl(t, e, n)
  }
  var Ll = ["emphasis", "blur", "select"],
    Pl = {
      itemStyle: "getItemStyle",
      lineStyle: "getLineStyle",
      areaStyle: "getAreaStyle"
    };

  function Ol(t, e, n, i) {
    n = n || "itemStyle";
    for (var r = 0; r < Ll.length; r++) {
      var o = Ll[r],
        a = e.getModel([o, n]);
      t.ensureState(o).style = i ? i(a) : a[Pl[n]]()
    }
  }

  function Rl(t, e) {
    e = !1 === e;
    var n = t;
    t.highDownSilentOnTouch && (n.__highDownSilentOnTouch = t.highDownSilentOnTouch), e && !n.__highDownDispatcher || (n.__highByOuter = n.__highByOuter || 0, n.__highDownDispatcher = !e)
  }

  function Nl(t) {
    return !(!t || !t.__highDownDispatcher)
  }

  function El(t) {
    return (t = t.type) === Js || t === tl || t === el
  }

  function zl(t) {
    return (t = t.type) === $s || t === Qs
  }
  var Bl = Wa.CMD,
    Fl = [
      [],
      [],
      []
    ],
    Vl = Math.sqrt,
    Hl = Math.atan2,
    Wl = Math.sqrt,
    Gl = Math.sin,
    Ul = Math.cos,
    Xl = Math.PI;

  function Yl(t) {
    return Math.sqrt(t[0] * t[0] + t[1] * t[1])
  }

  function ql(t, e) {
    return (t[0] * e[0] + t[1] * e[1]) / (Yl(t) * Yl(e))
  }

  function jl(t, e) {
    return (t[0] * e[1] < t[1] * e[0] ? -1 : 1) * Math.acos(ql(t, e))
  }

  function Zl(t, e, n, i, r, o, a, s, l, u, h) {
    var c = Ul(l = l * (Xl / 180)) * (t - n) / 2 + Gl(l) * (e - i) / 2,
      p = -1 * Gl(l) * (t - n) / 2 + Ul(l) * (e - i) / 2,
      d = (r = (d = (1 < (d = c * c / (a * a) + p * p / (s * s)) && (a *= Wl(d), s *= Wl(d)), (r === o ? -1 : 1) * Wl((a * a * (s * s) - a * a * (p * p) - s * s * (c * c)) / (a * a * (p * p) + s * s * (c * c))) || 0)) * a * p / s, d * -s * c / a);
    t = (t + n) / 2 + Ul(l) * r - Gl(l) * d, n = (e + i) / 2 + Gl(l) * r + Ul(l) * d, e = jl([1, 0], [(c - r) / a, (p - d) / s]), r = jl(i = [(c - r) / a, (p - d) / s], c = [(-1 * c - r) / a, (-1 * p - d) / s]);
    ql(i, c) <= -1 && (r = Xl), (r = 1 <= ql(i, c) ? 0 : r) < 0 && (p = Math.round(r / Xl * 1e6) / 1e6, r = 2 * Xl + p % 2 * Xl), h.addData(u, t, n, a, s, e, r, l, o)
  }
  var Kl = /([mlvhzcqtsa])([^mlvhzcqtsa]*)/gi,
    $l = /-?([0-9]*\.)?[0-9]+([eE]-?[0-9]+)?/g;
  i(tu, Ql = as), tu.prototype.applyTransform = function(t) {};
  var Ql, Jl = tu;

  function tu() {
    return null !== Ql && Ql.apply(this, arguments) || this
  }

  function eu(t) {
    return null != t.setData
  }

  function nu(t, e) {
    var n = function(t) {
      var e = new Wa;
      if (t) {
        var n, i = 0,
          r = 0,
          o = i,
          a = r,
          s = Wa.CMD,
          l = t.match(Kl);
        if (l) {
          for (var u = 0; u < l.length; u++) {
            for (var h = l[u], c = h.charAt(0), p = void 0, d = h.match($l) || [], f = d.length, g = 0; g < f; g++) d[g] = parseFloat(d[g]);
            for (var y = 0; y < f;) {
              var m = void 0,
                v = void 0,
                _ = void 0,
                x = void 0,
                w = void 0,
                b = void 0,
                S = void 0,
                M = i,
                T = r,
                I = void 0,
                C = void 0;
              switch (c) {
                case "l":
                  i += d[y++], r += d[y++], p = s.L, e.addData(p, i, r);
                  break;
                case "L":
                  i = d[y++], r = d[y++], p = s.L, e.addData(p, i, r);
                  break;
                case "m":
                  i += d[y++], r += d[y++], p = s.M, e.addData(p, i, r), o = i, a = r, c = "l";
                  break;
                case "M":
                  i = d[y++], r = d[y++], p = s.M, e.addData(p, i, r), o = i, a = r, c = "L";
                  break;
                case "h":
                  i += d[y++], p = s.L, e.addData(p, i, r);
                  break;
                case "H":
                  i = d[y++], p = s.L, e.addData(p, i, r);
                  break;
                case "v":
                  r += d[y++], p = s.L, e.addData(p, i, r);
                  break;
                case "V":
                  r = d[y++], p = s.L, e.addData(p, i, r);
                  break;
                case "C":
                  p = s.C, e.addData(p, d[y++], d[y++], d[y++], d[y++], d[y++], d[y++]), i = d[y - 2], r = d[y - 1];
                  break;
                case "c":
                  p = s.C, e.addData(p, d[y++] + i, d[y++] + r, d[y++] + i, d[y++] + r, d[y++] + i, d[y++] + r), i += d[y - 2], r += d[y - 1];
                  break;
                case "S":
                  m = i, v = r, I = e.len(), C = e.data, n === s.C && (m += i - C[I - 4], v += r - C[I - 3]), p = s.C, M = d[y++], T = d[y++], i = d[y++], r = d[y++], e.addData(p, m, v, M, T, i, r);
                  break;
                case "s":
                  m = i, v = r, I = e.len(), C = e.data, n === s.C && (m += i - C[I - 4], v += r - C[I - 3]), p = s.C, M = i + d[y++], T = r + d[y++], i += d[y++], r += d[y++], e.addData(p, m, v, M, T, i, r);
                  break;
                case "Q":
                  M = d[y++], T = d[y++], i = d[y++], r = d[y++], p = s.Q, e.addData(p, M, T, i, r);
                  break;
                case "q":
                  M = d[y++] + i, T = d[y++] + r, i += d[y++], r += d[y++], p = s.Q, e.addData(p, M, T, i, r);
                  break;
                case "T":
                  m = i, v = r, I = e.len(), C = e.data, n === s.Q && (m += i - C[I - 4], v += r - C[I - 3]), i = d[y++], r = d[y++], p = s.Q, e.addData(p, m, v, i, r);
                  break;
                case "t":
                  m = i, v = r, I = e.len(), C = e.data, n === s.Q && (m += i - C[I - 4], v += r - C[I - 3]), i += d[y++], r += d[y++], p = s.Q, e.addData(p, m, v, i, r);
                  break;
                case "A":
                  _ = d[y++], x = d[y++], w = d[y++], b = d[y++], S = d[y++], Zl(M = i, T = r, i = d[y++], r = d[y++], b, S, _, x, w, p = s.A, e);
                  break;
                case "a":
                  _ = d[y++], x = d[y++], w = d[y++], b = d[y++], S = d[y++], Zl(M = i, T = r, i += d[y++], r += d[y++], b, S, _, x, w, p = s.A, e)
              }
            }
            "z" !== c && "Z" !== c || (p = s.Z, e.addData(p), i = o, r = a), n = p
          }
          e.toStatic()
        }
      }
      return e
    }(t);
    return (t = k({}, e)).buildPath = function(t) {
      var e;
      eu(t) ? (t.setData(n.data), (e = t.getContext()) && t.rebuildPath(e, 1)) : n.rebuildPath(e = t, 1)
    }, t.applyTransform = function(t) {
      var e = n,
        i = t;
      if (i) {
        for (var r, o, a, s, l = e.data, u = e.len(), h = Bl.M, c = Bl.C, p = Bl.L, d = Bl.R, f = Bl.A, g = Bl.Q, y = 0, m = 0; y < u;) {
          switch (r = l[y++], m = y, o = 0, r) {
            case h:
            case p:
              o = 1;
              break;
            case c:
              o = 3;
              break;
            case g:
              o = 2;
              break;
            case f:
              var v = i[4],
                _ = i[5],
                x = Vl(i[0] * i[0] + i[1] * i[1]),
                w = Vl(i[2] * i[2] + i[3] * i[3]),
                b = Hl(-i[1] / w, i[0] / x);
              l[y] *= x, l[y++] += v, l[y] *= w, l[y++] += _, l[y++] *= x, l[y++] *= w, l[y++] += b, l[y++] += b, m = y += 2;
              break;
            case d:
              s[0] = l[y++], s[1] = l[y++], zt(s, s, i), l[m++] = s[0], l[m++] = s[1], s[0] += l[y++], s[1] += l[y++], zt(s, s, i), l[m++] = s[0], l[m++] = s[1]
          }
          for (a = 0; a < o; a++) {
            var S = Fl[a];
            S[0] = l[y++], S[1] = l[y++], zt(S, S, i), l[m++] = S[0], l[m++] = S[1]
          }
        }
        e.increaseVersion()
      }
      this.dirtyShape()
    }, t
  }
  var iu, ru = function() {
    this.cx = 0, this.cy = 0, this.r = 0
  };

  function ou(t) {
    return iu.call(this, t) || this
  }(kS = (i(ou, iu = as), ou.prototype.getDefaultShape = function() {
    return new ru
  }, ou.prototype.buildPath = function(t, e) {
    t.moveTo(e.cx + e.r, e.cy), t.arc(e.cx, e.cy, e.r, 0, 2 * Math.PI)
  }, ou)).prototype.type = "circle";
  var au, su = function() {
    this.cx = 0, this.cy = 0, this.rx = 0, this.ry = 0
  };

  function lu(t) {
    return au.call(this, t) || this
  }(mM = (i(lu, au = as), lu.prototype.getDefaultShape = function() {
    return new su
  }, lu.prototype.buildPath = function(t, e) {
    var n = e.cx,
      i = e.cy,
      r = e.rx,
      o = .5522848 * r,
      a = .5522848 * (e = e.ry);
    t.moveTo(n - r, i), t.bezierCurveTo(n - r, i - a, n - o, i - e, n, i - e), t.bezierCurveTo(n + o, i - e, n + r, i - a, n + r, i), t.bezierCurveTo(n + r, i + a, n + o, i + e, n, i + e), t.bezierCurveTo(n - o, i + e, n - r, i + a, n - r, i), t.closePath()
  }, lu)).prototype.type = "ellipse";
  var uu = Math.PI,
    hu = 2 * uu,
    cu = Math.sin,
    pu = Math.cos,
    du = Math.acos,
    fu = Math.atan2,
    gu = Math.abs,
    yu = Math.sqrt,
    mu = Math.max,
    vu = Math.min,
    _u = 1e-4;

  function xu(t, e, n, i, r, o, a) {
    var s, l, u = (a = (a ? o : -o) / yu((h = t - n) * h + (u = e - i) * u)) * u,
      h = (a = -a * h, t + u),
      c = (t = e + a, e = n + u, n = i + a, i = (h + e) / 2, (t + n) / 2),
      p = e - h,
      d = (e = ((h = h * n - e * t) * (s = n - t) - p * (n = (s < 0 ? -1 : 1) * yu(mu(0, (o = r - o) * o * (l = p * p + s * s) - h * h)))) / l, t = (-h * p - s * n) / l, (h * s + p * n) / l);
    h = (-h * p + s * n) / l;
    return (n = d - i) * n + (l = h - c) * l < (p = e - i) * p + (s = t - c) * s && (e = d, t = h), {
      cx: e,
      cy: t,
      x0: -u,
      y0: -a,
      x1: e * (r / o - 1),
      y1: t * (r / o - 1)
    }
  }
  var wu, bu = function() {
      this.cx = 0, this.cy = 0, this.r0 = 0, this.r = 0, this.startAngle = 0, this.endAngle = 2 * Math.PI, this.clockwise = !0, this.cornerRadius = 0
    },
    Su = (i(Mu, wu = as), Mu.prototype.getDefaultShape = function() {
      return new bu
    }, Mu.prototype.buildPath = function(t, e) {
      ! function(t, e) {
        var n, i, r, o, a, s, l, u, h, c, p, d, f, g, y, m, v, _, x, w, b, S, M, T, I, C, k, D, A, L, P = mu(e.r, 0),
          O = mu(e.r0 || 0, 0),
          R = 0 < P;
        (R || 0 < O) && (R || (P = O, O = 0), P < O && (R = P, P = O, O = R), R = e.startAngle, n = e.endAngle, isNaN(R) || isNaN(n) || (i = e.cx, r = e.cy, o = !!e.clockwise, m = gu(n - R), _u < (a = hu < m && m % hu) && (m = a), _u < P ? hu - _u < m ? (t.moveTo(i + P * pu(R), r + P * cu(R)), t.arc(i, r, P, R, n, !o), _u < O && (t.moveTo(i + O * pu(n), r + O * cu(n)), t.arc(i, r, O, n, R, o))) : (S = b = w = x = _ = v = c = h = C = I = T = M = u = l = s = a = void 0, p = P * pu(R), d = P * cu(R), f = O * pu(n), g = O * cu(n), (y = _u < m) && ((e = e.cornerRadius) && (a = (e = function(t) {
          if (W(t)) {
            var e = t.length;
            if (!e) return t;
            e = 1 === e ? [t[0], t[0], 0, 0] : 2 === e ? [t[0], t[0], t[1], t[1]] : 3 === e ? t.concat(t[2]) : t
          } else e = [t, t, t, t];
          return e
        }(e))[0], s = e[1], l = e[2], u = e[3]), e = gu(P - O) / 2, M = vu(e, l), T = vu(e, u), I = vu(e, a), C = vu(e, s), v = h = mu(M, T), _ = c = mu(I, C), _u < h || _u < c) && (x = P * pu(n), w = P * cu(n), b = O * pu(R), S = O * cu(R), m < uu) && (e = function(t, e, n, i, r, o, a, s) {
          var l = (s -= o) * (n -= t) - (a -= r) * (i -= e);
          if (!(l * l < _u)) return [t + (l = (a * (e - o) - s * (t - r)) / l) * n, e + l * i]
        }(p, d, b, S, x, w, f, g)) && (M = p - e[0], T = d - e[1], I = x - e[0], C = w - e[1], m = 1 / cu(du((M * I + T * C) / (yu(M * M + T * T) * yu(I * I + C * C))) / 2), M = yu(e[0] * e[0] + e[1] * e[1]), v = vu(h, (P - M) / (1 + m)), _ = vu(c, (O - M) / (m - 1))), y ? _u < v ? (k = vu(l, v), D = vu(u, v), A = xu(b, S, p, d, P, k, o), L = xu(x, w, f, g, P, D, o), t.moveTo(i + A.cx + A.x0, r + A.cy + A.y0), v < h && k === D ? t.arc(i + A.cx, r + A.cy, v, fu(A.y0, A.x0), fu(L.y0, L.x0), !o) : (0 < k && t.arc(i + A.cx, r + A.cy, k, fu(A.y0, A.x0), fu(A.y1, A.x1), !o), t.arc(i, r, P, fu(A.cy + A.y1, A.cx + A.x1), fu(L.cy + L.y1, L.cx + L.x1), !o), 0 < D && t.arc(i + L.cx, r + L.cy, D, fu(L.y1, L.x1), fu(L.y0, L.x0), !o))) : (t.moveTo(i + p, r + d), t.arc(i, r, P, R, n, !o)) : t.moveTo(i + p, r + d), _u < O && y ? _u < _ ? (k = vu(a, _), A = xu(f, g, x, w, O, -(D = vu(s, _)), o), L = xu(p, d, b, S, O, -k, o), t.lineTo(i + A.cx + A.x0, r + A.cy + A.y0), _ < c && k === D ? t.arc(i + A.cx, r + A.cy, _, fu(A.y0, A.x0), fu(L.y0, L.x0), !o) : (0 < D && t.arc(i + A.cx, r + A.cy, D, fu(A.y0, A.x0), fu(A.y1, A.x1), !o), t.arc(i, r, O, fu(A.cy + A.y1, A.cx + A.x1), fu(L.cy + L.y1, L.cx + L.x1), o), 0 < k && t.arc(i + L.cx, r + L.cy, k, fu(L.y1, L.x1), fu(L.y0, L.x0), !o))) : (t.lineTo(i + f, r + g), t.arc(i, r, O, n, R, o)) : t.lineTo(i + f, r + g)) : t.moveTo(i, r), t.closePath()))
      }(t, e)
    }, Mu.prototype.isZeroArea = function() {
      return this.shape.startAngle === this.shape.endAngle || this.shape.r === this.shape.r0
    }, Mu);

  function Mu(t) {
    return wu.call(this, t) || this
  }
  Su.prototype.type = "sector";
  var Tu, Iu = function() {
      this.cx = 0, this.cy = 0, this.r = 0, this.r0 = 0
    },
    Cu = (i(ku, Tu = as), ku.prototype.getDefaultShape = function() {
      return new Iu
    }, ku.prototype.buildPath = function(t, e) {
      var n = e.cx,
        i = e.cy,
        r = 2 * Math.PI;
      t.moveTo(n + e.r, i), t.arc(n, i, e.r, 0, r, !1), t.moveTo(n + e.r0, i), t.arc(n, i, e.r0, 0, r, !0)
    }, ku);

  function ku(t) {
    return Tu.call(this, t) || this
  }

  function Du(t, e, n) {
    var i = e.smooth,
      r = e.points;
    if (r && 2 <= r.length) {
      if (i)
        for (var o = function(t, e, n, i) {
            var r, o, a = [],
              s = [],
              l = [],
              u = [];
            if (i) {
              for (var h = [1 / 0, 1 / 0], c = [-1 / 0, -1 / 0], p = 0, d = t.length; p < d; p++) Bt(h, h, t[p]), Ft(c, c, t[p]);
              Bt(h, h, i[0]), Ft(c, c, i[1])
            }
            for (p = 0, d = t.length; p < d; p++) {
              var f = t[p];
              if (n) r = t[p ? p - 1 : d - 1], o = t[(p + 1) % d];
              else {
                if (0 === p || p === d - 1) {
                  a.push(Tt(t[p]));
                  continue
                }
                r = t[p - 1], o = t[p + 1]
              }
              Ct(s, o, r), At(s, s, e);
              var g = Pt(f, r),
                y = Pt(f, o),
                m = (0 !== (m = g + y) && (g /= m, y /= m), At(l, s, -g), At(u, s, y), It([], f, l));
              g = It([], f, u);
              i && (Ft(m, m, h), Bt(m, m, c), Ft(g, g, h), Bt(g, g, c)), a.push(m), a.push(g)
            }
            return n && a.push(a.shift()), a
          }(r, i, n, e.smoothConstraint), a = (t.moveTo(r[0][0], r[0][1]), r.length), s = 0; s < (n ? a : a - 1); s++) {
          var l = o[2 * s],
            u = o[2 * s + 1],
            h = r[(s + 1) % a];
          t.bezierCurveTo(l[0], l[1], u[0], u[1], h[0], h[1])
        } else {
          t.moveTo(r[0][0], r[0][1]);
          s = 1;
          for (var c = r.length; s < c; s++) t.lineTo(r[s][0], r[s][1])
        }
      n && t.closePath()
    }
  }
  Cu.prototype.type = "ring";
  var Au, Lu = function() {
      this.points = null, this.smooth = 0, this.smoothConstraint = null
    },
    Pu = (i(Ou, Au = as), Ou.prototype.getDefaultShape = function() {
      return new Lu
    }, Ou.prototype.buildPath = function(t, e) {
      Du(t, e, !0)
    }, Ou);

  function Ou(t) {
    return Au.call(this, t) || this
  }
  Pu.prototype.type = "polygon";
  var Ru, Nu = function() {
      this.points = null, this.percent = 1, this.smooth = 0, this.smoothConstraint = null
    },
    Eu = (i(zu, Ru = as), zu.prototype.getDefaultStyle = function() {
      return {
        stroke: "#000",
        fill: null
      }
    }, zu.prototype.getDefaultShape = function() {
      return new Nu
    }, zu.prototype.buildPath = function(t, e) {
      Du(t, e, !1)
    }, zu);

  function zu(t) {
    return Ru.call(this, t) || this
  }
  Eu.prototype.type = "polyline";
  var Bu, Fu = {},
    Vu = function() {
      this.x1 = 0, this.y1 = 0, this.x2 = 0, this.y2 = 0, this.percent = 1
    },
    Hu = (i(Wu, Bu = as), Wu.prototype.getDefaultStyle = function() {
      return {
        stroke: "#000",
        fill: null
      }
    }, Wu.prototype.getDefaultShape = function() {
      return new Vu
    }, Wu.prototype.buildPath = function(t, e) {
      var n, i, r, o;
      o = (this.subPixelOptimize ? (n = (o = vs(Fu, e, this.style)).x1, i = o.y1, r = o.x2, o) : (n = e.x1, i = e.y1, r = e.x2, e)).y2, 0 !== (e = e.percent) && (t.moveTo(n, i), e < 1 && (r = n * (1 - e) + r * e, o = i * (1 - e) + o * e), t.lineTo(r, o))
    }, Wu.prototype.pointAt = function(t) {
      var e = this.shape;
      return [e.x1 * (1 - t) + e.x2 * t, e.y1 * (1 - t) + e.y2 * t]
    }, Wu);

  function Wu(t) {
    return Bu.call(this, t) || this
  }
  Hu.prototype.type = "line";
  var Gu = [],
    Uu = function() {
      this.x1 = 0, this.y1 = 0, this.x2 = 0, this.y2 = 0, this.cpx1 = 0, this.cpy1 = 0, this.percent = 1
    };

  function Xu(t, e, n) {
    var i = t.cpx2,
      r = t.cpy2;
    return null != i || null != r ? [(n ? gn : fn)(t.x1, t.cpx1, t.cpx2, t.x2, e), (n ? gn : fn)(t.y1, t.cpy1, t.cpy2, t.y2, e)] : [(n ? wn : xn)(t.x1, t.cpx1, t.x2, e), (n ? wn : xn)(t.y1, t.cpy1, t.y2, e)]
  }
  i(ju, Yu = as), ju.prototype.getDefaultStyle = function() {
    return {
      stroke: "#000",
      fill: null
    }
  }, ju.prototype.getDefaultShape = function() {
    return new Uu
  }, ju.prototype.buildPath = function(t, e) {
    var n = e.x1,
      i = e.y1,
      r = e.x2,
      o = e.y2,
      a = e.cpx1,
      s = e.cpy1,
      l = e.cpx2,
      u = e.cpy2;
    0 !== (e = e.percent) && (t.moveTo(n, i), null == l || null == u ? (e < 1 && (Sn(n, a, r, e, Gu), a = Gu[1], r = Gu[2], Sn(i, s, o, e, Gu), s = Gu[1], o = Gu[2]), t.quadraticCurveTo(a, s, r, o)) : (e < 1 && (vn(n, a, l, r, e, Gu), a = Gu[1], l = Gu[2], r = Gu[3], vn(i, s, u, o, e, Gu), s = Gu[1], u = Gu[2], o = Gu[3]), t.bezierCurveTo(a, s, l, u, r, o)))
  }, ju.prototype.pointAt = function(t) {
    return Xu(this.shape, t, !1)
  }, ju.prototype.tangentAt = function(t) {
    return Lt(t = Xu(this.shape, t, !0), t)
  };
  var Yu, qu = ju;

  function ju(t) {
    return Yu.call(this, t) || this
  }
  qu.prototype.type = "bezier-curve";
  var Zu, Ku = function() {
      this.cx = 0, this.cy = 0, this.r = 0, this.startAngle = 0, this.endAngle = 2 * Math.PI, this.clockwise = !0
    },
    $u = (i(Qu, Zu = as), Qu.prototype.getDefaultStyle = function() {
      return {
        stroke: "#000",
        fill: null
      }
    }, Qu.prototype.getDefaultShape = function() {
      return new Ku
    }, Qu.prototype.buildPath = function(t, e) {
      var n = e.cx,
        i = e.cy,
        r = Math.max(e.r, 0),
        o = e.startAngle,
        a = e.endAngle,
        s = (e = e.clockwise, Math.cos(o)),
        l = Math.sin(o);
      t.moveTo(s * r + n, l * r + i), t.arc(n, i, r, o, a, !e)
    }, Qu);

  function Qu(t) {
    return Zu.call(this, t) || this
  }
  $u.prototype.type = "arc", i(eh, Ju = as), eh.prototype._updatePathDirty = function() {
    for (var t = this.shape.paths, e = this.shapeChanged(), n = 0; n < t.length; n++) e = e || t[n].shapeChanged();
    e && this.dirtyShape()
  }, eh.prototype.beforeBrush = function() {
    this._updatePathDirty();
    for (var t = this.shape.paths || [], e = this.getGlobalScale(), n = 0; n < t.length; n++) t[n].path || t[n].createPathProxy(), t[n].path.setScale(e[0], e[1], t[n].segmentIgnoreThreshold)
  }, eh.prototype.buildPath = function(t, e) {
    for (var n = e.paths || [], i = 0; i < n.length; i++) n[i].buildPath(t, n[i].shape, !0)
  }, eh.prototype.afterBrush = function() {
    for (var t = this.shape.paths || [], e = 0; e < t.length; e++) t[e].pathUpdated()
  }, eh.prototype.getBoundingRect = function() {
    return this._updatePathDirty.call(this), as.prototype.getBoundingRect.call(this)
  };
  var Ju, th = eh;

  function eh() {
    var t = null !== Ju && Ju.apply(this, arguments) || this;
    return t.type = "compound", t
  }

  function nh(t) {
    this.colorStops = t || []
  }
  nh.prototype.addColorStop = function(t, e) {
    this.colorStops.push({
      offset: t,
      color: e
    })
  }, i(oh, ih = sh = nh);
  var ih, rh = oh;

  function oh(t, e, n, i, r, o) {
    return (r = ih.call(this, r) || this).x = null == t ? 0 : t, r.y = null == e ? 0 : e, r.x2 = null == n ? 1 : n, r.y2 = null == i ? 0 : i, r.type = "linear", r.global = o || !1, r
  }
  i(lh, ah = sh);
  var ah, sh = lh;

  function lh(t, e, n, i, r) {
    return (i = ah.call(this, i) || this).x = null == t ? .5 : t, i.y = null == e ? .5 : e, i.r = null == n ? .5 : n, i.type = "radial", i.global = r || !1, i
  }
  var uh = [0, 0],
    hh = [0, 0],
    ch = new Se,
    ph = new Se,
    dh = (fh.prototype.fromBoundingRect = function(t, e) {
      var n = this._corners,
        i = this._axes,
        r = t.x,
        o = t.y,
        a = r + t.width;
      t = o + t.height;
      if (n[0].set(r, o), n[1].set(a, o), n[2].set(a, t), n[3].set(r, t), e)
        for (var s = 0; s < 4; s++) n[s].transform(e);
      for (Se.sub(i[0], n[1], n[0]), Se.sub(i[1], n[3], n[0]), i[0].normalize(), i[1].normalize(), s = 0; s < 2; s++) this._origin[s] = i[s].dot(n[0])
    }, fh.prototype.intersect = function(t, e) {
      var n = !0,
        i = !e;
      return ch.set(1 / 0, 1 / 0), ph.set(0, 0), !this._intersectCheckOneSide(this, t, ch, ph, i, 1) && (n = !1, i) || !this._intersectCheckOneSide(t, this, ch, ph, i, -1) && (n = !1, i) || i || Se.copy(e, n ? ch : ph), n
    }, fh.prototype._intersectCheckOneSide = function(t, e, n, i, r, o) {
      for (var a = !0, s = 0; s < 2; s++) {
        var l = this._axes[s];
        if (this._getProjMinMaxOnAxis(s, t._corners, uh), this._getProjMinMaxOnAxis(s, e._corners, hh), uh[1] < hh[0] || hh[1] < uh[0]) {
          if (a = !1, r) return a;
          var u = Math.abs(hh[0] - uh[1]),
            h = Math.abs(uh[0] - hh[1]);
          Math.min(u, h) > i.len() && (u < h ? Se.scale(i, l, -u * o) : Se.scale(i, l, h * o))
        } else n && (u = Math.abs(hh[0] - uh[1]), h = Math.abs(uh[0] - hh[1]), Math.min(u, h) < n.len()) && (u < h ? Se.scale(n, l, u * o) : Se.scale(n, l, -h * o))
      }
      return a
    }, fh.prototype._getProjMinMaxOnAxis = function(t, e, n) {
      for (var i = this._axes[t], r = this._origin, o = e[0].dot(i) + r[t], a = o, s = o, l = 1; l < e.length; l++) {
        var u = e[l].dot(i) + r[t];
        a = Math.min(u, a), s = Math.max(u, s)
      }
      n[0] = a, n[1] = s
    }, fh);

  function fh(t, e) {
    this._corners = [], this._axes = [], this._origin = [0, 0];
    for (var n = 0; n < 4; n++) this._corners[n] = new Se;
    for (n = 0; n < 2; n++) this._axes[n] = new Se;
    t && this.fromBoundingRect(t, e)
  }
  var gh, yh = [];
  i(mh, gh = Qn), mh.prototype.traverse = function(t, e) {
    t.call(e, this)
  }, mh.prototype.useStyle = function() {
    this.style = {}
  }, mh.prototype.getCursor = function() {
    return this._cursor
  }, mh.prototype.innerAfterBrush = function() {
    this._cursor = this._displayables.length
  }, mh.prototype.clearDisplaybles = function() {
    this._displayables = [], this._temporaryDisplayables = [], this._cursor = 0, this.markRedraw(), this.notClear = !1
  }, mh.prototype.clearTemporalDisplayables = function() {
    this._temporaryDisplayables = []
  }, mh.prototype.addDisplayable = function(t, e) {
    (e ? this._temporaryDisplayables : this._displayables).push(t), this.markRedraw()
  }, mh.prototype.addDisplayables = function(t, e) {
    e = e || !1;
    for (var n = 0; n < t.length; n++) this.addDisplayable(t[n], e)
  }, mh.prototype.getDisplayables = function() {
    return this._displayables
  }, mh.prototype.getTemporalDisplayables = function() {
    return this._temporaryDisplayables
  }, mh.prototype.eachPendingDisplayable = function(t) {
    for (var e = this._cursor; e < this._displayables.length; e++) t && t(this._displayables[e]);
    for (e = 0; e < this._temporaryDisplayables.length; e++) t && t(this._temporaryDisplayables[e])
  }, mh.prototype.update = function() {
    this.updateTransform();
    for (var t = this._cursor; t < this._displayables.length; t++)(e = this._displayables[t]).parent = this, e.update(), e.parent = null;
    var e;
    for (t = 0; t < this._temporaryDisplayables.length; t++)(e = this._temporaryDisplayables[t]).parent = this, e.update(), e.parent = null
  }, mh.prototype.getBoundingRect = function() {
    if (!this._rect) {
      for (var t = new Oe(1 / 0, 1 / 0, -1 / 0, -1 / 0), e = 0; e < this._displayables.length; e++) {
        var n = this._displayables[e],
          i = n.getBoundingRect().clone();
        n.needLocalTransform() && i.applyTransform(n.getLocalTransform(yh)), t.union(i)
      }
      this._rect = t
    }
    return this._rect
  }, mh.prototype.contain = function(t, e) {
    var n = this.transformCoordToLocal(t, e);
    if (this.getBoundingRect().contain(n[0], n[1]))
      for (var i = 0; i < this._displayables.length; i++)
        if (this._displayables[i].contain(t, e)) return !0;
    return !1
  }, Qn = mh;

  function mh() {
    var t = null !== gh && gh.apply(this, arguments) || this;
    return t.notClear = !0, t.incremental = !0, t._displayables = [], t._temporaryDisplayables = [], t._cursor = 0, t
  }
  var vh = So();

  function _h(t, e, n, i, r, o, a) {
    var s, l, u, h, c, p, d = !1,
      f = (G(r) ? (a = o, o = r, r = null) : q(r) && (o = r.cb, a = r.during, d = r.isFrom, l = r.removeOpt, r = r.dataIndex), "leave" === t),
      g = (f || e.stopAnimation("leave"), p = t, s = r, l = f ? l || {} : null, i = (g = i) && i.getAnimationDelayParams ? i.getAnimationDelayParams(e, r) : null, g && g.ecModel && (u = (u = g.ecModel.getUpdatePayload()) && u.animation), p = "update" === p, g && g.isAnimationEnabled() ? (c = h = r = void 0, c = l ? (r = nt(l.duration, 200), h = nt(l.easing, "cubicOut"), 0) : (r = g.getShallow(p ? "animationDurationUpdate" : "animationDuration"), h = g.getShallow(p ? "animationEasingUpdate" : "animationEasing"), g.getShallow(p ? "animationDelayUpdate" : "animationDelay")), G(c = u && (null != u.duration && (r = u.duration), null != u.easing && (h = u.easing), null != u.delay) ? u.delay : c) && (c = c(s, i)), {
        duration: (r = G(r) ? r(s) : r) || 0,
        delay: c,
        easing: h
      }) : null);
    g && 0 < g.duration ? (p = {
      duration: g.duration,
      delay: g.delay || 0,
      easing: g.easing,
      done: o,
      force: !!o || !!a,
      setToFinal: !f,
      scope: t,
      during: a
    }, d ? e.animateFrom(n, p) : e.animateTo(n, p)) : (e.stopAnimation(), d || e.attr(n), a && a(1), o && o())
  }

  function xh(t, e, n, i, r, o) {
    _h("update", t, e, n, i, r, o)
  }

  function wh(t, e, n, i, r, o) {
    _h("enter", t, e, n, i, r, o)
  }

  function bh(t) {
    if (!t.__zr) return !0;
    for (var e = 0; e < t.animators.length; e++)
      if ("leave" === t.animators[e].scope) return !0;
    return !1
  }

  function Sh(t, e, n, i, r, o) {
    bh(t) || _h("leave", t, e, n, i, r, o)
  }

  function Mh(t, e, n, i) {
    t.removeTextContent(), t.removeTextGuideLine(), Sh(t, {
      style: {
        opacity: 0
      }
    }, e, n, i)
  }

  function Th(t, e, n) {
    function i() {
      t.parent && t.parent.remove(t)
    }
    t.isGroup ? t.traverse((function(t) {
      t.isGroup || Mh(t, e, n, i)
    })) : Mh(t, e, n, i)
  }

  function Ih(t) {
    vh(t).oldStyle = t.style
  }
  var Ch = Math.max,
    kh = Math.min,
    Dh = {};

  function Ah(t) {
    return as.extend(t)
  }

  function Lh(t, e) {
    return function(t, e) {
      var n, r = nu(t, e);

      function o(t) {
        return (t = n.call(this, t) || this).applyTransform = r.applyTransform, t.buildPath = r.buildPath, t
      }
      return i(o, n = Jl), o
    }(t, e)
  }

  function Ph(t, e) {
    Dh[t] = e
  }

  function Oh(t) {
    if (Dh.hasOwnProperty(t)) return Dh[t]
  }

  function Rh(t, e, n, i) {
    return t = new Jl(nu(t, e)), n && ("center" === i && (n = Eh(n, t.getBoundingRect())), Bh(t, n)), t
  }

  function Nh(t, e, n) {
    var i = new gs({
      style: {
        image: t,
        x: e.x,
        y: e.y,
        width: e.width,
        height: e.height
      },
      onload: function(t) {
        "center" === n && (t = {
          width: t.width,
          height: t.height
        }, i.setStyle(Eh(e, t)))
      }
    });
    return i
  }

  function Eh(t, e) {
    e = e.width / e.height;
    var n = t.height * e;
    e = n <= t.width ? t.height : (n = t.width) / e;
    return {
      x: t.x + t.width / 2 - n / 2,
      y: t.y + t.height / 2 - e / 2,
      width: n,
      height: e
    }
  }

  function zh(t, e) {
    for (var n = [], i = t.length, r = 0; r < i; r++) {
      var o = t[r];
      n.push(o.getUpdatedPathProxy(!0))
    }
    return (e = new as(e)).createPathProxy(), e.buildPath = function(t) {
      var e;
      eu(t) && (t.appendPath(n), e = t.getContext()) && t.rebuildPath(e, 1)
    }, e
  }

  function Bh(t, e) {
    t.applyTransform && (e = t.getBoundingRect().calculateTransform(e), t.applyTransform(e))
  }

  function Fh(t, e) {
    return vs(t, t, {
      lineWidth: e
    }), t
  }
  var Vh = xs;

  function Hh(t, e) {
    for (var n = ge([]); t && t !== e;) me(n, t.getLocalTransform(), n), t = t.parent;
    return n
  }

  function Wh(t, e, n) {
    return e && !R(e) && (e = ur.getLocalTransform(e)), zt([], t, e = n ? we([], e) : e)
  }

  function Gh(t) {
    return !t.isGroup
  }

  function Uh(t, e, n) {
    var i, r;

    function o(t) {
      var e = {
        x: t.x,
        y: t.y,
        rotation: t.rotation
      };
      return null != t.shape && (e.shape = k({}, t.shape)), e
    }
    t && e && (r = {}, t.traverse((function(t) {
      Gh(t) && t.anid && (r[t.anid] = t)
    })), i = r, e.traverse((function(t) {
      var e, r;
      Gh(t) && t.anid && (e = i[t.anid]) && (r = o(t), t.attr(o(e)), xh(t, r, n, Us(t).dataIndex))
    })))
  }

  function Xh(t, e) {
    return E(t, (function(t) {
      var n = t[0];
      n = Ch(n, e.x), n = kh(n, e.x + e.width), t = t[1], t = Ch(t, e.y);
      return [n, kh(t, e.y + e.height)]
    }))
  }

  function Yh(t, e) {
    var n = Ch(t.x, e.x),
      i = kh(t.x + t.width, e.x + e.width),
      r = Ch(t.y, e.y);
    t = kh(t.y + t.height, e.y + e.height);
    if (n <= i && r <= t) return {
      x: n,
      y: r,
      width: i - n,
      height: t - r
    }
  }

  function qh(t, e, n) {
    var i = (e = k({
      rectHover: !0
    }, e)).style = {
      strokeNoScale: !0
    };
    if (n = n || {
        x: -1,
        y: -1,
        width: 2,
        height: 2
      }, t) return 0 === t.indexOf("image://") ? (i.image = t.slice(8), D(i, n), new gs(e)) : Rh(t.replace("path://", ""), e, n, "center")
  }

  function jh(t, e, n, i, r, o, a, s) {
    var l, u = (a = a - r) * (i = i - e) - (n = n - t) * (s = s - o);
    return !((l = u) <= 1e-6 && -1e-6 <= l || (r = ((l = t - r) * i - n * (t = e - o)) / u) < 0 || 1 < r || (i = (l * s - a * t) / u) < 0 || 1 < i)
  }

  function Zh(t) {
    var e = t.itemTooltipOption,
      n = t.componentModel,
      i = t.itemName,
      r = (e = U(e) ? {
        formatter: e
      } : e, n.mainType),
      o = (n = n.componentIndex, {
        componentType: r,
        name: i,
        $vars: ["name"]
      }),
      a = (o[r + "Index"] = n, t.formatterParamsExtra);
    (t = (a && N(F(a), (function(t) {
      xt(o, t) || (o[t] = a[t], o.$vars.push(t))
    })), Us(t.el))).componentMainType = r, t.componentIndex = n, t.tooltipConfig = {
      name: i,
      option: D({
        content: i,
        encodeHTMLContent: !0,
        formatterParams: o
      }, e)
    }
  }

  function Kh(t, e) {
    var n;
    (n = t.isGroup ? e(t) : n) || t.traverse(e)
  }

  function $h(t, e) {
    if (t)
      if (W(t))
        for (var n = 0; n < t.length; n++) Kh(t[n], e);
      else Kh(t, e)
  }
  Ph("circle", kS), Ph("ellipse", mM), Ph("sector", Su), Ph("ring", Cu), Ph("polygon", Pu), Ph("polyline", Eu), Ph("rect", Ms), Ph("line", Hu), Ph("bezierCurve", qu), Ph("arc", $u);
  var Qh = Object.freeze({
      __proto__: null,
      Arc: $u,
      BezierCurve: qu,
      BoundingRect: Oe,
      Circle: kS,
      CompoundPath: th,
      Ellipse: mM,
      Group: Rr,
      Image: gs,
      IncrementalDisplayable: Qn,
      Line: Hu,
      LinearGradient: rh,
      OrientedBoundingRect: dh,
      Path: as,
      Point: Se,
      Polygon: Pu,
      Polyline: Eu,
      RadialGradient: sh,
      Rect: Ms,
      Ring: Cu,
      Sector: Su,
      Text: Ds,
      applyTransform: Wh,
      clipPointsByRect: Xh,
      clipRectByRect: Yh,
      createIcon: qh,
      extendPath: Lh,
      extendShape: Ah,
      getShapeClass: Oh,
      getTransform: Hh,
      groupTransition: Uh,
      initProps: wh,
      isElementRemoved: bh,
      lineLineIntersect: jh,
      linePolygonIntersect: function(t, e, n, i, r) {
        for (var o = 0, a = r[r.length - 1]; o < r.length; o++) {
          var s = r[o];
          if (jh(t, e, n, i, s[0], s[1], a[0], a[1])) return !0;
          a = s
        }
      },
      makeImage: Nh,
      makePath: Rh,
      mergePath: zh,
      registerShape: Ph,
      removeElement: Sh,
      removeElementWithFadeOut: Th,
      resizePath: Bh,
      setTooltipConfig: Zh,
      subPixelOptimize: Vh,
      subPixelOptimizeLine: Fh,
      subPixelOptimizeRect: function(t) {
        return _s(t.shape, t.shape, t.style), t
      },
      transformDirection: function(t, e, n) {
        var i = 0 === e[4] || 0 === e[5] || 0 === e[0] ? 1 : Math.abs(2 * e[4] / e[0]),
          r = 0 === e[4] || 0 === e[5] || 0 === e[2] ? 1 : Math.abs(2 * e[4] / e[2]);
        i = Wh(["left" === t ? -i : "right" === t ? i : 0, "top" === t ? -r : "bottom" === t ? r : 0], e, n);
        return Math.abs(i[0]) > Math.abs(i[1]) ? 0 < i[0] ? "right" : "left" : 0 < i[1] ? "bottom" : "top"
      },
      traverseElements: $h,
      updateProps: xh
    }),
    Jh = {};

  function tc(t, e) {
    for (var n = 0; n < Zs.length; n++) {
      var i, r = e[i = Zs[n]];
      (i = t.ensureState(i)).style = i.style || {}, i.style.text = r
    }
    var o = t.currentStates.slice();
    t.clearStates(!0), t.setStyle({
      text: e.normal
    }), t.useStates(o, !0)
  }

  function ec(t, e, n) {
    for (var i, r = t.labelFetcher, o = t.labelDataIndex, a = t.labelDimIndex, s = e.normal, l = {
        normal: i = null == (i = r ? r.getFormattedLabel(o, "normal", null, a, s && s.get("formatter"), null != n ? {
          interpolatedValue: n
        } : null) : i) ? G(t.defaultText) ? t.defaultText(o, t, n) : t.defaultText : i
      }, u = 0; u < Zs.length; u++) {
      var h = Zs[u],
        c = e[h];
      l[h] = nt(r ? r.getFormattedLabel(o, h, null, a, c && c.get("formatter")) : null, i)
    }
    return l
  }

  function nc(t, e, n, i) {
    n = n || Jh;
    for (var r = t instanceof Ds, o = !1, a = 0; a < Ks.length; a++)
      if ((p = e[Ks[a]]) && p.getShallow("show")) {
        o = !0;
        break
      } var s = r ? t : t.getTextContent();
    if (o) {
      r || (s || (s = new Ds, t.setTextContent(s)), t.stateProxy && (s.stateProxy = t.stateProxy));
      var l = ec(n, e),
        u = e.normal,
        h = !!u.getShallow("show"),
        c = rc(u, i && i.normal, n, !1, !r);
      for (c.text = l.normal, r || t.setTextConfig(oc(u, n, !1)), a = 0; a < Zs.length; a++) {
        var p, d, f, g = Zs[a];
        (p = e[g]) && (d = s.ensureState(g), (f = !!nt(p.getShallow("show"), h)) != h && (d.ignore = !f), d.style = rc(p, i && i[g], n, !0, !r), d.style.text = l[g], r || (t.ensureState(g).textConfig = oc(p, n, !0)))
      }
      s.silent = !!u.getShallow("silent"), null != s.style.x && (c.x = s.style.x), null != s.style.y && (c.y = s.style.y), s.ignore = !h, s.useStyle(c), s.dirty(), n.enableTextSetter && (hc(s).setLabelText = function(t) {
        t = ec(n, e, t), tc(s, t)
      })
    } else s && (s.ignore = !0);
    t.dirty()
  }

  function ic(t, e) {
    for (var n = {
        normal: t.getModel(e = e || "label")
      }, i = 0; i < Zs.length; i++) {
      var r = Zs[i];
      n[r] = t.getModel([r, e])
    }
    return n
  }

  function rc(t, e, n, i, r) {
    var o, a = {},
      s = a,
      l = t,
      u = n,
      h = i,
      c = r;
    u = u || Jh;
    var p, d = (t = l.ecModel) && t.option.textStyle,
      f = function(t) {
        for (var e; t && t !== t.ecModel;) {
          var n = (t.option || Jh).rich;
          if (n) {
            e = e || {};
            for (var i = F(n), r = 0; r < i.length; r++) {
              e[i[r]] = 1
            }
          }
          t = t.parentModel
        }
        return e
      }(l);
    if (f)
      for (var g in p = {}, f) f.hasOwnProperty(g) && (o = l.getModel(["rich", g]), uc(p[g] = {}, o, d, u, h, c, !1, !0));
    return p && (s.rich = p), (t = l.get("overflow")) && (s.overflow = t), null != (t = l.get("minMargin")) && (s.margin = t), uc(s, l, d, u, h, c, !0, !1), e && k(a, e), a
  }

  function oc(t, e, n) {
    e = e || {};
    var i = {},
      r = t.getShallow("rotate"),
      o = nt(t.getShallow("distance"), n ? null : 5),
      a = t.getShallow("offset");
    return null != (n = "outside" === (n = t.getShallow("position") || (n ? null : "inside")) ? e.defaultOutsidePosition || "top" : n) && (i.position = n), null != a && (i.offset = a), null != r && (r *= Math.PI / 180, i.rotation = r), null != o && (i.distance = o), i.outsideFill = "inherit" === t.get("color") ? e.inheritColor || null : "auto", i
  }
  var ac = ["fontStyle", "fontWeight", "fontSize", "fontFamily", "textShadowColor", "textShadowBlur", "textShadowOffsetX", "textShadowOffsetY"],
    sc = ["align", "lineHeight", "width", "height", "tag", "verticalAlign", "ellipsis"],
    lc = ["padding", "borderWidth", "borderRadius", "borderDashOffset", "backgroundColor", "borderColor", "shadowColor", "shadowBlur", "shadowOffsetX", "shadowOffsetY"];

  function uc(t, e, n, i, r, o, a, s) {
    n = !r && n || Jh;
    var l = i && i.inheritColor,
      u = e.getShallow("color"),
      h = e.getShallow("textBorderColor"),
      c = nt(e.getShallow("opacity"), n.opacity);
    "inherit" !== u && "auto" !== u || (u = l || null), "inherit" !== h && "auto" !== h || (h = l || null), o || (u = u || n.color, h = h || n.textBorderColor), null != u && (t.fill = u), null != h && (t.stroke = h), u = nt(e.getShallow("textBorderWidth"), n.textBorderWidth);
    null != (u = (null != (h = (null != u && (t.lineWidth = u), nt(e.getShallow("textBorderType"), n.textBorderType))) && (t.lineDash = h), nt(e.getShallow("textBorderDashOffset"), n.textBorderDashOffset))) && (t.lineDashOffset = u), null != (c = r || null != c || s ? c : i && i.defaultOpacity) && (t.opacity = c), r || o || null == t.fill && i.inheritColor && (t.fill = i.inheritColor);
    for (var p = 0; p < ac.length; p++) {
      var d = ac[p];
      null != (f = nt(e.getShallow(d), n[d])) && (t[d] = f)
    }
    for (p = 0; p < sc.length; p++) d = sc[p], null != (f = e.getShallow(d)) && (t[d] = f);
    if (null == t.verticalAlign && null != (h = e.getShallow("baseline")) && (t.verticalAlign = h), !a || !i.disableBox) {
      for (p = 0; p < lc.length; p++) {
        var f;
        d = lc[p];
        null != (f = e.getShallow(d)) && (t[d] = f)
      }
      null != (u = e.getShallow("borderType")) && (t.borderDash = u), "auto" !== t.backgroundColor && "inherit" !== t.backgroundColor || !l || (t.backgroundColor = l), "auto" !== t.borderColor && "inherit" !== t.borderColor || !l || (t.borderColor = l)
    }
  }
  var hc = So();

  function cc(t, e, n, i) {
    t && ((t = hc(t)).prevValue = t.value, t.value = n, n = e.normal, t.valueAnimation = n.get("valueAnimation"), t.valueAnimation) && (t.precision = n.get("precision"), t.defaultInterpolatedText = i, t.statesModels = e)
  }

  function pc(t, e, n, i, r) {
    var o, a, s, l = hc(t);
    l.valueAnimation && l.prevValue !== l.value && (o = l.defaultInterpolatedText, a = nt(l.interpolatedValue, l.prevValue), s = l.value, t.percent = 0, (null == l.prevValue ? wh : xh)(t, {
      percent: 1
    }, i, e, null, (function(i) {
      var u = Ao(n, l.precision, a, s, i);
      l.interpolatedValue = 1 === i ? null : u, i = ec({
        labelDataIndex: e,
        labelFetcher: r,
        defaultText: o ? o(u) : u + ""
      }, l.statesModels, u);
      tc(t, i)
    })))
  }
  var dc = ["textStyle", "color"],
    fc = ["fontStyle", "fontWeight", "fontSize", "fontFamily", "padding", "lineHeight", "rich", "width", "height", "overflow"],
    gc = new Ds;
  yc.prototype.getTextColor = function(t) {
    var e = this.ecModel;
    return this.getShallow("color") || (!t && e ? e.get(dc) : null)
  }, yc.prototype.getFont = function() {
    return t = {
      fontStyle: this.getShallow("fontStyle"),
      fontWeight: this.getShallow("fontWeight"),
      fontSize: this.getShallow("fontSize"),
      fontFamily: this.getShallow("fontFamily")
    }, e = (e = this.ecModel) && e.getModel("textStyle"), st([t.fontStyle || e && e.getShallow("fontStyle") || "", t.fontWeight || e && e.getShallow("fontWeight") || "", (t.fontSize || e && e.getShallow("fontSize") || 12) + "px", t.fontFamily || e && e.getShallow("fontFamily") || "sans-serif"].join(" "));
    var t, e
  }, yc.prototype.getTextRect = function(t) {
    for (var e = {
        text: t,
        verticalAlign: this.getShallow("verticalAlign") || this.getShallow("baseline")
      }, n = 0; n < fc.length; n++) e[fc[n]] = this.getShallow(fc[n]);
    return gc.useStyle(e), gc.update(), gc.getBoundingRect()
  }, Vh = yc;

  function yc() {}
  var mc = Vo(by = [
      ["lineWidth", "width"],
      ["stroke", "color"],
      ["opacity"],
      ["shadowBlur"],
      ["shadowOffsetX"],
      ["shadowOffsetY"],
      ["shadowColor"],
      ["lineDash", "type"],
      ["lineDashOffset", "dashOffset"],
      ["lineCap", "cap"],
      ["lineJoin", "join"],
      ["miterLimit"]
    ]),
    vc = (_c.prototype.getLineStyle = function(t) {
      return mc(this, t)
    }, _c);

  function _c() {}
  var xc = Vo(wy = [
      ["fill", "color"],
      ["stroke", "borderColor"],
      ["lineWidth", "borderWidth"],
      ["opacity"],
      ["shadowBlur"],
      ["shadowOffsetX"],
      ["shadowOffsetY"],
      ["shadowColor"],
      ["lineDash", "borderType"],
      ["lineDashOffset", "borderDashOffset"],
      ["lineCap", "borderCap"],
      ["lineJoin", "borderJoin"],
      ["miterLimit", "borderMiterLimit"]
    ]),
    wc = (bc.prototype.getItemStyle = function(t, e) {
      return xc(this, t, e)
    }, bc);

  function bc() {}
  Tc.prototype.init = function(t, e, n) {}, Tc.prototype.mergeOption = function(t, e) {
    C(this.option, t, !0)
  }, Tc.prototype.get = function(t, e) {
    return null == t ? this.option : this._doGet(this.parsePath(t), !e && this.parentModel)
  }, Tc.prototype.getShallow = function(t, e) {
    var n;
    return null != (n = null == (n = this.option) ? n : n[t]) || e || (e = this.parentModel) && (n = e.getShallow(t)), n
  }, Tc.prototype.getModel = function(t, e) {
    var n = null != t;
    t = n ? this.parsePath(t) : null;
    return new Tc(n ? this._doGet(t) : this.option, e = e || this.parentModel && this.parentModel.getModel(this.resolveParentPath(t)), this.ecModel)
  }, Tc.prototype.isEmpty = function() {
    return null == this.option
  }, Tc.prototype.restoreData = function() {}, Tc.prototype.clone = function() {
    return new this.constructor(I(this.option))
  }, Tc.prototype.parsePath = function(t) {
    return "string" == typeof t ? t.split(".") : t
  }, Tc.prototype.resolveParentPath = function(t) {
    return t
  }, Tc.prototype.isAnimationEnabled = function() {
    if (!o.node && this.option) return null != this.option.animation ? !!this.option.animation : this.parentModel ? this.parentModel.isAnimationEnabled() : void 0
  }, Tc.prototype._doGet = function(e, n) {
    var i = this.option;
    if (e) {
      for (var r = 0; r < e.length && (!e[r] || null != (i = i && "object" == t(i) ? i[e[r]] : null)); r++);
      null == i && n && (i = n._doGet(this.resolveParentPath(e), n.parentModel))
    }
    return i
  };
  var Sc, Mc = Tc;

  function Tc(t, e, n) {
    this.parentModel = e, this.ecModel = n, this.option = t
  }
  Ro(Mc), gy = Mc, Sc = ["__\0is_clz", Eo++].join("_"), gy.prototype[Sc] = !0, gy.isInstance = function(t) {
    return !(!t || !t[Sc])
  }, O(Mc, vc), O(Mc, wc), O(Mc, Wo), O(Mc, Vh);
  var Ic = Math.round(10 * Math.random());

  function Cc(t) {
    return [t || "", Ic++].join("_")
  }
  var kc = "EN",
    Dc = {},
    Ac = {},
    Lc = o.domSupported && -1 < (document.documentElement.lang || navigator.language || navigator.browserLanguage || kc).toUpperCase().indexOf("ZH") ? "ZH" : kc;

  function Pc(t, e) {
    t = t.toUpperCase(), Ac[t] = new Mc(e), Dc[t] = e
  }
  Pc("EN", {
    time: {
      month: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
      monthAbbr: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
      dayOfWeek: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
      dayOfWeekAbbr: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
    },
    legend: {
      selector: {
        all: "All",
        inverse: "Inv"
      }
    },
    toolbox: {
      brush: {
        title: {
          rect: "Box Select",
          polygon: "Lasso Select",
          lineX: "Horizontally Select",
          lineY: "Vertically Select",
          keep: "Keep Selections",
          clear: "Clear Selections"
        }
      },
      dataView: {
        title: "Data View",
        lang: ["Data View", "Close", "Refresh"]
      },
      dataZoom: {
        title: {
          zoom: "Zoom",
          back: "Zoom Reset"
        }
      },
      magicType: {
        title: {
          line: "Switch to Line Chart",
          bar: "Switch to Bar Chart",
          stack: "Stack",
          tiled: "Tile"
        }
      },
      restore: {
        title: "Restore"
      },
      saveAsImage: {
        title: "Save as Image",
        lang: ["Right Click to Save Image"]
      }
    },
    series: {
      typeNames: {
        pie: "Pie chart",
        bar: "Bar chart",
        line: "Line chart",
        scatter: "Scatter plot",
        effectScatter: "Ripple scatter plot",
        radar: "Radar chart",
        tree: "Tree",
        treemap: "Treemap",
        boxplot: "Boxplot",
        candlestick: "Candlestick",
        k: "K line chart",
        heatmap: "Heat map",
        map: "Map",
        parallel: "Parallel coordinate map",
        lines: "Line graph",
        graph: "Relationship graph",
        sankey: "Sankey diagram",
        funnel: "Funnel chart",
        gauge: "Gauge",
        pictorialBar: "Pictorial bar",
        themeRiver: "Theme River Map",
        sunburst: "Sunburst",
        custom: "Custom chart",
        chart: "Chart"
      }
    },
    aria: {
      general: {
        withTitle: 'This is a chart about "{title}"',
        withoutTitle: "This is a chart"
      },
      series: {
        single: {
          prefix: "",
          withName: " with type {seriesType} named {seriesName}.",
          withoutName: " with type {seriesType}."
        },
        multiple: {
          prefix: ". It consists of {seriesCount} series count.",
          withName: " The {seriesId} series is a {seriesType} representing {seriesName}.",
          withoutName: " The {seriesId} series is a {seriesType}.",
          separator: {
            middle: "",
            end: ""
          }
        }
      },
      data: {
        allData: "The data is as follows: ",
        partialData: "The first {displayCnt} items are: ",
        withName: "the data for {name} is {value}",
        withoutName: "{value}",
        separator: {
          middle: ", ",
          end: ". "
        }
      }
    }
  }), Pc("ZH", {
    time: {
      month: ["一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月"],
      monthAbbr: ["1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月", "9月", "10月", "11月", "12月"],
      dayOfWeek: ["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"],
      dayOfWeekAbbr: ["日", "一", "二", "三", "四", "五", "六"]
    },
    legend: {
      selector: {
        all: "全选",
        inverse: "反选"
      }
    },
    toolbox: {
      brush: {
        title: {
          rect: "矩形选择",
          polygon: "圈选",
          lineX: "横向选择",
          lineY: "纵向选择",
          keep: "保持选择",
          clear: "清除选择"
        }
      },
      dataView: {
        title: "数据视图",
        lang: ["数据视图", "关闭", "刷新"]
      },
      dataZoom: {
        title: {
          zoom: "区域缩放",
          back: "区域缩放还原"
        }
      },
      magicType: {
        title: {
          line: "切换为折线图",
          bar: "切换为柱状图",
          stack: "切换为堆叠",
          tiled: "切换为平铺"
        }
      },
      restore: {
        title: "还原"
      },
      saveAsImage: {
        title: "保存为图片",
        lang: ["右键另存为图片"]
      }
    },
    series: {
      typeNames: {
        pie: "饼图",
        bar: "柱状图",
        line: "折线图",
        scatter: "散点图",
        effectScatter: "涟漪散点图",
        radar: "雷达图",
        tree: "树图",
        treemap: "矩形树图",
        boxplot: "箱型图",
        candlestick: "K线图",
        k: "K线图",
        heatmap: "热力图",
        map: "地图",
        parallel: "平行坐标图",
        lines: "线图",
        graph: "关系图",
        sankey: "桑基图",
        funnel: "漏斗图",
        gauge: "仪表盘图",
        pictorialBar: "象形柱图",
        themeRiver: "主题河流图",
        sunburst: "旭日图",
        custom: "自定义图表",
        chart: "图表"
      }
    },
    aria: {
      general: {
        withTitle: "这是一个关于“{title}”的图表。",
        withoutTitle: "这是一个图表，"
      },
      series: {
        single: {
          prefix: "",
          withName: "图表类型是{seriesType}，表示{seriesName}。",
          withoutName: "图表类型是{seriesType}。"
        },
        multiple: {
          prefix: "它由{seriesCount}个图表系列组成。",
          withName: "第{seriesId}个系列是一个表示{seriesName}的{seriesType}，",
          withoutName: "第{seriesId}个系列是一个{seriesType}，",
          separator: {
            middle: "；",
            end: "。"
          }
        }
      },
      data: {
        allData: "其数据是——",
        partialData: "其中，前{displayCnt}项是——",
        withName: "{name}的数据是{value}",
        withoutName: "{value}",
        separator: {
          middle: "，",
          end: ""
        }
      }
    }
  });
  var Oc = 36e5,
    Rc = 24 * Oc,
    Nc = (Eo = 365 * Rc, {
      year: "{yyyy}",
      month: "{MMM}",
      day: "{d}",
      hour: "{HH}:{mm}",
      minute: "{HH}:{mm}",
      second: "{HH}:{mm}:{ss}",
      millisecond: "{HH}:{mm}:{ss} {SSS}",
      none: "{yyyy}-{MM}-{dd} {HH}:{mm}:{ss} {SSS}"
    }),
    Ec = {
      year: "{yyyy}",
      month: "{yyyy}-{MM}",
      day: gy = "{yyyy}-{MM}-{dd}",
      hour: gy + " " + Nc.hour,
      minute: gy + " " + Nc.minute,
      second: gy + " " + Nc.second,
      millisecond: Nc.none
    },
    zc = ["year", "month", "day", "hour", "minute", "second", "millisecond"],
    Bc = ["year", "half-year", "quarter", "month", "week", "half-week", "day", "half-day", "quarter-day", "hour", "minute", "second", "millisecond"];

  function Fc(t, e) {
    return "0000".substr(0, e - (t += "").length) + t
  }

  function Vc(t) {
    switch (t) {
      case "half-year":
      case "quarter":
        return "month";
      case "week":
      case "half-week":
        return "day";
      case "half-day":
      case "quarter-day":
        return "hour";
      default:
        return t
    }
  }

  function Hc(t, e, n, i) {
    var r = (t = eo(t))[Uc(n)](),
      o = t[Xc(n)]() + 1,
      a = Math.floor((o - 1) / 3) + 1,
      s = t[Yc(n)](),
      l = t["get" + (n ? "UTC" : "") + "Day"](),
      u = t[qc(n)](),
      h = (u - 1) % 12 + 1,
      c = t[jc(n)](),
      p = t[Zc(n)](),
      d = (t = t[Kc(n)](), (n = 12 <= u ? "pm" : "am").toUpperCase()),
      f = (i = (i instanceof Mc ? i : Ac[i || Lc] || Ac.EN).getModel("time")).get("month"),
      g = i.get("monthAbbr"),
      y = i.get("dayOfWeek");
    i = i.get("dayOfWeekAbbr");
    return (e || "").replace(/{a}/g, n + "").replace(/{A}/g, d + "").replace(/{yyyy}/g, r + "").replace(/{yy}/g, Fc(r % 100 + "", 2)).replace(/{Q}/g, a + "").replace(/{MMMM}/g, f[o - 1]).replace(/{MMM}/g, g[o - 1]).replace(/{MM}/g, Fc(o, 2)).replace(/{M}/g, o + "").replace(/{dd}/g, Fc(s, 2)).replace(/{d}/g, s + "").replace(/{eeee}/g, y[l]).replace(/{ee}/g, i[l]).replace(/{e}/g, l + "").replace(/{HH}/g, Fc(u, 2)).replace(/{H}/g, u + "").replace(/{hh}/g, Fc(h + "", 2)).replace(/{h}/g, h + "").replace(/{mm}/g, Fc(c, 2)).replace(/{m}/g, c + "").replace(/{ss}/g, Fc(p, 2)).replace(/{s}/g, p + "").replace(/{SSS}/g, Fc(t, 3)).replace(/{S}/g, t + "")
  }

  function Wc(t, e) {
    var n = (t = eo(t))[Xc(e)]() + 1,
      i = t[Yc(e)](),
      r = t[qc(e)](),
      o = t[jc(e)](),
      a = t[Zc(e)]();
    return (r = (o = (a = (e = (t = 0 === t[Kc(e)]()) && 0 === a) && 0 === o) && 0 === r) && 1 === i) && 1 === n ? "year" : r ? "month" : o ? "day" : a ? "hour" : e ? "minute" : t ? "second" : "millisecond"
  }

  function Gc(t, e, n) {
    var i = Y(t) ? eo(t) : t;
    switch (e = e || Wc(t, n)) {
      case "year":
        return i[Uc(n)]();
      case "half-year":
        return 6 <= i[Xc(n)]() ? 1 : 0;
      case "quarter":
        return Math.floor((i[Xc(n)]() + 1) / 4);
      case "month":
        return i[Xc(n)]();
      case "day":
        return i[Yc(n)]();
      case "half-day":
        return i[qc(n)]() / 24;
      case "hour":
        return i[qc(n)]();
      case "minute":
        return i[jc(n)]();
      case "second":
        return i[Zc(n)]();
      case "millisecond":
        return i[Kc(n)]()
    }
  }

  function Uc(t) {
    return t ? "getUTCFullYear" : "getFullYear"
  }

  function Xc(t) {
    return t ? "getUTCMonth" : "getMonth"
  }

  function Yc(t) {
    return t ? "getUTCDate" : "getDate"
  }

  function qc(t) {
    return t ? "getUTCHours" : "getHours"
  }

  function jc(t) {
    return t ? "getUTCMinutes" : "getMinutes"
  }

  function Zc(t) {
    return t ? "getUTCSeconds" : "getSeconds"
  }

  function Kc(t) {
    return t ? "getUTCMilliseconds" : "getMilliseconds"
  }

  function $c(t) {
    return t ? "setUTCMonth" : "setMonth"
  }

  function Qc(t) {
    return t ? "setUTCDate" : "setDate"
  }

  function Jc(t) {
    return t ? "setUTCHours" : "setHours"
  }

  function tp(t) {
    return t ? "setUTCMinutes" : "setMinutes"
  }

  function ep(t) {
    return t ? "setUTCSeconds" : "setSeconds"
  }

  function np(t) {
    return t ? "setUTCMilliseconds" : "setMilliseconds"
  }

  function ip(t) {
    var e;
    return ao(t) ? (e = (t + "").split("."))[0].replace(/(\d{1,3})(?=(?:\d{3})+(?!\d))/g, "$1,") + (1 < e.length ? "." + e[1] : "") : U(t) ? t : "-"
  }

  function rp(t, e) {
    return t = (t || "").toLowerCase().replace(/-(.)/g, (function(t, e) {
      return e.toUpperCase()
    })), e ? t && t.charAt(0).toUpperCase() + t.slice(1) : t
  }
  var op = ot;

  function ap(t, e, n) {
    function i(t) {
      return t && st(t) ? t : "-"
    }

    function r(t) {
      return null != t && !isNaN(t) && isFinite(t)
    }
    var o = "time" === e,
      a = t instanceof Date;
    if (o || a) {
      o = o ? eo(t) : t;
      if (!isNaN(+o)) return Hc(o, "{yyyy}-{MM}-{dd} {HH}:{mm}:{ss}", n);
      if (a) return "-"
    }
    return "ordinal" === e ? X(t) ? i(t) : Y(t) && r(t) ? t + "" : "-" : r(o = oo(t)) ? ip(o) : X(t) ? i(t) : "boolean" == typeof t ? t + "" : "-"
  }

  function sp(t, e) {
    return "{" + t + (null == e ? "" : e) + "}"
  }
  var lp = ["a", "b", "c", "d", "e", "f", "g"];

  function up(t, e, n) {
    var i = (e = W(e) ? e : [e]).length;
    if (!i) return "";
    for (var r = e[0].$vars || [], o = 0; o < r.length; o++) {
      var a = lp[o];
      t = t.replace(sp(a), sp(a, 0))
    }
    for (var s = 0; s < i; s++)
      for (var l = 0; l < r.length; l++) {
        var u = e[s][r[l]];
        t = t.replace(sp(lp[l], s), n ? ee(u) : u)
      }
    return t
  }

  function hp(t, e) {
    var n = (t = U(t) ? {
        color: t,
        extraCssText: e
      } : t || {}).color,
      i = t.type,
      r = (e = t.extraCssText, t.renderMode || "html");
    return n ? "html" === r ? "subItem" === i ? '<span style="display:inline-block;vertical-align:middle;margin-right:8px;margin-left:3px;border-radius:4px;width:4px;height:4px;background-color:' + ee(n) + ";" + (e || "") + '"></span>' : '<span style="display:inline-block;margin-right:4px;border-radius:10px;width:10px;height:10px;background-color:' + ee(n) + ";" + (e || "") + '"></span>' : {
      renderMode: r,
      content: "{" + (t.markerId || "markerX") + "|}  ",
      style: "subItem" === i ? {
        width: 4,
        height: 4,
        borderRadius: 2,
        backgroundColor: n
      } : {
        width: 10,
        height: 10,
        borderRadius: 5,
        backgroundColor: n
      }
    } : ""
  }

  function cp(t, e) {
    return e = e || "transparent", U(t) ? t : q(t) && t.colorStops && (t.colorStops[0] || {}).color || e
  }
  var pp = N,
    dp = ["left", "right", "top", "bottom", "width", "height"],
    fp = [
      ["width", "left", "right"],
      ["height", "top", "bottom"]
    ];

  function gp(t, e, n, i, r) {
    var o = 0,
      a = 0,
      s = (null == i && (i = 1 / 0), null == r && (r = 1 / 0), 0);
    e.eachChild((function(l, u) {
      var h, c, p, d = l.getBoundingRect();
      u = (u = e.childAt(u + 1)) && u.getBoundingRect();
      s = "horizontal" === t ? (c = d.width + (u ? -u.x + d.x : 0), i < (h = o + c) || l.newline ? (o = 0, h = c, a += s + n, d.height) : Math.max(s, d.height)) : (c = d.height + (u ? -u.y + d.y : 0), r < (p = a + c) || l.newline ? (o += s + n, a = 0, p = c, d.width) : Math.max(s, d.width)), l.newline || (l.x = o, l.y = a, l.markRedraw(), "horizontal" === t ? o = h + n : a = p + n)
    }))
  }

  function yp(t, e, n) {
    n = op(n || 0);
    var i = e.width,
      r = e.height,
      o = qr(t.left, i),
      a = qr(t.top, r),
      s = (e = qr(t.right, i), qr(t.bottom, r)),
      l = qr(t.width, i),
      u = qr(t.height, r),
      h = n[2] + n[0],
      c = n[1] + n[3],
      p = t.aspect;
    switch (isNaN(l) && (l = i - e - c - o), isNaN(u) && (u = r - s - h - a), null != p && (isNaN(l) && isNaN(u) && (i / r < p ? l = .8 * i : u = .8 * r), isNaN(l) && (l = p * u), isNaN(u)) && (u = l / p), isNaN(o) && (o = i - e - l - c), isNaN(a) && (a = r - s - u - h), t.left || t.right) {
      case "center":
        o = i / 2 - l / 2 - n[3];
        break;
      case "right":
        o = i - l - c
    }
    switch (t.top || t.bottom) {
      case "middle":
      case "center":
        a = r / 2 - u / 2 - n[0];
        break;
      case "bottom":
        a = r - u - h
    }
    return o = o || 0, a = a || 0, isNaN(l) && (l = i - c - o - (e || 0)), isNaN(u) && (u = r - h - a - (s || 0)), (p = new Oe(o + n[3], a + n[0], l, u)).margin = n, p
  }

  function mp(t) {
    return q(t = t.layoutMode || t.constructor.layoutMode) ? t : t ? {
      type: t
    } : null
  }

  function vp(t, e, n) {
    var i = n && n.ignoreSize,
      r = (n = (W(i) || (i = [i, i]), o(fp[0], 0)), o(fp[1], 1));

    function o(n, r) {
      var o = {},
        l = 0,
        u = {},
        h = 0;
      if (pp(n, (function(e) {
          u[e] = t[e]
        })), pp(n, (function(t) {
          a(e, t) && (o[t] = u[t] = e[t]), s(o, t) && l++, s(u, t) && h++
        })), i[r]) s(e, n[1]) ? u[n[2]] = null : s(e, n[2]) && (u[n[1]] = null);
      else if (2 !== h && l) {
        if (!(2 <= l))
          for (var c = 0; c < n.length; c++) {
            var p = n[c];
            if (!a(o, p) && a(t, p)) {
              o[p] = t[p];
              break
            }
          }
        return o
      }
      return u
    }

    function a(t, e) {
      return t.hasOwnProperty(e)
    }

    function s(t, e) {
      return null != t[e] && "auto" !== t[e]
    }

    function l(t, e, n) {
      pp(t, (function(t) {
        e[t] = n[t]
      }))
    }
    l(fp[0], t, n), l(fp[1], t, r)
  }

  function _p(t) {
    return e = {}, (n = t) && e && pp(dp, (function(t) {
      n.hasOwnProperty(t) && (e[t] = n[t])
    })), e;
    var e, n
  }
  H(gp, "vertical"), H(gp, "horizontal");
  var xp, wp, bp, Sp, Mp = So(),
    Tp = (i(Ip, xp = Mc), Ip.prototype.init = function(t, e, n) {
      this.mergeDefaultAndTheme(t, n)
    }, Ip.prototype.mergeDefaultAndTheme = function(t, e) {
      var n = mp(this),
        i = n ? _p(t) : {};
      C(t, e.getTheme().get(this.mainType)), C(t, this.getDefaultOption()), n && vp(t, i, n)
    }, Ip.prototype.mergeOption = function(t, e) {
      C(this.option, t, !0);
      var n = mp(this);
      n && vp(this.option, t, n)
    }, Ip.prototype.optionUpdated = function(t, e) {}, Ip.prototype.getDefaultOption = function() {
      var t = this.constructor;
      if (!(e = t) || !e[Po]) return t.defaultOption;
      var e = Mp(this);
      if (!e.defaultOption) {
        for (var n = [], i = t; i;) {
          var r = i.prototype.defaultOption;
          r && n.push(r), i = i.superClass
        }
        for (var o = {}, a = n.length - 1; 0 <= a; a--) o = C(o, n[a], !0);
        e.defaultOption = o
      }
      return e.defaultOption
    }, Ip.prototype.getReferringComponents = function(t, e) {
      var n = t + "Id";
      return ko(this.ecModel, t, {
        index: this.get(t + "Index", !0),
        id: this.get(n, !0)
      }, e)
    }, Ip.prototype.getBoxLayoutParams = function() {
      return {
        left: this.get("left"),
        top: this.get("top"),
        right: this.get("right"),
        bottom: this.get("bottom"),
        width: this.get("width"),
        height: this.get("height")
      }
    }, Ip.prototype.getZLevelKey = function() {
      return ""
    }, Ip.prototype.setZLevel = function(t) {
      this.option.zlevel = t
    }, Ip.protoInitialize = ((vc = Ip.prototype).type = "component", vc.id = "", vc.name = "", vc.mainType = "", vc.subType = "", void(vc.componentIndex = 0)), Ip);

  function Ip(t, e, n) {
    return (t = xp.call(this, t, e, n) || this).uid = Cc("ec_cpt_model"), t
  }

  function Cp(t, e) {
    return t[e] || (t[e] = {
      predecessor: [],
      successor: []
    }), t[e]
  }
  No(Tp, Mc), Fo(Tp), bp = {}, (wp = Tp).registerSubTypeDefaulter = function(t, e) {
    t = Oo(t), bp[t.main] = e
  }, wp.determineSubType = function(t, e) {
    var n, i = e.type;
    return i || (n = Oo(t).main, wp.hasSubTypes(t) && bp[n] && (i = bp[n](e))), i
  }, Sp = function(t) {
    var e = [];
    return N(Tp.getClassesByMainType(t), (function(t) {
      e = e.concat(t.dependencies || t.prototype.dependencies || [])
    })), e = E(e, (function(t) {
      return Oo(t).main
    })), "dataset" !== t && L(e, "dataset") <= 0 && e.unshift("dataset"), e
  }, Tp.topologicalTravel = function(t, e, n, i) {
    if (t.length) {
      o = {}, a = [], N(r = e, (function(t) {
        var e, n, i = Cp(o, t),
          s = i.originalDeps = Sp(t);
        e = r, n = [], N(s, (function(t) {
          0 <= L(e, t) && n.push(t)
        })), s = n;
        i.entryCount = s.length, 0 === i.entryCount && a.push(t), N(s, (function(e) {
          L(i.predecessor, e) < 0 && i.predecessor.push(e);
          var n = Cp(o, e);
          L(n.successor, e) < 0 && n.successor.push(t)
        }))
      }));
      var r, o, a, s = (e = {
          graph: o,
          noEntryList: a
        }).graph,
        l = e.noEntryList,
        u = {};
      for (N(t, (function(t) {
          u[t] = !0
        })); l.length;) {
        var h = l.pop(),
          c = s[h],
          p = !!u[h];
        p && (n.call(i, h, c.originalDeps.slice()), delete u[h]), N(c.successor, p ? f : d)
      }
      N(u, (function() {
        throw new Error("")
      }))
    }

    function d(t) {
      s[t].entryCount--, 0 === s[t].entryCount && l.push(t)
    }

    function f(t) {
      u[t] = !0, d(t)
    }
  };
  wc = "";
  var kp = {
      darkMode: "auto",
      colorBy: "series",
      color: ["#5470c6", "#91cc75", "#fac858", "#ee6666", "#73c0de", "#3ba272", "#fc8452", "#9a60b4", "#ea7ccc"],
      gradientColor: ["#f6efa6", "#d88273", "#bf444c"],
      aria: {
        decal: {
          decals: [{
            color: Wo = ("undefined" != typeof navigator && (wc = navigator.platform || ""), "rgba(0, 0, 0, 0.2)"),
            dashArrayX: [1, 0],
            dashArrayY: [2, 5],
            symbolSize: 1,
            rotation: Math.PI / 6
          }, {
            color: Wo,
            symbol: "circle",
            dashArrayX: [
              [8, 8],
              [0, 8, 8, 0]
            ],
            dashArrayY: [6, 0],
            symbolSize: .8
          }, {
            color: Wo,
            dashArrayX: [1, 0],
            dashArrayY: [4, 3],
            rotation: -Math.PI / 4
          }, {
            color: Wo,
            dashArrayX: [
              [6, 6],
              [0, 6, 6, 0]
            ],
            dashArrayY: [6, 0]
          }, {
            color: Wo,
            dashArrayX: [
              [1, 0],
              [1, 6]
            ],
            dashArrayY: [1, 0, 6, 0],
            rotation: Math.PI / 4
          }, {
            color: Wo,
            symbol: "triangle",
            dashArrayX: [
              [9, 9],
              [0, 9, 9, 0]
            ],
            dashArrayY: [7, 2],
            symbolSize: .75
          }]
        }
      },
      textStyle: {
        fontFamily: wc.match(/^Win/) ? "Microsoft YaHei" : "sans-serif",
        fontSize: 12,
        fontStyle: "normal",
        fontWeight: "normal"
      },
      blendMode: null,
      stateAnimation: {
        duration: 300,
        easing: "cubicOut"
      },
      animation: "auto",
      animationDuration: 1e3,
      animationDurationUpdate: 500,
      animationEasing: "cubicInOut",
      animationEasingUpdate: "cubicInOut",
      animationThreshold: 2e3,
      progressiveThreshold: 3e3,
      progressive: 400,
      hoverLayerThreshold: 3e3,
      useUTC: !1
    },
    Dp = yt(["tooltip", "label", "itemName", "itemId", "itemGroupId", "itemChildGroupId", "seriesName"]),
    Ap = "original",
    Lp = "arrayRows",
    Pp = "objectRows",
    Op = "keyedColumns",
    Rp = "typedArray",
    Np = "unknown",
    Ep = "column",
    zp = "row",
    Bp = 1,
    Fp = 2,
    Vp = 3,
    Hp = So();

  function Wp(t, e, n) {
    var i, r, o, a, s, l = {},
      u = Gp(e);
    return u && t && (i = [], r = [], e = e.ecModel, e = Hp(e).datasetMap, u = u.uid + "_" + n.seriesLayoutBy, N(t = t.slice(), (function(e, n) {
      "ordinal" === (e = q(e) ? e : t[n] = {
        name: e
      }).type && null == o && (o = n, a = c(e)), l[e.name] = []
    })), s = e.get(u) || e.set(u, {
      categoryWayDim: a,
      valueWayDim: 0
    }), N(t, (function(t, e) {
      var n, a = t.name;
      t = c(t);
      null == o ? (n = s.valueWayDim, h(l[a], n, t), h(r, n, t), s.valueWayDim += t) : o === e ? (h(l[a], 0, t), h(i, 0, t)) : (n = s.categoryWayDim, h(l[a], n, t), h(r, n, t), s.categoryWayDim += t)
    })), i.length && (l.itemName = i), r.length) && (l.seriesName = r), l;

    function h(t, e, n) {
      for (var i = 0; i < n; i++) t.push(e + i)
    }

    function c(t) {
      return (t = t.dimsDef) ? t.length : 1
    }
  }

  function Gp(t) {
    if (!t.get("data", !0)) return ko(t.ecModel, "dataset", {
      index: t.get("datasetIndex", !0),
      id: t.get("datasetId", !0)
    }, Co).models[0]
  }

  function Up(t, e) {
    var n, i, r, o = t.data,
      a = t.sourceFormat,
      s = t.seriesLayoutBy,
      l = t.dimensionsDefine,
      u = t.startIndex,
      h = e;
    if (!Z(o)) {
      if (l && (q(l = l[h]) ? (i = l.name, r = l.type) : U(l) && (i = l)), null != r) return "ordinal" === r ? Bp : Vp;
      if (a === Lp) {
        var c = o;
        if (s === zp) {
          for (var p = c[h], d = 0; d < (p || []).length && d < 5; d++)
            if (null != (n = _(p[u + d]))) return n
        } else
          for (d = 0; d < c.length && d < 5; d++) {
            var f = c[u + d];
            if (f && null != (n = _(f[h]))) return n
          }
      } else if (a === Pp) {
        var g = o;
        if (!i) return Vp;
        for (d = 0; d < g.length && d < 5; d++)
          if ((m = g[d]) && null != (n = _(m[i]))) return n
      } else if (a === Op) {
        if (!i) return Vp;
        if (!(p = (l = o)[i]) || Z(p)) return Vp;
        for (d = 0; d < p.length && d < 5; d++)
          if (null != (n = _(p[d]))) return n
      } else if (a === Ap) {
        var y = o;
        for (d = 0; d < y.length && d < 5; d++) {
          var m, v = yo(m = y[d]);
          if (!W(v)) return Vp;
          if (null != (n = _(v[h]))) return n
        }
      }
    }
    return Vp;

    function _(t) {
      var e = U(t);
      return null != t && Number.isFinite(Number(t)) && "" !== t ? e ? Fp : Vp : e && "-" !== t ? Bp : void 0
    }
  }
  var Xp, Yp, qp, jp = yt(),
    Zp = So(),
    Kp = (So(), $p.prototype.getColorFromPalette = function(t, e, n) {
      var i = po(this.get("color", !0)),
        r = this.get("colorLayer", !0),
        o = this,
        a = Zp;
      return o = (a = a(e = e || o)).paletteIdx || 0, (e = a.paletteNameMap = a.paletteNameMap || {}).hasOwnProperty(t) ? e[t] : (r = (r = null != n && r ? function(t, e) {
        for (var n = t.length, i = 0; i < n; i++)
          if (t[i].length > e) return t[i];
        return t[n - 1]
      }(r, n) : i) || i) && r.length ? (n = r[o], t && (e[t] = n), a.paletteIdx = (o + 1) % r.length, n) : void 0
    }, $p.prototype.clearColorPalette = function() {
      var t;
      (t = Zp)(this).paletteIdx = 0, t(this).paletteNameMap = {}
    }, $p);

  function $p() {}
  var Qp, Jp = "\0_ec_inner",
    td = (i(ed, Qp = Mc), ed.prototype.init = function(t, e, n, i, r, o) {
      i = i || {}, this.option = null, this._theme = new Mc(i), this._locale = new Mc(r), this._optionManager = o
    }, ed.prototype.setOption = function(t, e, n) {
      e = rd(e), this._optionManager.setOption(t, n, e), this._resetOption(null, e)
    }, ed.prototype.resetOption = function(t, e) {
      return this._resetOption(t, rd(e))
    }, ed.prototype._resetOption = function(t, e) {
      var n, i = !1,
        r = this._optionManager;
      return t && "recreate" !== t || (n = r.mountOption("recreate" === t), this.option && "recreate" !== t ? (this.restoreData(), this._mergeOption(n, e)) : qp(this, n), i = !0), "timeline" !== t && "media" !== t || this.restoreData(), t && "recreate" !== t && "timeline" !== t || (n = r.getTimelineOption(this)) && (i = !0, this._mergeOption(n, e)), t && "recreate" !== t && "media" !== t || (n = r.getMediaOption(this)).length && N(n, (function(t) {
        i = !0, this._mergeOption(t, e)
      }), this), i
    }, ed.prototype.mergeOption = function(t) {
      this._mergeOption(t, null)
    }, ed.prototype._mergeOption = function(t, e) {
      var n = this.option,
        i = this._componentsMap,
        r = this._componentsCount,
        o = [],
        a = yt(),
        s = e && e.replaceMergeMainTypeMap;
      Hp(this).datasetMap = yt(), N(t, (function(t, e) {
        null != t && (Tp.hasClass(e) ? e && (o.push(e), a.set(e, !0)) : n[e] = null == n[e] ? I(t) : C(n[e], t, !0))
      })), s && s.each((function(t, e) {
        Tp.hasClass(e) && !a.get(e) && (o.push(e), a.set(e, !0))
      })), Tp.topologicalTravel(o, Tp.getAllClassMainTypes(), (function(e) {
        var o, a, l = function(t, e, n) {
            return (e = (e = jp.get(e)) && e(t)) ? n.concat(e) : n
          }(this, e, po(t[e])),
          u = (function(t, e, n) {
            N(t, (function(t) {
              var i, r, o = t.newOption;
              q(o) && (t.keyInfo.mainType = e, t.keyInfo.subType = (i = e, o = o, t = t.existing, r = n, o.type || (t ? t.subType : r.determineSubType(i, o))))
            }))
          }(a = function(t, e, n) {
            var i, r, o, a, s, l, u, h, c, p, d = "normalMerge" === n,
              f = "replaceMerge" === n,
              g = "replaceAll" === n,
              y = (t = t || [], e = (e || []).slice(), yt());
            return N(e, (function(t, n) {
              q(t) || (e[n] = null)
            })), n = function(t, e, n) {
              var i = [];
              if ("replaceAll" !== n)
                for (var r = 0; r < t.length; r++) {
                  var o = t[r];
                  o && null != o.id && e.set(o.id, r), i.push({
                    existing: "replaceMerge" === n || wo(o) ? null : o,
                    newOption: null,
                    keyInfo: null,
                    brandNew: null
                  })
                }
              return i
            }(t, y, n), (d || f) && (i = n, r = t, o = y, N(a = e, (function(t, e) {
              var n, s, l;
              t && null != t.id && (n = vo(t.id), null != (s = o.get(n))) && (at(!(l = i[s]).newOption, 'Duplicated option on id "' + n + '".'), l.newOption = t, l.existing = r[s], a[e] = null)
            }))), d && (s = n, N(l = e, (function(t, e) {
              if (t && null != t.name)
                for (var n = 0; n < s.length; n++) {
                  var i = s[n].existing;
                  if (!s[n].newOption && i && (null == i.id || null == t.id) && !wo(t) && !wo(i) && mo("name", i, t)) return s[n].newOption = t, void(l[e] = null)
                }
            }))), d || f ? (h = n, c = f, N(e, (function(t) {
              if (t) {
                for (var e, n = 0;
                  (e = h[n]) && (e.newOption || wo(e.existing) || e.existing && null != t.id && !mo("id", t, e.existing));) n++;
                e ? (e.newOption = t, e.brandNew = c) : h.push({
                  newOption: t,
                  brandNew: c,
                  existing: null,
                  keyInfo: null
                }), n++
              }
            }))) : g && (u = n, N(e, (function(t) {
              u.push({
                newOption: t,
                brandNew: !0,
                existing: null,
                keyInfo: null
              })
            }))), t = n, p = yt(), N(t, (function(t) {
              var e = t.existing;
              e && p.set(e.id, t)
            })), N(t, (function(t) {
              var e = t.newOption;
              at(!e || null == e.id || !p.get(e.id) || p.get(e.id) === t, "id duplicates: " + (e && e.id)), e && null != e.id && p.set(e.id, t), t.keyInfo || (t.keyInfo = {})
            })), N(t, (function(t, e) {
              var n = t.existing,
                i = t.newOption,
                r = t.keyInfo;
              if (q(i)) {
                if (r.name = null != i.name ? vo(i.name) : n ? n.name : co + e, n) r.id = vo(n.id);
                else if (null != i.id) r.id = vo(i.id);
                else
                  for (var o = 0; r.id = "\0" + r.name + "\0" + o++, p.get(r.id););
                p.set(r.id, t)
              }
            })), n
          }(a = i.get(e), l, a ? s && s.get(e) ? "replaceMerge" : "normalMerge" : "replaceAll"), e, Tp), n[e] = null, i.set(e, null), r.set(e, 0), []),
          h = [],
          c = 0;
        N(a, (function(t, n) {
          var i = t.existing,
            r = t.newOption;
          if (r) {
            var a = Tp.getClass(e, t.keyInfo.subType, !("series" === e));
            if (!a) return;
            if ("tooltip" === e) {
              if (o) return;
              o = !0
            }
            i && i.constructor === a ? (i.name = t.keyInfo.name, i.mergeOption(r, this), i.optionUpdated(r, !1)) : (n = k({
              componentIndex: n
            }, t.keyInfo), k(i = new a(r, this, this, n), n), t.brandNew && (i.__requireNewView = !0), i.init(r, this, this), i.optionUpdated(null, !0))
          } else i && (i.mergeOption({}, this), i.optionUpdated({}, !1));
          i ? (u.push(i.option), h.push(i), c++) : (u.push(void 0), h.push(void 0))
        }), this), n[e] = u, i.set(e, h), r.set(e, c), "series" === e && Xp(this)
      }), this), this._seriesIndices || Xp(this)
    }, ed.prototype.getOption = function() {
      var t = I(this.option);
      return N(t, (function(e, n) {
        if (Tp.hasClass(n)) {
          for (var i = po(e), r = i.length, o = !1, a = r - 1; 0 <= a; a--) i[a] && !wo(i[a]) ? o = !0 : (i[a] = null, o || r--);
          i.length = r, t[n] = i
        }
      })), delete t[Jp], t
    }, ed.prototype.getTheme = function() {
      return this._theme
    }, ed.prototype.getLocaleModel = function() {
      return this._locale
    }, ed.prototype.setUpdatePayload = function(t) {
      this._payload = t
    }, ed.prototype.getUpdatePayload = function() {
      return this._payload
    }, ed.prototype.getComponent = function(t, e) {
      var n = this._componentsMap.get(t);
      if (n) {
        if (t = n[e || 0]) return t;
        if (null == e)
          for (var i = 0; i < n.length; i++)
            if (n[i]) return n[i]
      }
    }, ed.prototype.queryComponents = function(t) {
      var e, n, i, r, o, a = t.mainType;
      return a && (e = t.index, n = t.id, i = t.name, r = this._componentsMap.get(a)) && r.length ? (null != e ? (o = [], N(po(e), (function(t) {
        r[t] && o.push(r[t])
      }))) : o = null != n ? nd("id", n, r) : null != i ? nd("name", i, r) : B(r, (function(t) {
        return !!t
      })), id(o, t)) : []
    }, ed.prototype.findComponents = function(t) {
      var e, n = t.query,
        i = t.mainType,
        r = (r = i + "Index", o = i + "Id", e = i + "Name", !(n = n) || null == n[r] && null == n[o] && null == n[e] ? null : {
          mainType: i,
          index: n[r],
          id: n[o],
          name: n[e]
        }),
        o = r ? this.queryComponents(r) : B(this._componentsMap.get(i), (function(t) {
          return !!t
        }));
      return n = id(o, t), t.filter ? B(n, t.filter) : n
    }, ed.prototype.eachComponent = function(t, e, n) {
      var i = this._componentsMap;
      if (G(t)) {
        var r = e,
          o = t;
        i.each((function(t, e) {
          for (var n = 0; t && n < t.length; n++) {
            var i = t[n];
            i && o.call(r, e, i, i.componentIndex)
          }
        }))
      } else
        for (var a = U(t) ? i.get(t) : q(t) ? this.findComponents(t) : null, s = 0; a && s < a.length; s++) {
          var l = a[s];
          l && e.call(n, l, l.componentIndex)
        }
    }, ed.prototype.getSeriesByName = function(t) {
      var e = _o(t, null);
      return B(this._componentsMap.get("series"), (function(t) {
        return !!t && null != e && t.name === e
      }))
    }, ed.prototype.getSeriesByIndex = function(t) {
      return this._componentsMap.get("series")[t]
    }, ed.prototype.getSeriesByType = function(t) {
      return B(this._componentsMap.get("series"), (function(e) {
        return !!e && e.subType === t
      }))
    }, ed.prototype.getSeries = function() {
      return B(this._componentsMap.get("series"), (function(t) {
        return !!t
      }))
    }, ed.prototype.getSeriesCount = function() {
      return this._componentsCount.get("series")
    }, ed.prototype.eachSeries = function(t, e) {
      Yp(this), N(this._seriesIndices, (function(n) {
        var i = this._componentsMap.get("series")[n];
        t.call(e, i, n)
      }), this)
    }, ed.prototype.eachRawSeries = function(t, e) {
      N(this._componentsMap.get("series"), (function(n) {
        n && t.call(e, n, n.componentIndex)
      }))
    }, ed.prototype.eachSeriesByType = function(t, e, n) {
      Yp(this), N(this._seriesIndices, (function(i) {
        var r = this._componentsMap.get("series")[i];
        r.subType === t && e.call(n, r, i)
      }), this)
    }, ed.prototype.eachRawSeriesByType = function(t, e, n) {
      return N(this.getSeriesByType(t), e, n)
    }, ed.prototype.isSeriesFiltered = function(t) {
      return Yp(this), null == this._seriesIndicesMap.get(t.componentIndex)
    }, ed.prototype.getCurrentSeriesIndices = function() {
      return (this._seriesIndices || []).slice()
    }, ed.prototype.filterSeries = function(t, e) {
      Yp(this);
      var n = [];
      N(this._seriesIndices, (function(i) {
        var r = this._componentsMap.get("series")[i];
        t.call(e, r, i) && n.push(i)
      }), this), this._seriesIndices = n, this._seriesIndicesMap = yt(n)
    }, ed.prototype.restoreData = function(t) {
      Xp(this);
      var e = this._componentsMap,
        n = [];
      e.each((function(t, e) {
        Tp.hasClass(e) && n.push(e)
      })), Tp.topologicalTravel(n, Tp.getAllClassMainTypes(), (function(n) {
        N(e.get(n), (function(e) {
          !e || "series" === n && function(t, e) {
            var n, i;
            if (e) return n = e.seriesIndex, i = e.seriesId, e = e.seriesName, null != n && t.componentIndex !== n || null != i && t.id !== i || null != e && t.name !== e
          }(e, t) || e.restoreData()
        }))
      }))
    }, ed.internalField = (Xp = function(t) {
      var e = t._seriesIndices = [];
      N(t._componentsMap.get("series"), (function(t) {
        t && e.push(t.componentIndex)
      })), t._seriesIndicesMap = yt(e)
    }, Yp = function(t) {}, void(qp = function(e, n) {
      e.option = {}, e.option[Jp] = 1, e._componentsMap = yt({
        series: []
      }), e._componentsCount = yt();
      var i, r, o = n.aria;
      q(o) && null == o.enabled && (o.enabled = !0), i = n, o = e._theme.option, r = i.color && !i.colorLayer, N(o, (function(e, n) {
        "colorLayer" === n && r || Tp.hasClass(n) || ("object" == t(e) ? i[n] = i[n] ? C(i[n], e, !1) : I(e) : null == i[n] && (i[n] = e))
      })), C(n, kp, !1), e._mergeOption(n, null)
    })), ed);

  function ed() {
    return null !== Qp && Qp.apply(this, arguments) || this
  }

  function nd(t, e, n) {
    var i, r;
    return W(e) ? (i = yt(), N(e, (function(t) {
      null != t && null != _o(t, null) && i.set(t, !0)
    })), B(n, (function(e) {
      return e && i.get(e[t])
    }))) : (r = _o(e, null), B(n, (function(e) {
      return e && null != r && e[t] === r
    })))
  }

  function id(t, e) {
    return e.hasOwnProperty("subType") ? B(t, (function(t) {
      return t && t.subType === e.subType
    })) : t
  }

  function rd(t) {
    var e = yt();
    return t && N(po(t.replaceMerge), (function(t) {
      e.set(t, !0)
    })), {
      replaceMergeMainTypeMap: e
    }
  }

  function od(t) {
    N(ad, (function(e) {
      this[e] = V(t[e], t)
    }), this)
  }
  O(td, Kp);
  var ad = ["getDom", "getZr", "getWidth", "getHeight", "getDevicePixelRatio", "dispatchAction", "isSSR", "isDisposed", "on", "off", "getDataURL", "getConnectedDataURL", "getOption", "getId", "updateLabelLayout"],
    sd = {},
    ld = (ud.prototype.create = function(t, e) {
      var n = [];
      N(sd, (function(i, r) {
        i = i.create(t, e), n = n.concat(i || [])
      })), this._coordinateSystems = n
    }, ud.prototype.update = function(t, e) {
      N(this._coordinateSystems, (function(n) {
        n.update && n.update(t, e)
      }))
    }, ud.prototype.getCoordinateSystems = function() {
      return this._coordinateSystems.slice()
    }, ud.register = function(t, e) {
      sd[t] = e
    }, ud.get = function(t) {
      return sd[t]
    }, ud);

  function ud() {
    this._coordinateSystems = []
  }
  var hd = /^(min|max)?(.+)$/,
    cd = (pd.prototype.setOption = function(t, e, n) {
      t && (N(po(t.series), (function(t) {
        t && t.data && Z(t.data) && ut(t.data)
      })), N(po(t.dataset), (function(t) {
        t && t.source && Z(t.source) && ut(t.source)
      }))), t = I(t);
      var i = this._optionBackup;
      t = function(t, e, n) {
        var i, r, o = [],
          a = t.baseOption,
          s = t.timeline,
          l = t.options,
          u = t.media,
          h = !!t.media,
          c = !!(l || s || a && a.timeline);

        function p(t) {
          N(e, (function(e) {
            e(t, n)
          }))
        }
        return a ? (r = a).timeline || (r.timeline = s) : ((c || h) && (t.options = t.media = null), r = t), h && W(u) && N(u, (function(t) {
          t && t.option && (t.query ? o.push(t) : i = i || t)
        })), p(r), N(l, p), N(o, (function(t) {
          return p(t.option)
        })), {
          baseOption: r,
          timelineOptions: l || [],
          mediaDefault: i,
          mediaList: o
        }
      }(t, e, !i);
      this._newBaseOption = t.baseOption, i ? (t.timelineOptions.length && (i.timelineOptions = t.timelineOptions), t.mediaList.length && (i.mediaList = t.mediaList), t.mediaDefault && (i.mediaDefault = t.mediaDefault)) : this._optionBackup = t
    }, pd.prototype.mountOption = function(t) {
      var e = this._optionBackup;
      return this._timelineOptions = e.timelineOptions, this._mediaList = e.mediaList, this._mediaDefault = e.mediaDefault, this._currentMediaIndices = [], I(t ? e.baseOption : this._newBaseOption)
    }, pd.prototype.getTimelineOption = function(t) {
      var e, n = this._timelineOptions;
      return n.length && (t = t.getComponent("timeline")) ? I(n[t.getCurrentIndex()]) : e
    }, pd.prototype.getMediaOption = function(t) {
      var e = this._api.getWidth(),
        n = this._api.getHeight(),
        i = this._mediaList,
        r = this._mediaDefault,
        o = [],
        a = [];
      if (i.length || r) {
        for (var s, l, u = 0, h = i.length; u < h; u++) ! function(t, e, n) {
          var i = {
              width: e,
              height: n,
              aspectratio: e / n
            },
            r = !0;
          return N(t, (function(t, e) {
            var n;
            (e = e.match(hd)) && e[1] && e[2] && (n = e[1], e = e[2].toLowerCase(), e = i[e], t = t, ("min" === (n = n) ? t <= e : "max" === n ? e <= t : e === t) || (r = !1))
          })), r
        }(i[u].query, e, n) || o.push(u);
        (o = !o.length && r ? [-1] : o).length && (s = o, l = this._currentMediaIndices, s.join(",") !== l.join(",")) && (a = E(o, (function(t) {
          return I((-1 === t ? r : i[t]).option)
        }))), this._currentMediaIndices = o
      }
      return a
    }, pd);

  function pd(t) {
    this._timelineOptions = [], this._mediaList = [], this._currentMediaIndices = [], this._api = t
  }
  var dd = N,
    fd = q,
    gd = ["areaStyle", "lineStyle", "nodeStyle", "linkStyle", "chordStyle", "label", "labelLine"];

  function yd(t) {
    var e = t && t.itemStyle;
    if (e)
      for (var n = 0, i = gd.length; n < i; n++) {
        var r = gd[n],
          o = e.normal,
          a = e.emphasis;
        o && o[r] && (t[r] = t[r] || {}, t[r].normal ? C(t[r].normal, o[r]) : t[r].normal = o[r], o[r] = null), a && a[r] && (t[r] = t[r] || {}, t[r].emphasis ? C(t[r].emphasis, a[r]) : t[r].emphasis = a[r], a[r] = null)
      }
  }

  function md(t, e, n) {
    var i, r;
    t && t[e] && (t[e].normal || t[e].emphasis) && (i = t[e].normal, r = t[e].emphasis, i && (n ? (t[e].normal = t[e].emphasis = null, D(t[e], i)) : t[e] = i), r) && (t.emphasis = t.emphasis || {}, (t.emphasis[e] = r).focus && (t.emphasis.focus = r.focus), r.blurScope) && (t.emphasis.blurScope = r.blurScope)
  }

  function vd(t) {
    md(t, "itemStyle"), md(t, "lineStyle"), md(t, "areaStyle"), md(t, "label"), md(t, "labelLine"), md(t, "upperLabel"), md(t, "edgeLabel")
  }

  function _d(t, e) {
    var n = fd(t) && t[e],
      i = fd(n) && n.textStyle;
    if (i)
      for (var r = 0, o = go.length; r < o; r++) {
        var a = go[r];
        i.hasOwnProperty(a) && (n[a] = i[a])
      }
  }

  function xd(t) {
    t && (vd(t), _d(t, "label"), t.emphasis) && _d(t.emphasis, "label")
  }

  function wd(t) {
    return W(t) ? t : t ? [t] : []
  }

  function bd(t) {
    return (W(t) ? t[0] : t) || {}
  }

  function Sd(t) {
    t && N(Md, (function(e) {
      e[0] in t && !(e[1] in t) && (t[e[1]] = t[e[0]])
    }))
  }
  var Md = [
      ["x", "left"],
      ["y", "top"],
      ["x2", "right"],
      ["y2", "bottom"]
    ],
    Td = ["grid", "geo", "parallel", "legend", "toolbox", "title", "visualMap", "dataZoom", "timeline"],
    Id = [
      ["borderRadius", "barBorderRadius"],
      ["borderColor", "barBorderColor"],
      ["borderWidth", "barBorderWidth"]
    ];

  function Cd(t) {
    var e = t && t.itemStyle;
    if (e)
      for (var n = 0; n < Id.length; n++) {
        var i = Id[n][1],
          r = Id[n][0];
        null != e[i] && (e[r] = e[i])
      }
  }

  function kd(t) {
    t && "edge" === t.alignTo && null != t.margin && null == t.edgeDistance && (t.edgeDistance = t.margin)
  }

  function Dd(t) {
    t && t.downplay && !t.blur && (t.blur = t.downplay)
  }

  function Ad(e, n) {
    (function(t, e) {
      dd(wd(t.series), (function(t) {
        if (fd(t) && fd(t)) {
          yd(t), vd(t), _d(t, "label"), _d(t, "upperLabel"), _d(t, "edgeLabel"), t.emphasis && (_d(t.emphasis, "label"), _d(t.emphasis, "upperLabel"), _d(t.emphasis, "edgeLabel"));
          var e = t.markPoint,
            n = (e && (yd(e), xd(e)), t.markLine),
            i = (n && (yd(n), xd(n)), t.markArea),
            r = (i && xd(i), t.data);
          if ("graph" === t.type) {
            r = r || t.nodes;
            var o = t.links || t.edges;
            if (o && !Z(o))
              for (var a = 0; a < o.length; a++) xd(o[a]);
            N(t.categories, (function(t) {
              vd(t)
            }))
          }
          if (r && !Z(r))
            for (a = 0; a < r.length; a++) xd(r[a]);
          if ((e = t.markPoint) && e.data) {
            var s = e.data;
            for (a = 0; a < s.length; a++) xd(s[a])
          }
          if ((n = t.markLine) && n.data) {
            var l = n.data;
            for (a = 0; a < l.length; a++) W(l[a]) ? (xd(l[a][0]), xd(l[a][1])) : xd(l[a])
          }
          "gauge" === t.type ? (_d(t, "axisLabel"), _d(t, "title"), _d(t, "detail")) : "treemap" === t.type ? (md(t.breadcrumb, "itemStyle"), N(t.levels, (function(t) {
            vd(t)
          }))) : "tree" === t.type && vd(t.leaves)
        }
      }));
      var n = ["xAxis", "yAxis", "radiusAxis", "angleAxis", "singleAxis", "parallelAxis", "radar"];
      e && n.push("valueAxis", "categoryAxis", "logAxis", "timeAxis"), dd(n, (function(e) {
        dd(wd(t[e]), (function(t) {
          t && (_d(t, "axisLabel"), _d(t.axisPointer, "label"))
        }))
      })), dd(wd(t.parallel), (function(t) {
        _d(t = t && t.parallelAxisDefault, "axisLabel"), _d(t && t.axisPointer, "label")
      })), dd(wd(t.calendar), (function(t) {
        md(t, "itemStyle"), _d(t, "dayLabel"), _d(t, "monthLabel"), _d(t, "yearLabel")
      })), dd(wd(t.radar), (function(t) {
        _d(t, "name"), t.name && null == t.axisName && (t.axisName = t.name, delete t.name), null != t.nameGap && null == t.axisNameGap && (t.axisNameGap = t.nameGap, delete t.nameGap)
      })), dd(wd(t.geo), (function(t) {
        fd(t) && (xd(t), dd(wd(t.regions), (function(t) {
          xd(t)
        })))
      })), dd(wd(t.timeline), (function(t) {
        xd(t), md(t, "label"), md(t, "itemStyle"), md(t, "controlStyle", !0), W(t = t.data) && N(t, (function(t) {
          q(t) && (md(t, "label"), md(t, "itemStyle"))
        }))
      })), dd(wd(t.toolbox), (function(t) {
        md(t, "iconStyle"), dd(t.feature, (function(t) {
          md(t, "iconStyle")
        }))
      })), _d(bd(t.axisPointer), "label"), _d(bd(t.tooltip).axisPointer, "label")
    })(e, n), e.series = po(e.series), N(e.series, (function(e) {
      if (q(e)) {
        var n, i = e.type;
        if ("line" === i) null != e.clipOverflow && (e.clip = e.clipOverflow);
        else if ("pie" === i || "gauge" === i) {
          if (null != e.clockWise && (e.clockwise = e.clockWise), kd(e.label), (n = e.data) && !Z(n))
            for (var r = 0; r < n.length; r++) kd(n[r]);
          null != e.hoverOffset && (e.emphasis = e.emphasis || {}, e.emphasis.scaleSize = null) && (e.emphasis.scaleSize = e.hoverOffset)
        } else if ("gauge" === i) {
          var o = function(t, e) {
            for (var n = "pointer.color".split(","), i = t, r = 0; r < n.length && null != (i = i && i[n[r]]); r++);
            return i
          }(e);
          if (null != o) {
            for (var a, s = e, l = "itemStyle.color", u = l.split(","), h = s, c = 0; c < u.length - 1; c++) null == h[a = u[c]] && (h[a] = {}), h = h[a];
            null != h[u[c]] || (h[u[c]] = o)
          }
        } else if ("bar" === i) {
          if (Cd(e), Cd(e.backgroundStyle), Cd(e.emphasis), (n = e.data) && !Z(n))
            for (r = 0; r < n.length; r++) "object" == t(n[r]) && (Cd(n[r]), Cd(n[r] && n[r].emphasis))
        } else "sunburst" === i ? ((l = e.highlightPolicy) && (e.emphasis = e.emphasis || {}, e.emphasis.focus || (e.emphasis.focus = l)), Dd(e), function t(e, n) {
          if (e)
            for (var i = 0; i < e.length; i++) n(e[i]), e[i] && t(e[i].children, n)
        }(e.data, Dd)) : "graph" === i || "sankey" === i ? (s = e) && null != s.focusNodeAdjacency && (s.emphasis = s.emphasis || {}, null == s.emphasis.focus) && (s.emphasis.focus = "adjacency") : "map" === i && (e.mapType && !e.map && (e.map = e.mapType), e.mapLocation) && D(e, e.mapLocation);
        null != e.hoverAnimation && (e.emphasis = e.emphasis || {}, e.emphasis) && null == e.emphasis.scale && (e.emphasis.scale = e.hoverAnimation), Sd(e)
      }
    })), e.dataRange && (e.visualMap = e.dataRange), N(Td, (function(t) {
      (t = e[t]) && N(t = W(t) ? t : [t], (function(t) {
        Sd(t)
      }))
    }))
  }

  function Ld(t) {
    N(t, (function(e, n) {
      var i = [],
        r = [NaN, NaN],
        o = [e.stackResultDimension, e.stackedOverDimension],
        a = e.data,
        s = e.isStackedByIndex,
        l = e.seriesModel.get("stackStrategy") || "samesign";
      a.modify(o, (function(o, u, h) {
        var c, p, d = a.get(e.stackedDimension, h);
        if (isNaN(d)) return r;
        s ? p = a.getRawIndex(h) : c = a.get(e.stackedByDimension, h);
        for (var f, g, y, m = NaN, v = n - 1; 0 <= v; v--) {
          var _ = t[v];
          if (0 <= (p = s ? p : _.data.rawIndexOf(_.stackedByDimension, c)) && (_ = _.data.getByRawIndex(_.stackResultDimension, p), "all" === l || "positive" === l && 0 < _ || "negative" === l && _ < 0 || "samesign" === l && 0 <= d && 0 < _ || "samesign" === l && d <= 0 && _ < 0)) {
            f = d, g = _, void 0, y = Math.max(Zr(f), Zr(g)), f += g, d = 20 < y ? f : jr(f, y), m = _;
            break
          }
        }
        return i[0] = d, i[1] = m, i
      }))
    }))
  }
  var Pd, Od, Rd = function(t) {
    this.data = t.data || (t.sourceFormat === Op ? {} : []), this.sourceFormat = t.sourceFormat || Np, this.seriesLayoutBy = t.seriesLayoutBy || Ep, this.startIndex = t.startIndex || 0, this.dimensionsDetectedCount = t.dimensionsDetectedCount, this.metaRawOption = t.metaRawOption;
    var e = this.dimensionsDefine = t.dimensionsDefine;
    if (e)
      for (var n = 0; n < e.length; n++) {
        var i = e[n];
        null == i.type && Up(this, n) === Bp && (i.type = "ordinal")
      }
  };

  function Nd(t) {
    return t instanceof Rd
  }

  function Ed(t, e, n) {
    n = n || Bd(t);
    var i = e.seriesLayoutBy,
      r = function(t, e, n, i, r) {
        var o, a, s;
        return t ? (e === Lp ? (s = t, "auto" === i || null == i ? Vd((function(t) {
          null != t && "-" !== t && (U(t) ? null == a && (a = 1) : a = 0)
        }), n, s, 10) : a = Y(i) ? i : i ? 1 : 0, r || 1 !== a || (r = [], Vd((function(t, e) {
          r[e] = null != t ? t + "" : ""
        }), n, s, 1 / 0)), o = r ? r.length : n === zp ? s.length : s[0] ? s[0].length : null) : e === Pp ? r = r || function(t) {
          for (var e, n = 0; n < t.length && !(e = t[n++]););
          if (e) return F(e)
        }(t) : e === Op ? r || (r = [], N(t, (function(t, e) {
          r.push(e)
        }))) : e === Ap && (o = W(i = yo(t[0])) && i.length || 1), {
          startIndex: a,
          dimensionsDefine: Fd(r),
          dimensionsDetectedCount: o
        }) : {
          dimensionsDefine: Fd(r),
          startIndex: a,
          dimensionsDetectedCount: o
        }
      }(t, n, i, e.sourceHeader, e.dimensions);
    return new Rd({
      data: t,
      sourceFormat: n,
      seriesLayoutBy: i,
      dimensionsDefine: r.dimensionsDefine,
      startIndex: r.startIndex,
      dimensionsDetectedCount: r.dimensionsDetectedCount,
      metaRawOption: I(e)
    })
  }

  function zd(t) {
    return new Rd({
      data: t,
      sourceFormat: Z(t) ? Rp : Ap
    })
  }

  function Bd(t) {
    var e = Np;
    if (Z(t)) e = Rp;
    else if (W(t)) {
      0 === t.length && (e = Lp);
      for (var n = 0, i = t.length; n < i; n++) {
        var r = t[n];
        if (null != r) {
          if (W(r) || Z(r)) {
            e = Lp;
            break
          }
          if (q(r)) {
            e = Pp;
            break
          }
        }
      }
    } else if (q(t))
      for (var o in t)
        if (xt(t, o) && R(t[o])) {
          e = Op;
          break
        } return e
  }

  function Fd(t) {
    var e;
    if (t) return e = yt(), E(t, (function(t, n) {
      var i;
      return null != (t = {
        name: (t = q(t) ? t : {
          name: t
        }).name,
        displayName: t.displayName,
        type: t.type
      }).name && (t.name += "", null == t.displayName && (t.displayName = t.name), (i = e.get(t.name)) ? t.name += "-" + i.count++ : e.set(t.name, {
        count: 1
      })), t
    }))
  }

  function Vd(t, e, n, i) {
    if (e === zp)
      for (var r = 0; r < n.length && r < i; r++) t(n[r] ? n[r][0] : null, r);
    else {
      var o = n[0] || [];
      for (r = 0; r < o.length && r < i; r++) t(o[r], r)
    }
  }

  function Hd(t) {
    return (t = t.sourceFormat) === Pp || t === Op
  }
  Yd.prototype.getSource = function() {
    return this._source
  }, Yd.prototype.count = function() {
    return 0
  }, Yd.prototype.getItem = function(t, e) {}, Yd.prototype.appendData = function(t) {}, Yd.prototype.clean = function() {}, Yd.protoInitialize = ((Vh = Yd.prototype).pure = !1, void(Vh.persistent = !0)), Yd.internalField = (Od = function(t, e, n) {
    var i, r = n.sourceFormat,
      o = n.seriesLayoutBy,
      a = n.startIndex;
    n = n.dimensionsDefine;
    k(t, Pd[rf(r, o)]), r === Rp ? (t.getItem = Wd, t.count = Ud, t.fillStorage = Gd) : (i = Kd(r, o), t.getItem = V(i, null, e, a, n), i = Jd(r, o), t.count = V(i, null, e, a, n))
  }, Wd = function(t, e) {
    t -= this._offset, e = e || [];
    for (var n = this._data, i = this._dimSize, r = i * t, o = 0; o < i; o++) e[o] = n[r + o];
    return e
  }, Gd = function(t, e, n, i) {
    for (var r = this._data, o = this._dimSize, a = 0; a < o; a++) {
      for (var s = i[a], l = null == s[0] ? 1 / 0 : s[0], u = null == s[1] ? -1 / 0 : s[1], h = e - t, c = n[a], p = 0; p < h; p++) {
        var d = r[p * o + a];
        (c[t + p] = d) < l && (l = d), u < d && (u = d)
      }
      s[0] = l, s[1] = u
    }
  }, Ud = function() {
    return this._data ? this._data.length / this._dimSize : 0
  }, (Vh = {})[Lp + "_" + Ep] = {
    pure: !0,
    appendData: qd
  }, Vh[Lp + "_" + zp] = {
    pure: !0,
    appendData: function() {
      throw new Error('Do not support appendData when set seriesLayoutBy: "row".')
    }
  }, Vh[Pp] = {
    pure: !0,
    appendData: qd
  }, Vh[Op] = {
    pure: !0,
    appendData: function(t) {
      var e = this._data;
      N(t, (function(t, n) {
        for (var i = e[n] || (e[n] = []), r = 0; r < (t || []).length; r++) i.push(t[r])
      }))
    }
  }, Vh[Ap] = {
    appendData: qd
  }, Vh[Rp] = {
    persistent: !1,
    pure: !0,
    appendData: function(t) {
      this._data = t
    },
    clean: function() {
      this._offset += this.count(), this._data = null
    }
  }, void(Pd = Vh));
  var Wd, Gd, Ud, Xd = Yd;

  function Yd(t, e) {
    t = Nd(t) ? t : zd(t);
    var n = (this._source = t, this._data = t.data);
    t.sourceFormat === Rp && (this._offset = 0, this._dimSize = e, this._data = n), Od(this, n, t)
  }

  function qd(t) {
    for (var e = 0; e < t.length; e++) this._data.push(t[e])
  }

  function jd(t, e, n, i) {
    return t[i]
  }(gy = {})[Lp + "_" + Ep] = function(t, e, n, i) {
    return t[i + e]
  }, gy[Lp + "_" + zp] = function(t, e, n, i, r) {
    i += e;
    for (var o = r || [], a = t, s = 0; s < a.length; s++) {
      var l = a[s];
      o[s] = l ? l[i] : null
    }
    return o
  }, gy[Pp] = jd, gy[Op] = function(t, e, n, i, r) {
    for (var o = r || [], a = 0; a < n.length; a++) {
      var s = t[n[a].name];
      o[a] = s ? s[i] : null
    }
    return o
  }, gy[Ap] = jd;
  var Zd = gy;

  function Kd(t, e) {
    return Zd[rf(t, e)]
  }

  function $d(t, e, n) {
    return t.length
  }(vc = {})[Lp + "_" + Ep] = function(t, e, n) {
    return Math.max(0, t.length - e)
  }, vc[Lp + "_" + zp] = function(t, e, n) {
    return (t = t[0]) ? Math.max(0, t.length - e) : 0
  }, vc[Pp] = $d, vc[Op] = function(t, e, n) {
    return (t = t[n[0].name]) ? t.length : 0
  }, vc[Ap] = $d;
  var Qd = vc;

  function Jd(t, e) {
    return Qd[rf(t, e)]
  }

  function tf(t, e, n) {
    return t[e]
  }(Wo = {})[Lp] = tf, Wo[Pp] = function(t, e, n) {
    return t[n]
  }, Wo[Op] = tf, Wo[Ap] = function(t, e, n) {
    return (t = yo(t)) instanceof Array ? t[e] : t
  }, Wo[Rp] = tf;
  var ef = Wo;

  function nf(t) {
    return ef[t]
  }

  function rf(t, e) {
    return t === Lp ? t + "_" + e : t
  }

  function of(t, e, n) {
    var i, r;
    if (t && null != (e = t.getRawDataItem(e))) return i = (r = t.getStore()).getSource().sourceFormat, null != n ? (t = t.getDimensionIndex(n), n = r.getDimensionProperty(t), nf(i)(e, t, n)) : (r = e, i === Ap ? yo(e) : r)
  }
  var af = /\{@(.+?)\}/g,
    sf = (lf.prototype.getDataParams = function(t, e) {
      var n = this.getData(e),
        i = this.getRawValue(t, e),
        r = n.getRawIndex(t),
        o = n.getName(t),
        a = n.getRawDataItem(t),
        s = (t = (s = n.getItemVisual(t, "style")) && s[n.getItemVisual(t, "drawType") || "fill"], s && s.stroke),
        l = this.mainType,
        u = "series" === l;
      n = n.userOutput && n.userOutput.get();
      return {
        componentType: l,
        componentSubType: this.subType,
        componentIndex: this.componentIndex,
        seriesType: u ? this.subType : null,
        seriesIndex: this.seriesIndex,
        seriesId: u ? this.id : null,
        seriesName: u ? this.name : null,
        name: o,
        dataIndex: r,
        data: a,
        dataType: e,
        value: i,
        color: t,
        borderColor: s,
        dimensionNames: n ? n.fullDimensions : null,
        encode: n ? n.encode : null,
        $vars: ["seriesName", "name", "value"]
      }
    }, lf.prototype.getFormattedLabel = function(t, e, n, i, r, o) {
      e = e || "normal";
      var a = this.getData(n);
      n = this.getDataParams(t, n);
      return o && (n.value = o.interpolatedValue), null != i && W(n.value) && (n.value = n.value[i]), G(r = r || a.getItemModel(t).get("normal" === e ? ["label", "formatter"] : [e, "label", "formatter"])) ? (n.status = e, n.dimensionIndex = i, r(n)) : U(r) ? up(r, n).replace(af, (function(e, n) {
        var i = n.length;
        "[" === n.charAt(0) && "]" === n.charAt(i - 1) && (n = +n.slice(1, i - 1)), i = of(a, t, n);
        return null != (i = o && W(o.interpolatedValue) && 0 <= (n = a.getDimensionIndex(n)) ? o.interpolatedValue[n] : i) ? i + "" : ""
      })) : void 0
    }, lf.prototype.getRawValue = function(t, e) {
      return of(this.getData(e), t)
    }, lf.prototype.formatTooltip = function(t, e, n) {}, lf);

  function lf() {}

  function uf(t) {
    var e, n;
    return q(t) ? t.type && (n = t) : e = t, {
      text: e,
      frag: n
    }
  }

  function hf(t) {
    return new cf(t)
  }
  pf.prototype.perform = function(t) {
    var e, n, i = this._upstream,
      r = t && t.skip,
      o = (this._dirty && i && ((o = this.context).data = o.outputData = i.context.outputData), this.__pipeline && (this.__pipeline.currentTask = this), this._plan && !r && (e = this._plan(this.context)), u(this._modBy)),
      a = this._modDataCount || 0,
      s = u(t && t.modBy),
      l = t && t.modDataCount || 0;

    function u(t) {
      return 1 <= t ? t : 1
    }
    if (o === s && a === l || (e = "reset"), !this._dirty && "reset" !== e || (this._dirty = !1, n = this._doReset(r)), this._modBy = s, this._modDataCount = l, o = t && t.step, this._dueEnd = i ? i._outputDueEnd : this._count ? this._count(this.context) : 1 / 0, this._progress) {
      var h = this._dueIndex,
        c = Math.min(null != o ? this._dueIndex + o : 1 / 0, this._dueEnd);
      if (!r && (n || h < c)) {
        var p = this._progress;
        if (W(p))
          for (var d = 0; d < p.length; d++) this._doProgress(p[d], h, c, s, l);
        else this._doProgress(p, h, c, s, l)
      }
      this._dueIndex = c, a = null != this._settedOutputEnd ? this._settedOutputEnd : c, this._outputDueEnd = a
    } else this._dueIndex = this._outputDueEnd = null != this._settedOutputEnd ? this._settedOutputEnd : this._dueEnd;
    return this.unfinished()
  }, pf.prototype.dirty = function() {
    this._dirty = !0, this._onDirty && this._onDirty(this.context)
  }, pf.prototype._doProgress = function(t, e, n, i, r) {
    _f.reset(e, n, i, r), this._callingProgress = t, this._callingProgress({
      start: e,
      end: n,
      count: n - e,
      next: _f.next
    }, this.context)
  }, pf.prototype._doReset = function(t) {
    var e, n;
    return this._dueIndex = this._outputDueEnd = this._dueEnd = 0, this._settedOutputEnd = null, !t && this._reset && ((e = this._reset(this.context)) && e.progress && (n = e.forceFirstProgress, e = e.progress), W(e)) && !e.length && (e = null), this._progress = e, this._modBy = this._modDataCount = null, (t = this._downstream) && t.dirty(), n
  }, pf.prototype.unfinished = function() {
    return this._progress && this._dueIndex < this._dueEnd
  }, pf.prototype.pipe = function(t) {
    this._downstream === t && !this._dirty || ((this._downstream = t)._upstream = this, t.dirty())
  }, pf.prototype.dispose = function() {
    this._disposed || (this._upstream && (this._upstream._downstream = null), this._downstream && (this._downstream._upstream = null), this._dirty = !1, this._disposed = !0)
  }, pf.prototype.getUpstream = function() {
    return this._upstream
  }, pf.prototype.getDownstream = function() {
    return this._downstream
  }, pf.prototype.setOutputEnd = function(t) {
    this._outputDueEnd = this._settedOutputEnd = t
  };
  var cf = pf;

  function pf(t) {
    this._reset = (t = t || {}).reset, this._plan = t.plan, this._count = t.count, this._onDirty = t.onDirty, this._dirty = !0
  }
  var df, ff, gf, yf, mf, vf, _f = vf = {
    reset: function(t, e, n, i) {
      ff = t, df = e, gf = n, yf = i, mf = Math.ceil(yf / gf), vf.next = 1 < gf && 0 < yf ? wf : xf
    }
  };

  function xf() {
    return ff < df ? ff++ : null
  }

  function wf() {
    var t = ff % mf * gf + Math.ceil(ff / mf);
    t = df <= ff ? null : t < yf ? t : ff;
    return ff++, t
  }

  function bf(t, e) {
    return "ordinal" === (e = e && e.type) ? t : null == (t = "time" !== e || Y(t) || null == t || "-" === t ? t : +eo(t)) || "" === t ? NaN : Number(t)
  }
  var Sf = yt({
    number: function(t) {
      return parseFloat(t)
    },
    time: function(t) {
      return +eo(t)
    },
    trim: function(t) {
      return U(t) ? st(t) : t
    }
  });

  function Mf(t) {
    return Sf.get(t)
  }
  var Tf = {
      lt: function(t, e) {
        return t < e
      },
      lte: function(t, e) {
        return t <= e
      },
      gt: function(t, e) {
        return e < t
      },
      gte: function(t, e) {
        return e <= t
      }
    },
    If = (Cf.prototype.evaluate = function(t) {
      return Y(t) ? this._opFn(t, this._rvalFloat) : this._opFn(oo(t), this._rvalFloat)
    }, Cf);

  function Cf(t, e) {
    Y(e) || uo(""), this._opFn = Tf[t], this._rvalFloat = oo(e)
  }
  Df.prototype.evaluate = function(t, e) {
    var n = Y(t) ? t : oo(t),
      i = Y(e) ? e : oo(e),
      r = isNaN(n),
      o = isNaN(i);
    return r && (n = this._incomparable), o && (i = this._incomparable), r && o && (r = U(t), o = U(e), r && (n = o ? t : 0), o) && (i = r ? e : 0), n < i ? this._resultLT : i < n ? -this._resultLT : 0
  };
  var kf = Df;

  function Df(t, e) {
    t = "desc" === t, this._resultLT = t ? 1 : -1, this._incomparable = "min" === (e = null == e ? t ? "min" : "max" : e) ? -1 / 0 : 1 / 0
  }
  Lf.prototype.evaluate = function(e) {
    var n, i = e === this._rval;
    return i || (n = t(e)) === this._rvalTypeof || "number" != n && "number" !== this._rvalTypeof || (i = oo(e) === this._rvalFloat), this._isEQ ? i : !i
  };
  var Af = Lf;

  function Lf(e, n) {
    this._rval = n, this._isEQ = e, this._rvalTypeof = t(n), this._rvalFloat = oo(n)
  }
  Of.prototype.getRawData = function() {
    throw new Error("not supported")
  }, Of.prototype.getRawDataItem = function(t) {
    throw new Error("not supported")
  }, Of.prototype.cloneRawData = function() {}, Of.prototype.getDimensionInfo = function(t) {}, Of.prototype.cloneAllDimensionInfo = function() {}, Of.prototype.count = function() {}, Of.prototype.retrieveValue = function(t, e) {}, Of.prototype.retrieveValueFromItem = function(t, e) {}, Of.prototype.convertValue = bf;
  var Pf = Of;

  function Of() {}

  function Rf(t) {
    return Ff(t.sourceFormat) || uo(""), t.data
  }

  function Nf(t) {
    var e = t.sourceFormat,
      n = t.data;
    if (Ff(e) || uo(""), e === Lp) {
      for (var i = [], r = 0, o = n.length; r < o; r++) i.push(n[r].slice());
      return i
    }
    if (e === Pp) {
      for (i = [], r = 0, o = n.length; r < o; r++) i.push(k({}, n[r]));
      return i
    }
  }

  function Ef(t, e, n) {
    if (null != n) return Y(n) || !isNaN(n) && !xt(e, n) ? t[n] : xt(e, n) ? e[n] : void 0
  }

  function zf(t) {
    return I(t)
  }
  var Bf = yt();

  function Ff(t) {
    return t === Lp || t === Pp
  }
  wc = "undefined";
  var Vf, Hf = ("undefined" == typeof Uint32Array ? "undefined" : t(Uint32Array)) == wc ? Array : Uint32Array,
    Wf = ("undefined" == typeof Uint16Array ? "undefined" : t(Uint16Array)) == wc ? Array : Uint16Array,
    Gf = ("undefined" == typeof Int32Array ? "undefined" : t(Int32Array)) == wc ? Array : Int32Array,
    Uf = {
      float: Vh = ("undefined" == typeof Float64Array ? "undefined" : t(Float64Array)) == wc ? Array : Float64Array,
      int: Gf,
      ordinal: Array,
      number: Array,
      time: Vh
    };

  function Xf(t) {
    return 65535 < t ? Hf : Wf
  }

  function Yf(t, e, n, i, r) {
    if (n = Uf[n || "float"], r) {
      var o = t[e],
        a = o && o.length;
      if (a !== i) {
        for (var s = new n(i), l = 0; l < a; l++) s[l] = o[l];
        t[e] = s
      }
    } else t[e] = new n(i)
  }
  jf.prototype.initData = function(t, e, n) {
    this._provider = t, this._chunks = [], this._indices = null, this.getRawIndex = this._getRawIdxIdentity;
    var i = t.getSource(),
      r = this.defaultDimValueGetter = Vf[i.sourceFormat];
    this._dimValueGetter = n || r, this._rawExtent = [], Hd(i), this._dimensions = E(e, (function(t) {
      return {
        type: t.type,
        property: t.property
      }
    })), this._initDataFromProvider(0, t.count())
  }, jf.prototype.getProvider = function() {
    return this._provider
  }, jf.prototype.getSource = function() {
    return this._provider.getSource()
  }, jf.prototype.ensureCalculationDimension = function(t, e) {
    var n = this._calcDimNameToIdx,
      i = this._dimensions,
      r = n.get(t);
    if (null != r) {
      if (i[r].type === e) return r
    } else r = i.length;
    return i[r] = {
      type: e
    }, n.set(t, r), this._chunks[r] = new Uf[e || "float"](this._rawCount), this._rawExtent[r] = [1 / 0, -1 / 0], r
  }, jf.prototype.collectOrdinalMeta = function(t, e) {
    for (var n = this._chunks[t], i = this._dimensions[t], r = this._rawExtent, o = i.ordinalOffset || 0, a = n.length, s = (0 === o && (r[t] = [1 / 0, -1 / 0]), r[t]), l = o; l < a; l++) {
      var u = n[l] = e.parseAndCollect(n[l]);
      isNaN(u) || (s[0] = Math.min(u, s[0]), s[1] = Math.max(u, s[1]))
    }
    i.ordinalMeta = e, i.ordinalOffset = a, i.type = "ordinal"
  }, jf.prototype.getOrdinalMeta = function(t) {
    return this._dimensions[t].ordinalMeta
  }, jf.prototype.getDimensionProperty = function(t) {
    return (t = this._dimensions[t]) && t.property
  }, jf.prototype.appendData = function(t) {
    var e = this._provider,
      n = this.count();
    e.appendData(t), t = e.count();
    return e.persistent || (t += n), n < t && this._initDataFromProvider(n, t, !0), [n, t]
  }, jf.prototype.appendValues = function(t, e) {
    for (var n = this._chunks, i = this._dimensions, r = i.length, o = this._rawExtent, a = this.count(), s = a + Math.max(t.length, e || 0), l = 0; l < r; l++) Yf(n, l, (d = i[l]).type, s, !0);
    for (var u = [], h = a; h < s; h++)
      for (var c = h - a, p = 0; p < r; p++) {
        var d = i[p],
          f = Vf.arrayRows.call(this, t[c] || u, d.property, c, p),
          g = (n[p][h] = f, o[p]);
        f < g[0] && (g[0] = f), f > g[1] && (g[1] = f)
      }
    return {
      start: a,
      end: this._rawCount = this._count = s
    }
  }, jf.prototype._initDataFromProvider = function(t, e, n) {
    for (var i = this._provider, r = this._chunks, o = this._dimensions, a = o.length, s = this._rawExtent, l = E(o, (function(t) {
        return t.property
      })), u = 0; u < a; u++) {
      var h = o[u];
      s[u] || (s[u] = [1 / 0, -1 / 0]), Yf(r, u, h.type, e, n)
    }
    if (i.fillStorage) i.fillStorage(t, e, r, s);
    else
      for (var c = [], p = t; p < e; p++) {
        c = i.getItem(p, c);
        for (var d = 0; d < a; d++) {
          var f = r[d],
            g = this._dimValueGetter(c, l[d], p, d);
          g < (f = (f[p] = g, s[d]))[0] && (f[0] = g), g > f[1] && (f[1] = g)
        }
      }!i.persistent && i.clean && i.clean(), this._rawCount = this._count = e, this._extent = []
  }, jf.prototype.count = function() {
    return this._count
  }, jf.prototype.get = function(t, e) {
    return 0 <= e && e < this._count && (t = this._chunks[t]) ? t[this.getRawIndex(e)] : NaN
  }, jf.prototype.getValues = function(t, e) {
    var n = [],
      i = [];
    if (null == e) {
      e = t, t = [];
      for (var r = 0; r < this._dimensions.length; r++) i.push(r)
    } else i = t;
    r = 0;
    for (var o = i.length; r < o; r++) n.push(this.get(i[r], e));
    return n
  }, jf.prototype.getByRawIndex = function(t, e) {
    return 0 <= e && e < this._rawCount && (t = this._chunks[t]) ? t[e] : NaN
  }, jf.prototype.getSum = function(t) {
    var e = 0;
    if (this._chunks[t])
      for (var n = 0, i = this.count(); n < i; n++) {
        var r = this.get(t, n);
        isNaN(r) || (e += r)
      }
    return e
  }, jf.prototype.getMedian = function(t) {
    var e = [],
      n = (t = (this.each([t], (function(t) {
        isNaN(t) || e.push(t)
      })), e.sort((function(t, e) {
        return t - e
      }))), this.count());
    return 0 === n ? 0 : n % 2 == 1 ? t[(n - 1) / 2] : (t[n / 2] + t[n / 2 - 1]) / 2
  }, jf.prototype.indexOfRawIndex = function(t) {
    if (!(t >= this._rawCount || t < 0)) {
      if (!this._indices) return t;
      var e = this._indices,
        n = e[t];
      if (null != n && n < this._count && n === t) return t;
      for (var i = 0, r = this._count - 1; i <= r;) {
        var o = (i + r) / 2 | 0;
        if (e[o] < t) i = 1 + o;
        else {
          if (!(e[o] > t)) return o;
          r = o - 1
        }
      }
    }
    return -1
  }, jf.prototype.indicesOfNearest = function(t, e, n) {
    var i = this._chunks[t],
      r = [];
    if (i) {
      null == n && (n = 1 / 0);
      for (var o = 1 / 0, a = -1, s = 0, l = 0, u = this.count(); l < u; l++) {
        var h = e - i[this.getRawIndex(l)],
          c = Math.abs(h);
        c <= n && ((c < o || c === o && 0 <= h && a < 0) && (o = c, a = h, s = 0), h === a) && (r[s++] = l)
      }
      r.length = s
    }
    return r
  }, jf.prototype.getIndices = function() {
    var t = this._indices;
    if (t) {
      var e = t.constructor,
        n = this._count;
      if (e === Array)
        for (var i = new e(n), r = 0; r < n; r++) i[r] = t[r];
      else i = new e(t.buffer, 0, n)
    } else
      for (i = new(e = Xf(this._rawCount))(this.count()), r = 0; r < i.length; r++) i[r] = r;
    return i
  }, jf.prototype.filter = function(t, e) {
    if (!this._count) return this;
    for (var n = this.clone(), i = n.count(), r = new(Xf(n._rawCount))(i), o = [], a = t.length, s = 0, l = t[0], u = n._chunks, h = 0; h < i; h++) {
      var c = void 0,
        p = n.getRawIndex(h);
      if (0 === a) c = e(h);
      else if (1 === a) c = e(u[l][p], h);
      else {
        for (var d = 0; d < a; d++) o[d] = u[t[d]][p];
        o[d] = h, c = e.apply(null, o)
      }
      c && (r[s++] = p)
    }
    return s < i && (n._indices = r), n._count = s, n._extent = [], n._updateGetRawIdx(), n
  }, jf.prototype.selectRange = function(t) {
    var e = this.clone(),
      n = e._count;
    if (!n) return this;
    var i = F(t),
      r = i.length;
    if (!r) return this;
    var o = e.count(),
      a = new(Xf(e._rawCount))(o),
      s = 0,
      l = t[c = i[0]][0],
      u = t[c][1],
      h = e._chunks,
      c = !1;
    if (!e._indices) {
      var p = 0;
      if (1 === r) {
        for (var d = h[i[0]], f = 0; f < n; f++)(l <= (v = d[f]) && v <= u || isNaN(v)) && (a[s++] = p), p++;
        c = !0
      } else if (2 === r) {
        d = h[i[0]];
        var g = h[i[1]],
          y = t[i[1]][0],
          m = t[i[1]][1];
        for (f = 0; f < n; f++) {
          var v = d[f],
            _ = g[f];
          (l <= v && v <= u || isNaN(v)) && (y <= _ && _ <= m || isNaN(_)) && (a[s++] = p), p++
        }
        c = !0
      }
    }
    if (!c)
      if (1 === r)
        for (f = 0; f < o; f++) {
          var x = e.getRawIndex(f);
          (l <= (v = h[i[0]][x]) && v <= u || isNaN(v)) && (a[s++] = x)
        } else
          for (f = 0; f < o; f++) {
            for (var w = !0, b = (x = e.getRawIndex(f), 0); b < r; b++) {
              var S = i[b];
              ((v = h[S][x]) < t[S][0] || v > t[S][1]) && (w = !1)
            }
            w && (a[s++] = e.getRawIndex(f))
          }
    return s < o && (e._indices = a), e._count = s, e._extent = [], e._updateGetRawIdx(), e
  }, jf.prototype.map = function(t, e) {
    var n = this.clone(t);
    return this._updateDims(n, t, e), n
  }, jf.prototype.modify = function(t, e) {
    this._updateDims(this, t, e)
  }, jf.prototype._updateDims = function(e, n, i) {
    for (var r = e._chunks, o = [], a = n.length, s = e.count(), l = [], u = e._rawExtent, h = 0; h < n.length; h++) u[n[h]] = [1 / 0, -1 / 0];
    for (var c = 0; c < s; c++) {
      for (var p = e.getRawIndex(c), d = 0; d < a; d++) l[d] = r[n[d]][p];
      l[a] = c;
      var f = i && i.apply(null, l);
      if (null != f)
        for ("object" != t(f) && (o[0] = f, f = o), h = 0; h < f.length; h++) {
          var g = n[h],
            y = f[h],
            m = u[g];
          (g = r[g]) && (g[p] = y), y < m[0] && (m[0] = y), y > m[1] && (m[1] = y)
        }
    }
  }, jf.prototype.lttbDownSample = function(t, e) {
    var n, i = this.clone([t], !0),
      r = i._chunks[t],
      o = this.count(),
      a = 0,
      s = Math.floor(1 / e),
      l = this.getRawIndex(0),
      u = new(Xf(this._rawCount))(Math.min(2 * (Math.ceil(o / s) + 2), o));
    u[a++] = l;
    for (var h = 1; h < o - 1; h += s) {
      for (var c = Math.min(h + s, o - 1), p = Math.min(h + 2 * s, o), d = (p + c) / 2, f = 0, g = c; g < p; g++) {
        var y = r[M = this.getRawIndex(g)];
        isNaN(y) || (f += y)
      }
      f /= p - c;
      c = h;
      var m = Math.min(h + s, o),
        v = h - 1,
        _ = r[l],
        x = -1,
        w = c,
        b = -1,
        S = 0;
      for (g = c; g < m; g++) {
        var M;
        y = r[M = this.getRawIndex(g)];
        isNaN(y) ? (S++, b < 0 && (b = M)) : x < (n = Math.abs((v - d) * (y - _) - (v - g) * (f - _))) && (x = n, w = M)
      }
      0 < S && S < m - c && (u[a++] = Math.min(b, w), w = Math.max(b, w)), l = u[a++] = w
    }
    return u[a++] = this.getRawIndex(o - 1), i._count = a, i._indices = u, i.getRawIndex = this._getRawIdx, i
  }, jf.prototype.downSample = function(t, e, n, i) {
    for (var r = this.clone([t], !0), o = r._chunks, a = [], s = Math.floor(1 / e), l = o[t], u = this.count(), h = r._rawExtent[t] = [1 / 0, -1 / 0], c = new(Xf(this._rawCount))(Math.ceil(u / s)), p = 0, d = 0; d < u; d += s) {
      u - d < s && (a.length = s = u - d);
      for (var f = 0; f < s; f++) {
        var g = this.getRawIndex(d + f);
        a[f] = l[g]
      }
      var y = n(a),
        m = this.getRawIndex(Math.min(d + i(a, y) || 0, u - 1));
      (l[m] = y) < h[0] && (h[0] = y), y > h[1] && (h[1] = y), c[p++] = m
    }
    return r._count = p, r._indices = c, r._updateGetRawIdx(), r
  }, jf.prototype.each = function(t, e) {
    if (this._count)
      for (var n = t.length, i = this._chunks, r = 0, o = this.count(); r < o; r++) {
        var a = this.getRawIndex(r);
        switch (n) {
          case 0:
            e(r);
            break;
          case 1:
            e(i[t[0]][a], r);
            break;
          case 2:
            e(i[t[0]][a], i[t[1]][a], r);
            break;
          default:
            for (var s = 0, l = []; s < n; s++) l[s] = i[t[s]][a];
            l[s] = r, e.apply(null, l)
        }
      }
  }, jf.prototype.getDataExtent = function(t) {
    var e = this._chunks[t],
      n = [1 / 0, -1 / 0];
    if (!e) return n;
    var i = this.count();
    if (!this._indices) return this._rawExtent[t].slice();
    if (r = this._extent[t]) return r.slice();
    for (var r, o = (r = n)[0], a = r[1], s = 0; s < i; s++) {
      var l = e[this.getRawIndex(s)];
      l < o && (o = l), a < l && (a = l)
    }
    return this._extent[t] = [o, a]
  }, jf.prototype.getRawDataItem = function(t) {
    var e = this.getRawIndex(t);
    if (this._provider.persistent) return this._provider.getItem(e);
    for (var n = [], i = this._chunks, r = 0; r < i.length; r++) n.push(i[r][e]);
    return n
  }, jf.prototype.clone = function(t, e) {
    var n, i, r = new jf,
      o = this._chunks,
      a = t && z(t, (function(t, e) {
        return t[e] = !0, t
      }), {});
    if (a)
      for (var s = 0; s < o.length; s++) r._chunks[s] = a[s] ? (i = void 0, (i = (n = o[s]).constructor) === Array ? n.slice() : new i(n)) : o[s];
    else r._chunks = o;
    return this._copyCommonProps(r), e || (r._indices = this._cloneIndices()), r._updateGetRawIdx(), r
  }, jf.prototype._copyCommonProps = function(t) {
    t._count = this._count, t._rawCount = this._rawCount, t._provider = this._provider, t._dimensions = this._dimensions, t._extent = I(this._extent), t._rawExtent = I(this._rawExtent)
  }, jf.prototype._cloneIndices = function() {
    if (this._indices) {
      var t = this._indices.constructor,
        e = void 0;
      if (t === Array)
        for (var n = this._indices.length, i = (e = new t(n), 0); i < n; i++) e[i] = this._indices[i];
      else e = new t(this._indices);
      return e
    }
    return null
  }, jf.prototype._getRawIdxIdentity = function(t) {
    return t
  }, jf.prototype._getRawIdx = function(t) {
    return t < this._count && 0 <= t ? this._indices[t] : -1
  }, jf.prototype._updateGetRawIdx = function() {
    this.getRawIndex = this._indices ? this._getRawIdx : this._getRawIdxIdentity
  }, jf.internalField = void(Vf = {
    arrayRows: Zf,
    objectRows: function(t, e, n, i) {
      return bf(t[e], this._dimensions[i])
    },
    keyedColumns: Zf,
    original: function(t, e, n, i) {
      return bf((t = t && (null == t.value ? t : t.value)) instanceof Array ? t[i] : t, this._dimensions[i])
    },
    typedArray: function(t, e, n, i) {
      return t[i]
    }
  });
  var qf = jf;

  function jf() {
    this._chunks = [], this._rawExtent = [], this._extent = [], this._count = 0, this._rawCount = 0, this._calcDimNameToIdx = yt()
  }

  function Zf(t, e, n, i) {
    return bf(t[i], this._dimensions[i])
  }
  $f.prototype.dirty = function() {
    this._setLocalSource([], []), this._storeList = [], this._dirty = !0
  }, $f.prototype._setLocalSource = function(t, e) {
    this._sourceList = t, this._upstreamSignList = e, this._versionSignBase++, 9e10 < this._versionSignBase && (this._versionSignBase = 0)
  }, $f.prototype._getVersionSign = function() {
    return this._sourceHost.uid + "_" + this._versionSignBase
  }, $f.prototype.prepareSource = function() {
    this._isDirty() && (this._createSource(), this._dirty = !1)
  }, $f.prototype._createSource = function() {
    this._setLocalSource([], []);
    var t, e, n, i, r, o, a, s = this._sourceHost,
      l = this._getUpstreamSourceManagers(),
      u = !!l.length;
    Jf(s) ? (i = s, r = t = o = void 0, e = u ? ((e = l[0]).prepareSource(), o = (r = e.getSource()).data, t = r.sourceFormat, [e._getVersionSign()]) : (t = Z(o = i.get("data", !0)) ? Rp : Ap, []), i = this._getSourceMetaRawOption() || {}, r = r && r.metaRawOption || {}, a = nt(i.seriesLayoutBy, r.seriesLayoutBy) || null, n = nt(i.sourceHeader, r.sourceHeader), i = nt(i.dimensions, r.dimensions), r = a !== r.seriesLayoutBy || !!n != !!r.sourceHeader || i ? [Ed(o, {
      seriesLayoutBy: a,
      sourceHeader: n,
      dimensions: i
    }, t)] : []) : (o = s, e = u ? (r = (a = this._applyTransform(l)).sourceList, a.upstreamSignList) : (r = [Ed(o.get("source", !0), this._getSourceMetaRawOption(), null)], [])), this._setLocalSource(r, e)
  }, $f.prototype._applyTransform = function(t) {
    var e, n = this._sourceHost,
      i = n.get("transform", !0),
      r = n.get("fromTransformResult", !0),
      o = (null != r && 1 !== t.length && tg(""), []),
      a = [];
    return N(t, (function(t) {
      t.prepareSource();
      var e = t.getSource(r || 0);
      null == r || e || tg(""), o.push(e), a.push(t._getVersionSign())
    })), i ? e = function(t, e) {
      var n = po(t);
      (t = n.length) || uo("");
      for (var i = 0, r = t; i < r; i++) e = function(t, e) {
        e.length || uo(""), q(t) || uo("");
        var n = t.type,
          i = Bf.get(n);
        return i || uo(""), n = E(e, (function(t) {
          var e = t,
            n = (t = i, new Pf),
            r = e.data,
            o = n.sourceFormat = e.sourceFormat,
            a = e.startIndex,
            s = (e.seriesLayoutBy !== Ep && uo(""), []),
            l = {};
          if (c = e.dimensionsDefine) N(c, (function(t, e) {
            var n = t.name;
            e = {
              index: e,
              name: n,
              displayName: t.displayName
            };
            s.push(e), null != n && (xt(l, n) && uo(""), l[n] = e)
          }));
          else
            for (var u = 0; u < e.dimensionsDetectedCount; u++) s.push({
              index: u
            });
          var h = Kd(o, Ep),
            c = (t.__isBuiltIn && (n.getRawDataItem = function(t) {
              return h(r, a, s, t)
            }, n.getRawData = V(Rf, null, e)), n.cloneRawData = V(Nf, null, e), Jd(o, Ep)),
            p = (n.count = V(c, null, r, a, s), nf(o)),
            d = (n.retrieveValue = function(t, e) {
              return t = h(r, a, s, t), d(t, e)
            }, n.retrieveValueFromItem = function(t, e) {
              var n;
              return null != t && (n = s[e]) ? p(t, e, n.name) : void 0
            });
          return n.getDimensionInfo = V(Ef, null, s, l), n.cloneAllDimensionInfo = V(zf, null, s), n
        })), E(po(i.transform({
          upstream: n[0],
          upstreamList: n,
          config: I(t.config)
        })), (function(t, n) {
          q(t) || uo(""), t.data || uo(""), Ff(Bd(t.data)) || uo("");
          var i = e[0];
          n = i && 0 === n && !t.dimensions ? ((n = i.startIndex) && (t.data = i.data.slice(0, n).concat(t.data)), {
            seriesLayoutBy: Ep,
            sourceHeader: n,
            dimensions: i.metaRawOption.dimensions
          }) : {
            seriesLayoutBy: Ep,
            sourceHeader: 0,
            dimensions: t.dimensions
          };
          return Ed(t.data, n, null)
        }))
      }(n[i], e), i !== r - 1 && (e.length = Math.max(e.length, 1));
      return e
    }(i, o, n.componentIndex) : null != r && (e = [new Rd({
      data: (t = o[0]).data,
      sourceFormat: t.sourceFormat,
      seriesLayoutBy: t.seriesLayoutBy,
      dimensionsDefine: I(t.dimensionsDefine),
      startIndex: t.startIndex,
      dimensionsDetectedCount: t.dimensionsDetectedCount
    })]), {
      sourceList: e,
      upstreamSignList: a
    }
  }, $f.prototype._isDirty = function() {
    if (this._dirty) return !0;
    for (var t = this._getUpstreamSourceManagers(), e = 0; e < t.length; e++) {
      var n = t[e];
      if (n._isDirty() || this._upstreamSignList[e] !== n._getVersionSign()) return !0
    }
  }, $f.prototype.getSource = function(t) {
    var e = this._sourceList[t = t || 0];
    return e || (e = this._getUpstreamSourceManagers())[0] && e[0].getSource(t)
  }, $f.prototype.getSharedDataStore = function(t) {
    var e = t.makeStoreSchema();
    return this._innerGetDataStore(e.dimensions, t.source, e.hash)
  }, $f.prototype._innerGetDataStore = function(t, e, n) {
    var i, r, o = (r = this._storeList)[0];
    return (r = (o = o || (r[0] = {}))[n]) || (i = this._getUpstreamSourceManagers()[0], Jf(this._sourceHost) && i ? r = i._innerGetDataStore(t, e, n) : (r = new qf).initData(new Xd(e, t.length), t), o[n] = r), r
  }, $f.prototype._getUpstreamSourceManagers = function() {
    var t, e = this._sourceHost;
    return Jf(e) ? (t = Gp(e)) ? [t.getSourceManager()] : [] : E((t = e).get("transform", !0) || t.get("fromTransformResult", !0) ? ko(t.ecModel, "dataset", {
      index: t.get("fromDatasetIndex", !0),
      id: t.get("fromDatasetId", !0)
    }, Co).models : [], (function(t) {
      return t.getSourceManager()
    }))
  }, $f.prototype._getSourceMetaRawOption = function() {
    var t, e, n, i = this._sourceHost;
    return Jf(i) ? (t = i.get("seriesLayoutBy", !0), e = i.get("sourceHeader", !0), n = i.get("dimensions", !0)) : this._getUpstreamSourceManagers().length || (t = (i = i).get("seriesLayoutBy", !0), e = i.get("sourceHeader", !0), n = i.get("dimensions", !0)), {
      seriesLayoutBy: t,
      sourceHeader: e,
      dimensions: n
    }
  };
  var Kf = $f;

  function $f(t) {
    this._sourceList = [], this._storeList = [], this._upstreamSignList = [], this._versionSignBase = 0, this._dirty = !0, this._sourceHost = t
  }

  function Qf(t) {
    t.option.transform && ut(t.option.transform)
  }

  function Jf(t) {
    return "series" === t.mainType
  }

  function tg(t) {
    throw new Error(t)
  }
  var eg = "line-height:1";

  function ng(t, e) {
    var n = t.color || "#6e7079",
      i = t.fontSize || 12,
      r = t.fontWeight || "400",
      o = t.color || "#464646",
      a = t.fontSize || 14;
    t = t.fontWeight || "900";
    return "html" === e ? {
      nameStyle: "font-size:" + ee(i + "") + "px;color:" + ee(n) + ";font-weight:" + ee(r + ""),
      valueStyle: "font-size:" + ee(a + "") + "px;color:" + ee(o) + ";font-weight:" + ee(t + "")
    } : {
      nameStyle: {
        fontSize: i,
        fill: n,
        fontWeight: r
      },
      valueStyle: {
        fontSize: a,
        fill: o,
        fontWeight: t
      }
    }
  }
  var ig = [0, 10, 20, 30],
    rg = ["", "\n", "\n\n", "\n\n\n"];

  function og(t, e) {
    return e.type = t, e
  }

  function ag(t) {
    return "section" === t.type
  }

  function sg(t) {
    return ag(t) ? lg : ug
  }

  function lg(t, e, n, i) {
    var r, o = e.noHeader,
      a = (l = function t(e) {
        var n, i, r;
        return ag(e) ? (n = 0, i = e.blocks.length, r = 1 < i || 0 < i && !e.noHeader, N(e.blocks, (function(e) {
          var i = t(e);
          n <= i && (n = i + +(r && (!i || ag(e) && !e.noHeader)))
        })), n) : 0
      }(e), {
        html: ig[l],
        richText: rg[l]
      }),
      s = [],
      l = e.blocks || [],
      u = (at(!l || W(l)), l = l || [], t.orderMode),
      h = (e.sortBlocks && u && (l = l.slice(), xt(h = {
        valueAsc: "asc",
        valueDesc: "desc"
      }, u) ? (r = new kf(h[u], null), l.sort((function(t, e) {
        return r.evaluate(t.sortParam, e.sortParam)
      }))) : "seriesDesc" === u && l.reverse()), N(l, (function(n, r) {
        var o = e.valueFormatter;
        null != (o = sg(n)(o ? k(k({}, t), {
          valueFormatter: o
        }) : t, n, 0 < r ? a.html : 0, i)) && s.push(o)
      })), "richText" === t.renderMode ? s.join(a.richText) : cg(s.join(""), o ? n : a.html));
    return o ? h : (u = ap(e.header, "ordinal", t.useUTC), l = ng(i, t.renderMode).nameStyle, "richText" === t.renderMode ? pg(t, u, l) + a.richText + h : cg('<div style="' + l + ";" + eg + ';">' + ee(u) + "</div>" + h, n))
  }

  function ug(t, e, n, i) {
    var r, o, a, s, l = t.renderMode,
      u = e.noName,
      h = e.noValue,
      c = !e.markerType,
      p = e.name,
      d = t.useUTC,
      f = e.valueFormatter || t.valueFormatter || function(t) {
        return E(t = W(t) ? t : [t], (function(t, e) {
          return ap(t, W(o) ? o[e] : o, d)
        }))
      };
    if (!u || !h) return r = c ? "" : t.markupStyleCreator.makeTooltipMarker(e.markerType, e.markerColor || "#333", l), p = u ? "" : ap(p, "ordinal", d), o = e.valueType, f = h ? [] : f(e.value, e.dataIndex), e = !c || !u, a = !c && u, s = (i = ng(i, l)).nameStyle, i = i.valueStyle, "richText" === l ? (c ? "" : r) + (u ? "" : pg(t, p, s)) + (h ? "" : function(t, e, n, i, r) {
      return r = [r], i = i ? 10 : 20, n && r.push({
        padding: [0, 0, 0, i],
        align: "right"
      }), t.markupStyleCreator.wrapRichTextStyle(W(e) ? e.join("  ") : e, r)
    }(t, f, e, a, i)) : cg((c ? "" : r) + (u ? "" : '<span style="' + s + ";" + (c ? "" : "margin-left:2px") + '">' + ee(p) + "</span>") + (h ? "" : function(t, e, n, i) {
      return n = n ? "10px" : "20px", '<span style="' + (e = e ? "float:right;margin-left:" + n : "") + ";" + i + '">' + E(t = W(t) ? t : [t], ee).join("&nbsp;&nbsp;") + "</span>"
    }(f, e, a, i)), n)
  }

  function hg(t, e, n, i, r, o) {
    if (t) return sg(t)({
      useUTC: r,
      renderMode: n,
      orderMode: i,
      markupStyleCreator: e,
      valueFormatter: t.valueFormatter
    }, t, 0, o)
  }

  function cg(t, e) {
    return '<div style="margin: ' + e + "px 0 0;" + eg + ';">' + t + '<div style="clear:both"></div></div>'
  }

  function pg(t, e, n) {
    return t.markupStyleCreator.wrapRichTextStyle(e, n)
  }

  function dg(t, e) {
    return null != (t = t.get("padding")) ? t : "richText" === e ? [8, 10] : 10
  }
  gg.prototype._generateStyleName = function() {
    return "__EC_aUTo_" + this._nextStyleNameId++
  }, gg.prototype.makeTooltipMarker = function(t, e, n) {
    var i = "richText" === n ? this._generateStyleName() : null;
    return U(e = hp({
      color: e,
      type: t,
      renderMode: n,
      markerId: i
    })) ? e : (this.richTextStyles[i] = e.style, e.content)
  }, gg.prototype.wrapRichTextStyle = function(t, e) {
    var n = {};
    W(e) ? N(e, (function(t) {
      return k(n, t)
    })) : k(n, e), e = this._generateStyleName();
    return this.richTextStyles[e] = n, "{" + e + "|" + t + "}"
  };
  var fg = gg;

  function gg() {
    this.richTextStyles = {}, this._nextStyleNameId = so()
  }
  var yg = So();

  function mg(t, e) {
    return t.getName(e) || t.getId(e)
  }
  i(xg, vg = Tp), xg.prototype.init = function(t, e, n) {
    this.seriesIndex = this.componentIndex, this.dataTask = hf({
      count: bg,
      reset: Sg
    }), this.dataTask.context = {
      model: this
    }, this.mergeDefaultAndTheme(t, n), (yg(this).sourceManager = new Kf(this)).prepareSource(), Tg(t = this.getInitialData(t, n), this), this.dataTask.context.data = t, yg(this).dataBeforeProcessed = t, wg(this), this._initSelectedMapFromData(t)
  }, xg.prototype.mergeDefaultAndTheme = function(t, e) {
    var n = mp(this),
      i = n ? _p(t) : {},
      r = this.subType;
    Tp.hasClass(r), C(t, e.getTheme().get(this.subType)), C(t, this.getDefaultOption()), fo(t, "label", ["show"]), this.fillDataTextStyle(t.data), n && vp(t, i, n)
  }, xg.prototype.mergeOption = function(t, e) {
    var n;
    t = C(this.option, t, !0), this.fillDataTextStyle(t.data), Tg(n = ((n = ((n = mp(this)) && vp(this.option, t, n), yg(this).sourceManager)).dirty(), n.prepareSource(), this.getInitialData(t, e)), this), this.dataTask.dirty(), this.dataTask.context.data = n, yg(this).dataBeforeProcessed = n, wg(this), this._initSelectedMapFromData(n)
  }, xg.prototype.fillDataTextStyle = function(t) {
    if (t && !Z(t))
      for (var e = ["show"], n = 0; n < t.length; n++) t[n] && t[n].label && fo(t[n], "label", e)
  }, xg.prototype.getInitialData = function(t, e) {}, xg.prototype.appendData = function(t) {
    this.getRawData().appendData(t.data)
  }, xg.prototype.getData = function(t) {
    var e = Cg(this);
    return e ? (e = e.context.data, null != t && e.getLinkedData ? e.getLinkedData(t) : e) : yg(this).data
  }, xg.prototype.getAllData = function() {
    var t = this.getData();
    return t && t.getLinkedDataAll ? t.getLinkedDataAll() : [{
      data: t
    }]
  }, xg.prototype.setData = function(t) {
    var e, n = Cg(this);
    n && ((e = n.context).outputData = t, n !== this.dataTask) && (e.data = t), yg(this).data = t
  }, xg.prototype.getEncode = function() {
    var t = this.get("encode", !0);
    if (t) return yt(t)
  }, xg.prototype.getSourceManager = function() {
    return yg(this).sourceManager
  }, xg.prototype.getSource = function() {
    return this.getSourceManager().getSource()
  }, xg.prototype.getRawData = function() {
    return yg(this).dataBeforeProcessed
  }, xg.prototype.getColorBy = function() {
    return this.get("colorBy") || "series"
  }, xg.prototype.isColorBySeries = function() {
    return "series" === this.getColorBy()
  }, xg.prototype.getBaseAxis = function() {
    var t = this.coordinateSystem;
    return t && t.getBaseAxis && t.getBaseAxis()
  }, xg.prototype.formatTooltip = function(t, e, n) {
    return function(t) {
      var e, n, i, r, o, a, s, l, u, h, c, p = t.series,
        d = t.dataIndex,
        f = (t = t.multipleSeries, p.getData()),
        g = (x = f.mapDimensionsAll("defaultedTooltip")).length,
        y = p.getRawValue(d),
        m = W(y),
        v = (v = d, cp((w = p).getData().getItemVisual(v, "style")[w.visualDrawType]));

      function _(t, e) {
        (e = s.getDimensionInfo(e)) && !1 !== e.otherDims.tooltip && (l ? c.push(og("nameValue", {
          markerType: "subItem",
          markerColor: a,
          name: e.displayName,
          value: t,
          valueType: e.type
        })) : (u.push(t), h.push(e.type)))
      }
      1 < g || m && !g ? (w = y, r = d, o = x, a = v, s = p.getData(), l = z(w, (function(t, e, n) {
        return n = s.getDimensionInfo(n), t || n && !1 !== n.tooltip && null != n.displayName
      }), !1), u = [], h = [], c = [], o.length ? N(o, (function(t) {
        _(of(s, r, t), t)
      })) : N(w, _), e = (o = {
        inlineValues: u,
        inlineValueTypes: h,
        blocks: c
      }).inlineValueTypes, n = o.blocks, i = (o = o.inlineValues)[0]) : g ? (w = f.getDimensionInfo(x[0]), i = o = of(f, d, x[0]), e = w.type) : i = o = m ? y[0] : y;
      var x = (g = xo(p)) && p.name || "",
        w = f.getName(d);
      return og("section", {
        header: x,
        noHeader: t || !g,
        sortParam: i,
        blocks: [og("nameValue", {
          markerType: "item",
          markerColor: v,
          name: m = t ? x : w,
          noName: !st(m),
          value: o,
          valueType: e,
          dataIndex: d
        })].concat(n || [])
      })
    }({
      series: this,
      dataIndex: t,
      multipleSeries: e
    })
  }, xg.prototype.isAnimationEnabled = function() {
    var t = this.ecModel;
    return !!(!o.node || t && t.ssr) && !!(t = !((t = this.getShallow("animation")) && this.getData().count() > this.getShallow("animationThreshold")) && t)
  }, xg.prototype.restoreData = function() {
    this.dataTask.dirty()
  }, xg.prototype.getColorFromPalette = function(t, e, n) {
    var i = this.ecModel;
    return Kp.prototype.getColorFromPalette.call(this, t, e, n) || i.getColorFromPalette(t, e, n)
  }, xg.prototype.coordDimToDataDim = function(t) {
    return this.getRawData().mapDimensionsAll(t)
  }, xg.prototype.getProgressive = function() {
    return this.get("progressive")
  }, xg.prototype.getProgressiveThreshold = function() {
    return this.get("progressiveThreshold")
  }, xg.prototype.select = function(t, e) {
    this._innerSelect(this.getData(e), t)
  }, xg.prototype.unselect = function(t, e) {
    var n = this.option.selectedMap;
    if (n) {
      var i = this.option.selectedMode,
        r = this.getData(e);
      if ("series" === i || "all" === n) this.option.selectedMap = {}, this._selectedDataIndicesMap = {};
      else
        for (var o = 0; o < t.length; o++) {
          var a = mg(r, t[o]);
          n[a] = !1, this._selectedDataIndicesMap[a] = -1
        }
    }
  }, xg.prototype.toggleSelect = function(t, e) {
    for (var n = [], i = 0; i < t.length; i++) n[0] = t[i], this.isSelected(t[i], e) ? this.unselect(n, e) : this.select(n, e)
  }, xg.prototype.getSelectedDataIndices = function() {
    if ("all" === this.option.selectedMap) return [].slice.call(this.getData().getIndices());
    for (var t = this._selectedDataIndicesMap, e = F(t), n = [], i = 0; i < e.length; i++) {
      var r = t[e[i]];
      0 <= r && n.push(r)
    }
    return n
  }, xg.prototype.isSelected = function(t, e) {
    var n = this.option.selectedMap;
    return !!n && (e = this.getData(e), "all" === n || n[mg(e, t)]) && !e.getItemModel(t).get(["select", "disabled"])
  }, xg.prototype.isUniversalTransitionEnabled = function() {
    var t;
    return !!this.__universalTransitionEnabled || !!(t = this.option.universalTransition) && (!0 === t || t && t.enabled)
  }, xg.prototype._innerSelect = function(t, e) {
    var n = this.option,
      i = n.selectedMode,
      r = e.length;
    if (i && r)
      if ("series" === i) n.selectedMap = "all";
      else if ("multiple" === i) {
      q(n.selectedMap) || (n.selectedMap = {});
      for (var o = n.selectedMap, a = 0; a < r; a++) {
        var s, l = e[a];
        o[s = mg(t, l)] = !0, this._selectedDataIndicesMap[s] = t.getRawIndex(l)
      }
    } else "single" !== i && !0 !== i || (s = mg(t, i = e[r - 1]), n.selectedMap = ((n = {})[s] = !0, n), this._selectedDataIndicesMap = ((n = {})[s] = t.getRawIndex(i), n))
  }, xg.prototype._initSelectedMapFromData = function(t) {
    var e;
    this.option.selectedMap || (e = [], t.hasItemOption && t.each((function(n) {
      var i = t.getRawDataItem(n);
      i && i.selected && e.push(n)
    })), 0 < e.length && this._innerSelect(t, e))
  }, xg.registerClass = function(t) {
    return Tp.registerClass(t)
  }, xg.protoInitialize = ((gy = xg.prototype).type = "series.__base__", gy.seriesIndex = 0, gy.ignoreStyleOnData = !1, gy.hasSymbolVisual = !1, gy.defaultSymbol = "circle", gy.visualStyleAccessPath = "itemStyle", void(gy.visualDrawType = "fill"));
  var vg, _g = xg;

  function xg() {
    var t = null !== vg && vg.apply(this, arguments) || this;
    return t._selectedDataIndicesMap = {}, t
  }

  function wg(t) {
    var e, n, i = t.name;
    xo(t) || (t.name = (t = (e = (t = t).getRawData()).mapDimensionsAll("seriesName"), n = [], N(t, (function(t) {
      (t = e.getDimensionInfo(t)).displayName && n.push(t.displayName)
    })), n.join(" ") || i))
  }

  function bg(t) {
    return t.model.getRawData().count()
  }

  function Sg(t) {
    return (t = t.model).setData(t.getRawData().cloneShallow()), Mg
  }

  function Mg(t, e) {
    e.outputData && t.end > e.outputData.count() && e.model.getRawData().cloneShallow(e.outputData)
  }

  function Tg(t, e) {
    N(mt(t.CHANGABLE_METHODS, t.DOWNSAMPLE_METHODS), (function(n) {
      t.wrapMethod(n, H(Ig, e))
    }))
  }

  function Ig(t, e) {
    return (t = Cg(t)) && t.setOutputEnd((e || this).count()), e
  }

  function Cg(t) {
    var e, n;
    if (n = (n = (t.ecModel || {}).scheduler) && n.getPipeline(t.uid)) return (n = n.currentTask) && (e = n.agentStubMap) ? e.get(t.uid) : n
  }
  O(_g, sf), O(_g, Kp), No(_g, Tp), Dg.prototype.init = function(t, e) {}, Dg.prototype.render = function(t, e, n, i) {}, Dg.prototype.dispose = function(t, e) {}, Dg.prototype.updateView = function(t, e, n, i) {}, Dg.prototype.updateLayout = function(t, e, n, i) {}, Dg.prototype.updateVisual = function(t, e, n, i) {}, Dg.prototype.toggleBlurSeries = function(t, e, n) {}, Dg.prototype.eachRendered = function(t) {
    var e = this.group;
    e && e.traverse(t)
  };
  var kg = Dg;

  function Dg() {
    this.group = new Rr, this.uid = Cc("viewComponent")
  }

  function Ag() {
    var t = So();
    return function(e) {
      var n = t(e),
        i = (e = e.pipelineContext, !!n.large),
        r = !!n.progressiveRender,
        o = n.large = !(!e || !e.large);
      n = n.progressiveRender = !(!e || !e.progressiveRender);
      return !(i == o && r == n) && "reset"
    }
  }
  Ro(kg), Fo(kg);
  var Lg = So(),
    Pg = Ag(),
    Og = (Rg.prototype.init = function(t, e) {}, Rg.prototype.render = function(t, e, n, i) {}, Rg.prototype.highlight = function(t, e, n, i) {
      (t = t.getData(i && i.dataType)) && Eg(t, i, "emphasis")
    }, Rg.prototype.downplay = function(t, e, n, i) {
      (t = t.getData(i && i.dataType)) && Eg(t, i, "normal")
    }, Rg.prototype.remove = function(t, e) {
      this.group.removeAll()
    }, Rg.prototype.dispose = function(t, e) {}, Rg.prototype.updateView = function(t, e, n, i) {
      this.render(t, e, n, i)
    }, Rg.prototype.updateLayout = function(t, e, n, i) {
      this.render(t, e, n, i)
    }, Rg.prototype.updateVisual = function(t, e, n, i) {
      this.render(t, e, n, i)
    }, Rg.prototype.eachRendered = function(t) {
      $h(this.group, t)
    }, Rg.markUpdateMethod = function(t, e) {
      Lg(t).updateMethod = e
    }, Rg.protoInitialize = void(Rg.prototype.type = "chart"), Rg);

  function Rg() {
    this.group = new Rr, this.uid = Cc("viewChart"), this.renderTask = hf({
      plan: zg,
      reset: Bg
    }), this.renderTask.context = {
      view: this
    }
  }

  function Ng(t, e, n) {
    t && Nl(t) && ("emphasis" === e ? ml : vl)(t, n)
  }

  function Eg(t, e, n) {
    var i, r = bo(t, e),
      o = e && null != e.highlightKey ? (e = e.highlightKey, i = null == (i = Ys[e]) && Xs <= 32 ? Ys[e] = Xs++ : i) : null;
    null != r ? N(po(r), (function(e) {
      Ng(t.getItemGraphicEl(e), n, o)
    })) : t.eachItemGraphicEl((function(t) {
      Ng(t, n, o)
    }))
  }

  function zg(t) {
    return Pg(t.model)
  }

  function Bg(t) {
    var e = t.model,
      n = t.ecModel,
      i = t.api,
      r = t.payload,
      o = e.pipelineContext.progressiveRender,
      a = (t = t.view, r && Lg(r).updateMethod);
    return "render" !== (o = o ? "incrementalPrepareRender" : a && t[a] ? a : "render") && t[o](e, n, i, r), Fg[o]
  }
  Ro(Og), Fo(Og);
  var Fg = {
      incrementalPrepareRender: {
        progress: function(t, e) {
          e.view.incrementalRender(t, e.model, e.ecModel, e.api, e.payload)
        }
      },
      render: {
        forceFirstProgress: !0,
        progress: function(t, e) {
          e.view.render(e.model, e.ecModel, e.api, e.payload)
        }
      }
    },
    Vg = "\0__throttleOriginMethod",
    Hg = "\0__throttleRate",
    Wg = "\0__throttleType";

  function Gg(t, e, n) {
    var i, r, o, a, s, l = 0,
      u = 0,
      h = null;

    function c() {
      u = (new Date).getTime(), h = null, t.apply(o, a || [])
    }

    function p() {
      for (var t = [], p = 0; p < arguments.length; p++) t[p] = arguments[p];
      i = (new Date).getTime(), o = this, a = t;
      var d = s || e,
        f = s || n;
      s = null, r = i - (f ? l : u) - d, clearTimeout(h), f ? h = setTimeout(c, d) : 0 <= r ? c() : h = setTimeout(c, -r), l = i
    }
    return e = e || 0, p.clear = function() {
      h && (clearTimeout(h), h = null)
    }, p.debounceNextCall = function(t) {
      s = t
    }, p
  }

  function Ug(t, e, n, i) {
    var r = t[e];
    if (r) {
      var o = r[Vg] || r,
        a = r[Wg];
      if (r[Hg] !== n || a !== i) {
        if (null == n || !i) return t[e] = o;
        (r = t[e] = Gg(o, n, "debounce" === i))[Vg] = o, r[Wg] = i, r[Hg] = n
      }
    }
  }

  function Xg(t, e) {
    var n = t[e];
    n && n[Vg] && (n.clear && n.clear(), t[e] = n[Vg])
  }
  var Yg = So(),
    qg = {
      itemStyle: Vo(wy, !0),
      lineStyle: Vo(by, !0)
    },
    jg = {
      lineStyle: "stroke",
      itemStyle: "fill"
    };

  function Zg(t, e) {
    return (t = t.visualStyleMapper || qg[e]) || (console.warn("Unknown style type '" + e + "'."), qg.itemStyle)
  }

  function Kg(t, e) {
    return (t = t.visualDrawType || jg[e]) || (console.warn("Unknown style type '" + e + "'."), "fill")
  }
  vc = {
    createOnAllSeries: !0,
    performRawSeries: !0,
    reset: function(t, e) {
      var n = t.getData(),
        i = t.visualStyleAccessPath || "itemStyle",
        r = t.getModel(i),
        o = Zg(t, i)(r),
        a = ((r = r.getShallow("decal")) && (n.setVisual("decal", r), r.dirty = !0), Kg(t, i)),
        s = G(r = o[a]) ? r : null;
      i = "auto" === o.fill || "auto" === o.stroke;
      if (o[a] && !s && !i || (r = t.getColorFromPalette(t.name, null, e.getSeriesCount()), o[a] || (o[a] = r, n.setVisual("colorFromPalette", !0)), o.fill = "auto" === o.fill || G(o.fill) ? r : o.fill, o.stroke = "auto" === o.stroke || G(o.stroke) ? r : o.stroke), n.setVisual("style", o), n.setVisual("drawType", a), !e.isSeriesFiltered(t) && s) return n.setVisual("colorFromPalette", !1), {
        dataEach: function(e, n) {
          var i = t.getDataParams(n),
            r = k({}, o);
          r[a] = s(i), e.setItemVisual(n, "style", r)
        }
      }
    }
  };
  var $g = new Mc,
    Qg = (Wo = {
      createOnAllSeries: !0,
      performRawSeries: !0,
      reset: function(t, e) {
        var n, i, r;
        if (!t.ignoreStyleOnData && !e.isSeriesFiltered(t)) return e = t.getData(), n = t.visualStyleAccessPath || "itemStyle", i = Zg(t, n), r = e.getVisual("drawType"), {
          dataEach: e.hasItemOption ? function(t, e) {
            var o = t.getRawDataItem(e);
            o && o[n] && ($g.option = o[n], o = i($g), k(t.ensureUniqueItemVisual(e, "style"), o), $g.option.decal && (t.setItemVisual(e, "decal", $g.option.decal), $g.option.decal.dirty = !0), r in o) && t.setItemVisual(e, "colorFromPalette", !1)
          } : null
        }
      }
    }, wc = {
      performRawSeries: !0,
      overallReset: function(t) {
        var e = yt();
        t.eachSeries((function(t) {
          var n, i = t.getColorBy();
          t.isColorBySeries() || (i = t.type + "-" + i, (n = e.get(i)) || e.set(i, n = {}), Yg(t).scope = n)
        })), t.eachSeries((function(e) {
          var n, i, r, o, a, s;
          e.isColorBySeries() || t.isSeriesFiltered(e) || (n = e.getRawData(), i = {}, r = e.getData(), o = Yg(e).scope, a = e.visualStyleAccessPath || "itemStyle", s = Kg(e, a), r.each((function(t) {
            var e = r.getRawIndex(t);
            i[e] = t
          })), n.each((function(t) {
            var a, l = i[t];
            r.getItemVisual(l, "colorFromPalette") && (l = r.ensureUniqueItemVisual(l, "style"), t = n.getName(t) || t + "", a = n.count(), l[s] = e.getColorFromPalette(t, o, a))
          })))
        }))
      }
    }, Math.PI);
  ty.prototype.restoreData = function(t, e) {
    t.restoreData(e), this._stageTaskMap.each((function(t) {
      (t = t.overallTask) && t.dirty()
    }))
  }, ty.prototype.getPerformArgs = function(t, e) {
    var n, i;
    if (t.__pipeline) return i = (n = this._pipelineMap.get(t.__pipeline.id)).context, {
      step: e = !e && n.progressiveEnabled && (!i || i.progressiveRender) && t.__idxInPipeline > n.blockIndex ? n.step : null,
      modBy: null != (t = i && i.modDataCount) ? Math.ceil(t / e) : null,
      modDataCount: t
    }
  }, ty.prototype.getPipeline = function(t) {
    return this._pipelineMap.get(t)
  }, ty.prototype.updateStreamModes = function(t, e) {
    var n = this._pipelineMap.get(t.uid),
      i = t.getData().count(),
      r = (e = n.progressiveEnabled && e.incrementalPrepareRender && i >= n.threshold, t.get("large") && i >= t.get("largeThreshold"));
    i = "mod" === t.get("progressiveChunkMode") ? i : null;
    t.pipelineContext = n.context = {
      progressiveRender: e,
      modDataCount: i,
      large: r
    }
  }, ty.prototype.restorePipelines = function(t) {
    var e = this,
      n = e._pipelineMap = yt();
    t.eachSeries((function(t) {
      var i = t.getProgressive(),
        r = t.uid;
      n.set(r, {
        id: r,
        head: null,
        tail: null,
        threshold: t.getProgressiveThreshold(),
        progressiveEnabled: i && !(t.preventIncremental && t.preventIncremental()),
        blockIndex: -1,
        step: Math.round(i || 700),
        count: 0
      }), e._pipe(t, t.dataTask)
    }))
  }, ty.prototype.prepareStageTasks = function() {
    var t = this._stageTaskMap,
      e = this.api.getModel(),
      n = this.api;
    N(this._allHandlers, (function(i) {
      var r = t.get(i.uid) || t.set(i.uid, {});
      at(!(i.reset && i.overallReset), ""), i.reset && this._createSeriesStageTask(i, r, e, n), i.overallReset && this._createOverallStageTask(i, r, e, n)
    }), this)
  }, ty.prototype.prepareView = function(t, e, n, i) {
    var r = t.renderTask,
      o = r.context;
    o.model = e, o.ecModel = n, o.api = i, r.__block = !t.incrementalPrepareRender, this._pipe(e, r)
  }, ty.prototype.performDataProcessorTasks = function(t, e) {
    this._performStageTasks(this._dataProcessorHandlers, t, e, {
      block: !0
    })
  }, ty.prototype.performVisualTasks = function(t, e, n) {
    this._performStageTasks(this._visualHandlers, t, e, n)
  }, ty.prototype._performStageTasks = function(t, e, n, i) {
    i = i || {};
    var r = !1,
      o = this;

    function a(t, e) {
      return t.setDirty && (!t.dirtyMap || t.dirtyMap.get(e.__pipeline.id))
    }
    N(t, (function(t, s) {
      var l, u, h, c, p;
      i.visualType && i.visualType !== t.visualType || (l = (u = o._stageTaskMap.get(t.uid)).seriesTaskMap, (u = u.overallTask) ? ((c = u.agentStubMap).each((function(t) {
        a(i, t) && (t.dirty(), h = !0)
      })), h && u.dirty(), o.updatePayload(u, n), p = o.getPerformArgs(u, i.block), c.each((function(t) {
        t.perform(p)
      })), u.perform(p) && (r = !0)) : l && l.each((function(s, l) {
        a(i, s) && s.dirty();
        var u = o.getPerformArgs(s, i.block);
        u.skip = !t.performRawSeries && e.isSeriesFiltered(s.context.model), o.updatePayload(s, n), s.perform(u) && (r = !0)
      })))
    })), this.unfinished = r || this.unfinished
  }, ty.prototype.performSeriesTasks = function(t) {
    var e;
    t.eachSeries((function(t) {
      e = t.dataTask.perform() || e
    })), this.unfinished = e || this.unfinished
  }, ty.prototype.plan = function() {
    this._pipelineMap.each((function(t) {
      var e = t.tail;
      do {
        if (e.__block) {
          t.blockIndex = e.__idxInPipeline;
          break
        }
      } while (e = e.getUpstream())
    }))
  }, ty.prototype.updatePayload = function(t, e) {
    "remain" !== e && (t.context.payload = e)
  }, ty.prototype._createSeriesStageTask = function(t, e, n, i) {
    var r = this,
      o = e.seriesTaskMap,
      a = e.seriesTaskMap = yt(),
      s = (e = t.seriesType, t.getTargetSeries);

    function l(e) {
      var s = e.uid;
      (s = a.set(s, o && o.get(s) || hf({
        plan: oy,
        reset: ay,
        count: uy
      }))).context = {
        model: e,
        ecModel: n,
        api: i,
        useClearVisual: t.isVisual && !t.isLayout,
        plan: t.plan,
        reset: t.reset,
        scheduler: r
      }, r._pipe(e, s)
    }
    t.createOnAllSeries ? n.eachRawSeries(l) : e ? n.eachRawSeriesByType(e, l) : s && s(n, i).each(l)
  }, ty.prototype._createOverallStageTask = function(t, e, n, i) {
    var r = this,
      o = e.overallTask = e.overallTask || hf({
        reset: ey
      }),
      a = (o.context = {
        ecModel: n,
        api: i,
        overallReset: t.overallReset,
        scheduler: r
      }, o.agentStubMap),
      s = o.agentStubMap = yt(),
      l = (e = t.seriesType, t.getTargetSeries),
      u = !0,
      h = !1;

    function c(t) {
      var e = t.uid;
      (e = s.set(e, a && a.get(e) || (h = !0, hf({
        reset: ny,
        onDirty: ry
      })))).context = {
        model: t,
        overallProgress: u
      }, e.agent = o, e.__block = u, r._pipe(t, e)
    }
    at(!t.createOnAllSeries, ""), e ? n.eachRawSeriesByType(e, c) : l ? l(n, i).each(c) : (u = !1, N(n.getSeries(), c)), h && o.dirty()
  }, ty.prototype._pipe = function(t, e) {
    t = t.uid, (t = this._pipelineMap.get(t)).head || (t.head = e), t.tail && t.tail.pipe(e), (t.tail = e).__idxInPipeline = t.count++, e.__pipeline = t
  }, ty.wrapStageHandler = function(t, e) {
    return (t = G(t) ? {
      overallReset: t,
      seriesType: function(t) {
        hy = null;
        try {
          t(cy, py)
        } catch (t) {}
        return hy
      }(t)
    } : t).uid = Cc("stageHandler"), e && (t.visualType = e), t
  };
  var Jg = ty;

  function ty(t, e, n, i) {
    this._stageTaskMap = yt(), this.ecInstance = t, this.api = e, n = this._dataProcessorHandlers = n.slice(), i = this._visualHandlers = i.slice(), this._allHandlers = n.concat(i)
  }

  function ey(t) {
    t.overallReset(t.ecModel, t.api, t.payload)
  }

  function ny(t) {
    return t.overallProgress && iy
  }

  function iy() {
    this.agent.dirty(), this.getDownstream().dirty()
  }

  function ry() {
    this.agent && this.agent.dirty()
  }

  function oy(t) {
    return t.plan ? t.plan(t.model, t.ecModel, t.api, t.payload) : null
  }

  function ay(t) {
    return t.useClearVisual && t.data.clearAllVisual(), 1 < (t = t.resetDefines = po(t.reset(t.model, t.ecModel, t.api, t.payload))).length ? E(t, (function(t, e) {
      return ly(e)
    })) : sy
  }
  var sy = ly(0);

  function ly(t) {
    return function(e, n) {
      var i = n.data,
        r = n.resetDefines[t];
      if (r && r.dataEach)
        for (var o = e.start; o < e.end; o++) r.dataEach(i, o);
      else r && r.progress && r.progress(e, i)
    }
  }

  function uy(t) {
    return t.data.count()
  }
  var hy, cy = {},
    py = {};

  function dy(t, e) {
    for (var n in e.prototype) t[n] = wt
  }

  function fy() {
    return {
      axisLine: {
        lineStyle: {
          color: yy
        }
      },
      splitLine: {
        lineStyle: {
          color: "#484753"
        }
      },
      splitArea: {
        areaStyle: {
          color: ["rgba(255,255,255,0.02)", "rgba(255,255,255,0.05)"]
        }
      },
      minorSplitLine: {
        lineStyle: {
          color: "#20203B"
        }
      }
    }
  }
  dy(cy, td), dy(py, od), cy.eachSeriesByType = cy.eachRawSeriesByType = function(t) {
    hy = t
  }, cy.eachComponent = function(t) {
    "series" === t.mainType && t.subType && (hy = t.subType)
  };
  var gy = {
      color: Vh = ["#37A2DA", "#32C5E9", "#67E0E3", "#9FE6B8", "#FFDB5C", "#ff9f7f", "#fb7293", "#E062AE", "#E690D1", "#e7bcf3", "#9d96f5", "#8378EA", "#96BFFF"],
      colorLayer: [
        ["#37A2DA", "#ffd85c", "#fd7b5f"],
        ["#37A2DA", "#67E0E3", "#FFDB5C", "#ff9f7f", "#E062AE", "#9d96f5"],
        ["#37A2DA", "#32C5E9", "#9FE6B8", "#FFDB5C", "#ff9f7f", "#fb7293", "#e7bcf3", "#8378EA", "#96BFFF"], Vh
      ]
    },
    yy = "#B9B8CE",
    my = ((Vh = {
      darkMode: !0,
      color: by = ["#4992ff", "#7cffb2", "#fddd60", "#ff6e76", "#58d9f9", "#05c091", "#ff8a45", "#8d48e3", "#dd79ff"],
      backgroundColor: wy = "#100C2A",
      axisPointer: {
        lineStyle: {
          color: "#817f91"
        },
        crossStyle: {
          color: "#817f91"
        },
        label: {
          color: "#fff"
        }
      },
      legend: {
        textStyle: {
          color: yy
        }
      },
      textStyle: {
        color: yy
      },
      title: {
        textStyle: {
          color: "#EEF1FA"
        },
        subtextStyle: {
          color: "#B9B8CE"
        }
      },
      toolbox: {
        iconStyle: {
          borderColor: yy
        }
      },
      dataZoom: {
        borderColor: "#71708A",
        textStyle: {
          color: yy
        },
        brushStyle: {
          color: "rgba(135,163,206,0.3)"
        },
        handleStyle: {
          color: "#353450",
          borderColor: "#C5CBE3"
        },
        moveHandleStyle: {
          color: "#B0B6C3",
          opacity: .3
        },
        fillerColor: "rgba(135,163,206,0.2)",
        emphasis: {
          handleStyle: {
            borderColor: "#91B7F2",
            color: "#4D587D"
          },
          moveHandleStyle: {
            color: "#636D9A",
            opacity: .7
          }
        },
        dataBackground: {
          lineStyle: {
            color: "#71708A",
            width: 1
          },
          areaStyle: {
            color: "#71708A"
          }
        },
        selectedDataBackground: {
          lineStyle: {
            color: "#87A3CE"
          },
          areaStyle: {
            color: "#87A3CE"
          }
        }
      },
      visualMap: {
        textStyle: {
          color: yy
        }
      },
      timeline: {
        lineStyle: {
          color: yy
        },
        label: {
          color: yy
        },
        controlStyle: {
          color: yy,
          borderColor: yy
        }
      },
      calendar: {
        itemStyle: {
          color: wy
        },
        dayLabel: {
          color: yy
        },
        monthLabel: {
          color: yy
        },
        yearLabel: {
          color: yy
        }
      },
      timeAxis: fy(),
      logAxis: fy(),
      valueAxis: fy(),
      categoryAxis: fy(),
      line: {
        symbol: "circle"
      },
      graph: {
        color: by
      },
      gauge: {
        title: {
          color: yy
        },
        axisLine: {
          lineStyle: {
            color: [
              [1, "rgba(207,212,219,0.2)"]
            ]
          }
        },
        axisLabel: {
          color: yy
        },
        detail: {
          color: "#EEF1FA"
        }
      },
      candlestick: {
        itemStyle: {
          color: "#f64e56",
          color0: "#54ea92",
          borderColor: "#f64e56",
          borderColor0: "#54ea92"
        }
      }
    }).categoryAxis.splitLine.show = !1, vy.prototype.normalizeQuery = function(t) {
      var e, n, i, r = {},
        o = {},
        a = {};
      return U(t) ? (e = Oo(t), r.mainType = e.main || null, r.subType = e.sub || null) : (n = ["Index", "Name", "Id"], i = {
        name: 1,
        dataIndex: 1,
        dataType: 1
      }, N(t, (function(t, e) {
        for (var s = !1, l = 0; l < n.length; l++) {
          var u = n[l],
            h = e.lastIndexOf(u);
          0 < h && h === e.length - u.length && "data" !== (h = e.slice(0, h)) && (r.mainType = h, r[u.toLowerCase()] = t, s = !0)
        }
        i.hasOwnProperty(e) && (o[e] = t, s = !0), s || (a[e] = t)
      }))), {
        cptQuery: r,
        dataQuery: o,
        otherQuery: a
      }
    }, vy.prototype.filter = function(t, e) {
      var n, i, r, o, a, s = this.eventInfo;
      return !s || (n = s.targetEl, i = s.packedEvent, r = s.model, s = s.view, !r) || !s || (o = e.cptQuery, a = e.dataQuery, l(o, r, "mainType") && l(o, r, "subType") && l(o, r, "index", "componentIndex") && l(o, r, "name") && l(o, r, "id") && l(a, i, "name") && l(a, i, "dataIndex") && l(a, i, "dataType") && (!s.filterForExposedEvent || s.filterForExposedEvent(t, e.otherQuery, n, i)));

      function l(t, e, n, i) {
        return null == t[n] || e[i || n] === t[n]
      }
    }, vy.prototype.afterTrigger = function() {
      this.eventInfo = null
    }, vy);

  function vy() {}
  var _y = ["symbol", "symbolSize", "symbolRotate", "symbolOffset"],
    xy = _y.concat(["symbolKeepAspect"]),
    wy = {
      createOnAllSeries: !0,
      performRawSeries: !0,
      reset: function(t, e) {
        var n = t.getData();
        if (t.legendIcon && n.setVisual("legendIcon", t.legendIcon), t.hasSymbolVisual) {
          for (var i, r = {}, o = {}, a = !1, s = 0; s < _y.length; s++) {
            var l = _y[s],
              u = t.get(l);
            G(u) ? (a = !0, o[l] = u) : r[l] = u
          }
          if (r.symbol = r.symbol || t.defaultSymbol, n.setVisual(k({
              legendIcon: t.legendIcon || r.symbol,
              symbolKeepAspect: t.get("symbolKeepAspect")
            }, r)), !e.isSeriesFiltered(t)) return i = F(o), {
            dataEach: a ? function(e, n) {
              for (var r = t.getRawValue(n), a = t.getDataParams(n), s = 0; s < i.length; s++) {
                var l = i[s];
                e.setItemVisual(n, l, o[l](r, a))
              }
            } : null
          }
        }
      }
    },
    by = {
      createOnAllSeries: !0,
      performRawSeries: !0,
      reset: function(t, e) {
        if (t.hasSymbolVisual && !e.isSeriesFiltered(t)) return {
          dataEach: t.getData().hasItemOption ? function(t, e) {
            for (var n = t.getItemModel(e), i = 0; i < xy.length; i++) {
              var r = xy[i],
                o = n.getShallow(r, !0);
              null != o && t.setItemVisual(e, r, o)
            }
          } : null
        }
      }
    };

  function Sy(t, e) {
    switch (e) {
      case "color":
        return t.getVisual("style")[t.getVisual("drawType")];
      case "opacity":
        return t.getVisual("style").opacity;
      case "symbol":
      case "symbolSize":
      case "liftZ":
        return t.getVisual(e)
    }
  }

  function My(t, e, n, i, r) {
    var o = t + e;
    n.isSilent(o) || i.eachComponent({
      mainType: "series",
      subType: "pie"
    }, (function(t) {
      for (var e, i, a = t.seriesIndex, s = t.option.selectedMap, l = r.selected, u = 0; u < l.length; u++) l[u].seriesIndex === a && (i = bo(e = t.getData(), r.fromActionPayload), n.trigger(o, {
        type: o,
        seriesId: t.id,
        name: W(i) ? e.getName(i[0]) : e.getName(i),
        selected: U(s) ? s : k({}, s)
      }))
    }))
  }

  function Ty(t, e, n) {
    for (var i; t && (!e(t) || (i = t, !n));) t = t.__hostTarget || t.parent;
    return i
  }
  var Iy = Math.round(9 * Math.random()),
    Cy = "function" == typeof Object.defineProperty,
    ky = (Dy.prototype.get = function(t) {
      return this._guard(t)[this._id]
    }, Dy.prototype.set = function(t, e) {
      return t = this._guard(t), Cy ? Object.defineProperty(t, this._id, {
        value: e,
        enumerable: !1,
        configurable: !0
      }) : t[this._id] = e, this
    }, Dy.prototype.delete = function(t) {
      return !!this.has(t) && (delete this._guard(t)[this._id], !0)
    }, Dy.prototype.has = function(t) {
      return !!this._guard(t)[this._id]
    }, Dy.prototype._guard = function(t) {
      if (t !== Object(t)) throw TypeError("Value of WeakMap is not a non-null object.");
      return t
    }, Dy);

  function Dy() {
    this._id = "__ec_inner_" + Iy++
  }
  var Ay = as.extend({
      type: "triangle",
      shape: {
        cx: 0,
        cy: 0,
        width: 0,
        height: 0
      },
      buildPath: function(t, e) {
        var n = e.cx,
          i = e.cy,
          r = e.width / 2;
        e = e.height / 2;
        t.moveTo(n, i - e), t.lineTo(n + r, i + e), t.lineTo(n - r, i + e), t.closePath()
      }
    }),
    Ly = as.extend({
      type: "diamond",
      shape: {
        cx: 0,
        cy: 0,
        width: 0,
        height: 0
      },
      buildPath: function(t, e) {
        var n = e.cx,
          i = e.cy,
          r = e.width / 2;
        e = e.height / 2;
        t.moveTo(n, i - e), t.lineTo(n + r, i), t.lineTo(n, i + e), t.lineTo(n - r, i), t.closePath()
      }
    }),
    Py = as.extend({
      type: "pin",
      shape: {
        x: 0,
        y: 0,
        width: 0,
        height: 0
      },
      buildPath: function(t, e) {
        var n = e.x,
          i = e.y,
          r = e.width / 5 * 3,
          o = (e = Math.max(r, e.height), (r = r / 2) * r / (e - r)),
          a = (e = i - e + r + o, Math.asin(o / r)),
          s = Math.cos(a) * r,
          l = Math.sin(a),
          u = Math.cos(a),
          h = .6 * r,
          c = .7 * r;
        t.moveTo(n - s, e + o), t.arc(n, e, r, Math.PI - a, 2 * Math.PI + a), t.bezierCurveTo(n + s - l * h, e + o + u * h, n, i - c, n, i), t.bezierCurveTo(n, i - c, n - s + l * h, e + o + u * h, n - s, e + o), t.closePath()
      }
    }),
    Oy = as.extend({
      type: "arrow",
      shape: {
        x: 0,
        y: 0,
        width: 0,
        height: 0
      },
      buildPath: function(t, e) {
        var n = e.height,
          i = e.width,
          r = e.x;
        e = e.y, i = i / 3 * 2;
        t.moveTo(r, e), t.lineTo(r + i, e + n), t.lineTo(r, e + n / 4 * 3), t.lineTo(r - i, e + n), t.lineTo(r, e), t.closePath()
      }
    }),
    Ry = {
      line: function(t, e, n, i, r) {
        r.x1 = t, r.y1 = e + i / 2, r.x2 = t + n, r.y2 = e + i / 2
      },
      rect: function(t, e, n, i, r) {
        r.x = t, r.y = e, r.width = n, r.height = i
      },
      roundRect: function(t, e, n, i, r) {
        r.x = t, r.y = e, r.width = n, r.height = i, r.r = Math.min(n, i) / 4
      },
      square: function(t, e, n, i, r) {
        n = Math.min(n, i), r.x = t, r.y = e, r.width = n, r.height = n
      },
      circle: function(t, e, n, i, r) {
        r.cx = t + n / 2, r.cy = e + i / 2, r.r = Math.min(n, i) / 2
      },
      diamond: function(t, e, n, i, r) {
        r.cx = t + n / 2, r.cy = e + i / 2, r.width = n, r.height = i
      },
      pin: function(t, e, n, i, r) {
        r.x = t + n / 2, r.y = e + i / 2, r.width = n, r.height = i
      },
      arrow: function(t, e, n, i, r) {
        r.x = t + n / 2, r.y = e + i / 2, r.width = n, r.height = i
      },
      triangle: function(t, e, n, i, r) {
        r.cx = t + n / 2, r.cy = e + i / 2, r.width = n, r.height = i
      }
    },
    Ny = {},
    Ey = (N({
      line: Hu,
      rect: Ms,
      roundRect: Ms,
      square: Ms,
      circle: kS,
      diamond: Ly,
      pin: Py,
      arrow: Oy,
      triangle: Ay
    }, (function(t, e) {
      Ny[e] = new t
    })), as.extend({
      type: "symbol",
      shape: {
        symbolType: "",
        x: 0,
        y: 0,
        width: 0,
        height: 0
      },
      calculateTextPosition: function(t, e, n) {
        t = wr(t, e, n);
        var i = this.shape;
        return i && "pin" === i.symbolType && "inside" === e.position && (t.y = n.y + .4 * n.height), t
      },
      buildPath: function(t, e, n) {
        var i, r = e.symbolType;
        "none" !== r && (i = (i = Ny[r]) || Ny[r = "rect"], Ry[r](e.x, e.y, e.width, e.height, i.shape), i.buildPath(t, i.shape, n))
      }
    }));

  function zy(t, e) {
    var n;
    "image" !== this.type && (n = this.style, this.__isEmptyBrush ? (n.stroke = t, n.fill = e || "#fff", n.lineWidth = 2) : "line" === this.shape.symbolType ? n.stroke = t : n.fill = t, this.markRedraw())
  }

  function By(t, e, n, i, r, o, a) {
    var s = 0 === t.indexOf("empty");
    return (a = 0 === (t = s ? t.substr(5, 1).toLowerCase() + t.substr(6) : t).indexOf("image://") ? Nh(t.slice(8), new Oe(e, n, i, r), a ? "center" : "cover") : 0 === t.indexOf("path://") ? Rh(t.slice(7), {}, new Oe(e, n, i, r), a ? "center" : "cover") : new Ey({
      shape: {
        symbolType: t,
        x: e,
        y: n,
        width: i,
        height: r
      }
    })).__isEmptyBrush = s, a.setColor = zy, o && a.setColor(o), a
  }

  function Fy(t) {
    return [(t = W(t) ? t : [+t, +t])[0] || 0, t[1] || 0]
  }

  function Vy(t, e) {
    if (null != t) return [qr((t = W(t) ? t : [t, t])[0], e[0]) || 0, qr(nt(t[1], t[0]), e[1]) || 0]
  }

  function Hy(t) {
    return isFinite(t)
  }

  function Wy(t, e, n) {
    for (var i, r, o, a, s, l, u, h, c, p = "radial" === e.type ? (i = t, r = e, a = (o = n).width, s = o.height, l = Math.min(a, s), u = null == r.x ? .5 : r.x, h = null == r.y ? .5 : r.y, c = null == r.r ? .5 : r.r, r.global || (u = u * a + o.x, h = h * s + o.y, c *= l), u = Hy(u) ? u : .5, h = Hy(h) ? h : .5, c = 0 <= c && Hy(c) ? c : .5, i.createRadialGradient(u, h, 0, u, h, c)) : (r = t, a = n, o = null == (s = e).x ? 0 : s.x, l = null == s.x2 ? 1 : s.x2, i = null == s.y ? 0 : s.y, u = null == s.y2 ? 0 : s.y2, s.global || (o = o * a.width + a.x, l = l * a.width + a.x, i = i * a.height + a.y, u = u * a.height + a.y), o = Hy(o) ? o : 0, l = Hy(l) ? l : 1, i = Hy(i) ? i : 0, u = Hy(u) ? u : 0, r.createLinearGradient(o, i, l, u)), d = e.colorStops, f = 0; f < d.length; f++) p.addColorStop(d[f].offset, d[f].color);
    return p
  }

  function Gy(t) {
    return parseInt(t, 10)
  }

  function Uy(t, e, n) {
    var i = ["width", "height"][e],
      r = ["clientWidth", "clientHeight"][e],
      o = ["paddingLeft", "paddingTop"][e];
    e = ["paddingRight", "paddingBottom"][e];
    return null != n[i] && "auto" !== n[i] ? parseFloat(n[i]) : (n = document.defaultView.getComputedStyle(t), (t[r] || Gy(n[i]) || Gy(t.style[i])) - (Gy(n[o]) || 0) - (Gy(n[e]) || 0) | 0)
  }

  function Xy(t) {
    var e, n = t.style,
      i = n.lineDash && 0 < n.lineWidth && (r = n.lineDash, i = n.lineWidth, r && "solid" !== r && 0 < i ? "dashed" === r ? [4 * i, 2 * i] : "dotted" === r ? [i] : Y(r) ? [r] : W(r) ? r : null : null),
      r = n.lineDashOffset;
    return i && (e = n.strokeNoScale && t.getLineScale ? t.getLineScale() : 1) && 1 !== e && (i = E(i, (function(t) {
      return t / e
    })), r /= e), [i, r]
  }
  var Yy = new Wa(!0);

  function qy(t) {
    var e = t.stroke;
    return !(null == e || "none" === e || !(0 < t.lineWidth))
  }

  function jy(t) {
    return "string" == typeof t && "none" !== t
  }

  function Zy(t) {
    return null != (t = t.fill) && "none" !== t
  }

  function Ky(t, e) {
    var n;
    null != e.fillOpacity && 1 !== e.fillOpacity ? (n = t.globalAlpha, t.globalAlpha = e.fillOpacity * e.opacity, t.fill(), t.globalAlpha = n) : t.fill()
  }

  function $y(t, e) {
    var n;
    null != e.strokeOpacity && 1 !== e.strokeOpacity ? (n = t.globalAlpha, t.globalAlpha = e.strokeOpacity * e.opacity, t.stroke(), t.globalAlpha = n) : t.stroke()
  }

  function Qy(t, e, n) {
    if (qo(n = Xo(e.image, e.__image, n))) return t = t.createPattern(n, e.repeat || "repeat"), "function" == typeof DOMMatrix && t && t.setTransform && ((n = new DOMMatrix).translateSelf(e.x || 0, e.y || 0), n.rotateSelf(0, 0, (e.rotation || 0) * bt), n.scaleSelf(e.scaleX || 1, e.scaleY || 1), t.setTransform(n)), t
  }
  var Jy = ["shadowBlur", "shadowOffsetX", "shadowOffsetY"],
    tm = [
      ["lineCap", "butt"],
      ["lineJoin", "miter"],
      ["miterLimit", 10]
    ];

  function em(t, e, n, i, r) {
    var o, a = !1;
    if (!i && e === (n = n || {})) return !1;
    !i && e.opacity === n.opacity || (rm(t, r), a = !0, o = Math.max(Math.min(e.opacity, 1), 0), t.globalAlpha = isNaN(o) ? aa.opacity : o), !i && e.blend === n.blend || (a || (rm(t, r), a = !0), t.globalCompositeOperation = e.blend || aa.blend);
    for (var s = 0; s < Jy.length; s++) {
      var l = Jy[s];
      !i && e[l] === n[l] || (a || (rm(t, r), a = !0), t[l] = t.dpr * (e[l] || 0))
    }
    return !i && e.shadowColor === n.shadowColor || (a || (rm(t, r), a = !0), t.shadowColor = e.shadowColor || aa.shadowColor), a
  }

  function nm(t, e, n, i, r) {
    var o = om(e, r.inHover),
      a = i ? null : n && om(n, r.inHover) || {};
    if (o !== a) {
      var s = em(t, o, a, i, r);
      (i || o.fill !== a.fill) && (s || (rm(t, r), s = !0), jy(o.fill)) && (t.fillStyle = o.fill), (i || o.stroke !== a.stroke) && (s || (rm(t, r), s = !0), jy(o.stroke)) && (t.strokeStyle = o.stroke), !i && o.opacity === a.opacity || (s || (rm(t, r), s = !0), t.globalAlpha = null == o.opacity ? 1 : o.opacity), e.hasStroke() && (n = o.lineWidth / (o.strokeNoScale && e.getLineScale ? e.getLineScale() : 1), t.lineWidth !== n) && (s || (rm(t, r), s = !0), t.lineWidth = n);
      for (var l = 0; l < tm.length; l++) {
        var u = tm[l],
          h = u[0];
        !i && o[h] === a[h] || (s || (rm(t, r), s = !0), t[h] = o[h] || u[1])
      }
    }
  }

  function im(t, e) {
    e = e.transform;
    var n = t.dpr || 1;
    e ? t.setTransform(n * e[0], n * e[1], n * e[2], n * e[3], n * e[4], n * e[5]) : t.setTransform(n, 0, 0, n, 0, 0)
  }

  function rm(t, e) {
    e.batchFill && t.fill(), e.batchStroke && t.stroke(), e.batchFill = "", e.batchStroke = ""
  }

  function om(t, e) {
    return e && t.__hoverStyle || t.style
  }

  function am(t, e) {
    sm(t, e, {
      inHover: !1,
      viewWidth: 0,
      viewHeight: 0
    }, !0)
  }

  function sm(t, e, n, i) {
    var r = e.transform;
    if (e.shouldBePainted(n.viewWidth, n.viewHeight, !1, !1)) {
      var o = e.__clipPaths,
        a = !1,
        s = !1;
      if (!(c = n.prevElClipPaths) || function(t, e) {
          if (t !== e && (t || e)) {
            if (!t || !e || t.length !== e.length) return 1;
            for (var n = 0; n < t.length; n++)
              if (t[n] !== e[n]) return 1
          }
        }(o, c)) {
        if (c && c.length && (rm(t, n), t.restore(), s = a = !0, n.prevElClipPaths = null, n.allClipped = !1, n.prevEl = null), o && o.length) {
          rm(t, n), t.save();
          for (var l = o, h = t, c = n, p = !1, d = 0; d < l.length; d++) {
            var f = l[d];
            p = p || f.isZeroArea();
            im(h, f), h.beginPath(), f.buildPath(h, f.shape), h.clip()
          }
          c.allClipped = p, a = !0
        }
        n.prevElClipPaths = o
      }
      if (n.allClipped) e.__isRendered = !1;
      else {
        e.beforeBrush && e.beforeBrush(), e.innerBeforeBrush();
        var g, y, m, v, _, x, w, b, S, M, T, I, C, k, D, A, L, P, O, R, N, E, z, B = ((c = n.prevEl) || (s = a = !0), e instanceof as && e.autoBatch && (B = Zy(o = e.style), g = qy(o), !(o.lineDash || !(+B ^ +g) || B && "string" != typeof o.fill || g && "string" != typeof o.stroke || o.strokePercent < 1 || o.strokeOpacity < 1 || o.fillOpacity < 1)));
        a = (a || (g = r, o = c.transform, g && o ? g[0] !== o[0] || g[1] !== o[1] || g[2] !== o[2] || g[3] !== o[3] || g[4] !== o[4] || g[5] !== o[5] : g || o) ? (rm(t, n), im(t, e)) : B || rm(t, n), om(e, n.inHover));
        if (e instanceof as) 1 !== n.lastDrawType && (s = !0, n.lastDrawType = 1), nm(t, e, c, s, n), B && (n.batchFill || n.batchStroke) || t.beginPath(), r = t, o = e, G = B, D = qy(v = a), A = Zy(v), P = (L = v.strokePercent) < 1, O = !o.path, o.silent && !P || !O || o.createPathProxy(), R = o.path || Yy, N = o.__dirty, G || (_ = v.fill, z = v.stroke, x = A && !!_.colorStops, w = D && !!z.colorStops, b = A && !!_.image, S = D && !!z.image, E = C = I = T = M = void 0, (x || w) && (E = o.getBoundingRect()), x && (M = N ? Wy(r, _, E) : o.__canvasFillGradient, o.__canvasFillGradient = M), w && (T = N ? Wy(r, z, E) : o.__canvasStrokeGradient, o.__canvasStrokeGradient = T), b && (I = N || !o.__canvasFillPattern ? Qy(r, _, o) : o.__canvasFillPattern, o.__canvasFillPattern = I), S && (C = N || !o.__canvasStrokePattern ? Qy(r, z, o) : o.__canvasStrokePattern, o.__canvasStrokePattern = I), x ? r.fillStyle = M : b && (I ? r.fillStyle = I : A = !1), w ? r.strokeStyle = T : S && (C ? r.strokeStyle = C : D = !1)), E = o.getGlobalScale(), R.setScale(E[0], E[1], o.segmentIgnoreThreshold), r.setLineDash && v.lineDash && (k = (_ = Xy(o))[0], W = _[1]), z = !0, (O || 4 & N) && (R.setDPR(r.dpr), P ? R.setContext(null) : (R.setContext(r), z = !1), R.reset(), o.buildPath(R, o.shape, G), R.toStatic(), o.pathUpdated()), z && R.rebuildPath(r, P ? L : 1), k && (r.setLineDash(k), r.lineDashOffset = W), G || (v.strokeFirst ? (D && $y(r, v), A && Ky(r, v)) : (A && Ky(r, v), D && $y(r, v))), k && r.setLineDash([]), B && (n.batchFill = a.fill || "", n.batchStroke = a.stroke || "");
        else if (e instanceof hs) 3 !== n.lastDrawType && (s = !0, n.lastDrawType = 3), nm(t, e, c, s, n), x = t, M = e, null != (I = (b = a).text) && (I += ""), I && (x.font = b.font || u, x.textAlign = b.textAlign, x.textBaseline = b.textBaseline, T = w = void 0, x.setLineDash && b.lineDash && (w = (M = Xy(M))[0], T = M[1]), w && (x.setLineDash(w), x.lineDashOffset = T), b.strokeFirst ? (qy(b) && x.strokeText(I, b.x, b.y), Zy(b) && x.fillText(I, b.x, b.y)) : (Zy(b) && x.fillText(I, b.x, b.y), qy(b) && x.strokeText(I, b.x, b.y)), w) && x.setLineDash([]);
        else if (e instanceof gs) 2 !== n.lastDrawType && (s = !0, n.lastDrawType = 2), S = c, C = s, em(t, om(e, (E = n).inHover), S && om(S, E.inHover), C, E), _ = t, O = a, (o = (N = e).__image = Xo(O.image, N.__image, N, N.onload)) && qo(o) && (z = O.x || 0, R = O.y || 0, P = N.getWidth(), N = N.getHeight(), L = o.width / o.height, null == P && null != N ? P = N * L : null == N && null != P ? N = P / L : null == P && null == N && (P = o.width, N = o.height), O.sWidth && O.sHeight ? (y = O.sx || 0, m = O.sy || 0, _.drawImage(o, y, m, O.sWidth, O.sHeight, z, R, P, N)) : O.sx && O.sy ? (y = O.sx, m = O.sy, _.drawImage(o, y, m, P - y, N - m, z, R, P, N)) : _.drawImage(o, z, R, P, N));
        else if (e.getTemporalDisplayables) {
          4 !== n.lastDrawType && (s = !0, n.lastDrawType = 4);
          var F, V, H = t,
            W = e,
            G = n,
            U = W.getDisplayables(),
            X = W.getTemporalDisplayables(),
            Y = (H.save(), {
              prevElClipPaths: null,
              prevEl: null,
              allClipped: !1,
              viewWidth: G.viewWidth,
              viewHeight: G.viewHeight,
              inHover: G.inHover
            });
          for (F = W.getCursor(), V = U.length; F < V; F++)(q = U[F]).beforeBrush && q.beforeBrush(), q.innerBeforeBrush(), sm(H, q, Y, F === V - 1), q.innerAfterBrush(), q.afterBrush && q.afterBrush(), Y.prevEl = q;
          for (var q, j = 0, Z = X.length; j < Z; j++)(q = X[j]).beforeBrush && q.beforeBrush(), q.innerBeforeBrush(), sm(H, q, Y, j === Z - 1), q.innerAfterBrush(), q.afterBrush && q.afterBrush(), Y.prevEl = q;
          W.clearTemporalDisplayables(), W.notClear = !0, H.restore()
        }
        B && i && rm(t, n), e.innerAfterBrush(), e.afterBrush && e.afterBrush(), (n.prevEl = e).__dirty = 0, e.__isRendered = !0
      }
    } else e.__dirty &= -2, e.__isRendered = !1
  }
  var lm = new ky,
    um = new Pn(100),
    hm = ["symbol", "symbolSize", "symbolKeepAspect", "color", "backgroundColor", "dashArrayX", "dashArrayY", "maxTileWidth", "maxTileHeight"];

  function cm(e, n) {
    if ("none" === e) return null;
    var i = n.getDevicePixelRatio(),
      r = n.getZr(),
      o = "svg" === r.painter.type;
    if (n = (e.dirty && lm.delete(e), lm.get(e))) return n;
    for (var a, s = D(e, {
        symbol: "rect",
        symbolSize: 1,
        symbolKeepAspect: !0,
        color: "rgba(0, 0, 0, 0.2)",
        backgroundColor: null,
        dashArrayX: 5,
        dashArrayY: 5,
        rotation: 0,
        maxTileWidth: 512,
        maxTileHeight: 512
      }), l = n = ("none" === s.backgroundColor && (s.backgroundColor = null), {
        repeat: "repeat"
      }), u = [i], h = !0, p = 0; p < hm.length; ++p) {
      var d = s[hm[p]];
      if (null != d && !W(d) && !U(d) && !Y(d) && "boolean" != typeof d) {
        h = !1;
        break
      }
      u.push(d)
    }
    h && (a = u.join(",") + (o ? "-svg" : ""), x = um.get(a)) && (o ? l.svgElement = x : l.image = x);
    var f, g = function t(e) {
        if (!e || 0 === e.length) return [
          [0, 0]
        ];
        if (Y(e)) return [
          [o = Math.ceil(e), o]
        ];
        for (var n = !0, i = 0; i < e.length; ++i)
          if (!Y(e[i])) {
            n = !1;
            break
          } if (n) return t([e]);
        var r = [];
        for (i = 0; i < e.length; ++i) {
          var o;
          Y(e[i]) ? (o = Math.ceil(e[i]), r.push([o, o])) : (o = E(e[i], (function(t) {
            return Math.ceil(t)
          }))).length % 2 == 1 ? r.push(o.concat(o)) : r.push(o)
        }
        return r
      }(s.dashArrayX),
      y = function(e) {
        if (!e || "object" == t(e) && 0 === e.length) return [0, 0];
        if (Y(e)) return [n = Math.ceil(e), n];
        var n = E(e, (function(t) {
          return Math.ceil(t)
        }));
        return e.length % 2 ? n.concat(n) : n
      }(s.dashArrayY),
      m = function t(e) {
        if (!e || 0 === e.length) return [
          ["rect"]
        ];
        if (U(e)) return [
          [e]
        ];
        for (var n = !0, i = 0; i < e.length; ++i)
          if (!U(e[i])) {
            n = !1;
            break
          } if (n) return t([e]);
        var r = [];
        for (i = 0; i < e.length; ++i) U(e[i]) ? r.push([e[i]]) : r.push(e[i]);
        return r
      }(s.symbol),
      v = function(t) {
        return E(t, pm)
      }(g),
      _ = pm(y),
      x = !o && c.createCanvas(),
      w = o && {
        tag: "g",
        attrs: {},
        key: "dcl",
        children: []
      },
      b = function() {
        for (var t = 1, e = 0, n = v.length; e < n; ++e) t = lo(t, v[e]);
        var i = 1;
        for (e = 0, n = m.length; e < n; ++e) i = lo(i, m[e].length);
        t *= i;
        var r = _ * v.length * m.length;
        return {
          width: Math.max(1, Math.min(t, s.maxTileWidth)),
          height: Math.max(1, Math.min(r, s.maxTileHeight))
        }
      }();
    x && (x.width = b.width * i, x.height = b.height * i, f = x.getContext("2d")), f && (f.clearRect(0, 0, x.width, x.height), s.backgroundColor) && (f.fillStyle = s.backgroundColor, f.fillRect(0, 0, x.width, x.height));
    for (var S = 0, M = 0; M < y.length; ++M) S += y[M];
    if (!(S <= 0))
      for (var T = -_, I = 0, C = 0, k = 0; T < b.height;) {
        if (I % 2 == 0) {
          for (var A = C / 2 % m.length, L = 0, P = 0, O = 0; L < 2 * b.width;) {
            var R, N, z, B, F, V = 0;
            for (M = 0; M < g[k].length; ++M) V += g[k][M];
            if (V <= 0) break;
            P % 2 == 0 && (N = .5 * (1 - s.symbolSize), R = L + g[k][P] * N, N = T + y[I] * N, z = g[k][P] * s.symbolSize, B = y[I] * s.symbolSize, F = O / 2 % m[A].length, function(t, e, n, a, l) {
              var u = o ? 1 : i;
              l = By(l, t * u, e * u, n * u, a * u, s.color, s.symbolKeepAspect);
              o ? (t = r.painter.renderOneToVNode(l)) && w.children.push(t) : am(f, l)
            }(R, N, z, B, m[A][F])), L += g[k][P], ++O, ++P === g[k].length && (P = 0)
          }++k === g.length && (k = 0)
        }
        T += y[I], ++C, ++I === y.length && (I = 0)
      }
    return h && um.put(a, x || w), l.image = x, l.svgElement = w, l.svgWidth = b.width, l.svgHeight = b.height, n.rotation = s.rotation, n.scaleX = n.scaleY = o ? 1 : 1 / i, lm.set(e, n), e.dirty = !1, n
  }

  function pm(t) {
    for (var e = 0, n = 0; n < t.length; ++n) e += t[n];
    return t.length % 2 == 1 ? 2 * e : e
  }
  var dm = new Ut,
    fm = {},
    gm = (Ly = {
      PROCESSOR: {
        FILTER: 1e3,
        SERIES_FILTER: 800,
        STATISTIC: 5e3
      },
      VISUAL: {
        LAYOUT: 1e3,
        PROGRESSIVE_LAYOUT: 1100,
        GLOBAL: 2e3,
        CHART: 3e3,
        POST_CHART_LAYOUT: 4600,
        COMPONENT: 4e3,
        BRUSH: 5e3,
        CHART_ITEM: 4500,
        ARIA: 6e3,
        DECAL: 7e3
      }
    }, "__flagInMainProcess"),
    ym = "__pendingUpdate",
    mm = "__needsUpdateStatus",
    vm = /^[a-zA-Z0-9_]+$/,
    _m = "__connectUpdateStatus";

  function xm(t) {
    return function() {
      for (var e = [], n = 0; n < arguments.length; n++) e[n] = arguments[n];
      if (!this.isDisposed()) return bm(this, t, e);
      this.id
    }
  }

  function wm(t) {
    return function() {
      for (var e = [], n = 0; n < arguments.length; n++) e[n] = arguments[n];
      return bm(this, t, e)
    }
  }

  function bm(t, e, n) {
    return n[0] = n[0] && n[0].toLowerCase(), Ut.prototype[e].apply(t, n)
  }
  i(Tm, Sm = Ut);
  var Sm, Mm = Tm;

  function Tm() {
    return null !== Sm && Sm.apply(this, arguments) || this
  }
  var Im, Cm, km, Dm, Am, Lm, Pm, Om, Rm, Nm, Em, zm, Bm, Fm, Vm, Hm, Wm, Gm, Um, Xm = ((Py = Mm.prototype).on = wm("on"), Py.off = wm("off"), i(Ym, Um = Ut), Ym.prototype._onframe = function() {
    if (!this._disposed) {
      Gm(this);
      var t = this._scheduler;
      if (this[ym]) {
        var e = this[ym].silent;
        this[gm] = !0;
        try {
          Im(this), Dm.update.call(this, null, this[ym].updateParams)
        } catch (t) {
          throw this[gm] = !1, this[ym] = null, t
        }
        this._zr.flush(), this[gm] = !1, this[ym] = null, Om.call(this, e), Rm.call(this, e)
      } else if (t.unfinished) {
        var n = 1,
          i = this._model,
          r = this._api;
        t.unfinished = !1;
        do {
          var o = +new Date
        } while (t.performSeriesTasks(i), t.performDataProcessorTasks(i), Lm(this, i), t.performVisualTasks(i), Fm(this, this._model, r, "remain", {}), 0 < (n -= +new Date - o) && t.unfinished);
        t.unfinished || this._zr.flush()
      }
    }
  }, Ym.prototype.getDom = function() {
    return this._dom
  }, Ym.prototype.getId = function() {
    return this.id
  }, Ym.prototype.getZr = function() {
    return this._zr
  }, Ym.prototype.isSSR = function() {
    return this._ssr
  }, Ym.prototype.setOption = function(t, e, n) {
    if (!this[gm])
      if (this._disposed) this.id;
      else {
        q(e) && (n = e.lazyUpdate, i = e.silent, r = e.replaceMerge, o = e.transition, e = e.notMerge), this[gm] = !0, this._model && !e || (e = new cd(this._api), a = this._theme, (s = this._model = new td).scheduler = this._scheduler, s.ssr = this._ssr, s.init(null, null, null, a, this._locale, e)), this._model.setOption(t, {
          replaceMerge: r
        }, nv);
        var i, r, o, a, s = {
          seriesTransition: o,
          optionChanged: !0
        };
        if (n) this[ym] = {
          silent: i,
          updateParams: s
        }, this[gm] = !1, this.getZr().wakeUp();
        else {
          try {
            Im(this), Dm.update.call(this, null, s)
          } catch (t) {
            throw this[ym] = null, this[gm] = !1, t
          }
          this._ssr || this._zr.flush(), this[ym] = null, this[gm] = !1, Om.call(this, i), Rm.call(this, i)
        }
      }
  }, Ym.prototype.setTheme = function() {}, Ym.prototype.getModel = function() {
    return this._model
  }, Ym.prototype.getOption = function() {
    return this._model && this._model.getOption()
  }, Ym.prototype.getWidth = function() {
    return this._zr.getWidth()
  }, Ym.prototype.getHeight = function() {
    return this._zr.getHeight()
  }, Ym.prototype.getDevicePixelRatio = function() {
    return this._zr.painter.dpr || o.hasGlobalWindow && window.devicePixelRatio || 1
  }, Ym.prototype.getRenderedCanvas = function(t) {
    return this.renderToCanvas(t)
  }, Ym.prototype.renderToCanvas = function(t) {
    return this._zr.painter.getRenderedCanvas({
      backgroundColor: (t = t || {}).backgroundColor || this._model.get("backgroundColor"),
      pixelRatio: t.pixelRatio || this.getDevicePixelRatio()
    })
  }, Ym.prototype.renderToSVGString = function(t) {
    return this._zr.painter.renderToString({
      useViewBox: (t = t || {}).useViewBox
    })
  }, Ym.prototype.getSvgDataURL = function() {
    var t;
    if (o.svgSupported) return N((t = this._zr).storage.getDisplayList(), (function(t) {
      t.stopAnimation(null, !0)
    })), t.painter.toDataURL()
  }, Ym.prototype.getDataURL = function(t) {
    var e, n, i, r;
    if (!this._disposed) return r = (t = t || {}).excludeComponents, e = this._model, n = [], i = this, N(r, (function(t) {
      e.eachComponent({
        mainType: t
      }, (function(t) {
        (t = i._componentsMap[t.__viewId]).group.ignore || (n.push(t), t.group.ignore = !0)
      }))
    })), r = "svg" === this._zr.painter.getType() ? this.getSvgDataURL() : this.renderToCanvas(t).toDataURL("image/" + (t && t.type || "png")), N(n, (function(t) {
      t.group.ignore = !1
    })), r;
    this.id
  }, Ym.prototype.getConnectedDataURL = function(t) {
    var e, n, i, r, o, a, s, l, u, h, p, d, f, g, y;
    if (!this._disposed) return e = "svg" === t.type, n = this.group, i = Math.min, r = Math.max, sv[n] ? (a = o = 1 / 0, l = s = -1 / 0, u = [], h = t && t.pixelRatio || this.getDevicePixelRatio(), N(av, (function(h, c) {
      var p;
      h.group === n && (p = e ? h.getZr().painter.getSvgDom().innerHTML : h.renderToCanvas(I(t)), h = h.getDom().getBoundingClientRect(), o = i(h.left, o), a = i(h.top, a), s = r(h.right, s), l = r(h.bottom, l), u.push({
        dom: p,
        left: h.left,
        top: h.top
      }))
    })), p = (s *= h) - (o *= h), d = (l *= h) - (a *= h), f = c.createCanvas(), (g = Hr(f, {
      renderer: e ? "svg" : "canvas"
    })).resize({
      width: p,
      height: d
    }), e ? (y = "", N(u, (function(t) {
      var e = t.left - o,
        n = t.top - a;
      y += '<g transform="translate(' + e + "," + n + ')">' + t.dom + "</g>"
    })), g.painter.getSvgRoot().innerHTML = y, t.connectedBackgroundColor && g.painter.setBackgroundColor(t.connectedBackgroundColor), g.refreshImmediately(), g.painter.toDataURL()) : (t.connectedBackgroundColor && g.add(new Ms({
      shape: {
        x: 0,
        y: 0,
        width: p,
        height: d
      },
      style: {
        fill: t.connectedBackgroundColor
      }
    })), N(u, (function(t) {
      t = new gs({
        style: {
          x: t.left * h - o,
          y: t.top * h - a,
          image: t.dom
        }
      }), g.add(t)
    })), g.refreshImmediately(), f.toDataURL("image/" + (t && t.type || "png")))) : this.getDataURL(t);
    this.id
  }, Ym.prototype.convertToPixel = function(t, e) {
    return Am(this, "convertToPixel", t, e)
  }, Ym.prototype.convertFromPixel = function(t, e) {
    return Am(this, "convertFromPixel", t, e)
  }, Ym.prototype.containPixel = function(t, e) {
    var n;
    if (!this._disposed) return N(To(this._model, t), (function(t, i) {
      0 <= i.indexOf("Models") && N(t, (function(t) {
        var r = t.coordinateSystem;
        r && r.containPoint ? n = n || !!r.containPoint(e) : "seriesModels" === i && (r = this._chartsMap[t.__viewId]) && r.containPoint && (n = n || r.containPoint(e, t))
      }), this)
    }), this), !!n;
    this.id
  }, Ym.prototype.getVisual = function(t, e) {
    var n = (t = To(this._model, t, {
      defaultMainType: "series"
    })).seriesModel.getData();
    if (null == (t = t.hasOwnProperty("dataIndexInside") ? t.dataIndexInside : t.hasOwnProperty("dataIndex") ? n.indexOfRawIndex(t.dataIndex) : null)) return Sy(n, e);
    var i = n,
      r = t,
      o = e;
    switch (o) {
      case "color":
        return i.getItemVisual(r, "style")[i.getVisual("drawType")];
      case "opacity":
        return i.getItemVisual(r, "style").opacity;
      case "symbol":
      case "symbolSize":
      case "liftZ":
        return i.getItemVisual(r, o)
    }
  }, Ym.prototype.getViewOfComponentModel = function(t) {
    return this._componentsMap[t.__viewId]
  }, Ym.prototype.getViewOfSeriesModel = function(t) {
    return this._chartsMap[t.__viewId]
  }, Ym.prototype._initEvents = function() {
    var t, e, n, i = this;
    N(Qm, (function(t) {
      function e(e) {
        var n, r, o, a = i.getModel(),
          s = e.target;
        "globalout" === t ? n = {} : s && Ty(s, (function(t) {
          var e;
          return (t = Us(t)) && null != t.dataIndex ? (e = t.dataModel || a.getSeriesByIndex(t.seriesIndex), n = e && e.getDataParams(t.dataIndex, t.dataType, s) || {}, 1) : t.eventData && (n = k({}, t.eventData), 1)
        }), !0), n && (r = n.componentType, o = n.componentIndex, "markLine" !== r && "markPoint" !== r && "markArea" !== r || (r = "series", o = n.seriesIndex), o = (r = r && null != o && a.getComponent(r, o)) && i["series" === r.mainType ? "_chartsMap" : "_componentsMap"][r.__viewId], n.event = e, n.type = t, i._$eventProcessor.eventInfo = {
          targetEl: s,
          packedEvent: n,
          model: r,
          view: o
        }, i.trigger(t, n))
      }
      e.zrEventfulCallAtLast = !0, i._zr.on(t, e, i)
    })), N(tv, (function(t, e) {
      i._messageCenter.on(e, (function(t) {
        this.trigger(e, t)
      }), i)
    })), N(["selectchanged"], (function(t) {
      i._messageCenter.on(t, (function(e) {
        this.trigger(t, e)
      }), i)
    })), t = this._messageCenter, n = (e = this)._api, t.on("selectchanged", (function(t) {
      var i = n.getModel();
      t.isFromClick ? (My("map", "selectchanged", e, i, t), My("pie", "selectchanged", e, i, t)) : "select" === t.fromAction ? (My("map", "selected", e, i, t), My("pie", "selected", e, i, t)) : "unselect" === t.fromAction && (My("map", "unselected", e, i, t), My("pie", "unselected", e, i, t))
    }))
  }, Ym.prototype.isDisposed = function() {
    return this._disposed
  }, Ym.prototype.clear = function() {
    this._disposed ? this.id : this.setOption({
      series: []
    }, !0)
  }, Ym.prototype.dispose = function() {
    var t, e, n;
    this._disposed ? this.id : (this._disposed = !0, this.getDom() && Do(this.getDom(), hv, ""), e = (t = this)._api, n = t._model, N(t._componentsViews, (function(t) {
      t.dispose(n, e)
    })), N(t._chartsViews, (function(t) {
      t.dispose(n, e)
    })), t._zr.dispose(), t._dom = t._model = t._chartsMap = t._componentsMap = t._chartsViews = t._componentsViews = t._scheduler = t._api = t._zr = t._throttledZrFlush = t._theme = t._coordSysMgr = t._messageCenter = null, delete av[t.id])
  }, Ym.prototype.resize = function(t) {
    if (!this[gm])
      if (this._disposed) this.id;
      else {
        this._zr.resize(t);
        var e = this._model;
        if (this._loadingFX && this._loadingFX.resize(), e) {
          e = e.resetOption("media");
          var n = t && t.silent;
          this[ym] && (null == n && (n = this[ym].silent), e = !0, this[ym] = null), this[gm] = !0;
          try {
            e && Im(this), Dm.update.call(this, {
              type: "resize",
              animation: k({
                duration: 0
              }, t && t.animation)
            })
          } catch (t) {
            throw this[gm] = !1, t
          }
          this[gm] = !1, Om.call(this, n), Rm.call(this, n)
        }
      }
  }, Ym.prototype.showLoading = function(t, e) {
    this._disposed ? this.id : (q(t) && (e = t, t = ""), t = t || "default", this.hideLoading(), ov[t] && (t = ov[t](this._api, e), e = this._zr, this._loadingFX = t, e.add(t)))
  }, Ym.prototype.hideLoading = function() {
    this._disposed ? this.id : (this._loadingFX && this._zr.remove(this._loadingFX), this._loadingFX = null)
  }, Ym.prototype.makeActionFromEvent = function(t) {
    var e = k({}, t);
    return e.type = tv[t.type], e
  }, Ym.prototype.dispatchAction = function(t, e) {
    var n;
    this._disposed ? this.id : (q(e) || (e = {
      silent: !!e
    }), Jm[t.type] && this._model && (this[gm] ? this._pendingActions.push(t) : (n = e.silent, Pm.call(this, t, n), (t = e.flush) ? this._zr.flush() : !1 !== t && o.browser.weChat && this._throttledZrFlush(), Om.call(this, n), Rm.call(this, n))))
  }, Ym.prototype.updateLabelLayout = function() {
    dm.trigger("series:layoutlabels", this._model, this._api, {
      updatedSeries: []
    })
  }, Ym.prototype.appendData = function(t) {
    var e;
    this._disposed ? this.id : (e = t.seriesIndex, this.getModel().getSeriesByIndex(e).appendData(t), this._scheduler.unfinished = !0, this.getZr().wakeUp())
  }, Ym.internalField = (Im = function(t) {
    var e = t._scheduler;
    e.restorePipelines(t._model), e.prepareStageTasks(), Cm(t, !0), Cm(t, !1), e.plan()
  }, Cm = function(t, e) {
    for (var n = t._model, i = t._scheduler, r = e ? t._componentsViews : t._chartsViews, o = e ? t._componentsMap : t._chartsMap, a = t._zr, s = t._api, l = 0; l < r.length; l++) r[l].__alive = !1;

    function u(t) {
      var l, u = t.__requireNewView,
        h = (t.__requireNewView = !1, "_ec_" + t.id + "_" + t.type);
      (u = !u && o[h]) || (l = Oo(t.type), (u = new(e ? kg.getClass(l.main, l.sub) : Og.getClass(l.sub))).init(n, s), o[h] = u, r.push(u), a.add(u.group)), t.__viewId = u.__id = h, u.__alive = !0, u.__model = t, u.group.__ecComponentInfo = {
        mainType: t.mainType,
        index: t.componentIndex
      }, e || i.prepareView(u, t, n, s)
    }
    for (e ? n.eachComponent((function(t, e) {
        "series" !== t && u(e)
      })) : n.eachSeries(u), l = 0; l < r.length;) {
      var h = r[l];
      h.__alive ? l++ : (e || h.renderTask.dispose(), a.remove(h.group), h.dispose(n, s), r.splice(l, 1), o[h.__id] === h && delete o[h.__id], h.__id = h.group.__ecComponentInfo = null)
    }
  }, km = function(t, e, n, i, r) {
    var o, a, s = t._model;

    function l(i) {
      i && i.__alive && i[e] && i[e](i.__model, s, t._api, n)
    }
    s.setUpdatePayload(n), i ? ((o = {})[i + "Id"] = n[i + "Id"], o[i + "Index"] = n[i + "Index"], o[i + "Name"] = n[i + "Name"], o = {
      mainType: i,
      query: o
    }, r && (o.subType = r), null != (r = n.excludeSeriesId) && (a = yt(), N(po(r), (function(t) {
      null != (t = _o(t, null)) && a.set(t, !0)
    }))), s && s.eachComponent(o, (function(e) {
      var i, r;
      if (!(o = a && null != a.get(e.id)))
        if (zl(n))
          if (e instanceof _g) {
            if (n.type === $s && !n.notBlur && !e.get(["emphasis", "disabled"])) {
              var o = e,
                s = n,
                l = t._api,
                u = o.seriesIndex,
                h = o.getData(s.dataType);
              if (h) {
                s = (W(s = bo(h, s)) ? s[0] : s) || 0;
                var c = h.getItemGraphicEl(s);
                if (!c)
                  for (var p = h.count(), d = 0; !c && d < p;) c = h.getItemGraphicEl(d++);
                c ? Tl(u, (s = Us(c)).focus, s.blurScope, l) : (s = o.get(["emphasis", "focus"]), o = o.get(["emphasis", "blurScope"]), null != s && Tl(u, s, o, l))
              }
            }
          } else s = (u = Cl(e.mainType, e.componentIndex, n.name, t._api)).focusSelf, o = u.dispatchers, n.type === $s && s && !n.notBlur && Il(e.mainType, e.componentIndex, t._api), o && N(o, (function(t) {
            (n.type === $s ? ml : vl)(t)
          }));
      else El(n) && e instanceof _g && (l = e, o = n, t._api, El(o) && (i = o.dataType, W(r = bo(l.getData(i), o)) || (r = [r]), l[o.type === el ? "toggleSelect" : o.type === Js ? "select" : "unselect"](r, i)), kl(e), Wm(t))
    }), t), s && s.eachComponent(o, (function(e) {
      a && null != a.get(e.id) || l(t["series" === i ? "_chartsMap" : "_componentsMap"][e.__viewId])
    }), t)) : N([].concat(t._componentsViews).concat(t._chartsViews), l)
  }, Dm = {
    prepareAndUpdate: function(t) {
      Im(this), Dm.update.call(this, t, {
        optionChanged: null != t.newOption
      })
    },
    update: function(t, e) {
      var n = this._model,
        i = this._api,
        r = this._zr,
        o = this._coordSysMgr,
        a = this._scheduler;
      n && (n.setUpdatePayload(t), a.restoreData(n, t), a.performSeriesTasks(n), o.create(n, i), a.performDataProcessorTasks(n, t), Lm(this, n), o.update(n, i), qm(n), a.performVisualTasks(n, t), zm(this, n, i, t, e), o = n.get("backgroundColor") || "transparent", a = n.get("darkMode"), r.setBackgroundColor(o), null != a && "auto" !== a && r.setDarkMode(a), dm.trigger("afterupdate", n, i))
    },
    updateTransform: function(t) {
      var e, n, i = this,
        r = this._model,
        o = this._api;
      r && (r.setUpdatePayload(t), e = [], r.eachComponent((function(n, a) {
        "series" !== n && (n = i.getViewOfComponentModel(a)) && n.__alive && (!n.updateTransform || (a = n.updateTransform(a, r, o, t)) && a.update) && e.push(n)
      })), n = yt(), r.eachSeries((function(e) {
        var a = i._chartsMap[e.__viewId];
        (!a.updateTransform || (a = a.updateTransform(e, r, o, t)) && a.update) && n.set(e.uid, 1)
      })), qm(r), this._scheduler.performVisualTasks(r, t, {
        setDirty: !0,
        dirtyMap: n
      }), Fm(this, r, o, t, {}, n), dm.trigger("afterupdate", r, o))
    },
    updateView: function(t) {
      var e = this._model;
      e && (e.setUpdatePayload(t), Og.markUpdateMethod(t, "updateView"), qm(e), this._scheduler.performVisualTasks(e, t, {
        setDirty: !0
      }), zm(this, e, this._api, t, {}), dm.trigger("afterupdate", e, this._api))
    },
    updateVisual: function(t) {
      var e = this,
        n = this._model;
      n && (n.setUpdatePayload(t), n.eachSeries((function(t) {
        t.getData().clearAllVisual()
      })), Og.markUpdateMethod(t, "updateVisual"), qm(n), this._scheduler.performVisualTasks(n, t, {
        visualType: "visual",
        setDirty: !0
      }), n.eachComponent((function(i, r) {
        "series" !== i && (i = e.getViewOfComponentModel(r)) && i.__alive && i.updateVisual(r, n, e._api, t)
      })), n.eachSeries((function(i) {
        e._chartsMap[i.__viewId].updateVisual(i, n, e._api, t)
      })), dm.trigger("afterupdate", n, this._api))
    },
    updateLayout: function(t) {
      Dm.update.call(this, t)
    }
  }, Am = function(t, e, n, i) {
    if (t._disposed) t.id;
    else
      for (var r = t._model, o = t._coordSysMgr.getCoordinateSystems(), a = To(r, n), s = 0; s < o.length; s++) {
        var l = o[s];
        if (l[e] && null != (l = l[e](r, a, i))) return l
      }
  }, Lm = function(t, e) {
    var n = t._chartsMap,
      i = t._scheduler;
    e.eachSeries((function(t) {
      i.updateStreamModes(t, n[t.__viewId])
    }))
  }, Pm = function(t, e) {
    var n, i, r = this,
      o = this.getModel(),
      a = t.type,
      s = t.escapeConnect,
      l = Jm[a],
      u = l.actionInfo,
      h = (p = (u.update || "update").split(":")).pop(),
      c = null != p[0] && Oo(p[0]),
      p = (this[gm] = !0, [t]),
      d = !1,
      f = (t.batch && (d = !0, p = E(t.batch, (function(e) {
        return (e = D(k({}, e), t)).batch = null, e
      }))), []),
      g = El(t),
      y = zl(t);
    if (y && Ml(this._api), N(p, (function(e) {
        var i, o;
        (n = (n = l.action(e, r._model, r._api)) || k({}, e)).type = u.event || n.type, f.push(n), y ? (i = (o = Io(t)).queryOptionMap, o = o.mainTypeSpecified ? i.keys()[0] : "series", km(r, h, e, o), Wm(r)) : g ? (km(r, h, e, "series"), Wm(r)) : c && km(r, h, e, c.main, c.sub)
      })), "none" !== h && !y && !g && !c) try {
      this[ym] ? (Im(this), Dm.update.call(this, t), this[ym] = null) : Dm[h].call(this, t)
    } catch (e) {
      throw this[gm] = !1, e
    }
    n = d ? {
      type: u.event || a,
      escapeConnect: s,
      batch: f
    } : f[0], this[gm] = !1, e || ((p = this._messageCenter).trigger(n.type, n), g && (d = {
      type: "selectchanged",
      escapeConnect: s,
      selected: (i = [], o.eachSeries((function(t) {
        N(t.getAllData(), (function(e) {
          e.data;
          e = e.type;
          var n = t.getSelectedDataIndices();
          0 < n.length && (n = {
            dataIndex: n,
            seriesIndex: t.seriesIndex
          }, null != e && (n.dataType = e), i.push(n))
        }))
      })), i),
      isFromClick: t.isFromClick || !1,
      fromAction: t.type,
      fromActionPayload: t
    }, p.trigger(d.type, d)))
  }, Om = function(t) {
    for (var e = this._pendingActions; e.length;) {
      var n = e.shift();
      Pm.call(this, n, t)
    }
  }, Rm = function(t) {
    t || this.trigger("updated")
  }, Nm = function(t, e) {
    t.on("rendered", (function(n) {
      e.trigger("rendered", n), !t.animation.isFinished() || e[ym] || e._scheduler.unfinished || e._pendingActions.length || e.trigger("finished")
    }))
  }, Em = function(t, e) {
    t.on("mouseover", (function(t) {
      var n, i, r, o, a = Ty(t.target, Nl);
      a && (a = a, n = t, t = e._api, r = (o = Cl((i = Us(a)).componentMainType, i.componentIndex, i.componentHighDownName, t)).dispatchers, o = o.focusSelf, r ? (o && Il(i.componentMainType, i.componentIndex, t), N(r, (function(t) {
        return gl(t, n)
      }))) : (Tl(i.seriesIndex, i.focus, i.blurScope, t), "self" === i.focus && Il(i.componentMainType, i.componentIndex, t), gl(a, n)), Wm(e))
    })).on("mouseout", (function(t) {
      var n, i, r = Ty(t.target, Nl);
      r && (r = r, n = t, Ml(t = e._api), (i = Cl((i = Us(r)).componentMainType, i.componentIndex, i.componentHighDownName, t).dispatchers) ? N(i, (function(t) {
        return yl(t, n)
      })) : yl(r, n), Wm(e))
    })).on("click", (function(t) {
      var n;
      (t = Ty(t.target, (function(t) {
        return null != Us(t).dataIndex
      }), !0)) && (n = t.selected ? "unselect" : "select", t = Us(t), e._api.dispatchAction({
        type: n,
        dataType: t.dataType,
        dataIndexInside: t.dataIndex,
        seriesIndex: t.seriesIndex,
        isFromClick: !0
      }))
    }))
  }, zm = function(t, e, n, i, r) {
    var o, a, s, l, u, h, c;
    u = [], c = !(h = []), (o = e).eachComponent((function(t, e) {
      var n = e.get("zlevel") || 0,
        i = e.get("z") || 0,
        r = e.getZLevelKey();
      c = c || !!r, ("series" === t ? h : u).push({
        zlevel: n,
        z: i,
        idx: e.componentIndex,
        type: t,
        key: r
      })
    })), c && ($e(a = u.concat(h), (function(t, e) {
      return t.zlevel === e.zlevel ? t.z - e.z : t.zlevel - e.zlevel
    })), N(a, (function(t) {
      var e = o.getComponent(t.type, t.idx),
        n = t.zlevel;
      t = t.key;
      null != s && (n = Math.max(s, n)), t ? (n === s && t !== l && n++, l = t) : l && (n === s && n++, l = ""), s = n, e.setZLevel(n)
    }))), Bm(t, e, n, i, r), N(t._chartsViews, (function(t) {
      t.__alive = !1
    })), Fm(t, e, n, i, r), N(t._chartsViews, (function(t) {
      t.__alive || t.remove(e, n)
    }))
  }, Bm = function(t, e, n, i, r, o) {
    N(o || t._componentsViews, (function(t) {
      var r = t.__model;
      Km(0, t), t.render(r, e, n, i), Zm(r, t), $m(r, t)
    }))
  }, Fm = function(t, e, n, i, r, a) {
    var s, l, u, h, c = t._scheduler,
      p = (r = k(r || {}, {
        updatedSeries: e.getSeries()
      }), dm.trigger("series:beforeupdate", e, n, r), !1);
    e.eachSeries((function(e) {
      var n, r = t._chartsMap[e.__viewId],
        o = (r.__alive = !0, r.renderTask);
      c.updatePayload(o, i), Km(0, r), a && a.get(e.uid) && o.dirty(), o.perform(c.getPerformArgs(o)) && (p = !0), r.group.silent = !!e.get("silent"), o = r, n = e.get("blendMode") || null, o.eachRendered((function(t) {
        t.isGroup || (t.style.blend = n)
      })), kl(e)
    })), c.unfinished = p || c.unfinished, dm.trigger("series:layoutlabels", e, n, r), dm.trigger("series:transition", e, n, r), e.eachSeries((function(e) {
      var n = t._chartsMap[e.__viewId];
      Zm(e, n), $m(e, n)
    })), l = e, u = (s = t)._zr.storage, h = 0, u.traverse((function(t) {
      t.isGroup || h++
    })), h > l.get("hoverLayerThreshold") && !o.node && !o.worker && l.eachSeries((function(t) {
      t.preventUsingHoverLayer || (t = s._chartsMap[t.__viewId]).__alive && t.eachRendered((function(t) {
        t.states.emphasis && (t.states.emphasis.hoverLayer = !0)
      }))
    })), dm.trigger("series:afterupdate", e, n, r)
  }, Wm = function(t) {
    t[mm] = !0, t.getZr().wakeUp()
  }, Gm = function(t) {
    t[mm] && (t.getZr().storage.traverse((function(t) {
      bh(t) || jm(t)
    })), t[mm] = !1)
  }, Vm = function(t) {
    return i(e, n = od), e.prototype.getCoordinateSystems = function() {
      return t._coordSysMgr.getCoordinateSystems()
    }, e.prototype.getComponentByElement = function(e) {
      for (; e;) {
        var n = e.__ecComponentInfo;
        if (null != n) return t._model.getComponent(n.mainType, n.index);
        e = e.parent
      }
    }, e.prototype.enterEmphasis = function(e, n) {
      ml(e, n), Wm(t)
    }, e.prototype.leaveEmphasis = function(e, n) {
      vl(e, n), Wm(t)
    }, e.prototype.enterBlur = function(e) {
      _l(e), Wm(t)
    }, e.prototype.leaveBlur = function(e) {
      xl(e), Wm(t)
    }, e.prototype.enterSelect = function(e) {
      wl(e), Wm(t)
    }, e.prototype.leaveSelect = function(e) {
      bl(e), Wm(t)
    }, e.prototype.getModel = function() {
      return t.getModel()
    }, e.prototype.getViewOfComponentModel = function(e) {
      return t.getViewOfComponentModel(e)
    }, e.prototype.getViewOfSeriesModel = function(e) {
      return t.getViewOfSeriesModel(e)
    }, new e(t);

    function e() {
      return null !== n && n.apply(this, arguments) || this
    }
    var n
  }, void(Hm = function(t) {
    function e(t, e) {
      for (var n = 0; n < t.length; n++) t[n][_m] = e
    }
    N(tv, (function(n, i) {
      t._messageCenter.on(i, (function(n) {
        var i, r;
        !sv[t.group] || 0 === t[_m] || n && n.escapeConnect || (i = t.makeActionFromEvent(n), r = [], N(av, (function(e) {
          e !== t && e.group === t.group && r.push(e)
        })), e(r, 0), N(r, (function(t) {
          1 !== t[_m] && t.dispatchAction(i)
        })), e(r, 2))
      }))
    }))
  })), Ym);

  function Ym(t, e, n) {
    var i = Um.call(this, new my) || this;
    i._chartsViews = [], i._chartsMap = {}, i._componentsViews = [], i._componentsMap = {}, i._pendingActions = [], n = n || {}, U(e) && (e = rv[e]), i._dom = t, n.ssr && Ur((function(t) {
      var e, n = (t = Us(t)).dataIndex;
      if (null != n) return (e = yt()).set("series_index", t.seriesIndex), e.set("data_index", n), t.ssrType && e.set("ssr_type", t.ssrType), e
    })), t = i._zr = Hr(t, {
      renderer: n.renderer || "canvas",
      devicePixelRatio: n.devicePixelRatio,
      width: n.width,
      height: n.height,
      ssr: n.ssr,
      useDirtyRect: nt(n.useDirtyRect, !1),
      useCoarsePointer: nt(n.useCoarsePointer, "auto"),
      pointerSize: n.pointerSize
    }), i._ssr = n.ssr, i._throttledZrFlush = Gg(V(t.flush, t), 17), (e = I(e)) && Ad(e, !0), i._theme = e, i._locale = U(e = n.locale || Lc) ? (n = Dc[e.toUpperCase()] || {}, "ZH" === e || "EN" === e ? I(n) : C(I(n), I(Dc.EN), !1)) : C(I(e), I(Dc.EN), !1), i._coordSysMgr = new ld, n = i._api = Vm(i);

    function r(t, e) {
      return t.__prio - e.__prio
    }
    return $e(iv, r), $e(ev, r), i._scheduler = new Jg(i, n, ev, iv), i._messageCenter = new Mm, i._initEvents(), i.resize = V(i.resize, i), t.animation.on("frame", i._onframe, i), Nm(t, i), Em(t, i), ut(i), i
  }

  function qm(t) {
    t.clearColorPalette(), t.eachSeries((function(t) {
      t.clearColorPalette()
    }))
  }

  function jm(t) {
    for (var e = [], n = t.currentStates, i = 0; i < n.length; i++) {
      var r = n[i];
      "emphasis" !== r && "blur" !== r && "select" !== r && e.push(r)
    }
    t.selected && t.states.select && e.push("select"), 2 === t.hoverState && t.states.emphasis ? e.push("emphasis") : 1 === t.hoverState && t.states.blur && e.push("blur"), t.useStates(e)
  }

  function Zm(t, e) {
    var n, i;
    t.preventAutoZ || (n = t.get("z") || 0, i = t.get("zlevel") || 0, e.eachRendered((function(t) {
      return function t(e, n, i, r) {
        var o = e.getTextContent(),
          a = e.getTextGuideLine(),
          s = e.isGroup;
        if (s)
          for (var l = e.childrenRef(), u = 0; u < l.length; u++) r = Math.max(t(l[u], n, i, r), r);
        else e.z = n, e.zlevel = i, r = Math.max(e.z2, r);
        return o && (o.z = n, o.zlevel = i, isFinite(r)) && (o.z2 = r + 2), a && (s = e.textGuideLineConfig, a.z = n, a.zlevel = i, isFinite(r)) && (a.z2 = r + (s && s.showAbove ? 1 : -1)), r
      }(t, n, i, -1 / 0), !0
    })))
  }

  function Km(t, e) {
    e.eachRendered((function(t) {
      var e, n;
      bh(t) || (e = t.getTextContent(), n = t.getTextGuideLine(), t.stateTransition && (t.stateTransition = null), e && e.stateTransition && (e.stateTransition = null), n && n.stateTransition && (n.stateTransition = null), t.hasState() ? (t.prevStates = t.currentStates, t.clearStates()) : t.prevStates && (t.prevStates = null))
    }))
  }

  function $m(t, e) {
    var n = t.getModel("stateAnimation"),
      i = t.isAnimationEnabled(),
      r = 0 < (t = n.get("duration")) ? {
        duration: t,
        delay: n.get("delay"),
        easing: n.get("easing")
      } : null;
    e.eachRendered((function(t) {
      var e, n, o;
      t.states && t.states.emphasis && (bh(t) || (t instanceof as && ((o = qs(n = t)).normalFill = n.style.fill, o.normalStroke = n.style.stroke, n = n.states.select || {}, o.selectFill = n.style && n.style.fill || null, o.selectStroke = n.style && n.style.stroke || null), t.__dirty && (o = t.prevStates) && t.useStates(o), i && (t.stateTransition = r, n = t.getTextContent(), e = t.getTextGuideLine(), n && (n.stateTransition = r), e) && (e.stateTransition = r), t.__dirty && jm(t)))
    }))
  }
  var Qm = ((Oy = Xm.prototype).on = xm("on"), Oy.off = xm("off"), Oy.one = function(t, e, n) {
      var i = this;
      this.on.call(this, t, (function n() {
        for (var r = [], o = 0; o < arguments.length; o++) r[o] = arguments[o];
        e && e.apply && e.apply(this, r), i.off(t, n)
      }), n)
    }, ["click", "dblclick", "mouseover", "mouseout", "mousemove", "mousedown", "mouseup", "globalout", "contextmenu"]),
    Jm = {},
    tv = {},
    ev = [],
    nv = [],
    iv = [],
    rv = {},
    ov = {},
    av = {},
    sv = {},
    lv = +new Date,
    uv = +new Date,
    hv = "_echarts_instance_";

  function cv(t) {
    sv[t] = !1
  }

  function pv(t) {
    return av[(e = hv, (t = t).getAttribute ? t.getAttribute(e) : t[e])];
    var e
  }

  function dv(t, e) {
    rv[t] = e
  }

  function fv(t) {
    L(nv, t) < 0 && nv.push(t)
  }

  function gv(t, e) {
    Mv(ev, t, e, 2e3)
  }

  function yv(t) {
    vv("afterinit", t)
  }

  function mv(t) {
    vv("afterupdate", t)
  }

  function vv(t, e) {
    dm.on(t, e)
  }

  function _v(t, e, n) {
    G(e) && (n = e, e = "");
    var i = q(t) ? t.type : [t, t = {
      event: e
    }][0];
    t.event = (t.event || i).toLowerCase(), e = t.event, tv[e] || (at(vm.test(i) && vm.test(e)), Jm[i] || (Jm[i] = {
      action: n,
      actionInfo: t
    }), tv[e] = i)
  }

  function xv(t, e) {
    ld.register(t, e)
  }

  function wv(t, e) {
    Mv(iv, t, e, 1e3, "layout")
  }

  function bv(t, e) {
    Mv(iv, t, e, 3e3, "visual")
  }
  Ay = cv;
  var Sv = [];

  function Mv(t, e, n, i, r) {
    (G(e) || q(e)) && (n = e, e = i), 0 <= L(Sv, n) || (Sv.push(n), (i = Jg.wrapStageHandler(n, r)).__prio = e, i.__raw = n, t.push(i))
  }

  function Tv(t, e) {
    ov[t] = e
  }

  function Iv(t, e, n) {
    var i = fm.registerMap;
    i && i(t, e, n)
  }

  function Cv(t) {
    var e = (t = I(t)).type,
      n = (e || uo(""), e.split(":")),
      i = (2 !== n.length && uo(""), !1);
    "echarts" === n[0] && (e = n[1], i = !0), t.__isBuiltIn = i, Bf.set(e, t)
  }

  function kv(t) {
    return null == t ? 0 : t.length || 1
  }

  function Dv(t) {
    return t
  }
  bv(2e3, vc), bv(4500, Wo), bv(4500, wc), bv(2e3, wy), bv(4500, by), bv(7e3, (function(t, e) {
    t.eachRawSeries((function(n) {
      var i;
      !t.isSeriesFiltered(n) && ((i = n.getData()).hasItemVisual() && i.each((function(t) {
        var n = i.getItemVisual(t, "decal");
        n && (i.ensureUniqueItemVisual(t, "style").decal = cm(n, e))
      })), n = i.getVisual("decal")) && (i.getVisual("style").decal = cm(n, e))
    }))
  })), fv(Ad), gv(900, (function(t) {
    var e = yt();
    t.eachSeries((function(t) {
      var n, i = t.get("stack");
      i && (i = e.get(i) || e.set(i, []), (t = {
        stackResultDimension: (n = t.getData()).getCalculationInfo("stackResultDimension"),
        stackedOverDimension: n.getCalculationInfo("stackedOverDimension"),
        stackedDimension: n.getCalculationInfo("stackedDimension"),
        stackedByDimension: n.getCalculationInfo("stackedByDimension"),
        isStackedByIndex: n.getCalculationInfo("isStackedByIndex"),
        data: n,
        seriesModel: t
      }).stackedDimension) && (t.isStackedByIndex || t.stackedByDimension) && (i.length && n.setCalculationInfo("stackedOnSeries", i[i.length - 1].seriesModel), i.push(t))
    })), e.each(Ld)
  })), Tv("default", (function(t, e) {
    D(e = e || {}, {
      text: "loading",
      textColor: "#000",
      fontSize: 12,
      fontWeight: "normal",
      fontStyle: "normal",
      fontFamily: "sans-serif",
      maskColor: "rgba(255, 255, 255, 0.8)",
      showSpinner: !0,
      color: "#5470c6",
      spinnerRadius: 10,
      lineWidth: 5,
      zlevel: 0
    });
    var n, i = new Rr,
      r = new Ms({
        style: {
          fill: e.maskColor
        },
        zlevel: e.zlevel,
        z: 1e4
      }),
      o = (i.add(r), new Ds({
        style: {
          text: e.text,
          fill: e.textColor,
          fontSize: e.fontSize,
          fontWeight: e.fontWeight,
          fontStyle: e.fontStyle,
          fontFamily: e.fontFamily
        },
        zlevel: e.zlevel,
        z: 10001
      })),
      a = new Ms({
        style: {
          fill: "none"
        },
        textContent: o,
        textConfig: {
          position: "right",
          distance: 10
        },
        zlevel: e.zlevel,
        z: 10001
      });
    return i.add(a), e.showSpinner && ((n = new $u({
      shape: {
        startAngle: -Qg / 2,
        endAngle: -Qg / 2 + .1,
        r: e.spinnerRadius
      },
      style: {
        stroke: e.color,
        lineCap: "round",
        lineWidth: e.lineWidth
      },
      zlevel: e.zlevel,
      z: 10001
    })).animateShape(!0).when(1e3, {
      endAngle: 3 * Qg / 2
    }).start("circularInOut"), n.animateShape(!0).when(1e3, {
      startAngle: 3 * Qg / 2
    }).delay(300).start("circularInOut"), i.add(n)), i.resize = function() {
      var i = o.getBoundingRect().width,
        s = e.showSpinner ? e.spinnerRadius : 0,
        l = (i = (t.getWidth() - 2 * s - (e.showSpinner && i ? 10 : 0) - i) / 2 - (e.showSpinner && i ? 0 : 5 + i / 2) + (e.showSpinner ? 0 : i / 2) + (i ? 0 : s), t.getHeight() / 2);
      e.showSpinner && n.setShape({
        cx: i,
        cy: l
      }), a.setShape({
        x: i - s,
        y: l - s,
        width: 2 * s,
        height: 2 * s
      }), r.setShape({
        x: 0,
        y: 0,
        width: t.getWidth(),
        height: t.getHeight()
      })
    }, i.resize(), i
  })), _v({
    type: $s,
    event: $s,
    update: $s
  }, wt), _v({
    type: Qs,
    event: Qs,
    update: Qs
  }, wt), _v({
    type: Js,
    event: Js,
    update: Js
  }, wt), _v({
    type: tl,
    event: tl,
    update: tl
  }, wt), _v({
    type: el,
    event: el,
    update: el
  }, wt), dv("light", gy), dv("dark", Vh), Lv.prototype.add = function(t) {
    return this._add = t, this
  }, Lv.prototype.update = function(t) {
    return this._update = t, this
  }, Lv.prototype.updateManyToOne = function(t) {
    return this._updateManyToOne = t, this
  }, Lv.prototype.updateOneToMany = function(t) {
    return this._updateOneToMany = t, this
  }, Lv.prototype.updateManyToMany = function(t) {
    return this._updateManyToMany = t, this
  }, Lv.prototype.remove = function(t) {
    return this._remove = t, this
  }, Lv.prototype.execute = function() {
    this[this._diffModeMultiple ? "_executeMultiple" : "_executeOneToOne"]()
  }, Lv.prototype._executeOneToOne = function() {
    var t = this._old,
      e = this._new,
      n = {},
      i = new Array(t.length),
      r = new Array(e.length);
    this._initIndexMap(t, null, i, "_oldKeyGetter"), this._initIndexMap(e, n, r, "_newKeyGetter");
    for (var o = 0; o < t.length; o++) {
      var a, s = i[o],
        l = n[s],
        u = kv(l);
      1 < u ? (a = l.shift(), 1 === l.length && (n[s] = l[0]), this._update && this._update(a, o)) : 1 === u ? (n[s] = null, this._update && this._update(l, o)) : this._remove && this._remove(o)
    }
    this._performRestAdd(r, n)
  }, Lv.prototype._executeMultiple = function() {
    var t = this._old,
      e = this._new,
      n = {},
      i = {},
      r = [],
      o = [];
    this._initIndexMap(t, n, r, "_oldKeyGetter"), this._initIndexMap(e, i, o, "_newKeyGetter");
    for (var a = 0; a < r.length; a++) {
      var s = r[a],
        l = n[s],
        u = i[s],
        h = kv(l),
        c = kv(u);
      if (1 < h && 1 === c) this._updateManyToOne && this._updateManyToOne(u, l), i[s] = null;
      else if (1 === h && 1 < c) this._updateOneToMany && this._updateOneToMany(u, l), i[s] = null;
      else if (1 === h && 1 === c) this._update && this._update(u, l), i[s] = null;
      else if (1 < h && 1 < c) this._updateManyToMany && this._updateManyToMany(u, l), i[s] = null;
      else if (1 < h)
        for (var p = 0; p < h; p++) this._remove && this._remove(l[p]);
      else this._remove && this._remove(l)
    }
    this._performRestAdd(o, i)
  }, Lv.prototype._performRestAdd = function(t, e) {
    for (var n = 0; n < t.length; n++) {
      var i = t[n],
        r = e[i],
        o = kv(r);
      if (1 < o)
        for (var a = 0; a < o; a++) this._add && this._add(r[a]);
      else 1 === o && this._add && this._add(r);
      e[i] = null
    }
  }, Lv.prototype._initIndexMap = function(t, e, n, i) {
    for (var r = this._diffModeMultiple, o = 0; o < t.length; o++) {
      var a, s, l = "_ec_" + this[i](t[o], o);
      r || (n[o] = l), e && (0 === (s = kv(a = e[l])) ? (e[l] = o, r && n.push(l)) : 1 === s ? e[l] = [a, o] : a.push(o))
    }
  };
  var Av = Lv;

  function Lv(t, e, n, i, r, o) {
    this._old = t, this._new = e, this._oldKeyGetter = n || Dv, this._newKeyGetter = i || Dv, this.context = r, this._diffModeMultiple = "multiple" === o
  }
  Ov.prototype.get = function() {
    return {
      fullDimensions: this._getFullDimensionNames(),
      encode: this._encode
    }
  }, Ov.prototype._getFullDimensionNames = function() {
    return this._cachedDimNames || (this._cachedDimNames = this._schema ? this._schema.makeOutputDimensionNames() : []), this._cachedDimNames
  };
  var Pv = Ov;

  function Ov(t, e) {
    this._encode = t, this._schema = e
  }

  function Rv(t, e) {
    return t.hasOwnProperty(e) || (t[e] = []), t[e]
  }
  var Nv = function(t) {
      this.otherDims = {}, null != t && k(this, t)
    },
    Ev = So(),
    zv = {
      float: "f",
      int: "i",
      ordinal: "o",
      number: "n",
      time: "t"
    },
    Bv = (Fv.prototype.isDimensionOmitted = function() {
      return this._dimOmitted
    }, Fv.prototype._updateDimOmitted = function(t) {
      (this._dimOmitted = t) && !this._dimNameMap && (this._dimNameMap = Wv(this.source))
    }, Fv.prototype.getSourceDimensionIndex = function(t) {
      return nt(this._dimNameMap.get(t), -1)
    }, Fv.prototype.getSourceDimension = function(t) {
      var e = this.source.dimensionsDefine;
      if (e) return e[t]
    }, Fv.prototype.makeStoreSchema = function() {
      for (var t = this._fullDimCount, e = Hd(this.source), n = !(30 < t), i = "", r = [], o = 0, a = 0; o < t; o++) {
        var s, l = void 0,
          u = void 0,
          h = void 0,
          c = this.dimensions[a];
        c && c.storeDimIndex === o ? (l = e ? c.name : null, u = c.type, h = c.ordinalMeta, a++) : (s = this.getSourceDimension(o)) && (l = e ? s.name : null, u = s.type), r.push({
          property: l,
          type: u,
          ordinalMeta: h
        }), !e || null == l || c && c.isCalculationCoord || (i += n ? l.replace(/\`/g, "`1").replace(/\$/g, "`2") : l), i = i + "$" + (zv[u] || "f"), h && (i += h.uid), i += "$"
      }
      var p = this.source;
      return {
        dimensions: r,
        hash: [p.seriesLayoutBy, p.startIndex, i].join("$$")
      }
    }, Fv.prototype.makeOutputDimensionNames = function() {
      for (var t = [], e = 0, n = 0; e < this._fullDimCount; e++) {
        var i = void 0,
          r = this.dimensions[n];
        r && r.storeDimIndex === e ? (r.isCalculationCoord || (i = r.name), n++) : (r = this.getSourceDimension(e)) && (i = r.name), t.push(i)
      }
      return t
    }, Fv.prototype.appendCalculationDimension = function(t) {
      this.dimensions.push(t), t.isCalculationCoord = !0, this._fullDimCount++, this._updateDimOmitted(!0)
    }, Fv);

  function Fv(t) {
    this.dimensions = t.dimensions, this._dimOmitted = t.dimensionOmitted, this.source = t.source, this._fullDimCount = t.fullDimensionCount, this._updateDimOmitted(t.dimensionOmitted)
  }

  function Vv(t) {
    return t instanceof Bv
  }

  function Hv(t) {
    for (var e = yt(), n = 0; n < (t || []).length; n++) {
      var i;
      null != (i = q(i = t[n]) ? i.name : i) && null == e.get(i) && e.set(i, n)
    }
    return e
  }

  function Wv(t) {
    var e = Ev(t);
    return e.dimNameMap || (e.dimNameMap = Hv(t.dimensionsDefine))
  }
  var Gv, Uv, Xv, Yv, qv, jv, Zv, Kv = q,
    $v = E,
    Qv = "undefined" == typeof Int32Array ? Array : Int32Array,
    Jv = ["hasItemOption", "_nameList", "_idList", "_invertedIndicesMap", "_dimSummary", "userOutput", "_rawData", "_dimValueGetter", "_nameDimIdx", "_idDimIdx", "_nameRepeatCount"],
    t_ = ["_approximateExtent"],
    e_ = (n_.prototype.getDimension = function(t) {
      var e;
      return null == (e = this._recognizeDimIndex(t)) ? t : (e = t, this._dimOmitted ? null != (t = this._dimIdxToName.get(e)) ? t : (t = this._schema.getSourceDimension(e)) ? t.name : void 0 : this.dimensions[e])
    }, n_.prototype.getDimensionIndex = function(t) {
      var e = this._recognizeDimIndex(t);
      return null != e ? e : null == t ? -1 : (e = this._getDimInfo(t)) ? e.storeDimIndex : this._dimOmitted ? this._schema.getSourceDimensionIndex(t) : -1
    }, n_.prototype._recognizeDimIndex = function(t) {
      if (Y(t) || null != t && !isNaN(t) && !this._getDimInfo(t) && (!this._dimOmitted || this._schema.getSourceDimensionIndex(t) < 0)) return +t
    }, n_.prototype._getStoreDimIndex = function(t) {
      return this.getDimensionIndex(t)
    }, n_.prototype.getDimensionInfo = function(t) {
      return this._getDimInfo(this.getDimension(t))
    }, n_.prototype._initGetDimensionInfo = function(t) {
      var e = this._dimInfos;
      this._getDimInfo = t ? function(t) {
        return e.hasOwnProperty(t) ? e[t] : void 0
      } : function(t) {
        return e[t]
      }
    }, n_.prototype.getDimensionsOnCoord = function() {
      return this._dimSummary.dataDimsOnCoord.slice()
    }, n_.prototype.mapDimension = function(t, e) {
      var n = this._dimSummary;
      return null == e ? n.encodeFirstDimNotExtra[t] : (n = n.encode[t]) ? n[e] : null
    }, n_.prototype.mapDimensionsAll = function(t) {
      return (this._dimSummary.encode[t] || []).slice()
    }, n_.prototype.getStore = function() {
      return this._store
    }, n_.prototype.initData = function(t, e, n) {
      var i, r, o = this;
      (i = t instanceof qf ? t : i) || (r = this.dimensions, t = Nd(t) || R(t) ? new Xd(t, r.length) : t, i = new qf, r = $v(r, (function(t) {
        return {
          type: o._dimInfos[t].type,
          property: t
        }
      })), i.initData(t, r, n)), this._store = i, this._nameList = (e || []).slice(), this._idList = [], this._nameRepeatCount = {}, this._doInit(0, i.count()), this._dimSummary = function(t, e) {
        var n, i = {},
          r = i.encode = {},
          o = yt(),
          a = [],
          s = [],
          l = {},
          u = (N(t.dimensions, (function(e) {
            var n, i, u = t.getDimensionInfo(e),
              h = u.coordDim;
            h && (n = u.coordDimIndex, Rv(r, h)[n] = e, u.isExtraCoord || (o.set(h, 1), "ordinal" !== (i = u.type) && "time" !== i && (a[0] = e), Rv(l, h)[n] = t.getDimensionIndex(u.name)), u.defaultTooltip) && s.push(e), Dp.each((function(t, e) {
              var n = Rv(r, e);
              null != (e = u.otherDims[e]) && !1 !== e && (n[e] = u.name)
            }))
          })), []),
          h = {};
        return (n = ((n = (o.each((function(t, e) {
          var n = r[e];
          h[e] = n[0], u = u.concat(n)
        })), i.dataDimsOnCoord = u, i.dataDimIndicesOnCoord = E(u, (function(e) {
          return t.getDimensionInfo(e).storeDimIndex
        })), i.encodeFirstDimNotExtra = h, r.label)) && n.length && (a = n.slice()), r.tooltip)) && n.length ? s = n.slice() : s.length || (s = a.slice()), r.defaultedLabel = a, r.defaultedTooltip = s, i.userOutput = new Pv(l, e), i
      }(this, this._schema), this.userOutput = this._dimSummary.userOutput
    }, n_.prototype.appendData = function(t) {
      t = this._store.appendData(t), this._doInit(t[0], t[1])
    }, n_.prototype.appendValues = function(t, e) {
      var n = (t = this._store.appendValues(t, e.length)).start,
        i = t.end,
        r = this._shouldMakeIdFromName();
      if (this._updateOrdinalMeta(), e)
        for (var o = n; o < i; o++) this._nameList[o] = e[o - n], r && Zv(this, o)
    }, n_.prototype._updateOrdinalMeta = function() {
      for (var t = this._store, e = this.dimensions, n = 0; n < e.length; n++) {
        var i = this._dimInfos[e[n]];
        i.ordinalMeta && t.collectOrdinalMeta(i.storeDimIndex, i.ordinalMeta)
      }
    }, n_.prototype._shouldMakeIdFromName = function() {
      var t = this._store.getProvider();
      return null == this._idDimIdx && t.getSource().sourceFormat !== Rp && !t.fillStorage
    }, n_.prototype._doInit = function(t, e) {
      if (!(e <= t)) {
        var n = this._store.getProvider(),
          i = (this._updateOrdinalMeta(), this._nameList),
          r = this._idList;
        if (n.getSource().sourceFormat === Ap && !n.pure)
          for (var o = [], a = t; a < e; a++) {
            var s, l = n.getItem(a, o);
            this.hasItemOption || !q(s = l) || s instanceof Array || (this.hasItemOption = !0), l && (s = l.name, null == i[a] && null != s && (i[a] = _o(s, null)), l = l.id, null == r[a]) && null != l && (r[a] = _o(l, null))
          }
        if (this._shouldMakeIdFromName())
          for (a = t; a < e; a++) Zv(this, a);
        Gv(this)
      }
    }, n_.prototype.getApproximateExtent = function(t) {
      return this._approximateExtent[t] || this._store.getDataExtent(this._getStoreDimIndex(t))
    }, n_.prototype.setApproximateExtent = function(t, e) {
      e = this.getDimension(e), this._approximateExtent[e] = t.slice()
    }, n_.prototype.getCalculationInfo = function(t) {
      return this._calculationInfo[t]
    }, n_.prototype.setCalculationInfo = function(t, e) {
      Kv(t) ? k(this._calculationInfo, t) : this._calculationInfo[t] = e
    }, n_.prototype.getName = function(t) {
      t = this.getRawIndex(t);
      var e = this._nameList[t];
      return null == (e = null == e && null != this._nameDimIdx ? Xv(this, this._nameDimIdx, t) : e) ? "" : e
    }, n_.prototype._getCategory = function(t, e) {
      return e = this._store.get(t, e), (t = this._store.getOrdinalMeta(t)) ? t.categories[e] : e
    }, n_.prototype.getId = function(t) {
      return Uv(this, this.getRawIndex(t))
    }, n_.prototype.count = function() {
      return this._store.count()
    }, n_.prototype.get = function(t, e) {
      var n = this._store;
      if (t = this._dimInfos[t]) return n.get(t.storeDimIndex, e)
    }, n_.prototype.getByRawIndex = function(t, e) {
      var n = this._store;
      if (t = this._dimInfos[t]) return n.getByRawIndex(t.storeDimIndex, e)
    }, n_.prototype.getIndices = function() {
      return this._store.getIndices()
    }, n_.prototype.getDataExtent = function(t) {
      return this._store.getDataExtent(this._getStoreDimIndex(t))
    }, n_.prototype.getSum = function(t) {
      return this._store.getSum(this._getStoreDimIndex(t))
    }, n_.prototype.getMedian = function(t) {
      return this._store.getMedian(this._getStoreDimIndex(t))
    }, n_.prototype.getValues = function(t, e) {
      var n = this,
        i = this._store;
      return W(t) ? i.getValues($v(t, (function(t) {
        return n._getStoreDimIndex(t)
      })), e) : i.getValues(t)
    }, n_.prototype.hasValue = function(t) {
      for (var e = this._dimSummary.dataDimIndicesOnCoord, n = 0, i = e.length; n < i; n++)
        if (isNaN(this._store.get(e[n], t))) return !1;
      return !0
    }, n_.prototype.indexOfName = function(t) {
      for (var e = 0, n = this._store.count(); e < n; e++)
        if (this.getName(e) === t) return e;
      return -1
    }, n_.prototype.getRawIndex = function(t) {
      return this._store.getRawIndex(t)
    }, n_.prototype.indexOfRawIndex = function(t) {
      return this._store.indexOfRawIndex(t)
    }, n_.prototype.rawIndexOf = function(t, e) {
      return null == (t = (t && this._invertedIndicesMap[t])[e]) || isNaN(t) ? -1 : t
    }, n_.prototype.indicesOfNearest = function(t, e, n) {
      return this._store.indicesOfNearest(this._getStoreDimIndex(t), e, n)
    }, n_.prototype.each = function(t, e, n) {
      G(t) && (n = e, e = t, t = []), n = n || this, t = $v(Yv(t), this._getStoreDimIndex, this), this._store.each(t, n ? V(e, n) : e)
    }, n_.prototype.filterSelf = function(t, e, n) {
      return G(t) && (n = e, e = t, t = []), n = n || this, t = $v(Yv(t), this._getStoreDimIndex, this), this._store = this._store.filter(t, n ? V(e, n) : e), this
    }, n_.prototype.selectRange = function(t) {
      var e = this,
        n = {};
      return N(F(t), (function(i) {
        var r = e._getStoreDimIndex(i);
        n[r] = t[i]
      })), this._store = this._store.selectRange(n), this
    }, n_.prototype.mapArray = function(t, e, n) {
      G(t) && (n = e, e = t, t = []);
      var i = [];
      return this.each(t, (function() {
        i.push(e && e.apply(this, arguments))
      }), n = n || this), i
    }, n_.prototype.map = function(t, e, n, i) {
      return n = n || i || this, i = $v(Yv(t), this._getStoreDimIndex, this), (t = jv(this))._store = this._store.map(i, n ? V(e, n) : e), t
    }, n_.prototype.modify = function(t, e, n, i) {
      n = n || i || this, i = $v(Yv(t), this._getStoreDimIndex, this), this._store.modify(i, n ? V(e, n) : e)
    }, n_.prototype.downSample = function(t, e, n, i) {
      var r = jv(this);
      return r._store = this._store.downSample(this._getStoreDimIndex(t), e, n, i), r
    }, n_.prototype.lttbDownSample = function(t, e) {
      var n = jv(this);
      return n._store = this._store.lttbDownSample(this._getStoreDimIndex(t), e), n
    }, n_.prototype.getRawDataItem = function(t) {
      return this._store.getRawDataItem(t)
    }, n_.prototype.getItemModel = function(t) {
      var e = this.hostModel;
      t = this.getRawDataItem(t);
      return new Mc(t, e, e && e.ecModel)
    }, n_.prototype.diff = function(t) {
      var e = this;
      return new Av(t ? t.getStore().getIndices() : [], this.getStore().getIndices(), (function(e) {
        return Uv(t, e)
      }), (function(t) {
        return Uv(e, t)
      }))
    }, n_.prototype.getVisual = function(t) {
      var e = this._visual;
      return e && e[t]
    }, n_.prototype.setVisual = function(t, e) {
      this._visual = this._visual || {}, Kv(t) ? k(this._visual, t) : this._visual[t] = e
    }, n_.prototype.getItemVisual = function(t, e) {
      return null == (t = (t = this._itemVisuals[t]) && t[e]) ? this.getVisual(e) : t
    }, n_.prototype.hasItemVisual = function() {
      return 0 < this._itemVisuals.length
    }, n_.prototype.ensureUniqueItemVisual = function(t, e) {
      var n, i = (n = this._itemVisuals)[t];
      return null == (n = (i = i || (n[t] = {}))[e]) && (W(n = this.getVisual(e)) ? n = n.slice() : Kv(n) && (n = k({}, n)), i[e] = n), n
    }, n_.prototype.setItemVisual = function(t, e, n) {
      var i = this._itemVisuals[t] || {};
      this._itemVisuals[t] = i, Kv(e) ? k(i, e) : i[e] = n
    }, n_.prototype.clearAllVisual = function() {
      this._visual = {}, this._itemVisuals = []
    }, n_.prototype.setLayout = function(t, e) {
      Kv(t) ? k(this._layout, t) : this._layout[t] = e
    }, n_.prototype.getLayout = function(t) {
      return this._layout[t]
    }, n_.prototype.getItemLayout = function(t) {
      return this._itemLayouts[t]
    }, n_.prototype.setItemLayout = function(t, e, n) {
      this._itemLayouts[t] = n ? k(this._itemLayouts[t] || {}, e) : e
    }, n_.prototype.clearItemLayouts = function() {
      this._itemLayouts.length = 0
    }, n_.prototype.setItemGraphicEl = function(t, e) {
      Gs(this.hostModel && this.hostModel.seriesIndex, this.dataType, t, e), this._graphicEls[t] = e
    }, n_.prototype.getItemGraphicEl = function(t) {
      return this._graphicEls[t]
    }, n_.prototype.eachItemGraphicEl = function(t, e) {
      N(this._graphicEls, (function(n, i) {
        n && t && t.call(e, n, i)
      }))
    }, n_.prototype.cloneShallow = function(t) {
      return t = t || new n_(this._schema || $v(this.dimensions, this._getDimInfo, this), this.hostModel), qv(t, this), t._store = this._store, t
    }, n_.prototype.wrapMethod = function(t, e) {
      var n = this[t];
      G(n) && (this.__wrappedMethods = this.__wrappedMethods || [], this.__wrappedMethods.push(t), this[t] = function() {
        var t = n.apply(this, arguments);
        return e.apply(this, [t].concat(rt(arguments)))
      })
    }, n_.internalField = (Gv = function(t) {
      var e = t._invertedIndicesMap;
      N(e, (function(n, i) {
        var r = t._dimInfos[i],
          o = r.ordinalMeta,
          a = t._store;
        if (o) {
          n = e[i] = new Qv(o.categories.length);
          for (var s = 0; s < n.length; s++) n[s] = -1;
          for (s = 0; s < a.count(); s++) n[a.get(r.storeDimIndex, s)] = s
        }
      }))
    }, Xv = function(t, e, n) {
      return _o(t._getCategory(e, n), null)
    }, Uv = function(t, e) {
      var n = t._idList[e];
      return null == (n = null == n && null != t._idDimIdx ? Xv(t, t._idDimIdx, e) : n) ? "e\0\0" + e : n
    }, Yv = function(t) {
      return W(t) ? t : null != t ? [t] : []
    }, jv = function(t) {
      var e = new n_(t._schema || $v(t.dimensions, t._getDimInfo, t), t.hostModel);
      return qv(e, t), e
    }, qv = function(t, e) {
      N(Jv.concat(e.__wrappedMethods || []), (function(n) {
        e.hasOwnProperty(n) && (t[n] = e[n])
      })), t.__wrappedMethods = e.__wrappedMethods, N(t_, (function(n) {
        t[n] = I(e[n])
      })), t._calculationInfo = k({}, e._calculationInfo)
    }, void(Zv = function(t, e) {
      var n = t._nameList,
        i = t._idList,
        r = t._nameDimIdx,
        o = t._idDimIdx,
        a = n[e],
        s = i[e];
      null == a && null != r && (n[e] = a = Xv(t, r, e)), null == s && null != o && (i[e] = s = Xv(t, o, e)), null == s && null != a && (s = a, 1 < (r = (n = t._nameRepeatCount)[a] = (n[a] || 0) + 1) && (s += "__ec__" + r), i[e] = s)
    })), n_);

  function n_(t, e) {
    this.type = "list", this._dimOmitted = !1, this._nameList = [], this._idList = [], this._visual = {}, this._layout = {}, this._itemVisuals = [], this._itemLayouts = [], this._graphicEls = [], this._approximateExtent = {}, this._calculationInfo = {}, this.hasItemOption = !1, this.TRANSFERABLE_METHODS = ["cloneShallow", "downSample", "lttbDownSample", "map"], this.CHANGABLE_METHODS = ["filterSelf", "selectRange"];
    for (var n, i, r = !(this.DOWNSAMPLE_METHODS = ["downSample", "lttbDownSample"]), o = (Vv(t) ? (n = t.dimensions, this._dimOmitted = t.isDimensionOmitted(), this._schema = t) : (r = !0, n = t), n = n || ["x", "y"], {}), a = [], s = {}, l = !1, u = {}, h = 0; h < n.length; h++) {
      var c, p = (c = U(c = n[h]) ? new Nv({
          name: c
        }) : c instanceof Nv ? c : new Nv(c)).name,
        d = (c.type = c.type || "float", c.coordDim || (c.coordDim = p, c.coordDimIndex = 0), c.otherDims = c.otherDims || {});
      a.push(p), null != u[p] && (l = !0), (o[p] = c).createInvertedIndices && (s[p] = []), 0 === d.itemName && (this._nameDimIdx = h), 0 === d.itemId && (this._idDimIdx = h), r && (c.storeDimIndex = h)
    }
    this.dimensions = a, this._dimInfos = o, this._initGetDimensionInfo(l), this.hostModel = e, this._invertedIndicesMap = s, this._dimOmitted && (i = this._dimIdxToName = yt(), N(a, (function(t) {
      i.set(o[t].storeDimIndex, t)
    })))
  }

  function i_(t, e) {
    Nd(t) || (t = zd(t));
    for (var n, i, r = (e = e || {}).coordDimensions || [], o = e.dimensionsDefine || t.dimensionsDefine || [], a = yt(), s = [], l = (u = t, n = r, p = e.dimensionsCount, i = Math.max(u.dimensionsDetectedCount || 1, n.length, o.length, p || 0), N(n, (function(t) {
        q(t) && (t = t.dimsDef) && (i = Math.max(i, t.length))
      })), i), u = e.canOmitUnusedDimensions && 30 < l, h = o === t.dimensionsDefine, c = h ? Wv(t) : Hv(o), p = e.encodeDefine, d = yt(p = !p && e.encodeDefaulter ? e.encodeDefaulter(t, l) : p), f = new Gf(l), g = 0; g < f.length; g++) f[g] = -1;

    function y(t) {
      var e, n, i, r = f[t];
      return r < 0 ? (e = q(e = o[t]) ? e : {
        name: e
      }, n = new Nv, null != (i = e.name) && null != c.get(i) && (n.name = n.displayName = i), null != e.type && (n.type = e.type), null != e.displayName && (n.displayName = e.displayName), f[t] = s.length, n.storeDimIndex = t, s.push(n), n) : s[r]
    }
    if (!u)
      for (g = 0; g < l; g++) y(g);
    d.each((function(t, e) {
      var n;
      1 === (t = po(t).slice()).length && !U(t[0]) && t[0] < 0 ? d.set(e, !1) : (n = d.set(e, []), N(t, (function(t, i) {
        null != (t = U(t) ? c.get(t) : t) && t < l && v(y(n[i] = t), e, i)
      })))
    }));
    var m = 0;

    function v(t, e, n) {
      null != Dp.get(e) ? t.otherDims[e] = n : (t.coordDim = e, t.coordDimIndex = n, a.set(e, !0))
    }
    N(r, (function(t) {
      U(t) ? (r = t, i = {}) : (r = (i = t).name, t = i.ordinalMeta, i.ordinalMeta = null, (i = k({}, i)).ordinalMeta = t, e = i.dimsDef, n = i.otherDims, i.name = i.coordDim = i.coordDimIndex = i.dimsDef = i.otherDims = null);
      var e, n, i, r, o = d.get(r);
      if (!1 !== o) {
        if (!(o = po(o)).length)
          for (var a = 0; a < (e && e.length || 1); a++) {
            for (; m < l && null != y(m).coordDim;) m++;
            m < l && o.push(m++)
          }
        N(o, (function(t, o) {
          t = y(t), h && null != i.type && (t.type = i.type), v(D(t, i), r, o), null == t.name && e && (q(o = e[o]) || (o = {
            name: o
          }), t.name = t.displayName = o.name, t.defaultTooltip = o.defaultTooltip), n && D(t.otherDims, n)
        }))
      }
    }));
    var _ = e.generateCoord,
      x = null != (w = e.generateCoordCount),
      w = _ ? w || 1 : 0,
      b = _ || "value";

    function S(t) {
      null == t.name && (t.name = t.coordDim)
    }
    if (u) N(s, (function(t) {
      S(t)
    })), s.sort((function(t, e) {
      return t.storeDimIndex - e.storeDimIndex
    }));
    else
      for (var M = 0; M < l; M++) {
        var T = y(M);
        null == T.coordDim && (T.coordDim = function(t, e, n) {
          if (n || e.hasKey(t)) {
            for (var i = 0; e.hasKey(t + i);) i++;
            t += i
          }
          return e.set(t, !0), t
        }(b, a, x), T.coordDimIndex = 0, (!_ || w <= 0) && (T.isExtraCoord = !0), w--), S(T), null != T.type || Up(t, M) !== Bp && (!T.isExtraCoord || null == T.otherDims.itemName && null == T.otherDims.seriesName) || (T.type = "ordinal")
      }
    for (var I = s, C = yt(), A = 0; A < I.length; A++) {
      var L = I[A],
        P = L.name,
        O = C.get(P) || 0;
      0 < O && (L.name = P + (O - 1)), O++, C.set(P, O)
    }
    return new Bv({
      source: t,
      dimensions: s,
      fullDimensionCount: l,
      dimensionOmitted: u
    })
  }
  var r_ = function(t) {
      this.coordSysDims = [], this.axisMap = yt(), this.categoryAxisMap = yt(), this.coordSysName = t
    },
    o_ = {
      cartesian2d: function(t, e, n, i) {
        var r = t.getReferringComponents("xAxis", Co).models[0];
        t = t.getReferringComponents("yAxis", Co).models[0];
        e.coordSysDims = ["x", "y"], n.set("x", r), n.set("y", t), a_(r) && (i.set("x", r), e.firstCategoryDimIndex = 0), a_(t) && (i.set("y", t), null == e.firstCategoryDimIndex) && (e.firstCategoryDimIndex = 1)
      },
      singleAxis: function(t, e, n, i) {
        t = t.getReferringComponents("singleAxis", Co).models[0], e.coordSysDims = ["single"], n.set("single", t), a_(t) && (i.set("single", t), e.firstCategoryDimIndex = 0)
      },
      polar: function(t, e, n, i) {
        var r = (t = t.getReferringComponents("polar", Co).models[0]).findAxisModel("radiusAxis");
        t = t.findAxisModel("angleAxis");
        e.coordSysDims = ["radius", "angle"], n.set("radius", r), n.set("angle", t), a_(r) && (i.set("radius", r), e.firstCategoryDimIndex = 0), a_(t) && (i.set("angle", t), null == e.firstCategoryDimIndex) && (e.firstCategoryDimIndex = 1)
      },
      geo: function(t, e, n, i) {
        e.coordSysDims = ["lng", "lat"]
      },
      parallel: function(t, e, n, i) {
        var r = t.ecModel,
          o = (t = r.getComponent("parallel", t.get("parallelIndex")), e.coordSysDims = t.dimensions.slice());
        N(t.parallelAxisIndex, (function(t, a) {
          t = r.getComponent("parallelAxis", t);
          var s = o[a];
          n.set(s, t), a_(t) && (i.set(s, t), null == e.firstCategoryDimIndex) && (e.firstCategoryDimIndex = a)
        }))
      }
    };

  function a_(t) {
    return "category" === t.get("type")
  }

  function s_(t, e, n) {
    var i, r, o, a, s, l, u, h, c, p = (n = n || {}).byIndex,
      d = n.stackedCoordDimension,
      f = (Vv(e.schema) ? (r = e.schema, i = r.dimensions, o = e.store) : i = e, !(!t || !t.get("stack")));
    return N(i, (function(t, e) {
      U(t) && (i[e] = t = {
        name: t
      }), f && !t.isExtraCoord && (p || a || !t.ordinalMeta || (a = t), s || "ordinal" === t.type || "time" === t.type || d && d !== t.coordDim || (s = t))
    })), !s || p || a || (p = !0), s && (l = "__\0ecstackresult_" + t.id, u = "__\0ecstackedover_" + t.id, a && (a.createInvertedIndices = !0), h = s.coordDim, n = s.type, c = 0, N(i, (function(t) {
      t.coordDim === h && c++
    })), e = {
      name: l,
      coordDim: h,
      coordDimIndex: c,
      type: n,
      isExtraCoord: !0,
      isCalculationCoord: !0,
      storeDimIndex: i.length
    }, t = {
      name: u,
      coordDim: u,
      coordDimIndex: c + 1,
      type: n,
      isExtraCoord: !0,
      isCalculationCoord: !0,
      storeDimIndex: i.length + 1
    }, r ? (o && (e.storeDimIndex = o.ensureCalculationDimension(u, n), t.storeDimIndex = o.ensureCalculationDimension(l, n)), r.appendCalculationDimension(e), r.appendCalculationDimension(t)) : (i.push(e), i.push(t))), {
      stackedDimension: s && s.name,
      stackedByDimension: a && a.name,
      isStackedByIndex: p,
      stackedOverDimension: u,
      stackResultDimension: l
    }
  }

  function l_(t, e) {
    return !!e && e === t.getCalculationInfo("stackedDimension")
  }

  function u_(t, e) {
    return l_(t, e) ? t.getCalculationInfo("stackResultDimension") : e
  }

  function h_(t, e, n) {
    n = n || {};
    var i, r, o, a, s, l, u = e.getSourceManager(),
      h = !1,
      c = (t = (t ? (h = !0, i = zd(t)) : h = (i = u.getSource()).sourceFormat === Ap, function(t) {
        var e = t.get("coordinateSystem"),
          n = new r_(e);
        if (e = o_[e]) return e(t, n, n.axisMap, n.categoryAxisMap), n
      }(e)), r = t, c = (c = e).get("coordinateSystem"), c = ld.get(c), p = (p = r && r.coordSysDims ? E(r.coordSysDims, (function(t) {
        var e = {
          name: t
        };
        return (t = r.axisMap.get(t)) && (t = t.get("type"), e.type = "category" === (t = t) ? "ordinal" : "time" === t ? "time" : "float"), e
      })) : p) || c && (c.getDimensionsInfo ? c.getDimensionsInfo() : c.dimensions.slice()) || ["x", "y"]),
      p = G(p = n.useEncodeDefaulter) ? p : p ? H(Wp, c, e) : null,
      d = (c = (p = i_(i, c = {
        coordDimensions: c,
        generateCoord: n.generateCoord,
        encodeDefine: e.getEncode(),
        encodeDefaulter: p,
        canOmitUnusedDimensions: !h
      })).dimensions, o = n.createInvertedIndices, (a = t) && N(c, (function(t, e) {
        var n = t.coordDim;
        (n = a.categoryAxisMap.get(n)) && (null == s && (s = e), t.ordinalMeta = n.getOrdinalMeta(), o) && (t.createInvertedIndices = !0), null != t.otherDims.itemName && (l = !0)
      })), l || null == s || (c[s].otherDims.itemName = 0), s);
    t = s_(e, {
      schema: p,
      store: n = h ? null : u.getSharedDataStore(p)
    }), (c = new e_(p, e)).setCalculationInfo(t), p = null == d || (u = i).sourceFormat !== Ap || W(yo(function(t) {
      for (var e = 0; e < t.length && null == t[e];) e++;
      return t[e]
    }(u.data || []))) ? null : function(t, e, n, i) {
      return i === d ? n : this.defaultDimValueGetter(t, e, n, i)
    };
    return c.hasItemOption = !1, c.initData(h ? i : n, null, p), c
  }
  p_.prototype.getSetting = function(t) {
    return this._setting[t]
  }, p_.prototype.unionExtent = function(t) {
    var e = this._extent;
    t[0] < e[0] && (e[0] = t[0]), t[1] > e[1] && (e[1] = t[1])
  }, p_.prototype.unionExtentFromData = function(t, e) {
    this.unionExtent(t.getApproximateExtent(e))
  }, p_.prototype.getExtent = function() {
    return this._extent.slice()
  }, p_.prototype.setExtent = function(t, e) {
    var n = this._extent;
    isNaN(t) || (n[0] = t), isNaN(e) || (n[1] = e)
  }, p_.prototype.isInExtentRange = function(t) {
    return this._extent[0] <= t && this._extent[1] >= t
  }, p_.prototype.isBlank = function() {
    return this._isBlank
  }, p_.prototype.setBlank = function(t) {
    this._isBlank = t
  };
  var c_ = p_;

  function p_(t) {
    this._setting = t || {}, this._extent = [1 / 0, -1 / 0]
  }
  Fo(c_);
  var d_ = 0,
    f_ = (g_.createByAxisModel = function(t) {
      var e;
      return new g_({
        categories: e = (e = (t = t.option).data) && E(e, y_),
        needCollect: !e,
        deduplication: !1 !== t.dedplication
      })
    }, g_.prototype.getOrdinal = function(t) {
      return this._getOrCreateMap().get(t)
    }, g_.prototype.parseAndCollect = function(t) {
      var e, n, i = this._needCollect;
      return U(t) || i ? (i && !this._deduplication ? (n = this.categories.length, this.categories[n] = t) : null == (n = (e = this._getOrCreateMap()).get(t)) && (i ? (n = this.categories.length, this.categories[n] = t, e.set(t, n)) : n = NaN), n) : t
    }, g_.prototype._getOrCreateMap = function() {
      return this._map || (this._map = yt(this.categories))
    }, g_);

  function g_(t) {
    this.categories = t.categories || [], this._needCollect = t.needCollect, this._deduplication = t.deduplication, this.uid = ++d_
  }

  function y_(t) {
    return q(t) && null != t.value ? t.value : t + ""
  }

  function m_(t) {
    return "interval" === t.type || "log" === t.type
  }

  function v_(t) {
    var e = Math.pow(10, io(t));
    return (t = t / e) ? 2 === t ? t = 3 : 3 === t ? t = 5 : t *= 2 : t = 1, jr(t * e)
  }

  function __(t) {
    return Zr(t) + 2
  }

  function x_(t, e, n) {
    t[e] = Math.max(Math.min(t[e], n[1]), n[0])
  }

  function w_(t, e) {
    return t >= e[0] && t <= e[1]
  }

  function b_(t, e) {
    return e[1] === e[0] ? .5 : (t - e[0]) / (e[1] - e[0])
  }

  function S_(t, e) {
    return t * (e[1] - e[0]) + e[0]
  }
  i(I_, M_ = c_), I_.prototype.parse = function(t) {
    return null == t ? NaN : U(t) ? this._ordinalMeta.getOrdinal(t) : Math.round(t)
  }, I_.prototype.contain = function(t) {
    return w_(t = this.parse(t), this._extent) && null != this._ordinalMeta.categories[t]
  }, I_.prototype.normalize = function(t) {
    return b_(t = this._getTickNumber(this.parse(t)), this._extent)
  }, I_.prototype.scale = function(t) {
    return t = Math.round(S_(t, this._extent)), this.getRawOrdinalNumber(t)
  }, I_.prototype.getTicks = function() {
    for (var t = [], e = this._extent, n = e[0]; n <= e[1];) t.push({
      value: n
    }), n++;
    return t
  }, I_.prototype.getMinorTicks = function(t) {}, I_.prototype.setSortInfo = function(t) {
    if (null == t) this._ordinalNumbersByTick = this._ticksByOrdinalNumber = null;
    else {
      for (var e = t.ordinalNumbers, n = this._ordinalNumbersByTick = [], i = this._ticksByOrdinalNumber = [], r = 0, o = this._ordinalMeta.categories.length, a = Math.min(o, e.length); r < a; ++r) {
        var s = e[r];
        i[n[r] = s] = r
      }
      for (var l = 0; r < o; ++r) {
        for (; null != i[l];) l++;
        n.push(l), i[l] = r
      }
    }
  }, I_.prototype._getTickNumber = function(t) {
    var e = this._ticksByOrdinalNumber;
    return e && 0 <= t && t < e.length ? e[t] : t
  }, I_.prototype.getRawOrdinalNumber = function(t) {
    var e = this._ordinalNumbersByTick;
    return e && 0 <= t && t < e.length ? e[t] : t
  }, I_.prototype.getLabel = function(t) {
    if (!this.isBlank()) return t = this.getRawOrdinalNumber(t.value), null == (t = this._ordinalMeta.categories[t]) ? "" : t + ""
  }, I_.prototype.count = function() {
    return this._extent[1] - this._extent[0] + 1
  }, I_.prototype.unionExtentFromData = function(t, e) {
    this.unionExtent(t.getApproximateExtent(e))
  }, I_.prototype.isInExtentRange = function(t) {
    return t = this._getTickNumber(t), this._extent[0] <= t && this._extent[1] >= t
  }, I_.prototype.getOrdinalMeta = function() {
    return this._ordinalMeta
  }, I_.prototype.calcNiceTicks = function() {}, I_.prototype.calcNiceExtent = function() {}, I_.type = "ordinal";
  var M_, T_ = I_;

  function I_(t) {
    var e = ((t = M_.call(this, t) || this).type = "ordinal", t.getSetting("ordinalMeta"));
    return W(e = e || new f_({})) && (e = new f_({
      categories: E(e, (function(t) {
        return q(t) ? t.value : t
      }))
    })), t._ordinalMeta = e, t._extent = t.getSetting("extent") || [0, e.categories.length - 1], t
  }
  c_.registerClass(T_);
  var C_, k_ = jr,
    D_ = (i(A_, C_ = c_), A_.prototype.parse = function(t) {
      return t
    }, A_.prototype.contain = function(t) {
      return w_(t, this._extent)
    }, A_.prototype.normalize = function(t) {
      return b_(t, this._extent)
    }, A_.prototype.scale = function(t) {
      return S_(t, this._extent)
    }, A_.prototype.setExtent = function(t, e) {
      var n = this._extent;
      isNaN(t) || (n[0] = parseFloat(t)), isNaN(e) || (n[1] = parseFloat(e))
    }, A_.prototype.unionExtent = function(t) {
      var e = this._extent;
      t[0] < e[0] && (e[0] = t[0]), t[1] > e[1] && (e[1] = t[1]), this.setExtent(e[0], e[1])
    }, A_.prototype.getInterval = function() {
      return this._interval
    }, A_.prototype.setInterval = function(t) {
      this._interval = t, this._niceExtent = this._extent.slice(), this._intervalPrecision = __(t)
    }, A_.prototype.getTicks = function(t) {
      var e = this._interval,
        n = this._extent,
        i = this._niceExtent,
        r = this._intervalPrecision,
        o = [];
      if (e) {
        n[0] < i[0] && o.push(t ? {
          value: k_(i[0] - e, r)
        } : {
          value: n[0]
        });
        for (var a = i[0]; a <= i[1] && (o.push({
            value: a
          }), (a = k_(a + e, r)) !== o[o.length - 1].value);)
          if (1e4 < o.length) return [];
        var s = o.length ? o[o.length - 1].value : i[1];
        n[1] > s && o.push(t ? {
          value: k_(s + e, r)
        } : {
          value: n[1]
        })
      }
      return o
    }, A_.prototype.getMinorTicks = function(t) {
      for (var e = this.getTicks(!0), n = [], i = this.getExtent(), r = 1; r < e.length; r++) {
        for (var o = e[r], a = e[r - 1], s = 0, l = [], u = (o.value - a.value) / t; s < t - 1;) {
          var h = k_(a.value + (s + 1) * u);
          h > i[0] && h < i[1] && l.push(h), s++
        }
        n.push(l)
      }
      return n
    }, A_.prototype.getLabel = function(t, e) {
      return null == t ? "" : (null == (e = e && e.precision) ? e = Zr(t.value) || 0 : "auto" === e && (e = this._intervalPrecision), ip(k_(t.value, e, !0)))
    }, A_.prototype.calcNiceTicks = function(t, e, n) {
      t = t || 5;
      var i = this._extent,
        r = i[1] - i[0];
      isFinite(r) && (r < 0 && i.reverse(), r = function(t, e, n, i) {
        var r = {},
          o = t[1] - t[0];
        return o = r.interval = ro(o / e, !0), null != n && o < n && (o = r.interval = n), null != i && i < o && (o = r.interval = i), e = r.intervalPrecision = __(o), i = n = r.niceTickExtent = [jr(Math.ceil(t[0] / o) * o, e), jr(Math.floor(t[1] / o) * o, e)], o = t, isFinite(i[0]) || (i[0] = o[0]), isFinite(i[1]) || (i[1] = o[1]), x_(i, 0, o), x_(i, 1, o), i[0] > i[1] && (i[0] = i[1]), r
      }(i, t, e, n), this._intervalPrecision = r.intervalPrecision, this._interval = r.interval, this._niceExtent = r.niceTickExtent)
    }, A_.prototype.calcNiceExtent = function(t) {
      var e = this._extent,
        n = (e[0] === e[1] && (0 !== e[0] ? (n = Math.abs(e[0]), t.fixMax || (e[1] += n / 2), e[0] -= n / 2) : e[1] = 1), e[1] - e[0]);
      isFinite(n) || (e[0] = 0, e[1] = 1), this.calcNiceTicks(t.splitNumber, t.minInterval, t.maxInterval), n = this._interval;
      t.fixMin || (e[0] = k_(Math.floor(e[0] / n) * n)), t.fixMax || (e[1] = k_(Math.ceil(e[1] / n) * n))
    }, A_.prototype.setNiceExtent = function(t, e) {
      this._niceExtent = [t, e]
    }, A_.type = "interval", A_);

  function A_() {
    var t = null !== C_ && C_.apply(this, arguments) || this;
    return t.type = "interval", t._interval = 0, t._intervalPrecision = 2, t
  }
  c_.registerClass(D_);
  var L_ = "undefined" != typeof Float32Array,
    P_ = L_ ? Float32Array : Array;

  function O_(t) {
    return W(t) ? L_ ? new Float32Array(t) : t : new P_(t)
  }

  function R_(t) {
    return t.get("stack") || "__ec_stack_" + t.seriesIndex
  }

  function N_(t) {
    return t.dim + t.index
  }

  function E_(t, e) {
    var n = [];
    return e.eachSeriesByType(t, (function(t) {
      F_(t) && n.push(t)
    })), n
  }

  function z_(t) {
    var e, n, i = function(t) {
        var e, n = {},
          i = (N(t, (function(t) {
            var e = t.coordinateSystem.getBaseAxis();
            if ("time" === e.type || "value" === e.type) {
              t = t.getData();
              for (var i = e.dim + "_" + e.index, r = t.getDimensionIndex(t.mapDimension(e.dim)), o = t.getStore(), a = 0, s = o.count(); a < s; ++a) {
                var l = o.get(r, a);
                n[i] ? n[i].push(l) : n[i] = [l]
              }
            }
          })), {});
        for (e in n)
          if (n.hasOwnProperty(e)) {
            var r = n[e];
            if (r) {
              r.sort((function(t, e) {
                return t - e
              }));
              for (var o = null, a = 1; a < r.length; ++a) {
                var s = r[a] - r[a - 1];
                0 < s && (o = null === o ? s : Math.min(o, s))
              }
              i[e] = o
            }
          } return i
      }(t),
      r = [];
    return N(t, (function(t) {
      var e, n = t.coordinateSystem.getBaseAxis(),
        o = n.getExtent(),
        a = (e = "category" === n.type ? n.getBandWidth() : "value" === n.type || "time" === n.type ? (e = n.dim + "_" + n.index, e = i[e], a = Math.abs(o[1] - o[0]), s = n.scale.getExtent(), s = Math.abs(s[1] - s[0]), e ? a / s * e : a) : (s = t.getData(), Math.abs(o[1] - o[0]) / s.count()), qr(t.get("barWidth"), e)),
        s = (o = qr(t.get("barMaxWidth"), e), qr(t.get("barMinWidth") || (V_(t) ? .5 : 1), e)),
        l = t.get("barGap"),
        u = t.get("barCategoryGap");
      r.push({
        bandWidth: e,
        barWidth: a,
        barMaxWidth: o,
        barMinWidth: s,
        barGap: l,
        barCategoryGap: u,
        axisKey: N_(n),
        stackId: R_(t)
      })
    })), e = {}, N(r, (function(t, n) {
      var i, r = t.axisKey,
        o = t.bandWidth,
        a = ((a = ((a = ((i = (o = e[r] || {
          bandWidth: o,
          remainedWidth: o,
          autoWidthCount: 0,
          categoryGap: null,
          gap: "20%",
          stacks: {}
        }).stacks)[r = (e[r] = o, t.stackId)] || o.autoWidthCount++, i[r] = i[r] || {
          width: 0,
          maxWidth: 0
        }, t.barWidth)) && !i[r].width && (i[r].width = a, a = Math.min(o.remainedWidth, a), o.remainedWidth -= a), t.barMaxWidth)) && (i[r].maxWidth = a), t.barMinWidth);
      null != (r = (null != (i = (a && (i[r].minWidth = a), t.barGap)) && (o.gap = i), t.barCategoryGap)) && (o.categoryGap = r)
    })), n = {}, N(e, (function(t, e) {
      n[e] = {};
      var i, r = t.stacks,
        o = t.bandWidth,
        a = t.categoryGap,
        s = (null == a && (s = F(r).length, a = Math.max(35 - 4 * s, 15) + "%"), qr(a, o)),
        l = qr(t.gap, 1),
        u = t.remainedWidth,
        h = t.autoWidthCount,
        c = (u - s) / (h + (h - 1) * l),
        p = (c = Math.max(c, 0), N(r, (function(t) {
          var e, n = t.maxWidth,
            i = t.minWidth;
          t.width ? (e = t.width, n && (e = Math.min(e, n)), i && (e = Math.max(e, i)), t.width = e, u -= e + l * e, h--) : (e = c, n && n < e && (e = Math.min(n, u)), (e = i && e < i ? i : e) !== c && (t.width = e, u -= e + l * e, h--))
        })), c = (u - s) / (h + (h - 1) * l), c = Math.max(c, 0), 0),
        d = (N(r, (function(t, e) {
          t.width || (t.width = c), p += (i = t).width * (1 + l)
        })), i && (p -= i.width * l), -p / 2);
      N(r, (function(t, i) {
        n[e][i] = n[e][i] || {
          bandWidth: o,
          offset: d,
          width: t.width
        }, d += t.width * (1 + l)
      }))
    })), n
  }

  function B_(t, e) {
    var n = z_(t = E_(t, e));
    N(t, (function(t) {
      var e = t.getData(),
        i = t.coordinateSystem.getBaseAxis(),
        r = (t = R_(t), t = (i = n[N_(i)][t]).offset, i.width);
      e.setLayout({
        bandWidth: i.bandWidth,
        offset: t,
        size: r
      })
    }))
  }

  function F_(t) {
    return t.coordinateSystem && "cartesian2d" === t.coordinateSystem.type
  }

  function V_(t) {
    return t.pipelineContext && t.pipelineContext.large
  }
  i(G_, H_ = D_), G_.prototype.getLabel = function(t) {
    var e = this.getSetting("useUTC");
    return Hc(t.value, Ec[function(t) {
      switch (t) {
        case "year":
        case "month":
          return "day";
        case "millisecond":
          return "millisecond";
        default:
          return "second"
      }
    }(Vc(this._minLevelUnit))] || Ec.second, e, this.getSetting("locale"))
  }, G_.prototype.getFormattedLabel = function(t, e, n) {
    var i = this.getSetting("useUTC"),
      r = this.getSetting("locale"),
      o = null;
    if (U(n)) o = n;
    else if (G(n)) o = n(t.value, e, {
      level: t.level
    });
    else {
      var a = k({}, Nc);
      if (0 < t.level)
        for (var s = 0; s < zc.length; ++s) a[zc[s]] = "{primary|" + a[zc[s]] + "}";
      var l = n ? !1 === n.inherit ? n : D(n, a) : a,
        u = Wc(t.value, i);
      if (l[u]) o = l[u];
      else if (l.inherit) {
        for (s = Bc.indexOf(u) - 1; 0 <= s; --s)
          if (l[u]) {
            o = l[u];
            break
          } o = o || a.none
      }
      W(o) && (e = null == t.level ? 0 : 0 <= t.level ? t.level : o.length + t.level, o = o[e = Math.min(e, o.length - 1)])
    }
    return Hc(new Date(t.value), o, i, r)
  }, G_.prototype.getTicks = function() {
    var t = this._interval,
      e = this._extent,
      n = [];
    return t && (n.push({
      value: e[0],
      level: 0
    }), t = this.getSetting("useUTC"), t = function(t, e, n, i) {
      var r = Bc,
        o = 0;

      function a(t, r, o) {
        var a = [],
          s = !r.length;
        if (! function(t, e, n, i) {
            function r(t) {
              return Gc(c, t, i) === Gc(p, t, i)
            }

            function o() {
              return r("year")
            }

            function a() {
              return o() && r("month")
            }

            function s() {
              return a() && r("day")
            }

            function l() {
              return s() && r("hour")
            }

            function u() {
              return l() && r("minute")
            }

            function h() {
              return u() && r("second")
            }
            var c = eo(e),
              p = eo(n);
            switch (t) {
              case "year":
                return o();
              case "month":
                return a();
              case "day":
                return s();
              case "hour":
                return l();
              case "minute":
                return u();
              case "second":
                return h();
              case "millisecond":
                return h() && r("millisecond")
            }
          }(Vc(t), i[0], i[1], n)) {
          s && (r = [{
            value: function(t, e, n) {
              var i = new Date(t);
              switch (Vc(e)) {
                case "year":
                case "month":
                  i[$c(n)](0);
                case "day":
                  i[Qc(n)](1);
                case "hour":
                  i[Jc(n)](0);
                case "minute":
                  i[tp(n)](0);
                case "second":
                  i[ep(n)](0), i[np(n)](0)
              }
              return i.getTime()
            }(new Date(i[0]), t, n)
          }, {
            value: i[1]
          }]);
          for (var l, u, h = 0; h < r.length - 1; h++) {
            var c = r[h].value,
              p = r[h + 1].value;
            if (c !== p) {
              var d = void 0,
                f = void 0,
                g = void 0;
              switch (t) {
                case "year":
                  d = Math.max(1, Math.round(e / Rc / 365)), f = Uc(n), g = n ? "setUTCFullYear" : "setFullYear";
                  break;
                case "half-year":
                case "quarter":
                case "month":
                  u = e, d = 6 < (u /= 30 * Rc) ? 6 : 3 < u ? 3 : 2 < u ? 2 : 1, f = Xc(n), g = $c(n);
                  break;
                case "week":
                case "half-week":
                case "day":
                  u = e, d = 16 < (u /= Rc) ? 16 : 7.5 < u ? 7 : 3.5 < u ? 4 : 1.5 < u ? 2 : 1, f = Yc(n), g = Qc(n);
                  break;
                case "half-day":
                case "quarter-day":
                case "hour":
                  l = e, d = 12 < (l /= Oc) ? 12 : 6 < l ? 6 : 3.5 < l ? 4 : 2 < l ? 2 : 1, f = qc(n), g = Jc(n);
                  break;
                case "minute":
                  d = X_(e, !0), f = jc(n), g = tp(n);
                  break;
                case "second":
                  d = X_(e, !1), f = Zc(n), g = ep(n);
                  break;
                case "millisecond":
                  d = ro(e, !0), f = Kc(n), g = np(n)
              }
              M = S = b = w = void 0;
              for (var y = d, m = c, v = p, _ = f, x = g, w = a, b = new Date(m), S = m, M = b[_](); S < v && S <= i[1];) w.push({
                value: S
              }), b[x](M += y), S = b.getTime();
              w.push({
                value: S,
                notAdd: !0
              }), "year" === t && 1 < o.length && 0 === h && o.unshift({
                value: o[0].value - d
              })
            }
          }
          for (h = 0; h < a.length; h++) o.push(a[h])
        }
      }
      for (var s = [], l = [], u = 0, h = 0, c = 0; c < r.length && o++ < 1e4; ++c) {
        var p = Vc(r[c]);
        if (function(t) {
            return t === Vc(t)
          }(r[c]))
          if (a(r[c], s[s.length - 1] || [], l), p !== (r[c + 1] ? Vc(r[c + 1]) : null)) {
            if (l.length) {
              h = u, l.sort((function(t, e) {
                return t.value - e.value
              }));
              for (var d = [], f = 0; f < l.length; ++f) {
                var g = l[f].value;
                0 !== f && l[f - 1].value === g || (d.push(l[f]), g >= i[0] && g <= i[1] && u++)
              }
              if (1.5 * (p = (i[1] - i[0]) / e) < u && p / 1.5 < h) break;
              if (s.push(d), p < u || t === r[c]) break
            }
            l = []
          }
      }
      var y = B(E(s, (function(t) {
          return B(t, (function(t) {
            return t.value >= i[0] && t.value <= i[1] && !t.notAdd
          }))
        })), (function(t) {
          return 0 < t.length
        })),
        m = [],
        v = y.length - 1;
      for (c = 0; c < y.length; ++c)
        for (var _ = y[c], x = 0; x < _.length; ++x) m.push({
          value: _[x].value,
          level: v - c
        });
      m.sort((function(t, e) {
        return t.value - e.value
      }));
      var w = [];
      for (c = 0; c < m.length; ++c) 0 !== c && m[c].value === m[c - 1].value || w.push(m[c]);
      return w
    }(this._minLevelUnit, this._approxInterval, t, e), (n = n.concat(t)).push({
      value: e[1],
      level: 0
    })), n
  }, G_.prototype.calcNiceExtent = function(t) {
    var e, n = this._extent;
    n[0] === n[1] && (n[0] -= Rc, n[1] += Rc), n[1] === -1 / 0 && n[0] === 1 / 0 && (e = new Date, n[1] = +new Date(e.getFullYear(), e.getMonth(), e.getDate()), n[0] = n[1] - Rc), this.calcNiceTicks(t.splitNumber, t.minInterval, t.maxInterval)
  }, G_.prototype.calcNiceTicks = function(t, e, n) {
    var i = (i = this._extent)[1] - i[0];
    this._approxInterval = i / (t = t || 10), null != e && this._approxInterval < e && (this._approxInterval = e), null != n && this._approxInterval > n && (this._approxInterval = n), i = U_.length, t = Math.min(function(t, e, n, i) {
      for (; n < i;) {
        var r = n + i >>> 1;
        t[r][1] < e ? n = 1 + r : i = r
      }
      return n
    }(U_, this._approxInterval, 0, i), i - 1);
    this._interval = U_[t][1], this._minLevelUnit = U_[Math.max(t - 1, 0)][0]
  }, G_.prototype.parse = function(t) {
    return Y(t) ? t : +eo(t)
  }, G_.prototype.contain = function(t) {
    return w_(this.parse(t), this._extent)
  }, G_.prototype.normalize = function(t) {
    return b_(this.parse(t), this._extent)
  }, G_.prototype.scale = function(t) {
    return S_(t, this._extent)
  }, G_.type = "time";
  var H_, W_ = G_;

  function G_(t) {
    return (t = H_.call(this, t) || this).type = "time", t
  }
  var U_ = [
    ["second", 1e3],
    ["minute", 6e4],
    ["hour", Oc],
    ["quarter-day", 6 * Oc],
    ["half-day", 12 * Oc],
    ["day", 1.2 * Rc],
    ["half-week", 3.5 * Rc],
    ["week", 7 * Rc],
    ["month", 31 * Rc],
    ["quarter", 95 * Rc],
    ["half-year", Eo / 2],
    ["year", Eo]
  ];

  function X_(t, e) {
    return 30 < (t /= e ? 6e4 : 1e3) ? 30 : 20 < t ? 20 : 15 < t ? 15 : 10 < t ? 10 : 5 < t ? 5 : 2 < t ? 2 : 1
  }
  c_.registerClass(W_);
  var Y_, q_ = c_.prototype,
    j_ = D_.prototype,
    Z_ = jr,
    K_ = Math.floor,
    $_ = Math.ceil,
    Q_ = Math.pow,
    J_ = Math.log,
    tx = (i(ex, Y_ = c_), ex.prototype.getTicks = function(t) {
      var e = this._originalScale,
        n = this._extent,
        i = e.getExtent();
      return E(j_.getTicks.call(this, t), (function(t) {
        t = t.value;
        var e = jr(Q_(this.base, t));
        e = t === n[0] && this._fixMin ? nx(e, i[0]) : e;
        return {
          value: t === n[1] && this._fixMax ? nx(e, i[1]) : e
        }
      }), this)
    }, ex.prototype.setExtent = function(t, e) {
      var n = J_(this.base);
      t = J_(Math.max(0, t)) / n, e = J_(Math.max(0, e)) / n, j_.setExtent.call(this, t, e)
    }, ex.prototype.getExtent = function() {
      var t = this.base,
        e = q_.getExtent.call(this);
      return e[0] = Q_(t, e[0]), e[1] = Q_(t, e[1]), t = this._originalScale.getExtent(), this._fixMin && (e[0] = nx(e[0], t[0])), this._fixMax && (e[1] = nx(e[1], t[1])), e
    }, ex.prototype.unionExtent = function(t) {
      this._originalScale.unionExtent(t);
      var e = this.base;
      t[0] = J_(t[0]) / J_(e), t[1] = J_(t[1]) / J_(e), q_.unionExtent.call(this, t)
    }, ex.prototype.unionExtentFromData = function(t, e) {
      this.unionExtent(t.getApproximateExtent(e))
    }, ex.prototype.calcNiceTicks = function(t) {
      t = t || 10;
      var e = this._extent,
        n = e[1] - e[0];
      if (!(n == 1 / 0 || n <= 0)) {
        var i = no(n);
        for (t / n * i <= .5 && (i *= 10); !isNaN(i) && Math.abs(i) < 1 && 0 < Math.abs(i);) i *= 10;
        t = [jr($_(e[0] / i) * i), jr(K_(e[1] / i) * i)], this._interval = i, this._niceExtent = t
      }
    }, ex.prototype.calcNiceExtent = function(t) {
      j_.calcNiceExtent.call(this, t), this._fixMin = t.fixMin, this._fixMax = t.fixMax
    }, ex.prototype.parse = function(t) {
      return t
    }, ex.prototype.contain = function(t) {
      return w_(t = J_(t) / J_(this.base), this._extent)
    }, ex.prototype.normalize = function(t) {
      return b_(t = J_(t) / J_(this.base), this._extent)
    }, ex.prototype.scale = function(t) {
      return t = S_(t, this._extent), Q_(this.base, t)
    }, ex.type = "log", ex);

  function ex() {
    var t = null !== Y_ && Y_.apply(this, arguments) || this;
    return t.type = "log", t.base = 10, t._originalScale = new D_, t._interval = 0, t
  }

  function nx(t, e) {
    return Z_(t, Zr(e))
  }(ky = tx.prototype).getMinorTicks = j_.getMinorTicks, ky.getLabel = j_.getLabel, c_.registerClass(tx), rx.prototype._prepareParams = function(t, e, n) {
    n[1] < n[0] && (n = [NaN, NaN]), this._dataMin = n[0], this._dataMax = n[1];
    var i = this._isOrdinal = "ordinal" === t.type,
      r = (G(r = (null == (r = (this._needCrossZero = "interval" === t.type && e.getNeedCrossZero && e.getNeedCrossZero(), e.get("min", !0))) && (r = e.get("startValue", !0)), this._modelMinRaw = r)) ? this._modelMinNum = sx(t, r({
        min: n[0],
        max: n[1]
      })) : "dataMin" !== r && (this._modelMinNum = sx(t, r)), this._modelMaxRaw = e.get("max", !0));
    G(r) ? this._modelMaxNum = sx(t, r({
      min: n[0],
      max: n[1]
    })) : "dataMax" !== r && (this._modelMaxNum = sx(t, r)), i ? this._axisDataLen = e.getCategories().length : "boolean" == typeof(t = W(n = e.get("boundaryGap")) ? n : [n || 0, n || 0])[0] || "boolean" == typeof t[1] ? this._boundaryGapInner = [0, 0] : this._boundaryGapInner = [xr(t[0], 1), xr(t[1], 1)]
  }, rx.prototype.calculate = function() {
    var t = this._isOrdinal,
      e = this._dataMin,
      n = this._dataMax,
      i = this._axisDataLen,
      r = this._boundaryGapInner,
      o = t ? null : n - e || Math.abs(e),
      a = "dataMin" === this._modelMinRaw ? e : this._modelMinNum,
      s = "dataMax" === this._modelMaxRaw ? n : this._modelMaxNum,
      l = null != a,
      u = null != s;
    null == a && (a = t ? i ? 0 : NaN : e - r[0] * o), null == s && (s = t ? i ? i - 1 : NaN : n + r[1] * o), null != a && isFinite(a) || (a = NaN), null != s && isFinite(s) || (s = NaN), e = tt(a) || tt(s) || t && !i;
    return null != (n = (this._needCrossZero && (a = 0 < a && 0 < s && !l ? 0 : a) < 0 && s < 0 && !u && (s = 0), this._determinedMin)) && (a = n, l = !0), null != (r = this._determinedMax) && (s = r, u = !0), {
      min: a,
      max: s,
      minFixed: l,
      maxFixed: u,
      isBlank: e
    }
  }, rx.prototype.modifyDataMinMax = function(t, e) {
    this[ax[t]] = e
  }, rx.prototype.setDeterminedMinMax = function(t, e) {
    this[ox[t]] = e
  }, rx.prototype.freeze = function() {
    this.frozen = !0
  };
  var ix = rx;

  function rx(t, e, n) {
    this._prepareParams(t, e, n)
  }
  var ox = {
      min: "_determinedMin",
      max: "_determinedMax"
    },
    ax = {
      min: "_dataMin",
      max: "_dataMax"
    };

  function sx(t, e) {
    return null == e ? null : tt(e) ? NaN : t.parse(e)
  }

  function lx(t, e) {
    var n, i, r, o, a, s = t.type,
      l = (l = e, u = (h = t).getExtent(), (c = h.rawExtentInfo) || (c = new ix(h, l, u), h.rawExtentInfo = c), c.calculate()),
      u = (t.setBlank(l.isBlank), l.min),
      h = l.max,
      c = e.ecModel;
    return c && "time" === s && (t = E_("bar", c), n = !1, N(t, (function(t) {
      n = n || t.getBaseAxis() === e.axis
    })), n) && (s = z_(t), c = u, t = h, s = s, a = (a = (i = e).axis.getExtent())[1] - a[0], void 0 !== (s = function(t, e, n) {
      if (t && e) return t = t[N_(e)]
    }(s, i.axis)) && (r = 1 / 0, N(s, (function(t) {
      r = Math.min(t.offset, r)
    })), o = -1 / 0, N(s, (function(t) {
      o = Math.max(t.offset + t.width, o)
    })), r = Math.abs(r), t += (o = Math.abs(o)) / (i = r + o) * (a = (s = t - c) / (1 - (r + o) / a) - s), c -= r / i * a), u = (s = {
      min: c,
      max: t
    }).min, h = s.max), {
      extent: [u, h],
      fixMin: l.minFixed,
      fixMax: l.maxFixed
    }
  }

  function ux(t, e) {
    var n = lx(t, e),
      i = n.extent,
      r = e.get("splitNumber"),
      o = (t instanceof tx && (t.base = e.get("logBase")), t.type),
      a = e.get("interval");
    o = "interval" === o || "time" === o;
    t.setExtent(i[0], i[1]), t.calcNiceExtent({
      splitNumber: r,
      fixMin: n.fixMin,
      fixMax: n.fixMax,
      minInterval: o ? e.get("minInterval") : null,
      maxInterval: o ? e.get("maxInterval") : null
    }), null != a && t.setInterval && t.setInterval(a)
  }

  function hx(t, e) {
    if (e = e || t.get("type")) switch (e) {
      case "category":
        return new T_({
          ordinalMeta: t.getOrdinalMeta ? t.getOrdinalMeta() : t.getCategories(),
          extent: [1 / 0, -1 / 0]
        });
      case "time":
        return new W_({
          locale: t.ecModel.getLocaleModel(),
          useUTC: t.ecModel.get("useUTC")
        });
      default:
        return new(c_.getClass(e) || D_)
    }
  }

  function cx(t) {
    var e, n, i, r = t.getLabelModel().get("formatter"),
      o = "category" === t.type ? t.scale.getExtent()[0] : null;
    return "time" === t.scale.type ? (i = r, function(e, n) {
      return t.scale.getFormattedLabel(e, n, i)
    }) : U(r) ? (n = r, function(e) {
      return e = t.scale.getLabel(e), n.replace("{value}", null != e ? e : "")
    }) : G(r) ? (e = r, function(n, i) {
      return null != o && (i = n.value - o), e(px(t, n), i, null != n.level ? {
        level: n.level
      } : null)
    }) : function(e) {
      return t.scale.getLabel(e)
    }
  }

  function px(t, e) {
    return "category" === t.type ? t.scale.getLabel(e) : e.value
  }

  function dx(t) {
    return null == (t = t.get("interval")) ? "auto" : t
  }

  function fx(t) {
    return "category" === t.type && 0 === dx(t.getLabelModel())
  }
  yx.prototype.getNeedCrossZero = function() {
    return !this.option.scale
  }, yx.prototype.getCoordSysModel = function() {};
  var gx = yx;

  function yx() {}
  Py = Object.freeze({
    __proto__: null,
    createDimensions: function(t, e) {
      return i_(t, e).dimensions
    },
    createList: function(t) {
      return h_(null, t)
    },
    createScale: function(t, e) {
      var n = e;
      return (e = hx(n = e instanceof Mc ? n : new Mc(e))).setExtent(t[0], t[1]), ux(e, n), e
    },
    createSymbol: By,
    createTextStyle: function(t, e) {
      return rc(t, null, null, "normal" !== (e = e || {}).state)
    },
    dataStack: {
      isDimensionStacked: l_,
      enableDataStack: s_,
      getStackedDimension: u_
    },
    enableHoverEmphasis: Dl,
    getECData: Us,
    getLayoutRect: yp,
    mixinAxisModelCommonMethods: function(t) {
      O(t, gx)
    }
  });
  var mx = [],
    vx = {
      registerPreprocessor: fv,
      registerProcessor: gv,
      registerPostInit: yv,
      registerPostUpdate: mv,
      registerUpdateLifecycle: vv,
      registerAction: _v,
      registerCoordinateSystem: xv,
      registerLayout: wv,
      registerVisual: bv,
      registerTransform: Cv,
      registerLoading: Tv,
      registerMap: Iv,
      registerImpl: function(t, e) {
        fm[t] = e
      },
      PRIORITY: Ly,
      ComponentModel: Tp,
      ComponentView: kg,
      SeriesModel: _g,
      ChartView: Og,
      registerComponentModel: function(t) {
        Tp.registerClass(t)
      },
      registerComponentView: function(t) {
        kg.registerClass(t)
      },
      registerSeriesModel: function(t) {
        _g.registerClass(t)
      },
      registerChartView: function(t) {
        Og.registerClass(t)
      },
      registerSubTypeDefaulter: function(t, e) {
        Tp.registerSubTypeDefaulter(t, e)
      },
      registerPainter: function(t, e) {
        Wr(t, e)
      }
    };

  function _x(t) {
    W(t) ? N(t, (function(t) {
      _x(t)
    })) : 0 <= L(mx, t) || (mx.push(t), (t = G(t) ? {
      install: t
    } : t).install(vx))
  }

  function xx(t, e) {
    return Math.abs(t - e) < 1e-8
  }

  function bx(t, e, n) {
    var i = 0,
      r = t[0];
    if (r) {
      for (var o = 1; o < t.length; o++) {
        var a = t[o];
        i += ja(r[0], r[1], a[0], a[1], e, n), r = a
      }
      var s = t[0];
      return xx(r[0], s[0]) && xx(r[1], s[1]) || (i += ja(r[0], r[1], s[0], s[1], e, n)), 0 !== i
    }
  }
  var Sx = [];

  function Mx(t, e) {
    for (var n = 0; n < t.length; n++) zt(t[n], t[n], e)
  }

  function Tx(t, e, n, i) {
    for (var r = 0; r < t.length; r++) {
      var o = t[r];
      (o = i ? i.project(o) : o) && isFinite(o[0]) && isFinite(o[1]) && (Bt(e, e, o), Ft(n, n, o))
    }
  }

  function Ix(t) {
    this.name = t
  }
  Ix.prototype.setCenter = function(t) {
    this._center = t
  }, Ix.prototype.getCenter = function() {
    return this._center || (this._center = this.calcCenter())
  };
  var Cx, kx, Dx = function(t, e) {
      this.type = "polygon", this.exterior = t, this.interiors = e
    },
    Ax = function(t) {
      this.type = "linestring", this.points = t
    },
    Lx = (i(Px, Cx = Oy = Ix), Px.prototype.calcCenter = function() {
      for (var t, e = this.geometries, n = 0, i = 0; i < e.length; i++) {
        var r, o = e[i];
        n < (r = (r = o.exterior) && r.length) && (t = o, n = r)
      }
      if (t) {
        for (var a = t.exterior, s = 0, l = 0, u = 0, h = a.length, c = a[h - 1][0], p = a[h - 1][1], d = 0; d < h; d++) {
          var f = a[d][0],
            g = a[d][1],
            y = c * g - f * p;
          s += y, l += (c + f) * y, u += (p + g) * y, c = f, p = g
        }
        return s ? [l / s / 3, u / s / 3, s] : [a[0][0] || 0, a[0][1] || 0]
      }
      var m = this.getBoundingRect();
      return [m.x + m.width / 2, m.y + m.height / 2]
    }, Px.prototype.getBoundingRect = function(t) {
      var e, n, i = this._rect;
      return i && !t || (e = [1 / 0, 1 / 0], n = [-1 / 0, -1 / 0], N(this.geometries, (function(i) {
        "polygon" === i.type ? Tx(i.exterior, e, n, t) : N(i.points, (function(i) {
          Tx(i, e, n, t)
        }))
      })), isFinite(e[0]) && isFinite(e[1]) && isFinite(n[0]) && isFinite(n[1]) || (e[0] = e[1] = n[0] = n[1] = 0), i = new Oe(e[0], e[1], n[0] - e[0], n[1] - e[1]), t) || (this._rect = i), i
    }, Px.prototype.contain = function(t) {
      var e = this.getBoundingRect(),
        n = this.geometries;
      if (e.contain(t[0], t[1])) t: for (var i = 0, r = n.length; i < r; i++) {
        var o = n[i];
        if ("polygon" === o.type) {
          var a = o.exterior,
            s = o.interiors;
          if (bx(a, t[0], t[1])) {
            for (var l = 0; l < (s ? s.length : 0); l++)
              if (bx(s[l], t[0], t[1])) continue t;
            return !0
          }
        }
      }
      return !1
    }, Px.prototype.transformTo = function(t, e, n, i) {
      for (var r = this.getBoundingRect(), o = r.width / r.height, a = (o = (n ? i = i || n / o : n = o * i, new Oe(t, e, n, i)), r.calculateTransform(o)), s = this.geometries, l = 0; l < s.length; l++) {
        var u = s[l];
        "polygon" === u.type ? (Mx(u.exterior, a), N(u.interiors, (function(t) {
          Mx(t, a)
        }))) : N(u.points, (function(t) {
          Mx(t, a)
        }))
      }(r = this._rect).copy(o), this._center = [r.x + r.width / 2, r.y + r.height / 2]
    }, Px.prototype.cloneShallow = function(t) {
      return (t = new Px(t = null == t ? this.name : t, this.geometries, this._center))._rect = this._rect, t.transformTo = null, t
    }, Px);

  function Px(t, e, n) {
    return (t = Cx.call(this, t) || this).type = "geoJSON", t.geometries = e, t._center = n && [n[0], n[1]], t
  }

  function Ox(t, e) {
    return (t = kx.call(this, t) || this).type = "geoSVG", t._elOnlyForCalculate = e, t
  }

  function Rx(t, e, n) {
    for (var i = 0; i < t.length; i++) t[i] = Nx(t[i], e[i], n)
  }

  function Nx(t, e, n) {
    for (var i = [], r = e[0], o = e[1], a = 0; a < t.length; a += 2) {
      var s = (s = t.charCodeAt(a) - 64) >> 1 ^ -(1 & s),
        l = (l = t.charCodeAt(a + 1) - 64) >> 1 ^ -(1 & l);
      i.push([(r = s += r) / n, (o = l += o) / n])
    }
    return i
  }

  function Ex(t, e) {
    var n, i, r;
    return E(B((t = (n = t).UTF8Encoding ? (null == (r = (i = n).UTF8Scale) && (r = 1024), N(i.features, (function(t) {
      var e = t.geometry,
        n = e.encodeOffsets,
        i = e.coordinates;
      if (n) switch (e.type) {
        case "LineString":
          e.coordinates = Nx(i, n, r);
          break;
        case "Polygon":
        case "MultiLineString":
          Rx(i, n, r);
          break;
        case "MultiPolygon":
          N(i, (function(t, e) {
            return Rx(t, n[e], r)
          }))
      }
    })), i.UTF8Encoding = !1, i) : n).features, (function(t) {
      return t.geometry && t.properties && 0 < t.geometry.coordinates.length
    })), (function(t) {
      var n = t.properties,
        i = t.geometry,
        r = [];
      switch (i.type) {
        case "Polygon":
          var o = i.coordinates;
          r.push(new Dx(o[0], o.slice(1)));
          break;
        case "MultiPolygon":
          N(i.coordinates, (function(t) {
            t[0] && r.push(new Dx(t[0], t.slice(1)))
          }));
          break;
        case "LineString":
          r.push(new Ax([i.coordinates]));
          break;
        case "MultiLineString":
          r.push(new Ax(i.coordinates))
      }
      return (t = new Lx(n[e || "name"], r, n.cp)).properties = n, t
    }))
  }
  i(Ox, kx = Oy), Ox.prototype.calcCenter = function() {
    for (var t = this._elOnlyForCalculate, e = [(e = t.getBoundingRect()).x + e.width / 2, e.y + e.height / 2], n = ge(Sx), i = t; i && !i.isGeoSVGGraphicRoot;) me(n, i.getLocalTransform(), n), i = i.parent;
    return we(n, n), zt(e, e, n), e
  };
  vc = Object.freeze({
    __proto__: null,
    MAX_SAFE_INTEGER: 9007199254740991,
    asc: function(t) {
      return t.sort((function(t, e) {
        return t - e
      })), t
    },
    getPercentWithPrecision: function(t, e, n) {
      return t[e] && function(t, e) {
        var n = z(t, (function(t, e) {
          return t + (isNaN(e) ? 0 : e)
        }), 0);
        if (0 === n) return [];
        for (var i = Math.pow(10, e), r = (e = E(t, (function(t) {
            return (isNaN(t) ? 0 : t) / n * i * 100
          })), 100 * i), o = E(e, (function(t) {
            return Math.floor(t)
          })), a = z(o, (function(t, e) {
            return t + e
          }), 0), s = E(e, (function(t, e) {
            return t - o[e]
          })); a < r;) {
          for (var l = Number.NEGATIVE_INFINITY, u = null, h = 0, c = s.length; h < c; ++h) s[h] > l && (l = s[h], u = h);
          ++o[u], s[u] = 0, ++a
        }
        return E(o, (function(t) {
          return t / i
        }))
      }(t, n)[e] || 0
    },
    getPixelPrecision: $r,
    getPrecision: Zr,
    getPrecisionSafe: Kr,
    isNumeric: ao,
    isRadianAroundZero: Jr,
    linearMap: Yr,
    nice: ro,
    numericToNumber: oo,
    parseDate: eo,
    quantile: function(t, e) {
      e = (t.length - 1) * e + 1;
      var n = Math.floor(e),
        i = +t[n - 1];
      return (e -= n) ? i + e * (t[n] - i) : i
    },
    quantity: no,
    quantityExponent: io,
    reformIntervals: function(t) {
      t.sort((function(t, e) {
        return function t(e, n, i) {
          return e.interval[i] < n.interval[i] || e.interval[i] === n.interval[i] && (e.close[i] - n.close[i] == (i ? -1 : 1) || !i && t(e, n, 1))
        }(t, e, 0) ? -1 : 1
      }));
      for (var e = -1 / 0, n = 1, i = 0; i < t.length;) {
        for (var r = t[i].interval, o = t[i].close, a = 0; a < 2; a++) r[a] <= e && (r[a] = e, o[a] = a ? 1 : 1 - n), e = r[a], n = o[a];
        r[0] === r[1] && o[0] * o[1] != 1 ? t.splice(i, 1) : i++
      }
      return t
    },
    remRadian: Qr,
    round: jr
  }), Wo = Object.freeze({
    __proto__: null,
    format: Hc,
    parse: eo
  }), wc = Object.freeze({
    __proto__: null,
    Arc: $u,
    BezierCurve: qu,
    BoundingRect: Oe,
    Circle: kS,
    CompoundPath: th,
    Ellipse: mM,
    Group: Rr,
    Image: gs,
    IncrementalDisplayable: Qn,
    Line: Hu,
    LinearGradient: rh,
    Polygon: Pu,
    Polyline: Eu,
    RadialGradient: sh,
    Rect: Ms,
    Ring: Cu,
    Sector: Su,
    Text: Ds,
    clipPointsByRect: Xh,
    clipRectByRect: Yh,
    createIcon: qh,
    extendPath: Lh,
    extendShape: Ah,
    getShapeClass: Oh,
    getTransform: Hh,
    initProps: wh,
    makeImage: Nh,
    makePath: Rh,
    mergePath: zh,
    registerShape: Ph,
    resizePath: Bh,
    updateProps: xh
  }), wy = Object.freeze({
    __proto__: null,
    addCommas: ip,
    capitalFirst: function(t) {
      return t && t.charAt(0).toUpperCase() + t.substr(1)
    },
    encodeHTML: ee,
    formatTime: function(t, e, n) {
      "week" !== t && "month" !== t && "quarter" !== t && "half-year" !== t && "year" !== t || (t = "MM-dd\nyyyy");
      var i = (e = eo(e))[(n = n ? "getUTC" : "get") + "FullYear"](),
        r = e[n + "Month"]() + 1,
        o = e[n + "Date"](),
        a = e[n + "Hours"](),
        s = e[n + "Minutes"](),
        l = e[n + "Seconds"]();
      e = e[n + "Milliseconds"]();
      return t.replace("MM", Fc(r, 2)).replace("M", r).replace("yyyy", i).replace("yy", Fc(i % 100 + "", 2)).replace("dd", Fc(o, 2)).replace("d", o).replace("hh", Fc(a, 2)).replace("h", a).replace("mm", Fc(s, 2)).replace("m", s).replace("ss", Fc(l, 2)).replace("s", l).replace("SSS", Fc(e, 3))
    },
    formatTpl: up,
    getTextRect: function(t, e, n, i, r, o, a, s) {
      return new Ds({
        style: {
          text: t,
          font: e,
          align: n,
          verticalAlign: i,
          padding: r,
          rich: o,
          overflow: a ? "truncate" : null,
          lineHeight: s
        }
      }).getBoundingRect()
    },
    getTooltipMarker: hp,
    normalizeCssArray: op,
    toCamelCase: rp,
    truncateText: Zo
  }), by = Object.freeze({
    __proto__: null,
    bind: V,
    clone: I,
    curry: H,
    defaults: D,
    each: N,
    extend: k,
    filter: B,
    indexOf: L,
    inherits: P,
    isArray: W,
    isFunction: G,
    isObject: q,
    isString: U,
    map: E,
    merge: C,
    reduce: z
  });
  var zx = So();

  function Bx(t, e) {
    return e = E(e, (function(e) {
      return t.scale.parse(e)
    })), "time" === t.type && 0 < e.length && (e.sort(), e.unshift(e[0]), e.push(e[e.length - 1])), e
  }

  function Fx(t, e) {
    var n, i = Vx(t, "labels"),
      r = Hx(i, e = dx(e));
    return r || Wx(i, e, {
      labels: G(e) ? Ux(t, e) : Gx(t, n = "auto" === e ? null != (i = zx(r = t).autoInterval) ? i : zx(r).autoInterval = r.calculateCategoryInterval() : e),
      labelCategoryInterval: n
    })
  }

  function Vx(t, e) {
    return zx(t)[e] || (zx(t)[e] = [])
  }

  function Hx(t, e) {
    for (var n = 0; n < t.length; n++)
      if (t[n].key === e) return t[n].value
  }

  function Wx(t, e, n) {
    return t.push({
      key: e,
      value: n
    }), n
  }

  function Gx(t, e, n) {
    for (var i = cx(t), r = t.scale, o = r.getExtent(), a = t.getLabelModel(), s = [], l = Math.max((e || 0) + 1, 1), u = (e = o[0], r.count()), h = (u = (0 !== e && 1 < l && 2 < u / l && (e = Math.round(Math.ceil(e / l) * l)), fx(t)), t = a.get("showMinLabel") || u, a = a.get("showMaxLabel") || u, t && e !== o[0] && c(o[0]), e); h <= o[1]; h += l) c(h);

    function c(t) {
      var e = {
        value: t
      };
      s.push(n ? t : {
        formattedLabel: i(e),
        rawLabel: r.getLabel(e),
        tickValue: t
      })
    }
    return a && h - l !== o[1] && c(o[1]), s
  }

  function Ux(t, e, n) {
    var i = t.scale,
      r = cx(t),
      o = [];
    return N(i.getTicks(), (function(t) {
      var a = i.getLabel(t),
        s = t.value;
      e(t.value, a) && o.push(n ? s : {
        formattedLabel: r(t),
        rawLabel: a,
        tickValue: s
      })
    })), o
  }
  var Xx = [0, 1];
  Yx.prototype.contain = function(t) {
    var e = this._extent,
      n = Math.min(e[0], e[1]);
    e = Math.max(e[0], e[1]);
    return n <= t && t <= e
  }, Yx.prototype.containData = function(t) {
    return this.scale.contain(t)
  }, Yx.prototype.getExtent = function() {
    return this._extent.slice()
  }, Yx.prototype.getPixelPrecision = function(t) {
    return $r(t || this.scale.getExtent(), this._extent)
  }, Yx.prototype.setExtent = function(t, e) {
    var n = this._extent;
    n[0] = t, n[1] = e
  }, Yx.prototype.dataToCoord = function(t, e) {
    var n = this._extent,
      i = this.scale;
    return t = i.normalize(t), this.onBand && "ordinal" === i.type && qx(n = n.slice(), i.count()), Yr(t, Xx, n, e)
  }, Yx.prototype.coordToData = function(t, e) {
    var n = this._extent,
      i = this.scale;
    this.onBand && "ordinal" === i.type && qx(n = n.slice(), i.count()), i = Yr(t, n, Xx, e);
    return this.scale.scale(i)
  }, Yx.prototype.pointToData = function(t, e) {}, Yx.prototype.getTicksCoords = function(t) {
    var e, n, i, r, o, a, s, l, u = E(function(t, e) {
      var n, i, r, o, a = t.getTickModel().get("customValues");
      return a ? {
        ticks: Bx(t, a)
      } : "category" === t.type ? (a = e, (o = Hx(i = Vx(e = t, "ticks"), r = dx(a))) || (a.get("show") && !e.scale.isBlank() || [], Wx(i, r, {
        ticks: G(r) ? Ux(e, r, !0) : "auto" === r ? (n = (o = Fx(e, e.getLabelModel())).labelCategoryInterval, E(o.labels, (function(t) {
          return t.tickValue
        }))) : Gx(e, n = r, !0),
        tickCategoryInterval: n
      }))) : {
        ticks: E(t.scale.getTicks(), (function(t) {
          return t.value
        }))
      }
    }(this, l = (t = t || {}).tickModel || this.getTickModel()).ticks, (function(t) {
      return {
        coord: this.dataToCoord("ordinal" === this.scale.type ? this.scale.getRawOrdinalNumber(t) : t),
        tickValue: t
      }
    }), this);

    function h(t, e) {
      return t = jr(t), e = jr(e), a ? e < t : t < e
    }
    return e = this, n = u, l = l = l.get("alignWithLabel"), t = t.clamp, s = n.length, e.onBand && !l && s && (l = e.getExtent(), 1 === s ? (n[0].coord = l[0], i = n[1] = {
      coord: l[1]
    }) : (o = n[s - 1].tickValue - n[0].tickValue, r = (n[s - 1].coord - n[0].coord) / o, N(n, (function(t) {
      t.coord -= r / 2
    })), e = 1 + (o = e.scale.getExtent())[1] - n[s - 1].tickValue, i = {
      coord: n[s - 1].coord + r * e
    }, n.push(i)), a = l[0] > l[1], h(n[0].coord, l[0]) && (t ? n[0].coord = l[0] : n.shift()), t && h(l[0], n[0].coord) && n.unshift({
      coord: l[0]
    }), h(l[1], i.coord) && (t ? i.coord = l[1] : n.pop()), t) && h(i.coord, l[1]) && n.push({
      coord: l[1]
    }), u
  }, Yx.prototype.getMinorTicksCoords = function() {
    var t;
    return "ordinal" === this.scale.type ? [] : (t = this.model.getModel("minorTick").get("splitNumber"), E(this.scale.getMinorTicks(t = 0 < t && t < 100 ? t : 5), (function(t) {
      return E(t, (function(t) {
        return {
          coord: this.dataToCoord(t),
          tickValue: t
        }
      }), this)
    }), this))
  }, Yx.prototype.getViewLabels = function() {
    return function(t) {
      var e, n, i, r, o, a = t.getLabelModel().get("customValues");
      return a ? (e = cx(t), {
        labels: Bx(t, a).map((function(n) {
          var i = {
            value: n
          };
          return {
            formattedLabel: e(i),
            rawLabel: t.scale.getLabel(i),
            tickValue: n
          }
        }))
      }) : "category" === t.type ? (r = (a = t).getLabelModel(), o = Fx(a, r), !r.get("show") || a.scale.isBlank() ? {
        labels: [],
        labelCategoryInterval: o.labelCategoryInterval
      } : o) : (r = (n = t).scale.getTicks(), i = cx(n), {
        labels: E(r, (function(t, e) {
          return {
            level: t.level,
            formattedLabel: i(t, e),
            rawLabel: n.scale.getLabel(t),
            tickValue: t.value
          }
        }))
      })
    }(this).labels
  }, Yx.prototype.getLabelModel = function() {
    return this.model.getModel("axisLabel")
  }, Yx.prototype.getTickModel = function() {
    return this.model.getModel("axisTick")
  }, Yx.prototype.getBandWidth = function() {
    var t, e = this._extent;
    0 === (t = (t = this.scale.getExtent())[1] - t[0] + (this.onBand ? 1 : 0)) && (t = 1), e = Math.abs(e[1] - e[0]);
    return Math.abs(e) / t
  }, Yx.prototype.calculateCategoryInterval = function() {
    r = (n = d = this).getLabelModel();
    var t = {
        axisRotate: n.getRotate ? n.getRotate() : n.isHorizontal && !n.isHorizontal() ? 90 : 0,
        labelRotate: r.get("rotate") || 0,
        font: r.getFont()
      },
      e = cx(d),
      n = (t.axisRotate - t.labelRotate) / 180 * Math.PI,
      i = (r = d.scale).getExtent(),
      r = r.count();
    if (i[1] - i[0] < 1) return 0;
    for (var o = 1, a = (40 < r && (o = Math.max(1, Math.floor(r / 40))), i[0]), s = d.dataToCoord(a + 1) - d.dataToCoord(a), l = Math.abs(s * Math.cos(n)), u = (s = Math.abs(s * Math.sin(n)), 0), h = 0; a <= i[1]; a += o) {
      var c = 1.3 * (p = yr(e({
          value: a
        }), t.font, "center", "top")).width,
        p = 1.3 * p.height;
      u = Math.max(u, c, 7), h = Math.max(h, p, 7)
    }
    n = u / l, l = h / s, isNaN(n) && (n = 1 / 0), isNaN(l) && (l = 1 / 0), s = Math.max(0, Math.floor(Math.min(n, l))), n = zx(d.model), l = d.getExtent();
    var d = n.lastAutoInterval,
      f = n.lastTickCount;
    return null != d && null != f && Math.abs(d - s) <= 1 && Math.abs(f - r) <= 1 && s < d && n.axisExtent0 === l[0] && n.axisExtent1 === l[1] ? s = d : (n.lastTickCount = r, n.lastAutoInterval = s, n.axisExtent0 = l[0], n.axisExtent1 = l[1]), s
  }, gy = Yx;

  function Yx(t, e, n) {
    this.onBand = !1, this.inverse = !1, this.dim = t, this.scale = e, this._extent = n || [0, 0]
  }

  function qx(t, e) {
    e = (t[1] - t[0]) / e / 2, t[0] += e, t[1] -= e
  }
  var jx = 2 * Math.PI,
    Zx = Wa.CMD,
    Kx = ["top", "right", "bottom", "left"];

  function $x(t, e, n, i, r, o, a, s) {
    var l = r - t,
      u = o - e,
      h = (n = n - t, i = i - e, Math.sqrt(n * n + i * i));
    l = (l * (n /= h) + u * (i /= h)) / h, s && (l = Math.min(Math.max(l, 0), 1)), u = a[0] = t + (l *= h) * n, s = a[1] = e + l * i;
    return Math.sqrt((u - r) * (u - r) + (s - o) * (s - o))
  }

  function Qx(t, e, n, i, r, o, a) {
    return n < 0 && (t += n, n = -n), i < 0 && (e += i, i = -i), n = t + n, i = e + i, t = a[0] = Math.min(Math.max(r, t), n), n = a[1] = Math.min(Math.max(o, e), i), Math.sqrt((t - r) * (t - r) + (n - o) * (n - o))
  }
  var Jx = [];

  function tw(t, e, n) {
    for (var i, r, o, a, s, l, u, h, c, p = 0, d = 0, f = 0, g = 0, y = 1 / 0, m = e.data, v = t.x, _ = t.y, x = 0; x < m.length;) {
      var w = m[x++],
        b = (1 === x && (f = p = m[x], g = d = m[x + 1]), y);
      switch (w) {
        case Zx.M:
          p = f = m[x++], d = g = m[x++];
          break;
        case Zx.L:
          b = $x(p, d, m[x], m[x + 1], v, _, Jx, !0), p = m[x++], d = m[x++];
          break;
        case Zx.C:
          b = _n(p, d, m[x++], m[x++], m[x++], m[x++], m[x], m[x + 1], v, _, Jx), p = m[x++], d = m[x++];
          break;
        case Zx.Q:
          b = Mn(p, d, m[x++], m[x++], m[x], m[x + 1], v, _, Jx), p = m[x++], d = m[x++];
          break;
        case Zx.A:
          var S = m[x++],
            M = m[x++],
            T = m[x++],
            I = m[x++],
            C = m[x++],
            k = m[x++],
            D = (x += 1, !!(1 - m[x++])),
            A = Math.cos(C) * T + S,
            L = Math.sin(C) * I + M;
          x <= 1 && (f = A, g = L), L = (A = C) + k, D = D, a = (v - S) * (o = I) / T + S, s = _, l = Jx, c = h = u = void 0, a -= i = S, s -= r = M, h = (a /= u = Math.sqrt(a * a + s * s)) * o + i, c = (s /= u) * o + r, b = Math.abs(A - L) % jx < 1e-4 || ((L = D ? (D = A, A = Ya(L), Ya(D)) : (A = Ya(A), Ya(L))) < A && (L += jx), (D = Math.atan2(s, a)) < 0 && (D += jx), A <= D && D <= L) || A <= D + jx && D + jx <= L ? (l[0] = h, l[1] = c, u - o) : (c = ((D = o * Math.cos(A) + i) - a) * (D - a) + ((h = o * Math.sin(A) + r) - s) * (h - s)) < (i = ((u = o * Math.cos(L) + i) - a) * (u - a) + ((A = o * Math.sin(L) + r) - s) * (A - s)) ? (l[0] = D, l[1] = h, Math.sqrt(c)) : (l[0] = u, l[1] = A, Math.sqrt(i)), p = Math.cos(C + k) * T + S, d = Math.sin(C + k) * I + M;
          break;
        case Zx.R:
          b = Qx(f = p = m[x++], g = d = m[x++], m[x++], m[x++], v, _, Jx);
          break;
        case Zx.Z:
          b = $x(p, d, f, g, v, _, Jx, !0), p = f, d = g
      }
      b < y && (y = b, n.set(Jx[0], Jx[1]))
    }
    return y
  }
  var ew = new Se,
    nw = new Se,
    iw = new Se,
    rw = new Se,
    ow = new Se;

  function aw(t, e) {
    if (t) {
      var n = t.getTextGuideLine(),
        i = t.getTextContent();
      if (i && n) {
        var r = t.textGuideLineConfig || {},
          o = [
            [0, 0],
            [0, 0],
            [0, 0]
          ],
          a = r.candidates || Kx,
          s = i.getBoundingRect().clone(),
          l = (s.applyTransform(i.getComputedTransform()), 1 / 0),
          u = r.anchor,
          h = t.getComputedTransform(),
          c = h && we([], h),
          p = e.get("length2") || 0;
        u && iw.copy(u);
        for (var d, f, g = 0; g < a.length; g++) {
          var y = a[g],
            m = (x = _ = m = void 0, y),
            v = s,
            _ = ew,
            x = rw,
            w = v.width,
            b = v.height;
          switch (m) {
            case "top":
              _.set(v.x + w / 2, v.y - 0), x.set(0, -1);
              break;
            case "bottom":
              _.set(v.x + w / 2, v.y + b + 0), x.set(0, 1);
              break;
            case "left":
              _.set(v.x - 0, v.y + b / 2), x.set(-1, 0);
              break;
            case "right":
              _.set(v.x + w + 0, v.y + b / 2), x.set(1, 0)
          }
          Se.scaleAndAdd(nw, ew, rw, p), nw.transform(c), y = t.getBoundingRect(), (y = u ? u.distance(nw) : t instanceof as ? tw(nw, t.path, iw) : (m = iw, d = Qx((d = y).x, y.y, y.width, y.height, nw.x, nw.y, Jx), m.set(Jx[0], Jx[1]), d)) < l && (l = y, nw.transform(h), iw.transform(h), iw.toArray(o[0]), nw.toArray(o[1]), ew.toArray(o[2]))
        }
        i = o, (r = e.get("minTurnAngle")) <= 180 && 0 < r && (r = r / 180 * Math.PI, ew.fromArray(i[0]), nw.fromArray(i[1]), iw.fromArray(i[2]), Se.sub(rw, ew, nw), Se.sub(ow, iw, nw), e = rw.len(), f = ow.len(), e < .001 || f < .001 || (rw.scale(1 / e), ow.scale(1 / f), e = rw.dot(ow), Math.cos(r) < e && (f = $x(nw.x, nw.y, iw.x, iw.y, ew.x, ew.y, sw, !1), lw.fromArray(sw), lw.scaleAndAdd(ow, f / Math.tan(Math.PI - r)), e = iw.x !== nw.x ? (lw.x - nw.x) / (iw.x - nw.x) : (lw.y - nw.y) / (iw.y - nw.y), isNaN(e) || (e < 0 ? Se.copy(lw, nw) : 1 < e && Se.copy(lw, iw), lw.toArray(i[1]))))), n.setShape({
          points: o
        })
      }
    }
  }
  var sw = [],
    lw = new Se;

  function uw(t, e, n, i) {
    var r = "normal" === n;
    (e = ((n = r ? t : t.ensureState(n)).ignore = e, i.get("smooth"))) && !0 === e && (e = .3), n.shape = n.shape || {}, 0 < e && (n.shape.smooth = e), e = i.getModel("lineStyle").getLineStyle();
    r ? t.useStyle(e) : n.style = e
  }

  function hw(t, e) {
    var n = e.smooth,
      i = e.points;
    if (i)
      if (t.moveTo(i[0][0], i[0][1]), 0 < n && 3 <= i.length) {
        e = Ot(i[0], i[1]);
        var r = Ot(i[1], i[2]);
        e && r ? (n = Math.min(e, r) * n, e = Et([], i[1], i[0], n / e), n = Et([], i[1], i[2], n / r), r = Et([], e, n, .5), t.bezierCurveTo(e[0], e[1], e[0], e[1], r[0], r[1]), t.bezierCurveTo(n[0], n[1], n[0], n[1], i[2][0], i[2][1])) : (t.lineTo(i[1][0], i[1][1]), t.lineTo(i[2][0], i[2][1]))
      } else
        for (var o = 1; o < i.length; o++) t.lineTo(i[o][0], i[o][1])
  }

  function cw(t) {
    for (var e = [], n = 0; n < t.length; n++) {
      var i, r, o, a, s, l, u = t[n];
      u.defaultAttr.ignore || (r = (i = u.label).getComputedTransform(), o = i.getBoundingRect(), a = !r || r[1] < 1e-5 && r[2] < 1e-5, l = i.style.margin || 0, (s = o.clone()).applyTransform(r), s.x -= l / 2, s.y -= l / 2, s.width += l, s.height += l, l = a ? new dh(o, r) : null, e.push({
        label: i,
        labelLine: u.labelLine,
        rect: s,
        localRect: o,
        obb: l,
        priority: u.priority,
        defaultAttr: u.defaultAttr,
        layoutOption: u.computedLayoutOption,
        axisAligned: a,
        transform: r
      }))
    }
    return e
  }

  function pw(t, e, n, i, r, o) {
    var a = t.length;
    if (!(a < 2)) {
      t.sort((function(t, n) {
        return t.rect[e] - n.rect[e]
      }));
      for (var s = 0, l = !1, u = 0, h = 0; h < a; h++) {
        var c, p = t[h],
          d = p.rect;
        (c = d[e] - s) < 0 && (d[e] -= c, p.label[e] -= c, l = !0), u += Math.max(-c, 0), s = d[e] + d[n]
      }
      0 < u && o && x(-u / a, 0, a);
      var f, g, y = t[0],
        m = t[a - 1];
      return v(), f < 0 && w(-f, .8), g < 0 && w(g, .8), v(), _(f, g, 1), _(g, f, -1), v(), f < 0 && b(-f), g < 0 && b(g), l
    }

    function v() {
      f = y.rect[e] - i, g = r - m.rect[e] - m.rect[n]
    }

    function _(t, e, n) {
      t < 0 && (0 < (e = Math.min(e, -t)) ? (x(e * n, 0, a), (e += t) < 0 && w(-e * n, 1)) : w(-t * n, 1))
    }

    function x(n, i, r) {
      0 !== n && (l = !0);
      for (var o = i; o < r; o++) {
        var a = t[o];
        a.rect[e] += n, a.label[e] += n
      }
    }

    function w(i, r) {
      for (var o = [], s = 0, l = 1; l < a; l++) {
        var u = t[l - 1].rect;
        u = Math.max(t[l].rect[e] - u[e] - u[n], 0);
        o.push(u), s += u
      }
      if (s) {
        var h = Math.min(Math.abs(i) / s, r);
        if (0 < i)
          for (l = 0; l < a - 1; l++) x(o[l] * h, 0, l + 1);
        else
          for (l = a - 1; 0 < l; l--) x(-o[l - 1] * h, l, a)
      }
    }

    function b(t) {
      for (var e = t < 0 ? -1 : 1, n = (t = Math.abs(t), Math.ceil(t / (a - 1))), i = 0; i < a - 1; i++)
        if (0 < e ? x(n, 0, i + 1) : x(-n, a - i - 1, a), (t -= n) <= 0) return
    }
  }

  function dw(t) {
    var e = [],
      n = (t.sort((function(t, e) {
        return e.priority - t.priority
      })), new Oe(0, 0, 0, 0));

    function i(t) {
      var e;
      t.ignore || null == (e = t.ensureState("emphasis")).ignore && (e.ignore = !1), t.ignore = !0
    }
    for (var r = 0; r < t.length; r++) {
      for (var o = t[r], a = o.axisAligned, s = o.localRect, l = o.transform, u = o.label, h = o.labelLine, c = (n.copy(o.rect), n.width -= .1, n.height -= .1, n.x += .05, n.y += .05, o.obb), p = !1, d = 0; d < e.length; d++) {
        var f = e[d];
        if (n.intersect(f.rect)) {
          if (a && f.axisAligned) {
            p = !0;
            break
          }
          if (f.obb || (f.obb = new dh(f.localRect, f.transform)), (c = c || new dh(s, l)).intersect(f.obb)) {
            p = !0;
            break
          }
        }
      }
      p ? (i(u), h && i(h)) : (u.attr("ignore", o.defaultAttr.ignore), h && h.attr("ignore", o.defaultAttr.labelGuideIgnore), e.push(o))
    }
  }

  function fw(t, e) {
    var n = t.label;
    e = e && e.getTextGuideLine();
    return {
      dataIndex: t.dataIndex,
      dataType: t.dataType,
      seriesIndex: t.seriesModel.seriesIndex,
      text: t.label.style.text,
      rect: t.hostRect,
      labelRect: t.rect,
      align: n.style.align,
      verticalAlign: n.style.verticalAlign,
      labelLinePoints: function(t) {
        if (t) {
          for (var e = [], n = 0; n < t.length; n++) e.push(t[n].slice());
          return e
        }
      }(e && e.shape.points)
    }
  }
  var gw = ["align", "verticalAlign", "width", "height", "fontSize"],
    yw = new ur,
    mw = So(),
    vw = So();

  function _w(t, e, n) {
    for (var i = 0; i < n.length; i++) {
      var r = n[i];
      null != e[r] && (t[r] = e[r])
    }
  }
  var xw = ["x", "y", "rotation"],
    ww = (bw.prototype.clearLabels = function() {
      this._labelList = [], this._chartViewList = []
    }, bw.prototype._addLabel = function(t, e, n, i, r) {
      var o, a = i.style,
        s = i.__hostTarget.textConfig || {},
        l = i.getComputedTransform(),
        u = i.getBoundingRect().plain(),
        h = ((l = (Oe.applyTransform(u, u, l), l ? yw.setLocalTransform(l) : (yw.x = yw.y = yw.rotation = yw.originX = yw.originY = 0, yw.scaleX = yw.scaleY = 1), yw.rotation = Ya(yw.rotation), i.__hostTarget)) && (o = l.getBoundingRect().plain(), h = l.getComputedTransform(), Oe.applyTransform(o, o, h)), o && l.getTextGuideLine());
      this._labelList.push({
        label: i,
        labelLine: h,
        seriesModel: n,
        dataIndex: t,
        dataType: e,
        layoutOption: r,
        computedLayoutOption: null,
        rect: u,
        hostRect: o,
        priority: o ? o.width * o.height : 0,
        defaultAttr: {
          ignore: i.ignore,
          labelGuideIgnore: h && h.ignore,
          x: yw.x,
          y: yw.y,
          scaleX: yw.scaleX,
          scaleY: yw.scaleY,
          rotation: yw.rotation,
          style: {
            x: a.x,
            y: a.y,
            align: a.align,
            verticalAlign: a.verticalAlign,
            width: a.width,
            height: a.height,
            fontSize: a.fontSize
          },
          cursor: i.cursor,
          attachedPos: s.position,
          attachedRot: s.rotation
        }
      })
    }, bw.prototype.addLabelsOfSeries = function(t) {
      var e = this,
        n = (this._chartViewList.push(t), t.__model),
        i = n.get("labelLayout");
      (G(i) || F(i).length) && t.group.traverse((function(t) {
        if (t.ignore) return !0;
        var r = t.getTextContent();
        t = Us(t);
        r && !r.disableLabelLayout && e._addLabel(t.dataIndex, t.dataType, n, r, i)
      }))
    }, bw.prototype.updateLayoutConfig = function(t) {
      for (var e = t.getWidth(), n = t.getHeight(), i = 0; i < this._labelList.length; i++) {
        var r = this._labelList[i],
          o = r.label,
          a = o.__hostTarget,
          s = r.defaultAttr,
          l = void 0,
          u = (l = G(r.layoutOption) ? r.layoutOption(fw(r, a)) : r.layoutOption, r.computedLayoutOption = l = l || {}, Math.PI / 180),
          h = (a && a.setTextConfig({
            local: !1,
            position: null != l.x || null != l.y ? null : s.attachedPos,
            rotation: null != l.rotate ? l.rotate * u : s.attachedRot,
            offset: [l.dx || 0, l.dy || 0]
          }), !1);
        null != l.x ? (o.x = qr(l.x, e), o.setStyle("x", 0), h = !0) : (o.x = s.x, o.setStyle("x", s.style.x)), null != l.y ? (o.y = qr(l.y, n), o.setStyle("y", 0), h = !0) : (o.y = s.y, o.setStyle("y", s.style.y)), l.labelLinePoints && (c = a.getTextGuideLine()) && (c.setShape({
          points: l.labelLinePoints
        }), h = !1), mw(o).needsUpdateLabelLine = h, o.rotation = null != l.rotate ? l.rotate * u : s.rotation, o.scaleX = s.scaleX, o.scaleY = s.scaleY;
        for (var c, p = 0; p < gw.length; p++) {
          var d = gw[p];
          o.setStyle(d, (null != l[d] ? l : s.style)[d])
        }
        l.draggable ? (o.draggable = !0, o.cursor = "move", a && (c = r.seriesModel, null != r.dataIndex && (c = r.seriesModel.getData(r.dataType).getItemModel(r.dataIndex)), o.on("drag", function(t, e) {
          return function() {
            aw(t, e)
          }
        }(a, c.getModel("labelLine"))))) : (o.off("drag"), o.cursor = s.cursor)
      }
    }, bw.prototype.layout = function(t) {
      var e = t.getWidth(),
        n = (t = t.getHeight(), cw(this._labelList)),
        i = B(n, (function(t) {
          return "shiftX" === t.layoutOption.moveOverlap
        })),
        r = B(n, (function(t) {
          return "shiftY" === t.layoutOption.moveOverlap
        }));
      pw(i, "x", "width", 0, e, void 0), pw(r, "y", "height", 0, t, void 0), dw(B(n, (function(t) {
        return t.layoutOption.hideOverlap
      })))
    }, bw.prototype.processLabelsOverall = function() {
      var t = this;
      N(this._chartViewList, (function(e) {
        var n = e.__model,
          i = e.ignoreLabelLineUpdate,
          r = n.isAnimationEnabled();
        e.group.traverse((function(e) {
          if (e.ignore && !e.forceLabelAnimation) return !0;
          var o = !i,
            a = e.getTextContent();
          (o = !o && a ? mw(a).needsUpdateLabelLine : o) && t._updateLabelLine(e, n), r && t._animateLabels(e, n)
        }))
      }))
    }, bw.prototype._updateLabelLine = function(t, e) {
      var n = t.getTextContent(),
        i = (r = Us(t)).dataIndex;
      if (n && null != i) {
        e = (n = e.getData(r.dataType)).getItemModel(i);
        var r = {},
          o = (i = ((i = n.getItemVisual(i, "style")) && (n = n.getVisual("drawType"), r.stroke = i[n]), e.getModel("labelLine")), t),
          a = function(t, e) {
            for (var n = {
                normal: t.getModel(e = e || "labelLine")
              }, i = 0; i < Zs.length; i++) {
              var r = Zs[i];
              n[r] = t.getModel([r, e])
            }
            return n
          }(e),
          s = (n = r, o.getTextGuideLine()),
          l = o.getTextContent();
        if (l) {
          for (var u = (e = a.normal).get("show"), h = l.ignore, c = 0; c < Ks.length; c++) {
            var p, d = Ks[c],
              f = a[d],
              g = "normal" === d;
            f && (p = f.get("show"), (g ? h : nt(l.states[d] && l.states[d].ignore, h)) || !nt(p, u) ? ((p = g ? s : s && s.states[d]) && (p.ignore = !0), s && uw(s, !0, d, f)) : (s || (s = new Eu, o.setTextGuideLine(s), g || !h && u || uw(s, !0, "normal", a.normal), o.stateProxy && (s.stateProxy = o.stateProxy)), uw(s, !1, d, f)))
          }
          s && (D(s.style, n), s.style.fill = null, n = e.get("showAbove"), (o.textGuideLineConfig = o.textGuideLineConfig || {}).showAbove = n || !1, s.buildPath = hw)
        } else s && o.removeTextGuideLine();
        aw(t, i)
      }
    }, bw.prototype._animateLabels = function(t, e) {
      var n, i, r, o, a, s = t.getTextContent(),
        l = t.getTextGuideLine();
      !s || !t.forceLabelAnimation && (s.ignore || s.invisible || t.disableLabelAnimation || bh(t)) || (o = (r = mw(s)).oldLayout, n = (i = Us(t)).dataIndex, a = {
        x: s.x,
        y: s.y,
        rotation: s.rotation
      }, i = e.getData(i.dataType), o ? (s.attr(o), (t = t.prevStates) && (0 <= L(t, "select") && s.attr(r.oldLayoutSelect), 0 <= L(t, "emphasis")) && s.attr(r.oldLayoutEmphasis), xh(s, a, e, n)) : (s.attr(a), hc(s).valueAnimation || (t = nt(s.style.opacity, 1), s.style.opacity = 0, wh(s, {
        style: {
          opacity: t
        }
      }, e, n))), r.oldLayout = a, s.states.select && (_w(t = r.oldLayoutSelect = {}, a, xw), _w(t, s.states.select, xw)), s.states.emphasis && (_w(t = r.oldLayoutEmphasis = {}, a, xw), _w(t, s.states.emphasis, xw)), pc(s, n, i, e, e)), !l || l.ignore || l.invisible || (o = (r = vw(l)).oldLayout, a = {
        points: l.shape.points
      }, o ? (l.attr({
        shape: o
      }), xh(l, {
        shape: a
      }, e)) : (l.setShape(a), l.style.strokePercent = 0, wh(l, {
        style: {
          strokePercent: 1
        }
      }, e)), r.oldLayout = a)
    }, bw);

  function bw() {
    this._labelList = [], this._chartViewList = []
  }
  var Sw = So();

  function Mw(t) {
    t.registerUpdateLifecycle("series:beforeupdate", (function(t, e, n) {
      (Sw(e).labelManager || (Sw(e).labelManager = new ww)).clearLabels()
    })), t.registerUpdateLifecycle("series:layoutlabels", (function(t, e, n) {
      var i = Sw(e).labelManager;
      n.updatedSeries.forEach((function(t) {
        i.addLabelsOfSeries(e.getViewOfSeriesModel(t))
      })), i.updateLayoutConfig(e), i.layout(e), i.processLabelsOverall()
    }))
  }

  function Tw(t, e, n) {
    var i = c.createCanvas(),
      r = e.getWidth(),
      o = (e = e.getHeight(), i.style);
    return o && (o.position = "absolute", o.left = "0", o.top = "0", o.width = r + "px", o.height = e + "px", i.setAttribute("data-zr-dom-id", t)), i.width = r * n, i.height = e * n, i
  }
  _x(Mw), i(kw, Iw = Ut), kw.prototype.getElementCount = function() {
    return this.__endIndex - this.__startIndex
  }, kw.prototype.afterBrush = function() {
    this.__prevStartIndex = this.__startIndex, this.__prevEndIndex = this.__endIndex
  }, kw.prototype.initContext = function() {
    this.ctx = this.dom.getContext("2d"), this.ctx.dpr = this.dpr
  }, kw.prototype.setUnpainted = function() {
    this.__firstTimePaint = !0
  }, kw.prototype.createBackBuffer = function() {
    var t = this.dpr;
    this.domBack = Tw("back-" + this.id, this.painter, t), this.ctxBack = this.domBack.getContext("2d"), 1 !== t && this.ctxBack.scale(t, t)
  }, kw.prototype.createRepaintRects = function(t, e, n, i) {
    if (this.__firstTimePaint) return this.__firstTimePaint = !1, null;
    var r = [],
      o = this.maxRepaintRectCount,
      a = !1,
      s = new Oe(0, 0, 0, 0);

    function l(t) {
      if (t.isFinite() && !t.isZero())
        if (0 === r.length)(e = new Oe(0, 0, 0, 0)).copy(t), r.push(e);
        else {
          for (var e, n = !1, i = 1 / 0, l = 0, u = 0; u < r.length; ++u) {
            var h = r[u];
            if (h.intersect(t)) {
              var c = new Oe(0, 0, 0, 0);
              c.copy(h), c.union(t), r[u] = c, n = !0;
              break
            }
            a && (s.copy(t), s.union(h), c = t.width * t.height, h = h.width * h.height, (h = s.width * s.height - c - h) < i) && (i = h, l = u)
          }
          a && (r[l].union(t), n = !0), n || ((e = new Oe(0, 0, 0, 0)).copy(t), r.push(e)), a = a || r.length >= o
        }
    }
    for (var u, h = this.__startIndex; h < this.__endIndex; ++h)(c = t[h]) && (d = c.shouldBePainted(n, i, !0, !0), (p = c.__isRendered && (1 & c.__dirty || !d) ? c.getPrevPaintRect() : null) && l(p), u = d && (1 & c.__dirty || !c.__isRendered) ? c.getPaintRect() : null) && l(u);
    for (h = this.__prevStartIndex; h < this.__prevEndIndex; ++h) {
      var c, p, d = (c = e[h]) && c.shouldBePainted(n, i, !0, !0);
      !c || d && c.__zr || !c.__isRendered || (p = c.getPrevPaintRect()) && l(p)
    }
    do {
      var f = !1;
      for (h = 0; h < r.length;)
        if (r[h].isZero()) r.splice(h, 1);
        else {
          for (var g = h + 1; g < r.length;) r[h].intersect(r[g]) ? (f = !0, r[h].union(r[g]), r.splice(g, 1)) : g++;
          h++
        }
    } while (f);
    return this._paintRects = r
  }, kw.prototype.debugGetPaintRects = function() {
    return (this._paintRects || []).slice()
  }, kw.prototype.resize = function(t, e) {
    var n = this.dpr,
      i = this.dom,
      r = i.style,
      o = this.domBack;
    r && (r.width = t + "px", r.height = e + "px"), i.width = t * n, i.height = e * n, o && (o.width = t * n, o.height = e * n, 1 !== n) && this.ctxBack.scale(n, n)
  }, kw.prototype.clear = function(t, e, n) {
    var i = this.dom,
      r = this.ctx,
      o = i.width,
      a = i.height,
      s = (e = e || this.clearColor, this.motionBlur && !t),
      l = this.lastFrameAlpha,
      u = this.dpr,
      h = this,
      c = (s && (this.domBack || this.createBackBuffer(), this.ctxBack.globalCompositeOperation = "copy", this.ctxBack.drawImage(i, 0, 0, o / u, a / u)), this.domBack);

    function p(t, n, i, o) {
      var a;
      r.clearRect(t, n, i, o), e && "transparent" !== e && (a = void 0, $(e) ? (a = (e.global || e.__width === i && e.__height === o) && e.__canvasGradient || Wy(r, e, {
        x: 0,
        y: 0,
        width: i,
        height: o
      }), e.__canvasGradient = a, e.__width = i, e.__height = o) : Q(e) && (e.scaleX = e.scaleX || u, e.scaleY = e.scaleY || u, a = Qy(r, e, {
        dirty: function() {
          h.setUnpainted(), h.painter.refresh()
        }
      })), r.save(), r.fillStyle = a || e, r.fillRect(t, n, i, o), r.restore()), s && (r.save(), r.globalAlpha = l, r.drawImage(c, t, n, i, o), r.restore())
    }!n || s ? p(0, 0, o, a) : n.length && N(n, (function(t) {
      p(t.x * u, t.y * u, t.width * u, t.height * u)
    }))
  };
  var Iw, Cw = kw;

  function kw(t, e, n) {
    var i, r = Iw.call(this) || this;
    return (t = (r.motionBlur = !1, r.lastFrameAlpha = .7, r.dpr = 1, r.virtual = !1, r.config = {}, r.incremental = !1, r.zlevel = 0, r.maxRepaintRectCount = 5, r.__dirty = !0, r.__firstTimePaint = !0, r.__used = !1, r.__drawIndex = 0, r.__startIndex = 0, r.__endIndex = 0, r.__prevStartIndex = null, r.__prevEndIndex = null, n = n || tr, "string" == typeof t ? i = Tw(t, e, n) : q(t) && (t = (i = t).id), r.id = t, (r.dom = i).style)) && (_t(i), i.onselectstart = function() {
      return !1
    }, t.padding = "0", t.margin = "0", t.borderWidth = "0"), r.painter = e, r.dpr = n, r
  }
  var Dw = 314159;
  Lw.prototype.getType = function() {
    return "canvas"
  }, Lw.prototype.isSingleCanvas = function() {
    return this._singleCanvas
  }, Lw.prototype.getViewportRoot = function() {
    return this._domRoot
  }, Lw.prototype.getViewportRootOffset = function() {
    var t = this.getViewportRoot();
    if (t) return {
      offsetLeft: t.offsetLeft || 0,
      offsetTop: t.offsetTop || 0
    }
  }, Lw.prototype.refresh = function(t) {
    var e = this.storage.getDisplayList(!0),
      n = this._prevDisplayList,
      i = this._zlevelList;
    this._redrawId = Math.random(), this._paintList(e, n, t, this._redrawId);
    for (var r = 0; r < i.length; r++) {
      var o, a = i[r];
      !(a = this._layers[a]).__builtin__ && a.refresh && (o = 0 === r ? this._backgroundColor : null, a.refresh(o))
    }
    return this._opts.useDirtyRect && (this._prevDisplayList = e.slice()), this
  }, Lw.prototype.refreshHover = function() {
    this._paintHoverList(this.storage.getDisplayList(!1))
  }, Lw.prototype._paintHoverList = function(t) {
    var e = t.length,
      n = this._hoverlayer;
    if (n && n.clear(), e) {
      for (var i, r = {
          inHover: !0,
          viewWidth: this._width,
          viewHeight: this._height
        }, o = 0; o < e; o++) {
        var a = t[o];
        a.__inHover && (n = n || (this._hoverlayer = this.getLayer(1e5)), i || (i = n.ctx).save(), sm(i, a, r, o === e - 1))
      }
      i && i.restore()
    }
  }, Lw.prototype.getHoverLayer = function() {
    return this.getLayer(1e5)
  }, Lw.prototype.paintOne = function(t, e) {
    am(t, e)
  }, Lw.prototype._paintList = function(t, e, n, i) {
    var r, o, a;
    this._redrawId === i && (n = n || !1, this._updateLayerStatus(t), r = (o = this._doPaintList(t, e, n)).finished, o = o.needsRefreshHover, this._needsManuallyCompositing && this._compositeManually(), o && this._paintHoverList(t), r ? this.eachLayer((function(t) {
      t.afterBrush && t.afterBrush()
    })) : (a = this, rn((function() {
      a._paintList(t, e, n, i)
    }))))
  }, Lw.prototype._compositeManually = function() {
    var t = this.getLayer(Dw).ctx,
      e = this._domRoot.width,
      n = this._domRoot.height;
    t.clearRect(0, 0, e, n), this.eachBuiltinLayer((function(i) {
      i.virtual && t.drawImage(i.dom, 0, 0, e, n)
    }))
  }, Lw.prototype._doPaintList = function(t, e, n) {
    for (var i = this, r = [], a = this._opts.useDirtyRect, s = 0; s < this._zlevelList.length; s++) {
      var l = this._zlevelList[s];
      (l = this._layers[l]).__builtin__ && l !== this._hoverlayer && (l.__dirty || n) && r.push(l)
    }
    for (var u = !0, h = !1, c = function(o) {
        function s(e) {
          var n = {
            inHover: !1,
            allClipped: !1,
            prevEl: null,
            viewWidth: i._width,
            viewHeight: i._height
          };
          for (c = y; c < d.__endIndex; c++) {
            var r = t[c];
            if (r.__inHover && (h = !0), i._doPaintEl(r, d, a, e, n, c === d.__endIndex - 1), m && 15 < Date.now() - v) break
          }
          n.prevElClipPaths && f.restore()
        }
        var l, c, d = r[o],
          f = d.ctx,
          g = a && d.createRepaintRects(t, e, p._width, p._height),
          y = n ? d.__startIndex : d.__drawIndex,
          m = !n && d.incremental && Date.now,
          v = m && Date.now();
        o = d.zlevel === p._zlevelList[0] ? p._backgroundColor : null;
        if (d.__startIndex !== d.__endIndex && (y !== d.__startIndex || (l = t[y]).incremental && l.notClear && !n) || d.clear(!1, o, g), -1 === y && (console.error("For some unknown reason. drawIndex is -1"), y = d.__startIndex), g)
          if (0 === g.length) c = d.__endIndex;
          else
            for (var _ = p.dpr, x = 0; x < g.length; ++x) {
              var w = g[x];
              f.save(), f.beginPath(), f.rect(w.x * _, w.y * _, w.width * _, w.height * _), f.clip(), s(w), f.restore()
            } else f.save(), s(), f.restore();
        d.__drawIndex = c, d.__drawIndex < d.__endIndex && (u = !1)
      }, p = this, d = 0; d < r.length; d++) c(d);
    return o.wxa && N(this._layers, (function(t) {
      t && t.ctx && t.ctx.draw && t.ctx.draw()
    })), {
      finished: u,
      needsRefreshHover: h
    }
  }, Lw.prototype._doPaintEl = function(t, e, n, i, r, o) {
    e = e.ctx, n ? (n = t.getPaintRect(), (!i || n && n.intersect(i)) && (sm(e, t, r, o), t.setPrevPaintRect(n))) : sm(e, t, r, o)
  }, Lw.prototype.getLayer = function(t, e) {
    this._singleCanvas && !this._needsManuallyCompositing && (t = Dw);
    var n = this._layers[t];
    return n || ((n = new Cw("zr_" + t, this, this.dpr)).zlevel = t, n.__builtin__ = !0, this._layerConfig[t] ? C(n, this._layerConfig[t], !0) : this._layerConfig[t - .01] && C(n, this._layerConfig[t - .01], !0), e && (n.virtual = e), this.insertLayer(t, n), n.initContext()), n
  }, Lw.prototype.insertLayer = function(t, e) {
    var n, i = this._layers,
      r = this._zlevelList,
      o = r.length,
      a = this._domRoot,
      s = null,
      l = -1;
    if (!i[t] && (n = e) && (n.__builtin__ || "function" == typeof n.resize && "function" == typeof n.refresh)) {
      if (0 < o && t > r[0]) {
        for (l = 0; l < o - 1 && !(r[l] < t && r[l + 1] > t); l++);
        s = i[r[l]]
      }
      r.splice(l + 1, 0, t), (i[t] = e).virtual || (s ? (n = s.dom).nextSibling ? a.insertBefore(e.dom, n.nextSibling) : a.appendChild(e.dom) : a.firstChild ? a.insertBefore(e.dom, a.firstChild) : a.appendChild(e.dom)), e.painter || (e.painter = this)
    }
  }, Lw.prototype.eachLayer = function(t, e) {
    for (var n = this._zlevelList, i = 0; i < n.length; i++) {
      var r = n[i];
      t.call(e, this._layers[r], r)
    }
  }, Lw.prototype.eachBuiltinLayer = function(t, e) {
    for (var n = this._zlevelList, i = 0; i < n.length; i++) {
      var r = n[i],
        o = this._layers[r];
      o.__builtin__ && t.call(e, o, r)
    }
  }, Lw.prototype.eachOtherLayer = function(t, e) {
    for (var n = this._zlevelList, i = 0; i < n.length; i++) {
      var r = n[i],
        o = this._layers[r];
      o.__builtin__ || t.call(e, o, r)
    }
  }, Lw.prototype.getLayers = function() {
    return this._layers
  }, Lw.prototype._updateLayerStatus = function(t) {
    function e(t) {
      r && (r.__endIndex !== t && (r.__dirty = !0), r.__endIndex = t)
    }
    if (this.eachBuiltinLayer((function(t, e) {
        t.__dirty = t.__used = !1
      })), this._singleCanvas)
      for (var n = 1; n < t.length; n++)
        if ((s = t[n]).zlevel !== t[n - 1].zlevel || s.incremental) {
          this._needsManuallyCompositing = !0;
          break
        } for (var i, r = null, o = 0, a = 0; a < t.length; a++) {
      var s, l = (s = t[a]).zlevel,
        u = void 0;
      i !== l && (i = l, o = 0), s.incremental ? ((u = this.getLayer(l + .001, this._needsManuallyCompositing)).incremental = !0, o = 1) : u = this.getLayer(l + (0 < o ? .01 : 0), this._needsManuallyCompositing), u.__builtin__ || T("ZLevel " + l + " has been used by unkown layer " + u.id), u !== r && (u.__used = !0, u.__startIndex !== a && (u.__dirty = !0), u.__startIndex = a, u.incremental ? u.__drawIndex = -1 : u.__drawIndex = a, e(a), r = u), 1 & s.__dirty && !s.__inHover && (u.__dirty = !0, u.incremental) && u.__drawIndex < 0 && (u.__drawIndex = a)
    }
    e(a), this.eachBuiltinLayer((function(t, e) {
      !t.__used && 0 < t.getElementCount() && (t.__dirty = !0, t.__startIndex = t.__endIndex = t.__drawIndex = 0), t.__dirty && t.__drawIndex < 0 && (t.__drawIndex = t.__startIndex)
    }))
  }, Lw.prototype.clear = function() {
    return this.eachBuiltinLayer(this._clearLayer), this
  }, Lw.prototype._clearLayer = function(t) {
    t.clear()
  }, Lw.prototype.setBackgroundColor = function(t) {
    this._backgroundColor = t, N(this._layers, (function(t) {
      t.setUnpainted()
    }))
  }, Lw.prototype.configLayer = function(t, e) {
    if (e) {
      var n = this._layerConfig;
      n[t] ? C(n[t], e, !0) : n[t] = e;
      for (var i = 0; i < this._zlevelList.length; i++) {
        var r = this._zlevelList[i];
        r !== t && r !== t + .01 || C(this._layers[r], n[t], !0)
      }
    }
  }, Lw.prototype.delLayer = function(t) {
    var e = this._layers,
      n = this._zlevelList,
      i = e[t];
    i && (i.dom.parentNode.removeChild(i.dom), delete e[t], n.splice(L(n, t), 1))
  }, Lw.prototype.resize = function(t, e) {
    if (this._domRoot.style) {
      var n = this._domRoot,
        i = (n.style.display = "none", this._opts),
        r = this.root;
      if (null != t && (i.width = t), null != e && (i.height = e), t = Uy(r, 0, i), e = Uy(r, 1, i), n.style.display = "", this._width !== t || e !== this._height) {
        for (var o in n.style.width = t + "px", n.style.height = e + "px", this._layers) this._layers.hasOwnProperty(o) && this._layers[o].resize(t, e);
        this.refresh(!0)
      }
      this._width = t, this._height = e
    } else {
      if (null == t || null == e) return;
      this._width = t, this._height = e, this.getLayer(Dw).resize(t, e)
    }
    return this
  }, Lw.prototype.clearLayer = function(t) {
    (t = this._layers[t]) && t.clear()
  }, Lw.prototype.dispose = function() {
    this.root.innerHTML = "", this.root = this.storage = this._domRoot = this._layers = null
  }, Lw.prototype.getRenderedCanvas = function(t) {
    if (this._singleCanvas && !this._compositeManually) return this._layers[Dw].dom;
    var e = new Cw("image", this, (t = t || {}).pixelRatio || this.dpr),
      n = (e.initContext(), e.clear(!1, t.backgroundColor || this._backgroundColor), e.ctx);
    if (t.pixelRatio <= this.dpr) {
      this.refresh();
      var i = e.dom.width,
        r = e.dom.height;
      this.eachLayer((function(t) {
        t.__builtin__ ? n.drawImage(t.dom, 0, 0, i, r) : t.renderToCanvas && (n.save(), t.renderToCanvas(n), n.restore())
      }))
    } else
      for (var o = {
          inHover: !1,
          viewWidth: this._width,
          viewHeight: this._height
        }, a = this.storage.getDisplayList(!0), s = 0, l = a.length; s < l; s++) {
        var u = a[s];
        sm(n, u, o, s === l - 1)
      }
    return e.dom
  }, Lw.prototype.getWidth = function() {
    return this._width
  }, Lw.prototype.getHeight = function() {
    return this._height
  };
  var Aw = Lw;

  function Lw(t, e, n, i) {
    this.type = "canvas", this._zlevelList = [], this._prevDisplayList = [], this._layers = {}, this._layerConfig = {}, this._needsManuallyCompositing = !1, this.type = "canvas";
    var r = !t.nodeName || "CANVAS" === t.nodeName.toUpperCase();
    this._opts = n = k({}, n || {}), this.dpr = n.devicePixelRatio || tr, this._singleCanvas = r, (this.root = t).style && (_t(t), t.innerHTML = ""), this.storage = e;
    e = this._zlevelList;
    var o, a, s = (this._prevDisplayList = [], this._layers);
    r ? (o = (r = t).width, a = r.height, null != n.width && (o = n.width), null != n.height && (a = n.height), this.dpr = n.devicePixelRatio || 1, r.width = o * this.dpr, r.height = a * this.dpr, this._width = o, this._height = a, (o = new Cw(r, this, this.dpr)).__builtin__ = !0, o.initContext(), (s[Dw] = o).zlevel = Dw, e.push(Dw), this._domRoot = t) : (this._width = Uy(t, 0, n), this._height = Uy(t, 1, n), o = this._domRoot = (a = this._width, r = this._height, (s = document.createElement("div")).style.cssText = ["position:relative", "width:" + a + "px", "height:" + r + "px", "padding:0", "margin:0", "border-width:0"].join(";") + ";", s), t.appendChild(o))
  }
  i(Rw, Pw = Tp), Rw.prototype.init = function(t, e, n) {
    Pw.prototype.init.call(this, t, e, n), this._sourceManager = new Kf(this), Qf(this)
  }, Rw.prototype.mergeOption = function(t, e) {
    Pw.prototype.mergeOption.call(this, t, e), Qf(this)
  }, Rw.prototype.optionUpdated = function() {
    this._sourceManager.dirty()
  }, Rw.prototype.getSourceManager = function() {
    return this._sourceManager
  }, Rw.type = "dataset", Rw.defaultOption = {
    seriesLayoutBy: Ep
  };
  var Pw, Ow = Rw;

  function Rw() {
    var t = null !== Pw && Pw.apply(this, arguments) || this;
    return t.type = "dataset", t
  }
  i(zw, Nw = kg), zw.type = "dataset";
  var Nw, Ew = zw;

  function zw() {
    var t = null !== Nw && Nw.apply(this, arguments) || this;
    return t.type = "dataset", t
  }

  function Bw(t) {
    t.registerComponentModel(Ow), t.registerComponentView(Ew)
  }
  _x([function(t) {
    t.registerPainter("canvas", Aw)
  }, Bw]), _x(Mw);
  var Fw = {
      average: function(t) {
        for (var e = 0, n = 0, i = 0; i < t.length; i++) isNaN(t[i]) || (e += t[i], n++);
        return 0 === n ? NaN : e / n
      },
      sum: function(t) {
        for (var e = 0, n = 0; n < t.length; n++) e += t[n] || 0;
        return e
      },
      max: function(t) {
        for (var e = -1 / 0, n = 0; n < t.length; n++) t[n] > e && (e = t[n]);
        return isFinite(e) ? e : NaN
      },
      min: function(t) {
        for (var e = 1 / 0, n = 0; n < t.length; n++) t[n] < e && (e = t[n]);
        return isFinite(e) ? e : NaN
      },
      minmax: function(t) {
        for (var e = -1 / 0, n = -1 / 0, i = 0; i < t.length; i++) {
          var r = t[i],
            o = Math.abs(r);
          e < o && (e = o, n = r)
        }
        return isFinite(n) ? n : NaN
      },
      nearest: function(t) {
        return t[0]
      }
    },
    Vw = function(t) {
      return Math.round(t.length / 2)
    };

  function Hw(t) {
    return {
      seriesType: t,
      reset: function(t, e, n) {
        var i, r = t.getData(),
          o = t.get("sampling"),
          a = t.coordinateSystem,
          s = r.count();
        10 < s && "cartesian2d" === a.type && o && (i = a.getBaseAxis(), a = a.getOtherAxis(i), i = i.getExtent(), n = n.getDevicePixelRatio(), i = Math.abs(i[1] - i[0]) * (n || 1), n = Math.round(s / i), isFinite(n)) && 1 < n && ("lttb" === o && t.setData(r.lttbDownSample(r.mapDimension(a.dim), 1 / n)), s = void 0, U(o) ? s = Fw[o] : G(o) && (s = o), s) && t.setData(r.downSample(r.mapDimension(a.dim), 1 / n, s, Vw))
      }
    }
  }
  i(Gw, Ww = _g), Gw.prototype.getInitialData = function(t, e) {
    return h_(null, this, {
      useEncodeDefaulter: !0
    })
  }, Gw.prototype.getMarkerPosition = function(t, e, n) {
    var i, r, o = this.coordinateSystem;
    return o && o.clampData ? (i = o.clampData(t), r = o.dataToPoint(i), n ? N(o.getAxes(), (function(t, n) {
      if ("category" === t.type && null != e) {
        var o = t.getTicksCoords(),
          a = t.getTickModel().get("alignWithLabel"),
          s = i[n],
          l = "x1" === e[n] || "y1" === e[n];
        if (l && !a && (s += 1), !(o.length < 2))
          if (2 === o.length) r[n] = t.toGlobalCoord(t.getExtent()[l ? 1 : 0]);
          else {
            for (var u = void 0, h = void 0, c = 1, p = 0; p < o.length; p++) {
              var d = o[p].coord,
                f = p === o.length - 1 ? o[p - 1].tickValue + c : o[p].tickValue;
              if (f === s) {
                h = d;
                break
              }
              if (f < s) u = d;
              else if (null != u && s < f) {
                h = (d + u) / 2;
                break
              }
              1 === p && (c = f - o[0].tickValue)
            }
            null == h && (h = (u ? o[o.length - 1] : o[0]).coord), r[n] = t.toGlobalCoord(h)
          }
      }
    })) : (n = (t = this.getData()).getLayout("offset"), t = t.getLayout("size"), o = o.getBaseAxis().isHorizontal() ? 0 : 1, r[o] += n + t / 2), r) : [NaN, NaN]
  }, Gw.type = "series.__base_bar__", Gw.defaultOption = {
    z: 2,
    coordinateSystem: "cartesian2d",
    legendHoverLink: !0,
    barMinHeight: 0,
    barMinAngle: 0,
    large: !1,
    largeThreshold: 400,
    progressive: 3e3,
    progressiveChunkMode: "mod"
  };
  var Ww;
  Vh = Gw;

  function Gw() {
    var t = null !== Ww && Ww.apply(this, arguments) || this;
    return t.type = Gw.type, t
  }
  _g.registerClass(Vh), i(Yw, Uw = Vh), Yw.prototype.getInitialData = function() {
    return h_(null, this, {
      useEncodeDefaulter: !0,
      createInvertedIndices: !!this.get("realtimeSort", !0) || null
    })
  }, Yw.prototype.getProgressive = function() {
    return !!this.get("large") && this.get("progressive")
  }, Yw.prototype.getProgressiveThreshold = function() {
    var t = this.get("progressiveThreshold"),
      e = this.get("largeThreshold");
    return t < e ? e : t
  }, Yw.prototype.brushSelector = function(t, e, n) {
    return n.rect(e.getItemLayout(t))
  }, Yw.type = "series.bar", Yw.dependencies = ["grid", "polar"], Yw.defaultOption = (Eo = {
    clip: !0,
    roundCap: !1,
    showBackground: !1,
    backgroundStyle: {
      color: "rgba(180, 180, 180, 0.2)",
      borderColor: null,
      borderWidth: 0,
      borderType: "solid",
      borderRadius: 0,
      shadowBlur: 0,
      shadowColor: null,
      shadowOffsetX: 0,
      shadowOffsetY: 0,
      opacity: 1
    },
    select: {
      itemStyle: {
        borderColor: "#212121"
      }
    },
    realtimeSort: !1
  }, C(C({}, Vh.defaultOption, !0), Eo, !0));
  var Uw, Xw = Yw;

  function Yw() {
    var t = null !== Uw && Uw.apply(this, arguments) || this;
    return t.type = Yw.type, t
  }

  function qw(t, e, n, i, r) {
    var o = (l = t.getArea()).x,
      a = l.y,
      s = l.width,
      l = l.height,
      u = n.get(["lineStyle", "width"]) || 2,
      h = (o -= u / 2, a -= u / 2, s += u, l += u, s = Math.ceil(s), o !== Math.floor(o) && (o = Math.floor(o), s++), new Ms({
        shape: {
          x: o,
          y: a,
          width: s,
          height: l
        }
      }));
    return e && (e = (u = t.getBaseAxis()).isHorizontal(), t = u.inverse, e ? (t && (h.shape.x += s), h.shape.width = 0) : (t || (h.shape.y += l), h.shape.height = 0), u = G(r) ? function(t) {
      r(t, h)
    } : null, wh(h, {
      shape: {
        width: s,
        height: l,
        x: o,
        y: a
      }
    }, n, null, i, u)), h
  }

  function jw(t, e, n) {
    var i = t.getArea(),
      r = jr(i.r0, 1),
      o = jr(i.r, 1),
      a = new Su({
        shape: {
          cx: jr(t.cx, 1),
          cy: jr(t.cy, 1),
          r0: r,
          r: o,
          startAngle: i.startAngle,
          endAngle: i.endAngle,
          clockwise: i.clockwise
        }
      });
    return e && ("angle" === t.getBaseAxis().dim ? a.shape.endAngle = i.startAngle : a.shape.r = r, wh(a, {
      shape: {
        endAngle: i.endAngle,
        r: o
      }
    }, n)), a
  }
  var Zw, Kw = function() {
      this.cx = 0, this.cy = 0, this.r0 = 0, this.r = 0, this.startAngle = 0, this.endAngle = 2 * Math.PI, this.clockwise = !0
    },
    $w = (i(Qw, Zw = as), Qw.prototype.getDefaultShape = function() {
      return new Kw
    }, Qw.prototype.buildPath = function(t, e) {
      var n = e.cx,
        i = e.cy,
        r = Math.max(e.r0 || 0, 0),
        o = Math.max(e.r, 0),
        a = .5 * (o - r),
        s = r + a,
        l = e.startAngle,
        u = e.endAngle,
        h = (e = e.clockwise, 2 * Math.PI),
        c = e ? u - l < h : l - u < h,
        p = (h = (c || (l = u - (e ? h : -h)), Math.cos(l)), Math.sin(l)),
        d = Math.cos(u),
        f = Math.sin(u);
      c ? (t.moveTo(h * r + n, p * r + i), t.arc(h * s + n, p * s + i, a, -Math.PI + l, l, !e)) : t.moveTo(h * o + n, p * o + i), t.arc(n, i, o, l, u, !e), t.arc(d * s + n, f * s + i, a, u - 2 * Math.PI, u - Math.PI, !e), 0 !== r && t.arc(n, i, r, u, l, e)
    }, Qw);

  function Qw(t) {
    return (t = Zw.call(this, t) || this).type = "sausage", t
  }

  function Jw(t, e) {
    return t.type === e
  }

  function tb(t, e) {
    var n, i = t.mapDimensionsAll("defaultedLabel"),
      r = i.length;
    if (1 === r) return null != (n = of(t, e, i[0])) ? n + "" : null;
    if (r) {
      for (var o = [], a = 0; a < i.length; a++) o.push(of(t, e, i[a]));
      return o.join(" ")
    }
  }

  function eb(t, e) {
    var n = t.mapDimensionsAll("defaultedLabel");
    if (!W(e)) return e + "";
    for (var i = [], r = 0; r < n.length; r++) {
      var o = t.getDimensionIndex(n[r]);
      0 <= o && i.push(e[o])
    }
    return i.join(" ")
  }

  function nb(t, e, n) {
    return e * Math.sin(t) * (n ? -1 : 1)
  }

  function ib(t, e, n) {
    return e * Math.cos(t) * (n ? 1 : -1)
  }
  var rb = Math.max,
    ob = Math.min;
  i(lb, ab = Og), lb.prototype.render = function(t, e, n, i) {
    this._model = t, this._removeOnRenderedListener(n), this._updateDrawMode(t);
    var r = t.get("coordinateSystem");
    "cartesian2d" !== r && "polar" !== r || (this._progressiveEls = null, this._isLargeDraw ? this._renderLarge(t, e, n) : this._renderNormal(t, e, n, i))
  }, lb.prototype.incrementalPrepareRender = function(t) {
    this._clear(), this._updateDrawMode(t), this._updateLargeClip(t)
  }, lb.prototype.incrementalRender = function(t, e) {
    this._progressiveEls = [], this._incrementalRenderLarge(t, e)
  }, lb.prototype.eachRendered = function(t) {
    $h(this._progressiveEls || this.group, t)
  }, lb.prototype._updateDrawMode = function(t) {
    t = t.pipelineContext.large, null != this._isLargeDraw && t === this._isLargeDraw || (this._isLargeDraw = t, this._clear())
  }, lb.prototype._renderNormal = function(t, e, n, i) {
    var r, o, a, s = this.group,
      l = t.getData(),
      u = this._data,
      h = t.coordinateSystem,
      c = h.getBaseAxis(),
      p = ("cartesian2d" === h.type ? r = c.isHorizontal() : "polar" === h.type && (r = "angle" === c.dim), t.isAnimationEnabled() ? t : null),
      d = function(t, e) {
        t = t.get("realtimeSort", !0);
        var n = e.getBaseAxis();
        if (t && "category" === n.type && "cartesian2d" === e.type) return {
          baseAxis: n,
          otherAxis: e.getOtherAxis(n)
        }
      }(t, h),
      f = (d && this._enableRealtimeSort(d, l, n), t.get("clip", !0) || d),
      g = (n = l, a = (o = h).getArea && o.getArea(), !Jw(o, "cartesian2d") || "category" === (o = o.getBaseAxis()).type && o.onBand || (n = n.getLayout("bandWidth"), o.isHorizontal() ? (a.x -= n, a.width += 2 * n) : (a.y -= n, a.height += 2 * n)), a),
      y = (s.removeClipPath(), t.get("roundCap", !0)),
      m = t.get("showBackground", !0),
      v = t.getModel("backgroundStyle"),
      _ = v.get("borderRadius") || 0,
      x = [],
      w = this._backgroundEls,
      b = i && i.isInitSort,
      S = i && "changeAxisOrder" === i.type;

    function M(t) {
      var e = yb[h.type](l, t),
        n = (n = r, new("polar" === h.type ? Su : Ms)({
          shape: Tb(n, e, h),
          silent: !0,
          z2: 0
        }));
      return n.useStyle(v.getItemStyle()), "cartesian2d" === h.type ? n.setShape("r", _) : n.setShape("cornerRadius", _), x[t] = n
    }
    l.diff(u).add((function(e) {
      var n, i, o = l.getItemModel(e),
        a = yb[h.type](l, e, o);
      m && M(e), l.hasValue(e) && gb[h.type](a) && (n = !1, f && (n = ub[h.type](g, a)), i = hb[h.type](t, l, e, a, r, p, c.model, !1, y), d && (i.forceLabelAnimation = !0), vb(i, l, e, o, a, t, r, "polar" === h.type), b ? i.attr({
        shape: a
      }) : d ? cb(d, p, i, a, e, r, !1, !1) : wh(i, {
        shape: a
      }, t, e), l.setItemGraphicEl(e, i), s.add(i), i.ignore = n)
    })).update((function(e, n) {
      var i, o = l.getItemModel(e),
        a = yb[h.type](l, e, o),
        T = (m && (T = void 0, 0 === w.length ? T = M(n) : ((T = w[n]).useStyle(v.getItemStyle()), "cartesian2d" === h.type ? T.setShape("r", _) : T.setShape("cornerRadius", _), x[e] = T), i = yb[h.type](l, e), xh(T, {
          shape: Tb(r, i, h)
        }, p, e)), u.getItemGraphicEl(n));
      l.hasValue(e) && gb[h.type](a) ? (i = !1, f && (i = ub[h.type](g, a)) && s.remove(T), T ? Ih(T) : T = hb[h.type](t, l, e, a, r, p, c.model, !!T, y), d && (T.forceLabelAnimation = !0), S ? (n = T.getTextContent()) && null != (n = hc(n)).prevValue && (n.prevValue = n.value) : vb(T, l, e, o, a, t, r, "polar" === h.type), b ? T.attr({
        shape: a
      }) : d ? cb(d, p, T, a, e, r, !0, S) : xh(T, {
        shape: a
      }, t, e, null), l.setItemGraphicEl(e, T), T.ignore = i, s.add(T)) : s.remove(T)
    })).remove((function(e) {
      var n = u.getItemGraphicEl(e);
      n && Th(n, t, e)
    })).execute();
    var T = this._backgroundGroup || (this._backgroundGroup = new Rr);
    T.removeAll();
    for (var I = 0; I < x.length; ++I) T.add(x[I]);
    s.add(T), this._backgroundEls = x, this._data = l
  }, lb.prototype._renderLarge = function(t, e, n) {
    this._clear(), Sb(t, this.group), this._updateLargeClip(t)
  }, lb.prototype._incrementalRenderLarge = function(t, e) {
    this._removeBackground(), Sb(e, this.group, this._progressiveEls, !0)
  }, lb.prototype._updateLargeClip = function(t) {
    var e = t.get("clip", !0) && (e = t.coordinateSystem, n = !1, t = t, e ? "polar" === e.type ? jw(e, n, t) : "cartesian2d" === e.type ? qw(e, n, t, void 0, void 0) : null : null),
      n = this.group;
    e ? n.setClipPath(e) : n.removeClipPath()
  }, lb.prototype._enableRealtimeSort = function(t, e, n) {
    var i, r, o = this;
    e.count() && (i = t.baseAxis, this._isFirstFrame ? (this._dispatchInitSort(e, t, n), this._isFirstFrame = !1) : (r = function(t) {
      return (t = (t = e.getItemGraphicEl(t)) && t.shape) && Math.abs(i.isHorizontal() ? t.height : t.width) || 0
    }, this._onRendered = function() {
      o._updateSortWithinSameData(e, r, i, n)
    }, n.getZr().on("rendered", this._onRendered)))
  }, lb.prototype._dataSort = function(t, e, n) {
    var i = [];
    return t.each(t.mapDimension(e.dim), (function(t, e) {
      var r = n(e);
      i.push({
        dataIndex: e,
        mappedValue: null == r ? NaN : r,
        ordinalNumber: t
      })
    })), i.sort((function(t, e) {
      return e.mappedValue - t.mappedValue
    })), {
      ordinalNumbers: E(i, (function(t) {
        return t.ordinalNumber
      }))
    }
  }, lb.prototype._isOrderChangedWithinSameData = function(t, e, n) {
    for (var i = n.scale, r = t.mapDimension(n.dim), o = Number.MAX_VALUE, a = 0, s = i.getOrdinalMeta().categories.length; a < s; ++a) {
      var l;
      if (o < (l = (l = t.rawIndexOf(r, i.getRawOrdinalNumber(a))) < 0 ? Number.MIN_VALUE : e(t.indexOfRawIndex(l)))) return !0;
      o = l
    }
    return !1
  }, lb.prototype._isOrderDifferentInView = function(t, e) {
    for (var n = e.scale, i = (e = n.getExtent(), Math.max(0, e[0])), r = Math.min(e[1], n.getOrdinalMeta().categories.length - 1); i <= r; ++i)
      if (t.ordinalNumbers[i] !== n.getRawOrdinalNumber(i)) return !0
  }, lb.prototype._updateSortWithinSameData = function(t, e, n, i) {
    this._isOrderChangedWithinSameData(t, e, n) && (t = this._dataSort(t, n, e), this._isOrderDifferentInView(t, n)) && (this._removeOnRenderedListener(i), i.dispatchAction({
      type: "changeAxisOrder",
      componentType: n.dim + "Axis",
      axisId: n.index,
      sortInfo: t
    }))
  }, lb.prototype._dispatchInitSort = function(t, e, n) {
    var i = e.baseAxis,
      r = this._dataSort(t, i, (function(n) {
        return t.get(t.mapDimension(e.otherAxis.dim), n)
      }));
    n.dispatchAction({
      type: "changeAxisOrder",
      componentType: i.dim + "Axis",
      isInitSort: !0,
      axisId: i.index,
      sortInfo: r
    })
  }, lb.prototype.remove = function(t, e) {
    this._clear(this._model), this._removeOnRenderedListener(e)
  }, lb.prototype.dispose = function(t, e) {
    this._removeOnRenderedListener(e)
  }, lb.prototype._removeOnRenderedListener = function(t) {
    this._onRendered && (t.getZr().off("rendered", this._onRendered), this._onRendered = null)
  }, lb.prototype._clear = function(t) {
    var e = this.group,
      n = this._data;
    t && t.isAnimationEnabled() && n && !this._isLargeDraw ? (this._removeBackground(), this._backgroundEls = [], n.eachItemGraphicEl((function(e) {
      Th(e, t, Us(e).dataIndex)
    }))) : e.removeAll(), this._data = null, this._isFirstFrame = !0
  }, lb.prototype._removeBackground = function() {
    this.group.remove(this._backgroundGroup), this._backgroundGroup = null
  }, lb.type = "bar";
  var ab, sb = lb;

  function lb() {
    var t = ab.call(this) || this;
    return t.type = lb.type, t._isFirstFrame = !0, t
  }
  var ub = {
      cartesian2d: function(t, e) {
        var n = e.width < 0 ? -1 : 1,
          i = e.height < 0 ? -1 : 1,
          r = (n < 0 && (e.x += e.width, e.width = -e.width), i < 0 && (e.y += e.height, e.height = -e.height), t.x + t.width),
          o = t.y + t.height,
          a = rb(e.x, t.x),
          s = ob(e.x + e.width, r),
          l = (t = rb(e.y, t.y), ob(e.y + e.height, o)),
          u = s < a,
          h = l < t;
        return e.x = u && r < a ? s : a, e.y = h && o < t ? l : t, e.width = u ? 0 : s - a, e.height = h ? 0 : l - t, n < 0 && (e.x += e.width, e.width = -e.width), i < 0 && (e.y += e.height, e.height = -e.height), u || h
      },
      polar: function(t, e) {
        var n, i = e.r0 <= e.r ? 1 : -1,
          r = (i < 0 && (n = e.r, e.r = e.r0, e.r0 = n), ob(e.r, t.r));
        t = rb(e.r0, t.r0), r = (e.r = r) - (e.r0 = t) < 0;
        return i < 0 && (n = e.r, e.r = e.r0, e.r0 = n), r
      }
    },
    hb = {
      cartesian2d: function(t, e, n, i, r, o, a, s, l) {
        return (i = new Ms({
          shape: k({}, i),
          z2: 1
        })).__dataIndex = n, i.name = "item", o && (i.shape[r ? "height" : "width"] = 0), i
      },
      polar: function(t, e, n, i, r, o, a, s, l) {
        var u, h, c = new(l = !r && l ? $w : Su)({
            shape: i,
            z2: 1
          }),
          p = (c.name = "item", mb(r));
        return c.calculateTextPosition = (u = p, h = ({
          isRoundCap: l === $w
        } || {}).isRoundCap, function(t, e, n) {
          if (!(i = e.position) || i instanceof Array) return wr(t, e, n);
          var i = u(i),
            r = null != e.distance ? e.distance : 5,
            o = this.shape,
            a = o.cx,
            s = o.cy,
            l = o.r,
            c = o.r0,
            p = (l + c) / 2,
            d = o.startAngle,
            f = o.endAngle,
            g = (d + f) / 2,
            y = h ? Math.abs(l - c) / 2 : 0,
            m = Math.cos,
            v = Math.sin,
            _ = a + l * m(d),
            x = s + l * v(d),
            w = "left",
            b = "top";
          switch (i) {
            case "startArc":
              _ = a + (c - r) * m(g), x = s + (c - r) * v(g), w = "center", b = "top";
              break;
            case "insideStartArc":
              _ = a + (c + r) * m(g), x = s + (c + r) * v(g), w = "center", b = "bottom";
              break;
            case "startAngle":
              _ = a + p * m(d) + nb(d, r + y, !1), x = s + p * v(d) + ib(d, r + y, !1), w = "right", b = "middle";
              break;
            case "insideStartAngle":
              _ = a + p * m(d) + nb(d, y - r, !1), x = s + p * v(d) + ib(d, y - r, !1), w = "left", b = "middle";
              break;
            case "middle":
              _ = a + p * m(g), x = s + p * v(g), w = "center", b = "middle";
              break;
            case "endArc":
              _ = a + (l + r) * m(g), x = s + (l + r) * v(g), w = "center", b = "bottom";
              break;
            case "insideEndArc":
              _ = a + (l - r) * m(g), x = s + (l - r) * v(g), w = "center", b = "top";
              break;
            case "endAngle":
              _ = a + p * m(f) + nb(f, r + y, !0), x = s + p * v(f) + ib(f, r + y, !0), w = "left", b = "middle";
              break;
            case "insideEndAngle":
              _ = a + p * m(f) + nb(f, y - r, !0), x = s + p * v(f) + ib(f, y - r, !0), w = "right", b = "middle";
              break;
            default:
              return wr(t, e, n)
          }
          return (t = t || {}).x = _, t.y = x, t.align = w, t.verticalAlign = b, t
        }), o && (p = {}, c.shape[l = r ? "r" : "endAngle"] = r ? i.r0 : i.startAngle, p[l] = i[l], (s ? xh : wh)(c, {
          shape: p
        }, o)), c
      }
    };

  function cb(t, e, n, i, r, o, a, s) {
    var l;
    o = o ? (l = {
      x: i.x,
      width: i.width
    }, {
      y: i.y,
      height: i.height
    }) : (l = {
      y: i.y,
      height: i.height
    }, {
      x: i.x,
      width: i.width
    });
    s || (a ? xh : wh)(n, {
      shape: o
    }, e, r, null), (a ? xh : wh)(n, {
      shape: l
    }, e ? t.baseAxis.model : null, r)
  }

  function pb(t, e) {
    for (var n = 0; n < e.length; n++)
      if (!isFinite(t[e[n]])) return 1
  }
  var db = ["x", "y", "width", "height"],
    fb = ["cx", "cy", "r", "startAngle", "endAngle"],
    gb = {
      cartesian2d: function(t) {
        return !pb(t, db)
      },
      polar: function(t) {
        return !pb(t, fb)
      }
    },
    yb = {
      cartesian2d: function(t, e, n) {
        t = t.getItemLayout(e);
        var i = n && (e = t, i = (n = n).get(["itemStyle", "borderColor"])) && "none" !== i ? (i = n.get(["itemStyle", "borderWidth"]) || 0, n = isNaN(e.width) ? Number.MAX_VALUE : Math.abs(e.width), e = isNaN(e.height) ? Number.MAX_VALUE : Math.abs(e.height), Math.min(i, n, e)) : 0;
        n = 0 < t.width ? 1 : -1, e = 0 < t.height ? 1 : -1;
        return {
          x: t.x + n * i / 2,
          y: t.y + e * i / 2,
          width: t.width - n * i,
          height: t.height - e * i
        }
      },
      polar: function(t, e, n) {
        return {
          cx: (t = t.getItemLayout(e)).cx,
          cy: t.cy,
          r0: t.r0,
          r: t.r,
          startAngle: t.startAngle,
          endAngle: t.endAngle,
          clockwise: t.clockwise
        }
      }
    };

  function mb(t) {
    return e = t ? "Arc" : "Angle",
      function(t) {
        switch (t) {
          case "start":
          case "insideStart":
          case "end":
          case "insideEnd":
            return t + e;
          default:
            return t
        }
      };
    var e
  }

  function vb(t, e, n, i, r, o, a, s) {
    var l = e.getItemVisual(n, "style"),
      u = ((u = (s ? o.get("roundCap") || (k(u = t.shape, function(t, e, n) {
        if (null == (t = t.get("borderRadius"))) return {
          cornerRadius: 0
        };
        W(t) || (t = [t, t, t, t]);
        var i = Math.abs(e.r || 0 - e.r0 || 0);
        return {
          cornerRadius: E(t, (function(t) {
            return xr(t, i)
          }))
        }
      }(i.getModel("itemStyle"), u)), t.setShape(u)) : (u = i.get(["itemStyle", "borderRadius"]) || 0, t.setShape("r", u)), t.useStyle(l), i.getShallow("cursor"))) && t.attr("cursor", u), s ? a ? r.r >= r.r0 ? "endArc" : "startArc" : r.endAngle >= r.startAngle ? "endAngle" : "startAngle" : a ? 0 <= r.height ? "bottom" : "top" : 0 <= r.width ? "right" : "left"),
      h = ic(i);
    nc(t, h, {
      labelFetcher: o,
      labelDataIndex: n,
      defaultText: tb(o.getData(), n),
      inheritColor: l.fill,
      defaultOpacity: l.opacity,
      defaultOutsidePosition: u
    }), l = t.getTextContent(), s && l && (s = i.get(["label", "position"]), t.textConfig.inside = "middle" === s || null, function(t, e, n, i) {
      if (Y(i)) t.setTextConfig({
        rotation: i
      });
      else if (W(e)) t.setTextConfig({
        rotation: 0
      });
      else {
        var r, o = (i = t.shape).clockwise ? i.startAngle : i.endAngle,
          a = i.clockwise ? i.endAngle : i.startAngle,
          s = (o + a) / 2;
        switch (i = n(e)) {
          case "startArc":
          case "insideStartArc":
          case "middle":
          case "insideEndArc":
          case "endArc":
            r = s;
            break;
          case "startAngle":
          case "insideStartAngle":
            r = o;
            break;
          case "endAngle":
          case "insideEndAngle":
            r = a;
            break;
          default:
            return t.setTextConfig({
              rotation: 0
            })
        }
        n = 1.5 * Math.PI - r, "middle" === i && n > Math.PI / 2 && n < 1.5 * Math.PI && (n -= Math.PI), t.setTextConfig({
          rotation: n
        })
      }
    }(t, "outside" === s ? u : s, mb(a), i.get(["label", "rotate"]))), cc(l, h, o.getRawValue(n), (function(t) {
      return eb(e, t)
    })), u = i.getModel(["emphasis"]);
    Al(t, u.get("focus"), u.get("blurScope"), u.get("disabled")), Ol(t, i), null != (s = r).startAngle && null != s.endAngle && s.startAngle === s.endAngle && (t.style.fill = "none", t.style.stroke = "none", N(t.states, (function(t) {
      t.style && (t.style.fill = t.style.stroke = "none")
    })))
  }
  var _b, xb = function() {},
    wb = (i(bb, _b = as), bb.prototype.getDefaultShape = function() {
      return new xb
    }, bb.prototype.buildPath = function(t, e) {
      for (var n = e.points, i = this.baseDimIdx, r = 1 - this.baseDimIdx, o = [], a = [], s = this.barWidth, l = 0; l < n.length; l += 3) a[i] = s, a[r] = n[l + 2], o[i] = n[l + i], o[r] = n[l + r], t.rect(o[0], o[1], a[0], a[1])
    }, bb);

  function bb(t) {
    return (t = _b.call(this, t) || this).type = "largeBar", t
  }

  function Sb(t, e, n, i) {
    var r = t.getData(),
      o = r.getLayout("valueAxisHorizontal") ? 1 : 0,
      a = r.getLayout("largeDataIndices"),
      s = r.getLayout("size"),
      l = t.getModel("backgroundStyle"),
      u = r.getLayout("largeBackgroundPoints");
    (l = (u && ((u = new wb({
      shape: {
        points: u
      },
      incremental: !!i,
      silent: !0,
      z2: 0
    })).baseDimIdx = o, u.largeDataIndices = a, u.barWidth = s, u.useStyle(l.getItemStyle()), e.add(u), n) && n.push(u), new wb({
      shape: {
        points: r.getLayout("largePoints")
      },
      incremental: !!i,
      ignoreCoarsePointer: !0,
      z2: 1
    }))).baseDimIdx = o, l.largeDataIndices = a, l.barWidth = s, e.add(l), l.useStyle(r.getVisual("style")), Us(l).seriesIndex = t.seriesIndex, t.get("silent") || (l.on("mousedown", Mb), l.on("mousemove", Mb)), n && n.push(l)
  }
  var Mb = Gg((function(t) {
    t = function(t, e, n) {
      for (var i = t.baseDimIdx, r = 1 - i, o = t.shape.points, a = t.largeDataIndices, s = [], l = [], u = t.barWidth, h = 0, c = o.length / 3; h < c; h++) {
        var p = 3 * h;
        if (l[i] = u, l[r] = o[2 + p], s[i] = o[p + i], s[r] = o[p + r], l[r] < 0 && (s[r] += l[r], l[r] = -l[r]), s[0] <= e && e <= s[0] + l[0] && s[1] <= n && n <= s[1] + l[1]) return a[h]
      }
      return -1
    }(this, t.offsetX, t.offsetY), Us(this).dataIndex = 0 <= t ? t : null
  }), 30, !1);

  function Tb(t, e, n) {
    var i, r;
    return Jw(n, "cartesian2d") ? (i = e, r = n.getArea(), {
      x: (t ? i : r).x,
      y: (t ? r : i).y,
      width: (t ? i : r).width,
      height: (t ? r : i).height
    }) : {
      cx: (r = n.getArea()).cx,
      cy: r.cy,
      r0: (t ? r : e).r0,
      r: (t ? r : e).r,
      startAngle: t ? e.startAngle : 0,
      endAngle: t ? e.endAngle : 2 * Math.PI
    }
  }
  _x((function(t) {
    t.registerChartView(sb), t.registerSeriesModel(Xw), t.registerLayout(t.PRIORITY.VISUAL.LAYOUT, H(B_, "bar")), t.registerLayout(t.PRIORITY.VISUAL.PROGRESSIVE_LAYOUT, function(t) {
      return {
        seriesType: t,
        plan: Ag(),
        reset: function(t) {
          var e, n, i, r, o, a, s, l, u, h, c, p, d, f, g, y;
          if (F_(t)) return e = t.getData(), s = (n = t.coordinateSystem).getBaseAxis(), i = n.getOtherAxis(s), r = e.getDimensionIndex(e.mapDimension(i.dim)), o = e.getDimensionIndex(e.mapDimension(s.dim)), a = t.get("showBackground", !0), s = e.mapDimension(i.dim), l = e.getCalculationInfo("stackResultDimension"), u = l_(e, s) && !!e.getCalculationInfo("stackedOnSeries"), h = i.isHorizontal(), c = function(t) {
            var e = t.model.get("startValue");
            return e = e || 0, t.toGlobalCoord(t.dataToCoord("log" !== t.type || 0 < e ? e : 1))
          }(i), p = V_(t), d = t.get("barMinHeight") || 0, f = l && e.getDimensionIndex(l), g = e.getLayout("size"), y = e.getLayout("offset"), {
            progress: function(t, e) {
              for (var i, s = t.count, l = p && O_(3 * s), m = p && a && O_(3 * s), v = p && O_(s), _ = n.master.getRect(), x = h ? _.width : _.height, w = e.getStore(), b = 0; null != (i = t.next());) {
                var S, M = w.get(u ? f : r, i),
                  T = w.get(o, i),
                  I = c,
                  C = void 0,
                  k = void(u && (C = +M - w.get(r, i))),
                  D = void 0,
                  A = void 0,
                  L = void 0;
                h ? (S = n.dataToPoint([M, T]), k = I = u ? n.dataToPoint([C, T])[0] : I, D = S[1] + y, A = S[0] - I, L = g, Math.abs(A) < d && (A = (A < 0 ? -1 : 1) * d)) : (S = n.dataToPoint([T, M]), u && (I = n.dataToPoint([T, C])[1]), k = S[0] + y, D = I, A = g, L = S[1] - I, Math.abs(L) < d && (L = (L <= 0 ? -1 : 1) * d)), p ? (l[b] = k, l[b + 1] = D, l[b + 2] = h ? A : L, m && (m[b] = h ? _.x : k, m[b + 1] = h ? D : _.y, m[b + 2] = x), v[i] = i) : e.setItemLayout(i, {
                  x: k,
                  y: D,
                  width: A,
                  height: L
                }), b += 3
              }
              p && e.setLayout({
                largePoints: l,
                largeDataIndices: v,
                largeBackgroundPoints: m,
                valueAxisHorizontal: h
              })
            }
          }
        }
      }
    }("bar")), t.registerProcessor(t.PRIORITY.PROCESSOR.STATISTIC, Hw("bar")), t.registerAction({
      type: "changeAxisOrder",
      event: "changeAxisOrder",
      update: "update"
    }, (function(t, e) {
      var n = t.componentType || "series";
      e.eachComponent({
        mainType: n,
        query: t
      }, (function(e) {
        t.sortInfo && e.axis.setCategorySortInfo(t.sortInfo)
      }))
    }))
  })), i(kb, Ib = _g), kb.prototype.getInitialData = function(t) {
    return h_(null, this, {
      useEncodeDefaulter: !0
    })
  }, kb.prototype.getLegendIcon = function(t) {
    var e = new Rr,
      n = By("line", 0, t.itemHeight / 2, t.itemWidth, 0, t.lineStyle.stroke, !1),
      i = (n = (e.add(n), n.setStyle(t.lineStyle), this.getData().getVisual("symbol")), this.getData().getVisual("symbolRotate")),
      r = (n = "none" === n ? "circle" : n, .8 * t.itemHeight);
    r = By(n, (t.itemWidth - r) / 2, (t.itemHeight - r) / 2, r, r, t.itemStyle.fill), e.add(r), r.setStyle(t.itemStyle), i = "inherit" === t.iconRotate ? i : t.iconRotate || 0;
    return r.rotation = i * Math.PI / 180, r.setOrigin([t.itemWidth / 2, t.itemHeight / 2]), -1 < n.indexOf("empty") && (r.style.stroke = r.style.fill, r.style.fill = "#fff", r.style.lineWidth = 2), e
  }, kb.type = "series.line", kb.dependencies = ["grid", "polar"], kb.defaultOption = {
    z: 3,
    coordinateSystem: "cartesian2d",
    legendHoverLink: !0,
    clip: !0,
    label: {
      position: "top"
    },
    endLabel: {
      show: !1,
      valueAnimation: !0,
      distance: 8
    },
    lineStyle: {
      width: 2,
      type: "solid"
    },
    emphasis: {
      scale: !0
    },
    step: !1,
    smooth: !1,
    smoothMonotone: null,
    symbol: "emptyCircle",
    symbolSize: 4,
    symbolRotate: null,
    showSymbol: !0,
    showAllSymbol: "auto",
    connectNulls: !1,
    sampling: "none",
    animationEasing: "linear",
    progressive: 0,
    hoverLayerThreshold: 1 / 0,
    universalTransition: {
      divideShape: "clone"
    },
    triggerLineEvent: !1
  };
  var Ib, Cb = kb;

  function kb() {
    var t = null !== Ib && Ib.apply(this, arguments) || this;
    return t.type = kb.type, t.hasSymbolVisual = !0, t
  }
  i(Lb, Db = Rr), Lb.prototype._createSymbol = function(t, e, n, i, r) {
    this.removeAll(), (r = By(t, -1, -1, 2, 2, null, r)).attr({
      z2: 100,
      culling: !0,
      scaleX: i[0] / 2,
      scaleY: i[1] / 2
    }), r.drift = Pb, this._symbolType = t, this.add(r)
  }, Lb.prototype.stopSymbolAnimation = function(t) {
    this.childAt(0).stopAnimation(null, t)
  }, Lb.prototype.getSymbolType = function() {
    return this._symbolType
  }, Lb.prototype.getSymbolPath = function() {
    return this.childAt(0)
  }, Lb.prototype.highlight = function() {
    ml(this.childAt(0))
  }, Lb.prototype.downplay = function() {
    vl(this.childAt(0))
  }, Lb.prototype.setZ = function(t, e) {
    var n = this.childAt(0);
    n.zlevel = t, n.z = e
  }, Lb.prototype.setDraggable = function(t, e) {
    var n = this.childAt(0);
    n.draggable = t, n.cursor = !e && t ? "move" : n.cursor
  }, Lb.prototype.updateData = function(t, e, n, i) {
    this.silent = !1;
    var r, o, a, s = t.getItemVisual(e, "symbol") || "circle",
      l = t.hostModel,
      u = Lb.getSymbolSize(t, e),
      h = s !== this._symbolType,
      c = i && i.disableAnimation;
    h ? (r = t.getItemVisual(e, "symbolKeepAspect"), this._createSymbol(s, t, e, u, r)) : ((o = this.childAt(0)).silent = !1, a = {
      scaleX: u[0] / 2,
      scaleY: u[1] / 2
    }, c ? o.attr(a) : xh(o, a, l, e), Ih(o)), this._updateCommon(t, e, u, n, i), h && (o = this.childAt(0), c || (a = {
      scaleX: this._sizeX,
      scaleY: this._sizeY,
      style: {
        opacity: o.style.opacity
      }
    }, o.scaleX = o.scaleY = 0, o.style.opacity = 0, wh(o, a, l, e))), c && this.childAt(0).stopAnimation("leave")
  }, Lb.prototype._updateCommon = function(t, e, n, i, r) {
    var o, a, s, l, u, h, c, p, d = this.childAt(0),
      f = t.hostModel,
      g = (i && (o = i.emphasisItemStyle, s = i.blurItemStyle, a = i.selectItemStyle, l = i.focus, u = i.blurScope, c = i.labelStatesModels, p = i.hoverScale, y = i.cursorStyle, h = i.emphasisDisabled), i && !t.hasItemOption || (o = (g = (i = i && i.itemModel ? i.itemModel : t.getItemModel(e)).getModel("emphasis")).getModel("itemStyle").getItemStyle(), a = i.getModel(["select", "itemStyle"]).getItemStyle(), s = i.getModel(["blur", "itemStyle"]).getItemStyle(), l = g.get("focus"), u = g.get("blurScope"), h = g.get("disabled"), c = ic(i), p = g.getShallow("scale"), y = i.getShallow("cursor")), t.getItemVisual(e, "symbolRotate")),
      y = (i = (g = ((i = (d.attr("rotation", (g || 0) * Math.PI / 180 || 0), Vy(t.getItemVisual(e, "symbolOffset"), n))) && (d.x = i[0], d.y = i[1]), y && d.attr("cursor", y), t.getItemVisual(e, "style"))).fill, d instanceof gs ? (y = d.style, d.useStyle(k({
        image: y.image,
        x: y.x,
        y: y.y,
        width: y.width,
        height: y.height
      }, g))) : (d.__isEmptyBrush ? d.useStyle(k({}, g)) : d.useStyle(g), d.style.decal = null, d.setColor(i, r && r.symbolInnerColor), d.style.strokeNoScale = !0), t.getItemVisual(e, "liftZ")),
      m = this._z2,
      v = (null != y ? null == m && (this._z2 = d.z2, d.z2 += y) : null != m && (d.z2 = m, this._z2 = null), r && r.useNameLabel);
    nc(d, c, {
      labelFetcher: f,
      labelDataIndex: e,
      defaultText: function(e) {
        return v ? t.getName(e) : tb(t, e)
      },
      inheritColor: i,
      defaultOpacity: g.opacity
    }), this._sizeX = n[0] / 2, this._sizeY = n[1] / 2, (y = d.ensureState("emphasis")).style = o, d.ensureState("select").style = a, d.ensureState("blur").style = s, m = null == p || !0 === p ? Math.max(1.1, 3 / this._sizeY) : isFinite(p) && 0 < p ? +p : 1, y.scaleX = this._sizeX * m, y.scaleY = this._sizeY * m, this.setSymbolScale(1), Al(this, l, u, h)
  }, Lb.prototype.setSymbolScale = function(t) {
    this.scaleX = this.scaleY = t
  }, Lb.prototype.fadeOut = function(t, e, n) {
    var i = this.childAt(0),
      r = Us(this).dataIndex,
      o = n && n.animation;
    this.silent = i.silent = !0, n && n.fadeLabel ? (n = i.getTextContent()) && Sh(n, {
      style: {
        opacity: 0
      }
    }, e, {
      dataIndex: r,
      removeOpt: o,
      cb: function() {
        i.removeTextContent()
      }
    }) : i.removeTextContent(), Sh(i, {
      style: {
        opacity: 0
      },
      scaleX: 0,
      scaleY: 0
    }, e, {
      dataIndex: r,
      cb: t,
      removeOpt: o
    })
  }, Lb.getSymbolSize = function(t, e) {
    return Fy(t.getItemVisual(e, "symbolSize"))
  };
  var Db, Ab = Lb;

  function Lb(t, e, n, i) {
    var r = Db.call(this) || this;
    return r.updateData(t, e, n, i), r
  }

  function Pb(t, e) {
    this.parent.drift(t, e)
  }

  function Ob(t, e, n, i) {
    return e && !isNaN(e[0]) && !isNaN(e[1]) && (!i.isIgnore || !i.isIgnore(n)) && (!i.clipShape || i.clipShape.contain(e[0], e[1])) && "none" !== t.getItemVisual(n, "symbol")
  }

  function Rb(t) {
    return (t = null == t || q(t) ? t : {
      isIgnore: t
    }) || {}
  }

  function Nb(t) {
    var e = (t = t.hostModel).getModel("emphasis");
    return {
      emphasisItemStyle: e.getModel("itemStyle").getItemStyle(),
      blurItemStyle: t.getModel(["blur", "itemStyle"]).getItemStyle(),
      selectItemStyle: t.getModel(["select", "itemStyle"]).getItemStyle(),
      focus: e.get("focus"),
      blurScope: e.get("blurScope"),
      emphasisDisabled: e.get("disabled"),
      hoverScale: e.get("scale"),
      labelStatesModels: ic(t),
      cursorStyle: t.get("cursor")
    }
  }
  zb.prototype.updateData = function(t, e) {
    this._progressiveEls = null, e = Rb(e);
    var n = this.group,
      i = t.hostModel,
      r = this._data,
      o = this._SymbolCtor,
      a = e.disableAnimation,
      s = Nb(t),
      l = {
        disableAnimation: a
      },
      u = e.getSymbolPoint || function(e) {
        return t.getItemLayout(e)
      };
    r || n.removeAll(), t.diff(r).add((function(i) {
      var r, a = u(i);
      Ob(t, a, i, e) && ((r = new o(t, i, s, l)).setPosition(a), t.setItemGraphicEl(i, r), n.add(r))
    })).update((function(h, c) {
      c = r.getItemGraphicEl(c);
      var p, d, f = u(h);
      Ob(t, f, h, e) ? (p = t.getItemVisual(h, "symbol") || "circle", d = c && c.getSymbolType && c.getSymbolType(), !c || d && d !== p ? (n.remove(c), (c = new o(t, h, s, l)).setPosition(f)) : (c.updateData(t, h, s, l), d = {
        x: f[0],
        y: f[1]
      }, a ? c.attr(d) : xh(c, d, i)), n.add(c), t.setItemGraphicEl(h, c)) : n.remove(c)
    })).remove((function(t) {
      var e = r.getItemGraphicEl(t);
      e && e.fadeOut((function() {
        n.remove(e)
      }), i)
    })).execute(), this._getSymbolPoint = u, this._data = t
  }, zb.prototype.updateLayout = function() {
    var t = this,
      e = this._data;
    e && e.eachItemGraphicEl((function(e, n) {
      n = t._getSymbolPoint(n), e.setPosition(n), e.markRedraw()
    }))
  }, zb.prototype.incrementalPrepareUpdate = function(t) {
    this._seriesScope = Nb(t), this._data = null, this.group.removeAll()
  }, zb.prototype.incrementalUpdate = function(t, e, n) {
    function i(t) {
      t.isGroup || (t.incremental = !0, t.ensureState("emphasis").hoverLayer = !0)
    }
    this._progressiveEls = [], n = Rb(n);
    for (var r = t.start; r < t.end; r++) {
      var o, a = e.getItemLayout(r);
      Ob(e, a, r, n) && ((o = new this._SymbolCtor(e, r, this._seriesScope)).traverse(i), o.setPosition(a), this.group.add(o), e.setItemGraphicEl(r, o), this._progressiveEls.push(o))
    }
  }, zb.prototype.eachRendered = function(t) {
    $h(this._progressiveEls || this.group, t)
  }, zb.prototype.remove = function(t) {
    var e = this.group,
      n = this._data;
    n && t ? n.eachItemGraphicEl((function(t) {
      t.fadeOut((function() {
        e.remove(t)
      }), n.hostModel)
    })) : e.removeAll()
  };
  var Eb = zb;

  function zb(t) {
    this.group = new Rr, this._SymbolCtor = t || Ab
  }

  function Bb(t, e, n) {
    var i = t.getBaseAxis(),
      r = (n = function(t, e) {
        var n = 0;
        t = t.scale.getExtent();
        return "start" === e ? n = t[0] : "end" === e ? n = t[1] : Y(e) && !isNaN(e) ? n = e : 0 < t[0] ? n = t[0] : t[1] < 0 && (n = t[1]), n
      }(r = t.getOtherAxis(i), n), i = i.dim, r.dim),
      o = e.mapDimension(r),
      a = e.mapDimension(i),
      s = "x" === r || "radius" === r ? 1 : 0,
      l = (t = E(t.dimensions, (function(t) {
        return e.mapDimension(t)
      })), !1),
      u = e.getCalculationInfo("stackResultDimension");
    return l_(e, t[0]) && (l = !0, t[0] = u), l_(e, t[1]) && (l = !0, t[1] = u), {
      dataDimsForPoint: t,
      valueStart: n,
      valueAxisDim: r,
      baseAxisDim: i,
      stacked: !!l,
      valueDim: o,
      baseDim: a,
      baseDataOffset: s,
      stackedOverDimension: e.getCalculationInfo("stackedOverDimension")
    }
  }

  function Fb(t, e, n, i) {
    var r = NaN,
      o = (t.stacked && (r = n.get(n.getCalculationInfo("stackedOverDimension"), i)), isNaN(r) && (r = t.valueStart), t.baseDataOffset),
      a = [];
    return a[o] = n.get(t.baseDim, i), a[1 - o] = r, e.dataToPoint(a)
  }
  var Vb = Math.min,
    Hb = Math.max;

  function Wb(t, e) {
    return isNaN(t) || isNaN(e)
  }

  function Gb(t, e, n, i, r, o, a, s, l) {
    for (var u, h, c, p, d = n, f = 0; f < i; f++) {
      var g = e[2 * d],
        y = e[2 * d + 1];
      if (r <= d || d < 0) break;
      if (Wb(g, y)) {
        if (l) {
          d += o;
          continue
        }
        break
      }
      if (d === n) t[0 < o ? "moveTo" : "lineTo"](g, y), c = g, p = y;
      else {
        if ((A = g - u) * A + (L = y - h) * L < .5) {
          d += o;
          continue
        }
        if (0 < a) {
          for (var m = d + o, v = e[2 * m], _ = e[2 * m + 1]; v === g && _ === y && f < i;) f++, d += o, v = e[2 * (m += o)], _ = e[2 * m + 1], g = e[2 * d], y = e[2 * d + 1];
          var x = f + 1;
          if (l)
            for (; Wb(v, _) && x < i;) x++, v = e[2 * (m += o)], _ = e[2 * m + 1];
          var w, b, S, M, T, I, C, k, D, A = 0,
            L = 0,
            P = void 0,
            O = void 0;
          i <= x || Wb(v, _) ? (C = g, k = y) : (A = v - u, L = _ - h, w = g - u, b = v - g, S = y - h, M = _ - y, I = T = void 0, O = "x" === s ? (C = g - (D = 0 < A ? 1 : -1) * (T = Math.abs(w)) * a, k = y, P = g + D * (I = Math.abs(b)) * a, y) : "y" === s ? (k = y - (D = 0 < L ? 1 : -1) * (T = Math.abs(S)) * a, P = C = g, y + D * (I = Math.abs(M)) * a) : (T = Math.sqrt(w * w + S * S), C = g - A * a * (1 - (w = (I = Math.sqrt(b * b + M * M)) / (I + T))), k = y - L * a * (1 - w), O = y + L * a * w, P = Vb(P = g + A * a * w, Hb(v, g)), O = Vb(O, Hb(_, y)), P = Hb(P, Vb(v, g)), k = y - (L = (O = Hb(O, Vb(_, y))) - y) * T / I, C = Vb(C = g - (A = P - g) * T / I, Hb(u, g)), k = Vb(k, Hb(h, y)), P = g + (A = g - (C = Hb(C, Vb(u, g)))) * I / T, y + (L = y - (k = Hb(k, Vb(h, y)))) * I / T)), t.bezierCurveTo(c, p, C, k, g, y), c = P, p = O
        } else t.lineTo(g, y)
      }
      u = g, h = y, d += o
    }
    return f
  }
  var Ub, Xb = function() {
      this.smooth = 0, this.smoothConstraint = !0
    },
    Yb = (i(qb, Ub = as), qb.prototype.getDefaultStyle = function() {
      return {
        stroke: "#000",
        fill: null
      }
    }, qb.prototype.getDefaultShape = function() {
      return new Xb
    }, qb.prototype.buildPath = function(t, e) {
      var n = e.points,
        i = 0,
        r = n.length / 2;
      if (e.connectNulls) {
        for (; 0 < r && Wb(n[2 * r - 2], n[2 * r - 1]); r--);
        for (; i < r && Wb(n[2 * i], n[2 * i + 1]); i++);
      }
      for (; i < r;) i += Gb(t, n, i, r, r, 1, e.smooth, e.smoothMonotone, e.connectNulls) + 1
    }, qb.prototype.getPointOn = function(t, e) {
      this.path || (this.createPathProxy(), this.buildPath(this.path, this.shape));
      for (var n, i, r = this.path.data, o = Wa.CMD, a = "x" === e, s = [], l = 0; l < r.length;) {
        var u = void 0,
          h = void 0;
        switch (r[l++]) {
          case o.M:
            n = r[l++], i = r[l++];
            break;
          case o.L:
            var c;
            u = r[l++], h = r[l++];
            if ((c = a ? (t - n) / (u - n) : (t - i) / (h - i)) <= 1 && 0 <= c) return v = a ? (h - i) * c + i : (u - n) * c + n, a ? [t, v] : [v, t];
            n = u, i = h;
            break;
          case o.C:
            u = r[l++], h = r[l++];
            var p = r[l++],
              d = r[l++],
              f = r[l++],
              g = r[l++],
              y = a ? yn(n, u, p, f, t, s) : yn(i, h, d, g, t, s);
            if (0 < y)
              for (var m = 0; m < y; m++) {
                var v, _ = s[m];
                if (_ <= 1 && 0 <= _) return v = a ? fn(i, h, d, g, _) : fn(n, u, p, f, _), a ? [t, v] : [v, t]
              }
            n = f, i = g
        }
      }
    }, qb);

  function qb(t) {
    return (t = Ub.call(this, t) || this).type = "ec-polyline", t
  }
  i(Kb, jb = Xb);
  var jb, Zb = Kb;

  function Kb() {
    return null !== jb && jb.apply(this, arguments) || this
  }
  i(Jb, $b = as), Jb.prototype.getDefaultShape = function() {
    return new Zb
  }, Jb.prototype.buildPath = function(t, e) {
    var n = e.points,
      i = e.stackedOnPoints,
      r = 0,
      o = n.length / 2,
      a = e.smoothMonotone;
    if (e.connectNulls) {
      for (; 0 < o && Wb(n[2 * o - 2], n[2 * o - 1]); o--);
      for (; r < o && Wb(n[2 * r], n[2 * r + 1]); r++);
    }
    for (; r < o;) {
      var s = Gb(t, n, r, o, o, 1, e.smooth, a, e.connectNulls);
      Gb(t, i, r + s - 1, s, o, -1, e.stackedOnSmooth, a, e.connectNulls), r += s + 1, t.closePath()
    }
  };
  var $b, Qb = Jb;

  function Jb(t) {
    return (t = $b.call(this, t) || this).type = "ec-polygon", t
  }

  function tS(t, e) {
    if (t.length === e.length) {
      for (var n = 0; n < t.length; n++)
        if (t[n] !== e[n]) return;
      return 1
    }
  }

  function eS(t) {
    for (var e = 1 / 0, n = 1 / 0, i = -1 / 0, r = -1 / 0, o = 0; o < t.length;) {
      var a = t[o++],
        s = t[o++];
      isNaN(a) || (e = Math.min(a, e), i = Math.max(a, i)), isNaN(s) || (n = Math.min(s, n), r = Math.max(s, r))
    }
    return [
      [e, n],
      [i, r]
    ]
  }

  function nS(t, e) {
    var n = (t = eS(t))[0],
      i = (t = t[1], (e = eS(e))[0]);
    e = e[1];
    return Math.max(Math.abs(n[0] - i[0]), Math.abs(n[1] - i[1]), Math.abs(t[0] - e[0]), Math.abs(t[1] - e[1]))
  }

  function iS(t) {
    return Y(t) ? t : t ? .5 : 0
  }

  function rS(t, e, n, i) {
    var r = "x" === (e = e.getBaseAxis()).dim || "radius" === e.dim ? 0 : 1,
      o = [],
      a = 0,
      s = [],
      l = [],
      u = [],
      h = [];
    if (i) {
      for (a = 0; a < t.length; a += 2) isNaN(t[a]) || isNaN(t[a + 1]) || h.push(t[a], t[a + 1]);
      t = h
    }
    for (a = 0; a < t.length - 2; a += 2) switch (u[0] = t[a + 2], u[1] = t[a + 3], l[0] = t[a], l[1] = t[a + 1], o.push(l[0], l[1]), n) {
      case "end":
        s[r] = u[r], s[1 - r] = l[1 - r], o.push(s[0], s[1]);
        break;
      case "middle":
        var c = [];
        s[r] = c[r] = (l[r] + u[r]) / 2, s[1 - r] = l[1 - r], c[1 - r] = u[1 - r], o.push(s[0], s[1]), o.push(c[0], c[1]);
        break;
      default:
        s[r] = l[r], s[1 - r] = u[1 - r], o.push(s[0], s[1])
    }
    return o.push(t[a++], t[a++]), o
  }

  function oS(t, e) {
    return [t[2 * e], t[2 * e + 1]]
  }

  function aS(t) {
    if (t.get(["endLabel", "show"])) return 1;
    for (var e = 0; e < Zs.length; e++)
      if (t.get([Zs[e], "endLabel", "show"])) return 1
  }

  function sS(t, e, n, i) {
    var r, o, a, s, l, u, h, c, p;
    return Jw(e, "cartesian2d") ? (r = i.getModel("endLabel"), o = r.get("valueAnimation"), a = i.getData(), s = {
      lastFrameIndex: 0
    }, l = aS(i) ? function(n, i) {
      t._endLabelOnDuring(n, i, a, s, o, r, e)
    } : null, u = e.getBaseAxis().isHorizontal(), h = qw(e, n, i, (function() {
      var e = t._endLabel;
      e && n && null != s.originalX && e.attr({
        x: s.originalX,
        y: s.originalY
      })
    }), l), i.get("clip", !0) || (c = h.shape, p = Math.max(c.width, c.height), u ? (c.y -= p, c.height += 2 * p) : (c.x -= p, c.width += 2 * p)), l && l(1, h), h) : jw(e, n, i)
  }
  i(hS, lS = Og), hS.prototype.init = function() {
    var t = new Rr,
      e = new Eb;
    this.group.add(e.group), this._symbolDraw = e, this._lineGroup = t
  }, hS.prototype.render = function(t, e, n) {
    function i(t) {
      o._changePolyState(t)
    }
    var r, o = this,
      a = t.coordinateSystem,
      s = this.group,
      l = t.getData(),
      u = t.getModel("lineStyle"),
      h = t.getModel("areaStyle"),
      c = l.getLayout("points") || [],
      p = "polar" === a.type,
      d = this._coordSys,
      f = this._symbolDraw,
      g = this._polyline,
      y = this._polygon,
      m = this._lineGroup,
      v = (e = !e.ssr && t.get("animation"), !h.isEmpty()),
      _ = h.get("origin"),
      x = Bb(a, l, _),
      w = (x = v && function(t, e, n) {
        if (!n.valueDim) return [];
        for (var i = e.count(), r = O_(2 * i), o = 0; o < i; o++) {
          var a = Fb(n, t, e, o);
          r[2 * o] = a[0], r[2 * o + 1] = a[1]
        }
        return r
      }(a, l, x), t.get("showSymbol")),
      b = t.get("connectNulls"),
      S = w && !p && function(t, e, n) {
        var i = "auto" === (t = t.get("showAllSymbol"));
        if (!t || i) {
          var r, o, a = n.getAxesByScale("ordinal")[0];
          if (a && (!i || ! function(t, e) {
              for (var n = t.getExtent(), i = Math.abs(n[1] - n[0]) / t.scale.count(), r = (isNaN(i) && (i = 0), e.count()), o = Math.max(1, Math.round(r / 5)), a = 0; a < r; a += o)
                if (1.5 * Ab.getSymbolSize(e, a)[t.isHorizontal() ? 1 : 0] > i) return;
              return 1
            }(a, e))) return r = e.mapDimension(a.dim), o = {}, N(a.getViewLabels(), (function(t) {
              t = a.scale.getRawOrdinalNumber(t.tickValue), o[t] = 1
            })),
            function(t) {
              return !o.hasOwnProperty(e.get(r, t))
            }
        }
      }(t, l, a),
      M = this._data,
      T = (M && M.eachItemGraphicEl((function(t, e) {
        t.__temp && (s.remove(t), M.setItemGraphicEl(e, null))
      })), w || f.remove(), s.add(m), !p && t.get("step")),
      I = (a && a.getArea && t.get("clip", !0) && (null != (r = a.getArea()).width ? (r.x -= .1, r.y -= .1, r.width += .2, r.height += .2) : r.r0 && (r.r0 -= .5, r.r += .5)), this._clipShapeForSymbol = r, function(t, e, n) {
        var i = t.getVisual("visualMeta");
        if (i && i.length && t.count() && "cartesian2d" === e.type) {
          for (var r, o = i.length - 1; 0 <= o; o--) {
            var a, s = t.getDimensionInfo(i[o].dimension);
            if ("x" === (a = s && s.coordDim) || "y" === a) {
              r = i[o];
              break
            }
          }
          if (r) {
            var l = e.getAxis(a),
              u = (e = E(r.stops, (function(t) {
                return {
                  coord: l.toGlobalCoord(l.dataToCoord(t.value)),
                  color: t.color
                }
              }))).length,
              h = r.outerColors.slice(),
              c = (n = (u && e[0].coord > e[u - 1].coord && (e.reverse(), h.reverse()), function(t, e) {
                var n, i, r = [],
                  o = t.length;

                function a(t, e, n) {
                  var i = t.coord;
                  return {
                    coord: n,
                    color: $n((n - i) / (e.coord - i), [t.color, e.color])
                  }
                }
                for (var s = 0; s < o; s++) {
                  var l = t[s],
                    u = l.coord;
                  if (u < 0) n = l;
                  else {
                    if (e < u) {
                      i ? r.push(a(i, l, e)) : n && r.push(a(n, l, 0), a(n, l, e));
                      break
                    }
                    n && (r.push(a(n, l, 0)), n = null), r.push(l), i = l
                  }
                }
                return r
              }(e, "x" === a ? n.getWidth() : n.getHeight()))).length;
            if (!c && u) return e[0].coord < 0 ? h[1] || e[u - 1].color : h[0] || e[0].color;
            var p = n[0].coord - 10,
              d = (u = n[c - 1].coord + 10) - p;
            return d < .001 ? "transparent" : (N(n, (function(t) {
              t.offset = (t.coord - p) / d
            })), n.push({
              offset: c ? n[c - 1].offset : .5,
              color: h[1] || "transparent"
            }), n.unshift({
              offset: c ? n[0].offset : .5,
              color: h[0] || "transparent"
            }), (e = new rh(0, 0, 0, 0, n, !0))[a] = p, e[a + "2"] = u, e)
          }
        }
      }(l, a, n) || l.getVisual("style")[l.getVisual("drawType")]);
    n = (d = (g && d.type === a.type && T === this._step ? (v && !y ? y = this._newPolygon(c, x) : y && !v && (m.remove(y), y = this._polygon = null), p || this._initOrUpdateEndLabel(t, a, cp(I)), (d = m.getClipPath()) ? wh(d, {
      shape: sS(this, a, !1, t).shape
    }, t) : m.setClipPath(sS(this, a, !0, t)), w && f.updateData(l, {
      isIgnore: S,
      clipShape: r,
      disableAnimation: !0,
      getSymbolPoint: function(t) {
        return [c[2 * t], c[2 * t + 1]]
      }
    }), tS(this._stackedOnPoints, x) && tS(this._points, c) || (e ? this._doUpdateAnimation(l, x, a, n, T, _, b) : (T && (c = rS(c, a, T, b), x = x && rS(x, a, T, b)), g.setShape({
      points: c
    }), y && y.setShape({
      points: c,
      stackedOnPoints: x
    })))) : (w && f.updateData(l, {
      isIgnore: S,
      clipShape: r,
      disableAnimation: !0,
      getSymbolPoint: function(t) {
        return [c[2 * t], c[2 * t + 1]]
      }
    }), e && this._initSymbolLabelAnimation(l, a, r), T && (c = rS(c, a, T, b), x = x && rS(x, a, T, b)), g = this._newPolyline(c), v ? y = this._newPolygon(c, x) : y && (m.remove(y), y = this._polygon = null), p || this._initOrUpdateEndLabel(t, a, cp(I)), m.setClipPath(sS(this, a, !0, t))), t.getModel("emphasis"))).get("focus"), w = d.get("blurScope"), f = d.get("disabled"), g.useStyle(D(u.getLineStyle(), {
      fill: "none",
      stroke: I,
      lineJoin: "bevel"
    })), Ol(g, t, "lineStyle"), 0 < g.style.lineWidth && "bolder" === t.get(["emphasis", "lineStyle", "width"]) && (g.getState("emphasis").style.lineWidth = +g.style.lineWidth + 1), Us(g).seriesIndex = t.seriesIndex, Al(g, n, w, f), S = iS(t.get("smooth")), e = t.get("smoothMonotone");
    g.setShape({
      smooth: S,
      smoothMonotone: e,
      connectNulls: b
    }), y && (r = l.getCalculationInfo("stackedOnSeries"), v = 0, y.useStyle(D(h.getAreaStyle(), {
      fill: I,
      opacity: .7,
      lineJoin: "bevel",
      decal: l.getVisual("style").decal
    })), r && (v = iS(r.get("smooth"))), y.setShape({
      smooth: S,
      stackedOnSmooth: v,
      smoothMonotone: e,
      connectNulls: b
    }), Ol(y, t, "areaStyle"), Us(y).seriesIndex = t.seriesIndex, Al(y, n, w, f)), l.eachItemGraphicEl((function(t) {
      t && (t.onHoverStateChange = i)
    })), this._polyline.onHoverStateChange = i, this._data = l, this._coordSys = a, this._stackedOnPoints = x, this._points = c, this._step = T, this._valueOrigin = _, t.get("triggerLineEvent") && (this.packEventData(t, g), y) && this.packEventData(t, y)
  }, hS.prototype.packEventData = function(t, e) {
    Us(e).eventData = {
      componentType: "series",
      componentSubType: "line",
      componentIndex: t.componentIndex,
      seriesIndex: t.seriesIndex,
      seriesName: t.name,
      seriesType: "line"
    }
  }, hS.prototype.highlight = function(t, e, n, i) {
    var r = t.getData(),
      o = bo(r, i);
    if (this._changePolyState("emphasis"), !(o instanceof Array) && null != o && 0 <= o) {
      var a = r.getLayout("points");
      if (!(l = r.getItemGraphicEl(o))) {
        var s = a[2 * o];
        a = a[2 * o + 1];
        if (isNaN(s) || isNaN(a)) return;
        if (this._clipShapeForSymbol && !this._clipShapeForSymbol.contain(s, a)) return;
        var l, u = t.get("zlevel") || 0,
          h = t.get("z") || 0;
        (s = ((l = new Ab(r, o)).x = s, l.y = a, l.setZ(u, h), l.getSymbolPath().getTextContent())) && (s.zlevel = u, s.z = h, s.z2 = this._polyline.z2 + 1), l.__temp = !0, r.setItemGraphicEl(o, l), l.stopSymbolAnimation(!0), this.group.add(l)
      }
      l.highlight()
    } else Og.prototype.highlight.call(this, t, e, n, i)
  }, hS.prototype.downplay = function(t, e, n, i) {
    var r, o = t.getData(),
      a = bo(o, i);
    this._changePolyState("normal"), null != a && 0 <= a ? (r = o.getItemGraphicEl(a)) && (r.__temp ? (o.setItemGraphicEl(a, null), this.group.remove(r)) : r.downplay()) : Og.prototype.downplay.call(this, t, e, n, i)
  }, hS.prototype._changePolyState = function(t) {
    var e = this._polygon;
    pl(this._polyline, t), e && pl(e, t)
  }, hS.prototype._newPolyline = function(t) {
    var e = this._polyline;
    return e && this._lineGroup.remove(e), e = new Yb({
      shape: {
        points: t
      },
      segmentIgnoreThreshold: 2,
      z2: 10
    }), this._lineGroup.add(e), this._polyline = e
  }, hS.prototype._newPolygon = function(t, e) {
    var n = this._polygon;
    return n && this._lineGroup.remove(n), n = new Qb({
      shape: {
        points: t,
        stackedOnPoints: e
      },
      segmentIgnoreThreshold: 2
    }), this._lineGroup.add(n), this._polygon = n
  }, hS.prototype._initSymbolLabelAnimation = function(t, e, n) {
    var i, r, o, a = (o = e.getBaseAxis()).inverse,
      s = (o = ("cartesian2d" === e.type ? (i = o.isHorizontal(), r = !1) : "polar" === e.type && (i = "angle" === o.dim, r = !0), t.hostModel)).get("animationDuration"),
      l = (G(s) && (s = s(null)), o.get("animationDelay") || 0),
      u = G(l) ? l(null) : l;
    t.eachItemGraphicEl((function(t, o) {
      var h, c, p, d, f, g = t;
      g && (d = [t.x, t.y], f = c = h = void 0, n && (f = r ? (p = n, d = e.pointToCoord(d), i ? (h = p.startAngle, c = p.endAngle, -d[1] / 180 * Math.PI) : (h = p.r0, c = p.r, d[0])) : i ? (h = n.x, c = n.x + n.width, t.x) : (h = n.y + n.height, c = n.y, t.y)), p = c === h ? 0 : (f - h) / (c - h), a && (p = 1 - p), d = G(l) ? l(o) : s * p + u, f = (t = g.getSymbolPath()).getTextContent(), g.attr({
        scaleX: 0,
        scaleY: 0
      }), g.animateTo({
        scaleX: 1,
        scaleY: 1
      }, {
        duration: 200,
        setToFinal: !0,
        delay: d
      }), f && f.animateFrom({
        style: {
          opacity: 0
        }
      }, {
        duration: 300,
        delay: d
      }), t.disableLabelAnimation = !0)
    }))
  }, hS.prototype._initOrUpdateEndLabel = function(t, e, n) {
    var i, r, o, a = t.getModel("endLabel");
    aS(t) ? (i = t.getData(), r = this._polyline, (o = i.getLayout("points")) ? (this._endLabel || ((this._endLabel = new Ds({
      z2: 200
    })).ignoreClip = !0, r.setTextContent(this._endLabel), r.disableLabelAnimation = !0), 0 <= (o = function(t) {
      for (var e, n, i = t.length / 2; 0 < i && (e = t[2 * i - 2], n = t[2 * i - 1], isNaN(e) || isNaN(n)); i--);
      return i - 1
    }(o)) && (nc(r, ic(t, "endLabel"), {
      inheritColor: n,
      labelFetcher: t,
      labelDataIndex: o,
      defaultText: function(t, e, n) {
        return null != n ? eb(i, n) : tb(i, t)
      },
      enableTextSetter: !0
    }, (n = a, o = (t = (t = e).getBaseAxis()).isHorizontal(), t = t.inverse, a = o ? t ? "right" : "left" : "center", o = o ? "middle" : t ? "top" : "bottom", {
      normal: {
        align: n.get("align") || a,
        verticalAlign: n.get("verticalAlign") || o
      }
    })), r.textConfig.position = null)) : (r.removeTextContent(), this._endLabel = null)) : this._endLabel && (this._polyline.removeTextContent(), this._endLabel = null)
  }, hS.prototype._endLabelOnDuring = function(t, e, n, i, r, o, a) {
    var s, l, u, h, c, p, d, f, g, y, m = this._endLabel,
      v = this._polyline;
    m && (t < 1 && null == i.originalX && (i.originalX = m.x, i.originalY = m.y), s = n.getLayout("points"), g = (l = n.hostModel).get("connectNulls"), u = o.get("precision"), o = o.get("distance") || 0, c = (a = a.getBaseAxis()).isHorizontal(), a = a.inverse, e = e.shape, h = (c ? o : 0) * (a ? -1 : 1), o = (c ? 0 : -o) * (a ? -1 : 1), d = void 0, 1 <= (f = (p = (c = function(t, e, n) {
      for (var i, r, o = t.length / 2, a = "x" === n ? 0 : 1, s = 0, l = -1, u = 0; u < o; u++)
        if (r = t[2 * u + a], !isNaN(r) && !isNaN(t[2 * u + 1 - a])) {
          if (0 !== u) {
            if (i <= e && e <= r || e <= i && r <= e) {
              l = u;
              break
            }
            s = u
          }
          i = r
        } return {
        range: [s, l],
        t: (e - i) / (r - i)
      }
    }(s, a = a ? c ? e.x : e.y + e.height : c ? e.x + e.width : e.y, e = c ? "x" : "y")).range)[1] - p[0]) ? (1 < f && !g ? (y = oS(s, p[0]), m.attr({
      x: y[0] + h,
      y: y[1] + o
    }), r && (d = l.getRawValue(p[0]))) : ((y = v.getPointOn(a, e)) && m.attr({
      x: y[0] + h,
      y: y[1] + o
    }), f = l.getRawValue(p[0]), g = l.getRawValue(p[1]), r && (d = Ao(n, u, f, g, c.t))), i.lastFrameIndex = p[0]) : (y = oS(s, v = 1 === t || 0 < i.lastFrameIndex ? p[0] : 0), r && (d = l.getRawValue(v)), m.attr({
      x: y[0] + h,
      y: y[1] + o
    })), r) && "function" == typeof(a = hc(m)).setLabelText && a.setLabelText(d)
  }, hS.prototype._doUpdateAnimation = function(t, e, n, i, r, o, a) {
    var s = this._polyline,
      l = this._polygon,
      u = t.hostModel,
      h = (e = function(t, e, n, i, r, o) {
        a = [], e.diff(t).add((function(t) {
          a.push({
            cmd: "+",
            idx: t
          })
        })).update((function(t, e) {
          a.push({
            cmd: "=",
            idx: e,
            idx1: t
          })
        })).remove((function(t) {
          a.push({
            cmd: "-",
            idx: t
          })
        })).execute();
        for (var a, s = a, l = [], u = [], h = [], c = [], p = [], d = [], f = [], g = Bb(r, e, o), y = t.getLayout("points") || [], m = e.getLayout("points") || [], v = 0; v < s.length; v++) {
          var _ = s[v],
            x = !0,
            w = void 0;
          switch (_.cmd) {
            case "=":
              var b = 2 * _.idx,
                S = (w = 2 * _.idx1, y[b]),
                M = y[1 + b],
                T = m[w],
                I = m[w + 1];
              (isNaN(S) || isNaN(M)) && (S = T, M = I), l.push(S, M), u.push(T, I), h.push(n[b], n[1 + b]), c.push(i[w], i[w + 1]), f.push(e.getRawIndex(_.idx1));
              break;
            case "+":
              S = _.idx, M = g.dataDimsForPoint, T = r.dataToPoint([e.get(M[0], S), e.get(M[1], S)]), w = 2 * S, l.push(T[0], T[1]), u.push(m[w], m[w + 1]), I = Fb(g, r, e, S), h.push(I[0], I[1]), c.push(i[w], i[w + 1]), f.push(e.getRawIndex(S));
              break;
            case "-":
              x = !1
          }
          x && (p.push(_), d.push(d.length))
        }
        d.sort((function(t, e) {
          return f[t] - f[e]
        }));
        var C = O_(o = l.length),
          k = O_(o),
          D = O_(o),
          A = O_(o),
          L = [];
        for (v = 0; v < d.length; v++) {
          var P = d[v],
            O = 2 * v,
            R = 2 * P;
          C[O] = l[R], C[1 + O] = l[1 + R], k[O] = u[R], k[1 + O] = u[1 + R], D[O] = h[R], D[1 + O] = h[1 + R], A[O] = c[R], A[1 + O] = c[1 + R], L[v] = p[P]
        }
        return {
          current: C,
          next: k,
          stackedOnCurrent: D,
          stackedOnNext: A,
          status: L
        }
      }(this._data, t, this._stackedOnPoints, e, this._coordSys, this._valueOrigin)).current,
      c = e.stackedOnCurrent,
      p = e.next,
      d = e.stackedOnNext;
    if (r && (h = rS(e.current, n, r, a), c = rS(e.stackedOnCurrent, n, r, a), p = rS(e.next, n, r, a), d = rS(e.stackedOnNext, n, r, a)), 3e3 < nS(h, p) || l && 3e3 < nS(c, d)) s.stopAnimation(), s.setShape({
      points: p
    }), l && (l.stopAnimation(), l.setShape({
      points: p,
      stackedOnPoints: d
    }));
    else {
      s.shape.__points = e.current, s.shape.points = h;
      n = {
        shape: {
          points: p
        }
      };
      for (var f, g = (e.current !== h && (n.shape.__points = e.next), s.stopAnimation(), xh(s, n, u), l && (l.setShape({
          points: h,
          stackedOnPoints: c
        }), l.stopAnimation(), xh(l, {
          shape: {
            stackedOnPoints: d
          }
        }, u), s.shape.points !== l.shape.points) && (l.shape.points = s.shape.points), []), y = e.status, m = 0; m < y.length; m++) "=" === y[m].cmd && (f = t.getItemGraphicEl(y[m].idx1)) && g.push({
        el: f,
        ptIdx: m
      });
      s.animators && s.animators.length && s.animators[0].during((function() {
        l && l.dirtyShape();
        for (var t = s.shape.__points, e = 0; e < g.length; e++) {
          var n = g[e].el,
            i = 2 * g[e].ptIdx;
          n.x = t[i], n.y = t[1 + i], n.markRedraw()
        }
      }))
    }
  }, hS.prototype.remove = function(t) {
    var e = this.group,
      n = this._data;
    this._lineGroup.removeAll(), this._symbolDraw.remove(!0), n && n.eachItemGraphicEl((function(t, i) {
      t.__temp && (e.remove(t), n.setItemGraphicEl(i, null))
    })), this._polyline = this._polygon = this._coordSys = this._points = this._stackedOnPoints = this._endLabel = this._data = null
  }, hS.type = "line";
  var lS, uS = hS;

  function hS() {
    return null !== lS && lS.apply(this, arguments) || this
  }
  _x((function(t) {
    t.registerChartView(uS), t.registerSeriesModel(Cb), t.registerLayout((!0, {
      seriesType: "line",
      plan: Ag(),
      reset: function(t) {
        var e, n, i, r, o, a = t.getData(),
          s = t.coordinateSystem;
        t = t.pipelineContext;
        if (s) return t = E(s.dimensions, (function(t) {
          return a.mapDimension(t)
        })).slice(0, 2), e = t.length, n = a.getCalculationInfo("stackResultDimension"), l_(a, t[0]) && (t[0] = n), l_(a, t[1]) && (t[1] = n), i = a.getStore(), r = a.getDimensionIndex(t[0]), o = a.getDimensionIndex(t[1]), e && {
          progress: function(t, n) {
            for (var a = O_((t.end - t.start) * e), l = [], u = [], h = t.start, c = 0; h < t.end; h++) {
              var p, d = void 0;
              d = 1 === e ? (p = i.get(r, h), s.dataToPoint(p, null, u)) : (l[0] = i.get(r, h), l[1] = i.get(o, h), s.dataToPoint(l, null, u)), a[c++] = d[0], a[c++] = d[1]
            }
            n.setLayout("points", a)
          }
        }
      }
    })), t.registerVisual({
      seriesType: "line",
      reset: function(t) {
        var e = t.getData();
        (t = t.getModel("lineStyle").getLineStyle()) && !t.stroke && (t.stroke = e.getVisual("style").fill), e.setVisual("legendLineStyle", t)
      }
    }), t.registerProcessor(t.PRIORITY.PROCESSOR.STATISTIC, Hw("line"))
  }));
  var cS, pS = function() {
      this.angle = 0, this.width = 10, this.r = 10, this.x = 0, this.y = 0
    },
    dS = (i(fS, cS = as), fS.prototype.getDefaultShape = function() {
      return new pS
    }, fS.prototype.buildPath = function(t, e) {
      var n = Math.cos,
        i = Math.sin,
        r = e.r,
        o = e.width,
        a = e.angle,
        s = e.x - n(a) * o * (r / 3 <= o ? 1 : 2),
        l = e.y - i(a) * o * (r / 3 <= o ? 1 : 2);
      a = e.angle - Math.PI / 2;
      t.moveTo(s, l), t.lineTo(e.x + n(a) * o, e.y + i(a) * o), t.lineTo(e.x + n(e.angle) * r, e.y + i(e.angle) * r), t.lineTo(e.x - n(a) * o, e.y - i(a) * o), t.lineTo(s, l)
    }, fS);

  function fS(t) {
    return (t = cS.call(this, t) || this).type = "pointer", t
  }

  function gS(t, e) {
    var n = null == t ? "" : t + "";
    return e && (U(e) ? n = e.replace("{value}", n) : G(e) && (n = e(t))), n
  }
  i(vS, yS = Og), vS.prototype.render = function(t, e, n) {
    this.group.removeAll();
    var i, r, o, a, s = t.get(["axisLine", "lineStyle", "color"]),
      l = (r = n, o = (i = t).get("center"), a = r.getWidth(), l = r.getHeight(), a = Math.min(a, l), {
        cx: qr(o[0], r.getWidth()),
        cy: qr(o[1], r.getHeight()),
        r: qr(i.get("radius"), a / 2)
      });
    this._renderMain(t, e, n, s, l), this._data = t.getData()
  }, vS.prototype.dispose = function() {}, vS.prototype._renderMain = function(t, e, n, i, r) {
    for (var o, a = this.group, s = t.get("clockwise"), l = -t.get("startAngle") / 180 * Math.PI, u = -t.get("endAngle") / 180 * Math.PI, h = (o = t.getModel("axisLine")).get("roundCap") ? $w : Su, c = o.get("show"), p = o.getModel("lineStyle"), d = p.get("width"), f = (Ha(o = [l, u], !s), (u = o[1]) - (l = o[0])), g = l, y = [], m = 0; c && m < i.length; m++) {
      var v = new h({
        shape: {
          startAngle: g,
          endAngle: u = l + f * Math.min(Math.max(i[m][0], 0), 1),
          cx: r.cx,
          cy: r.cy,
          clockwise: s,
          r0: r.r - d,
          r: r.r
        },
        silent: !0
      });
      v.setStyle({
        fill: i[m][1]
      }), v.setStyle(p.getLineStyle(["color", "width"])), y.push(v), g = u
    }

    function _(t) {
      if (t <= 0) return i[0][1];
      for (var e = 0; e < i.length; e++)
        if (i[e][0] >= t && (0 === e ? 0 : i[e - 1][0]) < t) return i[e][1];
      return i[e - 1][1]
    }
    y.reverse(), N(y, (function(t) {
      return a.add(t)
    })), this._renderTicks(t, e, n, _, r, l, u, s, d), this._renderTitleAndDetail(t, e, n, _, r), this._renderAnchor(t, r), this._renderPointer(t, e, n, _, r, l, u, s, d)
  }, vS.prototype._renderTicks = function(t, e, n, i, r, o, a, s, l) {
    for (var u, h, c, p, d, f, g, y = this.group, m = r.cx, v = r.cy, _ = r.r, x = +t.get("min"), w = +t.get("max"), b = t.getModel("splitLine"), S = t.getModel("axisTick"), M = t.getModel("axisLabel"), T = t.get("splitNumber"), I = S.get("splitNumber"), C = qr(b.get("length"), _), k = qr(S.get("length"), _), D = o, A = (a - o) / T, L = A / I, P = b.getModel("lineStyle").getLineStyle(), O = S.getModel("lineStyle").getLineStyle(), R = b.get("distance"), N = 0; N <= T; N++)
      if (z = Math.cos(D), B = Math.sin(D), b.get("show") && (u = new Hu({
          shape: {
            x1: z * (_ - (g = R ? R + l : l)) + m,
            y1: B * (_ - g) + v,
            x2: z * (_ - C - g) + m,
            y2: B * (_ - C - g) + v
          },
          style: P,
          silent: !0
        }), "auto" === P.stroke && u.setStyle({
          stroke: i(N / T)
        }), y.add(u)), M.get("show") && (g = M.get("distance") + R, u = gS(jr(N / T * (w - x) + x), M.get("formatter")), h = i(N / T), c = z * (_ - C - g) + m, p = B * (_ - C - g) + v, f = 0, "radial" === (d = M.get("rotate")) ? (f = -D + 2 * Math.PI) > Math.PI / 2 && (f += Math.PI) : "tangential" === d ? f = -D - Math.PI / 2 : Y(d) && (f = d * Math.PI / 180), 0 === f ? y.add(new Ds({
          style: rc(M, {
            text: u,
            x: c,
            y: p,
            verticalAlign: B < -.8 ? "top" : .8 < B ? "bottom" : "middle",
            align: z < -.4 ? "left" : .4 < z ? "right" : "center"
          }, {
            inheritColor: h
          }),
          silent: !0
        })) : y.add(new Ds({
          style: rc(M, {
            text: u,
            x: c,
            y: p,
            verticalAlign: "middle",
            align: "center"
          }, {
            inheritColor: h
          }),
          silent: !0,
          originX: c,
          originY: p,
          rotation: f
        }))), S.get("show") && N !== T) {
        g = (g = S.get("distance")) ? g + l : l;
        for (var E = 0; E <= I; E++) {
          var z = Math.cos(D),
            B = Math.sin(D),
            F = new Hu({
              shape: {
                x1: z * (_ - g) + m,
                y1: B * (_ - g) + v,
                x2: z * (_ - k - g) + m,
                y2: B * (_ - k - g) + v
              },
              silent: !0,
              style: O
            });
          "auto" === O.stroke && F.setStyle({
            stroke: i((N + E / I) / T)
          }), y.add(F), D += L
        }
        D -= L
      } else D += A
  }, vS.prototype._renderPointer = function(t, e, n, i, r, o, a, s, l) {
    var u = this.group,
      h = this._data,
      c = this._progressEls,
      p = [],
      d = t.get(["pointer", "show"]),
      f = t.getModel("progress"),
      g = f.get("show"),
      y = t.getData(),
      m = y.mapDimension("value"),
      v = +t.get("min"),
      _ = +t.get("max"),
      x = [v, _],
      w = [o, a];

    function b(e, n) {
      var i = qr((e = y.getItemModel(e).getModel("pointer")).get("width"), r.r),
        o = qr(e.get("length"), r.r),
        a = t.get(["pointer", "icon"]),
        s = qr((l = e.get("offsetCenter"))[0], r.r),
        l = qr(l[1], r.r);
      e = e.get("keepAspect");
      return (a = a ? By(a, s - i / 2, l - o, i, o, null, e) : new dS({
        shape: {
          angle: -Math.PI / 2,
          width: i,
          r: o,
          x: s,
          y: l
        }
      })).rotation = -(n + Math.PI / 2), a.x = r.cx, a.y = r.cy, a
    }

    function S(t, e) {
      var n = f.get("roundCap") ? $w : Su,
        i = f.get("overlap"),
        a = i ? f.get("width") : l / y.count(),
        u = i ? r.r - a : r.r - (t + 1) * a;
      a = i ? r.r : r.r - t * a, n = new n({
        shape: {
          startAngle: o,
          endAngle: e,
          cx: r.cx,
          cy: r.cy,
          clockwise: s,
          r0: u,
          r: a
        }
      });
      return i && (n.z2 = _ - y.get(m, t) % _), n
    }(g || d) && (y.diff(h).add((function(e) {
      var n, i, r = y.get(m, e);
      d && (wh(n = b(e, o), {
        rotation: -((isNaN(+r) ? w[0] : Yr(r, x, w, !0)) + Math.PI / 2)
      }, t), u.add(n), y.setItemGraphicEl(e, n)), g && (n = S(e, o), i = f.get("clip"), wh(n, {
        shape: {
          endAngle: Yr(r, x, w, i)
        }
      }, t), u.add(n), Gs(t.seriesIndex, y.dataType, e, n), p[e] = n)
    })).update((function(e, n) {
      var i, r, a = y.get(m, e);
      d && ((r = b(e, i = (i = h.getItemGraphicEl(n)) ? i.rotation : o)).rotation = i, xh(r, {
        rotation: -((isNaN(+a) ? w[0] : Yr(a, x, w, !0)) + Math.PI / 2)
      }, t), u.add(r), y.setItemGraphicEl(e, r)), g && (r = S(e, (i = c[n]) ? i.shape.endAngle : o), n = f.get("clip"), xh(r, {
        shape: {
          endAngle: Yr(a, x, w, n)
        }
      }, t), u.add(r), Gs(t.seriesIndex, y.dataType, e, r), p[e] = r)
    })).execute(), y.each((function(t) {
      var e, n, r, o, a = y.getItemModel(t),
        s = (u = a.getModel("emphasis")).get("focus"),
        l = u.get("blurScope"),
        u = u.get("disabled");
      d && (e = y.getItemGraphicEl(t), r = (n = y.getItemVisual(t, "style")).fill, e instanceof gs ? (o = e.style, e.useStyle(k({
        image: o.image,
        x: o.x,
        y: o.y,
        width: o.width,
        height: o.height
      }, n))) : (e.useStyle(n), "pointer" !== e.type && e.setColor(r)), e.setStyle(a.getModel(["pointer", "itemStyle"]).getItemStyle()), "auto" === e.style.fill && e.setStyle("fill", i(Yr(y.get(m, t), x, [0, 1], !0))), e.z2EmphasisLift = 0, Ol(e, a), Al(e, s, l, u)), g && ((o = p[t]).useStyle(y.getItemVisual(t, "style")), o.setStyle(a.getModel(["progress", "itemStyle"]).getItemStyle()), o.z2EmphasisLift = 0, Ol(o, a), Al(o, s, l, u))
    })), this._progressEls = p)
  }, vS.prototype._renderAnchor = function(t, e) {
    var n, i, r, o;
    (t = t.getModel("anchor")).get("show") && (n = t.get("size"), o = t.get("icon"), i = t.get("offsetCenter"), r = t.get("keepAspect"), (o = By(o, e.cx - n / 2 + qr(i[0], e.r), e.cy - n / 2 + qr(i[1], e.r), n, n, null, r)).z2 = t.get("showAbove") ? 1 : 0, o.setStyle(t.getModel("itemStyle").getItemStyle()), this.group.add(o))
  }, vS.prototype._renderTitleAndDetail = function(t, e, n, i, r) {
    var o = this,
      a = t.getData(),
      s = a.mapDimension("value"),
      l = +t.get("min"),
      u = +t.get("max"),
      h = new Rr,
      c = [],
      p = [],
      d = t.isAnimationEnabled(),
      f = t.get(["pointer", "showAbove"]);
    a.diff(this._data).add((function(t) {
      c[t] = new Ds({
        silent: !0
      }), p[t] = new Ds({
        silent: !0
      })
    })).update((function(t, e) {
      c[t] = o._titleEls[e], p[t] = o._detailEls[e]
    })).execute(), a.each((function(e) {
      var n, o, g, y, m, v, _ = a.getItemModel(e),
        x = a.get(s, e),
        w = new Rr,
        b = i(Yr(x, [l, u], [0, 1], !0));
      (v = ((v = _.getModel("title")).get("show") && (n = v.get("offsetCenter"), o = r.cx + qr(n[0], r.r), n = r.cy + qr(n[1], r.r), (y = c[e]).attr({
        z2: f ? 0 : 2,
        style: rc(v, {
          x: o,
          y: n,
          text: a.getName(e),
          align: "center",
          verticalAlign: "middle"
        }, {
          inheritColor: b
        })
      }), w.add(y)), _.getModel("detail"))).get("show") && (o = v.get("offsetCenter"), n = r.cx + qr(o[0], r.r), _ = r.cy + qr(o[1], r.r), o = qr(v.get("width"), r.r), g = qr(v.get("height"), r.r), b = t.get(["progress", "show"]) ? a.getItemVisual(e, "style").fill : b, y = p[e], m = v.get("formatter"), y.attr({
        z2: f ? 0 : 2,
        style: rc(v, {
          x: n,
          y: _,
          text: gS(x, m),
          width: isNaN(o) ? null : o,
          height: isNaN(g) ? null : g,
          align: "center",
          verticalAlign: "middle"
        }, {
          inheritColor: b
        })
      }), cc(y, {
        normal: v
      }, x, (function(t) {
        return gS(t, m)
      })), d && pc(y, e, a, t, {
        getFormattedLabel: function(t, e, n, i, r, o) {
          return gS(o ? o.interpolatedValue : x, m)
        }
      }), w.add(y)), h.add(w)
    })), this.group.add(h), this._titleEls = c, this._detailEls = p
  }, vS.type = "gauge";
  var yS, mS = vS;

  function vS() {
    var t = null !== yS && yS.apply(this, arguments) || this;
    return t.type = vS.type, t
  }
  i(wS, _S = _g), wS.prototype.getInitialData = function(t, e) {
    return n = this, i = W(i = ["value"]) ? {
      coordDimensions: i
    } : k({
      encodeDefine: n.getEncode()
    }, i), i = i_(r = n.getSource(), i).dimensions, (i = new e_(i, n)).initData(r, void 0), i;
    var n, i, r
  }, wS.type = "series.gauge", wS.defaultOption = {
    z: 2,
    colorBy: "data",
    center: ["50%", "50%"],
    legendHoverLink: !0,
    radius: "75%",
    startAngle: 225,
    endAngle: -45,
    clockwise: !0,
    min: 0,
    max: 100,
    splitNumber: 10,
    axisLine: {
      show: !0,
      roundCap: !1,
      lineStyle: {
        color: [
          [1, "#E6EBF8"]
        ],
        width: 10
      }
    },
    progress: {
      show: !1,
      overlap: !0,
      width: 10,
      roundCap: !1,
      clip: !0
    },
    splitLine: {
      show: !0,
      length: 10,
      distance: 10,
      lineStyle: {
        color: "#63677A",
        width: 3,
        type: "solid"
      }
    },
    axisTick: {
      show: !0,
      splitNumber: 5,
      length: 6,
      distance: 10,
      lineStyle: {
        color: "#63677A",
        width: 1,
        type: "solid"
      }
    },
    axisLabel: {
      show: !0,
      distance: 15,
      color: "#464646",
      fontSize: 12,
      rotate: 0
    },
    pointer: {
      icon: null,
      offsetCenter: [0, 0],
      show: !0,
      showAbove: !0,
      length: "60%",
      width: 6,
      keepAspect: !1
    },
    anchor: {
      show: !1,
      showAbove: !1,
      size: 6,
      icon: "circle",
      offsetCenter: [0, 0],
      keepAspect: !1,
      itemStyle: {
        color: "#fff",
        borderWidth: 0,
        borderColor: "#5470c6"
      }
    },
    title: {
      show: !0,
      offsetCenter: [0, "20%"],
      color: "#464646",
      fontSize: 16,
      valueAnimation: !1
    },
    detail: {
      show: !0,
      backgroundColor: "rgba(0,0,0,0)",
      borderWidth: 0,
      borderColor: "#ccc",
      width: 100,
      height: null,
      padding: [5, 10],
      offsetCenter: [0, "40%"],
      color: "#464646",
      fontSize: 30,
      fontWeight: "bold",
      lineHeight: 30,
      valueAnimation: !1
    }
  };
  var _S, xS = wS;

  function wS() {
    var t = null !== _S && _S.apply(this, arguments) || this;
    return t.type = wS.type, t.visualStyleAccessPath = "itemStyle", t
  }
  _x((function(t) {
    t.registerChartView(mS), t.registerSeriesModel(xS)
  })), i(MS, bS = Tp), MS.type = "grid", MS.dependencies = ["xAxis", "yAxis"], MS.layoutMode = "box", MS.defaultOption = {
    show: !1,
    z: 0,
    left: "10%",
    top: 60,
    right: "10%",
    bottom: 70,
    containLabel: !1,
    backgroundColor: "rgba(0,0,0,0)",
    borderWidth: 1,
    borderColor: "#ccc"
  };
  var bS, SS = MS;

  function MS() {
    return null !== bS && bS.apply(this, arguments) || this
  }
  i(CS, TS = Tp), CS.prototype.getCoordSysModel = function() {
    return this.getReferringComponents("grid", Co).models[0]
  }, CS.type = "cartesian2dAxis";
  var TS, IS = CS;

  function CS() {
    return null !== TS && TS.apply(this, arguments) || this
  }
  O(IS, gx);
  var kS, DS = {
      category: Oy = C({
        boundaryGap: !0,
        deduplication: null,
        splitLine: {
          show: !1
        },
        axisTick: {
          alignWithLabel: !1,
          interval: "auto"
        },
        axisLabel: {
          interval: "auto"
        }
      }, ky = {
        show: !0,
        z: 0,
        inverse: !1,
        name: "",
        nameLocation: "end",
        nameRotate: null,
        nameTruncate: {
          maxWidth: null,
          ellipsis: "...",
          placeholder: "."
        },
        nameTextStyle: {},
        nameGap: 15,
        silent: !1,
        triggerEvent: !1,
        tooltip: {
          show: !1
        },
        axisPointer: {},
        axisLine: {
          show: !0,
          onZero: !0,
          onZeroAxisIndex: null,
          lineStyle: {
            color: "#6E7079",
            width: 1,
            type: "solid"
          },
          symbol: ["none", "none"],
          symbolSize: [10, 15]
        },
        axisTick: {
          show: !0,
          inside: !1,
          length: 5,
          lineStyle: {
            width: 1
          }
        },
        axisLabel: {
          show: !0,
          inside: !1,
          rotate: 0,
          showMinLabel: null,
          showMaxLabel: null,
          margin: 8,
          fontSize: 12
        },
        splitLine: {
          show: !0,
          lineStyle: {
            color: ["#E0E6F1"],
            width: 1,
            type: "solid"
          }
        },
        splitArea: {
          show: !1,
          areaStyle: {
            color: ["rgba(250,250,250,0.2)", "rgba(210,219,238,0.2)"]
          }
        }
      }),
      value: kS = C({
        boundaryGap: [0, 0],
        axisLine: {
          show: "auto"
        },
        axisTick: {
          show: "auto"
        },
        splitNumber: 5,
        minorTick: {
          show: !1,
          splitNumber: 5,
          length: 3,
          lineStyle: {}
        },
        minorSplitLine: {
          show: !1,
          lineStyle: {
            color: "#F4F7FD",
            width: 1
          }
        }
      }, ky),
      time: C({
        splitNumber: 6,
        axisLabel: {
          showMinLabel: !1,
          showMaxLabel: !1,
          rich: {
            primary: {
              fontWeight: "bold"
            }
          }
        },
        splitLine: {
          show: !1
        }
      }, kS),
      log: D({
        logBase: 10
      }, kS)
    },
    AS = {
      value: 1,
      category: 1,
      time: 1,
      log: 1
    };

  function LS(t, e, n, r) {
    N(AS, (function(o, a) {
      var s, l = C(C({}, DS[a], !0), r, !0);
      i(u, s = n), u.prototype.mergeDefaultAndTheme = function(t, e) {
        var n = mp(this),
          i = n ? _p(t) : {};
        C(t, e.getTheme().get(a + "Axis")), C(t, this.getDefaultOption()), t.type = PS(t), n && vp(t, i, n)
      }, u.prototype.optionUpdated = function() {
        "category" === this.option.type && (this.__ordinalMeta = f_.createByAxisModel(this))
      }, u.prototype.getCategories = function(t) {
        var e = this.option;
        if ("category" === e.type) return t ? e.data : this.__ordinalMeta.categories
      }, u.prototype.getOrdinalMeta = function() {
        return this.__ordinalMeta
      }, u.type = e + "Axis." + a, u.defaultOption = l, l = u;

      function u() {
        var t = null !== s && s.apply(this, arguments) || this;
        return t.type = e + "Axis." + a, t
      }
      t.registerComponentModel(l)
    })), t.registerSubTypeDefaulter(e + "Axis", PS)
  }

  function PS(t) {
    return t.type || (t.data ? "category" : "value")
  }

  function OS(t) {
    this.type = "cartesian", this._dimList = [], this._axes = {}, this.name = t || ""
  }
  OS.prototype.getAxis = function(t) {
    return this._axes[t]
  }, OS.prototype.getAxes = function() {
    return E(this._dimList, (function(t) {
      return this._axes[t]
    }), this)
  }, OS.prototype.getAxesByScale = function(t) {
    return t = t.toLowerCase(), B(this.getAxes(), (function(e) {
      return e.scale.type === t
    }))
  }, OS.prototype.addAxis = function(t) {
    var e = t.dim;
    this._axes[e] = t, this._dimList.push(e)
  };
  var RS = ["x", "y"];

  function NS(t) {
    return "interval" === t.type || "time" === t.type
  }
  i(BS, ES = OS), BS.prototype.calcAffineTransform = function() {
    this._transform = this._invTransform = null;
    var t, e, n, i, r = this.getAxis("x").scale,
      o = this.getAxis("y").scale;
    NS(r) && NS(o) && (r = r.getExtent(), o = o.getExtent(), i = this.dataToPoint([r[0], o[0]]), e = this.dataToPoint([r[1], o[1]]), t = r[1] - r[0], n = o[1] - o[0], t) && n && (t = (e[0] - i[0]) / t, e = (e[1] - i[1]) / n, n = i[0] - r[0] * t, r = i[1] - o[0] * e, i = this._transform = [t, 0, 0, e, n, r], this._invTransform = we([], i))
  }, BS.prototype.getBaseAxis = function() {
    return this.getAxesByScale("ordinal")[0] || this.getAxesByScale("time")[0] || this.getAxis("x")
  }, BS.prototype.containPoint = function(t) {
    var e = this.getAxis("x"),
      n = this.getAxis("y");
    return e.contain(e.toLocalCoord(t[0])) && n.contain(n.toLocalCoord(t[1]))
  }, BS.prototype.containData = function(t) {
    return this.getAxis("x").containData(t[0]) && this.getAxis("y").containData(t[1])
  }, BS.prototype.containZone = function(t, e) {
    t = this.dataToPoint(t), e = this.dataToPoint(e);
    var n = this.getArea();
    e = new Oe(t[0], t[1], e[0] - t[0], e[1] - t[1]);
    return n.intersect(e)
  }, BS.prototype.dataToPoint = function(t, e, n) {
    n = n || [];
    var i, r = t[0],
      o = t[1];
    return this._transform && null != r && isFinite(r) && null != o && isFinite(o) ? zt(n, t, this._transform) : (t = this.getAxis("x"), i = this.getAxis("y"), n[0] = t.toGlobalCoord(t.dataToCoord(r, e)), n[1] = i.toGlobalCoord(i.dataToCoord(o, e)), n)
  }, BS.prototype.clampData = function(t, e) {
    var n = this.getAxis("x").scale,
      i = this.getAxis("y").scale,
      r = n.getExtent(),
      o = i.getExtent();
    n = n.parse(t[0]), i = i.parse(t[1]);
    return (e = e || [])[0] = Math.min(Math.max(Math.min(r[0], r[1]), n), Math.max(r[0], r[1])), e[1] = Math.min(Math.max(Math.min(o[0], o[1]), i), Math.max(o[0], o[1])), e
  }, BS.prototype.pointToData = function(t, e) {
    var n, i, r = [];
    return this._invTransform ? zt(r, t, this._invTransform) : (n = this.getAxis("x"), i = this.getAxis("y"), r[0] = n.coordToData(n.toLocalCoord(t[0]), e), r[1] = i.coordToData(i.toLocalCoord(t[1]), e), r)
  }, BS.prototype.getOtherAxis = function(t) {
    return this.getAxis("x" === t.dim ? "y" : "x")
  }, BS.prototype.getArea = function(t) {
    t = t || 0;
    var e = this.getAxis("x").getGlobalExtent(),
      n = this.getAxis("y").getGlobalExtent(),
      i = Math.min(e[0], e[1]) - t,
      r = Math.min(n[0], n[1]) - t;
    e = Math.max(e[0], e[1]) - i + t, n = Math.max(n[0], n[1]) - r + t;
    return new Oe(i, r, e, n)
  };
  var ES, zS = BS;

  function BS() {
    var t = null !== ES && ES.apply(this, arguments) || this;
    return t.type = "cartesian2d", t.dimensions = RS, t
  }
  i(HS, FS = gy), HS.prototype.isHorizontal = function() {
    var t = this.position;
    return "top" === t || "bottom" === t
  }, HS.prototype.getGlobalExtent = function(t) {
    var e = this.getExtent();
    return e[0] = this.toGlobalCoord(e[0]), e[1] = this.toGlobalCoord(e[1]), t && e[0] > e[1] && e.reverse(), e
  }, HS.prototype.pointToData = function(t, e) {
    return this.coordToData(this.toLocalCoord(t["x" === this.dim ? 0 : 1]), e)
  }, HS.prototype.setCategorySortInfo = function(t) {
    if ("category" !== this.type) return !1;
    this.model.option.categorySortInfo = t, this.scale.setSortInfo(t)
  };
  var FS, VS = HS;

  function HS(t, e, n, i, r) {
    return (t = FS.call(this, t, e, n) || this).index = 0, t.type = i || "value", t.position = r || "bottom", t
  }

  function WS(t, e, n) {
    n = n || {};
    t = t.coordinateSystem;
    var i = {},
      r = (s = e.axis).getAxesOnZeroOf()[0],
      o = s.position,
      a = r ? "onZero" : o,
      s = s.dim,
      l = (t = [(t = t.getRect()).x, t.x + t.width, t.y, t.y + t.height], {
        left: 0,
        right: 1,
        top: 0,
        bottom: 1,
        onZero: 2
      }),
      u = e.get("offset") || 0,
      h = (u = "x" === s ? [t[2] - u, t[3] + u] : [t[0] - u, t[1] + u], r && (h = r.toGlobalCoord(r.dataToCoord(0)), u[l.onZero] = Math.max(Math.min(h, u[1]), u[0])), i.position = ["y" === s ? u[l[a]] : t[0], "x" === s ? u[l[a]] : t[3]], i.rotation = Math.PI / 2 * ("x" === s ? 0 : 1), i.labelDirection = i.tickDirection = i.nameDirection = {
        top: -1,
        bottom: 1,
        left: -1,
        right: 1
      } [o], i.labelOffset = r ? u[l[o]] - u[l.onZero] : 0, e.get(["axisTick", "inside"]) && (i.tickDirection = -i.tickDirection), et(n.labelInside, e.get(["axisLabel", "inside"])) && (i.labelDirection = -i.labelDirection), e.get(["axisLabel", "rotate"]));
    return i.labelRotate = "top" === a ? -h : h, i.z2 = 1, i
  }

  function GS(t) {
    return "cartesian2d" === t.get("coordinateSystem")
  }

  function US(t) {
    var e = {
      xAxisModel: null,
      yAxisModel: null
    };
    return N(e, (function(n, i) {
      var r = i.replace(/Model$/, "");
      r = t.getReferringComponents(r, Co).models[0];
      e[i] = r
    })), e
  }
  var XS = Math.log;
  qS.prototype.getRect = function() {
    return this._rect
  }, qS.prototype.update = function(t, e) {
    var n = this._axesMap;

    function i(t) {
      var e, n = F(t),
        i = n.length;
      if (i) {
        for (var r = [], o = i - 1; 0 <= o; o--) {
          var a = t[+n[o]],
            s = a.model,
            l = a.scale;
          m_(l) && s.get("alignTicks") && null == s.get("interval") ? r.push(a) : (ux(l, s), m_(l) && (e = a))
        }
        r.length && (e || ux((e = r.pop()).scale, e.model), N(r, (function(t) {
          var n = t.scale,
            i = (t = t.model, e.scale),
            r = D_.prototype,
            o = r.getTicks.call(i),
            a = r.getTicks.call(i, !0),
            s = o.length - 1,
            l = (i = r.getInterval.call(i), (t = lx(n, t)).extent),
            u = t.fixMin,
            h = (t = t.fixMax, "log" === n.type && (h = XS(n.base), l = [XS(l[0]) / h, XS(l[1]) / h]), n.setExtent(l[0], l[1]), n.calcNiceExtent({
              splitNumber: s,
              fixMin: u,
              fixMax: t
            }), r.getExtent.call(n)),
            c = (u && (l[0] = h[0]), t && (l[1] = h[1]), r.getInterval.call(n)),
            p = l[0],
            d = l[1];
          if (u && t) c = (d - p) / s;
          else if (u)
            for (d = l[0] + c * s; d < l[1] && isFinite(d) && isFinite(l[1]);) c = v_(c), d = l[0] + c * s;
          else if (t)
            for (p = l[1] - c * s; p > l[0] && isFinite(p) && isFinite(l[0]);) c = v_(c), p = l[1] - c * s;
          else h = (c = s < n.getTicks().length - 1 ? v_(c) : c) * s, (p = jr((d = Math.ceil(l[1] / c) * c) - h)) < 0 && 0 <= l[0] ? (p = 0, d = jr(h)) : 0 < d && l[1] <= 0 && (d = 0, p = -jr(h));
          u = (o[0].value - a[0].value) / i, t = (o[s].value - a[s].value) / i, r.setExtent.call(n, p + c * u, d + c * t), r.setInterval.call(n, c), (u || t) && r.setNiceExtent.call(n, p + c, d - c)
        })))
      }
    }
    this._updateScale(t, this.model), i(n.x), i(n.y);
    var r = {};
    N(n.x, (function(t) {
      ZS(n, "y", t, r)
    })), N(n.y, (function(t) {
      ZS(n, "x", t, r)
    })), this.resize(this.model, e)
  }, qS.prototype.resize = function(t, e, n) {
    var i = t.getBoxLayoutParams(),
      r = (n = !n && t.get("containLabel"), yp(i, {
        width: e.getWidth(),
        height: e.getHeight()
      })),
      o = (this._rect = r, this._axesList);

    function a() {
      N(o, (function(t) {
        var e, n, i = t.isHorizontal(),
          o = i ? [0, r.width] : [0, r.height],
          a = t.inverse ? 1 : 0;
        t.setExtent(o[a], o[1 - a]), o = t, e = i ? r.x : r.y, a = o.getExtent(), n = a[0] + a[1], o.toGlobalCoord = "x" === o.dim ? function(t) {
          return t + e
        } : function(t) {
          return n - t + e
        }, o.toLocalCoord = "x" === o.dim ? function(t) {
          return t - e
        } : function(t) {
          return n - t + e
        }
      }))
    }
    a(), n && (N(o, (function(t) {
      var e, n, i;
      t.model.get(["axisLabel", "inside"]) || (e = function(t) {
        var e = t.model,
          n = t.scale;
        if (e.get(["axisLabel", "show"]) && !n.isBlank()) {
          var i, r, o = n.getExtent(),
            a = n instanceof T_ ? n.count() : (i = n.getTicks()).length,
            s = t.getLabelModel(),
            l = cx(t),
            u = 1;
          40 < a && (u = Math.ceil(a / 40));
          for (var h, c, p, d = 0; d < a; d += u) {
            var f = l(i ? i[d] : {
                value: o[0] + d
              }, d),
              g = (f = f = s.getTextRect(f), c = g = c = void 0, h = (h = s.get("rotate") || 0) * Math.PI / 180, c = f.width, g = f.height, p = c * Math.abs(Math.cos(h)) + Math.abs(g * Math.sin(h)), c = c * Math.abs(Math.sin(h)) + Math.abs(g * Math.cos(h)), new Oe(f.x, f.y, p, c));
            r ? r.union(g) : r = g
          }
          return r
        }
      }(t)) && (n = t.isHorizontal() ? "height" : "width", i = t.model.get(["axisLabel", "margin"]), r[n] -= e[n] + i, "top" === t.position ? r.y += e.height + i : "left" === t.position && (r.x += e.width + i))
    })), a()), N(this._coordsList, (function(t) {
      t.calcAffineTransform()
    }))
  }, qS.prototype.getAxis = function(t, e) {
    if (null != (t = this._axesMap[t])) return t[e || 0]
  }, qS.prototype.getAxes = function() {
    return this._axesList.slice()
  }, qS.prototype.getCartesian = function(t, e) {
    if (null != t && null != e) return this._coordsMap["x" + t + "y" + e];
    q(t) && (e = t.yAxisIndex, t = t.xAxisIndex);
    for (var n = 0, i = this._coordsList; n < i.length; n++)
      if (i[n].getAxis("x").index === t || i[n].getAxis("y").index === e) return i[n]
  }, qS.prototype.getCartesians = function() {
    return this._coordsList.slice()
  }, qS.prototype.convertToPixel = function(t, e, n) {
    return (e = this._findConvertTarget(e)).cartesian ? e.cartesian.dataToPoint(n) : e.axis ? e.axis.toGlobalCoord(e.axis.dataToCoord(n)) : null
  }, qS.prototype.convertFromPixel = function(t, e, n) {
    return (e = this._findConvertTarget(e)).cartesian ? e.cartesian.pointToData(n) : e.axis ? e.axis.coordToData(e.axis.toLocalCoord(n)) : null
  }, qS.prototype._findConvertTarget = function(t) {
    var e, n, i = t.seriesModel,
      r = t.xAxisModel || i && i.getReferringComponents("xAxis", Co).models[0],
      o = t.yAxisModel || i && i.getReferringComponents("yAxis", Co).models[0],
      a = (t = t.gridModel, this._coordsList);
    return i ? L(a, e = i.coordinateSystem) < 0 && (e = null) : r && o ? e = this.getCartesian(r.componentIndex, o.componentIndex) : r ? n = this.getAxis("x", r.componentIndex) : o ? n = this.getAxis("y", o.componentIndex) : t && t.coordinateSystem === this && (e = this._coordsList[0]), {
      cartesian: e,
      axis: n
    }
  }, qS.prototype.containPoint = function(t) {
    var e = this._coordsList[0];
    if (e) return e.containPoint(t)
  }, qS.prototype._initCartesian = function(t, e, n) {
    var i = this,
      r = this,
      o = {
        left: !1,
        right: !1,
        top: !1,
        bottom: !1
      },
      a = {
        x: {},
        y: {}
      },
      s = {
        x: 0,
        y: 0
      };

    function l(e) {
      return function(n, i) {
        var l, u;
        jS(n, t) && (l = n.get("position"), "x" === e ? "top" !== l && "bottom" !== l && (l = o.bottom ? "top" : "bottom") : "left" !== l && "right" !== l && (l = o.left ? "right" : "left"), o[l] = !0, u = "category" === (l = new VS(e, hx(n), [0, 0], n.get("type"), l)).type, l.onBand = u && n.get("boundaryGap"), l.inverse = n.get("inverse"), (n.axis = l).model = n, l.grid = r, l.index = i, r._axesList.push(l), a[e][i] = l, s[e]++)
      }
    }
    e.eachComponent("xAxis", l("x"), this), e.eachComponent("yAxis", l("y"), this), s.x && s.y ? N((this._axesMap = a).x, (function(e, n) {
      N(a.y, (function(r, o) {
        var a = new zS(o = "x" + n + "y" + o);
        a.master = i, a.model = t, i._coordsMap[o] = a, i._coordsList.push(a), a.addAxis(e), a.addAxis(r)
      }))
    })) : (this._axesMap = {}, this._axesList = [])
  }, qS.prototype._updateScale = function(t, e) {
    function n(t, e) {
      var n, i, r;
      N((n = t, i = e.dim, r = {}, N(n.mapDimensionsAll(i), (function(t) {
        r[u_(n, t)] = !0
      })), F(r)), (function(n) {
        e.scale.unionExtentFromData(t, n)
      }))
    }
    N(this._axesList, (function(t) {
      var e;
      t.scale.setExtent(1 / 0, -1 / 0), "category" === t.type && (e = t.model.get("categorySortInfo"), t.scale.setSortInfo(e))
    })), t.eachSeries((function(t) {
      var i, r;
      GS(t) && (r = (i = US(t)).xAxisModel, i = i.yAxisModel, jS(r, e)) && jS(i, e) && (r = this.getCartesian(r.componentIndex, i.componentIndex), i = t.getData(), t = r.getAxis("x"), r = r.getAxis("y"), n(i, t), n(i, r))
    }), this)
  }, qS.prototype.getTooltipAxes = function(t) {
    var e = [],
      n = [];
    return N(this.getCartesians(), (function(i) {
      var r = null != t && "auto" !== t ? i.getAxis(t) : i.getBaseAxis();
      i = i.getOtherAxis(r);
      L(e, r) < 0 && e.push(r), L(n, i) < 0 && n.push(i)
    })), {
      baseAxes: e,
      otherAxes: n
    }
  }, qS.create = function(t, e) {
    var n = [];
    return t.eachComponent("grid", (function(i, r) {
      var o = new qS(i, t, e);
      o.name = "grid_" + r, o.resize(i, e, !0), i.coordinateSystem = o, n.push(o)
    })), t.eachSeries((function(t) {
      var e, n, i;
      GS(t) && (e = (n = US(t)).xAxisModel, n = n.yAxisModel, i = e.getCoordSysModel().coordinateSystem, t.coordinateSystem = i.getCartesian(e.componentIndex, n.componentIndex))
    })), n
  }, qS.dimensions = RS;
  var YS = qS;

  function qS(t, e, n) {
    this.type = "grid", this._coordsMap = {}, this._coordsList = [], this._axesMap = {}, this._axesList = [], this.axisPointerEnabled = !0, this.dimensions = RS, this._initCartesian(t, e, n), this.model = t
  }

  function jS(t, e) {
    return t.getCoordSysModel() === e
  }

  function ZS(t, e, n, i) {
    n.getAxesOnZeroOf = function() {
      return r ? [r] : []
    };
    var r, o = t[e];
    e = (t = n.model).get(["axisLine", "onZero"]), n = t.get(["axisLine", "onZeroAxisIndex"]);
    if (e) {
      if (null != n) KS(o[n]) && (r = o[n]);
      else
        for (var a in o)
          if (o.hasOwnProperty(a) && KS(o[a]) && !i[s(o[a])]) {
            r = o[a];
            break
          } r && (i[s(r)] = !0)
    }

    function s(t) {
      return t.dim + "_" + t.index
    }
  }

  function KS(t) {
    return t && "category" !== t.type && "time" !== t.type && (e = (t = (t = t).scale.getExtent())[0], t = t[1], !(0 < e && 0 < t || e < 0 && t < 0));
    var e
  }
  var $S = Math.PI,
    QS = (JS.prototype.hasBuilder = function(t) {
      return !!tM[t]
    }, JS.prototype.add = function(t) {
      tM[t](this.opt, this.axisModel, this.group, this._transformGroup)
    }, JS.prototype.getGroup = function() {
      return this.group
    }, JS.innerTextLayout = function(t, e, n) {
      var i;
      return {
        rotation: e = Qr(e - t),
        textAlign: t = Jr(e) ? (i = 0 < n ? "top" : "bottom", "center") : Jr(e - $S) ? (i = 0 < n ? "bottom" : "top", "center") : (i = "middle", 0 < e && e < $S ? 0 < n ? "right" : "left" : 0 < n ? "left" : "right"),
        textVerticalAlign: i
      }
    }, JS.makeAxisEventDataBase = function(t) {
      var e = {
        componentType: t.mainType,
        componentIndex: t.componentIndex
      };
      return e[t.mainType + "Index"] = t.componentIndex, e
    }, JS.isLabelSilent = function(t) {
      var e = t.get("tooltip");
      return t.get("silent") || !(t.get("triggerEvent") || e && e.show)
    }, JS);

  function JS(t, e) {
    this.group = new Rr, this.opt = e, this.axisModel = t, D(e, {
      labelOffset: 0,
      nameDirection: 1,
      tickDirection: 1,
      labelDirection: 1,
      silent: !0,
      handleAutoShown: function() {
        return !0
      }
    }), (t = new Rr({
      x: e.position[0],
      y: e.position[1],
      rotation: e.rotation
    })).updateTransform(), this._transformGroup = t
  }
  var tM = {
    axisLine: function(t, e, n, i) {
      var r, o, a, s, l, u, h, c = e.get(["axisLine", "show"]);
      (c = "auto" === c && t.handleAutoShown ? t.handleAutoShown("axisLine") : c) && (c = e.axis.getExtent(), i = i.transform, r = [c[0], 0], o = [c[1], 0], a = o[0] < r[0], i && (zt(r, r, i), zt(o, o, i)), s = k({
        lineCap: "round"
      }, e.getModel(["axisLine", "lineStyle"]).getLineStyle()), Fh((c = new Hu({
        shape: {
          x1: r[0],
          y1: r[1],
          x2: o[0],
          y2: o[1]
        },
        style: s,
        strokeContainThreshold: t.strokeContainThreshold || 5,
        silent: !0,
        z2: 1
      })).shape, c.style.lineWidth), c.anid = "line", n.add(c), null != (l = e.get(["axisLine", "symbol"]))) && (i = e.get(["axisLine", "symbolSize"]), U(l) && (l = [l, l]), (U(i) || Y(i)) && (i = [i, i]), c = Vy(e.get(["axisLine", "symbolOffset"]) || 0, i), u = i[0], h = i[1], N([{
        rotate: t.rotation + Math.PI / 2,
        offset: c[0],
        r: 0
      }, {
        rotate: t.rotation - Math.PI / 2,
        offset: c[1],
        r: Math.sqrt((r[0] - o[0]) * (r[0] - o[0]) + (r[1] - o[1]) * (r[1] - o[1]))
      }], (function(e, i) {
        var c;
        "none" !== l[i] && null != l[i] && (i = By(l[i], -u / 2, -h / 2, u, h, s.stroke, !0), c = e.r + e.offset, i.attr({
          rotation: e.rotate,
          x: (e = a ? o : r)[0] + c * Math.cos(t.rotation),
          y: e[1] - c * Math.sin(t.rotation),
          silent: !0,
          z2: 11
        }), n.add(i))
      })))
    },
    axisTickLabel: function(t, e, n, i) {
      var r, o, a, s, l, u = function(t, e, n, i) {
          var r = n.axis,
            o = n.getModel("axisTick");
          if ("auto" === (a = o.get("show")) && i.handleAutoShown && (a = i.handleAutoShown("axisTick")), a && !r.scale.isBlank()) {
            for (var a = o.getModel("lineStyle"), s = (i = i.tickDirection * o.get("length"), rM(r.getTicksCoords(), e.transform, i, D(a.getLineStyle(), {
                stroke: n.get(["axisLine", "lineStyle", "color"])
              }), "ticks")), l = 0; l < s.length; l++) t.add(s[l]);
            return s
          }
        }(n, i, e, t),
        h = function(t, e, n, i) {
          var r, o, a, s, l, u, h, c, p = n.axis,
            d = et(i.axisLabelShow, n.get(["axisLabel", "show"]));
          if (d && !p.scale.isBlank()) return r = n.getModel("axisLabel"), o = r.get("margin"), a = p.getViewLabels(), d = (et(i.labelRotate, r.get("rotate")) || 0) * $S / 180, s = QS.innerTextLayout(i.rotation, d, i.labelDirection), l = n.getCategories && n.getCategories(!0), u = [], h = QS.isLabelSilent(n), c = n.get("triggerEvent"), N(a, (function(d, f) {
            var g = "ordinal" === p.scale.type ? p.scale.getRawOrdinalNumber(d.tickValue) : d.tickValue,
              y = d.formattedLabel,
              m = d.rawLabel,
              v = r,
              _ = (v = l && l[g] && q(_ = l[g]) && _.textStyle ? new Mc(_.textStyle, r, n.ecModel) : v).getTextColor() || n.get(["axisLine", "lineStyle", "color"]),
              x = p.dataToCoord(g),
              w = v.getShallow("align", !0) || s.textAlign,
              b = nt(v.getShallow("alignMinLabel", !0), w),
              S = nt(v.getShallow("alignMaxLabel", !0), w),
              M = v.getShallow("verticalAlign", !0) || v.getShallow("baseline", !0) || s.textVerticalAlign,
              T = nt(v.getShallow("verticalAlignMinLabel", !0), M),
              I = nt(v.getShallow("verticalAlignMaxLabel", !0), M);
            (x = new Ds({
              x: x,
              y: i.labelOffset + i.labelDirection * o,
              rotation: s.rotation,
              silent: h,
              z2: 10 + (d.level || 0),
              style: rc(v, {
                text: y,
                align: 0 === f ? b : f === a.length - 1 ? S : w,
                verticalAlign: 0 === f ? T : f === a.length - 1 ? I : M,
                fill: G(_) ? _("category" === p.type ? m : "value" === p.type ? g + "" : g, f) : _
              })
            })).anid = "label_" + g, c && ((d = QS.makeAxisEventDataBase(n)).targetType = "axisLabel", d.value = m, d.tickIndex = f, "category" === p.type && (d.dataIndex = g), Us(x).eventData = d), e.add(x), x.updateTransform(), u.push(x), t.add(x), x.decomposeTransform()
          })), u
        }(n, i, e, t),
        c = (o = h, u = u, fx((r = e).axis) || (d = r.get(["axisLabel", "showMinLabel"]), r = r.get(["axisLabel", "showMaxLabel"]), u = u || [], y = (o = o || [])[0], f = o[1], a = o[o.length - 1], o = o[o.length - 2], s = u[0], g = u[1], l = u[u.length - 1], u = u[u.length - 2], !1 === d ? (eM(y), eM(s)) : nM(y, f) && (d ? (eM(f), eM(g)) : (eM(y), eM(s))), !1 === r ? (eM(a), eM(l)) : nM(o, a) && (r ? (eM(o), eM(u)) : (eM(a), eM(l)))), n),
        p = i,
        d = e,
        f = t.tickDirection,
        g = d.axis,
        y = d.getModel("minorTick");
      if (y.get("show") && !g.scale.isBlank()) {
        var m = g.getMinorTicksCoords();
        if (m.length) {
          g = y.getModel("lineStyle");
          for (var v = f * y.get("length"), _ = D(g.getLineStyle(), D(d.getModel("axisTick").getLineStyle(), {
              stroke: d.get(["axisLine", "lineStyle", "color"])
            })), x = 0; x < m.length; x++)
            for (var w = rM(m[x], p.transform, v, _, "minorticks_" + x), b = 0; b < w.length; b++) c.add(w[b])
        }
      }
      e.get(["axisLabel", "hideOverlap"]) && dw(cw(E(h, (function(t) {
        return {
          label: t,
          priority: t.z2,
          defaultAttr: {
            ignore: t.ignore
          }
        }
      }))))
    },
    axisName: function(t, e, n, i) {
      var r, o, a, s, l, u, h, c, p = et(t.axisName, e.get("name"));
      p && (c = e.get("nameLocation"), l = t.nameDirection, r = e.getModel("nameTextStyle"), u = e.get("nameGap") || 0, o = (h = e.axis.getExtent())[0] > h[1] ? -1 : 1, o = ["start" === c ? h[0] - o * u : "end" === c ? h[1] + o * u : (h[0] + h[1]) / 2, iM(c) ? t.labelOffset + l * u : 0], null != (u = e.get("nameRotate")) && (u = u * $S / 180), iM(c) ? a = QS.innerTextLayout(t.rotation, null != u ? u : t.rotation, l) : (a = function(t, e, n, i) {
        var r;
        n = Qr(n - t), t = i[0] > i[1], i = "start" === e && !t || "start" !== e && t;
        return {
          rotation: n,
          textAlign: e = Jr(n - $S / 2) ? (r = i ? "bottom" : "top", "center") : Jr(n - 1.5 * $S) ? (r = i ? "top" : "bottom", "center") : (r = "middle", n < 1.5 * $S && $S / 2 < n ? i ? "left" : "right" : i ? "right" : "left"),
          textVerticalAlign: r
        }
      }(t.rotation, c, u || 0, h), null != (s = t.axisNameAvailableWidth) && (s = Math.abs(s / Math.sin(a.rotation)), isFinite(s) || (s = null))), l = r.getFont(), u = (c = e.get("nameTruncate", !0) || {}).ellipsis, h = et(t.nameTruncateMaxWidth, c.maxWidth, s), Zh({
        el: t = new Ds({
          x: o[0],
          y: o[1],
          rotation: a.rotation,
          silent: QS.isLabelSilent(e),
          style: rc(r, {
            text: p,
            font: l,
            overflow: "truncate",
            width: h,
            ellipsis: u,
            fill: r.getTextColor() || e.get(["axisLine", "lineStyle", "color"]),
            align: r.get("align") || a.textAlign,
            verticalAlign: r.get("verticalAlign") || a.textVerticalAlign
          }),
          z2: 1
        }),
        componentModel: e,
        itemName: p
      }), t.__fullText = p, t.anid = "name", e.get("triggerEvent") && ((c = QS.makeAxisEventDataBase(e)).targetType = "axisName", c.name = p, Us(t).eventData = c), i.add(t), t.updateTransform(), n.add(t), t.decomposeTransform())
    }
  };

  function eM(t) {
    t && (t.ignore = !0)
  }

  function nM(t, e) {
    var n, i = t && t.getBoundingRect().clone(),
      r = e && e.getBoundingRect().clone();
    if (i && r) return _e(n = ge([]), n, -t.rotation), i.applyTransform(me([], n, t.getLocalTransform())), r.applyTransform(me([], n, e.getLocalTransform())), i.intersect(r)
  }

  function iM(t) {
    return "middle" === t || "center" === t
  }

  function rM(t, e, n, i, r) {
    for (var o = [], a = [], s = [], l = 0; l < t.length; l++) {
      var u = t[l].coord;
      Fh((u = (a[0] = u, s[a[1] = 0] = u, s[1] = n, e && (zt(a, a, e), zt(s, s, e)), new Hu({
        shape: {
          x1: a[0],
          y1: a[1],
          x2: s[0],
          y2: s[1]
        },
        style: i,
        z2: 2,
        autoBatch: !0,
        silent: !0
      }))).shape, u.style.lineWidth), u.anid = r + "_" + t[l].tickValue, o.push(u)
    }
    return o
  }

  function oM(t, e) {
    return "all" === t || W(t) && 0 <= L(t, e) || t === e
  }

  function aM(t) {
    var e = (t.ecModel.getComponent("axisPointer") || {}).coordSysAxesInfo;
    return e && e.axesInfo[lM(t)]
  }

  function sM(t) {
    return !!t.get(["handle", "show"])
  }

  function lM(t) {
    return t.type + "||" + t.id
  }
  var uM, hM = {},
    cM = (i(pM, uM = kg), pM.prototype.render = function(t, e, n, i) {
      var r, o, a, s, l, u;
      this.axisPointerClass && (r = aM(r = t)) && (l = r.axisPointerModel, o = r.axis.scale, a = l.option, u = l.get("status"), null != (s = l.get("value")) && (s = o.parse(s)), l = sM(l), null == u && (a.status = l ? "show" : "hide"), (u = o.getExtent().slice())[0] > u[1] && u.reverse(), (s = null == s || s > u[1] ? u[1] : s) < u[0] && (s = u[0]), a.value = s, l) && (a.status = r.axis.scale.isBlank() ? "hide" : "show"), uM.prototype.render.apply(this, arguments), this._doUpdateAxisPointerClass(t, n, !0)
    }, pM.prototype.updateAxisPointer = function(t, e, n, i) {
      this._doUpdateAxisPointerClass(t, n, !1)
    }, pM.prototype.remove = function(t, e) {
      var n = this._axisPointer;
      n && n.remove(e)
    }, pM.prototype.dispose = function(t, e) {
      this._disposeAxisPointer(e), uM.prototype.dispose.apply(this, arguments)
    }, pM.prototype._doUpdateAxisPointerClass = function(t, e, n) {
      var i, r = pM.getAxisPointerClass(this.axisPointerClass);
      r && ((i = (i = aM(i = t)) && i.axisPointerModel) ? (this._axisPointer || (this._axisPointer = new r)).render(t, i, e, n) : this._disposeAxisPointer(e))
    }, pM.prototype._disposeAxisPointer = function(t) {
      this._axisPointer && this._axisPointer.dispose(t), this._axisPointer = null
    }, pM.registerAxisPointerClass = function(t, e) {
      hM[t] = e
    }, pM.getAxisPointerClass = function(t) {
      return t && hM[t]
    }, pM.type = "axis", pM);

  function pM() {
    var t = null !== uM && uM.apply(this, arguments) || this;
    return t.type = pM.type, t
  }
  var dM, fM = So(),
    gM = ["axisLine", "axisTickLabel", "axisName"],
    yM = ["splitArea", "splitLine", "minorSplitLine"],
    mM = (i(vM, dM = cM), vM.prototype.render = function(t, e, n, i) {
      this.group.removeAll();
      var r, o, a = this._axisGroup;
      this._axisGroup = new Rr, this.group.add(this._axisGroup), t.get("show") && (o = WS(r = t.getCoordSysModel(), t), o = new QS(t, k({
        handleAutoShown: function(e) {
          for (var n = r.coordinateSystem.getCartesians(), i = 0; i < n.length; i++)
            if (m_(n[i].getOtherAxis(t.axis).scale)) return !0;
          return !1
        }
      }, o)), N(gM, o.add, o), this._axisGroup.add(o.getGroup()), N(yM, (function(e) {
        t.get([e, "show"]) && xM[e](this, this._axisGroup, t, r)
      }), this), i && "changeAxisOrder" === i.type && i.isInitSort || Uh(a, this._axisGroup, t), dM.prototype.render.call(this, t, e, n, i))
    }, vM.prototype.remove = function() {
      fM(this).splitAreaColors = null
    }, vM.type = "cartesianAxis", vM);

  function vM() {
    var t = null !== dM && dM.apply(this, arguments) || this;
    return t.type = vM.type, t.axisPointerClass = "CartesianAxisPointer", t
  }
  var _M, xM = {
      splitLine: function(t, e, n, i) {
        var r = n.axis;
        if (!r.scale.isBlank())
          for (var o = (n = n.getModel("splitLine")).getModel("lineStyle"), a = W(a = o.get("color")) ? a : [a], s = i.coordinateSystem.getRect(), l = r.isHorizontal(), u = 0, h = r.getTicksCoords({
              tickModel: n
            }), c = [], p = [], d = o.getLineStyle(), f = 0; f < h.length; f++) {
            var g = r.toGlobalCoord(h[f].coord),
              y = (g = (l ? (c[0] = g, c[1] = s.y, p[0] = g, p[1] = s.y + s.height) : (c[0] = s.x, c[1] = g, p[0] = s.x + s.width, p[1] = g), u++ % a.length), h[f].tickValue);
            Fh((y = new Hu({
              anid: null != y ? "line_" + h[f].tickValue : null,
              autoBatch: !0,
              shape: {
                x1: c[0],
                y1: c[1],
                x2: p[0],
                y2: p[1]
              },
              style: D({
                stroke: a[g]
              }, d),
              silent: !0
            })).shape, d.lineWidth), e.add(y)
          }
      },
      minorSplitLine: function(t, e, n, i) {
        var r = n.axis,
          o = (n = n.getModel("minorSplitLine").getModel("lineStyle"), i.coordinateSystem.getRect()),
          a = r.isHorizontal(),
          s = r.getMinorTicksCoords();
        if (s.length)
          for (var l = [], u = [], h = n.getLineStyle(), c = 0; c < s.length; c++)
            for (var p = 0; p < s[c].length; p++) {
              var d = r.toGlobalCoord(s[c][p].coord);
              Fh((d = (a ? (l[0] = d, l[1] = o.y, u[0] = d, u[1] = o.y + o.height) : (l[0] = o.x, l[1] = d, u[0] = o.x + o.width, u[1] = d), new Hu({
                anid: "minor_line_" + s[c][p].tickValue,
                autoBatch: !0,
                shape: {
                  x1: l[0],
                  y1: l[1],
                  x2: u[0],
                  y2: u[1]
                },
                style: h,
                silent: !0
              }))).shape, h.lineWidth), e.add(d)
            }
      },
      splitArea: function(t, e, n, i) {
        var r = e,
          o = (e = i, (i = n).axis);
        if (!o.scale.isBlank()) {
          var a = (n = (i = i.getModel("splitArea")).getModel("areaStyle")).get("color"),
            s = e.coordinateSystem.getRect(),
            l = o.getTicksCoords({
              tickModel: i,
              clamp: !0
            });
          if (l.length) {
            var u = a.length,
              h = fM(t).splitAreaColors,
              c = yt(),
              p = 0;
            if (h)
              for (var d = 0; d < l.length; d++) {
                var f = h.get(l[d].tickValue);
                if (null != f) {
                  p = (f + (u - 1) * d) % u;
                  break
                }
              }
            var g = o.toGlobalCoord(l[0].coord),
              y = n.getAreaStyle();
            for (a = W(a) ? a : [a], d = 1; d < l.length; d++) {
              var m = o.toGlobalCoord(l[d].coord),
                v = void 0,
                _ = void 0,
                x = void 0,
                w = void 0;
              g = o.isHorizontal() ? (v = g, _ = s.y, w = s.height, v + (x = m - v)) : (v = s.x, _ = g, x = s.width, _ + (w = m - _));
              null != (m = l[d - 1].tickValue) && c.set(m, p), r.add(new Ms({
                anid: null != m ? "area_" + m : null,
                shape: {
                  x: v,
                  y: _,
                  width: x,
                  height: w
                },
                style: D({
                  fill: a[p]
                }, y),
                autoBatch: !0,
                silent: !0
              })), p = (p + 1) % u
            }
            fM(t).splitAreaColors = c
          }
        }
      }
    },
    wM = (i(bM, _M = mM), bM.type = "xAxis", bM);

  function bM() {
    var t = null !== _M && _M.apply(this, arguments) || this;
    return t.type = bM.type, t
  }
  i(TM, SM = mM), TM.type = "yAxis";
  var SM, MM = TM;

  function TM() {
    var t = null !== SM && SM.apply(this, arguments) || this;
    return t.type = wM.type, t
  }
  i(kM, IM = kg), kM.prototype.render = function(t, e) {
    this.group.removeAll(), t.get("show") && this.group.add(new Ms({
      shape: t.coordinateSystem.getRect(),
      style: D({
        fill: t.get("backgroundColor")
      }, t.getItemStyle()),
      silent: !0,
      z2: -1
    }))
  }, kM.type = "grid";
  var IM, CM = kM;

  function kM() {
    var t = null !== IM && IM.apply(this, arguments) || this;
    return t.type = "grid", t
  }
  var DM = {
    offset: 0
  };
  _x((function(t) {
    t.registerComponentView(CM), t.registerComponentModel(SS), t.registerCoordinateSystem("cartesian2d", YS), LS(t, "x", IS, DM), LS(t, "y", IS, DM), t.registerComponentView(wM), t.registerComponentView(MM), t.registerPreprocessor((function(t) {
      t.xAxis && t.yAxis && !t.grid && (t.grid = {})
    }))
  }));
  var AM = So(),
    LM = I,
    PM = V;

  function OM() {
    this._dragging = !1, this.animationThreshold = 15
  }

  function RM(t, e, n, i) {
    ! function t(e, n) {
      var i;
      return q(e) && q(n) ? (i = !0, N(n, (function(n, r) {
        i = i && t(e[r], n)
      })), !!i) : e === n
    }(AM(n).lastProp, i) && (AM(n).lastProp = i, e ? xh(n, i, t) : (n.stopAnimation(), n.attr(i)))
  }

  function NM(t, e) {
    t[e.get(["label", "show"]) ? "show" : "hide"]()
  }

  function EM(t) {
    return {
      x: t.x || 0,
      y: t.y || 0,
      rotation: t.rotation || 0
    }
  }

  function zM(t, e, n) {
    var i = e.get("z"),
      r = e.get("zlevel");
    t && t.traverse((function(t) {
      "group" !== t.type && (null != i && (t.z = i), null != r && (t.zlevel = r), t.silent = n)
    }))
  }

  function BM(t, e, n, i, r) {
    t = e.scale.parse(t);
    var o, a = e.scale.getLabel({
      value: t
    }, {
      precision: r.precision
    });
    return (r = r.formatter) && (o = {
      value: px(e, {
        value: t
      }),
      axisDimension: e.dim,
      axisIndex: e.index,
      seriesData: []
    }, N(i, (function(t) {
      var e = n.getSeriesByIndex(t.seriesIndex);
      t = t.dataIndexInside;
      (e = e && e.getDataParams(t)) && o.seriesData.push(e)
    })), U(r) ? a = r.replace("{value}", a) : G(r) && (a = r(o))), a
  }

  function FM(t, e, n) {
    var i = [1, 0, 0, 1, 0, 0];
    return _e(i, i, n.rotation), ve(i, i, n.position), Wh([t.dataToCoord(e), (n.labelOffset || 0) + (n.labelDirection || 1) * (n.labelMargin || 0)], i)
  }
  OM.prototype.render = function(t, e, n, i) {
    var r, o, a = e.get("value"),
      s = e.get("status");
    this._axisModel = t, this._axisPointerModel = e, this._api = n, !i && this._lastValue === a && this._lastStatus === s || (this._lastValue = a, this._lastStatus = s, i = this._group, r = this._handle, s && "hide" !== s ? (i && i.show(), r && r.show(), this.makeElOption(s = {}, a, t, e, n), (o = s.graphicKey) !== this._lastGraphicKey && this.clear(n), this._lastGraphicKey = o, o = this._moveAnimation = this.determineAnimation(t, e), i ? (o = H(RM, e, o), this.updatePointerEl(i, s, o), this.updateLabelEl(i, s, o, e)) : (i = this._group = new Rr, this.createPointerEl(i, s, t, e), this.createLabelEl(i, s, t, e), n.getZr().add(i)), zM(i, e, !0), this._renderHandle(a)) : (i && i.hide(), r && r.hide()))
  }, OM.prototype.remove = function(t) {
    this.clear(t)
  }, OM.prototype.dispose = function(t) {
    this.clear(t)
  }, OM.prototype.determineAnimation = function(t, e) {
    var n, i = e.get("animation"),
      r = t.axis,
      o = "category" === r.type;
    return !(!(e = e.get("snap")) && !o) && ("auto" === i || null == i ? (n = this.animationThreshold, o && r.getBandWidth() > n || !!e && (o = aM(t).seriesDataCount, e = r.getExtent(), Math.abs(e[0] - e[1]) / o > n)) : !0 === i)
  }, OM.prototype.makeElOption = function(t, e, n, i, r) {}, OM.prototype.createPointerEl = function(t, e, n, i) {
    var r = e.pointer;
    r && (r = AM(t).pointerEl = new Qh[r.type](LM(e.pointer)), t.add(r))
  }, OM.prototype.createLabelEl = function(t, e, n, i) {
    e.label && (e = AM(t).labelEl = new Ds(LM(e.label)), t.add(e), NM(e, i))
  }, OM.prototype.updatePointerEl = function(t, e, n) {
    (t = AM(t).pointerEl) && e.pointer && (t.setStyle(e.pointer.style), n(t, {
      shape: e.pointer.shape
    }))
  }, OM.prototype.updateLabelEl = function(t, e, n, i) {
    (t = AM(t).labelEl) && (t.setStyle(e.label.style), n(t, {
      x: e.label.x,
      y: e.label.y
    }), NM(t, i))
  }, OM.prototype._renderHandle = function(t) {
    var e, n, i, r, o, a;
    !this._dragging && this.updateHandleTransform && (e = this._axisPointerModel, n = this._api.getZr(), i = this._handle, r = e.getModel("handle"), a = e.get("status"), r.get("show") && a && "hide" !== a ? (this._handle || (o = !0, i = this._handle = qh(r.get("icon"), {
      cursor: "move",
      draggable: !0,
      onmousemove: function(t) {
        ue(t.event)
      },
      onmousedown: PM(this._onHandleDragMove, this, 0, 0),
      drift: PM(this._onHandleDragMove, this),
      ondragend: PM(this._onHandleDragEnd, this)
    }), n.add(i)), zM(i, e, !1), i.setStyle(r.getItemStyle(null, ["color", "borderColor", "borderWidth", "opacity", "shadowColor", "shadowBlur", "shadowOffsetX", "shadowOffsetY"])), W(a = r.get("size")) || (a = [a, a]), i.scaleX = a[0] / 2, i.scaleY = a[1] / 2, Ug(this, "_doDispatchAxisPointer", r.get("throttle") || 0, "fixRate"), this._moveHandleToValue(t, o)) : (i && n.remove(i), this._handle = null))
  }, OM.prototype._moveHandleToValue = function(t, e) {
    RM(this._axisPointerModel, !e && this._moveAnimation, this._handle, EM(this.getHandleTransform(t, this._axisModel, this._axisPointerModel)))
  }, OM.prototype._onHandleDragMove = function(t, e) {
    var n = this._handle;
    n && (this._dragging = !0, t = this.updateHandleTransform(EM(n), [t, e], this._axisModel, this._axisPointerModel), this._payloadInfo = t, n.stopAnimation(), n.attr(EM(t)), AM(n).lastProp = null, this._doDispatchAxisPointer())
  }, OM.prototype._doDispatchAxisPointer = function() {
    var t, e;
    this._handle && (t = this._payloadInfo, e = this._axisModel, this._api.dispatchAction({
      type: "updateAxisPointer",
      x: t.cursorPoint[0],
      y: t.cursorPoint[1],
      tooltipOption: t.tooltipOption,
      axesInfo: [{
        axisDim: e.axis.dim,
        axisIndex: e.componentIndex
      }]
    }))
  }, OM.prototype._onHandleDragEnd = function() {
    var t;
    this._dragging = !1, this._handle && (t = this._axisPointerModel.get("value"), this._moveHandleToValue(t), this._api.dispatchAction({
      type: "hideTip"
    }))
  }, OM.prototype.clear = function(t) {
    this._lastValue = null, this._lastStatus = null;
    t = t.getZr();
    var e = this._group,
      n = this._handle;
    t && e && (this._lastGraphicKey = null, e && t.remove(e), n && t.remove(n), this._group = null, this._handle = null, this._payloadInfo = null), Xg(this, "_doDispatchAxisPointer")
  }, OM.prototype.doClear = function() {}, OM.prototype.buildLabel = function(t, e, n) {
    return {
      x: t[n = n || 0],
      y: t[1 - n],
      width: e[n],
      height: e[1 - n]
    }
  }, i(WM, VM = OM), WM.prototype.makeElOption = function(t, e, n, i, r) {
    var o, a, s = n.axis,
      l = s.grid,
      u = i.get("type"),
      h = GM(l, s).getOtherAxis(s).getGlobalExtent(),
      c = s.toGlobalCoord(s.dataToCoord(e, !0)),
      p = (u && "none" !== u && (o = (a = i).get("type"), a = a.getModel(o + "Style"), "line" === o ? (p = a.getLineStyle()).fill = null : "shadow" === o && ((p = a.getAreaStyle()).stroke = null), o = p, (a = UM[u](s, c, h)).style = o, t.graphicKey = a.type, t.pointer = a), WS(l.model, n));
    u = e, s = t, c = p, h = n, o = i, a = r, l = QS.innerTextLayout(c.rotation, 0, c.labelDirection), c.labelMargin = o.get(["label", "margin"]),
      function(t, e, n, i, r) {
        var o, a = BM(n.get("value"), e.axis, e.ecModel, n.get("seriesDataIndices"), {
            precision: n.get(["label", "precision"]),
            formatter: n.get(["label", "formatter"])
          }),
          s = (n = n.getModel("label"), op(n.get("padding") || 0)),
          l = n.getFont(),
          u = yr(a, l),
          h = r.position,
          c = u.width + s[1] + s[3];
        u = u.height + s[0] + s[2], (i = ("bottom" === (o = ("right" === (o = r.align) && (h[0] -= c), "center" === o && (h[0] -= c / 2), r.verticalAlign)) && (h[1] -= u), "middle" === o && (h[1] -= u / 2), r = h, o = c, c = u, i = (u = i).getWidth(), u = u.getHeight(), r[0] = Math.min(r[0] + o, i) - o, r[1] = Math.min(r[1] + c, u) - c, r[0] = Math.max(r[0], 0), r[1] = Math.max(r[1], 0), n.get("backgroundColor"))) && "auto" !== i || (i = e.get(["axisLine", "lineStyle", "color"])), t.label = {
          x: h[0],
          y: h[1],
          style: rc(n, {
            text: a,
            font: l,
            fill: n.getTextColor(),
            padding: s,
            backgroundColor: i
          }),
          z2: 10
        }
      }(s, h, o, a, {
        position: FM(h.axis, u, c),
        align: l.textAlign,
        verticalAlign: l.textVerticalAlign
      })
  }, WM.prototype.getHandleTransform = function(t, e, n) {
    var i = WS(e.axis.grid.model, e, {
      labelInside: !1
    });
    return {
      x: (n = (i.labelMargin = n.get(["handle", "margin"]), FM(e.axis, t, i)))[0],
      y: n[1],
      rotation: i.rotation + (i.labelDirection < 0 ? Math.PI : 0)
    }
  }, WM.prototype.updateHandleTransform = function(t, e, n, i) {
    var r = (n = n.axis).grid,
      o = n.getGlobalExtent(!0),
      a = (r = GM(r, n).getOtherAxis(n).getGlobalExtent(), n = "x" === n.dim ? 0 : 1, [t.x, t.y]);
    return (o = [e = (a[n] += e[n], a[n] = Math.min(o[1], a[n]), a[n] = Math.max(o[0], a[n]), (r[1] + r[0]) / 2), e])[n] = a[n], {
      x: a[0],
      y: a[1],
      rotation: t.rotation,
      cursorPoint: o,
      tooltipOption: [{
        verticalAlign: "middle"
      }, {
        align: "center"
      }][n]
    }
  };
  var VM, HM = WM;

  function WM() {
    return null !== VM && VM.apply(this, arguments) || this
  }

  function GM(t, e) {
    var n = {};
    return n[e.dim + "AxisIndex"] = e.index, t.getCartesian(n)
  }
  var UM = {
    line: function(t, e, n) {
      var i;
      return i = [e, n[0]], e = [e, n[1]], {
        type: "Line",
        subPixelOptimize: !0,
        shape: {
          x1: i[n = (n = XM(t)) || 0],
          y1: i[1 - n],
          x2: e[n],
          y2: e[1 - n]
        }
      }
    },
    shadow: function(t, e, n) {
      var i = Math.max(1, t.getBandWidth()),
        r = n[1] - n[0];
      return {
        type: "Rect",
        shape: (e = [e - i / 2, n[0]], n = [i, r], i = XM(t), {
          x: e[i = i || 0],
          y: e[1 - i],
          width: n[i],
          height: n[1 - i]
        })
      }
    }
  };

  function XM(t) {
    return "x" === t.dim ? 0 : 1
  }
  i(jM, YM = Tp), jM.type = "axisPointer", jM.defaultOption = {
    show: "auto",
    z: 50,
    type: "line",
    snap: !1,
    triggerTooltip: !0,
    triggerEmphasis: !0,
    value: null,
    status: null,
    link: [],
    animation: null,
    animationDurationUpdate: 200,
    lineStyle: {
      color: "#B9BEC9",
      width: 1,
      type: "dashed"
    },
    shadowStyle: {
      color: "rgba(210,219,238,0.2)"
    },
    label: {
      show: !0,
      formatter: null,
      precision: "auto",
      margin: 3,
      color: "#fff",
      padding: [5, 7, 5, 7],
      backgroundColor: "auto",
      borderColor: null,
      borderWidth: 0,
      borderRadius: 3
    },
    handle: {
      show: !1,
      icon: "M10.7,11.9v-1.3H9.3v1.3c-4.9,0.3-8.8,4.4-8.8,9.4c0,5,3.9,9.1,8.8,9.4h1.3c4.9-0.3,8.8-4.4,8.8-9.4C19.5,16.3,15.6,12.2,10.7,11.9z M13.3,24.4H6.7v-1.2h6.6z M13.3,22H6.7v-1.2h6.6z M13.3,19.6H6.7v-1.2h6.6z",
      size: 45,
      margin: 50,
      color: "#333",
      shadowBlur: 3,
      shadowColor: "#aaa",
      shadowOffsetX: 0,
      shadowOffsetY: 2,
      throttle: 40
    }
  };
  var YM, qM = jM;

  function jM() {
    var t = null !== YM && YM.apply(this, arguments) || this;
    return t.type = jM.type, t
  }
  var ZM = So(),
    KM = N;

  function $M(t, e, n) {
    var i, r, a;

    function s(t, e) {
      r.on(t, (function(t) {
        n = a;
        var n, i, o = {
          dispatchAction: function t(e) {
            var r = i[e.type];
            r ? r.push(e) : (e.dispatchAction = t, n.dispatchAction(e))
          },
          pendings: i = {
            showTip: [],
            hideTip: []
          }
        };
        KM(ZM(r).records, (function(n) {
          n && e(n, t, o.dispatchAction)
        }));
        var s, l = o.pendings,
          u = a,
          h = l.showTip.length,
          c = l.hideTip.length;
        h ? s = l.showTip[h - 1] : c && (s = l.hideTip[c - 1]), s && (s.dispatchAction = null, u.dispatchAction(s))
      }))
    }
    o.node || (i = e.getZr(), ZM(i).records || (ZM(i).records = {}), a = e, ZM(r = i).initialized || (ZM(r).initialized = !0, s("click", H(JM, "click")), s("mousemove", H(JM, "mousemove")), s("globalout", QM)), (ZM(i).records[t] || (ZM(i).records[t] = {})).handler = n)
  }

  function QM(t, e, n) {
    t.handler("leave", null, n)
  }

  function JM(t, e, n, i) {
    e.handler(t, n, i)
  }

  function tT(t, e) {
    o.node || (e = e.getZr(), (ZM(e).records || {})[t] && (ZM(e).records[t] = null))
  }
  i(iT, eT = kg), iT.prototype.render = function(t, e, n) {
    e = e.getComponent("tooltip");
    var i = t.get("triggerOn") || e && e.get("triggerOn") || "mousemove|click";
    $M("axisPointer", n, (function(t, e, n) {
      "none" !== i && ("leave" === t || 0 <= i.indexOf(t)) && n({
        type: "updateAxisPointer",
        currTrigger: t,
        x: e && e.offsetX,
        y: e && e.offsetY
      })
    }))
  }, iT.prototype.remove = function(t, e) {
    tT("axisPointer", e)
  }, iT.prototype.dispose = function(t, e) {
    tT("axisPointer", e)
  }, iT.type = "axisPointer";
  var eT, nT = iT;

  function iT() {
    var t = null !== eT && eT.apply(this, arguments) || this;
    return t.type = iT.type, t
  }

  function rT(t, e) {
    var n, i, r, o, a = [],
      s = t.seriesIndex;
    return null == s || !(e = e.getSeriesByIndex(s)) || null == (s = bo(n = e.getData(), t)) || s < 0 || W(s) ? {
      point: []
    } : (i = n.getItemGraphicEl(s), r = e.coordinateSystem, e.getTooltipPosition ? a = e.getTooltipPosition(s) || [] : r && r.dataToPoint ? a = t.isStacked ? (e = r.getBaseAxis(), t = r.getOtherAxis(e).dim, e = e.dim, t = "x" === t || "radius" === t ? 1 : 0, e = n.mapDimension(e), (o = [])[t] = n.get(e, s), o[1 - t] = n.get(n.getCalculationInfo("stackResultDimension"), s), r.dataToPoint(o) || []) : r.dataToPoint(n.getValues(E(r.dimensions, (function(t) {
      return n.mapDimension(t)
    })), s)) || [] : i && ((e = i.getBoundingRect().clone()).applyTransform(i.transform), a = [e.x + e.width / 2, e.y + e.height / 2]), {
      point: a,
      el: i
    })
  }
  var oT = So();

  function aT(t, e, n) {
    var i, r, o, a, s, l, u, h, c, p, d, f, g, y, m = t.currTrigger,
      v = [t.x, t.y],
      _ = t,
      x = t.dispatchAction || V(n.dispatchAction, n),
      w = e.getComponent("axisPointer").coordSysAxesInfo;
    if (w) return cT(v) && (v = rT({
      seriesIndex: _.seriesIndex,
      dataIndex: _.dataIndex
    }, e).point), i = cT(v), r = _.axesInfo, o = w.axesInfo, a = "leave" === m || cT(v), s = {}, e = {
      list: [],
      map: {}
    }, u = {
      showPointer: H(lT, l = {}),
      showTooltip: H(uT, e)
    }, N(w.coordSysMap, (function(t, e) {
      var n = i || t.containPoint(v);
      N(w.coordSysAxesInfo[e], (function(t, e) {
        var o = t.axis,
          l = function(t, e) {
            for (var n = 0; n < (t || []).length; n++) {
              var i = t[n];
              if (e.axis.dim === i.axisDim && e.axis.model.componentIndex === i.axisIndex) return i
            }
          }(r, t);
        a || !n || r && !l || null != (l = null != (l = l && l.value) || i ? l : o.pointToData(v)) && sT(t, l, u, !1, s)
      }))
    })), h = {}, N(o, (function(t, e) {
      var n = t.linkGroup;
      n && !l[e] && N(n.axesInfo, (function(e, i) {
        i = l[i];
        e !== t && i && (i = i.value, n.mapper && (i = t.axis.scale.parse(n.mapper(i, hT(e), hT(t)))), h[t.key] = i)
      }))
    })), N(h, (function(t, e) {
      sT(o[e], t, u, !0, s)
    })), c = l, _ = o, p = s.axesInfo = [], N(_, (function(t, e) {
      var n = t.axisPointerModel.option;
      (e = c[e]) ? (t.useHandle || (n.status = "show"), n.value = e.value, n.seriesDataIndices = (e.payloadBatch || []).slice()) : t.useHandle || (n.status = "hide"), "show" === n.status && p.push({
        axisDim: t.axis.dim,
        axisIndex: t.axis.model.componentIndex,
        value: n.value
      })
    })), m = e, _ = t, e = x, cT(t = v) || !m.list.length ? e({
      type: "hideTip"
    }) : (x = ((m.list[0].dataByAxis[0] || {}).seriesDataIndices || [])[0] || {}, e({
      type: "showTip",
      escapeConnect: !0,
      x: t[0],
      y: t[1],
      tooltipOption: _.tooltipOption,
      position: _.position,
      dataIndexInside: x.dataIndexInside,
      dataIndex: x.dataIndex,
      seriesIndex: x.seriesIndex,
      dataByCoordSys: m.list
    })), e = o, _ = (t = n).getZr(), x = "axisPointerLastHighlights", d = oT(_)[x] || {}, f = oT(_)[x] = {}, N(e, (function(t, e) {
      var n = t.axisPointerModel.option;
      "show" === n.status && t.triggerEmphasis && N(n.seriesDataIndices, (function(t) {
        var e = t.seriesIndex + " | " + t.dataIndex;
        f[e] = t
      }))
    })), g = [], y = [], N(d, (function(t, e) {
      f[e] || y.push(t)
    })), N(f, (function(t, e) {
      d[e] || g.push(t)
    })), y.length && t.dispatchAction({
      type: "downplay",
      escapeConnect: !0,
      notBlur: !0,
      batch: y
    }), g.length && t.dispatchAction({
      type: "highlight",
      escapeConnect: !0,
      notBlur: !0,
      batch: g
    }), s
  }

  function sT(t, e, n, i, r) {
    var o, a, s, l, u, h, c, p, d, f, g = t.axis;
    !g.scale.isBlank() && g.containData(e) && (t.involveSeries ? (a = e, s = t.axis, l = s.dim, u = a, h = [], c = Number.MAX_VALUE, p = -1, N(t.seriesModels, (function(t, e) {
      var n, i = t.getData().mapDimensionsAll(l);
      if (t.getAxisTooltipData) var r = (o = t.getAxisTooltipData(i, a, s)).dataIndices,
        o = o.nestestValue;
      else {
        if (!(r = t.getData().indicesOfNearest(i[0], a, "category" === s.type ? .5 : null)).length) return;
        o = t.getData().get(i[0], r[0])
      }
      null != o && isFinite(o) && (i = a - o, (n = Math.abs(i)) <= c) && ((n < c || 0 <= i && p < 0) && (c = n, p = i, u = o, h.length = 0), N(r, (function(e) {
        h.push({
          seriesIndex: t.seriesIndex,
          dataIndexInside: e,
          dataIndex: t.getData().getRawIndex(e)
        })
      })))
    })), f = (o = {
      payloadBatch: h,
      snapToValue: u
    }).snapToValue, (d = o.payloadBatch)[0] && null == r.seriesIndex && k(r, d[0]), !i && t.snap && g.containData(f) && null != f && (e = f), n.showPointer(t, e, d), n.showTooltip(t, o, f)) : n.showPointer(t, e))
  }

  function lT(t, e, n, i) {
    t[e.key] = {
      value: n,
      payloadBatch: i
    }
  }

  function uT(t, e, n, i) {
    n = n.payloadBatch;
    var r, o, a = e.axis,
      s = a.model,
      l = e.axisPointerModel;
    e.triggerTooltip && n.length && (r = lM(e = e.coordSys.model), (o = t.map[r]) || (o = t.map[r] = {
      coordSysId: e.id,
      coordSysIndex: e.componentIndex,
      coordSysType: e.type,
      coordSysMainType: e.mainType,
      dataByAxis: []
    }, t.list.push(o)), o.dataByAxis.push({
      axisDim: a.dim,
      axisIndex: s.componentIndex,
      axisType: s.type,
      axisId: s.id,
      value: i,
      valueLabelOpt: {
        precision: l.get(["label", "precision"]),
        formatter: l.get(["label", "formatter"])
      },
      seriesDataIndices: n.slice()
    }))
  }

  function hT(t) {
    var e = t.axis.model,
      n = {};
    t = n.axisDim = t.axis.dim;
    return n.axisIndex = n[t + "AxisIndex"] = e.componentIndex, n.axisName = n[t + "AxisName"] = e.name, n.axisId = n[t + "AxisId"] = e.id, n
  }

  function cT(t) {
    return !t || null == t[0] || isNaN(t[0]) || null == t[1] || isNaN(t[1])
  }

  function pT(t) {
    cM.registerAxisPointerClass("CartesianAxisPointer", HM), t.registerComponentModel(qM), t.registerComponentView(nT), t.registerPreprocessor((function(t) {
      var e;
      t && (t.axisPointer && 0 !== t.axisPointer.length || (t.axisPointer = {}), e = t.axisPointer.link) && !W(e) && (t.axisPointer.link = [e])
    })), t.registerProcessor(t.PRIORITY.PROCESSOR.STATISTIC, (function(t, e) {
      t.getComponent("axisPointer").coordSysAxesInfo = function(t, e) {
        var n, i, r, o, a, s, l, u = {
          axesInfo: {},
          seriesInvolved: !1,
          coordSysAxesInfo: {},
          coordSysMap: {}
        };
        return n = u, e = e, r = (i = t).getComponent("tooltip"), o = i.getComponent("axisPointer"), a = o.get("link", !0) || [], s = [], N(e.getCoordinateSystems(), (function(t) {
          var e, l, u, h, c;

          function p(r, u, h) {
            var c, p, d = h.model.getModel("axisPointer", o),
              f = d.get("show");
            f && ("auto" !== f || r || sM(d)) && (null == u && (u = d.get("triggerTooltip")), f = (d = r ? function(t, e, n, i, r, o) {
              var a = e.getModel("axisPointer"),
                s = {};
              return N(["type", "snap", "lineStyle", "shadowStyle", "label", "animation", "animationDurationUpdate", "animationEasingUpdate", "z"], (function(t) {
                s[t] = I(a.get(t))
              })), s.snap = "category" !== t.type && !!o, "cross" === a.get("type") && (s.type = "line"), null == (e = s.label || (s.label = {})).show && (e.show = !1), "cross" === r && (r = a.get(["label", "show"]), e.show = null == r || r, o || (r = s.lineStyle = a.get("crossStyle")) && D(e, r.textStyle)), t.model.getModel("axisPointer", new Mc(s, n, i))
            }(h, l, o, i, r, u) : d).get("snap"), r = d.get("triggerEmphasis"), c = lM(h.model), p = u || f || "category" === h.type, u = n.axesInfo[c] = {
              key: c,
              axis: h,
              coordSys: t,
              axisPointerModel: d,
              triggerTooltip: u,
              triggerEmphasis: r,
              involveSeries: p,
              snap: f,
              useHandle: sM(d),
              seriesModels: [],
              linkGroup: null
            }, e[c] = u, n.seriesInvolved = n.seriesInvolved || p, null != (r = function(t, e) {
              for (var n = e.model, i = e.dim, r = 0; r < t.length; r++) {
                var o = t[r] || {};
                if (oM(o[i + "AxisId"], n.id) || oM(o[i + "AxisIndex"], n.componentIndex) || oM(o[i + "AxisName"], n.name)) return r
              }
            }(a, h))) && ((f = s[r] || (s[r] = {
              axesInfo: {}
            })).axesInfo[c] = u, f.mapper = a[r].mapper, u.linkGroup = f)
          }
          t.axisPointerEnabled && (u = lM(t.model), e = n.coordSysAxesInfo[u] = {}, l = (n.coordSysMap[u] = t).model.getModel("tooltip", r), N(t.getAxes(), H(p, !1, null)), t.getTooltipAxes) && r && l.get("show") && (u = "axis" === l.get("trigger"), h = "cross" === l.get(["axisPointer", "type"]), c = t.getTooltipAxes(l.get(["axisPointer", "axis"])), (u || h) && N(c.baseAxes, H(p, !h || "cross", u)), h) && N(c.otherAxes, H(p, "cross", !1))
        })), u.seriesInvolved && (l = u, t.eachSeries((function(t) {
          var e = t.coordinateSystem,
            n = t.get(["tooltip", "trigger"], !0),
            i = t.get(["tooltip", "show"], !0);
          e && "none" !== n && !1 !== n && "item" !== n && !1 !== i && !1 !== t.get(["axisPointer", "show"], !0) && N(l.coordSysAxesInfo[lM(e.model)], (function(n) {
            var i = n.axis;
            e.getAxis(i.dim) === i && (n.seriesModels.push(t), null == n.seriesDataCount && (n.seriesDataCount = 0), n.seriesDataCount += t.getData().count())
          }))
        }))), u
      }(t, e)
    })), t.registerAction({
      type: "updateAxisPointer",
      event: "updateAxisPointer",
      update: ":updateAxisPointer"
    }, aT)
  }
  i(gT, dT = Tp), gT.type = "tooltip", gT.dependencies = ["axisPointer"], gT.defaultOption = {
    z: 60,
    show: !0,
    showContent: !0,
    trigger: "item",
    triggerOn: "mousemove|click",
    alwaysShowContent: !1,
    displayMode: "single",
    renderMode: "auto",
    confine: null,
    showDelay: 0,
    hideDelay: 100,
    transitionDuration: .4,
    enterable: !1,
    backgroundColor: "#fff",
    shadowBlur: 10,
    shadowColor: "rgba(0, 0, 0, .2)",
    shadowOffsetX: 1,
    shadowOffsetY: 2,
    borderRadius: 4,
    borderWidth: 1,
    padding: null,
    extraCssText: "",
    axisPointer: {
      type: "line",
      axis: "auto",
      animation: "auto",
      animationDurationUpdate: 200,
      animationEasingUpdate: "exponentialOut",
      crossStyle: {
        color: "#999",
        width: 1,
        type: "dashed",
        textStyle: {}
      }
    },
    textStyle: {
      color: "#666",
      fontSize: 14
    }
  };
  var dT, fT = gT;

  function gT() {
    var t = null !== dT && dT.apply(this, arguments) || this;
    return t.type = gT.type, t
  }

  function yT(t) {
    var e = t.get("confine");
    return null != e ? e : "richText" === t.get("renderMode")
  }

  function mT(t) {
    if (o.domSupported)
      for (var e = document.documentElement.style, n = 0, i = t.length; n < i; n++)
        if (t[n] in e) return t[n]
  }
  var vT = mT(["transform", "webkitTransform", "OTransform", "MozTransform", "msTransform"]);

  function _T(t, e) {
    if (!t) return e;
    e = rp(e, !0);
    var n = t.indexOf(e);
    return (t = -1 === n ? e : "-" + t.slice(0, n) + "-" + e).toLowerCase()
  }
  var xT = _T(mT(["webkitTransition", "transition", "OTransition", "MozTransition", "msTransition"]), "transition"),
    wT = _T(vT, "transform"),
    bT = "position:absolute;display:block;border-style:solid;white-space:nowrap;z-index:9999999;" + (o.transform3dSupported ? "will-change:transform;" : "");

  function ST(t, e, n) {
    var i;
    t = t.toFixed(0) + "px", e = e.toFixed(0) + "px";
    return o.transformSupported ? (i = "translate" + ((i = o.transform3dSupported) ? "3d" : "") + "(" + t + "," + e + (i ? ",0" : "") + ")", n ? "top:0;left:0;" + wT + ":" + i + ";" : [
      ["top", 0],
      ["left", 0],
      [vT, i]
    ]) : n ? "top:" + e + ";left:" + t + ";" : [
      ["top", e],
      ["left", t]
    ]
  }

  function MT(t, e, n, i, r) {
    var o, a, s = e && e.painter;
    n ? (o = s && s.getViewportRoot()) && (a = t, n = n, $t(Kt, o, i, r, !0)) && $t(a, n, Kt[0], Kt[1]) : (t[0] = i, t[1] = r, (o = s && s.getViewportRootOffset()) && (t[0] += o.offsetLeft, t[1] += o.offsetTop)), t[2] = t[0] / e.getWidth(), t[3] = t[1] / e.getHeight()
  }
  IT.prototype.update = function(t) {
    this._container || (n = "position", n = (e = (e = i = this._api.getDom()).currentStyle || document.defaultView && document.defaultView.getComputedStyle(e)) ? n ? e[n] : e : null, "absolute" !== (e = i.style).position && "absolute" !== n && (e.position = "relative"));
    var e, n, i = t.get("alwaysShowContent");
    i && this._moveIfResized(), this._alwaysShowContent = i, this.el.className = t.get("className") || ""
  }, IT.prototype.show = function(t, e) {
    clearTimeout(this._hideTimeout), clearTimeout(this._longHideTimeout);
    var n = this.el,
      i = n.style,
      r = this._styleCoord;
    n.innerHTML ? i.cssText = bT + function(t, e, n) {
      var i, r, a = [],
        s = t.get("transitionDuration"),
        l = t.get("backgroundColor"),
        u = t.get("shadowBlur"),
        h = t.get("shadowColor"),
        c = t.get("shadowOffsetX"),
        p = t.get("shadowOffsetY"),
        d = t.getModel("textStyle"),
        f = dg(t, "html");
      return a.push("box-shadow:" + c + "px " + p + "px " + u + "px " + h), e && s && a.push((h = "opacity" + (u = " " + (c = s) / 2 + "s " + (p = "cubic-bezier(0.23,1,0.32,1)")) + ",visibility" + u, n || (u = " " + c + "s " + p, h += o.transformSupported ? "," + wT + u : ",left" + u + ",top" + u), xT + ":" + h)), l && a.push("background-color:" + l), N(["width", "color", "radius"], (function(e) {
        var n = "border-" + e,
          i = rp(n);
        null != (i = t.get(i)) && a.push(n + ":" + i + ("color" === e ? "" : "px"))
      })), a.push((r = [], e = (i = d).get("fontSize"), (s = i.getTextColor()) && r.push("color:" + s), r.push("font:" + i.getFont()), e && r.push("line-height:" + Math.round(3 * e / 2) + "px"), s = i.get("textShadowColor"), e = i.get("textShadowBlur") || 0, n = i.get("textShadowOffsetX") || 0, c = i.get("textShadowOffsetY") || 0, s && e && r.push("text-shadow:" + n + "px " + c + "px " + e + "px " + s), N(["decoration", "align"], (function(t) {
        var e = i.get(t);
        e && r.push("text-" + t + ":" + e)
      })), r.join(";"))), null != f && a.push("padding:" + op(f).join("px ") + "px"), a.join(";") + ";"
    }(t, !this._firstShow, this._longHide) + ST(r[0], r[1], !0) + "border-color:" + cp(e) + ";" + (t.get("extraCssText") || "") + ";pointer-events:" + (this._enterable ? "auto" : "none") : i.display = "none", this._show = !0, this._firstShow = !1, this._longHide = !1
  }, IT.prototype.setContent = function(t, e, n, i, r) {
    var o = this.el;
    if (null == t) o.innerHTML = "";
    else {
      var a, s, l, u, h, c = "";
      if (U(r) && "item" === n.get("trigger") && !yT(n) && (n = n, i = i, c = U(r = r) && "inside" !== r ? (a = n.get("backgroundColor"), n = n.get("borderWidth"), i = cp(i), r = r = "left" === (r = r) ? "right" : "right" === r ? "left" : "top" === r ? "bottom" : "top", p = Math.max(1.5 * Math.round(n), 6), s = "", l = wT + ":", -1 < L(["left", "right"], r) ? (s += "top:50%", l += "translateY(-50%) rotate(" + (h = "left" == r ? -225 : -45) + "deg)") : (s += "left:50%", l += "translateX(-50%) rotate(" + (h = "top" == r ? 225 : 45) + "deg)"), h = h * Math.PI / 180, h = (u = p + n) * Math.abs(Math.cos(h)) + u * Math.abs(Math.sin(h)), i = i + " solid " + n + "px;", '<div style="' + ["position:absolute;width:" + p + "px;height:" + p + "px;z-index:-1;", (s += ";" + r + ":-" + Math.round(100 * ((h - Math.SQRT2 * n) / 2 + Math.SQRT2 * n - (h - u) / 2)) / 100 + "px") + ";" + l + ";", "border-bottom:" + i, "border-right:" + i, "background-color:" + a + ";"].join("") + '"></div>') : ""), U(t)) o.innerHTML = t + c;
      else if (t) {
        o.innerHTML = "", W(t) || (t = [t]);
        for (var p, d = 0; d < t.length; d++) K(t[d]) && t[d].parentNode !== o && o.appendChild(t[d]);
        c && o.childNodes.length && ((p = document.createElement("div")).innerHTML = c, o.appendChild(p))
      }
    }
  }, IT.prototype.setEnterable = function(t) {
    this._enterable = t
  }, IT.prototype.getSize = function() {
    var t = this.el;
    return [t.offsetWidth, t.offsetHeight]
  }, IT.prototype.moveTo = function(t, e) {
    var n, i = this._styleCoord;
    MT(i, this._zr, this._container, t, e), null != i[0] && null != i[1] && (n = this.el.style, N(ST(i[0], i[1]), (function(t) {
      n[t[0]] = t[1]
    })))
  }, IT.prototype._moveIfResized = function() {
    var t = this._styleCoord[2],
      e = this._styleCoord[3];
    this.moveTo(t * this._zr.getWidth(), e * this._zr.getHeight())
  }, IT.prototype.hide = function() {
    var t = this,
      e = this.el.style;
    e.visibility = "hidden", e.opacity = "0", o.transform3dSupported && (e.willChange = ""), this._show = !1, this._longHideTimeout = setTimeout((function() {
      return t._longHide = !0
    }), 500)
  }, IT.prototype.hideLater = function(t) {
    !this._show || this._inContent && this._enterable || this._alwaysShowContent || (t ? (this._hideDelay = t, this._show = !1, this._hideTimeout = setTimeout(V(this.hide, this), t)) : this.hide())
  }, IT.prototype.isShow = function() {
    return this._show
  }, IT.prototype.dispose = function() {
    clearTimeout(this._hideTimeout), clearTimeout(this._longHideTimeout);
    var t = this.el.parentNode;
    t && t.removeChild(this.el), this.el = this._container = null
  };
  var TT = IT;

  function IT(t, e) {
    if (this._show = !1, this._styleCoord = [0, 0, 0, 0], this._enterable = !0, this._alwaysShowContent = !1, this._firstShow = !0, this._longHide = !0, o.wxa) return null;
    var n = document.createElement("div"),
      i = (n.domBelongToZr = !0, this.el = n, this._zr = t.getZr()),
      r = (e = (e = e.appendTo) && (U(e) ? document.querySelector(e) : K(e) ? e : G(e) && e(t.getDom())), MT(this._styleCoord, i, e, t.getWidth() / 2, t.getHeight() / 2), (e || t.getDom()).appendChild(n), this._api = t, this._container = e, this);
    n.onmouseenter = function() {
      r._enterable && (clearTimeout(r._hideTimeout), r._show = !0), r._inContent = !0
    }, n.onmousemove = function(t) {
      var e;
      t = t || window.event, r._enterable || (e = i.handler, le(i.painter.getViewportRoot(), t, !0), e.dispatch("mousemove", t))
    }, n.onmouseleave = function() {
      r._inContent = !1, r._enterable && r._show && r.hideLater(r._hideDelay)
    }
  }
  kT.prototype.update = function(t) {
    (t = t.get("alwaysShowContent")) && this._moveIfResized(), this._alwaysShowContent = t
  }, kT.prototype.show = function() {
    this._hideTimeout && clearTimeout(this._hideTimeout), this.el.show(), this._show = !0
  }, kT.prototype.setContent = function(t, e, n, i, r) {
    var o = this,
      a = (q(t) && uo(""), this.el && this._zr.remove(this.el), n.getModel("textStyle")),
      s = (this.el = new Ds({
        style: {
          rich: e.richTextStyles,
          text: t,
          lineHeight: 22,
          borderWidth: 1,
          borderColor: i,
          textShadowColor: a.get("textShadowColor"),
          fill: n.get(["textStyle", "color"]),
          padding: dg(n, "richText"),
          verticalAlign: "top",
          align: "left"
        },
        z: n.get("z")
      }), N(["backgroundColor", "borderRadius", "shadowColor", "shadowBlur", "shadowOffsetX", "shadowOffsetY"], (function(t) {
        o.el.style[t] = n.get(t)
      })), N(["textShadowBlur", "textShadowOffsetX", "textShadowOffsetY"], (function(t) {
        o.el.style[t] = a.get(t) || 0
      })), this._zr.add(this.el), this);
    this.el.on("mouseover", (function() {
      s._enterable && (clearTimeout(s._hideTimeout), s._show = !0), s._inContent = !0
    })), this.el.on("mouseout", (function() {
      s._enterable && s._show && s.hideLater(s._hideDelay), s._inContent = !1
    }))
  }, kT.prototype.setEnterable = function(t) {
    this._enterable = t
  }, kT.prototype.getSize = function() {
    var t = this.el,
      e = this.el.getBoundingRect();
    t = AT(t.style);
    return [e.width + t.left + t.right, e.height + t.top + t.bottom]
  }, kT.prototype.moveTo = function(t, e) {
    var n, i, r = this.el;
    r && (LT(i = this._styleCoord, this._zr, t, e), t = i[0], e = i[1], n = DT((i = r.style).borderWidth || 0), i = AT(i), r.x = t + n + i.left, r.y = e + n + i.top, r.markRedraw())
  }, kT.prototype._moveIfResized = function() {
    var t = this._styleCoord[2],
      e = this._styleCoord[3];
    this.moveTo(t * this._zr.getWidth(), e * this._zr.getHeight())
  }, kT.prototype.hide = function() {
    this.el && this.el.hide(), this._show = !1
  }, kT.prototype.hideLater = function(t) {
    !this._show || this._inContent && this._enterable || this._alwaysShowContent || (t ? (this._hideDelay = t, this._show = !1, this._hideTimeout = setTimeout(V(this.hide, this), t)) : this.hide())
  }, kT.prototype.isShow = function() {
    return this._show
  }, kT.prototype.dispose = function() {
    this._zr.remove(this.el)
  };
  var CT = kT;

  function kT(t) {
    this._show = !1, this._styleCoord = [0, 0, 0, 0], this._alwaysShowContent = !1, this._enterable = !0, this._zr = t.getZr(), LT(this._styleCoord, this._zr, t.getWidth() / 2, t.getHeight() / 2)
  }

  function DT(t) {
    return Math.max(0, t)
  }

  function AT(t) {
    var e = DT(t.shadowBlur || 0),
      n = DT(t.shadowOffsetX || 0);
    t = DT(t.shadowOffsetY || 0);
    return {
      left: DT(e - n),
      right: DT(e + n),
      top: DT(e - t),
      bottom: DT(e + t)
    }
  }

  function LT(t, e, n, i) {
    t[0] = n, t[1] = i, t[2] = t[0] / e.getWidth(), t[3] = t[1] / e.getHeight()
  }
  var PT, OT = new Ms({
      shape: {
        x: -1,
        y: -1,
        width: 2,
        height: 2
      }
    }),
    RT = (i(NT, PT = kg), NT.prototype.init = function(t, e) {
      var n;
      !o.node && e.getDom() && (t = t.getComponent("tooltip"), n = this._renderMode = "auto" === (n = t.get("renderMode")) ? o.domSupported ? "html" : "richText" : n || "html", this._tooltipContent = "richText" === n ? new CT(e) : new TT(e, {
        appendTo: t.get("appendToBody", !0) ? "body" : t.get("appendTo", !0)
      }))
    }, NT.prototype.render = function(t, e, n) {
      !o.node && n.getDom() && (this.group.removeAll(), this._tooltipModel = t, this._ecModel = e, this._api = n, (e = this._tooltipContent).update(t), e.setEnterable(t.get("enterable")), this._initGlobalListener(), this._keepShow(), "richText" !== this._renderMode && t.get("transitionDuration") ? Ug(this, "_updatePosition", 50, "fixRate") : Xg(this, "_updatePosition"))
    }, NT.prototype._initGlobalListener = function() {
      var t = this._tooltipModel.get("triggerOn");
      $M("itemTooltip", this._api, V((function(e, n, i) {
        "none" !== t && (0 <= t.indexOf(e) ? this._tryShow(n, i) : "leave" === e && this._hide(i))
      }), this))
    }, NT.prototype._keepShow = function() {
      var t, e = this._tooltipModel,
        n = this._ecModel,
        i = this._api,
        r = e.get("triggerOn");
      null != this._lastX && null != this._lastY && "none" !== r && "click" !== r && (t = this, clearTimeout(this._refreshUpdateTimeout), this._refreshUpdateTimeout = setTimeout((function() {
        i.isDisposed() || t.manuallyShowTip(e, n, i, {
          x: t._lastX,
          y: t._lastY,
          dataByCoordSys: t._lastDataByCoordSys
        })
      })))
    }, NT.prototype.manuallyShowTip = function(t, e, n, i) {
      var r, a, s, l;
      i.from !== this.uid && !o.node && n.getDom() && (r = zT(i, n), this._ticket = "", l = i.dataByCoordSys, (a = function(t, e, n) {
        var i, r = Io(t).queryOptionMap,
          o = r.keys()[0];
        if (o && "series" !== o && ((e = ko(e, o, r.get(o), {
            useDefault: !1,
            enableAll: !1,
            enableNone: !1
          }).models[0]) && (n.getViewOfComponentModel(e).group.traverse((function(e) {
            var n = Us(e).tooltipConfig;
            if (n && n.name === t.name) return i = e, !0
          })), i))) return {
          componentMainType: o,
          componentIndex: e.componentIndex,
          el: i
        }
      }(i, e, n)) ? ((s = a.el.getBoundingRect().clone()).applyTransform(a.el.transform), this._tryShow({
        offsetX: s.x + s.width / 2,
        offsetY: s.y + s.height / 2,
        target: a.el,
        position: i.position,
        positionDefault: "bottom"
      }, r)) : i.tooltip && null != i.x && null != i.y ? ((s = OT).x = i.x, s.y = i.y, s.update(), Us(s).tooltipConfig = {
        name: null,
        option: i.tooltip
      }, this._tryShow({
        offsetX: i.x,
        offsetY: i.y,
        target: s
      }, r)) : l ? this._tryShow({
        offsetX: i.x,
        offsetY: i.y,
        position: i.position,
        dataByCoordSys: l,
        tooltipOption: i.tooltipOption
      }, r) : null != i.seriesIndex ? this._manuallyAxisShowTip(t, e, n, i) || (s = (a = rT(i, e)).point[0], l = a.point[1], null != s && null != l && this._tryShow({
        offsetX: s,
        offsetY: l,
        target: a.el,
        position: i.position,
        positionDefault: "bottom"
      }, r)) : null != i.x && null != i.y && (n.dispatchAction({
        type: "updateAxisPointer",
        x: i.x,
        y: i.y
      }), this._tryShow({
        offsetX: i.x,
        offsetY: i.y,
        position: i.position,
        target: n.getZr().findHover(i.x, i.y).target
      }, r)))
    }, NT.prototype.manuallyHideTip = function(t, e, n, i) {
      var r = this._tooltipContent;
      this._tooltipModel && r.hideLater(this._tooltipModel.get("hideDelay")), this._lastX = this._lastY = this._lastDataByCoordSys = null, i.from !== this.uid && this._hide(zT(i, n))
    }, NT.prototype._manuallyAxisShowTip = function(t, e, n, i) {
      var r = i.seriesIndex,
        o = i.dataIndex,
        a = e.getComponent("axisPointer").coordSysAxesInfo;
      if (null != r && null != o && null != a && (a = e.getSeriesByIndex(r)) && "axis" === (e = ET([a.getData().getItemModel(o), a, (a.coordinateSystem || {}).model], this._tooltipModel)).get("trigger")) return n.dispatchAction({
        type: "updateAxisPointer",
        seriesIndex: r,
        dataIndex: o,
        position: i.position
      }), !0
    }, NT.prototype._tryShow = function(t, e) {
      var n, i, r, o = t.target;
      this._tooltipModel && (this._lastX = t.offsetX, this._lastY = t.offsetY, (n = t.dataByCoordSys) && n.length ? this._showAxisTooltip(n, t) : o ? "legend" !== Us(o).ssrType && (Ty(o, (function(t) {
        return null != Us(t).dataIndex ? (i = t, 1) : null != Us(t).tooltipConfig && (r = t, 1)
      }), !(this._lastDataByCoordSys = null)), i ? this._showSeriesItemTooltip(t, i, e) : r ? this._showComponentItemTooltip(t, r, e) : this._hide(e)) : (this._lastDataByCoordSys = null, this._hide(e)))
    }, NT.prototype._showOrMove = function(t, e) {
      t = t.get("showDelay"), e = V(e, this), clearTimeout(this._showTimout), 0 < t ? this._showTimout = setTimeout(e, t) : e()
    }, NT.prototype._showAxisTooltip = function(t, e) {
      var n = this._ecModel,
        i = this._tooltipModel,
        r = [e.offsetX, e.offsetY],
        o = ET([e.tooltipOption], i),
        a = this._renderMode,
        s = [],
        l = og("section", {
          blocks: [],
          noHeader: !0
        }),
        u = [],
        h = new fg,
        c = (N(t, (function(t) {
          N(t.dataByAxis, (function(t) {
            var e, r, o = n.getComponent(t.axisDim + "Axis", t.axisIndex),
              c = t.value;
            o && null != c && (e = BM(c, o.axis, n, t.seriesDataIndices, t.valueLabelOpt), r = og("section", {
              header: e,
              noHeader: !st(e),
              sortBlocks: !0,
              blocks: []
            }), l.blocks.push(r), N(t.seriesDataIndices, (function(l) {
              var p, d = n.getSeriesByIndex(l.seriesIndex),
                f = (l = l.dataIndexInside, d.getDataParams(l));
              f.dataIndex < 0 || (f.axisDim = t.axisDim, f.axisIndex = t.axisIndex, f.axisType = t.axisType, f.axisId = t.axisId, f.axisValue = px(o.axis, {
                value: c
              }), f.axisValueLabel = e, f.marker = h.makeTooltipMarker("item", cp(f.color), a), (p = (l = uf(d.formatTooltip(l, !0, null))).frag) && (d = ET([d], i).get("valueFormatter"), r.blocks.push(d ? k({
                valueFormatter: d
              }, p) : p)), l.text && u.push(l.text), s.push(f))
            })))
          }))
        })), l.blocks.reverse(), u.reverse(), e.position),
        p = (e = o.get("order"), e = ((e = hg(l, h, a, e, n.get("useUTC"), o.get("textStyle"))) && u.unshift(e), "richText" === a ? "\n\n" : "<br/>"), u.join(e));
      this._showOrMove(o, (function() {
        this._updateContentNotChangedOnAxis(t, s) ? this._updatePosition(o, c, r[0], r[1], this._tooltipContent, s) : this._showTooltipContent(o, p, s, Math.random() + "", r[0], r[1], c, null, h)
      }))
    }, NT.prototype._showSeriesItemTooltip = function(t, e, n) {
      var i, r, o, a, s, l = this._ecModel,
        u = (e = Us(e)).seriesIndex,
        h = l.getSeriesByIndex(u),
        c = e.dataModel || h,
        p = e.dataIndex,
        d = (e = e.dataType, c.getData(e)),
        f = this._renderMode,
        g = t.positionDefault,
        y = ET([d.getItemModel(p), c, h && (h.coordinateSystem || {}).model], this._tooltipModel, g ? {
          position: g
        } : null);
      null != (h = y.get("trigger")) && "item" !== h || (i = c.getDataParams(p, e), r = new fg, i.marker = r.makeTooltipMarker("item", cp(i.color), f), g = uf(c.formatTooltip(p, !1, e)), h = y.get("order"), e = y.get("valueFormatter"), o = g.frag, a = o ? hg(e ? k({
        valueFormatter: e
      }, o) : o, r, f, h, l.get("useUTC"), y.get("textStyle")) : g.text, s = "item_" + c.name + "_" + p, this._showOrMove(y, (function() {
        this._showTooltipContent(y, a, i, s, t.offsetX, t.offsetY, t.position, t.target, r)
      })), n({
        type: "showTip",
        dataIndexInside: p,
        dataIndex: d.getRawIndex(p),
        seriesIndex: u,
        from: this.uid
      }))
    }, NT.prototype._showComponentItemTooltip = function(t, e, n) {
      var i = "html" === this._renderMode,
        r = (a = Us(e)).tooltipConfig.option || {},
        o = r.encodeHTMLContent,
        a = (o = (U(r) && (r = {
          content: r,
          formatter: r
        }, o = !0), o && i && r.content && ((r = I(r)).content = ee(r.content)), [r]), (i = this._ecModel.getComponent(a.componentMainType, a.componentIndex)) && o.push(i), o.push({
          formatter: r.content
        }), t.positionDefault),
        s = ET(o, this._tooltipModel, a ? {
          position: a
        } : null),
        l = s.get("content"),
        u = Math.random() + "",
        h = new fg;
      this._showOrMove(s, (function() {
        var n = I(s.get("formatterParams") || {});
        this._showTooltipContent(s, l, n, u, t.offsetX, t.offsetY, t.position, e, h)
      })), n({
        type: "showTip",
        from: this.uid
      })
    }, NT.prototype._showTooltipContent = function(t, e, n, i, r, o, a, s, l) {
      var u, h, c, p, d;
      this._ticket = "", t.get("showContent") && t.get("show") && ((u = this._tooltipContent).setEnterable(t.get("enterable")), h = t.get("formatter"), a = a || t.get("position"), e = e, c = this._getNearestPoint([r, o], n, t.get("trigger"), t.get("borderColor")).color, h && (e = U(h) ? (p = t.ecModel.get("useUTC"), e = h, up(e = (d = W(n) ? n[0] : n) && d.axisType && 0 <= d.axisType.indexOf("time") ? Hc(d.axisValue, e, p) : e, n, !0)) : G(h) ? (d = V((function(e, i) {
        e === this._ticket && (u.setContent(i, l, t, c, a), this._updatePosition(t, a, r, o, u, n, s))
      }), this), this._ticket = i, h(n, i, d)) : h), u.setContent(e, l, t, c, a), u.show(t, c), this._updatePosition(t, a, r, o, u, n, s))
    }, NT.prototype._getNearestPoint = function(t, e, n, i) {
      return "axis" === n || W(e) ? {
        color: i || ("html" === this._renderMode ? "#fff" : "none")
      } : W(e) ? void 0 : {
        color: i || e.color || e.borderColor
      }
    }, NT.prototype._updatePosition = function(t, e, n, i, r, o, a) {
      var s, l = this._api.getWidth(),
        u = this._api.getHeight(),
        h = (e = e || t.get("position"), r.getSize()),
        c = t.get("align"),
        p = t.get("verticalAlign"),
        d = a && a.getBoundingRect().clone();
      a && d.applyTransform(a.transform), W(e = G(e) ? e([n, i], o, r.el, d, {
        viewSize: [l, u],
        contentSize: h.slice()
      }) : e) ? (n = qr(e[0], l), i = qr(e[1], u)) : q(e) ? ((o = e).width = h[0], o.height = h[1], n = (o = yp(o, {
        width: l,
        height: u
      })).x, i = o.y, p = c = null) : (n = (s = U(e) && a ? function(t, e, n, i) {
        var r = n[0],
          o = n[1],
          a = Math.ceil(Math.SQRT2 * i) + 8,
          s = 0,
          l = 0,
          u = e.width,
          h = e.height;
        switch (t) {
          case "inside":
            s = e.x + u / 2 - r / 2, l = e.y + h / 2 - o / 2;
            break;
          case "top":
            s = e.x + u / 2 - r / 2, l = e.y - o - a;
            break;
          case "bottom":
            s = e.x + u / 2 - r / 2, l = e.y + h + a;
            break;
          case "left":
            s = e.x - r - a, l = e.y + h / 2 - o / 2;
            break;
          case "right":
            s = e.x + u + a, l = e.y + h / 2 - o / 2
        }
        return [s, l]
      }(e, d, h, t.get("borderWidth")) : function(t, e, n, i, r, o, a) {
        var s = (n = n.getSize())[0];
        n = n[1];
        return null != o && (i < t + s + o + 2 ? t -= s + o : t += o), null != a && (r < e + n + a ? e -= n + a : e += a), [t, e]
      }(n, i, r, l, u, c ? null : 20, p ? null : 20))[0], i = s[1]), c && (n -= BT(c) ? h[0] / 2 : "right" === c ? h[0] : 0), p && (i -= BT(p) ? h[1] / 2 : "bottom" === p ? h[1] : 0), yT(t) && (o = n, a = i, e = l, d = u, p = (c = (c = r).getSize())[0], c = c[1], o = Math.min(o + p, e) - p, a = Math.min(a + c, d) - c, n = (s = [o = Math.max(o, 0), a = Math.max(a, 0)])[0], i = s[1]), r.moveTo(n, i)
    }, NT.prototype._updateContentNotChangedOnAxis = function(t, e) {
      var n = this._lastDataByCoordSys,
        i = this._cbParamsList,
        r = !!n && n.length === t.length;
      return r && N(n, (function(n, o) {
        n = n.dataByAxis || [];
        var a = (t[o] || {}).dataByAxis || [];
        (r = r && n.length === a.length) && N(n, (function(t, n) {
          n = a[n] || {};
          var o = t.seriesDataIndices || [],
            s = n.seriesDataIndices || [];
          (r = r && t.value === n.value && t.axisType === n.axisType && t.axisId === n.axisId && o.length === s.length) && N(o, (function(t, e) {
            e = s[e], r = r && t.seriesIndex === e.seriesIndex && t.dataIndex === e.dataIndex
          })), i && N(t.seriesDataIndices, (function(t) {
            t = t.seriesIndex;
            var n = e[t];
            t = i[t];
            n && t && t.data !== n.data && (r = !1)
          }))
        }))
      })), this._lastDataByCoordSys = t, this._cbParamsList = e, !!r
    }, NT.prototype._hide = function(t) {
      this._lastDataByCoordSys = null, t({
        type: "hideTip",
        from: this.uid
      })
    }, NT.prototype.dispose = function(t, e) {
      !o.node && e.getDom() && (Xg(this, "_updatePosition"), this._tooltipContent.dispose(), tT("itemTooltip", e))
    }, NT.type = "tooltip", NT);

  function NT() {
    var t = null !== PT && PT.apply(this, arguments) || this;
    return t.type = NT.type, t
  }

  function ET(t, e, n) {
    for (var i = e.ecModel, r = n ? (r = new Mc(n, i, i), new Mc(e.option, r, i)) : e, o = t.length - 1; 0 <= o; o--) {
      var a = t[o];
      (a = a && (U(a = a instanceof Mc ? a.get("tooltip", !0) : a) ? {
        formatter: a
      } : a)) && (r = new Mc(a, r, i))
    }
    return r
  }

  function zT(t, e) {
    return t.dispatchAction || V(e.dispatchAction, e)
  }

  function BT(t) {
    return "center" === t || "middle" === t
  }

  function FT(t) {
    fo(t, "label", ["show"])
  }
  _x((function(t) {
    _x(pT), t.registerComponentModel(fT), t.registerComponentView(RT), t.registerAction({
      type: "showTip",
      event: "showTip",
      update: "tooltip:manuallyShowTip"
    }, wt), t.registerAction({
      type: "hideTip",
      event: "hideTip",
      update: "tooltip:manuallyHideTip"
    }, wt)
  }));
  var VT, HT = So(),
    WT = (i(GT, VT = Tp), GT.prototype.init = function(t, e, n) {
      this.mergeDefaultAndTheme(t, n), this._mergeOption(t, n, !1, !0)
    }, GT.prototype.isAnimationEnabled = function() {
      var t;
      return !o.node && (t = this.__hostSeries, this.getShallow("animation")) && t && t.isAnimationEnabled()
    }, GT.prototype.mergeOption = function(t, e) {
      this._mergeOption(t, e, !1, !1)
    }, GT.prototype._mergeOption = function(t, e, n, i) {
      var r = this.mainType;
      n || e.eachSeries((function(t) {
        var n = t.get(this.mainType, !0),
          o = HT(t)[r];
        n && n.data ? (o ? o._mergeOption(n, e, !0) : (i && FT(n), N(n.data, (function(t) {
          t instanceof Array ? (FT(t[0]), FT(t[1])) : FT(t)
        })), k(o = this.createMarkerModelFromSeries(n, this, e), {
          mainType: this.mainType,
          seriesIndex: t.seriesIndex,
          name: t.name,
          createdBySelf: !0
        }), o.__hostSeries = t), HT(t)[r] = o) : HT(t)[r] = null
      }), this)
    }, GT.prototype.formatTooltip = function(t, e, n) {
      var i = this.getData(),
        r = this.getRawValue(t);
      i = i.getName(t);
      return og("section", {
        header: this.name,
        blocks: [og("nameValue", {
          name: i,
          value: r,
          noName: !i,
          noValue: null == r
        })]
      })
    }, GT.prototype.getData = function() {
      return this._data
    }, GT.prototype.setData = function(t) {
      this._data = t
    }, GT.prototype.getDataParams = function(t, e) {
      return t = sf.prototype.getDataParams.call(this, t, e), (e = this.__hostSeries) && (t.seriesId = e.id, t.seriesName = e.name, t.seriesType = e.subType), t
    }, GT.getMarkerModelFromSeries = function(t, e) {
      return HT(t)[e]
    }, GT.type = "marker", GT.dependencies = ["series", "grid", "polar", "geo"], GT);

  function GT() {
    var t = null !== VT && VT.apply(this, arguments) || this;
    return t.type = GT.type, t.createdBySelf = !1, t
  }
  O(WT, sf.prototype), i(YT, UT = WT), YT.prototype.createMarkerModelFromSeries = function(t, e, n) {
    return new YT(t, e, n)
  }, YT.type = "markLine", YT.defaultOption = {
    z: 5,
    symbol: ["circle", "arrow"],
    symbolSize: [8, 16],
    symbolOffset: 0,
    precision: 2,
    tooltip: {
      trigger: "item"
    },
    label: {
      show: !0,
      position: "end",
      distance: 5
    },
    lineStyle: {
      type: "dashed"
    },
    emphasis: {
      label: {
        show: !0
      },
      lineStyle: {
        width: 3
      }
    },
    animationEasing: "linear"
  };
  var UT, XT = YT;

  function YT() {
    var t = null !== UT && UT.apply(this, arguments) || this;
    return t.type = YT.type, t
  }

  function qT(t, e, n, i, r, o) {
    var a = [],
      s = l_(e, i) ? e.getCalculationInfo("stackResultDimension") : i;
    t = QT(e, s, t), t = e.indicesOfNearest(s, t)[0], a[r] = e.get(n, t), a[o] = e.get(s, t), r = e.get(i, t), n = Zr(e.get(i, t));
    return 0 <= (n = Math.min(n, 20)) && (a[o] = +a[o].toFixed(n)), [a, r]
  }
  var jT = {
    min: H(qT, "min"),
    max: H(qT, "max"),
    average: H(qT, "average"),
    median: H(qT, "median")
  };

  function ZT(t, e) {
    if (e) {
      var n, i = t.getData(),
        r = t.coordinateSystem,
        o = r && r.dimensions;
      if (n = e, (isNaN(parseFloat(n.x)) || isNaN(parseFloat(n.y))) && !W(e.coord) && W(o) && (n = KT(e, i, r, t), (e = I(e)).type && jT[e.type] && n.baseAxis && n.valueAxis ? (r = L(o, n.baseAxis.dim), t = L(o, n.valueAxis.dim), n = jT[e.type](i, n.baseDataDim, n.valueDataDim, r, t), e.coord = n[0], e.value = n[1]) : e.coord = [null != e.xAxis ? e.xAxis : e.radiusAxis, null != e.yAxis ? e.yAxis : e.angleAxis]), null != e.coord && W(o))
        for (var a = e.coord, s = 0; s < 2; s++) jT[a[s]] && (a[s] = QT(i, i.mapDimension(o[s]), a[s]));
      else e.coord = [];
      return e
    }
  }

  function KT(t, e, n, i) {
    var r = {};
    return null != t.valueIndex || null != t.valueDim ? (r.valueDataDim = null != t.valueIndex ? e.getDimension(t.valueIndex) : t.valueDim, r.valueAxis = n.getAxis(function(t, e) {
      return (t = t.getData().getDimensionInfo(e)) && t.coordDim
    }(i, r.valueDataDim)), r.baseAxis = n.getOtherAxis(r.valueAxis), r.baseDataDim = e.mapDimension(r.baseAxis.dim)) : (r.baseAxis = i.getBaseAxis(), r.valueAxis = n.getOtherAxis(r.baseAxis), r.baseDataDim = e.mapDimension(r.baseAxis.dim), r.valueDataDim = e.mapDimension(r.valueAxis.dim)), r
  }

  function $T(t, e) {
    return !(t && t.containData && e.coord && (n = e, isNaN(parseFloat(n.x))) && isNaN(parseFloat(n.y))) || t.containData(e.coord);
    var n
  }

  function QT(t, e, n) {
    var i, r;
    return "average" === n ? (r = i = 0, t.each(e, (function(t, e) {
      isNaN(t) || (i += t, r++)
    })), i / r) : "median" === n ? t.getMedian(e) : t.getDataExtent(e)["max" === n ? 1 : 0]
  }
  var JT, tI = Hu.prototype,
    eI = qu.prototype,
    nI = function() {
      this.x1 = 0, this.y1 = 0, this.x2 = 0, this.y2 = 0, this.percent = 1
    };

  function iI(t) {
    return isNaN(+t.cpx1) || isNaN(+t.cpy1)
  }
  i((function() {
    return null !== JT && JT.apply(this, arguments) || this
  }), JT = nI), i(aI, rI = as), aI.prototype.getDefaultStyle = function() {
    return {
      stroke: "#000",
      fill: null
    }
  }, aI.prototype.getDefaultShape = function() {
    return new nI
  }, aI.prototype.buildPath = function(t, e) {
    (iI(e) ? tI : eI).buildPath.call(this, t, e)
  }, aI.prototype.pointAt = function(t) {
    return (iI(this.shape) ? tI : eI).pointAt.call(this, t)
  }, aI.prototype.tangentAt = function(t) {
    var e;
    return Lt(e = iI(e = this.shape) ? [e.x2 - e.x1, e.y2 - e.y1] : eI.tangentAt.call(this, t), e)
  };
  var rI, oI = aI;

  function aI(t) {
    return (t = rI.call(this, t) || this).type = "ec-line", t
  }
  var sI = ["fromSymbol", "toSymbol"];

  function lI(t) {
    return "_" + t + "Type"
  }

  function uI(t, e, n) {
    var i, r, o, a = e.getItemVisual(n, t);
    return a && "none" !== a ? (i = e.getItemVisual(n, t + "Size"), r = e.getItemVisual(n, t + "Rotate"), o = e.getItemVisual(n, t + "Offset"), e = e.getItemVisual(n, t + "KeepAspect"), a + (n = Fy(i)) + Vy(o || 0, n) + (r || "") + (e || "")) : a
  }

  function hI(t, e, n) {
    var i, r, o, a = e.getItemVisual(n, t);
    if (a && "none" !== a) return o = e.getItemVisual(n, t + "Size"), i = e.getItemVisual(n, t + "Rotate"), r = e.getItemVisual(n, t + "Offset"), e = e.getItemVisual(n, t + "KeepAspect"), r = Vy(r || 0, n = Fy(o)), (o = By(a, -n[0] / 2 + r[0], -n[1] / 2 + r[1], n[0], n[1], null, e)).__specifiedRotation = null == i || isNaN(i) ? void 0 : +i * Math.PI / 180 || 0, o.name = t, o
  }

  function cI(t, e) {
    t.x1 = e[0][0], t.y1 = e[0][1], t.x2 = e[1][0], t.y2 = e[1][1], t.percent = 1, (e = e[2]) ? (t.cpx1 = e[0], t.cpy1 = e[1]) : (t.cpx1 = NaN, t.cpy1 = NaN)
  }
  i(fI, pI = Rr), fI.prototype._createLine = function(t, e, n) {
    var i, r, o = t.hostModel;
    (r = (r = r = t.getItemLayout(e), cI((i = new oI({
      name: "line",
      subPixelOptimize: !0
    })).shape, r), i)).shape.percent = 0, wh(r, {
      shape: {
        percent: 1
      }
    }, o, e), this.add(r), N(sI, (function(n) {
      var i = hI(n, t, e);
      this.add(i), this[lI(n)] = uI(n, t, e)
    }), this), this._updateCommonStl(t, e, n)
  }, fI.prototype.updateData = function(t, e, n) {
    var i = t.hostModel,
      r = this.childOfName("line"),
      o = t.getItemLayout(e),
      a = {
        shape: {}
      };
    cI(a.shape, o), xh(r, a, i, e), N(sI, (function(n) {
      var i = uI(n, t, e),
        r = lI(n);
      this[r] !== i && (this.remove(this.childOfName(n)), n = hI(n, t, e), this.add(n)), this[r] = i
    }), this), this._updateCommonStl(t, e, n)
  }, fI.prototype.getLinePath = function() {
    return this.childAt(0)
  }, fI.prototype._updateCommonStl = function(t, e, n) {
    var i = t.hostModel,
      r = this.childOfName("line"),
      o = n && n.emphasisLineStyle,
      a = n && n.blurLineStyle,
      s = n && n.selectLineStyle,
      l = n && n.labelStatesModels,
      u = n && n.emphasisDisabled,
      h = n && n.focus,
      c = n && n.blurScope,
      p = (n && !t.hasItemOption || (o = (f = (n = t.getItemModel(e)).getModel("emphasis")).getModel("lineStyle").getLineStyle(), a = n.getModel(["blur", "lineStyle"]).getLineStyle(), s = n.getModel(["select", "lineStyle"]).getLineStyle(), u = f.get("disabled"), h = f.get("focus"), c = f.get("blurScope"), l = ic(n)), t.getItemVisual(e, "style")),
      d = p.stroke,
      f = (r.useStyle(p), r.style.fill = null, r.style.strokeNoScale = !0, r.ensureState("emphasis").style = o, r.ensureState("blur").style = a, r.ensureState("select").style = s, N(sI, (function(t) {
        var e = this.childOfName(t);
        if (e) {
          e.setColor(d), e.style.opacity = p.opacity;
          for (var n = 0; n < Zs.length; n++) {
            var i = Zs[n],
              o = r.getState(i);
            o && (o = o.style || {}, i = (i = e.ensureState(i)).style || (i.style = {}), null != o.stroke && (i[e.__isEmptyBrush ? "stroke" : "fill"] = o.stroke), null != o.opacity) && (i.opacity = o.opacity)
          }
          e.markRedraw()
        }
      }), this), i.getRawValue(e));
    (n = (nc(this, l, {
      labelDataIndex: e,
      labelFetcher: {
        getFormattedLabel: function(e, n) {
          return i.getFormattedLabel(e, n, t.dataType)
        }
      },
      inheritColor: d || "#000",
      defaultOpacity: p.opacity,
      defaultText: (null == f ? t.getName(e) : isFinite(f) ? jr(f) : f) + ""
    }), this.getTextContent())) && (o = l.normal, n.__align = n.style.align, n.__verticalAlign = n.style.verticalAlign, n.__position = o.get("position") || "middle", W(a = o.get("distance")) || (a = [a, a]), n.__labelDistance = a), this.setTextConfig({
      position: null,
      local: !0,
      inside: !1
    }), Al(this, h, c, u)
  }, fI.prototype.highlight = function() {
    ml(this)
  }, fI.prototype.downplay = function() {
    vl(this)
  }, fI.prototype.updateLayout = function(t, e) {
    this.setLinePoints(t.getItemLayout(e))
  }, fI.prototype.setLinePoints = function(t) {
    var e = this.childOfName("line");
    cI(e.shape, t), e.dirty()
  }, fI.prototype.beforeUpdate = function() {
    var t = this.childOfName("fromSymbol"),
      e = this.childOfName("toSymbol"),
      n = this.getTextContent();
    if (t || e || n && !n.ignore) {
      for (var i = 1, r = this.parent; r;) r.scaleX && (i /= r.scaleX), r = r.parent;
      var o = this.childOfName("line");
      if (this.__dirty || o.__dirty) {
        var a = o.shape.percent,
          s = o.pointAt(0),
          l = o.pointAt(a),
          u = Ct([], l, s);
        if (Lt(u, u), t && (t.setPosition(s), v(t, 0), t.scaleX = t.scaleY = i * a, t.markRedraw()), e && (e.setPosition(l), v(e, 1), e.scaleX = e.scaleY = i * a, e.markRedraw()), n && !n.ignore) {
          n.x = n.y = 0;
          var h = void(n.originX = n.originY = 0),
            c = void 0,
            p = (t = n.__labelDistance)[0] * i,
            d = t[1] * i,
            f = (e = a / 2, o.tangentAt(e)),
            g = (t = [f[1], -f[0]], o.pointAt(e)),
            y = (0 < t[1] && (t[0] = -t[0], t[1] = -t[1]), f[0] < 0 ? -1 : 1),
            m = void("start" !== n.__position && "end" !== n.__position && (a = -Math.atan2(f[1], f[0]), l[0] < s[0] && (a = Math.PI + a), n.rotation = a));
          switch (n.__position) {
            case "insideStartTop":
            case "insideMiddleTop":
            case "insideEndTop":
            case "middle":
              m = -d, c = "bottom";
              break;
            case "insideStartBottom":
            case "insideMiddleBottom":
            case "insideEndBottom":
              m = d, c = "top";
              break;
            default:
              m = 0, c = "middle"
          }
          switch (n.__position) {
            case "end":
              n.x = u[0] * p + l[0], n.y = u[1] * d + l[1], h = .8 < u[0] ? "left" : u[0] < -.8 ? "right" : "center", c = .8 < u[1] ? "top" : u[1] < -.8 ? "bottom" : "middle";
              break;
            case "start":
              n.x = -u[0] * p + s[0], n.y = -u[1] * d + s[1], h = .8 < u[0] ? "right" : u[0] < -.8 ? "left" : "center", c = .8 < u[1] ? "bottom" : u[1] < -.8 ? "top" : "middle";
              break;
            case "insideStartTop":
            case "insideStart":
            case "insideStartBottom":
              n.x = p * y + s[0], n.y = s[1] + m, h = f[0] < 0 ? "right" : "left", n.originX = -p * y, n.originY = -m;
              break;
            case "insideMiddleTop":
            case "insideMiddle":
            case "insideMiddleBottom":
            case "middle":
              n.x = g[0], n.y = g[1] + m, h = "center", n.originY = -m;
              break;
            case "insideEndTop":
            case "insideEnd":
            case "insideEndBottom":
              n.x = -p * y + l[0], n.y = l[1] + m, h = 0 <= f[0] ? "right" : "left", n.originX = p * y, n.originY = -m
          }
          n.scaleX = n.scaleY = i, n.setStyle({
            verticalAlign: n.__verticalAlign || c,
            align: n.__align || h
          })
        }
      }
    }

    function v(t, e) {
      var n, i = t.__specifiedRotation;
      null == i ? (n = o.tangentAt(e), t.attr("rotation", (1 === e ? -1 : 1) * Math.PI / 2 - Math.atan2(n[1], n[0]))) : t.attr("rotation", i)
    }
  };
  var pI, dI = fI;

  function fI(t, e, n) {
    var i = pI.call(this) || this;
    return i._createLine(t, e, n), i
  }
  yI.prototype.updateData = function(t) {
    var e = this,
      n = (this._progressiveEls = null, this.group),
      i = this._lineData,
      r = (this._lineData = t, i || n.removeAll(), mI(t));
    t.diff(i).add((function(n) {
      e._doAdd(t, n, r)
    })).update((function(n, o) {
      e._doUpdate(i, t, o, n, r)
    })).remove((function(t) {
      n.remove(i.getItemGraphicEl(t))
    })).execute()
  }, yI.prototype.updateLayout = function() {
    var t = this._lineData;
    t && t.eachItemGraphicEl((function(e, n) {
      e.updateLayout(t, n)
    }), this)
  }, yI.prototype.incrementalPrepareUpdate = function(t) {
    this._seriesScope = mI(t), this._lineData = null, this.group.removeAll()
  }, yI.prototype.incrementalUpdate = function(t, e) {
    function n(t) {
      var e;
      t.isGroup || (e = t).animators && 0 < e.animators.length || (t.incremental = !0, t.ensureState("emphasis").hoverLayer = !0)
    }
    this._progressiveEls = [];
    for (var i, r = t.start; r < t.end; r++) _I(e.getItemLayout(r)) && ((i = new this._LineCtor(e, r, this._seriesScope)).traverse(n), this.group.add(i), e.setItemGraphicEl(r, i), this._progressiveEls.push(i))
  }, yI.prototype.remove = function() {
    this.group.removeAll()
  }, yI.prototype.eachRendered = function(t) {
    $h(this._progressiveEls || this.group, t)
  }, yI.prototype._doAdd = function(t, e, n) {
    _I(t.getItemLayout(e)) && (n = new this._LineCtor(t, e, n), t.setItemGraphicEl(e, n), this.group.add(n))
  }, yI.prototype._doUpdate = function(t, e, n, i, r) {
    t = t.getItemGraphicEl(n), _I(e.getItemLayout(i)) ? (t ? t.updateData(e, i, r) : t = new this._LineCtor(e, i, r), e.setItemGraphicEl(i, t), this.group.add(t)) : this.group.remove(t)
  };
  var gI = yI;

  function yI(t) {
    this.group = new Rr, this._LineCtor = t || dI
  }

  function mI(t) {
    var e = (t = t.hostModel).getModel("emphasis");
    return {
      lineStyle: t.getModel("lineStyle").getLineStyle(),
      emphasisLineStyle: e.getModel(["lineStyle"]).getLineStyle(),
      blurLineStyle: t.getModel(["blur", "lineStyle"]).getLineStyle(),
      selectLineStyle: t.getModel(["select", "lineStyle"]).getLineStyle(),
      emphasisDisabled: e.get("disabled"),
      blurScope: e.get("blurScope"),
      focus: e.get("focus"),
      labelStatesModels: ic(t)
    }
  }

  function vI(t) {
    return isNaN(t[0]) || isNaN(t[1])
  }

  function _I(t) {
    return t && !vI(t[0]) && !vI(t[1])
  }
  var xI, wI = So();
  i(bI, xI = kg), bI.prototype.init = function() {
    this.markerGroupMap = yt()
  }, bI.prototype.render = function(t, e, n) {
    var i = this,
      r = this.markerGroupMap;
    r.each((function(t) {
      wI(t).keep = !1
    })), e.eachSeries((function(t) {
      var r = WT.getMarkerModelFromSeries(t, i.type);
      r && i.renderSeries(t, r, e, n)
    })), r.each((function(t) {
      wI(t).keep || i.group.remove(t.group)
    }))
  }, bI.prototype.markKeep = function(t) {
    wI(t).keep = !0
  }, bI.prototype.toggleBlurSeries = function(t, e) {
    var n = this;
    N(t, (function(t) {
      (t = WT.getMarkerModelFromSeries(t, n.type)) && t.getData().eachItemGraphicEl((function(t) {
        t && (e ? _l : xl)(t)
      }))
    }))
  }, bI.type = "marker", Qn = bI;

  function bI() {
    var t = null !== xI && xI.apply(this, arguments) || this;
    return t.type = bI.type, t
  }

  function SI(t, e, n, i) {
    var r, o, a, s, l = t.getData();
    return (e = [ZT(t, (n = W(i) ? i : "min" === (r = i.type) || "max" === r || "average" === r || "median" === r || null != i.xAxis || null != i.yAxis ? (o = s = void 0, o = null != i.yAxis || null != i.xAxis ? (s = e.getAxis(null != i.yAxis ? "y" : "x"), et(i.yAxis, i.xAxis)) : (s = (e = KT(i, l, e, t)).valueAxis, QT(l, u_(l, e.valueDataDim), r)), e = 1 - (l = "x" === s.dim ? 0 : 1), s = {
      coord: []
    }, (a = I(i)).type = null, a.coord = [], a.coord[e] = -1 / 0, s.coord[e] = 1 / 0, 0 <= (e = n.get("precision")) && Y(o) && (o = +o.toFixed(Math.min(e, 20))), a.coord[l] = s.coord[l] = o, [a, s, {
      type: r,
      valueIndex: i.valueIndex,
      value: o
    }]) : [])[0]), ZT(t, n[1]), k({}, n[2])])[2].type = e[2].type || null, C(e[2], e[0]), C(e[2], e[1]), e
  }
  var MI = So();

  function TI(t) {
    return !isNaN(t) && !isFinite(t)
  }

  function II(t, e, n, i) {
    var r = 1 - t,
      o = i.dimensions[t];
    return TI(e[r]) && TI(n[r]) && e[t] === n[t] && i.getAxis(o).containData(e[t])
  }

  function CI(t, e) {
    if ("cartesian2d" === t.type) {
      var n = e[0].coord,
        i = e[1].coord;
      if (n && i && (II(1, n, i, t) || II(0, n, i, t))) return !0
    }
    return $T(t, e[0]) && $T(t, e[1])
  }

  function kI(t, e, n, i, r) {
    var o, a, s = i.coordinateSystem,
      l = qr((u = t.getItemModel(e)).get("x"), r.getWidth()),
      u = qr(u.get("y"), r.getHeight());
    isNaN(l) || isNaN(u) ? (o = i.getMarkerPosition ? i.getMarkerPosition(t.getValues(t.dimensions, e)) : (a = s.dimensions, r = t.get(a[0], e), i = t.get(a[1], e), s.dataToPoint([r, i])), Jw(s, "cartesian2d") && (r = s.getAxis("x"), i = s.getAxis("y"), a = s.dimensions, TI(t.get(a[0], e)) ? o[0] = r.toGlobalCoord(r.getExtent()[n ? 0 : 1]) : TI(t.get(a[1], e)) && (o[1] = i.toGlobalCoord(i.getExtent()[n ? 0 : 1]))), isNaN(l) || (o[0] = l), isNaN(u) || (o[1] = u)) : o = [l, u], t.setItemLayout(e, o)
  }
  i(LI, DI = Qn), LI.prototype.updateTransform = function(t, e, n) {
    e.eachSeries((function(t) {
      var e, i, r, o = WT.getMarkerModelFromSeries(t, "markLine");
      o && (e = o.getData(), i = MI(o).from, r = MI(o).to, i.each((function(e) {
        kI(i, e, !0, t, n), kI(r, e, !1, t, n)
      })), e.each((function(t) {
        e.setItemLayout(t, [i.getItemLayout(t), r.getItemLayout(t)])
      })), this.markerGroupMap.get(t.id).updateLayout())
    }), this)
  }, LI.prototype.renderSeries = function(t, e, n, i) {
    var r = t.coordinateSystem,
      o = t.id,
      a = t.getData(),
      s = (s = this.markerGroupMap).get(o) || s.set(o, new gI),
      l = (o = (this.group.add(s.group), function(t, e, n) {
        var i;
        i = t ? E(t && t.dimensions, (function(t) {
          return k(k({}, e.getData().getDimensionInfo(e.getData().mapDimension(t)) || {}), {
            name: t,
            ordinalMeta: null
          })
        })) : [{
          name: "value",
          type: "float"
        }];
        var r = new e_(i, n),
          o = new e_(i, n),
          a = new e_([], n);
        n = E(n.get("data"), H(SI, e, t, n));
        return t && (n = B(n, H(CI, t))), t = function(t, e) {
          return t ? function(t, n, i, r) {
            return bf(r < 2 ? t.coord && t.coord[r] : t.value, e[r])
          } : function(t, n, i, r) {
            return bf(t.value, e[r])
          }
        }(!!t, i), r.initData(E(n, (function(t) {
          return t[0]
        })), null, t), o.initData(E(n, (function(t) {
          return t[1]
        })), null, t), a.initData(E(n, (function(t) {
          return t[2]
        }))), a.hasItemOption = !0, {
          from: r,
          to: o,
          line: a
        }
      }(r, t, e))).from,
      u = o.to,
      h = o.line,
      c = (MI(e).from = l, MI(e).to = u, e.setData(h), e.get("symbol")),
      p = e.get("symbolSize"),
      d = e.get("symbolRotate"),
      f = e.get("symbolOffset");

    function g(e, n, r) {
      var o = e.getItemModel(n),
        s = (kI(e, n, r, t, i), o.getModel("itemStyle").getItemStyle());
      null == s.fill && (s.fill = Sy(a, "color")), e.setItemVisual(n, {
        symbolKeepAspect: o.get("symbolKeepAspect"),
        symbolOffset: nt(o.get("symbolOffset", !0), f[r ? 0 : 1]),
        symbolRotate: nt(o.get("symbolRotate", !0), d[r ? 0 : 1]),
        symbolSize: nt(o.get("symbolSize"), p[r ? 0 : 1]),
        symbol: nt(o.get("symbol", !0), c[r ? 0 : 1]),
        style: s
      })
    }
    W(c) || (c = [c, c]), W(p) || (p = [p, p]), W(d) || (d = [d, d]), W(f) || (f = [f, f]), o.from.each((function(t) {
      g(l, t, !0), g(u, t, !1)
    })), h.each((function(t) {
      var e = h.getItemModel(t).getModel("lineStyle").getLineStyle();
      h.setItemLayout(t, [l.getItemLayout(t), u.getItemLayout(t)]), null == e.stroke && (e.stroke = l.getItemVisual(t, "style").fill), h.setItemVisual(t, {
        fromSymbolKeepAspect: l.getItemVisual(t, "symbolKeepAspect"),
        fromSymbolOffset: l.getItemVisual(t, "symbolOffset"),
        fromSymbolRotate: l.getItemVisual(t, "symbolRotate"),
        fromSymbolSize: l.getItemVisual(t, "symbolSize"),
        fromSymbol: l.getItemVisual(t, "symbol"),
        toSymbolKeepAspect: u.getItemVisual(t, "symbolKeepAspect"),
        toSymbolOffset: u.getItemVisual(t, "symbolOffset"),
        toSymbolRotate: u.getItemVisual(t, "symbolRotate"),
        toSymbolSize: u.getItemVisual(t, "symbolSize"),
        toSymbol: u.getItemVisual(t, "symbol"),
        style: e
      })
    })), s.updateData(h), o.line.eachItemGraphicEl((function(t) {
      Us(t).dataModel = e, t.traverse((function(t) {
        Us(t).dataModel = e
      }))
    })), this.markKeep(s), s.group.silent = e.get("silent") || t.get("silent")
  }, LI.type = "markLine";
  var DI, AI = LI;

  function LI() {
    var t = null !== DI && DI.apply(this, arguments) || this;
    return t.type = LI.type, t
  }
  _x((function(t) {
    t.registerComponentModel(XT), t.registerComponentView(AI), t.registerPreprocessor((function(t) {
      ! function(t, e) {
        if (t)
          for (var n = W(t) ? t : [t], i = 0; i < n.length; i++)
            if (n[i] && n[i].markLine) return 1
      }(t.series) || (t.markLine = t.markLine || {})
    }))
  })), _x(Bw);
  var PI = {
      value: "eq",
      "<": "lt",
      "<=": "lte",
      ">": "gt",
      ">=": "gte",
      "=": "eq",
      "!=": "ne",
      "<>": "ne"
    },
    OI = (RI.prototype.evaluate = function(e) {
      var n = t(e);
      return U(n) ? this._condVal.test(e) : !!Y(n) && this._condVal.test(e + "")
    }, RI);

  function RI(t) {
    null == (this._condVal = U(t) ? new RegExp(t) : J(t) ? t : null) && uo("")
  }
  EI.prototype.evaluate = function() {
    return this.value
  };
  var NI = EI;

  function EI() {}
  BI.prototype.evaluate = function() {
    for (var t = this.children, e = 0; e < t.length; e++)
      if (!t[e].evaluate()) return !1;
    return !0
  };
  var zI = BI;

  function BI() {}
  VI.prototype.evaluate = function() {
    for (var t = this.children, e = 0; e < t.length; e++)
      if (t[e].evaluate()) return !0;
    return !1
  };
  var FI = VI;

  function VI() {}
  WI.prototype.evaluate = function() {
    return !this.child.evaluate()
  };
  var HI = WI;

  function WI() {}
  UI.prototype.evaluate = function() {
    for (var t = !!this.valueParser, e = (0, this.getValue)(this.valueGetterParam), n = t ? this.valueParser(e) : null, i = 0; i < this.subCondList.length; i++)
      if (!this.subCondList[i].evaluate(t ? n : e)) return !1;
    return !0
  };
  var GI = UI;

  function UI() {}

  function XI(t, e) {
    if (!0 === t || !1 === t) return (n = new NI).value = t, n;
    var n;
    if (qI(t) || uo(""), t.and) return YI("and", t, e);
    if (t.or) return YI("or", t, e);
    if (t.not) return n = e, qI(o = (o = t).not) || uo(""), (l = new HI).child = XI(o, n), l.child || uo(""), l;
    for (var i = t, r = e, o = r.prepareGetValue(i), a = [], s = F(i), l = i.parser, u = l ? Mf(l) : null, h = 0; h < s.length; h++) {
      var c, p = s[h];
      "parser" === p || r.valueGetterAttrMap.get(p) || (c = xt(PI, p) ? PI[p] : p, p = i[p], (c = function(t, e) {
        return "eq" === t || "ne" === t ? new Af("eq" === t, e) : xt(Tf, t) ? new If(t, e) : null
      }(c, p = u ? u(p) : p) || "reg" === c && new OI(p)) || uo(""), a.push(c))
    }
    return a.length || uo(""), (l = new GI).valueGetterParam = o, l.valueParser = u, l.getValue = r.getValue, l.subCondList = a, l
  }

  function YI(t, e, n) {
    return W(e = e[t]) || uo(""), e.length || uo(""), (t = new("and" === t ? zI : FI)).children = E(e, (function(t) {
      return XI(t, n)
    })), t.children.length || uo(""), t
  }

  function qI(t) {
    return q(t) && !R(t)
  }
  ZI.prototype.evaluate = function() {
    return this._cond.evaluate()
  };
  var jI = ZI;

  function ZI(t, e) {
    this._cond = XI(t, e)
  }
  var KI = {
      type: "echarts:filter",
      transform: function(t) {
        for (var e, n, i = t.upstream, r = (t = t.config, n = {
            valueGetterAttrMap: yt({
              dimension: !0
            }),
            prepareGetValue: function(t) {
              var e = t.dimension;
              return (t = (xt(t, "dimension") || uo(""), i.getDimensionInfo(e))) || uo(""), {
                dimIdx: t.index
              }
            },
            getValue: function(t) {
              return i.retrieveValueFromItem(e, t.dimIdx)
            }
          }, new jI(t, n)), o = [], a = 0, s = i.count(); a < s; a++) e = i.getRawDataItem(a), r.evaluate() && o.push(e);
        return {
          data: o
        }
      }
    },
    $I = {
      type: "echarts:sort",
      transform: function(t) {
        for (var e = t.upstream, n = ((t = po(t = t.config)).length || uo(""), []), i = ((t = (N(t, (function(t) {
            var i = t.dimension,
              r = t.order,
              o = t.parser,
              a = (t = t.incomparable, (i = (null == i && uo(""), "asc" !== r && "desc" !== r && uo(""), t && "min" !== t && "max" !== t && uo(""), "asc" !== r && "desc" !== r && uo(""), e.getDimensionInfo(i))) || uo(""), o ? Mf(o) : null);
            o && !a && uo(""), n.push({
              dimIdx: i.index,
              parser: a,
              comparator: new kf(r, t)
            })
          })), e.sourceFormat)) !== Lp && t !== Pp && uo(""), []), r = 0, o = e.count(); r < o; r++) i.push(e.getRawDataItem(r));
        return i.sort((function(t, i) {
          for (var r = 0; r < n.length; r++) {
            var o = n[r],
              a = e.retrieveValueFromItem(t, o.dimIdx),
              s = e.retrieveValueFromItem(i, o.dimIdx);
            if (0 !== (o = (o.parser && (a = o.parser(a), s = o.parser(s)), o.comparator.evaluate(a, s)))) return o
          }
          return 0
        })), {
          data: i
        }
      }
    };
  _x((function(t) {
    t.registerTransform(KI), t.registerTransform($I)
  }));
  var QI = Math.sin,
    JI = Math.cos,
    tC = Math.PI,
    eC = 2 * Math.PI,
    nC = 180 / tC,
    iC = (rC.prototype.reset = function(t) {
      this._start = !0, this._d = [], this._str = "", this._p = Math.pow(10, t || 4)
    }, rC.prototype.moveTo = function(t, e) {
      this._add("M", t, e)
    }, rC.prototype.lineTo = function(t, e) {
      this._add("L", t, e)
    }, rC.prototype.bezierCurveTo = function(t, e, n, i, r, o) {
      this._add("C", t, e, n, i, r, o)
    }, rC.prototype.quadraticCurveTo = function(t, e, n, i) {
      this._add("Q", t, e, n, i)
    }, rC.prototype.arc = function(t, e, n, i, r, o) {
      this.ellipse(t, e, n, n, 0, i, r, o)
    }, rC.prototype.ellipse = function(t, e, n, i, r, o, a, s) {
      var l, u = a - o,
        h = (s = !s, oi((p = Math.abs(u)) - eC) || (s ? eC <= u : eC <= -u)),
        c = !!h || !oi(p) && tC <= (0 < u ? u % eC : u % eC + eC) == !!s,
        p = t + n * JI(o);
      u = e + i * QI(o), this._start && this._add("M", p, u), r = Math.round(r * nC);
      h ? (h = 1 / this._p, this._add("A", n, i, r, 1, +s, t + n * JI(o + (l = (s ? 1 : -1) * (eC - h))), e + i * QI(o + l)), .01 < h && this._add("A", n, i, r, 0, +s, p, u)) : (o = t + n * JI(a), l = e + i * QI(a), this._add("A", n, i, r, +c, +s, o, l))
    }, rC.prototype.rect = function(t, e, n, i) {
      this._add("M", t, e), this._add("l", n, 0), this._add("l", 0, i), this._add("l", -n, 0), this._add("Z")
    }, rC.prototype.closePath = function() {
      0 < this._d.length && this._add("Z")
    }, rC.prototype._add = function(t, e, n, i, r, o, a, s, l) {
      for (var u = [], h = this._p, c = 1; c < arguments.length; c++) {
        var p = arguments[c];
        if (isNaN(p)) return void(this._invalid = !0);
        u.push(Math.round(p * h) / h)
      }
      this._d.push(t + u.join(" ")), this._start = "Z" === t
    }, rC.prototype.generateStr = function() {
      this._str = this._invalid ? "" : this._d.join(""), this._d = []
    }, rC.prototype.getStr = function() {
      return this._str
    }, rC);

  function rC() {}
  var oC = "none",
    aC = Math.round,
    sC = ["lineCap", "miterLimit", "lineJoin"],
    lC = E(sC, (function(t) {
      return "stroke-" + t.toLowerCase()
    }));
  var uC = "http://www.w3.org/2000/svg",
    hC = "http://www.w3.org/1999/xlink",
    cC = "ecmeta_";

  function pC(t) {
    return document.createElementNS(uC, t)
  }

  function dC(t, e, n, i, r) {
    return {
      tag: t,
      attrs: n || {},
      children: i,
      text: r,
      key: e
    }
  }

  function fC(t, e) {
    var n = (e = e || {}).newline ? "\n" : "";
    return function t(e) {
      var i = e.children,
        r = e.tag,
        o = e.attrs;
      e = e.text;
      return function(t, e) {
        var n = [];
        if (e)
          for (var i in e) {
            var r = e[i];
            !1 !== r && (!0 !== r && null != r && (i += '="' + r + '"'), n.push(i))
          }
        return "<" + t + " " + n.join(" ") + ">"
      }(r, o) + ("style" !== r ? ee(e) : e || "") + (i ? n + E(i, t).join(n) + n : "") + "</" + r + ">"
    }(t)
  }

  function gC(t) {
    return {
      zrId: t,
      shadowCache: {},
      patternCache: {},
      gradientCache: {},
      clipPathCache: {},
      defs: {},
      cssNodes: {},
      cssAnims: {},
      cssStyleCache: {},
      cssAnimIdx: 0,
      shadowIdx: 0,
      gradientIdx: 0,
      patternIdx: 0,
      clipPathIdx: 0
    }
  }

  function yC(t, e, n, i) {
    return dC("svg", "root", {
      width: t,
      height: e,
      xmlns: uC,
      "xmlns:xlink": hC,
      version: "1.1",
      baseProfile: "full",
      viewBox: !!i && "0 0 " + t + " " + e
    }, n)
  }
  var mC = 0,
    vC = {
      cubicIn: "0.32,0,0.67,0",
      cubicOut: "0.33,1,0.68,1",
      cubicInOut: "0.65,0,0.35,1",
      quadraticIn: "0.11,0,0.5,0",
      quadraticOut: "0.5,1,0.89,1",
      quadraticInOut: "0.45,0,0.55,1",
      quarticIn: "0.5,0,0.75,0",
      quarticOut: "0.25,1,0.5,1",
      quarticInOut: "0.76,0,0.24,1",
      quinticIn: "0.64,0,0.78,0",
      quinticOut: "0.22,1,0.36,1",
      quinticInOut: "0.83,0,0.17,1",
      sinusoidalIn: "0.12,0,0.39,0",
      sinusoidalOut: "0.61,1,0.88,1",
      sinusoidalInOut: "0.37,0,0.63,1",
      exponentialIn: "0.7,0,0.84,0",
      exponentialOut: "0.16,1,0.3,1",
      exponentialInOut: "0.87,0,0.13,1",
      circularIn: "0.55,0,1,0.45",
      circularOut: "0,0.55,0.45,1",
      circularInOut: "0.85,0,0.15,1"
    },
    _C = "transform-origin",
    xC = {
      fill: "fill",
      opacity: "opacity",
      lineWidth: "stroke-width",
      lineDashOffset: "stroke-dashoffset"
    };

  function wC(t, e) {
    var n = e.zrId + "-ani-" + e.cssAnimIdx++;
    return e.cssAnims[n] = t, n
  }

  function bC(t) {
    return U(t) ? vC[t] ? "cubic-bezier(" + vC[t] + ")" : In(t) ? t : "" : ""
  }

  function SC(t, e, n, i) {
    var r = t.animators,
      o = r.length,
      a = [];
    if (t instanceof th) {
      if (l = function(t, e, n) {
          t = t.shape.paths;
          var i, r, o = {};
          if (N(t, (function(t) {
              (e = gC(n.zrId)).animation = !0, SC(t, {}, e, !0), t = e.cssAnims;
              var e, a = e.cssNodes,
                s = (e = F(t)).length;
              if (s) {
                var l, u, h = t[r = e[s - 1]];
                for (l in h) {
                  var c = h[l];
                  o[l] = o[l] || {
                    d: ""
                  }, o[l].d += c.d || ""
                }
                for (u in a) {
                  var p = a[u].animation;
                  0 <= p.indexOf(r) && (i = p)
                }
              }
            })), i) return e.d = !1, t = wC(o, n), i.replace(r, t)
        }(t, e, n)) a.push(l);
      else if (!o) return
    } else if (!o) return;
    for (var s, l, u, h = {}, c = 0; c < o; c++) {
      var p = r[c],
        d = [p.getMaxTime() / 1e3 + "s"],
        f = bC(p.getClip().easing),
        g = p.getDelay();
      h[f = (d.push(f || "linear"), g && d.push(g / 1e3 + "s"), p.getLoop() && d.push("infinite"), d.join(" "))] = h[f] || [f, []], h[f][1].push(p)
    }

    function y(r) {
      var o = r[1],
        a = o.length,
        s = {},
        l = {},
        u = {},
        h = "animation-timing-function";

      function c(t, e, n) {
        for (var i = t.getTracks(), r = t.getMaxTime(), o = 0; o < i.length; o++) {
          var a = i[o];
          if (a.needsAnimate()) {
            var s = a.keyframes,
              l = a.propName;
            if (l = n ? n(l) : l)
              for (var u = 0; u < s.length; u++) {
                var c = s[u],
                  p = Math.round(c.time / r * 100) + "%",
                  d = bC(c.easing),
                  f = c.rawValue;
                (U(f) || Y(f)) && (e[p] = e[p] || {}, e[p][l] = c.rawValue, d) && (e[p][h] = d)
              }
          }
        }
      }
      for (var p, d, f = 0; f < a; f++)(C = (I = o[f]).targetName) ? "shape" === C && c(I, l) : i || c(I, s);
      for (T in s) {
        var g = {},
          y = (pr(g, t), k(g, s[T]), yi(g)),
          m = s[T][h];
        u[T] = y ? {
          transform: y
        } : {}, y = u[T], void 0, p = (g = g).originX, g = g.originY, (p || g) && (y[_C] = p + "px " + g + "px"), m && (u[T][h] = m)
      }
      var v, _, x, w = !0;
      for (T in l) {
        u[T] = u[T] || {};
        var b = !d,
          S = (m = l[T][h], (d = b ? new Wa : d).len()),
          M = (d.reset(), u[T].d = (_ = l[T], x = d, M = void 0, M = k({}, (v = t).shape), k(M, _), v.buildPath(x, M), (_ = new iC).reset(gi(v)), x.rebuildPath(_, 1), _.generateStr(), _.getStr()), d.len());
        if (!b && S !== M) {
          w = !1;
          break
        }
        m && (u[T][h] = m)
      }
      if (!w)
        for (var T in u) delete u[T].d;
      if (!i) {
        var I, C;
        for (f = 0; f < a; f++) "style" === (C = (I = o[f]).targetName) && c(I, u, (function(t) {
          return xC[t]
        }))
      }
      var D, A = F(u),
        L = !0;
      for (f = 1; f < A.length; f++) {
        var P = A[f - 1],
          O = A[f];
        if (u[P][_C] !== u[O][_C]) {
          L = !1;
          break
        }
        D = u[P][_C]
      }
      if (L && D) {
        for (var T in u) u[T][_C] && delete u[T][_C];
        e[_C] = D
      }
      if (B(A, (function(t) {
          return 0 < F(u[t]).length
        })).length) return wC(u, n) + " " + r[0] + " both"
    }
    for (s in h)(l = y(h[s])) && a.push(l);
    a.length && (u = n.zrId + "-cls-" + mC++, n.cssNodes["." + u] = {
      animation: a.join(",")
    }, e.class = u)
  }

  function MC(t, e, n, i) {
    var r = JSON.stringify(t),
      o = n.cssStyleCache[r];
    o || (o = n.zrId + "-cls-" + mC++, n.cssStyleCache[r] = o, n.cssNodes["." + o + (i ? ":hover" : "")] = t), e.class = e.class ? e.class + " " + o : o
  }
  var TC = Math.round;

  function IC(t) {
    return t && U(t.src)
  }

  function CC(t) {
    return t && G(t.toDataURL)
  }

  function kC(t, e, n, i) {
    ! function(t, e, n, i) {
      var r = null == e.opacity ? 1 : e.opacity;
      if (n instanceof gs) t("opacity", r);
      else if (null != (a = (a = e).fill) && a !== oC ? (t("fill", (a = ri(e.fill)).color), a = null != e.fillOpacity ? e.fillOpacity * a.opacity * r : a.opacity * r, (i || a < 1) && t("fill-opacity", a)) : t("fill", oC), null != (a = (a = e).stroke) && a !== oC) {
        var o = (o = (t("stroke", (a = ri(e.stroke)).color), e.strokeNoScale ? n.getLineScale() : 1)) ? (e.lineWidth || 0) / o : 0,
          a = null != e.strokeOpacity ? e.strokeOpacity * a.opacity * r : a.opacity * r;
        r = e.strokeFirst;
        !i && 1 == o || t("stroke-width", o), (i || r) && t("paint-order", r ? "stroke" : "fill"), (i || a < 1) && t("stroke-opacity", a), e.lineDash ? (r = (o = Xy(n))[0], a = o[1], r && (a = aC(a || 0), t("stroke-dasharray", r.join(",")), a || i) && t("stroke-dashoffset", a)) : i && t("stroke-dasharray", oC);
        for (var s = 0; s < sC.length; s++) {
          var l = sC[s];
          (i || e[l] !== is[l]) && (l = e[l] || is[l]) && t(lC[s], l)
        }
      } else i && t("stroke", oC)
    }((function(r, o) {
      var a = "fill" === r || "stroke" === r;
      a && di(o) ? BC(e, t, r, i) : a && hi(o) ? FC(n, t, r, i) : t[r] = a && "none" === o ? "transparent" : o
    }), e, n, !1);
    var r = t,
      o = i;
    if (function(t) {
        return t && (t.shadowBlur || t.shadowOffsetX || t.shadowOffsetY)
      }(g = (h = n).style)) {
      var a = function(t) {
          var e = t.style;
          t = t.getGlobalScale();
          return [e.shadowColor, (e.shadowBlur || 0).toFixed(2), (e.shadowOffsetX || 0).toFixed(2), (e.shadowOffsetY || 0).toFixed(2), t[0], t[1]].join(",")
        }(h),
        s = o.shadowCache,
        l = s[a];
      if (!l) {
        var u = (h = h.getGlobalScale())[0],
          h = h[1];
        if (!u || !h) return;
        var c = g.shadowOffsetX || 0,
          p = g.shadowOffsetY || 0,
          d = g.shadowBlur,
          f = (g = ri(g.shadowColor)).opacity,
          g = g.color;
        d = d / 2 / u + " " + d / 2 / h;
        l = o.zrId + "-s" + o.shadowIdx++, o.defs[l] = dC("filter", l, {
          id: l,
          x: "-100%",
          y: "-100%",
          width: "300%",
          height: "300%"
        }, [dC("feDropShadow", "", {
          dx: c / u,
          dy: p / h,
          stdDeviation: d,
          "flood-color": g,
          "flood-opacity": f
        })]), s[a] = l
      }
      r.filter = fi(l)
    }
  }

  function DC(t, e) {
    var n = Gr(e);
    n && (n.each((function(e, n) {
      null != e && (t[(cC + n).toLowerCase()] = e + "")
    })), e.isSilent()) && (t[cC + "silent"] = "true")
  }

  function AC(t) {
    return oi(t[0] - 1) && oi(t[1]) && oi(t[2]) && oi(t[3] - 1)
  }

  function LC(t, e, n) {
    var i;
    !e || oi((i = e)[4]) && oi(i[5]) && AC(e) || (i = n ? 10 : 1e4, t.transform = AC(e) ? "translate(" + TC(e[4] * i) / i + " " + TC(e[5] * i) / i + ")" : "matrix(" + ai((n = e)[0]) + "," + ai(n[1]) + "," + ai(n[2]) + "," + ai(n[3]) + "," + si(n[4]) + "," + si(n[5]) + ")")
  }

  function PC(t, e, n) {
    for (var i = t.points, r = [], o = 0; o < i.length; o++) r.push(TC(i[o][0] * n) / n), r.push(TC(i[o][1] * n) / n);
    e.points = r.join(" ")
  }

  function OC(t) {
    return !t.smooth
  }
  var RC, NC = {
    circle: [(RC = E(["cx", "cy", "r"], (function(t) {
      return "string" == typeof t ? [t, t] : t
    })), function(t, e, n) {
      for (var i = 0; i < RC.length; i++) {
        var r = RC[i],
          o = t[r[0]];
        null != o && (e[r[1]] = TC(o * n) / n)
      }
    })],
    polyline: [PC, OC],
    polygon: [PC, OC]
  };

  function EC(t, e) {
    var n, i, r, o, a, s = t.style,
      l = t.shape,
      u = NC[t.type],
      h = {},
      c = e.animation,
      p = "path",
      d = t.style.strokePercent,
      f = e.compress && gi(t) || 4;
    return !u || e.willUpdate || u[1] && !u[1](l) || c && function(t) {
      for (var e = t.animators, n = 0; n < e.length; n++)
        if ("shape" === e[n].targetName) return 1
    }(t) || d < 1 ? (c = !t.path || t.shapeChanged(), t.path || t.createPathProxy(), n = t.path, c && (n.beginPath(), t.buildPath(n, t.shape), t.pathUpdated()), c = n.getVersion(), r = (i = t).__svgPathBuilder, i.__svgPathVersion === c && r && d === i.__svgPathStrokePercent || ((r = r || (i.__svgPathBuilder = new iC)).reset(f), n.rebuildPath(r, d), r.generateStr(), i.__svgPathVersion = c, i.__svgPathStrokePercent = d), h.d = r.getStr()) : (p = t.type, n = Math.pow(10, f), u[0](l, h, n)), LC(h, t.transform), kC(h, s, t, e), DC(h, t), e.animation && SC(t, h, e), e.emphasis && (c = h, i = e, (d = t).ignore || (d.isSilent() ? MC(a = {
      "pointer-events": "none"
    }, c, i, !0) : (!(f = (r = d.states.emphasis && d.states.emphasis.style ? d.states.emphasis.style : {}).fill) && (o = d.style && d.style.fill, u = d.states.select && d.states.select.style && d.states.select.style.fill, u = 0 <= d.currentStates.indexOf("select") && u || o) && (f = ni(u)), (o = r.lineWidth) && (o /= !r.strokeNoScale && d.transform ? d.transform[0] : 1), a = {
      cursor: "pointer"
    }, f && (a.fill = f), r.stroke && (a.stroke = r.stroke), o && (a["stroke-width"] = o), MC(a, c, i, !0)))), dC(p, t.id + "", h)
  }

  function zC(t, e) {
    if (t instanceof as) return EC(t, e);
    if (t instanceof gs) {
      var n = e;
      if ((s = (i = (a = t).style).image) && !U(s) && (IC(s) ? s = s.src : CC(s) && (s = s.toDataURL())), s) return r = i.x || 0, o = i.y || 0, s = {
        href: s,
        width: i.width,
        height: i.height
      }, r && (s.x = r), o && (s.y = o), LC(s, a.transform), kC(s, i, a, n), DC(s, a), n.animation && SC(a, s, n), dC("image", a.id + "", s)
    } else if (t instanceof hs) {
      var i, r = t,
        o = e;
      if (null != (n = (i = r.style).text) && (n += ""), n && !isNaN(i.x) && !isNaN(i.y)) {
        var a = i.font || u,
          s = i.x || 0,
          h = (t = i.y || 0, e = _r(a), "top" === (h = i.textBaseline) ? t += e / 2 : "bottom" === h && (t -= e / 2), t);
        e = {
          "dominant-baseline": "central",
          "text-anchor": li[i.textAlign] || i.textAlign
        };
        if (Es(i)) {
          t = "";
          var c = i.fontStyle,
            p = Rs(i.fontSize);
          if (!parseFloat(p)) return;
          var d = i.fontFamily || l,
            f = i.fontWeight;
          t += "font-size:" + p + ";font-family:" + d + ";", c && "normal" !== c && (t += "font-style:" + c + ";"), f && "normal" !== f && (t += "font-weight:" + f + ";"), e.style = t
        } else e.style = "font: " + a;
        return n.match(/\s/) && (e["xml:space"] = "preserve"), s && (e.x = s), h && (e.y = h), LC(e, r.transform), kC(e, i, r, o), DC(e, r), o.animation && SC(r, e, o), dC("text", r.id + "", e, void 0, n)
      }
    }
  }

  function BC(t, e, n, i) {
    var r, o = {
      gradientUnits: (t = t[n]).global ? "userSpaceOnUse" : "objectBoundingBox"
    };
    if (ci(t)) r = "linearGradient", o.x1 = t.x, o.y1 = t.y, o.x2 = t.x2, o.y2 = t.y2;
    else {
      if (!pi(t)) return;
      r = "radialGradient", o.cx = nt(t.x, .5), o.cy = nt(t.y, .5), o.r = nt(t.r, .5)
    }
    for (var a = t.colorStops, s = [], l = 0, u = a.length; l < u; ++l) {
      var h = 100 * si(a[l].offset) + "%",
        c = (p = ri(a[l].color)).color,
        p = p.opacity;
      (h = {
        offset: h
      })["stop-color"] = c, p < 1 && (h["stop-opacity"] = p), s.push(dC("stop", l + "", h))
    }
    t = fC(dC(r, "", o, s));
    var d = i.gradientCache,
      f = d[t];
    f || (f = i.zrId + "-g" + i.gradientIdx++, d[t] = f, o.id = f, i.defs[f] = dC(r, f, o, s)), e[n] = fi(f)
  }

  function FC(t, e, n, i) {
    var r, o, a, s, l, u, h, c, p = t.style[n],
      d = t.getBoundingRect(),
      f = {},
      g = p.repeat,
      y = "no-repeat" === g,
      m = "repeat-x" === g,
      v = "repeat-y" === g;
    ui(p) ? (o = p.imageWidth, a = p.imageHeight, g = void 0, U(h = p.image) ? g = h : IC(h) ? g = h.src : CC(h) && (g = h.toDataURL()), "undefined" == typeof Image ? (at(o, h = "Image width/height must been given explictly in svg-ssr renderer."), at(a, h)) : null != o && null != a || (s = function(t, e) {
      var n, i;
      t && (n = t.elm, i = o || e.width, e = a || e.height, "pattern" === t.tag && (m ? (e = 1, i /= d.width) : v && (i = 1, e /= d.height)), t.attrs.width = i, t.attrs.height = e, n) && (n.setAttribute("width", i), n.setAttribute("height", e))
    }, (h = Xo(g, null, t, (function(t) {
      y || s(u, t), s(r, t)
    }))) && h.width && h.height && (o = o || h.width, a = a || h.height)), r = dC("image", "img", {
      href: g,
      width: o,
      height: a
    }), f.width = o, f.height = a) : p.svgElement && (r = I(p.svgElement), f.width = p.svgWidth, f.height = p.svgHeight), r && (y ? c = l = 1 : m ? (l = 1, c = f.width / d.width) : v ? (c = 1, l = f.height / d.height) : f.patternUnits = "userSpaceOnUse", null == c || isNaN(c) || (f.width = c), null == l || isNaN(l) || (f.height = l), (t = yi(p)) && (f.patternTransform = t), h = fC(u = dC("pattern", "", f, [r])), (c = (g = i.patternCache)[h]) || (c = i.zrId + "-p" + i.patternIdx++, g[h] = c, f.id = c, u = i.defs[c] = dC("pattern", c, f, [r])), e[n] = fi(c))
  }

  function VC(t) {
    return document.createTextNode(t)
  }

  function HC(t, e, n) {
    t.insertBefore(e, n)
  }

  function WC(t, e) {
    t.removeChild(e)
  }

  function GC(t, e) {
    t.appendChild(e)
  }

  function UC(t) {
    return t.parentNode
  }

  function XC(t) {
    return t.nextSibling
  }

  function YC(t, e) {
    t.textContent = e
  }
  var qC = dC("", "");

  function jC(t) {
    return void 0 === t
  }

  function ZC(t) {
    return void 0 !== t
  }

  function KC(t, e) {
    var n = t.key === e.key;
    return t.tag === e.tag && n
  }

  function $C(t) {
    var e, n = t.children,
      i = t.tag;
    if (ZC(i)) {
      var r = t.elm = pC(i);
      if (tk(qC, t), W(n))
        for (e = 0; e < n.length; ++e) {
          var o = n[e];
          null != o && GC(r, $C(o))
        } else ZC(t.text) && !q(t.text) && GC(r, VC(t.text))
    } else t.elm = VC(t.text);
    return t.elm
  }

  function QC(t, e, n, i, r) {
    for (; i <= r; ++i) {
      var o = n[i];
      null != o && HC(t, $C(o), e)
    }
  }

  function JC(t, e, n, i) {
    for (; n <= i; ++n) {
      var r = e[n];
      null != r && (ZC(r.tag) ? WC(UC(r.elm), r.elm) : WC(t, r.elm))
    }
  }

  function tk(t, e) {
    var n, i = e.elm,
      r = t && t.attrs || {},
      o = e.attrs || {};
    if (r !== o) {
      for (n in o) {
        var a = o[n];
        r[n] !== a && (!0 === a ? i.setAttribute(n, "") : !1 === a ? i.removeAttribute(n) : "style" === n ? i.style.cssText = a : 120 !== n.charCodeAt(0) ? i.setAttribute(n, a) : "xmlns:xlink" === n || "xmlns" === n ? i.setAttributeNS("http://www.w3.org/2000/xmlns/", n, a) : 58 === n.charCodeAt(3) ? i.setAttributeNS("http://www.w3.org/XML/1998/namespace", n, a) : 58 === n.charCodeAt(5) ? i.setAttributeNS(hC, n, a) : i.setAttribute(n, a))
      }
      for (n in r) n in o || i.removeAttribute(n)
    }
  }

  function ek(t, e) {
    var n = e.elm = t.elm,
      i = t.children,
      r = e.children;
    t !== e && (tk(t, e), jC(e.text) ? ZC(i) && ZC(r) ? i !== r && function(t, e, n) {
      for (var i, r, o, a = 0, s = 0, l = e.length - 1, u = e[0], h = e[l], c = n.length - 1, p = n[0], d = n[c]; a <= l && s <= c;) null == u ? u = e[++a] : null == h ? h = e[--l] : null == p ? p = n[++s] : null == d ? d = n[--c] : KC(u, p) ? (ek(u, p), u = e[++a], p = n[++s]) : KC(h, d) ? (ek(h, d), h = e[--l], d = n[--c]) : KC(u, d) ? (ek(u, d), HC(t, u.elm, XC(h.elm)), u = e[++a], d = n[--c]) : (KC(h, p) ? (ek(h, p), HC(t, h.elm, u.elm), h = e[--l]) : (jC(i) && (i = function(t, e, n) {
        for (var i = {}, r = e; r <= n; ++r) {
          var o = t[r].key;
          void 0 !== o && (i[o] = r)
        }
        return i
      }(e, a, l)), jC(r = i[p.key]) || (o = e[r]).tag !== p.tag ? HC(t, $C(p), u.elm) : (ek(o, p), e[r] = void 0, HC(t, o.elm, u.elm))), p = n[++s]);
      (a <= l || s <= c) && (l < a ? QC(t, null == n[c + 1] ? null : n[c + 1].elm, n, s, c) : JC(t, e, a, l))
    }(n, i, r) : ZC(r) ? (ZC(t.text) && YC(n, ""), QC(n, null, r, 0, r.length - 1)) : ZC(i) ? JC(n, i, 0, i.length - 1) : ZC(t.text) && YC(n, "") : t.text !== e.text && (ZC(i) && JC(n, i, 0, i.length - 1), YC(n, e.text)))
  }
  var nk = 0;

  function ik(t, e, n) {
    var i;
    this.type = "svg", this.refreshHover = function() {}, this.configLayer = function() {}, this.storage = e, this._opts = n = k({}, n), this.root = t, this._id = "zr" + nk++, this._oldVNode = yC(n.width, n.height), t && !n.ssr && ((e = this._viewport = document.createElement("div")).style.cssText = "position:relative;overflow:hidden", i = this._svgDom = this._oldVNode.elm = pC("svg"), tk(null, this._oldVNode), e.appendChild(i), t.appendChild(e)), this.resize(n.width, n.height)
  }
  ik.prototype.getType = function() {
    return this.type
  }, ik.prototype.getViewportRoot = function() {
    return this._viewport
  }, ik.prototype.getViewportRootOffset = function() {
    var t = this.getViewportRoot();
    if (t) return {
      offsetLeft: t.offsetLeft || 0,
      offsetTop: t.offsetTop || 0
    }
  }, ik.prototype.getSvgDom = function() {
    return this._svgDom
  }, ik.prototype.refresh = function() {
    var t, e, n, i, r;
    this.root && ((t = this.renderToVNode({
      willUpdate: !0
    })).attrs.style = "position:absolute;left:0;top:0;user-select:none", KC(e = this._oldVNode, n = t) ? ek(e, n) : (r = UC(i = e.elm), $C(n), null !== r && (HC(r, n.elm, XC(i)), JC(r, [e], 0, 0))), this._oldVNode = t)
  }, ik.prototype.renderOneToVNode = function(t) {
    return zC(t, gC(this._id))
  }, ik.prototype.renderToVNode = function(t) {
    t = t || {};
    var e, n, i, r, o, a = this.storage.getDisplayList(!0),
      s = this._width,
      l = this._height,
      u = gC(this._id),
      h = (u.animation = t.animation, u.willUpdate = t.willUpdate, u.compress = t.compress, u.emphasis = t.emphasis, []),
      c = ((c = this._bgVNode = function(t, e, n, i) {
        var r;
        return n && "none" !== n && (r = dC("rect", "bg", {
          width: t,
          height: e,
          x: "0",
          y: "0"
        }), di(n) ? BC({
          fill: n
        }, r.attrs, "fill", i) : hi(n) ? FC({
          style: {
            fill: n
          },
          dirty: wt,
          getBoundingRect: function() {
            return {
              width: t,
              height: e
            }
          }
        }, r.attrs, "fill", i) : (n = (i = ri(n)).color, i = i.opacity, r.attrs.fill = n, i < 1 && (r.attrs["fill-opacity"] = i))), r
      }(s, l, this._backgroundColor, u)) && h.push(c), t.compress ? null : this._mainVNode = dC("g", "main", {}, []));
    return (a = (this._paintList(a, u, c ? c.children : h), c && h.push(c), E(F(u.defs), (function(t) {
      return u.defs[t]
    })))).length && h.push(dC("defs", "defs", {}, a)), t.animation && (e = u.cssNodes, n = u.cssAnims, i = (c = (c = {
      newline: !0
    }) || {}).newline ? "\n" : "", r = " {" + i, o = i + "}", c = E(F(e), (function(t) {
      return t + r + E(F(e[t]), (function(n) {
        return n + ":" + e[t][n] + ";"
      })).join(i) + o
    })).join(i), a = E(F(n), (function(t) {
      return "@keyframes " + t + r + E(F(n[t]), (function(e) {
        return e + r + E(F(n[t][e]), (function(i) {
          var r = n[t][e][i];
          return i + ":" + (r = "d" === i ? 'path("' + r + '")' : r) + ";"
        })).join(i) + o
      })).join(i) + o
    })).join(i), c = c || a ? ["<![CDATA[", c, a, "]]>"].join(i) : "") && (a = dC("style", "stl", {}, [], c), h.push(a)), yC(s, l, h, t.useViewBox)
  }, ik.prototype.renderToString = function(t) {
    return fC(this.renderToVNode({
      animation: nt((t = t || {}).cssAnimation, !0),
      emphasis: nt(t.cssEmphasis, !0),
      willUpdate: !1,
      compress: !0,
      useViewBox: nt(t.useViewBox, !0)
    }), {
      newline: !0
    })
  }, ik.prototype.setBackgroundColor = function(t) {
    this._backgroundColor = t
  }, ik.prototype.getSvgRoot = function() {
    return this._mainVNode && this._mainVNode.elm
  }, ik.prototype._paintList = function(t, e, n) {
    for (var i, r, o, a, s, l, u, h = t.length, c = [], p = 0, d = 0, f = 0; f < h; f++) {
      var g = t[f];
      if (!g.invisible) {
        var y = g.__clipPaths,
          m = y && y.length || 0,
          v = M && M.length || 0,
          _ = void 0;
        for (_ = Math.max(m - 1, v - 1); 0 <= _ && (!y || !M || y[_] !== M[_]); _--);
        for (var x = v - 1; _ < x; x--) i = c[--p - 1];
        for (var w = _ + 1; w < m; w++) {
          var b = {},
            S = (r = y[w], o = b, u = S = l = s = void 0, l = (a = e).clipPathCache, S = a.defs, (u = l[r.id]) || (s = {
              id: u = a.zrId + "-c" + a.clipPathIdx++
            }, S[l[r.id] = u] = dC("clipPath", u, s, [EC(r, a)])), o["clip-path"] = fi(u), dC("g", "clip-g-" + d++, b, []));
          (i ? i.children : n).push(S), i = c[p++] = S
        }
        var M = y;
        (v = zC(g, e)) && (i ? i.children : n).push(v)
      }
    }
  }, ik.prototype.resize = function(t, e) {
    var n = this._opts,
      i = this.root,
      r = this._viewport;
    null != t && (n.width = t), null != e && (n.height = e), i && r && (r.style.display = "none", t = Uy(i, 0, n), e = Uy(i, 1, n), r.style.display = ""), this._width === t && this._height === e || (this._width = t, this._height = e, r && ((i = r.style).width = t + "px", i.height = e + "px"), hi(this._backgroundColor) ? this.refresh() : ((n = this._svgDom) && (n.setAttribute("width", t), n.setAttribute("height", e)), (r = this._bgVNode && this._bgVNode.elm) && (r.setAttribute("width", t), r.setAttribute("height", e))))
  }, ik.prototype.getWidth = function() {
    return this._width
  }, ik.prototype.getHeight = function() {
    return this._height
  }, ik.prototype.dispose = function() {
    this.root && (this.root.innerHTML = ""), this._svgDom = this._viewport = this.storage = this._oldVNode = this._bgVNode = this._mainVNode = null
  }, ik.prototype.clear = function() {
    this._svgDom && (this._svgDom.innerHTML = null), this._oldVNode = null
  }, ik.prototype.toDataURL = function(t) {
    var e = this.renderToString(),
      n = "data:image/svg+xml;";
    return t ? (e = mi(e)) && n + "base64," + e : n + "charset=UTF-8," + encodeURIComponent(e)
  }, Wr("svg", ik), e.Axis = gy, e.ChartView = Og, e.ComponentModel = Tp, e.ComponentView = kg, e.List = e_, e.Model = Mc, e.PRIORITY = Ly, e.SeriesModel = _g, e.color = Kn, e.connect = function(t) {
    var e;
    return W(t) && (e = t, t = null, N(e, (function(e) {
      null != e.group && (t = e.group)
    })), t = t || "g_" + uv++, N(e, (function(e) {
      e.group = t
    }))), sv[t] = !0, t
  }, e.dataTool = {}, e.dependencies = {
    zrender: "5.6.0"
  }, e.disConnect = Ay, e.disconnect = cv, e.dispose = function(t) {
    U(t) ? t = av[t] : t instanceof Xm || (t = pv(t)), t instanceof Xm && !t.isDisposed() && t.dispose()
  }, e.env = o, e.extendChartView = function(t) {
    return t = Og.extend(t), Og.registerClass(t), t
  }, e.extendComponentModel = function(t) {
    return t = Tp.extend(t), Tp.registerClass(t), t
  }, e.extendComponentView = function(t) {
    return t = kg.extend(t), kg.registerClass(t), t
  }, e.extendSeriesModel = function(t) {
    return t = _g.extend(t), _g.registerClass(t), t
  }, e.format = wy, e.getCoordinateSystemDimensions = function(t) {
    if (t = ld.get(t)) return t.getDimensionsInfo ? t.getDimensionsInfo() : t.dimensions.slice()
  }, e.getInstanceByDom = pv, e.getInstanceById = function(t) {
    return av[t]
  }, e.getMap = function(t) {
    var e = fm.getMap;
    return e && e(t)
  }, e.graphic = wc, e.helper = Py, e.init = function(t, e, n) {
    var i = !(n && n.ssr);
    if (i) {
      var r = pv(t);
      if (r) return r
    }
    return (r = new Xm(t, e, n)).id = "ec_" + lv++, av[r.id] = r, i && Do(t, hv, r.id), Hm(r), dm.trigger("afterinit", r), r
  }, e.innerDrawElementOnCanvas = am, e.matrix = be, e.number = vc, e.parseGeoJSON = Ex, e.parseGeoJson = Ex, e.registerAction = _v, e.registerCoordinateSystem = xv, e.registerLayout = wv, e.registerLoading = Tv, e.registerLocale = Pc, e.registerMap = Iv, e.registerPostInit = yv, e.registerPostUpdate = mv, e.registerPreprocessor = fv, e.registerProcessor = gv, e.registerTheme = dv, e.registerTransform = Cv, e.registerUpdateLifecycle = vv, e.registerVisual = bv, e.setCanvasCreator = function(t) {
    p({
      createCanvas: t
    })
  }, e.setPlatformAPI = p, e.throttle = Gg, e.time = Wo, e.use = _x, e.util = by, e.vector = Vt, e.version = "5.5.1", e.zrUtil = St, e.zrender = Xr
}));