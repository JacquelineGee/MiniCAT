var e = require("../@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.requestService = exports.isRelogin = void 0;
var r = e(require("../@babel/runtime/regenerator")),
  t = require("../@babel/runtime/helpers/objectSpread2"),
  o = require("../@babel/runtime/helpers/asyncToGenerator"),
  n = e(require("./config.js")),
  a = {
    show: !1
  };
exports.isRelogin = a;
var i = function() {
  var e = o(r.default.mark((function e(o) {
    var a, i, u, c = arguments;
    return r.default.wrap((function(e) {
      for (;;) switch (e.prev = e.next) {
        case 0:
          return a = c.length > 1 && void 0 !== c[1] ? c[1] : {}, i = c.length > 2 && void 0 !== c[2] ? c[2] : "GET", u = c.length > 3 && void 0 !== c[3] ? c[3] : {}, e.abrupt("return", new Promise((function(e, r) {
            var c = {
                "Content-Type": "application/json;charset=utf-8"
              },
              l = wx.getStorageSync("access_token");
            !(!1 === u.isToken) && l && (c.Authorization = "Bearer ".concat(l)), wx.request({
              url: "".concat(n.default.host).concat(o),
              data: a,
              method: i,
              traditional: !0,
              header: t(t({}, c), u),
              success: function(t) {
                200 === t.statusCode ? e(s(t.data)) : r("无效的会话，或者会话已过期，请重新登录。")
              },
              fail: function(e) {
                console.error("请求失败", e), r(e)
              }
            })
          })));
        case 4:
        case "end":
          return e.stop()
      }
    }), e)
  })));
  return function(r) {
    return e.apply(this, arguments)
  }
}();
exports.requestService = i;
var s = function(e) {
  return 401 === e.code ? (a.show || (a.show = !0, wx.showModal({
    title: "系统提示",
    content: "登录状态已过期，请点击确定重新登录",
    success: function(e) {
      e.confirm && (a.show = !1, wx.reLaunch({
        url: "/pages/login/login"
      }))
    }
  })), Promise.reject("无效的会话，或者会话已过期，请重新登录。")) : 500 === e.code ? (wx.showToast({
    title: "服务器错误",
    icon: "error",
    duration: 2e3
  }), Promise.reject(new Error(e.msg || "服务器错误"))) : e.data ? e.data : e.rows || 200 == e.code && e.msg ? e : void 0
};