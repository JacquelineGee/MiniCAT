var M = require("../../@babel/runtime/helpers/interopRequireDefault"),
  N = require("../../@babel/runtime/helpers/toConsumableArray");
require("../../@babel/runtime/helpers/Arrayincludes");
var j = M(require("../../@babel/runtime/regenerator")),
  I = require("../../@babel/runtime/helpers/objectSpread2"),
  D = require("../../@babel/runtime/helpers/asyncToGenerator"),
  g = require("../../utils/request"),
  u = M(require("../../utils/config.js")),
  i = getApp();
Page({
  data: {
    toptarHeight: 0,
    value: "",
    status: 1,
    statusList: [{
      text: "已处理",
      value: 2
    }, {
      text: "待处理",
      value: 1
    }, {
      text: "全部",
      value: 0
    }],
    warningImg: {
      1: "PHN2ZyB3aWR0aD0iNDgiIGhlaWdodD0iMjAiIHZpZXdCb3g9IjAgMCA0OCAyMCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxnIGNsaXAtcGF0aD0idXJsKCNjbGlwMF80NDJfNDY4KSI+DQo8cGF0aCBkPSJNNCAwSDQ0TDQ4IDVIMEw0IDBaIiBmaWxsPSIjOUEyMjJDIi8+DQo8cGF0aCBkPSJNNCAwSDQ0VjE4QzQ0IDE5LjEwNDYgNDMuMTA0NiAyMCA0MiAyMEg2QzQuODk1NDMgMjAgNCAxOS4xMDQ2IDQgMThWMFoiIGZpbGw9IiNGRjRENUQiLz4NCjxwYXRoIGQ9Ik0xNS40MiA0LjE4NEgxNi42NTZWOC41NzZIMTUuNDJWNC4xODRaTTEzLjIyNCA0LjcxMkgxNC40MzZWOC4yNzZIMTMuMjI0VjQuNzEyWk0xNy42NjQgNS42NDhIMTcuMjMyVjQuNTJIMjIuNjA4VjUuNTc2QzIyLjM1NiA2LjIyNCAyMS44NzYgNi43ODggMjEuMTY4IDcuMjQ0QzIxLjc1NiA3LjQ3MiAyMi40MjggNy42NzYgMjMuMTk2IDcuODU2TDIyLjUyNCA4LjkyNEMyMS41MDQgOC42IDIwLjY0IDguMjQgMTkuOTQ0IDcuODU2QzE5LjM0NCA4LjA4NCAxOC42NzIgOC4yNzYgMTcuOTE2IDguNDQ0TDE4LjQ4IDguODY0QzE3Ljg4IDkuMjcyIDE3LjI1NiA5LjYzMiAxNi42MDggOS45NDRMMTguNjg0IDkuODI0QzE5LjE0IDkuNTcyIDE5LjYwOCA5LjMwOCAyMC4wNzYgOS4wMzJMMjEuMTMyIDkuNzI4QzE5Ljc4OCAxMC40OTYgMTguMyAxMS4xNDQgMTYuNjY4IDExLjY0OEMxOC4wNzIgMTEuNTg4IDE5LjQ1MiAxMS41MTYgMjAuODA4IDExLjQzMkMyMC41OTIgMTEuMjE2IDIwLjM2NCAxMSAyMC4xMzYgMTAuNzk2TDIxLjEwOCAxMC4xOTZDMjIuMDQ0IDExLjAxMiAyMi43NTIgMTEuNzMyIDIzLjI1NiAxMi4zMzJMMjIuMjQ4IDEzLjAxNkMyMi4wNDQgMTIuNzUyIDIxLjgyOCAxMi41IDIxLjU4OCAxMi4yMzZDMjAuNTggMTIuMzA4IDE5LjYwOCAxMi4zNjggMTguNjg0IDEyLjQxNlYxNC4wNzJDMTguNjg0IDE0LjgyOCAxOC4zIDE1LjIxMiAxNy41NDQgMTUuMjEySDE2LjQxNkwxNi4xNTIgMTQuMDM2QzE2LjQ4OCAxNC4wODQgMTYuODEyIDE0LjEyIDE3LjEyNCAxNC4xMkMxNy4zMTYgMTQuMTIgMTcuNDEyIDE0IDE3LjQxMiAxMy43NzJWMTIuNDg4QzE1Ljk3MiAxMi41NiAxNC42MTYgMTIuNjA4IDEzLjM2OCAxMi42NTZMMTMuMTE2IDExLjU0QzEzLjQ3NiAxMS41NjQgMTMuODM2IDExLjU3NiAxNC4xOTYgMTEuNTc2QzE1LjA2IDExLjM4NCAxNS45NzIgMTEuMDg0IDE2LjkzMiAxMC42NzZDMTYuMDA4IDEwLjcyNCAxNS4wOTYgMTAuNzcyIDE0LjE5NiAxMC44MzJMMTMuOTggOS43ODhDMTQuNTA4IDkuNzg4IDE0Ljg5MiA5Ljc0IDE1LjEwOCA5LjY1NkMxNS44MTYgOS4zMiAxNi41NiA4Ljg2NCAxNy4zNCA4LjMxMkwxNi45MDggNy41MkMxNy42MjggNy40IDE4LjI2NCA3LjI1NiAxOC44MTYgNy4wODhDMTguMjg4IDYuNjMyIDE3LjkwNCA2LjE1MiAxNy42NjQgNS42NDhaTTE5Ljk0NCA2LjY1NkMyMC41NjggNi4zNjggMjEuMDI0IDYuMDMyIDIxLjMzNiA1LjY0OEgxOC43OTJDMTkuMDU2IDYuMDIgMTkuNDQgNi4zNTYgMTkuOTQ0IDYuNjU2Wk0xOS44NDggMTIuNjkyQzIxLjA5NiAxMy4wNjQgMjIuMjM2IDEzLjUyIDIzLjI2OCAxNC4wNDhMMjIuNjA4IDE1LjEwNEMyMS41MTYgMTQuNDY4IDIwLjM4OCAxMy45NzYgMTkuMjM2IDEzLjYxNkwxOS44NDggMTIuNjkyWk0xNS44ODggMTIuNzE2TDE2LjYzMiAxMy41NTZDMTUuNjk2IDE0LjE1NiAxNC41NDQgMTQuNjQ4IDEzLjE3NiAxNS4wNTZMMTIuNjM2IDEzLjkyOEMxMy45NTYgMTMuNjE2IDE1LjAzNiAxMy4yMDggMTUuODg4IDEyLjcxNlpNMzMuOTI0IDExLjI4OEgyNS45MlYxMC4xODRIMzIuNzEyVjkuNTcySDI2LjM3NlY4LjUxNkgzMi43MTJWNy45MDRIMjUuOTY4QzI1Ljc0IDguMDcyIDI1LjUxMiA4LjIyOCAyNS4yNzIgOC4zODRMMjQuNDggNy40MjRDMjUuODQ4IDYuNjA4IDI3LjAzNiA1LjQ2OCAyOC4wNTYgMy45OTJMMjkuMzE2IDQuMjhDMjkuMTcyIDQuNDg0IDI5LjA0IDQuNjc2IDI4LjkyIDQuODY4SDMyLjU5MlY1LjcyQzMyLjI5MiA2LjEyOCAzMS45OTIgNi40ODggMzEuNzA0IDYuOEgzMy45MjRWMTEuMjg4Wk0zMC4xOCA2LjhDMzAuNDY4IDYuNTM2IDMwLjc1NiA2LjIzNiAzMS4wNTYgNS45SDI4LjExNkMyNy44NCA2LjIxMiAyNy41NjQgNi41MTIgMjcuMjc2IDYuOEgzMC4xOFpNMjUuNzY0IDExLjgwNEwyNi45ODggMTIuMDU2QzI2LjY3NiAxMy4xNiAyNi4yNDQgMTQuMTIgMjUuNjggMTQuOTM2TDI0LjYgMTQuMjUyQzI1LjE1MiAxMy40ODQgMjUuNTM2IDEyLjY2OCAyNS43NjQgMTEuODA0Wk0zMS42OCAxNS4wOTJIMjguNzY0QzI3LjkyNCAxNS4wOTIgMjcuNTA0IDE0LjY2IDI3LjUwNCAxMy44MlYxMS43NDRIMjguNzUyVjEzLjU0NEMyOC43NTIgMTMuODMyIDI4Ljg3MiAxMy45NzYgMjkuMTI0IDEzLjk3NkgzMS40NTJDMzEuNjQ0IDEzLjk3NiAzMS43ODggMTMuOTE2IDMxLjg4NCAxMy44MkMzMi4wMDQgMTMuNyAzMi4wNzYgMTMuMzI4IDMyLjExMiAxMi43MTZMMzMuMyAxMy4xMTJDMzMuMjA0IDE0LjA3MiAzMy4wMjQgMTQuNjQ4IDMyLjc2IDE0Ljg0QzMyLjUyIDE1LjAwOCAzMi4xNiAxNS4wOTIgMzEuNjggMTUuMDkyWk0zMC4zNiAxMS4zNkMzMC45MTIgMTEuOTEyIDMxLjM0NCAxMi40MDQgMzEuNjQ0IDEyLjgxMkwzMC42IDEzLjUzMkMzMC4yODggMTMuMDc2IDI5Ljg2OCAxMi41NiAyOS4zMjggMTEuOTk2TDMwLjM2IDExLjM2Wk0zMy45IDExLjUxNkMzNC42MiAxMi40NzYgMzUuMTg0IDEzLjMyOCAzNS41OCAxNC4wNDhMMzQuNTM2IDE0Ljc4QzM0LjEyOCAxMy45ODggMzMuNTg4IDEzLjExMiAzMi44OTIgMTIuMTUyTDMzLjkgMTEuNTE2WiIgZmlsbD0id2hpdGUiLz4NCjwvZz4NCjxkZWZzPg0KPGNsaXBQYXRoIGlkPSJjbGlwMF80NDJfNDY4Ij4NCjxyZWN0IHdpZHRoPSI0OCIgaGVpZ2h0PSIyMCIgZmlsbD0id2hpdGUiLz4NCjwvY2xpcFBhdGg+DQo8L2RlZnM+DQo8L3N2Zz4NCg==",
      2: "PHN2ZyB3aWR0aD0iNDgiIGhlaWdodD0iMjAiIHZpZXdCb3g9IjAgMCA0OCAyMCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxnIGNsaXAtcGF0aD0idXJsKCNjbGlwMF8zODZfOTM1KSI+DQo8cGF0aCBkPSJNNCAwSDQ0TDQ4IDVIMEw0IDBaIiBmaWxsPSIjMDU0OThGIi8+DQo8cGF0aCBkPSJNNCAwSDQ0VjE4QzQ0IDE5LjEwNDYgNDMuMTA0NiAyMCA0MiAyMEg2QzQuODk1NDMgMjAgNCAxOS4xMDQ2IDQgMThWMFoiIGZpbGw9IiMwNTc1RTYiLz4NCjxwYXRoIGQ9Ik0xMy45NjggMTUuMTRIMTIuOTEyTDEyLjYzNiAxMy45MjhDMTIuOTQ4IDEzLjk3NiAxMy4yNDggMTQgMTMuNTM2IDE0QzEzLjggMTQgMTMuOTMyIDEzLjg1NiAxMy45MzIgMTMuNTkyVjExLjE4QzEzLjU0OCAxMS4zMjQgMTMuMTUyIDExLjQ2OCAxMi43NDQgMTEuNkwxMi40MzIgMTAuMzI4QzEyLjkzNiAxMC4yMDggMTMuNDQgMTAuMDY0IDEzLjkzMiA5Ljg5NlY3LjUySDEyLjYyNFY2LjMwOEgxMy45MzJWNC4xODRIMTUuMjA0VjYuMzA4SDE2LjI3MlY3LjUySDE1LjIwNFY5LjM2OEMxNS40OTIgOS4yMjQgMTUuNzggOS4wNjggMTYuMDY4IDguOTI0VjEwLjE5NkwxNS4yMDQgMTAuNjI4VjEzLjkxNkMxNS4yMDQgMTQuNzMyIDE0Ljc4NCAxNS4xNCAxMy45NjggMTUuMTRaTTE3LjA1MiA0LjUwOEgyMi41VjguODg4SDE3LjA1MlY0LjUwOFpNMjEuMjc2IDcuODhWNy4xNkgxOC4yNjRWNy44OEgyMS4yNzZaTTE4LjI2NCA2LjIyNEgyMS4yNzZWNS41MTZIMTguMjY0VjYuMjI0Wk0xNi4yODQgOS40NEgyMy4yMDhWMTAuNTU2SDIwLjM3NlYxMS41NTJIMjIuNjY4VjEyLjY1NkgyMC4zNzZWMTMuODJDMjAuODA4IDEzLjg2OCAyMS4zIDEzLjkwNCAyMS44NjQgMTMuOTA0QzIyLjUyNCAxMy45MDQgMjMuMDg4IDEzLjg2OCAyMy41NDQgMTMuODJMMjMuMTk2IDE1LjAzMkMyMi43NCAxNS4wMzIgMjIuMzIgMTUuMDIgMjEuOTQ4IDE1LjAwOEMyMC4zNCAxNC45OTYgMTkuMjQ4IDE0Ljg1MiAxOC42NDggMTQuNTY0QzE4LjI0IDE0LjM2IDE3Ljg4IDE0IDE3LjU0NCAxMy40ODRDMTcuMjggMTQuMTA4IDE2Ljk0NCAxNC42OTYgMTYuNTI0IDE1LjI0OEwxNS41ODggMTQuNDMyQzE2LjQyOCAxMy4zNzYgMTYuODk2IDEyLjIgMTYuOTkyIDEwLjkwNEwxOC4wOTYgMTEuMDM2QzE4LjA3MiAxMS40NjggMTguMDEyIDExLjg3NiAxNy45MjggMTIuMjZDMTguMjg4IDEyLjkwOCAxOC42ODQgMTMuMzI4IDE5LjE0IDEzLjUyQzE5LjE0IDEzLjUyIDE5LjE1MiAxMy41MzIgMTkuMTY0IDEzLjUzMlYxMC41NTZIMTYuMjg0VjkuNDRaTTI5LjMyOCAxNS4xMDRIMjcuNzhMMjcuNTE2IDEzLjg5MkMyNy45OTYgMTMuOTQgMjguNDY0IDEzLjk2NCAyOC44OTYgMTMuOTY0QzI5LjIyIDEzLjk2NCAyOS4zODggMTMuODA4IDI5LjM4OCAxMy41MDhWOC45MjRIMjQuODI4VjcuNjg4SDM1LjE3MlY4LjkyNEgzMC42NlYxMy44MzJDMzAuNjYgMTQuNjcyIDMwLjIxNiAxNS4xMDQgMjkuMzI4IDE1LjEwNFpNMjYuNTIgMTAuMDI4TDI3Ljc1NiAxMC4zMDRDMjcuMjc2IDExLjk2IDI2LjU4IDEzLjQgMjUuNjkyIDE0LjZMMjQuNiAxMy45MTZDMjUuNTEyIDEyLjY5MiAyNi4xNDggMTEuMzk2IDI2LjUyIDEwLjAyOFpNMzMuMjc2IDkuODcyQzM0LjA4IDExLjE1NiAzNC43NzYgMTIuNTI0IDM1LjM1MiAxMy45ODhMMzQuMjEyIDE0LjUwNEMzMy41ODggMTIuODk2IDMyLjg5MiAxMS40OCAzMi4xNDggMTAuMjU2TDMzLjI3NiA5Ljg3MlpNMjUuOTMyIDQuNjY0SDM0LjEwNFY1Ljg4OEgyNS45MzJWNC42NjRaIiBmaWxsPSJ3aGl0ZSIvPg0KPC9nPg0KPGRlZnM+DQo8Y2xpcFBhdGggaWQ9ImNsaXAwXzM4Nl85MzUiPg0KPHJlY3Qgd2lkdGg9IjQ4IiBoZWlnaHQ9IjIwIiBmaWxsPSJ3aGl0ZSIvPg0KPC9jbGlwUGF0aD4NCjwvZGVmcz4NCjwvc3ZnPg0K",
      3: "PHN2ZyB3aWR0aD0iNDgiIGhlaWdodD0iMjAiIHZpZXdCb3g9IjAgMCA0OCAyMCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxnIGNsaXAtcGF0aD0idXJsKCNjbGlwMF8zODZfOTUwKSI+DQo8cGF0aCBkPSJNNCAwSDQ0TDQ4IDVIMEw0IDBaIiBmaWxsPSIjOTY2QTE1Ii8+DQo8cGF0aCBkPSJNNCAwSDQ0VjE4QzQ0IDE5LjEwNDYgNDMuMTA0NiAyMCA0MiAyMEg2QzQuODk1NDMgMjAgNCAxOS4xMDQ2IDQgMThWMFoiIGZpbGw9IiNGRkFBMDUiLz4NCjxwYXRoIGQ9Ik0xMy42OTIgNy42MjhIMTcuMzUyVjcuMTEySDEyLjgwNFY2LjA1NkgxNy4zNTJWNS40OEMxNi4yMTIgNS41MjggMTUuMDI0IDUuNTc2IDEzLjc3NiA1LjYyNEwxMy41NzIgNC42MjhDMTYuNjggNC41NDQgMTkuNDUyIDQuMzg4IDIxLjg3NiA0LjE0OEwyMi4yNDggNS4xNTZDMjEuMTIgNS4yNTIgMTkuODk2IDUuMzM2IDE4LjYgNS40MDhWNi4wNTZIMjMuMTcyVjcuMTEySDE4LjZWNy42MjhIMjIuMjcyVjExLjgwNEgxOC42VjEyLjM2OEgyMi43NTJWMTMuMzUySDE4LjZWMTMuOTRIMjMuMzUyVjE1LjAwOEgxMi42NDhWMTMuOTRIMTcuMzUyVjEzLjM1MkgxMy4yNDhWMTIuMzY4SDE3LjM1MlYxMS44MDRIMTMuNjkyVjcuNjI4Wk0yMS4wNiAxMC44MlYxMC4xNzJIMTguNlYxMC44MkgyMS4wNlpNMTcuMzUyIDEwLjgyVjEwLjE3MkgxNC45MDRWMTAuODJIMTcuMzUyWk0xNC45MDQgOS4yMzZIMTcuMzUyVjguNjEySDE0LjkwNFY5LjIzNlpNMTguNiA4LjYxMlY5LjIzNkgyMS4wNlY4LjYxMkgxOC42Wk0yNC42NDggNC41MkgzNS4zNTJWNS42NDhIMzEuOTQ0VjYuNDRIMzQuNjQ0VjkuNjhIMjkuNzZMMjkuMzI4IDEwLjQzNkgzNS40OTZWMTEuNTg4SDMzLjAxMkMzMi43ODQgMTIuMTg4IDMyLjQxMiAxMi43MDQgMzEuOTA4IDEzLjE2QzMzLjAzNiAxMy40OTYgMzQuMTc2IDEzLjg4IDM1LjM1MiAxNC4zMjRMMzQuNTcyIDE1LjM1NkMzMy4zMTIgMTQuODI4IDMyLjA1MiAxNC4zNDggMzAuNzkyIDEzLjk0QzI5LjY2NCAxNC41MTYgMjcuODI4IDE0Ljk3MiAyNS4yNiAxNS4zMkwyNC43OTIgMTQuMTkyQzI2LjYxNiAxNCAyOC4wNDQgMTMuNzM2IDI5LjEgMTMuNDEyQzI4LjIgMTMuMTQ4IDI3LjMxMiAxMi45MiAyNi40MjQgMTIuNzE2QzI2LjY4OCAxMi4zMzIgMjYuOTQgMTEuOTYgMjcuMTggMTEuNTg4SDI0LjQ5MlYxMC40MzZIMjcuOUMyOC4wNDQgMTAuMTcyIDI4LjIgOS45MiAyOC4zNDQgOS42OEgyNS4zNTZWNi40NEgyOC4wNTZWNS42NDhIMjQuNjQ4VjQuNTJaTTMwLjU2NCAxMi43NzZDMzEuMDkyIDEyLjQ0IDMxLjQ3NiAxMi4wNDQgMzEuNzE2IDExLjU4OEgyOC42MkMyOC40NjQgMTEuODE2IDI4LjMyIDEyLjAyIDI4LjIgMTIuMjEyQzI4Ljk2OCAxMi4zNjggMjkuNzYgMTIuNTYgMzAuNTY0IDEyLjc3NlpNMzAuNzU2IDYuNDRWNS42NDhIMjkuMjQ0VjYuNDRIMzAuNzU2Wk0zMy40NDQgOC42MjRWNy40OTZIMzEuOTQ0VjguNjI0SDMzLjQ0NFpNMzAuNzU2IDguNjI0VjcuNDk2SDI5LjI0NFY4LjYyNEgzMC43NTZaTTI4LjA1NiA4LjYyNFY3LjQ5NkgyNi41NTZWOC42MjRIMjguMDU2WiIgZmlsbD0id2hpdGUiLz4NCjwvZz4NCjxkZWZzPg0KPGNsaXBQYXRoIGlkPSJjbGlwMF8zODZfOTUwIj4NCjxyZWN0IHdpZHRoPSI0OCIgaGVpZ2h0PSIyMCIgZmlsbD0id2hpdGUiLz4NCjwvY2xpcFBhdGg+DQo8L2RlZnM+DQo8L3N2Zz4NCg=="
    },
    show: !1,
    currentId: "",
    fileList: [],
    limit: 5,
    fileSize: 10,
    fileType: ["doc", "xls", "ppt", "txt", "pdf", "xlsx"],
    isShowTip: !0,
    isChoose: !1,
    reason: "",
    processingInstructions: "",
    unprocessedWarningCount: 0,
    currentOrderNumber: "",
    isIndex: !1
  },
  getWorkOrderList: function() {
    var M = arguments,
      N = this;
    return D(j.default.mark((function D() {
      var u, i, e, T, t;
      return j.default.wrap((function(j) {
        for (;;) switch (j.prev = j.next) {
          case 0:
            return u = M.length > 0 && void 0 !== M[0] ? M[0] : {}, i = {}, 0 != (e = u.orderStatus) && (i = I({}, u)), "orderContent" in u && (i.orderContent = u.orderContent), j.prev = 5, j.next = 8, (0, g.requestService)("/management/workOrder/list", i);
          case 8:
            T = j.sent, N.setData({
              warningCell: T.rows,
              status: e
            }), (t = T.total) != N.data.unprocessedWarningCount && (N.setData({
              unprocessedWarningCount: t
            }), wx.setTabBarBadge({
              index: 2,
              text: t > 0 ? t.toString() : ""
            })), j.next = 17;
            break;
          case 14:
            j.prev = 14, j.t0 = j.catch(5), console.error(j.t0);
          case 17:
          case "end":
            return j.stop()
        }
      }), D, null, [
        [5, 14]
      ])
    })))()
  },
  onStatusChange: function(M) {
    console.log(M);
    var N = M.detail;
    this.setData({
      status: N
    });
    var j = N;
    this.getWorkOrderList({
      orderStatus: j
    })
  },
  onChange: function(M) {
    this.setData({
      value: M.detail
    })
  },
  onSearch: function() {
    console.log("搜索关键词:", this.data.value), console.log("筛选状态:", this.data.status);
    var M = this.data.value,
      N = this.data.status;
    this.getWorkOrderList({
      orderContent: M,
      orderStatus: N
    })
  },
  dealWarning: function(M) {
    var N = M.currentTarget;
    console.log(N), this.setData({
      show: !0,
      currentId: N.dataset.id,
      currentOrderNumber: N.dataset.ordernumber
    })
  },
  onOverlayClick: function() {
    this.setData({
      show: !1
    })
  },
  afterRead: function(M) {
    var j = this,
      I = M.detail.file,
      D = I.name,
      g = I.size,
      i = I.url,
      e = this.data,
      T = e.fileType,
      t = e.fileSize,
      z = i;
    if (T.includes(D.split(".").pop()))
      if (g / 1024 / 1024 > t) wx.showToast({
        title: "上传文件大小不能超过 ".concat(t, " MB!"),
        icon: "none"
      });
      else {
        var L = {
          file: I
        };
        wx.uploadFile({
          url: "".concat(u.default.host, "/file/upload"),
          filePath: z,
          formData: L,
          name: "file",
          header: {
            Authorization: "Bearer ".concat(wx.getStorageSync("access_token"))
          },
          success: function(M) {
            var I = JSON.parse(M.data);
            200 === I.code ? (j.setData({
              fileList: [].concat(N(j.data.fileList), [{
                name: D,
                url: I.data.url
              }])
            }), console.log(j.data.fileList)) : wx.showToast({
              title: I.data.msg,
              icon: "none"
            })
          },
          fail: function() {
            wx.showToast({
              title: "上传文件失败，请重试",
              icon: "none"
            })
          }
        })
      }
    else wx.showToast({
      title: "文件格式不正确, 请上传".concat(T.join("/"), "格式文件!"),
      icon: "none"
    })
  },
  listToString: function(M, N) {
    var j = "";
    for (var I in N = N || ",", M) M[I].url && (j += M[I].url.replace(u.default.host, "") + N);
    return "" != j ? j.substr(0, j.length - 1) : ""
  },
  updateWorkOrder: function() {
    var M = this;
    return D(j.default.mark((function N() {
      var I, D, u, i, e, T, t, z;
      return j.default.wrap((function(N) {
        for (;;) switch (N.prev = N.next) {
          case 0:
            if (I = M.data, D = I.currentId, u = I.currentOrderNumber, i = I.reason, e = I.processingInstructions, T = I.fileList, i) {
              N.next = 4;
              break
            }
            return wx.showToast({
              title: "请输入预警原因",
              icon: "none"
            }), N.abrupt("return");
          case 4:
            if (e) {
              N.next = 7;
              break
            }
            return wx.showToast({
              title: "请输入处理说明",
              icon: "none"
            }), N.abrupt("return");
          case 7:
            if (T) {
              N.next = 10;
              break
            }
            return wx.showToast({
              title: "请上传附件",
              icon: "none"
            }), N.abrupt("return");
          case 10:
            return t = M.listToString(T), z = {
              id: D,
              orderNumber: u,
              warningReason: i,
              processDescription: e,
              attachment: t,
              orderStatus: "2"
            }, console.log(z), N.prev = 13, N.next = 16, (0, g.requestService)("/management/workOrder", z, "put");
          case 16:
            N.sent, wx.showToast({
              title: "处理成功",
              icon: "success"
            }), M.getWorkOrderList({
              orderStatus: 1
            }), M.resetForm(), N.next = 26;
            break;
          case 22:
            N.prev = 22, N.t0 = N.catch(13), console.error(N.t0), M.resetForm();
          case 26:
          case "end":
            return N.stop()
        }
      }), N, null, [
        [13, 22]
      ])
    })))()
  },
  resetForm: function() {
    this.setData({
      show: !1,
      reason: "",
      processingInstructions: "",
      fileList: []
    })
  },
  handleDelete: function(M) {
    var N = M.detail.index;
    console.log(N);
    var j = this.data.fileList.filter((function(M, j) {
      return j !== N
    }));
    this.setData({
      fileList: j
    })
  },
  getWarningDetail: function(M) {
    var N = M.currentTarget,
      j = N.dataset.id;
    console.log(N.dataset.id), wx.navigateTo({
      url: "/warningPackage/pages/warningDetails/warningDetails",
      success: function(M) {
        M.eventChannel.emit("warning-data", {
          data: {
            searchId: j
          }
        })
      }
    })
  },
  getPageInfo: function() {
    this.data.isIndex && this.setData({
      isIndex: !1
    })
  },
  onLoad: function(M) {
    this.setData({
      isIndex: M.isIndex || !1,
      toptarHeight: i.globalData.toptarHeight
    })
  },
  onReady: function() {},
  onShow: function() {
    this.getWorkOrderList({
      orderStatus: this.data.status
    })
  },
  onHide: function() {
    this.getPageInfo()
  },
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {}
});