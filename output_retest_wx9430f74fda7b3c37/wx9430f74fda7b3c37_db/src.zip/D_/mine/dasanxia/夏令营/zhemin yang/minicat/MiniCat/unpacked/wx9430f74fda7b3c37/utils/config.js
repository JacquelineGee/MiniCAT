Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.default = void 0;
exports.default = {
  host: "https://jhy.miup.fun:8226/prod-api"
};