var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")),
  n = require("../../@babel/runtime/helpers/asyncToGenerator"),
  r = require("../../utils/request");
Page({
  data: {
    username: "admin",
    password: "admin123"
  },
  login: function() {
    var t = this;
    return n(e.default.mark((function n() {
      var a, o, s, u;
      return e.default.wrap((function(e) {
        for (;;) switch (e.prev = e.next) {
          case 0:
            if (a = t.data, o = a.username, s = a.password, o) {
              e.next = 4;
              break
            }
            return wx.showToast({
              title: "用户名不能为空",
              icon: "none"
            }), e.abrupt("return");
          case 4:
            if (s) {
              e.next = 7;
              break
            }
            return wx.showToast({
              title: "密码不能为空",
              icon: "none"
            }), e.abrupt("return");
          case 7:
            return e.prev = 7, e.next = 10, (0, r.requestService)("/auth/login", {
              username: o,
              password: s
            }, "post", {
              isToken: !1
            });
          case 10:
            u = e.sent, wx.setStorageSync("access_token", u.access_token), wx.reLaunch({
              url: "/pages/index/index"
            }), e.next = 18;
            break;
          case 15:
            e.prev = 15, e.t0 = e.catch(7), console.error(e.t0);
          case 18:
          case "end":
            return e.stop()
        }
      }), n, null, [
        [7, 15]
      ])
    })))()
  },
  onLoad: function(e) {},
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {}
});