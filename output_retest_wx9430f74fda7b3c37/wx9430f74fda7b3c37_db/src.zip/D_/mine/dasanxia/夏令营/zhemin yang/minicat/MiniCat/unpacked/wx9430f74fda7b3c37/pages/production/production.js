var t = require("../../@babel/runtime/helpers/interopRequireWildcard"),
  e = require("../../@babel/runtime/helpers/interopRequireDefault"),
  a = require("../../@babel/runtime/helpers/objectSpread2"),
  i = e(require("../../@babel/runtime/regenerator")),
  n = require("../../@babel/runtime/helpers/asyncToGenerator"),
  r = require("../../@babel/runtime/helpers/slicedToArray"),
  o = require("../../utils/request"),
  s = require("../../utils/util"),
  l = t(require("../../components/ec-canvas/echarts")),
  c = getApp();
Page({
  data: {
    date: "",
    show: !1,
    toptarHeight: 0,
    defaultDate: [],
    minDate: new Date((new Date).getFullYear() - 1, 0, 1).getTime(),
    maxDate: (new Date).getTime(),
    fuelChart: {
      lazyLoad: !0
    },
    commonOption: {
      grid: [{
        containLabel: !0,
        top: "10%",
        right: "5%",
        height: "40%",
        left: "5%"
      }, {
        containLabel: !0,
        top: "60%",
        right: "5%",
        height: "40%",
        left: "5%"
      }],
      yAxis: {
        nameTextStyle: {
          show: !1,
          color: "rgba(0, 0, 0, 1)",
          fontFamily: "Microsoft YaHei",
          fontWeight: "600",
          fontSize: 12
        },
        axisLabel: {
          color: "#09163733",
          fontSize: ".75rem"
        },
        splitLine: {
          lineStyle: {
            color: "rgba(223, 223, 223, 1)",
            type: "dashed"
          }
        }
      }
    },
    showRows: 20,
    stripe: !0,
    borderline: !1,
    headerbg: "#F6F6F6",
    columnNames: ["日期", "机组", "入炉煤消耗量t", "供热量t", "供热热量GJ", "发电量万KWh"],
    tableData: [],
    detailData: [],
    chartData: {},
    panelDataMap: {
      heatDate: "日期",
      unit: "机组",
      coalConsumption: "耗煤量",
      heatSupply: "供热量",
      heatQuantity: "供热热量",
      electricityGeneration: "发电量"
    },
    tableTh: []
  },
  onDisplay: function() {
    this.setData({
      show: !0
    })
  },
  onClose: function() {
    this.setData({
      show: !1
    })
  },
  formatDate: function(t) {
    return t = new Date(t), "".concat(t.getMonth() + 1, "/").concat(t.getDate())
  },
  valueFormat: function(t) {
    return t = new Date(t), "".concat(t.getFullYear(), "-").concat(t.getMonth() + 1, "-").concat(t.getDate())
  },
  onConfirm: function(t) {
    var e = r(t.detail, 2),
      a = e[0],
      i = e[1];
    this.setData({
      show: !1,
      date: "".concat(this.formatDate(a), " - ").concat(this.formatDate(i))
    }), console.log("enter"), this.getEmissionHourList(a, i), this.loadInitialData(a, i)
  },
  setDefaultdate: function() {
    var t = this;
    return n(i.default.mark((function e() {
      var a, n;
      return i.default.wrap((function(e) {
        for (;;) switch (e.prev = e.next) {
          case 0:
            a = new Date, n = new Date(a.getTime() - 6048e5).getTime(), t.setData({
              date: "".concat(t.formatDate(n), " - ").concat(t.formatDate(t.data.maxDate)),
              defaultDate: [n, t.data.maxDate]
            });
          case 3:
          case "end":
            return e.stop()
        }
      }), e)
    })))()
  },
  setDefaultdata: function() {
    var t = this.data.defaultDate[0],
      e = this.data.defaultDate[1];
    this.getEmissionHourList(t, e), this.loadInitialData(t, e)
  },
  getEmissionHourList: function(t, e) {
    var a = this;
    return n(i.default.mark((function n() {
      var r, s, l, c, u, h;
      return i.default.wrap((function(i) {
        for (;;) switch (i.prev = i.next) {
          case 0:
            return (r = {}).startDate = a.valueFormat(t), r.endDate = a.valueFormat(e), i.prev = 3, i.next = 6, (0, o.requestService)("/management/app/product/getStatistic", r);
          case 6:
            s = i.sent, l = [], c = [], u = [], h = [], s.forEach((function(t) {
              l.push(t.heatDate), c.push(t.coalConsumption), u.push(t.electricityGeneration), h.push(t.heatSupply)
            })), a.setData({
              chartData: {
                date: l,
                coalConsumption: c,
                heatSupply: h,
                electricityGeneration: u
              }
            }), a.initFuelChart(), wx.hideLoading(), i.next = 20;
            break;
          case 17:
            i.prev = 17, i.t0 = i.catch(3), console.error(i.t0);
          case 20:
          case "end":
            return i.stop()
        }
      }), n, null, [
        [3, 17]
      ])
    })))()
  },
  initFuelChart: function() {
    var t = this;
    this.selectComponent("#fuelChart").init((function(e, a, i, n, r) {
      var o = l.init(e, null, {
        width: a,
        height: i,
        devicePixelRatio: r
      });
      e.setChart(o);
      var s = t.getBarChartOption(t.data.chartData);
      return o.setOption(s), o.dispatchAction({
        type: "updateAxisPointer",
        currTrigger: "leave"
      }), o
    }))
  },
  getBarChartOption: function(t) {
    var e = t.date,
      i = t.coalConsumption,
      n = t.heatSupply,
      r = t.electricityGeneration,
      o = this.data.commonOption.yAxis,
      c = o.axisLabel,
      u = o.splitLine,
      h = o.nameTextStyle;
    return console.log(n), {
      grid: this.data.commonOption.grid,
      tooltip: {
        trigger: "axis",
        axisPointer: {
          type: "cross"
        },
        borderWidth: .5,
        borderRadius: 5,
        borderColor: "#ccc",
        padding: 10,
        textStyle: {
          color: "#6B7387",
          fontSize: "0.875rem",
          fontFamily: "PingFang Sc"
        }
      },
      axisPointer: {
        link: {
          xAxisIndex: "all"
        },
        label: {
          backgroundColor: "#777"
        }
      },
      xAxis: [{
        gridIndex: 0,
        type: "category",
        data: e,
        axisTick: {
          show: !1
        },
        axisLine: {
          show: !0,
          lineStyle: {
            color: "#E5E6EB"
          }
        },
        axisLabel: {
          color: "#09163733",
          fontSize: ".75rem"
        }
      }, {
        gridIndex: 1,
        type: "category",
        data: e,
        axisTick: {
          show: !1
        },
        axisLine: {
          show: !0,
          lineStyle: {
            color: "#E5E6EB"
          }
        },
        axisLabel: {
          color: "#09163733",
          fontSize: ".75rem"
        }
      }],
      yAxis: [{
        gridIndex: 0,
        type: "value",
        name: "用煤量(t)",
        min: 0,
        axisLabel: c,
        splitLine: u,
        nameTextStyle: h
      }, {
        gridIndex: 1,
        type: "value",
        name: "发电量(MWh)",
        position: "right",
        axisTick: {
          alignWithLabel: !0
        },
        splitLine: {
          show: !1
        },
        axisLabel: c,
        nameTextStyle: a({}, h)
      }, {
        gridIndex: 1,
        type: "value",
        name: "供热量(t)",
        position: "left",
        axisTick: {
          alignWithLabel: !0
        },
        splitLine: u,
        axisLabel: c,
        nameTextStyle: a({
          padding: [0, 0, 0, 0]
        }, h)
      }],
      series: [{
        xAxisIndex: 0,
        yAxisIndex: 0,
        name: "用煤量(t)",
        type: "bar",
        barMaxWidth: 20,
        itemStyle: {
          color: new l.graphic.LinearGradient(0, 0, 0, 1, [{
            offset: 0,
            color: "#64A2F8"
          }, {
            offset: 1,
            color: "#3772E9"
          }]),
          borderRadius: [10, 10, 0, 0]
        },
        data: i
      }, {
        name: "发电量(MWh)",
        xAxisIndex: 1,
        yAxisIndex: 1,
        type: "line",
        data: (0, s.interpolationData)(r)
      }, {
        name: "供热量(t)",
        xAxisIndex: 1,
        yAxisIndex: 2,
        type: "line",
        data: n
      }]
    }
  },
  loadInitialData: function(t, e) {
    var a = this;
    return n(i.default.mark((function n() {
      var r, s, l, c;
      return i.default.wrap((function(i) {
        for (;;) switch (i.prev = i.next) {
          case 0:
            return (r = {}).startDate = a.valueFormat(t), r.endDate = a.valueFormat(e), i.prev = 3, i.next = 6, (0, o.requestService)("/management/app/product/getList", r);
          case 6:
            s = i.sent, l = [], c = [], [], Object.keys(s[0]).map((function(t) {
              c.push(a.data.panelDataMap[t])
            })), s.forEach((function(t) {
              var e = t.heatDate,
                a = t.unit,
                i = t.coalConsumption,
                n = t.heatSupply,
                r = t.heatQuantity,
                o = t.electricityGeneration;
              l.push([e, a, i, n, r, o])
            })), a.setData({
              tableTh: c,
              detailData: l,
              tableData: l.slice(0, 20)
            }), i.next = 19;
            break;
          case 16:
            i.prev = 16, i.t0 = i.catch(3), console.error(i.t0);
          case 19:
          case "end":
            return i.stop()
        }
      }), n, null, [
        [3, 16]
      ])
    })))()
  },
  mergeData: function(t) {
    var e = [],
      i = "";
    return t.forEach((function(t, n) {
      t.date !== i ? (e.push(a(a({}, t), {}, {
        rowspan: 1
      })), i = t.date) : e[e.length - 1].rowspan++
    })), e
  },
  loadMore: function() {
    this.setData({
      tableData: this.data.detailData
    })
  },
  onLoad: function(t) {
    wx.showLoading({
      title: "加载中..."
    }), this.setData({
      toptarHeight: c.globalData.toptarHeight
    }), this.setDefaultdate()
  },
  onReady: function() {
    this.setDefaultdata()
  },
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {}
});