var t = (0, require("../../../@babel/runtime/helpers/interopRequireDefault").default)(require("../../../utils/myfunc.js")),
  n = require("../../../apiconfig");
Page({
  data: {
    id: "",
    infolb: "",
    infolb2: "",
    unitname: "",
    infocontent: "",
    length: ""
  },
  onLoad: function(n) {
    console.log("options", n);
    var e = n.infolb,
      i = n.id,
      a = "";
    "staffs" == e && (a = "1.员工情况"), "menbers" == e && (a = "2.客户情况"), "achieve" == e && (a = "3.业绩情况"), this.setData({
      id: i,
      infolb: e,
      infolb2: a
    });
    var o = this;
    t.default.getInfo("d_unit", i).then((function(t) {
      o.setData({
        infocontent: t.data[e],
        unitname: t.data.unitname
      })
    }))
  },
  noteChange: function(t) {
    var n = t.detail.value.length;
    this.setData({
      length: n,
      infocontent: t.detail.value
    })
  },
  saveInfoN: function() {
    var e = {
      id: this.data.id,
      infolb: this.data.infolb,
      infocontent: this.data.infocontent
    };
    t.default.Post(n.dataApi + "unit/infoN_edit", e, (function(t) {
      if (200 == t.code) {
        var n = getCurrentPages(),
          e = n[n.length - 2];
        e.getInfo && "function" == typeof e.getInfo && e.getInfo(), wx.showModal({
          title: "系统提示",
          content: t.msg,
          success: function() {
            wx.navigateBack({
              detal: 1
            })
          }
        })
      } else wx.showToast({
        title: t.msg,
        icon: "none"
      })
    }))
  }
});