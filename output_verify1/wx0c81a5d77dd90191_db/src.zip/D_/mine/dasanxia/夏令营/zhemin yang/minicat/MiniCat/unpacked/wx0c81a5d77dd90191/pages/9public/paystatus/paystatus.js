Page({
  goback: function() {
    wx.navigateBack({
      delta: 3
    })
  },
  data: {
    pay_title: "",
    pay_icon: ""
  },
  onLoad: function(a) {
    var t = a.status,
      s = "支付失败！",
      i = "/images/flag/pay_success.svg";
    "1" == t ? s = "支付成功！" : "2" == t ? s = "团购成功！" : i = "/images/flag/pay_fail.svg", this.setData({
      pay_title: s,
      pay_icon: i
    })
  }
});