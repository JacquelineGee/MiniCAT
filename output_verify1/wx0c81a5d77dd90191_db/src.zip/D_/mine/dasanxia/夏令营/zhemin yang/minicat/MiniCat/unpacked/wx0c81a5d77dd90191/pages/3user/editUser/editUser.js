var t = require("../../../@babel/runtime/helpers/interopRequireDefault").default,
  e = require("../../../@babel/runtime/helpers/defineProperty"),
  i = t(require("../../../apiconfig")),
  a = require("../../../utils/myfunc.js");
Page({
  data: {
    userInfo: {},
    editInfo: {}
  },
  onLoad: function(t) {
    this.getmyinfo(), this.setData({
      userInfo: a.userInfo()
    })
  },
  getmyinfo: function() {
    var t = this;
    a.Post(i.default.dataApi + "staff/my_info", {}, (function(e) {
      200 == e.code && (null == e.data ? wx.showToast({
        title: "您不是本公司员工！",
        icon: "none",
        duration: 1600
      }) : t.setData({
        editInfo: e.data
      }))
    }))
  },
  saveEdit: function(t) {
    if (0 == a.inputCheck(this.data.editInfo.id, "number")) return a.showTip("您不是该公司员工！"), !1;
    if (0 == a.inputCheck(this.data.editInfo.staff, "char")) return a.showTip("请输入姓名！"), !1;
    var e = this.data.editInfo;
    wx.showLoading({
      title: "保存中",
      mask: "true"
    }), a.Post(i.default.dataApi + "staff/staff_edit", e, (function(t) {
      wx.hideLoading(), 200 == t.code ? wx.showModal({
        title: "系统提示",
        content: "保存成功！",
        success: function(t) {
          wx.navigateBack({
            delta: 1
          })
        }
      }) : wx.showToast({
        title: t.msg,
        icon: "error"
      })
    }))
  },
  inputChange: function(t) {
    var i = t.currentTarget.dataset.key;
    this.setData(e({}, i, t.detail.value))
  }
});