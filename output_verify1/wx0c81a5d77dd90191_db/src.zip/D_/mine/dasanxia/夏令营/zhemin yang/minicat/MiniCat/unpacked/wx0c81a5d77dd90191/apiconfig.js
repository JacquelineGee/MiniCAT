var i = "https://serve1.meiyiy.cn",
  t = {
    host: "https://meiyiy.cn",
    dataApi: i + "/myj_",
    loginApi: i + "/myj_loginwx/bjl_",
    resupApi: "https://resup.meiyiy.cn/"
  };
module.exports = t;