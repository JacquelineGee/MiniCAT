var e = (0, require("../../../@babel/runtime/helpers/interopRequireDefault").default)(require("../../../apiconfig")),
  t = (getApp(), require("../../../utils/myfunc.js"));
Page({
  data: {
    userInfo: {}
  },
  onLoad: function(e) {
    this.setData({
      userInfo: t.userInfo()
    })
  },
  toapply: function(a) {
    if (a.detail.value.unitname.length < 2) return wx.showModal({
      title: "提示！！",
      content: "请输入美容院名称。"
    }), !1;
    if (a.detail.value.address.length < 2) return wx.showToast({
      title: "请输入美容院地址!",
      icon: "none",
      duration: 1600
    }), !1;
    if (a.detail.value.contact.length < 2) return wx.showToast({
      title: "请输入联系人!",
      icon: "none",
      duration: 1600
    }), !1;
    if (a.detail.value.mobile.length < 2) return wx.showToast({
      title: "请输入联系电话!",
      icon: "none",
      duration: 1600
    }), !1;
    var n = {
      request: "addunit",
      token: this.data.userInfo.token,
      unitname: a.detail.value.unitname,
      contact: a.detail.value.contact,
      mobile: a.detail.value.mobile,
      address: a.detail.value.address,
      yourid1: this.data.userInfo.yourid1
    };
    t.Post(e.default.dataApi + "user/addmyapply", n, (function(e) {
      console.log("res", e), 200 == e.code ? wx.showModal({
        title: "系统提示",
        content: "保存成功！",
        success: function(e) {
          wx.navigateBack({
            delta: 2
          })
        }
      }) : wx.showModal({
        title: "系统提示",
        content: e.msg
      })
    }))
  }
});