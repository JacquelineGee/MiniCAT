var t = require("../../../@babel/runtime/helpers/interopRequireDefault").default,
  e = require("../../../@babel/runtime/helpers/defineProperty"),
  n = t(require("../../../utils/myfunc.js")),
  i = require("../../../apiconfig");
Page({
  data: {
    editInfo: ""
  },
  onLoad: function(t) {
    console.log("page:", "1work/unit/unitevent_edit");
    var e = this;
    n.default.getInfo("e_event", t.id).then((function(t) {
      e.setData({
        editInfo: t.data,
        length: t.data.note.length
      })
    }))
  },
  saveEvent: function() {
    var t = {
      token: n.default.userInfo().token,
      id: this.data.editInfo.id,
      note: this.data.editInfo.note
    };
    n.default.Post(i.dataApi + "event/event_edit", t, (function(t) {
      if (200 == t.code) {
        var e = getCurrentPages(),
          n = e[e.length - 2];
        n.getEventList && "function" == typeof n.getEventList && n.getEventList(), n.getCidjournalList && "function" == typeof n.getCidjournalList && n.getCidjournalList(), wx.showModal({
          title: "系统提示",
          content: t.msg,
          success: function() {
            wx.navigateBack({
              detal: 1
            })
          }
        })
      } else wx.showToast({
        title: t.msg,
        icon: "none"
      })
    }))
  },
  inputChange: function(t) {
    var n = t.currentTarget.dataset.item;
    this.setData(e({}, n, t.detail.value)), "editInfo.note" == n && this.setData({
      length: t.detail.value.length
    })
  }
});