var e = require("../../../apiconfig"),
  t = require("../../../utils/myfunc.js"),
  a = require("../../../utils/util");
Page({
  inputValue: "",
  data: {
    info: {},
    id: "",
    playtime: "",
    progress: 0,
    time: "",
    state_play: !1
  },
  onLoad: function(e) {
    var i = t.userInfo(),
      o = 0;
    if (i.avatar && i.avatar.length > 64 && (o = 1), this.setData({
        userInfo: i,
        state_avatar: o
      }), e.id) {
      var s = a.formatTimeMine(new Date);
      console.log("start_time", s), this.setData({
        id: e.id,
        start_date: s
      }), this.getVideoInfo(e.id)
    }
  },
  onReady: function(e) {
    this.videoContext = wx.createVideoContext("myVideo")
  },
  getVideoInfo: function(a) {
    var i = this,
      o = {
        id: a,
        token: this.data.userInfo.token
      };
    t.Post(e.dataApi + "help/videoinfo", o, (function(e) {
      if (200 == e.code) {
        var t = e.data;
        console.log("info", t), i.setData({
          info: t
        })
      }
    }))
  },
  saveshare: function(a) {
    var i = {
      token: this.data.userInfo.token,
      videoid: a
    };
    t.Post(e.dataApi + "help/saveshare", i, (function(e) {
      200 == e.code && console.log("res.msg", e.msg)
    }))
  },
  saveplayinfo: function() {
    var a = {
      token: this.data.userInfo.token,
      referid: this.data.userInfo.referid,
      videoid: this.data.id,
      playtime: this.data.start_date,
      progress: this.data.progress,
      time: this.data.time
    };
    t.Post(e.dataApi + "vwatch/saveplayinfo", a, (function(e) {
      200 == e.code && console.log("res.msg", e.msg)
    }))
  },
  timeUpdate: function(e) {
    var t = e.detail;
    if (t.duration) {
      var a = t.currentTime / t.duration;
      this.setData({
        progress: a,
        time: t.currentTime
      })
    }
  },
  videoPlay: function() {
    if (0 == this.data.state_avatar) return this.getUserProfile(), !1;
    var e = wx.createVideoContext("myVideo");
    0 == this.data.state_play ? (console.log("开始播放"), e.play(), e.requestFullScreen(), this.setData({
      state_play: !0
    })) : (console.log("暂停播放"), e.pause(), this.setData({
      state_play: !1
    }))
  },
  getUserProfile: function() {
    console.log("hello?");
    var a = this;
    wx.getUserProfile({
      desc: "头像展示",
      success: function(i) {
        console.log("profile", i.userInfo), wx.request({
          url: e.dataApi + "login/getprofilebyCode",
          method: "POST",
          header: {
            "Content-Type": "application/x-www-form-urlencoded"
          },
          data: {
            nickname: i.userInfo.nickName,
            avatar: i.userInfo.avatarUrl,
            gender: i.userInfo.gender,
            unitid: t.userInfo().unitid,
            wx_id: t.userInfo().wx_id
          },
          success: function(e) {
            200 == e.data.code ? (getApp().globalData.userInfo = e.data.data, wx.setStorageSync("userInfo", e.data.data), a.setData({
              state_avatar: 1
            })) : console.log(e.data.data)
          }
        })
      }
    })
  },
  onUnload: function() {
    this.data.progress > 0 && this.saveplayinfo()
  },
  onShareAppMessage: function() {
    var e = this.data.info,
      t = this.data.userInfo.unitid,
      a = this.data.userInfo.wx_id;
    return this.saveshare(e.id), {
      title: e.video,
      desc: e.videolb,
      path: "/pages/3user/user?unitid=" + t + "&wx_id=" + a + "&page=helpvideo&id=" + e.id,
      imageUrl: e.coverurl
    }
  }
});