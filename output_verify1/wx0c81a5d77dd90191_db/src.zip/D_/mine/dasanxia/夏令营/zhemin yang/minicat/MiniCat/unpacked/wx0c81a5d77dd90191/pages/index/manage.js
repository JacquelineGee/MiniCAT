var e = (0, require("../../@babel/runtime/helpers/interopRequireDefault").default)(require("../../utils/myfunc.js"));
Page({
  data: {
    userInfo: {},
    multiple: 0,
    checkList: [{
      icon: "/images/icon/house.svg",
      title: "店家管理",
      code: 1,
      url: "/pages/1unit/unita/unit_list"
    }, {
      icon: "/images/icon/mycust.svg",
      title: "客户管理",
      url: "/pages/2customer/customer/customerb_list",
      code: 2
    }, {
      icon: "/images/icon/daily.svg",
      title: "部门每日",
      url: "/pages/6summary/daily/dailyb_index",
      code: 3
    }, {
      icon: "/images/icon/month.svg",
      title: "部门月度",
      url: "/pages/6summary/month/monthb_index",
      code: 4
    }],
    achieveList: [{
      icon: "/images/icon/dailyc.svg",
      title: "每日汇总",
      url: "/pages/6summary/daily/dailyc_index",
      code: 11
    }, {
      icon: "/images/icon/monthc.svg",
      title: "月度汇总",
      url: "/pages/6summary/month/monthc_index",
      code: 12
    }, {
      icon: "/images/icon/dailyc.svg",
      title: "专家每日",
      url: "/pages/6summary/daily/dailyp_index",
      code: 13
    }, {
      icon: "/images/icon/monthc.svg",
      title: "专家月度",
      url: "/pages/6summary/month/monthp_index",
      code: 14
    }, {
      icon: "/images/icon/album1.svg",
      title: "顾客相册",
      url: "/pages/2customer/album/groupalbum_list",
      code: 15
    }]
  },
  itermCLick: function(i) {
    var t = e.default.userInfo();
    if ("Y" == t.power.weixin1 && null != t.power.weixin1) {
      var a = i.currentTarget.dataset.url;
      wx.navigateTo({
        url: a
      })
    } else wx.showToast({
      title: "您没有管理员权限！",
      icon: "none",
      duration: 1500
    })
  },
  onLoad: function(e) {
    var i = Math.trunc((this.data.checkList.length - 1) / 4);
    this.setData({
      multiple: i
    })
  }
});