var e = require("../../../@babel/runtime/helpers/interopRequireDefault").default,
  t = require("../../../@babel/runtime/helpers/defineProperty"),
  a = e(require("../../../utils/myfunc.js")),
  n = require("../../../apiconfig");
Page({
  data: {
    editInfo: "",
    length: ""
  },
  onLoad: function(e) {
    console.log("note_options", e);
    var t = JSON.parse(e.info),
      a = 0;
    t.note && (a = t.note.length), this.setData({
      editInfo: t,
      length: a
    })
  },
  saveInfoN: function() {
    var e = this.data.editInfo;
    a.default.Post(n.dataApi + "datas/keyword_edit", e, (function(e) {
      if (200 == e.code) {
        var t = getCurrentPages(),
          n = t[t.length - 2];
        n.getDatalist && "function" == typeof n.getDatalist && n.getDatalist(), wx.showModal({
          title: "系统提示",
          content: e.msg,
          showCancel: !1,
          success: function() {
            wx.navigateBack({
              detal: 1
            })
          }
        })
      } else a.default.showTip("保存失败！")
    }))
  },
  inputChange: function(e) {
    var a = e.currentTarget.dataset.key;
    this.setData(t(t({}, a, e.detail.value), "length", e.detail.value.length))
  }
});