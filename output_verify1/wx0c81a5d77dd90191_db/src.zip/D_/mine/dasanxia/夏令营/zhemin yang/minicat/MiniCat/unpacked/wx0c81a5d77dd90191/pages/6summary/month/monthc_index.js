var e = require("../../../@babel/runtime/helpers/defineProperty"),
  t = require("../../../apiconfig"),
  a = require("../../../utils/myfunc.js");
Page({
  data: {
    navList: [{
      title: "总结概况",
      index: "1"
    }, {
      title: "见诊记录",
      index: "2"
    }, {
      title: "销售记录",
      index: "3"
    }],
    cIndex: 1,
    thList: [{
      width: 120,
      orderid: 1,
      orderlb: "byChar",
      thname: "员工",
      field: "staff"
    }, {
      width: 100,
      orderid: 2,
      orderlb: "byNum",
      thname: "客数",
      field: "custnum"
    }, {
      width: 150,
      orderid: 3,
      orderlb: "byNum",
      thname: "成交",
      field: "tprice"
    }, {
      width: 140,
      orderid: 4,
      orderlb: "byNum",
      thname: "收款",
      field: "receive"
    }, {
      width: 120,
      orderid: 5,
      orderlb: "byNum",
      thname: "初/复",
      field: "zhena"
    }, {
      width: 120,
      orderid: 7,
      orderlb: "byNum",
      thname: "专/平",
      field: "zhenb"
    }],
    thList2: [{
      width: 120,
      orderid: 1,
      orderlb: "byChar",
      thname: "员工",
      field: "staff"
    }, {
      width: 200,
      orderid: 2,
      orderlb: "byChar",
      thname: "美容院",
      field: "unitname"
    }, {
      width: 150,
      orderid: 3,
      orderlb: "byChar",
      thname: "客户",
      field: "name"
    }, {
      width: 120,
      orderid: 4,
      orderlb: "byNum",
      thname: "成交",
      field: "price1"
    }, {
      width: 160,
      orderid: 5,
      orderlb: "byDate",
      thname: "日期",
      field: "date"
    }],
    thList3: [{
      width: 120,
      orderid: 1,
      orderlb: "byChar",
      thname: "员工",
      field: "staff"
    }, {
      width: 200,
      orderid: 2,
      orderlb: "byChar",
      thname: "美容院",
      field: "unitname"
    }, {
      width: 150,
      orderid: 3,
      orderlb: "byChar",
      thname: "产品",
      field: "product"
    }, {
      width: 120,
      orderid: 4,
      orderlb: "byNum",
      thname: "金额",
      field: "tprice"
    }, {
      width: 160,
      orderid: 5,
      orderlb: "byDate",
      thname: "日期",
      field: "date"
    }],
    thList4: [{
      width: 120,
      orderid: 1,
      orderlb: "byChar",
      thname: "员工",
      field: "staff"
    }, {
      width: 200,
      orderid: 2,
      orderlb: "byChar",
      thname: "美容院",
      field: "unitname"
    }, {
      width: 150,
      orderid: 3,
      orderlb: "byChar",
      thname: "客户",
      field: "name"
    }, {
      width: 120,
      orderid: 4,
      orderlb: "byNum",
      thname: "收款",
      field: "receive"
    }, {
      width: 160,
      orderid: 5,
      orderlb: "byDate",
      thname: "日期",
      field: "date"
    }],
    btnList: "",
    where: {
      date: "",
      depart: "-部门-",
      departid: ""
    },
    pickList: [],
    saleList: "",
    journalList: "",
    receiveList: ""
  },
  onLoad: function(t) {
    console.log("page:", "6summary/month/monthb_index");
    for (var r = [], i = 0, n = -2; n <= 0; n++) {
      var d = a.getMonthdate(n + 1),
        h = new Date(d[0]).getMonth() + 1 + "月";
      0 == n && (h = "本月"), r[i] = {
        index: d[0],
        btnname: h
      }, i++
    }
    var f = a.getMonthdate(1)[0];
    this.setData(e({
      btnList: r
    }, "where.date", f)), this.getDatalist()
  },
  DateChange: function(t) {
    var a = t.detail.value;
    this.setData(e({}, "where.date", a)), this.getDatalist()
  },
  clickBtn: function(t) {
    var a = t.currentTarget.dataset.index;
    this.setData(e(e({}, "where.date", a), "cIndex", 1)), this.getDatalist()
  },
  clickTab: function(e) {
    var t = e.detail.data.index,
      a = "",
      r = [],
      i = [];
    if (t > 1) {
      var n = this.data.navList.filter((function(e) {
        return e.index == t
      }))[0];
      a = n.title;
      var d = this.data.staffData.filter((function(e) {
        return e.depart == a
      }));
      r = this.data.departData.filter((function(e) {
        return e.depart == a
      }))[0];
      var h = this.data.departmonthList.filter((function(e) {
        return e.depart == a
      }));
      h.length > 0 && (i = h[0])
    }
    this.setData({
      cIndex: t,
      depart: a,
      indexList: d,
      subTotal: r,
      summary: i
    })
  },
  getDatalist: function() {
    var e = this,
      r = {
        date: this.data.where.date
      };
    a.Post(t.dataApi + "summary/groupmonth_start", r, (function(t) {
      if (200 == t.code) {
        var a, r = t.data.dailyList,
          i = t.data.journalList,
          n = t.data.miaoshaList,
          d = t.data.receiveList,
          h = t.data.staffList,
          f = [],
          c = 0,
          s = [];
        if (h.length > 0 && (h.forEach((function(e) {
            f.push({
              id: c,
              staff: e.staff,
              departid: e.departid,
              custnum: 0,
              zhen1: 0,
              zhena1: 0,
              zhen2: 0,
              zhena2: 0,
              zhen3: 0,
              zhena3: 0,
              zhen4: 0,
              zhena4: 0,
              tprice1: 0,
              tprice2: 0,
              tprice3: 0,
              tprice4: 0,
              tprice: 0,
              receive1: 0,
              receive2: 0,
              receive: 0,
              miaosha: 0
            }), c += 1
          })), s = h.map((function(e) {
            return e.staff
          }))), i.length > 0) {
          var o = {};
          i.forEach((function(e) {
            o[e.staff] = o[e.staff] || [], o[e.staff].push(e)
          })), s.forEach((function(e) {
            null == o[e] && (o[e] = [])
          })), s.forEach((function(e) {
            var t = 0,
              a = 0,
              r = 0,
              i = 0,
              n = 0,
              d = 0,
              h = 0,
              c = 0,
              s = 0,
              l = 0,
              u = 0,
              p = 0,
              m = 0;
            o[e].forEach((function(e) {
              t += 1, 1 * e.price1, 1 == e.zhena && 1 == e.zhenb && (a += 1, l += 1 * e.price1, e.price1 > 0 && (d += 1)), 1 == e.zhena && 0 == e.zhenb && (r += 1, u += 1 * e.price1, e.price1 > 0 && (h += 1)), 0 == e.zhena && 1 == e.zhenb && (i += 1, p += 1 * e.price1, e.price1 > 0 && (c += 1)), 0 == e.zhena && 0 == e.zhenb && (n += 1, m += 1 * e.price1, e.price1 > 0 && (s += 1))
            }));
            var b = f.indexOf(f.filter((function(t) {
                return t.staff == e
              }))[0]),
              v = f[b];
            v.custnum = t, v.zhen1 = a, v.zhena1 = d, v.zhen2 = r, v.zhena2 = h, v.zhen3 = i, v.zhena3 = c, v.zhen4 = n, v.zhena4 = s, v.tprice1 = l, v.tprice2 = u, v.tprice3 = p, v.tprice4 = m, v.tprice = l + u + p + m, f[b] = v
          }))
        }
        if (n.length > 0 && (o = {}, n.forEach((function(e) {
            o[e.staff] = o[e.staff] || [], o[e.staff].push(e)
          })), s.forEach((function(e) {
            null == o[e] && (o[e] = [])
          })), s.forEach((function(e) {
            var t = 0;
            o[e].forEach((function(e) {
              t += 1 * e.price1
            }));
            var a = f.indexOf(f.filter((function(t) {
                return t.staff == e
              }))[0]),
              r = f[a];
            r.miaosha = t, f[a] = r
          }))), d.length > 0) {
          o = {};
          d.forEach((function(e) {
            o[e.staff] = o[e.staff] || [], o[e.staff].push(e)
          })), s.forEach((function(e) {
            null == o[e] && (o[e] = [])
          })), s.forEach((function(e) {
            var t = 0,
              a = 0;
            o[e].forEach((function(e) {
              0 == e.salelb && (t += 1 * e.receive), 1 == e.salelb && (a += 1 * e.receive)
            }));
            var r = f.indexOf(f.filter((function(t) {
                return t.staff == e
              }))[0]),
              i = f[r];
            i.receive1 = t, i.receive2 = a, f[r] = i
          }))
        }
        if (f.length > 0) {
          var l = 0;
          f.forEach((function(e) {
            var t = h.indexOf(h.filter((function(t) {
              return t.staff == e.staff
            }))[0]);
            f[l].depart = h[t].depart, f[l].departid = h[t].departid, l += 1
          }));
          var u = {};
          f.forEach((function(e) {
            u[e.depart] = u[e.depart] || [], u[e.depart].push(e)
          }));
          var p = Object.keys(u),
            m = [{
              title: "汇总",
              index: 1
            }],
            b = 2;
          p.forEach((function(e) {
            m[b - 1] = {
              title: e,
              index: b
            }, b += 1
          }));
          var v = [];
          p.forEach((function(e) {
            var t, a = 0,
              r = 0,
              i = 0,
              n = 0,
              d = 0,
              h = 0,
              f = 0,
              c = 0,
              s = 0,
              o = 0,
              l = 0,
              p = 0,
              m = 0,
              b = 0,
              z = 0,
              L = 0,
              y = 0;
            u[e].forEach((function(e) {
              a += e.custnum, r += e.miaosha, i += e.zhen1, n += e.zhen2, d += e.zhen3, h += e.zhen4, f += e.zhena1, c += e.zhena2, s += e.zhena3, o += e.zhena4, l += e.tprice1, p += e.tprice2, m += e.tprice3, b += e.tprice4, z += e.receive1, L += e.receive2, y = z + L
            })), t = l + p + m + b, v.push({
              depart: e,
              dcustnum: a,
              dmiaosha: r,
              dzhen1: i,
              dzhen2: n,
              dzhen3: d,
              dzhen4: h,
              dzhena1: f,
              dzhena2: c,
              dzhena3: s,
              dzhena4: o,
              dtprice1: l,
              dtprice2: p,
              dtprice3: m,
              dtprice4: b,
              dtprice: t,
              dreceive1: z,
              dreceive2: L,
              dreceive: y
            })
          }))
        }
        var z = 0,
          L = 0,
          y = 0,
          g = 0,
          w = 0,
          D = 0,
          x = 0,
          E = 0,
          C = 0,
          N = 0,
          T = 0,
          O = 0,
          j = 0,
          k = 0,
          q = 0,
          B = 0;
        f.forEach((function(e) {
          z += e.custnum, L += e.zhen1, y += e.zhen2, g += e.zhen3, w += e.zhen4, D += e.zhena1, x += e.zhena2, E += e.zhena3, C += e.zhena4, N += e.tprice1, T += e.tprice2, T += e.tprice2, O += e.tprice3, j += e.tprice4, k += e.receive1, q += e.receive2, B += e.miaosha
        })), a = {
          tcustnum: z,
          tzhen1: L,
          tzhen2: y,
          tzhen3: g,
          tzhen4: w,
          tzhena1: D,
          tzhena2: x,
          tzhena3: E,
          tzhena4: C,
          ttprice1: N,
          ttprice2: T,
          ttprice3: O,
          ttprice4: j,
          ttprice: N + T + O + j,
          treceive1: k,
          treceive2: q,
          treceive: 0,
          tmiaosha: B
        }, e.setData({
          saleList: t.data.saleList,
          receiveList: t.data.receiveList,
          departmonthList: t.data.departmonthList,
          staffmonthList: t.data.staffmonthList,
          journalList: i,
          miaoshaList: n,
          dailyList: r,
          staffData: f,
          departData: v,
          navList: m,
          total: a
        })
      }
    }))
  },
  scrollgo: function(e) {
    this.setData({
      scrollX: e.detail.scrollLeft
    })
  },
  inputChange: function(t) {
    var a = t.currentTarget.dataset.item;
    this.setData(e({}, a, t.detail.value))
  },
  clickLine: function(t) {
    var r = t.currentTarget.dataset.item.id,
      i = t.currentTarget.dataset.arr,
      n = this.data.indexList.filter((function(e) {
        return e.id == r
      }))[0].staff,
      d = [],
      h = this.data.staffmonthList.filter((function(e) {
        return e.staff == n
      }));
    console.log("staffsummary", h), h.length > 0 && (d = h[0]);
    var f;
    f = a.selectChange(this.data[i], r), this.setData(e(e({}, i, f), "staffsummary", d))
  },
  getOrder: function(t) {
    var a = t.detail.data,
      r = t.currentTarget.dataset.arr;
    this.setData(e({}, r, a))
  },
  getOrder2: function(e) {
    var t = e.currentTarget.dataset.field,
      r = a.orderBy(this.data.departData, t, "byNum", 0);
    this.setData({
      departData: r,
      field: t
    })
  },
  getOrder3: function(e) {
    var t = e.currentTarget.dataset.field,
      r = a.orderBy(this.data.indexList, t, "byNum", 0);
    this.setData({
      indexList: r,
      field: t
    })
  }
});