var t = (0, require("../../../@babel/runtime/helpers/interopRequireDefault").default)(require("../../../utils/myfunc.js")),
  i = require("../../../apiconfig");
Page({
  data: {
    navList: [{
      title: "基本信息",
      index: "1"
    }, {
      title: "购买记录",
      index: "3"
    }, {
      title: "见诊日志",
      index: "5"
    }],
    cIndex: 1,
    id: "",
    cidInfo: "",
    remainList: [],
    buyList: [],
    nurseList: [],
    journalList: [],
    fbackList: [],
    state_show: !1
  },
  clickTab: function(t) {
    var i = t.detail.data.index;
    this.setData({
      cIndex: i
    }), "3" == i && this.getSaleList(this.data.id), "5" == i && this.getJournalList(this.data.id), "7" == i && this.doChart()
  },
  showHelp: function(t) {
    this.setData({
      state_show: !0
    })
  },
  hideHelp: function() {
    this.setData({
      state_show: !1
    })
  },
  onLoad: function(t) {
    this.setData({
      id: t.id
    }), this.getCidinfo()
  },
  getCidinfo: function() {
    var i = this;
    t.default.getInfo("d_cid", this.data.id).then((function(t) {
      i.setData({
        cidInfo: t.data
      })
    }))
  },
  toEdit: function(t) {
    var i = t.currentTarget.dataset.item;
    wx.navigateTo({
      url: "./customer_edit?id=" + i.id
    })
  },
  editinfo: function(t) {
    var i = t.currentTarget.dataset.key;
    wx.navigateTo({
      url: "./cidnote_edit?id=" + this.data.id + "&infolb=" + i
    })
  },
  clickLine: function(t) {
    var i = t.currentTarget.dataset.item;
    if (null != t) {
      var e = this.data.remainList;
      e.length && (e.forEach((function(t) {
        t.id == i.id && ("0" == t.select || null == t.select) ? t.select = "1" : t.select = "0"
      })), this.setData({
        remainList: e
      }))
    }
  },
  clickLine2: function(t) {
    var i = t.currentTarget.dataset.item;
    if (null != t) {
      var e = this.data.buyList;
      e.length && (e.forEach((function(t) {
        t.id == i.id && ("0" == t.select || null == t.select) ? t.select = "1" : t.select = "0"
      })), this.setData({
        buyList: e
      }))
    }
  },
  nurse: function(t) {
    var i = t.currentTarget.dataset.item;
    wx.navigateTo({
      url: "./xmnurse?cid=" + this.data.cid + "&item=" + JSON.stringify(i)
    })
  },
  getSaleList: function(e) {
    var a = this,
      n = {
        token: t.default.userInfo().token,
        cid: e
      };
    t.default.Post(i.dataApi + "eproduct/cideproduct_list", n, (function(t) {
      if (200 == t.code) {
        var i = 1;
        t.data.length > 0 && (i = 0), a.setData({
          buyList: t.data,
          show_state: i
        })
      }
    }))
  },
  getJournalList: function(e) {
    var a = this,
      n = {
        token: t.default.userInfo().token,
        cid: e
      };
    t.default.Post(i.dataApi + "journal/cidjournal_list", n, (function(t) {
      if (200 == t.code) {
        var i = 1;
        t.data.length > 0 && (i = 0), a.setData({
          journalList: t.data,
          show_state: i
        })
      }
    }))
  }
});