var t = (0, require("../../../@babel/runtime/helpers/interopRequireDefault").default)(require("../../../utils/myfunc.js")),
  e = require("../../../apiconfig");
getApp();
Page({
  data: {
    startdata: "开始时间",
    enddata: "结束时间",
    msg: "",
    resultList: [],
    cIndex: ""
  },
  onLoad: function(e) {
    this.setData({
      startdata: t.default.GetDateStr(-20),
      enddata: t.default.GetDateStr(3)
    }), this.fetchList()
  },
  toadd: function(t) {
    wx.navigateTo({
      url: "reimburse_add"
    })
  },
  ChangeStart: function(t) {
    var e = t.detail.value;
    e && this.setData({
      startdata: e
    }), this.fetchList()
  },
  ChangeEnd: function(t) {
    var e = t.detail.value;
    e && this.setData({
      enddata: e
    }), this.fetchList()
  },
  searchList: function() {
    this.fetchList()
  },
  clickItem: function(t) {
    var e = t.currentTarget.dataset.item;
    wx.navigateTo({
      url: "./reimburse_edit?id=" + e.id
    })
  },
  searchList1: function(t) {
    var e = new Date,
      a = e.getFullYear(),
      s = e.getMonth();
    0 == s && (s = 12, a -= 1), s < 10 && (s = "0" + s);
    var i = a + "-" + s + "-01",
      r = a + "-" + s + "-" + new Date(a, s, 0).getDate();
    this.setData({
      startdata: i,
      enddata: r,
      cIndex: t.currentTarget.dataset.index
    }), this.fetchList()
  },
  searchList2: function(t) {
    var e = new Date,
      a = e.getFullYear(),
      s = e.getMonth() + 1;
    s < 10 && (s = "0" + s);
    e.getDate();
    var i = a + "-" + s + "-01",
      r = a + "-" + s + "-" + function(t, e) {
        var a = new Date(0);
        return 12 == e ? (a.setUTCFullYear(t + 1), a.setUTCMonth(0)) : (a.setUTCFullYear(t), a.setUTCMonth(e)), a.setTime(a.getTime() - 1), a.getUTCDate()
      }(a, s);
    this.setData({
      startdata: i,
      enddata: r,
      cIndex: t.currentTarget.dataset.index
    }), this.fetchList()
  },
  fetchList: function(a) {
    var s = t.default.userInfo(),
      i = this,
      r = {
        token: s.token,
        st: i.data.startdata,
        et: i.data.enddata,
        staff: s.staff
      };
    i = this;
    t.default.Post(e.dataApi + "reimburse/reimburselist", r, (function(t) {
      200 == t.code && (i.setData({
        resultList: t.data,
        msg: t.msg
      }), console.log("loaddata", i.data))
    }))
  }
});