var t = (0, require("../../../@babel/runtime/helpers/interopRequireDefault").default)(require("../../../utils/myfunc.js")),
  a = require("../../../apiconfig");
Page({
  data: {
    latitude: 22.618963,
    longitude: 114.077332,
    myaddress: {},
    currentunit: {},
    markers: []
  },
  onReady: function(t) {
    this.mapCtx = wx.createMapContext("myMap")
  },
  onLoad: function() {
    this.getdataList();
    var a = this;
    t.default.getLocation().then((function(t) {
      console.log("当前所在位置的经纬度为：", t), a.setData({
        myaddress: {
          latitude: t.latitude,
          longitude: t.longitude
        }
      })
    }))
  },
  getdataList: function() {
    var e = this,
      i = {
        token: t.default.userInfo().token
      };
    t.default.Post(a.dataApi + "sysrefer/map_list", i, (function(t) {
      if (200 == t.code) {
        var a = t.data,
          i = [];
        if (a && a.length > 0) {
          var d = 0,
            n = 0;
          a.forEach((function(t) {
            null != t.latitude && t.latitude > 0 && (i[n] = {
              id: d,
              width: 20,
              height: 30,
              latitude: t.latitude,
              longitude: t.longitude,
              name: t.unitshort
            }, n++), d++
          }))
        }
        console.log("markers", i), e.setData({
          dataList: t.data,
          markers: i
        }), console.log("setData", e.data)
      }
    }))
  },
  markertap: function(t) {
    console.log("bindmarkertap", t.markerId);
    var a = this.data.dataList[t.markerId],
      e = this.distance(this.data.myaddress.latitude, this.data.myaddress.longitude, a.latitude, a.longitude);
    a.distance = Number(e).toFixed(0), this.setData({
      currentunit: a,
      latitude: a.latitude,
      longitude: a.longitude
    }), console.log("setData", this.data)
  },
  access: function() {
    var a = this;
    t.default.getLocation().then((function(t) {
      console.log("当前所在位置的经纬度为：", t), a.setData({
        latitude: t.latitude,
        longitude: t.longitude
      })
    }))
  },
  distance: function(t, a, e, i) {
    var d = t * Math.PI / 180,
      n = e * Math.PI / 180,
      s = d - n,
      o = a * Math.PI / 180 - i * Math.PI / 180,
      u = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(s / 2), 2) + Math.cos(d) * Math.cos(n) * Math.pow(Math.sin(o / 2), 2)));
    return u *= 6378.137, u = Math.round(1e4 * u) / 1e4, console.log("计算结果", u), u
  },
  tomyaddress: function() {
    this.setData({
      latitude: this.data.myaddress.latitude,
      longitude: this.data.myaddress.longitude
    })
  },
  openMap: function() {
    var t = this.data.currentunit;
    wx.openLocation({
      latitude: Number(t.latitude),
      longitude: Number(t.longitude),
      scale: 19,
      name: t.unitshort,
      address: t.address
    })
  }
});