var e, t = require("../../../@babel/runtime/helpers/interopRequireDefault").default,
  a = require("../../../@babel/runtime/helpers/regeneratorRuntime"),
  i = require("../../../@babel/runtime/helpers/asyncToGenerator"),
  n = require("../../../@babel/runtime/helpers/defineProperty"),
  r = t(require("../../../utils/myfunc.js")),
  s = (t(require("../../../regenerator-runtime/runtime.js")), require("../../../apiconfig"));
Page({
  data: {
    addInfo: {},
    cidList: [],
    albumlbList: [],
    mindate: "",
    maxdate: "",
    files: []
  },
  onLoad: function(e) {
    console.log("page:", "1work/album/album_add"), this.setData(n(n(n(n(n(n({}, "addInfo.unitid", e.unitid), "mindate", r.default.GetDateStr(-3650)), "maxdate", r.default.GetDateStr(0)), "addInfo.date", r.default.GetDateStr(0)), "cidList", wx.getStorageSync("cidList")), "albumlbList", wx.getStorageSync("albumlbList")))
  },
  chooseImage: function(e) {
    var t = this;
    wx.chooseImage({
      sizeType: ["original"],
      sourceType: ["album", "camera"],
      count: 9,
      success: function(e) {
        t.setData({
          files: t.data.files.concat(e.tempFilePaths)
        })
      }
    }), console.log("files", this.data.files)
  },
  previewImage: function(e) {
    wx.previewImage({
      current: e.currentTarget.id,
      urls: this.data.files
    })
  },
  deleteImage: function(e) {
    var t = this,
      a = t.data.files,
      i = e.currentTarget.dataset.item;
    console.log(t.data.files), console.log("item", i), wx.showModal({
      title: "系统提醒",
      content: "确定要删除此图片吗？",
      success: function(e) {
        if (e.confirm) a.splice(a.indexOf(i), 1);
        else if (e.cancel) return !1;
        t.setData({
          files: a
        })
      }
    })
  },
  bindDateChange: function(e) {
    this.setData({
      date: e.detail.value
    })
  },
  savetest: function(e, t, a) {
    var i = "";
    return (a = wx.getStorageSync("userInfo")) && a.token.length > 10 && (i = a.token), new Promise((function(n) {
      wx.request({
        url: s.dataApi + "album/album_add",
        method: "POST",
        header: {
          "Content-Type": "application/x-www-form-urlencoded",
          Authorization: i
        },
        data: e,
        success: function(i) {
          if (wx.hideLoading(), 200 == i.data.code) {
            var r = i.data.data;
            wx.showLoading({
              title: "图片上传中..."
            });
            var o = {
              token: a.token,
              groupid: a.groupid,
              pathlb: "albumcid",
              field: "pic",
              unitid: e.unitid,
              id: r
            };
            wx.uploadFile({
              url: s.resupApi + "myj_img/pic_save",
              filePath: t,
              name: "file",
              formData: o,
              success: function(e) {
                n("123");
                var t = JSON.parse(e.data);
                wx.hideLoading(), 200 == t.code ? console.log("up sucess") : wx.showToast({
                  title: "图片保存失败!",
                  icon: "none"
                })
              }
            })
          }
        }
      })
    }))
  },
  savepic: (e = i(a().mark((function e(t) {
    var i, n, s, o, u, d, l;
    return a().wrap((function(e) {
      for (;;) switch (e.prev = e.next) {
        case 0:
          if (0 != this.data.files.length) {
            e.next = 3;
            break
          }
          return r.default.showTip("请选择照片！"), e.abrupt("return", !1);
        case 3:
          if (0 != r.default.inputCheck(this.data.addInfo.cid, "char")) {
            e.next = 6;
            break
          }
          return r.default.showTip("请选择顾客！"), e.abrupt("return", !1);
        case 6:
          if (0 != r.default.inputCheck(this.data.addInfo.albumlb, "char")) {
            e.next = 9;
            break
          }
          return r.default.showTip("请选择照片类别！"), e.abrupt("return", !1);
        case 9:
          i = r.default.userInfo(), (n = this.data.addInfo).token = i.token, s = this, wx.showLoading({
            title: "保存中",
            mask: "true"
          }), o = this.data.files.length, u = 0;
        case 16:
          if (!(u < o)) {
            e.next = 26;
            break
          }
          return wx.hideLoading(), console.log("files[i]", s.data.files[u]), d = s.data.files[u], e.next = 22, this.savetest(n, d, i);
        case 22:
          u == o - 1 && ((l = getCurrentPages())[l.length - 2].getdataList(), wx.showModal({
            title: "系统提示",
            content: "保存成功！",
            showCancel: !1,
            success: function(e) {
              e.confirm && wx.navigateBack({
                delta: 1
              })
            }
          }));
        case 23:
          u++, e.next = 16;
          break;
        case 26:
        case "end":
          return e.stop()
      }
    }), e, this)
  }))), function(t) {
    return e.apply(this, arguments)
  }),
  showPicker: function(e) {
    var t = this.data[e.currentTarget.dataset.item];
    null == t || ("cidList" == e.currentTarget.dataset.item && t.forEach((function(e) {
      e.option = e.name
    })), "albumlbList" == e.currentTarget.dataset.item && t.forEach((function(e) {
      e.option = e.value
    })), this.setData({
      pickList: t,
      show_picker: !0,
      picker: e.currentTarget.dataset.item
    }))
  },
  getSelect: function(e) {
    "cidList" == this.data.picker && this.setData(n(n({}, "addInfo.cid", e.detail.data.id), "addInfo.name", e.detail.data.name)), "albumlbList" == this.data.picker && this.setData(n({}, "addInfo.albumlb", e.detail.data.value))
  },
  inputChange: function(e) {
    var t = e.currentTarget.dataset.item;
    this.setData(n({}, t, e.detail.value))
  },
  noteChange: function(e) {
    var t = e.currentTarget.dataset.item,
      a = e.detail.value.length;
    this.setData(n(n({}, t, e.detail.value), "length", a))
  }
});