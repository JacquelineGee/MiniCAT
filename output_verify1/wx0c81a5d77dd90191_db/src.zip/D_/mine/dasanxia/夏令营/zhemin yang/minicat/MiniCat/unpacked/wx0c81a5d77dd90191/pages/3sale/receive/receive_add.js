var t = require("../../../@babel/runtime/helpers/interopRequireDefault").default,
  e = require("../../../@babel/runtime/helpers/defineProperty"),
  a = t(require("../../../utils/myfunc.js")),
  i = require("../../../apiconfig");
Page({
  data: {
    navList: [{
      title: "订单收款",
      index: "1"
    }, {
      title: "收款记录",
      index: "2"
    }],
    cIndex: 1,
    editInfo: {},
    addInfo: {},
    indexList: [],
    stdate: a.default.GetDateStr(-1825),
    etdate: a.default.GetDateStr(0)
  },
  onLoad: function(t) {
    var e = JSON.parse(t.info);
    this.setData({
      editInfo: e
    }), this.getDatalist()
  },
  clickTab: function(t) {
    var e = t.detail.data.index;
    this.setData({
      cIndex: e
    }), 1 * e > 1 && this.getDatalist(e)
  },
  getDatalist: function() {
    var t = this,
      e = {
        sid: this.data.editInfo.id
      };
    a.default.Post(i.dataApi + "receive/add_start", e, (function(e) {
      if (200 == e.code) {
        var i = e.data.saleInfo;
        i.receive = i.price2, i.staff = a.default.userInfo().staff, t.setData({
          indexList: e.data.receiveList,
          addInfo: i
        })
      }
    }))
  },
  saveAdd: function(t) {
    var e = this;
    if (0 == a.default.inputCheck(this.data.addInfo.receive, "number")) return a.default.showTip("请输收款金额！"), !1;
    if (this.data.addInfo.receive > this.data.addInfo.price2) return a.default.showTip("收款金额不能大于欠款！"), !1;
    var s = this.data.addInfo;
    wx.showLoading({
      title: "保存中",
      mask: "true"
    }), a.default.Post(i.dataApi + "receive/receive_add", s, (function(t) {
      if (200 == t.code) {
        wx.hideLoading(), e.getDatalist();
        var i = getCurrentPages(),
          s = i[i.length - 2];
        "pages/3sale/sale/sale_list" == s.route && s.getDatalist(), "pages/3sale/sale/miaosha_list" == s.route && s.getDatalist(), wx.showModal({
          title: "系统提示",
          content: "保存成功！",
          showCancel: !1,
          success: function(t) {
            wx.navigateBack({
              delta: 1
            })
          }
        })
      } else a.default.showTip("保存失败！")
    }))
  },
  toDel: function(t) {
    var e = t.currentTarget.dataset.item,
      s = this;
    wx.showModal({
      title: "温馨提示",
      content: "您确定要删除吗？",
      success: function(t) {
        if (t.confirm) {
          var d = {
            id: e.id
          };
          a.default.Post(i.dataApi + "receive/receive_del", d, (function(t) {
            if (200 == t.code) {
              s.getDatalist();
              var e = getCurrentPages(),
                a = e[e.length - 2];
              "pages/3sale/sale/sale_list" == a.route && a.getDatalist(), "pages/3sale/sale/miaosha_list" == a.route && a.getDatalist(), wx.showModal({
                title: "系统提示",
                content: "删除成功！",
                showCancel: !1
              })
            } else wx.showToast({
              title: "删除失败!",
              icon: "error"
            })
          }))
        }
      }
    })
  },
  showPicker: function(t) {
    var e = this.data[t.currentTarget.dataset.item];
    null == e || ("productList" == t.currentTarget.dataset.item && e.forEach((function(t) {
      t.option = t.product
    })), this.setData({
      pickList: e,
      show_picker: !0,
      picker: t.currentTarget.dataset.item
    }))
  },
  getSelect: function(t) {
    "productList" == this.data.picker && this.setData(e(e(e(e({}, "addInfo.product", t.detail.data.product), "addInfo.amount", 1), "addInfo.uprice", t.detail.data.price), "addInfo.tprice", 1 * t.detail.data.price))
  },
  inputChange: function(t) {
    var a = t.currentTarget.dataset.key;
    this.setData(e({}, a, t.detail.value)), "addInfo.amount" == a && this.setData(e({}, "addInfo.tprice", t.detail.value * this.data.addInfo.uprice))
  }
});