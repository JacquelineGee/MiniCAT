var e = require("../../../@babel/runtime/helpers/interopRequireDefault").default,
  t = require("../../../@babel/runtime/helpers/defineProperty"),
  i = e(require("../../../utils/myfunc.js")),
  a = require("../../../apiconfig");
Page({
  data: {
    info: {},
    length: "",
    files: []
  },
  onLoad: function(e) {
    this.getUnitInfo(e.id)
  },
  getUnitInfo: function(e) {
    var t = this,
      n = {
        id: e,
        token: i.default.userInfo().token
      };
    i.default.Post(a.dataApi + "sysrefer/unit_info", n, (function(e) {
      200 == e.code && t.setData({
        info: e.data,
        length: e.data.address.length
      })
    }))
  },
  chooseImage: function(e) {
    var t = this;
    wx.chooseImage({
      sizeType: ["original"],
      sourceType: ["album", "camera"],
      count: 9,
      success: function(e) {
        console.log("res", e), wx.showLoading({
          title: "图片上传中..."
        });
        var n = {
          token: i.default.userInfo().token,
          pathlb: "myunit",
          field: "image",
          unitid: 6,
          id: t.data.info.id
        };
        wx.uploadFile({
          url: a.resupApi + "Mr_img/pic_save",
          filePath: e.tempFilePaths[0],
          name: "file",
          formData: n,
          success: function(e) {
            var t = JSON.parse(e.data);
            wx.hideLoading(), 200 == t.code ? console.log("up sucess") : wx.showToast({
              title: "图片保存失败!",
              icon: "none"
            })
          }
        })
      }
    }), console.log("files", this.data.files)
  },
  previewImage: function(e) {
    wx.previewImage({
      current: e.currentTarget.dataset.coverurl,
      urls: this.data.files
    })
  },
  changeNote: function(e) {
    var i = e.detail.value.length;
    this.setData(t({
      length: i
    }, "info.note", e.detail.value))
  },
  saveEdit: function(e) {
    if (e.detail.value.unitname.length < 2) return wx.showToast({
      title: "请输入美容院名称!",
      icon: "none",
      duration: 1600
    }), !1;
    var t = {
      token: i.default.userInfo().token,
      id: this.data.info.id,
      unitname: e.detail.value.unitname,
      tel: e.detail.value.tel,
      note: e.detail.value.note
    };
    i.default.Post(a.dataApi + "sysrefer/unit_edit", t, (function(e) {
      if (wx.showLoading({
          title: "保存中",
          mask: "true"
        }), 200 == e.code) {
        wx.hideLoading();
        var t = getCurrentPages();
        t[t.length - 2].getDatalist(), wx.showModal({
          title: "系统提示",
          content: "保存成功！",
          showCancel: !1,
          success: function(e) {
            e.confirm && wx.navigateBack({
              delta: 1
            })
          }
        })
      } else wx.showToast({
        title: e.msg,
        icon: "none"
      })
    }))
  }
});