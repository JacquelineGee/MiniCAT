var t = require("../@babel/runtime/helpers/typeof"),
  r = function(r) {
    var e = Object.prototype,
      n = e.hasOwnProperty,
      o = "function" == typeof Symbol ? Symbol : {},
      i = o.iterator || "@@iterator",
      a = o.asyncIterator || "@@asyncIterator",
      c = o.toStringTag || "@@toStringTag";

    function u(t, r, e) {
      return Object.defineProperty(t, r, {
        value: e,
        enumerable: !0,
        configurable: !0,
        writable: !0
      }), t[r]
    }
    try {
      u({}, "")
    } catch (t) {
      u = function(t, r, e) {
        return t[r] = e
      }
    }

    function h(t, r, e, n) {
      var o = r && r.prototype instanceof s ? r : s,
        i = Object.create(o.prototype),
        a = new _(n || []);
      return i._invoke = function(t, r, e) {
        var n = "suspendedStart";
        return function(o, i) {
          if ("executing" === n) throw new Error("Generator is already running");
          if ("completed" === n) {
            if ("throw" === o) throw i;
            return O()
          }
          for (e.method = o, e.arg = i;;) {
            var a = e.delegate;
            if (a) {
              var c = L(a, e);
              if (c) {
                if (c === f) continue;
                return c
              }
            }
            if ("next" === e.method) e.sent = e._sent = e.arg;
            else if ("throw" === e.method) {
              if ("suspendedStart" === n) throw n = "completed", e.arg;
              e.dispatchException(e.arg)
            } else "return" === e.method && e.abrupt("return", e.arg);
            n = "executing";
            var u = l(t, r, e);
            if ("normal" === u.type) {
              if (n = e.done ? "completed" : "suspendedYield", u.arg === f) continue;
              return {
                value: u.arg,
                done: e.done
              }
            }
            "throw" === u.type && (n = "completed", e.method = "throw", e.arg = u.arg)
          }
        }
      }(t, e, a), i
    }

    function l(t, r, e) {
      try {
        return {
          type: "normal",
          arg: t.call(r, e)
        }
      } catch (t) {
        return {
          type: "throw",
          arg: t
        }
      }
    }
    r.wrap = h;
    var f = {};

    function s() {}

    function p() {}

    function d() {}
    var y = {};
    u(y, i, (function() {
      return this
    }));
    var v = Object.getPrototypeOf,
      g = v && v(v(j([])));
    g && g !== e && n.call(g, i) && (y = g);
    var m = d.prototype = s.prototype = Object.create(y);

    function w(t) {
      ["next", "throw", "return"].forEach((function(r) {
        u(t, r, (function(t) {
          return this._invoke(r, t)
        }))
      }))
    }

    function b(r, e) {
      var o;
      this._invoke = function(i, a) {
        function c() {
          return new e((function(o, c) {
            ! function o(i, a, c, u) {
              var h = l(r[i], r, a);
              if ("throw" !== h.type) {
                var f = h.arg,
                  s = f.value;
                return s && "object" === t(s) && n.call(s, "__await") ? e.resolve(s.__await).then((function(t) {
                  o("next", t, c, u)
                }), (function(t) {
                  o("throw", t, c, u)
                })) : e.resolve(s).then((function(t) {
                  f.value = t, c(f)
                }), (function(t) {
                  return o("throw", t, c, u)
                }))
              }
              u(h.arg)
            }(i, a, o, c)
          }))
        }
        return o = o ? o.then(c, c) : c()
      }
    }

    function L(t, r) {
      var e = t.iterator[r.method];
      if (void 0 === e) {
        if (r.delegate = null, "throw" === r.method) {
          if (t.iterator.return && (r.method = "return", r.arg = void 0, L(t, r), "throw" === r.method)) return f;
          r.method = "throw", r.arg = new TypeError("The iterator does not provide a 'throw' method")
        }
        return f
      }
      var n = l(e, t.iterator, r.arg);
      if ("throw" === n.type) return r.method = "throw", r.arg = n.arg, r.delegate = null, f;
      var o = n.arg;
      return o ? o.done ? (r[t.resultName] = o.value, r.next = t.nextLoc, "return" !== r.method && (r.method = "next", r.arg = void 0), r.delegate = null, f) : o : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, f)
    }

    function x(t) {
      var r = {
        tryLoc: t[0]
      };
      1 in t && (r.catchLoc = t[1]), 2 in t && (r.finallyLoc = t[2], r.afterLoc = t[3]), this.tryEntries.push(r)
    }

    function E(t) {
      var r = t.completion || {};
      r.type = "normal", delete r.arg, t.completion = r
    }

    function _(t) {
      this.tryEntries = [{
        tryLoc: "root"
      }], t.forEach(x, this), this.reset(!0)
    }

    function j(t) {
      if (t) {
        var r = t[i];
        if (r) return r.call(t);
        if ("function" == typeof t.next) return t;
        if (!isNaN(t.length)) {
          var e = -1,
            o = function r() {
              for (; ++e < t.length;)
                if (n.call(t, e)) return r.value = t[e], r.done = !1, r;
              return r.value = void 0, r.done = !0, r
            };
          return o.next = o
        }
      }
      return {
        next: O
      }
    }

    function O() {
      return {
        value: void 0,
        done: !0
      }
    }
    return p.prototype = d, u(m, "constructor", d), u(d, "constructor", p), p.displayName = u(d, c, "GeneratorFunction"), r.isGeneratorFunction = function(t) {
      var r = "function" == typeof t && t.constructor;
      return !!r && (r === p || "GeneratorFunction" === (r.displayName || r.name))
    }, r.mark = function(t) {
      return Object.setPrototypeOf ? Object.setPrototypeOf(t, d) : (t.__proto__ = d, u(t, c, "GeneratorFunction")), t.prototype = Object.create(m), t
    }, r.awrap = function(t) {
      return {
        __await: t
      }
    }, w(b.prototype), u(b.prototype, a, (function() {
      return this
    })), r.AsyncIterator = b, r.async = function(t, e, n, o, i) {
      void 0 === i && (i = Promise);
      var a = new b(h(t, e, n, o), i);
      return r.isGeneratorFunction(e) ? a : a.next().then((function(t) {
        return t.done ? t.value : a.next()
      }))
    }, w(m), u(m, c, "Generator"), u(m, i, (function() {
      return this
    })), u(m, "toString", (function() {
      return "[object Generator]"
    })), r.keys = function(t) {
      var r = [];
      for (var e in t) r.push(e);
      return r.reverse(),
        function e() {
          for (; r.length;) {
            var n = r.pop();
            if (n in t) return e.value = n, e.done = !1, e
          }
          return e.done = !0, e
        }
    }, r.values = j, _.prototype = {
      constructor: _,
      reset: function(t) {
        if (this.prev = 0, this.next = 0, this.sent = this._sent = void 0, this.done = !1, this.delegate = null, this.method = "next", this.arg = void 0, this.tryEntries.forEach(E), !t)
          for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = void 0)
      },
      stop: function() {
        this.done = !0;
        var t = this.tryEntries[0].completion;
        if ("throw" === t.type) throw t.arg;
        return this.rval
      },
      dispatchException: function(t) {
        if (this.done) throw t;
        var r = this;

        function e(e, n) {
          return a.type = "throw", a.arg = t, r.next = e, n && (r.method = "next", r.arg = void 0), !!n
        }
        for (var o = this.tryEntries.length - 1; o >= 0; --o) {
          var i = this.tryEntries[o],
            a = i.completion;
          if ("root" === i.tryLoc) return e("end");
          if (i.tryLoc <= this.prev) {
            var c = n.call(i, "catchLoc"),
              u = n.call(i, "finallyLoc");
            if (c && u) {
              if (this.prev < i.catchLoc) return e(i.catchLoc, !0);
              if (this.prev < i.finallyLoc) return e(i.finallyLoc)
            } else if (c) {
              if (this.prev < i.catchLoc) return e(i.catchLoc, !0)
            } else {
              if (!u) throw new Error("try statement without catch or finally");
              if (this.prev < i.finallyLoc) return e(i.finallyLoc)
            }
          }
        }
      },
      abrupt: function(t, r) {
        for (var e = this.tryEntries.length - 1; e >= 0; --e) {
          var o = this.tryEntries[e];
          if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) {
            var i = o;
            break
          }
        }
        i && ("break" === t || "continue" === t) && i.tryLoc <= r && r <= i.finallyLoc && (i = null);
        var a = i ? i.completion : {};
        return a.type = t, a.arg = r, i ? (this.method = "next", this.next = i.finallyLoc, f) : this.complete(a)
      },
      complete: function(t, r) {
        if ("throw" === t.type) throw t.arg;
        return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && r && (this.next = r), f
      },
      finish: function(t) {
        for (var r = this.tryEntries.length - 1; r >= 0; --r) {
          var e = this.tryEntries[r];
          if (e.finallyLoc === t) return this.complete(e.completion, e.afterLoc), E(e), f
        }
      },
      catch: function(t) {
        for (var r = this.tryEntries.length - 1; r >= 0; --r) {
          var e = this.tryEntries[r];
          if (e.tryLoc === t) {
            var n = e.completion;
            if ("throw" === n.type) {
              var o = n.arg;
              E(e)
            }
            return o
          }
        }
        throw new Error("illegal catch attempt")
      },
      delegateYield: function(t, r, e) {
        return this.delegate = {
          iterator: j(t),
          resultName: r,
          nextLoc: e
        }, "next" === this.method && (this.arg = void 0), f
      }
    }, r
  }("object" === ("undefined" == typeof module ? "undefined" : t(module)) ? module.exports : {});
try {
  regeneratorRuntime = r
} catch (e) {
  "object" === ("undefined" == typeof globalThis ? "undefined" : t(globalThis)) ? globalThis.regeneratorRuntime = r: Function("r", "regeneratorRuntime = r")(r)
}