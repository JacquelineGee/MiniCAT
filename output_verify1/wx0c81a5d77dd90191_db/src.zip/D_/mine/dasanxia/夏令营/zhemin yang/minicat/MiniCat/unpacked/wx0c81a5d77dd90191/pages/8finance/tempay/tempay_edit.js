var t = getApp(),
  e = require("../../../apiconfig"),
  a = require("../../../utils/myfunc.js");
Page({
  data: {
    id: "",
    tempayInfo: "",
    note: ""
  },
  onLoad: function(t) {
    this.setData({
      id: t.id
    }), this.gettempayInfo(t.id)
  },
  gettempayInfo: function(n) {
    var o = this,
      i = {
        request: "gettempayInfo",
        id: n,
        Token: t.globalData.userInfo.Token
      };
    a.Post(e.financeApi, i, (function(t) {
      0 == t.code && o.setData({
        tempayInfo: t.data
      })
    }))
  },
  changeNote: function(t) {
    var e = t.detail.value.length;
    this.setData({
      length: e,
      note: t.detail.value
    })
  },
  formSubmit: function() {
    var n = {
        request: "editTempay",
        id: this.data.id,
        note: this.data.note,
        Token: t.globalData.userInfo.Token
      },
      o = this;
    a.Post(e.financeApi, n, (function(t) {
      if (o.setData({
          canClick: 0
        }), 0 == t.code) {
        var e = getCurrentPages();
        e[e.length - 2].onLoad(), wx.showModal({
          title: "系统提示",
          content: t.msg,
          showCancel: !1,
          success: function() {
            wx.navigateBack({
              detal: 1
            })
          }
        })
      } else wx.showModal({
        title: "系统提示",
        content: t.msg
      })
    }))
  }
});