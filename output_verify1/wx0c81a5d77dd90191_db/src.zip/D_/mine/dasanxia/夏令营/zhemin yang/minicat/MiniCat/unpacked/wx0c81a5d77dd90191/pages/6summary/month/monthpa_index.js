var e = require("../../../@babel/runtime/helpers/defineProperty"),
  t = require("../../../apiconfig"),
  r = require("../../../utils/myfunc.js");
Page({
  data: {
    navList: [{
      title: "总结概况",
      index: "1"
    }, {
      title: "见诊记录",
      index: "2"
    }, {
      title: "产品搭配",
      index: "3"
    }, {
      title: "收款记录",
      index: "4"
    }],
    cIndex: 1,
    thList: [{
      width: 200,
      orderid: 1,
      orderlb: "byChar",
      thname: "专家",
      field: "professor"
    }, {
      width: 150,
      orderid: 2,
      orderlb: "byNum",
      thname: "客数",
      field: "custnum"
    }, {
      width: 200,
      orderid: 3,
      orderlb: "byNum",
      thname: "成交",
      field: "tprice"
    }, {
      width: 200,
      orderid: 4,
      orderlb: "byNum",
      thname: "收款",
      field: "receive1"
    }],
    thList2: [{
      width: 120,
      orderid: 1,
      orderlb: "byChar",
      thname: "专家",
      field: "professor"
    }, {
      width: 200,
      orderid: 2,
      orderlb: "byChar",
      thname: "美容院",
      field: "unitname"
    }, {
      width: 150,
      orderid: 3,
      orderlb: "byChar",
      thname: "客户",
      field: "name"
    }, {
      width: 120,
      orderid: 4,
      orderlb: "byNum",
      thname: "成交",
      field: "price1"
    }, {
      width: 160,
      orderid: 5,
      orderlb: "byDate",
      thname: "日期",
      field: "date"
    }],
    thList3: [{
      width: 120,
      orderid: 1,
      orderlb: "byChar",
      thname: "专家",
      field: "professor"
    }, {
      width: 200,
      orderid: 2,
      orderlb: "byChar",
      thname: "美容院",
      field: "unitname"
    }, {
      width: 150,
      orderid: 3,
      orderlb: "byChar",
      thname: "产品",
      field: "product"
    }, {
      width: 120,
      orderid: 4,
      orderlb: "byNum",
      thname: "金额",
      field: "tprice"
    }, {
      width: 160,
      orderid: 5,
      orderlb: "byDate",
      thname: "日期",
      field: "date"
    }],
    thList5: [{
      width: 120,
      orderid: 1,
      orderlb: "byChar",
      thname: "专家",
      field: "professor"
    }, {
      width: 200,
      orderid: 2,
      orderlb: "byChar",
      thname: "美容院",
      field: "unitname"
    }, {
      width: 150,
      orderid: 3,
      orderlb: "byNum",
      thname: "成交",
      field: "price1"
    }, {
      width: 120,
      orderid: 4,
      orderlb: "byNum",
      thname: "欠款",
      field: "price2"
    }, {
      width: 160,
      orderid: 5,
      orderlb: "byDate",
      thname: "日期",
      field: "date"
    }],
    thList4: [{
      width: 120,
      orderid: 1,
      orderlb: "byChar",
      thname: "专家",
      field: "professor"
    }, {
      width: 200,
      orderid: 2,
      orderlb: "byChar",
      thname: "美容院",
      field: "unitname"
    }, {
      width: 150,
      orderid: 3,
      orderlb: "byChar",
      thname: "客户",
      field: "name"
    }, {
      width: 120,
      orderid: 4,
      orderlb: "byNum",
      thname: "收款",
      field: "receive"
    }, {
      width: 160,
      orderid: 5,
      orderlb: "byDate",
      thname: "日期",
      field: "date"
    }],
    btnList: "",
    where: {
      date: "",
      professor: ""
    },
    pickList: [],
    monthInfo: {},
    saleList: [],
    journalList: [],
    receiveList: [],
    professorData: [],
    mydepartList: []
  },
  onLoad: function(t) {
    console.log("page:", "6summary/month/monthpa_index");
    for (var a = [], i = 0, n = -3; n <= 0; n++) {
      var d = r.getMonthdate(n + 1),
        o = new Date(d[0]).getMonth() + 1 + "月";
      0 == n && (o = "本月"), a[i] = {
        index: d[0],
        btnname: o
      }, i++
    }
    var h = r.getMonthdate(1)[0];
    this.setData(e(e({
      btnList: a
    }, "where.date", h), "where.professor", r.userInfo().staff))
  },
  DateChange: function(t) {
    var r = t.detail.value;
    this.setData(e({}, "where.date", r)), this.getDatalist()
  },
  clickBtn: function(t) {
    var r = t.currentTarget.dataset.index;
    this.setData(e({}, "where.date", r)), this.getDatalist()
  },
  clickTab: function(e) {
    var t = e.detail.data.index;
    this.setData({
      cIndex: t
    })
  },
  getDatalist: function() {
    var e = this,
      a = {
        date: this.data.where.date,
        professor: this.data.where.professor
      };
    r.Post(t.dataApi + "summary/professoramonth_start", a, (function(t) {
      if (200 == t.code) {
        var a, i = t.data.journalList,
          n = t.data.receiveList,
          d = [],
          o = [r.userInfo().staff];
        if (d.push({
            id: 0,
            professor: o[0],
            custnum: 0,
            zhen1: 0,
            zhena1: 0,
            zhen2: 0,
            zhena2: 0,
            zhen3: 0,
            zhena3: 0,
            zhen4: 0,
            zhena4: 0,
            tprice1: 0,
            tprice2: 0,
            tprice3: 0,
            tprice4: 0,
            tprice: 0,
            receive1: 0,
            receive2: 0,
            receive: 0,
            miaosha: 0
          }), i.length > 0) {
          var h = {};
          i.forEach((function(e) {
            h[e.professor] = h[e.professor] || [], h[e.professor].push(e)
          })), o.forEach((function(e) {
            null == h[e] && (h[e] = [])
          })), o.forEach((function(e) {
            var t = 0,
              r = 0,
              a = 0,
              i = 0,
              n = 0,
              o = 0,
              s = 0,
              c = 0,
              f = 0,
              l = 0,
              u = 0,
              p = 0,
              m = 0;
            h[e].forEach((function(e) {
              t += 1, 1 * e.price1, 1 == e.zhena && 1 == e.zhenb && (r += 1, l += 1 * e.price1, e.price1 > 0 && (o += 1)), 1 == e.zhena && 0 == e.zhenb && (a += 1, u += 1 * e.price1, e.price1 > 0 && (s += 1)), 0 == e.zhena && 1 == e.zhenb && (i += 1, p += 1 * e.price1, e.price1 > 0 && (c += 1)), 0 == e.zhena && 0 == e.zhenb && (n += 1, m += 1 * e.price1, e.price1 > 0 && (f += 1))
            }));
            var b = d.indexOf(d.filter((function(t) {
                return t.professor == e
              }))[0]),
              v = d[b];
            v.custnum = t, v.zhen1 = r, v.zhena1 = o, v.zhen2 = a, v.zhena2 = s, v.zhen3 = i, v.zhena3 = c, v.zhen4 = n, v.zhena4 = f, v.tprice1 = l, v.tprice2 = u, v.tprice3 = p, v.tprice4 = m, v.tprice = l + u + p + m, d[b] = v
          }))
        }
        if (n.length > 0) {
          h = {};
          n.forEach((function(e) {
            h[e.professor] = h[e.professor] || [], h[e.professor].push(e)
          })), o.forEach((function(e) {
            null == h[e] && (h[e] = [])
          })), o.forEach((function(e) {
            var t = 0,
              r = 0;
            h[e].forEach((function(e) {
              0 == e.salelb && (t += 1 * e.receive), 1 == e.salelb && (r += 1 * e.receive)
            }));
            var a = d.indexOf(d.filter((function(t) {
                return t.professor == e
              }))[0]),
              i = d[a];
            i.receive1 = t, i.receive2 = r, d[a] = i
          }))
        }
        var s = 0,
          c = 0,
          f = 0,
          l = 0,
          u = 0,
          p = 0,
          m = 0,
          b = 0,
          v = 0,
          w = 0,
          z = 0,
          g = 0,
          y = 0,
          L = 0,
          D = 0,
          C = 0;
        d.forEach((function(e) {
          s += e.custnum, c += e.zhen1, f += e.zhen2, l += e.zhen3, u += e.zhen4, p += e.zhena1, m += e.zhena2, b += e.zhena3, v += e.zhena4, w += e.tprice1, z += e.tprice2, g += e.tprice3, y += e.tprice4, L += e.receive1, D += e.receive2, C += e.miaosha
        })), a = {
          tcustnum: s,
          tzhen1: c,
          tzhen2: f,
          tzhen3: l,
          tzhen4: u,
          tzhena1: p,
          tzhena2: m,
          tzhena3: b,
          tzhena4: v,
          ttprice1: w,
          ttprice2: z,
          ttprice3: g,
          ttprice4: y,
          ttprice: w + z + g + y,
          treceive1: L,
          treceive2: D,
          treceive: L + D,
          tmiaosha: C
        }, e.setData({
          monthInfo: t.data.monthInfo,
          saleList: t.data.saleList,
          receiveList: t.data.receiveList,
          journalList: i,
          professorData: d,
          total: a
        })
      }
    }))
  },
  editinfo: function(e) {
    if (null == this.data.monthInfo.id) return r.showTip("请选择部门！"), !1;
    var t = e.currentTarget.dataset.field,
      a = this.data.monthInfo.id,
      i = this.data.monthInfo[t],
      n = "";
    console.log("note", i), "msummary" == t && (n = this.data.where.professor + "-月度总结"), "mgoal" == t && (n = this.data.where.professor + "-月度计划");
    var d = {
      id: a,
      table: "c_promonth",
      field: t,
      note: i,
      title: n
    };
    wx.navigateTo({
      url: "/pages/9public/note/note_edit?info=" + JSON.stringify(d)
    })
  },
  scrollgo: function(e) {
    this.setData({
      scrollX: e.detail.scrollLeft
    })
  },
  showPicker: function(e) {
    var t = this.data[e.currentTarget.dataset.arr];
    t && t.length > 0 && ("mydepartList" == e.currentTarget.dataset.arr && t.forEach((function(e) {
      e.option = e.depart
    })), this.setData({
      pickList: t,
      show_picker: !0,
      picker: e.currentTarget.dataset.arr
    }))
  },
  getSelect: function(t) {
    "mydepartList" == this.data.picker && this.setData(e(e({}, "where.departid", t.detail.data.departid), "where.depart", t.detail.data.depart))
  },
  inputChange: function(t) {
    var r = t.currentTarget.dataset.item;
    this.setData(e({}, r, t.detail.value))
  },
  clickLine: function(t) {
    var a, i = t.currentTarget.dataset.item.id,
      n = t.currentTarget.dataset.arr;
    a = r.selectChange(this.data[n], i), this.setData(e({}, n, a))
  },
  getOrder: function(t) {
    var r = t.detail.data,
      a = t.currentTarget.dataset.arr;
    this.setData(e({}, a, r))
  },
  getOrder2: function(e) {
    var t = e.currentTarget.dataset.field,
      a = r.orderBy(this.data.professorData, t, "byNum", 0);
    this.setData({
      professorData: a,
      field: t
    })
  }
});