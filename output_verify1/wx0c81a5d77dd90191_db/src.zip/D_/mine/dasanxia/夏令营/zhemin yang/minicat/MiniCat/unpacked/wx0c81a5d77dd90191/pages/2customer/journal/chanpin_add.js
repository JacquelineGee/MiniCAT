var t = require("../../../@babel/runtime/helpers/interopRequireDefault").default,
  a = require("../../../@babel/runtime/helpers/defineProperty"),
  e = t(require("../../../utils/myfunc.js")),
  i = require("../../../apiconfig");
Page({
  data: {
    editInfo: {},
    addInfo: {},
    indexList: [],
    productList: "",
    cpIndex: 0
  },
  onLoad: function(t) {
    console.log("page:", "2customer/journal/chanpin_add");
    var a = JSON.parse(t.info);
    this.setData({
      editInfo: a
    });
    var i = this;
    this.getDatalist(), e.default.getList("productList").then((function(t) {
      i.setData({
        productList: t.data
      })
    }))
  },
  getDatalist: function() {
    var t = this,
      a = {
        token: e.default.userInfo().token,
        jid: this.data.editInfo.id
      };
    e.default.Post(i.dataApi + "eproduct/eproductbyjid_list", a, (function(a) {
      if (200 == a.code) {
        var e = 0,
          i = 0;
        a.data.length > 0 && (e = a.data.reduce((function(t, a) {
          return t + 1 * a.amount
        }), 0), i = a.data.reduce((function(t, a) {
          return t + 1 * a.tprice
        }), 0));
        var d = "数量:" + e + "， 金额:" + i;
        t.setData({
          indexList: a.data,
          msg: d
        })
      }
    }))
  },
  saveAdd: function(t) {
    var a = this;
    if (0 == e.default.inputCheck(this.data.addInfo.product, "char")) return e.default.showTip("请选择产品！"), !1;
    if (0 == e.default.inputCheck(this.data.addInfo.amount, "number")) return e.default.showTip("请输入产品数量！"), !1;
    if (0 == e.default.inputCheck(this.data.addInfo.tprice, "number")) return e.default.showTip("请输入金额！"), !1;
    var d = {
      token: e.default.userInfo().token,
      unitid: this.data.editInfo.unitid,
      staff: this.data.editInfo.staff,
      professor: this.data.editInfo.professor,
      date: this.data.editInfo.date,
      jid: this.data.editInfo.id,
      cid: this.data.editInfo.cid,
      name: this.data.editInfo.name,
      product: this.data.addInfo.product,
      amount: this.data.addInfo.amount,
      tprice: this.data.addInfo.tprice
    };
    wx.showLoading({
      title: "保存中",
      mask: "true"
    }), e.default.Post(i.dataApi + "eproduct/eproduct_add", d, (function(t) {
      if (wx.hideLoading(), 200 == t.code) {
        var e = 0,
          i = 0;
        t.data.length > 0 && (e = t.data.reduce((function(t, a) {
          return t + 1 * a.amount
        }), 0), i = t.data.reduce((function(t, a) {
          return t + 1 * a.tprice
        }), 0));
        var d = "数量:" + e + "， 金额:" + i;
        a.setData({
          indexList: t.data,
          msg: d
        }), wx.showModal({
          title: "系统提示",
          content: "保存成功！",
          showCancel: !1,
          success: function(t) {}
        })
      } else wx.showToast({
        title: t.msg,
        icon: "error"
      })
    }))
  },
  toDel: function(t) {
    var a = t.currentTarget.dataset.item,
      d = e.default.userInfo(),
      n = this;
    wx.showModal({
      title: "温馨提示",
      content: "您确定要删除吗？",
      success: function(t) {
        if (t.confirm) {
          var o = {
            token: d.token,
            id: a.id
          };
          e.default.Post(i.dataApi + "eproduct/eproduct_del", o, (function(t) {
            200 == t.code ? (wx.showToast({
              title: "删除成功!"
            }), n.getDatalist()) : wx.showToast({
              title: "删除失败!",
              icon: "error"
            })
          }))
        }
      }
    })
  },
  showPicker: function(t) {
    var a = this.data[t.currentTarget.dataset.item];
    null == a || ("productList" == t.currentTarget.dataset.item && a.forEach((function(t) {
      t.option = t.product
    })), this.setData({
      pickList: a,
      show_picker: !0,
      picker: t.currentTarget.dataset.item
    }))
  },
  getSelect: function(t) {
    "productList" == this.data.picker && this.setData(a(a(a(a({}, "addInfo.product", t.detail.data.product), "addInfo.amount", 1), "addInfo.uprice", t.detail.data.price), "addInfo.tprice", 1 * t.detail.data.price))
  },
  inputChange: function(t) {
    var e = t.currentTarget.dataset.key;
    this.setData(a({}, e, t.detail.value)), "addInfo.amount" == e && this.setData(a({}, "addInfo.tprice", t.detail.value * this.data.addInfo.uprice))
  }
});