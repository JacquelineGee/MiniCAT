var t = require("../../../apiconfig"),
  e = require("../../../utils/myfunc.js");
Page({
  data: {
    szlbList: [{
      value: "收入"
    }, {
      value: "支出"
    }],
    szlb: "支出",
    data: "",
    pettyList: "",
    cIndex: "0",
    power: "",
    index1: 1
  },
  onLoad: function(t) {
    var e = this.getFirstDay(2);
    this.setData({
      date: e
    })
  },
  clickBtn: function(t) {
    var e = t.currentTarget.dataset.index,
      a = this.getFirstDay(e);
    this.setData({
      cIndex: e,
      date: a
    }), this.getPettyList(a)
  },
  getFirstDay: function(t) {
    var e = new Date,
      a = e.getFullYear(),
      i = e.getMonth() + Number(t) - 1;
    return i < 10 && (i = "0" + i), a + "-" + i + "-01"
  },
  getPettyList: function(a) {
    var i = this,
      s = {
        token: e.userInfo().token,
        szlb: this.data.szlb,
        date: a
      };
    e.Post(t.dataApi + "petty/petty_list", s, (function(t) {
      if (200 == t.code) {
        var e = t.data;
        null != e && e.length > 0 && e.forEach((function(t) {
          "支出" == t.szlb ? t.number = t.num_out : t.number = t.num_in
        })), i.setData({
          pettyList: e,
          msg: t.msg
        })
      }
    }))
  },
  pickSzlb: function(t) {
    var e = t.detail.value;
    this.setData({
      index1: e,
      szlb: this.data.szlbList[e].value
    }), this.getPettyList(this.data.date)
  },
  pickDate: function(t) {
    var e = t.detail.value;
    this.setData({
      date: e
    }), this.getPettyList(e)
  }
});