var e = require("../../../@babel/runtime/helpers/defineProperty"),
  t = require("../../../apiconfig"),
  a = require("../../../utils/myfunc.js");
Page({
  data: {
    navList: [{
      title: "总结概况",
      index: "1"
    }, {
      title: "见诊记录",
      index: "2"
    }, {
      title: "产品搭配",
      index: "3"
    }, {
      title: "收款记录",
      index: "4"
    }, {
      title: "门店秒杀",
      index: "5"
    }],
    cIndex: 1,
    thList: [{
      width: 200,
      orderid: 1,
      orderlb: "byChar",
      thname: "员工",
      field: "staff"
    }, {
      width: 150,
      orderid: 2,
      orderlb: "byNum",
      thname: "客数",
      field: "custnum"
    }, {
      width: 200,
      orderid: 3,
      orderlb: "byNum",
      thname: "成交",
      field: "tprice"
    }, {
      width: 200,
      orderid: 4,
      orderlb: "byNum",
      thname: "收款",
      field: "receive1"
    }],
    thList2: [{
      width: 120,
      orderid: 1,
      orderlb: "byChar",
      thname: "员工",
      field: "staff"
    }, {
      width: 200,
      orderid: 2,
      orderlb: "byChar",
      thname: "美容院",
      field: "unitname"
    }, {
      width: 150,
      orderid: 3,
      orderlb: "byChar",
      thname: "客户",
      field: "name"
    }, {
      width: 120,
      orderid: 4,
      orderlb: "byNum",
      thname: "成交",
      field: "price1"
    }, {
      width: 160,
      orderid: 5,
      orderlb: "byDate",
      thname: "日期",
      field: "date"
    }],
    thList3: [{
      width: 120,
      orderid: 1,
      orderlb: "byChar",
      thname: "员工",
      field: "staff"
    }, {
      width: 200,
      orderid: 2,
      orderlb: "byChar",
      thname: "美容院",
      field: "unitname"
    }, {
      width: 150,
      orderid: 3,
      orderlb: "byChar",
      thname: "产品",
      field: "product"
    }, {
      width: 120,
      orderid: 4,
      orderlb: "byNum",
      thname: "金额",
      field: "tprice"
    }, {
      width: 160,
      orderid: 5,
      orderlb: "byDate",
      thname: "日期",
      field: "date"
    }],
    thList5: [{
      width: 120,
      orderid: 1,
      orderlb: "byChar",
      thname: "员工",
      field: "staff"
    }, {
      width: 200,
      orderid: 2,
      orderlb: "byChar",
      thname: "美容院",
      field: "unitname"
    }, {
      width: 150,
      orderid: 3,
      orderlb: "byNum",
      thname: "成交",
      field: "price1"
    }, {
      width: 120,
      orderid: 4,
      orderlb: "byNum",
      thname: "欠款",
      field: "price2"
    }, {
      width: 160,
      orderid: 5,
      orderlb: "byDate",
      thname: "日期",
      field: "date"
    }],
    thList4: [{
      width: 120,
      orderid: 1,
      orderlb: "byChar",
      thname: "员工",
      field: "staff"
    }, {
      width: 200,
      orderid: 2,
      orderlb: "byChar",
      thname: "美容院",
      field: "unitname"
    }, {
      width: 150,
      orderid: 3,
      orderlb: "byChar",
      thname: "客户",
      field: "name"
    }, {
      width: 120,
      orderid: 4,
      orderlb: "byNum",
      thname: "收款",
      field: "receive"
    }, {
      width: 160,
      orderid: 5,
      orderlb: "byDate",
      thname: "日期",
      field: "date"
    }],
    btnList: "",
    where: {
      date: "",
      staff: ""
    },
    pickList: [],
    monthInfo: {},
    saleList: [],
    journalList: [],
    miaoshaList: [],
    receiveList: [],
    staffData: [],
    mydepartList: []
  },
  onLoad: function(e) {
    console.log("page:", "6summary/month/monthb_index");
    for (var t = [], i = 0, r = -2; r <= 0; r++) {
      var d = a.getMonthdate(r + 1),
        n = new Date(d[0]).getMonth() + 1 + "月";
      0 == r && (n = "本月"), t[i] = {
        index: d[0],
        btnname: n
      }, i++
    }
    var h = a.getMonthdate(1)[0],
      o = a.userInfo().staff;
    this.setData({
      btnList: t,
      where: {
        date: h,
        staff: o
      }
    })
  },
  DateChange: function(t) {
    var a = t.detail.value;
    this.setData(e({}, "where.date", a)), this.getDatalist()
  },
  clickBtn: function(t) {
    var a = t.currentTarget.dataset.index;
    this.setData(e({}, "where.date", a)), this.getDatalist()
  },
  clickTab: function(e) {
    var t = e.detail.data.index;
    this.setData({
      cIndex: t
    })
  },
  getDatalist: function() {
    var e = this,
      i = this.data.where;
    a.Post(t.dataApi + "summary/staffmonth_start", i, (function(t) {
      if (200 == t.code) {
        var i = t.data.dailyList,
          r = t.data.journalList,
          d = t.data.miaoshaList,
          n = t.data.receiveList,
          h = [],
          o = [a.userInfo().staff],
          f = 0;
        if (r.length > 0) {
          var s = {};
          r.forEach((function(e) {
            s[e.staff] = s[e.staff] || [], s[e.staff].push(e)
          })), o.forEach((function(e) {
            null == s[e] && (s[e] = [])
          })), o.forEach((function(e) {
            f += 1;
            var t = 0,
              a = 0,
              i = 0,
              r = 0,
              d = 0,
              n = 0,
              o = 0,
              l = 0,
              c = 0,
              u = 0,
              m = 0,
              b = 0,
              p = 0,
              w = 0;
            s[e].forEach((function(e) {
              t += 1, w += 1 * e.price1, 1 == e.zhena && 1 == e.zhenb && (a += 1, u += 1 * e.price1, e.price1 > 0 && (n += 1)), 1 == e.zhena && 0 == e.zhenb && (i += 1, m += 1 * e.price1, e.price1 > 0 && (o += 1)), 0 == e.zhena && 1 == e.zhenb && (r += 1, b += 1 * e.price1, e.price1 > 0 && (l += 1)), 0 == e.zhena && 0 == e.zhenb && (d += 1, p += 1 * e.price1, e.price1 > 0 && (c += 1))
            })), h.push({
              id: f,
              staff: e,
              custnum: t,
              zhen1: a,
              zhena1: n,
              zhen2: i,
              zhena2: o,
              zhen3: r,
              zhena3: l,
              zhen4: d,
              zhena4: c,
              tprice1: u,
              tprice2: m,
              tprice3: b,
              tprice4: p,
              tprice: w
            })
          }))
        }
        if (d.length > 0 && (s = {}, d.forEach((function(e) {
            s[e.staff] = s[e.staff] || [], s[e.staff].push(e)
          })), o.forEach((function(e) {
            var t = 0;
            s[e].forEach((function(e) {
              t += 1 * e.price1
            })), h[0].miaosha = t
          }))), n.length > 0) {
          s = {};
          n.forEach((function(e) {
            s[e.staff] = s[e.staff] || [], s[e.staff].push(e)
          })), o.forEach((function(e) {
            var t = 0,
              a = 0;
            s[e].forEach((function(e) {
              0 == e.salelb && (t += 1 * e.receive), 1 == e.salelb && (a += 1 * e.receive)
            })), h[0].receive1 = t, h[0].receive2 = a
          }))
        }
        console.log("staffData", h), e.setData({
          monthInfo: t.data.monthInfo,
          saleList: t.data.saleList,
          receiveList: t.data.receiveList,
          journalList: r,
          miaoshaList: d,
          dailyList: i,
          staffData: h
        })
      }
    }))
  },
  inputChange: function(t) {
    var a = t.currentTarget.dataset.item;
    this.setData(e({}, a, t.detail.value))
  },
  clickLine: function(t) {
    var i, r = t.currentTarget.dataset.item.id,
      d = t.currentTarget.dataset.arr;
    i = a.selectChange(this.data[d], r), this.setData(e({}, d, i))
  },
  editinfo: function(e) {
    if (null == this.data.monthInfo.id) return a.showTip("请选择月份！"), !1;
    var t = e.currentTarget.dataset.field,
      i = this.data.monthInfo.id,
      r = this.data.monthInfo[t],
      d = "";
    console.log("note", r), "msummary" == t && (d = this.data.where.staff + "-月度总结"), "mgoal" == t && (d = this.data.where.staff + "-月度计划");
    var n = {
      id: i,
      table: "c_staffmonth",
      field: t,
      note: r,
      title: d
    };
    wx.navigateTo({
      url: "/pages/9public/note/note_edit?info=" + JSON.stringify(n)
    })
  },
  getOrder: function(t) {
    var a = t.detail.data,
      i = t.currentTarget.dataset.arr;
    this.setData(e({}, i, a))
  }
});