var t = require("../../../@babel/runtime/helpers/interopRequireDefault").default,
  e = require("../../../@babel/runtime/helpers/defineProperty"),
  a = t(require("../../../utils/myfunc.js")),
  i = require("../../../apiconfig");
Page({
  data: {
    indexList: [],
    where: {
      limit: 20,
      name: "",
      unitid: 0,
      unitname: "-美容院-",
      depart: "-部门-",
      departid: ""
    },
    unitList: "",
    mydepartList: ""
  },
  onLoad: function(t) {
    console.log("page:", "1work/customer/customerb_list");
    var e = this;
    a.default.getList("mydepartList").then((function(t) {
      e.setData({
        mydepartList: t.data
      })
    }))
  },
  getDepartunit: function(t) {
    var e = this;
    a.default.Post(i.dataApi + "datas/departunit_list", {
      departid: t
    }, (function(t) {
      200 == t.code && e.setData({
        unitList: t.data
      })
    }))
  },
  getDatalist: function() {
    var t = this,
      e = {
        limit: this.data.where.limit
      };
    if (!(this.data.where.unitid > 0)) return a.default.showTip("请选择美容院！"), !1;
    e.unitid = this.data.where.unitid, this.data.where.name.length > 0 && (e.name = this.data.where.name), a.default.Post(i.dataApi + "customer/mycustomer_list", e, (function(e) {
      var a = "计数:" + e.data.length;
      t.setData({
        indexList: e.data,
        msg: a
      })
    }))
  },
  clickLine: function(t) {
    var i, r = t.currentTarget.dataset.item.id,
      n = t.currentTarget.dataset.arr;
    i = a.default.selectChange(this.data[n], r), this.setData(e({}, n, i))
  },
  toAdd: function(t) {
    wx.navigateTo({
      url: "./customer_add"
    })
  },
  toEdit: function(t) {
    var e = t.currentTarget.dataset.item;
    wx.navigateTo({
      url: "./customer_edit?id=" + e.id
    })
  },
  toInfo: function(t) {
    var e = t.currentTarget.dataset.item;
    wx.navigateTo({
      url: "./customer_info?id=" + e.id
    })
  },
  showPicker: function(t) {
    var e = this.data[t.currentTarget.dataset.item];
    null == e || ("mydepartList" == t.currentTarget.dataset.item && e.forEach((function(t) {
      t.option = t.depart
    })), "unitList" == t.currentTarget.dataset.item && e.forEach((function(t) {
      t.option = t.unitname
    })), this.setData({
      pickList: e,
      show_picker: !0,
      picker: t.currentTarget.dataset.item
    }))
  },
  getSelect: function(t) {
    "mydepartList" == this.data.picker && (this.setData(e(e(e(e({}, "where.departid", t.detail.data.departid), "where.depart", t.detail.data.depart), "where.unitid", ""), "where.unitname", "-美容院-")), this.getDepartunit(t.detail.data.departid)), "unitList" == this.data.picker && this.setData(e(e({}, "where.unitid", t.detail.data.id), "where.unitname", t.detail.data.unitname))
  },
  inputChange: function(t) {
    var a = t.currentTarget.dataset.item;
    this.setData(e({}, a, t.detail.value))
  }
});