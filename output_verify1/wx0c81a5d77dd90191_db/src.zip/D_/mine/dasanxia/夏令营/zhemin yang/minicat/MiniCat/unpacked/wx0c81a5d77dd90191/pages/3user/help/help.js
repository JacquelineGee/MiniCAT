Page({
  data: {
    isShow: [{
      name: "what0",
      status: !1
    }, {
      name: "what1",
      status: !1
    }, {
      name: "what2",
      status: !1
    }, {
      name: "use3",
      status: !1
    }, {
      name: "use4",
      status: !1
    }, {
      name: "use5",
      status: !1
    }, {
      name: "use6",
      status: !1
    }, {
      name: "use7",
      status: !1
    }],
    systemInfo: {},
    imgArr: ["https://mrjgj.ltd/help/pic/7-1.jpg", "https://mrjgj.ltd/help/pic/7-2.jpg"]
  },
  onLoad: function(t) {
    var s = this;
    wx.getSystemInfo({
      success: function(t) {
        console.log(t), s.setData({
          systemInfo: t
        })
      }
    })
  },
  showHide: function(t) {
    console.log(t.currentTarget.dataset);
    for (var s = t.currentTarget.dataset, a = s.name, e = this.data.isShow, n = 0; n < e.length; n++) s.name == e[n].name ? e[n].status ? e[n].status = !1 : e[n].status = !0 : e[n].status = !1;
    this.setData({
      isShow: e,
      toView: a
    })
  },
  previewImage: function(t) {
    var s = t.target.dataset.src;
    wx.previewImage({
      current: s,
      urls: this.data.imgArr
    })
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {}
});