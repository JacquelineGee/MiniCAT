var e = getApp(),
  a = require("../../../apiconfig");
require("../../../utils/myfunc.js");
Page({
  data: {
    userInfo: {},
    agree: "",
    code: "",
    wxphonestate: 0
  },
  onLoad: function(a) {
    null != e.globalData.userInfo.wxphone && e.globalData.userInfo.wxphone.length > 8 && this.setData({
      wxphonestate: 1
    })
  },
  getcode: function() {
    var e = this;
    wx.login({
      success: function(a) {
        console.log("code1", a.code), e.setData({
          code: a.code
        })
      }
    }), console.log("code2", this.data)
  },
  getPhoneNumber: function(e) {
    var t = e.detail.encryptedData,
      o = e.detail.iv,
      n = this.data.code,
      d = this;
    console.log("code3", this.data), wx.request({
      url: a.dataApi + "login/getphonebyCode",
      method: "POST",
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      data: {
        encryptedData: t,
        iv: o,
        code: n,
        wx_id: d.data.userInfo.wx_id,
        unitid: d.data.userInfo.unitid
      },
      success: function(e) {
        200 == e.data.code ? (getApp().globalData.userInfo = e.data.data, console.log("用户数据phone"), wx.setStorageSync("userInfo", e.data.data), d.toapply()) : console.log(e.data.code)
      }
    })
  },
  checkboxChange: function(e) {
    console.log("checkbox发生change事件，携带value值为：", e.detail.value), 1 == e.detail.value[0] || (e.detail.value[0] = 0), this.setData({
      agree: e.detail.value[0]
    })
  },
  toapply: function() {
    wx.navigateTo({
      url: "/pages/3user/myapply/addapply"
    })
  }
});