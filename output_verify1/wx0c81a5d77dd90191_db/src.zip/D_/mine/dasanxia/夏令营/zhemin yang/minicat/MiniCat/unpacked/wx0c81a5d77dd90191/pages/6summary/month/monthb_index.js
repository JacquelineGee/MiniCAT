var t = require("../../../@babel/runtime/helpers/defineProperty"),
  e = require("../../../apiconfig"),
  a = require("../../../utils/myfunc.js");
Page({
  data: {
    navList: [{
      title: "总结概况",
      index: "1"
    }, {
      title: "见诊记录",
      index: "2"
    }, {
      title: "产品搭配",
      index: "3"
    }, {
      title: "收款记录",
      index: "4"
    }, {
      title: "门店秒杀",
      index: "5"
    }],
    cIndex: 1,
    thList: [{
      width: 200,
      orderid: 1,
      orderlb: "byChar",
      thname: "员工",
      field: "staff"
    }, {
      width: 150,
      orderid: 2,
      orderlb: "byNum",
      thname: "客数",
      field: "custnum"
    }, {
      width: 200,
      orderid: 3,
      orderlb: "byNum",
      thname: "成交",
      field: "tprice"
    }, {
      width: 200,
      orderid: 4,
      orderlb: "byNum",
      thname: "收款",
      field: "receive1"
    }],
    thList2: [{
      width: 120,
      orderid: 1,
      orderlb: "byChar",
      thname: "员工",
      field: "staff"
    }, {
      width: 200,
      orderid: 2,
      orderlb: "byChar",
      thname: "美容院",
      field: "unitname"
    }, {
      width: 150,
      orderid: 3,
      orderlb: "byChar",
      thname: "客户",
      field: "name"
    }, {
      width: 120,
      orderid: 4,
      orderlb: "byNum",
      thname: "成交",
      field: "price1"
    }, {
      width: 160,
      orderid: 5,
      orderlb: "byDate",
      thname: "日期",
      field: "date"
    }],
    thList3: [{
      width: 120,
      orderid: 1,
      orderlb: "byChar",
      thname: "员工",
      field: "staff"
    }, {
      width: 200,
      orderid: 2,
      orderlb: "byChar",
      thname: "美容院",
      field: "unitname"
    }, {
      width: 150,
      orderid: 3,
      orderlb: "byChar",
      thname: "产品",
      field: "product"
    }, {
      width: 120,
      orderid: 4,
      orderlb: "byNum",
      thname: "金额",
      field: "tprice"
    }, {
      width: 160,
      orderid: 5,
      orderlb: "byDate",
      thname: "日期",
      field: "date"
    }],
    thList5: [{
      width: 120,
      orderid: 1,
      orderlb: "byChar",
      thname: "员工",
      field: "staff"
    }, {
      width: 200,
      orderid: 2,
      orderlb: "byChar",
      thname: "美容院",
      field: "unitname"
    }, {
      width: 150,
      orderid: 3,
      orderlb: "byNum",
      thname: "成交",
      field: "price1"
    }, {
      width: 120,
      orderid: 4,
      orderlb: "byNum",
      thname: "欠款",
      field: "price2"
    }, {
      width: 160,
      orderid: 5,
      orderlb: "byDate",
      thname: "日期",
      field: "date"
    }],
    thList4: [{
      width: 120,
      orderid: 1,
      orderlb: "byChar",
      thname: "员工",
      field: "staff"
    }, {
      width: 200,
      orderid: 2,
      orderlb: "byChar",
      thname: "美容院",
      field: "unitname"
    }, {
      width: 150,
      orderid: 3,
      orderlb: "byChar",
      thname: "客户",
      field: "name"
    }, {
      width: 120,
      orderid: 4,
      orderlb: "byNum",
      thname: "收款",
      field: "receive"
    }, {
      width: 160,
      orderid: 5,
      orderlb: "byDate",
      thname: "日期",
      field: "date"
    }],
    btnList: "",
    where: {
      date: "",
      depart: "-部门-",
      departid: ""
    },
    pickList: [],
    monthInfo: {},
    saleList: [],
    journalList: [],
    miaoshaList: [],
    receiveList: [],
    staffData: [],
    mydepartList: []
  },
  onLoad: function(e) {
    console.log("page:", "6summary/month/monthb_index");
    for (var r = [], i = 0, d = -2; d <= 0; d++) {
      var n = a.getMonthdate(d + 1),
        h = new Date(n[0]).getMonth() + 1 + "月";
      0 == d && (h = "本月"), r[i] = {
        index: n[0],
        btnname: h
      }, i++
    }
    var o = a.getMonthdate(1)[0];
    this.setData(t({
      btnList: r
    }, "where.date", o));
    var s = this;
    console.log("data"), a.getList("mydepartList").then((function(t) {
      s.setData({
        mydepartList: t.data
      })
    }))
  },
  DateChange: function(e) {
    var a = e.detail.value;
    this.setData(t({}, "where.date", a)), this.getDatalist()
  },
  clickBtn: function(e) {
    var a = e.currentTarget.dataset.index;
    this.setData(t({}, "where.date", a)), this.getDatalist()
  },
  clickTab: function(t) {
    var e = t.detail.data.index;
    this.setData({
      cIndex: e
    })
  },
  getDatalist: function() {
    var t = this,
      r = {
        date: this.data.where.date
      };
    if (!(this.data.where.depart.length > 0 && "-部门-" != this.data.where.depart)) return a.showTip("请选择部门！"), !1;
    r.departid = this.data.where.departid, a.Post(e.dataApi + "summary/departmonth_start", r, (function(e) {
      if (200 == e.code) {
        var a, r = e.data.dailyList,
          i = e.data.journalList,
          d = e.data.miaoshaList,
          n = e.data.receiveList,
          h = e.data.staffList,
          o = [],
          s = 0,
          f = [];
        if (h.length > 0 && (h.forEach((function(t) {
            o.push({
              id: s,
              staff: t.staff,
              departid: t.departid,
              custnum: 0,
              zhen1: 0,
              zhena1: 0,
              zhen2: 0,
              zhena2: 0,
              zhen3: 0,
              zhena3: 0,
              zhen4: 0,
              zhena4: 0,
              tprice1: 0,
              tprice2: 0,
              tprice3: 0,
              tprice4: 0,
              tprice: 0,
              receive1: 0,
              receive2: 0,
              receive: 0,
              miaosha: 0
            }), s += 1
          })), f = h.map((function(t) {
            return t.staff
          }))), i.length > 0) {
          var c = {};
          i.forEach((function(t) {
            c[t.staff] = c[t.staff] || [], c[t.staff].push(t)
          })), f.forEach((function(t) {
            null == c[t] && (c[t] = [])
          })), f.forEach((function(t) {
            var e = 0,
              a = 0,
              r = 0,
              i = 0,
              d = 0,
              n = 0,
              h = 0,
              s = 0,
              f = 0,
              l = 0,
              u = 0,
              m = 0,
              p = 0;
            c[t].forEach((function(t) {
              e += 1, 1 * t.price1, 1 == t.zhena && 1 == t.zhenb && (a += 1, l += 1 * t.price1, t.price1 > 0 && (n += 1)), 1 == t.zhena && 0 == t.zhenb && (r += 1, u += 1 * t.price1, t.price1 > 0 && (h += 1)), 0 == t.zhena && 1 == t.zhenb && (i += 1, m += 1 * t.price1, t.price1 > 0 && (s += 1)), 0 == t.zhena && 0 == t.zhenb && (d += 1, p += 1 * t.price1, t.price1 > 0 && (f += 1))
            }));
            var b = o.indexOf(o.filter((function(e) {
                return e.staff == t
              }))[0]),
              v = o[b];
            v.custnum = e, v.zhen1 = a, v.zhena1 = n, v.zhen2 = r, v.zhena2 = h, v.zhen3 = i, v.zhena3 = s, v.zhen4 = d, v.zhena4 = f, v.tprice1 = l, v.tprice2 = u, v.tprice3 = m, v.tprice4 = p, v.tprice = l + u + m + p, o[b] = v
          }))
        }
        if (d.length > 0 && (c = {}, d.forEach((function(t) {
            c[t.staff] = c[t.staff] || [], c[t.staff].push(t)
          })), f.forEach((function(t) {
            null == c[t] && (c[t] = [])
          })), f.forEach((function(t) {
            var e = 0;
            c[t].forEach((function(t) {
              e += 1 * t.price1
            }));
            var a = o.indexOf(o.filter((function(e) {
                return e.staff == t
              }))[0]),
              r = o[a];
            r.miaosha = e, o[a] = r
          })), console.log("staffData", o)), n.length > 0) {
          c = {};
          n.forEach((function(t) {
            c[t.staff] = c[t.staff] || [], c[t.staff].push(t)
          })), f.forEach((function(t) {
            null == c[t] && (c[t] = [])
          })), f.forEach((function(t) {
            var e = 0,
              a = 0;
            c[t].forEach((function(t) {
              0 == t.salelb && (e += 1 * t.receive), 1 == t.salelb && (a += 1 * t.receive)
            }));
            var r = o.indexOf(o.filter((function(e) {
                return e.staff == t
              }))[0]),
              i = o[r];
            i.receive1 = e, i.receive2 = a, o[r] = i
          }))
        }
        var l = 0,
          u = 0,
          m = 0,
          p = 0,
          b = 0,
          v = 0,
          w = 0,
          g = 0,
          z = 0,
          y = 0,
          L = 0,
          D = 0,
          x = 0,
          C = 0,
          E = 0,
          T = 0;
        o.forEach((function(t) {
          l += t.custnum, u += t.zhen1, m += t.zhen2, p += t.zhen3, b += t.zhen4, v += t.zhena1, w += t.zhena2, g += t.zhena3, z += t.zhena4, y += t.tprice1, L += t.tprice2, D += t.tprice3, x += t.tprice4, C += t.receive1, E += t.receive2, T += t.miaosha
        })), a = {
          tcustnum: l,
          tzhen1: u,
          tzhen2: m,
          tzhen3: p,
          tzhen4: b,
          tzhena1: v,
          tzhena2: w,
          tzhena3: g,
          tzhena4: z,
          ttprice1: y,
          ttprice2: L,
          ttprice3: D,
          ttprice4: x,
          ttprice: y + L + D + x,
          treceive1: C,
          treceive2: E,
          treceive: C + E,
          tmiaosha: T
        }, t.setData({
          monthInfo: e.data.monthInfo,
          saleList: e.data.saleList,
          receiveList: e.data.receiveList,
          journalList: i,
          miaoshaList: d,
          dailyList: r,
          staffData: o,
          total: a
        })
      }
    }))
  },
  scrollgo: function(t) {
    this.setData({
      scrollX: t.detail.scrollLeft
    })
  },
  showPicker: function(t) {
    var e = this.data[t.currentTarget.dataset.arr];
    e && e.length > 0 && ("mydepartList" == t.currentTarget.dataset.arr && e.forEach((function(t) {
      t.option = t.depart
    })), this.setData({
      pickList: e,
      show_picker: !0,
      picker: t.currentTarget.dataset.arr
    }))
  },
  getSelect: function(e) {
    "mydepartList" == this.data.picker && this.setData(t(t({}, "where.departid", e.detail.data.departid), "where.depart", e.detail.data.depart))
  },
  inputChange: function(e) {
    var a = e.currentTarget.dataset.item;
    this.setData(t({}, a, e.detail.value))
  },
  clickLine: function(e) {
    var r, i = e.currentTarget.dataset.item.id,
      d = e.currentTarget.dataset.arr;
    r = a.selectChange(this.data[d], i), this.setData(t({}, d, r))
  },
  editinfo: function(t) {
    if (null == this.data.monthInfo.id) return a.showTip("请选择部门！"), !1;
    var e = t.currentTarget.dataset.field,
      r = this.data.monthInfo.id,
      i = this.data.monthInfo[e],
      d = "";
    console.log("note", i), "msummary" == e && (d = this.data.where.depart + "-月度总结"), "mgoal" == e && (d = this.data.where.depart + "-月度计划");
    var n = {
      id: r,
      table: "c_departmonth",
      field: e,
      note: i,
      title: d
    };
    wx.navigateTo({
      url: "/pages/9public/note/note_edit?info=" + JSON.stringify(n)
    })
  },
  getOrder: function(e) {
    var a = e.detail.data,
      r = e.currentTarget.dataset.arr;
    this.setData(t({}, r, a))
  },
  getOrder2: function(t) {
    var e = t.currentTarget.dataset.field,
      r = a.orderBy(this.data.staffData, e, "byNum", 0);
    this.setData({
      staffData: r,
      field: e
    })
  }
});