var t = require("../@babel/runtime/helpers/interopRequireDefault").default,
  e = t(require("./config.js")),
  n = (t(require("../regenerator-runtime/runtime.js")), require("../apiconfig"));
module.exports = {
  sysData: function(t) {
    if ("unitlb" == t) return [{
      value: "合作"
    }, {
      value: "跟进"
    }, {
      value: "无效"
    }]
  },
  getInfobyId: function(t, e) {
    var o = "",
      a = wx.getStorageSync("userInfo");
    return a && a.token.length > 10 && (o = a.token), new Promise((function(a) {
      wx.request({
        url: n.dataApi + "datas/getInfobyid",
        method: "POST",
        header: {
          Authorization: o
        },
        data: {
          token: getApp().globalData.userInfo.token,
          table: t,
          id: e
        },
        success: function(t) {
          a(t.data.data)
        }
      })
    }))
  },
  updatebyId: function(t, e, o) {
    var a = "",
      r = wx.getStorageSync("userInfo");
    r && r.token.length > 10 && (a = r.token);
    var u = {
      table: t,
      id: e,
      savestr: JSON.stringify(o)
    };
    return new Promise((function(t) {
      wx.request({
        url: n.dataApi + "datas/byid_update",
        method: "POST",
        header: {
          Authorization: a
        },
        data: u,
        success: function(e) {
          t(e.data)
        }
      })
    }))
  },
  getList: function(t) {
    var e = "",
      o = wx.getStorageSync("userInfo");
    o && o.token.length > 10 && (e = o.token);
    var a = {
        field: t
      },
      r = "";
    return "myunitList" == t && (r = "myunit_list"), "unitList" == t && (r = "unit_list"), "mydepartList" == t && (r = "mydepart_list"), "staffList" == t && (r = "staff_list"), "professorList" == t && (r = "professor_list"), "productList" == t && (r = "product_list"), "albumlb" == t && (r = "getlb_list"), "sharealbumlb" == t && (r = "sharealbumlb_list"), new Promise((function(t) {
      wx.request({
        url: n.dataApi + "datas/" + r,
        method: "POST",
        header: {
          Authorization: e
        },
        data: a,
        success: function(e) {
          t(e.data)
        }
      })
    }))
  },
  getcidList: function(t) {
    var e = "",
      o = wx.getStorageSync("userInfo");
    o && o.token.length > 10 && (e = o.token);
    var a = {
      unitid: t
    };
    return new Promise((function(t) {
      wx.request({
        url: n.dataApi + "datas/cid_list",
        method: "POST",
        header: {
          Authorization: e
        },
        data: a,
        success: function(e) {
          t(e.data)
        }
      })
    }))
  },
  getInfo: function(t, e) {
    var o = "",
      a = wx.getStorageSync("userInfo");
    a && a.token.length > 10 && (o = a.token);
    var r = {
      table: t,
      id: e
    };
    return new Promise((function(t) {
      wx.request({
        url: n.dataApi + "datas/byid_info",
        method: "POST",
        header: {
          Authorization: o
        },
        data: r,
        success: function(e) {
          t(e.data)
        }
      })
    }))
  },
  GetDateStr: function(t) {
    var e = new Date;
    e.setDate(e.getDate() + t);
    var n = e.getFullYear(),
      o = e.getMonth() + 1;
    o < 10 && (o = "0" + o);
    var a = e.getDate();
    return a < 10 && (a = "0" + a), n + "-" + o + "-" + a
  },
  getMonthdate: function(t) {
    var e, n = new Date,
      o = n.getFullYear(),
      a = n.getMonth(),
      r = (a + t) % 12;
    return r < 0 ? (r += 12, e = o + Math.floor((a + t) / 12)) : 0 == r ? (r = 12, e = o - 1 + Math.floor((a + t) / 12)) : r > 0 && (e = o + Math.floor((a + t) / 12)), r < 10 && (r = "0" + r), [e + "-" + r + "-01", e + "-" + r + "-" + new Date(e, r, 0).getDate()]
  },
  getBdays: function(t) {
    var e = new Date,
      n = e.getFullYear(),
      o = new Date(n, t.split("-")[1] - 1, t.split("-")[2]);
    o < e && o.setFullYear(e.getFullYear() + 1);
    var a = (o - e) / 864e5;
    return Math.ceil(a)
  },
  getdaysbyDate: function(t) {
    var e = (new Date - new Date(t.split("-")[0], t.split("-")[1] - 1, t.split("-")[2])) / 864e5;
    return Math.ceil(e)
  },
  searchList: function(t, e) {
    var n = [],
      o = t.charAt(0),
      a = t.length;
    if (0 == a) return e;
    for (var r = 0; r < e.length; r++) {
      var u = e[r],
        i = !1;
      for (var s in u)
        if ("function" == typeof u[s]) u[s]();
        else {
          var c = "";
          null != u[s] && (c = u[s]);
          for (var l = 0; l < c.length; l++)
            if (c.charAt(l) == o && c.substring(l).substring(0, a) == t) {
              i = !0;
              break
            }
        } i && n.push(u)
    }
    return n
  },
  orderBy: function(t, e, n, o) {
    if (t && t.length > 0) return "byNum" == n ? t.sort((function(t, n) {
      return 1 == o ? t[e] - n[e] : n[e] - t[e]
    })) : "byChar" == n ? t.sort((function(t, n) {
      return 1 == o ? n[e].localeCompare(t[e], "zh") : t[e].localeCompare(n[e], "zh")
    })) : "byTime" == n ? t.sort((function(t, n) {
      return 1 == o ? n[e] > t[e] ? 1 : -1 : t[e] > n[e] ? 1 : -1
    })) : "byDate" == n && t.sort((function(t, n) {
      return null == t[e] || "" == t[e] ? 1 : null == n[e] || "" == n[e] ? -1 : 1 == o ? Date.parse(n[e]) - Date.parse(t[e]) : Date.parse(t[e]) - Date.parse(n[e])
    })), t
  },
  selectChange: function(t, e) {
    if (t.length) return t.forEach((function(t) {
      t.id == e && ("0" == t.select || null == t.select) ? t.select = "1" : t.select = "0"
    })), t
  },
  indexOf: function(t, e, n) {
    if (n.length > 2) {
      for (var o = 0; o < t.length; o++)
        if (t[o][n] == e) return o
    } else
      for (o = 0; o < t.length; o++)
        if (t[o] == e) return o;
    return -1
  },
  subTotal: function(t, e, n) {
    var o = [],
      a = {};
    return t.forEach((function(t) {
      a[t[e]] = a[t[e]] || [], a[t[e]].push(t)
    })), Object.keys(a).forEach((function(t) {
      var e = 0,
        r = 0;
      a[t].forEach((function(t) {
        e += t[n] ? 1 * t[n] : 0, r++
      })), o.push({
        key: t,
        sum: e,
        num: r
      })
    })), o
  },
  Post: function(t, e, n) {
    var o = "",
      a = wx.getStorageSync("userInfo");
    a && a.token.length > 10 && (o = a.token), wx.request({
      method: "POST",
      url: t,
      data: e,
      header: {
        Authorization: o
      },
      success: function(t) {
        "function" == typeof n && n(t.data, "")
      },
      fail: function(e) {
        "function" == typeof n && n(null, e.errMsg), console.log("post 请求:" + t), console.log(e)
      }
    })
  },
  promisestart: function() {
    return new Promise((function(t) {
      wx.login({
        success: function(o) {
          console.log("startcode", o.code), wx.request({
            url: n.loginApi + "startbyCode",
            method: "POST",
            data: {
              code: o.code,
              groupid: e.default.groupid
            },
            success: function(e) {
              getApp().globalData.userInfo = e.data.data, wx.setStorageSync("userInfo", e.data.data), console.log("promise resole", e.data.data), t(e.data.data)
            }
          })
        }
      })
    }))
  },
  getCode: function() {
    return new Promise((function(t) {
      wx.login({
        success: function(e) {
          t(e.code)
        }
      })
    }))
  },
  callShop: function() {
    var t = getApp().globalData.userInfo,
      e = null == t.tel ? t.mobile : t.tel;
    wx.makePhoneCall({
      phoneNumber: e,
      fail: function() {}
    })
  },
  userInfo: function() {
    return wx.getStorageSync("userInfo")
  },
  showTip: function(t) {
    wx.showToast({
      title: t,
      icon: "none",
      duration: 1600
    })
  },
  inputCheck: function(t, e) {
    var n = 0;
    return "char" == e && t && t.length > 0 && (n = 1), "number" == e && t && t > 0 && (n = 1), n
  },
  getLocation: function() {
    return new Promise((function(t, e) {
      var n = function e(n) {
        t(n), wx.offLocationChange(e), wx.stopLocationUpdate(e)
      };
      wx.startLocationUpdate({
        success: function(t) {
          wx.onLocationChange(n)
        },
        fail: function(t) {
          wx.openSetting({
            success: function(t) {
              t.authSetting = {
                "scope.userLocation": !0
              }
            }
          }), e(t)
        }
      })
    }))
  }
};