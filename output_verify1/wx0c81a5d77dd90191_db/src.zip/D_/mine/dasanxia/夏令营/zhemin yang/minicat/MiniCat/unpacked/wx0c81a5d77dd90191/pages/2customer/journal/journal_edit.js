var t = require("../../../@babel/runtime/helpers/interopRequireDefault").default,
  e = require("../../../@babel/runtime/helpers/defineProperty"),
  a = t(require("../../../utils/myfunc.js")),
  i = require("../../../apiconfig");
Page({
  data: {
    editInfo: {},
    radiolist: [{
      name: "是",
      value: 1
    }, {
      name: "否",
      value: 0
    }],
    staffList: "",
    professorList: ""
  },
  onLoad: function(t) {
    console.log("page:", "2customer/journal/journal_edit");
    var e = JSON.parse(t.info);
    this.setData({
      editInfo: e
    });
    var i = this;
    a.default.getList("staffList").then((function(t) {
      i.setData({
        staffList: t.data
      })
    })), a.default.getList("professorList").then((function(t) {
      i.setData({
        professorList: t.data
      })
    }))
  },
  saveEdit: function(t) {
    if (0 == a.default.inputCheck(this.data.editInfo.cid, "number")) return a.default.showTip("请选择顾客！"), !1;
    if (0 == a.default.inputCheck(this.data.editInfo.staff, "char")) return a.default.showTip("请选择美导老师！"), !1;
    if (0 == a.default.inputCheck(this.data.editInfo.professor, "char") && 1 == this.data.editInfo.zhenb) return a.default.showTip("请选择专家！"), !1;
    var e = this.data.editInfo;
    e.token = a.default.userInfo().token, wx.showLoading({
      title: "保存中",
      mask: "true"
    }), a.default.Post(i.dataApi + "journal/journal_edit", e, (function(t) {
      if (wx.hideLoading(), 200 == t.code) {
        var e = getCurrentPages();
        e[e.length - 2].getDatalist(), wx.showModal({
          title: "系统提示",
          content: "保存成功！",
          showCancel: !1,
          success: function(t) {
            wx.navigateBack({
              delta: 1
            })
          }
        })
      } else wx.showToast({
        title: t.msg,
        icon: "error"
      })
    }))
  },
  showPicker: function(t) {
    var e = this.data[t.currentTarget.dataset.item];
    null == e || ("professorList" == t.currentTarget.dataset.item && e.forEach((function(t) {
      t.option = t.professor
    })), "staffList" == t.currentTarget.dataset.item && e.forEach((function(t) {
      t.option = t.staff
    })), this.setData({
      pickList: e,
      show_picker: !0,
      picker: t.currentTarget.dataset.item
    }))
  },
  getSelect: function(t) {
    "professorList" == this.data.picker && this.setData(e({}, "editInfo.professor", t.detail.data.professor)), "staffList" == this.data.picker && this.setData(e({}, "editInfo.staff", t.detail.data.staff))
  },
  inputChange: function(t) {
    var a = t.currentTarget.dataset.item;
    this.setData(e({}, a, t.detail.value)), "editInfo.note" == a && this.setData({
      length: t.detail.value.length
    })
  },
  radioChange: function(t) {
    var a = t.currentTarget.dataset.item2;
    this.setData(e({}, a, t.currentTarget.dataset.item.value))
  }
});