var e = require("../../../@babel/runtime/helpers/interopRequireDefault").default,
  t = require("../../../@babel/runtime/helpers/defineProperty"),
  a = e(require("../../../utils/myfunc.js")),
  i = require("../../../apiconfig");
Page({
  data: {
    editInfo: {}
  },
  onLoad: function(e) {
    console.log("page:", "1work/customer/customer_edit");
    var t = this;
    a.default.getInfo("d_cid", e.id).then((function(e) {
      t.setData({
        editInfo: e.data
      })
    }))
  },
  saveEdit: function(e) {
    if (e.detail.value.name.length < 2) return wx.showToast({
      title: "请输入顾客姓名!",
      icon: "none",
      duration: 1600
    }), !1;
    var t = {
      token: a.default.userInfo().token,
      id: this.data.editInfo.id,
      name: e.detail.value.name,
      bdate: this.data.editInfo.bdate
    };
    wx.showLoading({
      title: "保存中",
      mask: "true"
    }), a.default.Post(i.dataApi + "customer/customer_edit", t, (function(e) {
      if (200 == e.code) {
        wx.hideLoading();
        var t = getCurrentPages();
        t[t.length - 2].getCidinfo(), wx.showModal({
          title: "系统提示",
          content: "保存成功！",
          showCancel: !1,
          success: function(e) {
            e.confirm && wx.navigateBack({
              delta: 1
            })
          }
        })
      } else wx.showToast({
        title: e.msg,
        icon: "none"
      })
    }))
  },
  inputChange: function(e) {
    var a = e.currentTarget.dataset.item;
    this.setData(t({}, a, e.detail.value))
  }
});