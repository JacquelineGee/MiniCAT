var e = (0, require("../../../@babel/runtime/helpers/interopRequireDefault").default)(require("../../../utils/myfunc.js")),
  t = require("../../../apiconfig");
Page({
  data: {
    length: 0,
    date: "",
    start: "",
    end: "",
    staff: "",
    files: [],
    canClick: 1
  },
  onLoad: function(t) {
    this.setData({
      date: e.default.GetDateStr(0),
      start: e.default.GetDateStr(-50),
      end: e.default.GetDateStr(10),
      staff: e.default.userInfo().staff
    })
  },
  Changedate: function(e) {
    var t = e.detail.value;
    t && this.setData({
      date: t
    })
  },
  length: function(e) {
    var t = e.detail.value.length;
    this.setData({
      length: t,
      note: e.detail.value
    })
  },
  chooseImage: function(e) {
    var t = this;
    wx.chooseImage({
      sizeType: ["compressed"],
      sourceType: ["album", "camera"],
      count: 1,
      success: function(e) {
        t.setData({
          files: t.data.files.concat(e.tempFilePaths)
        })
      }
    })
  },
  previewImage: function(e) {
    wx.previewImage({
      current: e.currentTarget.id,
      urls: this.data.files
    })
  },
  deleteImage: function(e) {
    var t = this,
      a = t.data.files,
      n = e.currentTarget.dataset.index;
    console.log(t.data.files), console.log(t.data.files.length), wx.showModal({
      title: "系统提醒",
      content: "确定要删除此图片吗？",
      success: function(e) {
        if (e.confirm) a.splice(n, 1);
        else if (e.cancel) return !1;
        t.setData({
          files: a
        })
      }
    })
  },
  tosave: function(a) {
    var n = this;
    if (!(a.detail.value.number > 0)) return wx.showModal({
      title: "提示！！",
      content: "请输入报销金额。"
    }), !1;
    var i = e.default.userInfo(),
      s = {
        token: i.token,
        staff: i.staff,
        number: a.detail.value.number,
        date: a.detail.value.date,
        note: a.detail.value.note
      },
      l = this;
    e.default.Post(t.dataApi + "reimburse/reimburse_add", s, (function(e) {
      if (l.setData({
          canClick: 0
        }), console.log(e.data), 200 == e.code) {
        var t = e.data;
        if (1 == n.data.files.length) l.uploadImage(t);
        else {
          var a = getCurrentPages();
          a[a.length - 2].onLoad(), wx.showModal({
            title: "系统提示",
            content: "保存成功！",
            showCancel: !1,
            success: function(e) {
              e.confirm && wx.navigateBack({
                delta: 1
              })
            }
          })
        }
      } else wx.showToast({
        title: "保存失败!",
        icon: "none"
      }), l.setData({
        canClick: 1
      })
    }))
  },
  uploadImage: function(a) {
    var n = e.default.userInfo();
    wx.showLoading({
      title: "图片上传中..."
    });
    var i = {
      token: n.token,
      pathlb: "reimburse",
      field: "pic",
      unitid: n.unitid,
      id: a
    };
    wx.uploadFile({
      url: t.resupApi + "Mr_img/pic_save",
      filePath: this.data.files[0],
      name: "file",
      formData: i,
      success: function(e) {
        var t = JSON.parse(e.data);
        if (console.log(t), console.log(e.data), wx.hideLoading(), 200 == t.code) {
          var a = getCurrentPages();
          a[a.length - 2].onLoad(), wx.showModal({
            title: "系统提示",
            content: "保存成功！",
            showCancel: !1,
            success: function(e) {
              e.confirm && wx.navigateBack({
                delta: 1
              })
            }
          })
        } else wx.showToast({
          title: "保存失败!",
          icon: "none"
        })
      }
    })
  }
});