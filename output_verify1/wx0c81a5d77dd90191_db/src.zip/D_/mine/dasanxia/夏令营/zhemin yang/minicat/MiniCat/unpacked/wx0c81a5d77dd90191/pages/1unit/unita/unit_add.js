var t = require("../../../@babel/runtime/helpers/interopRequireDefault").default,
  a = require("../../../@babel/runtime/helpers/defineProperty"),
  e = t(require("../../../utils/myfunc.js")),
  i = require("../../../apiconfig");
Page({
  data: {
    addInfo: {},
    staffList: ""
  },
  onLoad: function(t) {
    console.log("page:", "1work/unit/unit_add");
    var i = wx.getStorageSync("staffList");
    this.setData(a({
      staffList: i
    }, "addInfo.staff", e.default.userInfo().staff))
  },
  saveAdd: function(t) {
    if (t.detail.value.unitname.length < 2) return e.default.showTip("请填写美容院名称！"), !1;
    if (0 == e.default.inputCheck(this.data.addInfo.unitname, "char")) return e.default.showTip("请填写美容院名称！"), !1;
    var a = this.data.addInfo;
    a.token = e.default.userInfo().token, wx.showLoading({
      title: "保存中",
      mask: "true"
    }), e.default.Post(i.dataApi + "unit/unit_add", a, (function(t) {
      if (200 == t.code) {
        wx.hideLoading();
        var a = getCurrentPages();
        a[a.length - 2].getDatalist(), wx.showModal({
          title: "系统提示",
          content: "保存成功！",
          showCancel: !1,
          success: function(t) {
            wx.navigateBack({
              delta: 1
            })
          }
        })
      } else wx.showToast({
        title: t.msg,
        icon: "error"
      })
    }))
  },
  showPicker: function(t) {
    var a = this.data[t.currentTarget.dataset.arr];
    null != a && ("staffList" == t.currentTarget.dataset.arr && a.forEach((function(t) {
      t.option = t.staff
    })), this.setData({
      pickList: a,
      show_picker: !0,
      picker: t.currentTarget.dataset.arr
    }))
  },
  getSelect: function(t) {
    "staffList" == this.data.picker && this.setData(a({}, "addInfo.staff", t.detail.data.staff))
  },
  inputChange: function(t) {
    var e = t.currentTarget.dataset.key;
    this.setData(a({}, e, t.detail.value)), "addInfo.address" == e && this.setData({
      length: t.detail.value.length
    })
  }
});