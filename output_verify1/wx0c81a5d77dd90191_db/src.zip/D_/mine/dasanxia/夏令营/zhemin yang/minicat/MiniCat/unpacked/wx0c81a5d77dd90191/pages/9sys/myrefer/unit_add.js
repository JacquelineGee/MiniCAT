var t = (0, require("../../../@babel/runtime/helpers/interopRequireDefault").default)(require("../../../utils/myfunc.js")),
  e = require("../../../apiconfig");
Page({
  data: {
    num_id: "",
    unitname: "",
    note: ""
  },
  onLoad: function(t) {
    this.getUnitaddstart()
  },
  getUnitaddstart: function() {
    var a = this,
      n = {
        token: t.default.userInfo().token
      };
    t.default.Post(e.dataApi + "sysrefer/newunitid", n, (function(t) {
      200 == t.code && a.setData({
        num_id: t.data
      })
    }))
  },
  changeNote: function(t) {
    var e = t.detail.value.length;
    this.setData({
      length: e,
      note: t.detail.value
    })
  },
  formSubmit: function(a) {
    if (a.detail.value.unitname.length < 2) return wx.showToast({
      title: "请填写美容院名称！",
      icon: "none",
      duration: 1600
    }), !1;
    var n = {
      token: t.default.userInfo().token,
      num_id: a.detail.value.num_id,
      unitname: a.detail.value.unitname,
      tel: a.detail.value.tel,
      address: this.data.note
    };
    wx.showLoading({
      title: "保存中",
      mask: "true"
    }), t.default.Post(e.dataApi + "sysrefer/saveunit", n, (function(t) {
      if (wx.hideLoading(), 200 == t.code) {
        var e = getCurrentPages();
        e[e.length - 2].getUnitList(), wx.showModal({
          title: "系统提示",
          content: "保存成功！",
          showCancel: !1,
          success: function(t) {
            wx.navigateBack({
              delta: 1
            })
          }
        })
      } else wx.showToast({
        title: t.msg,
        icon: "error"
      })
    }))
  }
});