var t = function(t) {
  return (t = t.toString())[1] ? t : "0" + t
};
module.exports = {
  formatTimeMine: function(e) {
    var n = e.getFullYear(),
      o = e.getMonth() + 1,
      r = e.getDate(),
      a = e.getHours(),
      i = e.getMinutes(),
      u = e.getSeconds();
    return [n, o, r].map(t).join("-") + " " + [a, i, u].map(t).join(":")
  },
  formatTime: function(e) {
    var n = e.getFullYear(),
      o = e.getMonth() + 1,
      r = e.getDate(),
      a = e.getHours(),
      i = e.getMinutes(),
      u = e.getSeconds();
    return [n, o, r].map(t).join("/") + " " + [a, i, u].map(t).join(":")
  },
  formatTimeYYMMDD: function(e) {
    return [e.getFullYear(), e.getMonth() + 1, e.getDate()].map(t).join("-")
  }
};