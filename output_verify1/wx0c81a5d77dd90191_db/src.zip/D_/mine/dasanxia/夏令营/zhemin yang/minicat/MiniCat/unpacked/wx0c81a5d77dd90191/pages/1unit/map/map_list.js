var t = (0, require("../../../@babel/runtime/helpers/interopRequireDefault").default)(require("../../../utils/myfunc.js"));
require("../../../apiconfig");
Page({
  data: {
    latitude: 22.618963,
    longitude: 114.077332,
    myaddress: {},
    currentunit: {},
    markers: []
  },
  onReady: function(t) {
    this.mapCtx = wx.createMapContext("myMap")
  },
  onLoad: function(a) {
    console.log("page:", "1unit/map/map_list");
    var e = JSON.parse(a.list);
    this.dealList(e);
    var i = this;
    t.default.getLocation().then((function(t) {
      i.setData({
        myaddress: {
          latitude: t.latitude,
          longitude: t.longitude
        },
        latitude: t.latitude,
        longitude: t.longitude
      })
    }))
  },
  dealList: function(t) {
    var a = t.filter((function(t) {
        return t.latitude && t.latitude > 0
      })),
      e = [];
    if (a && a.length > 0) {
      var i = 0,
        n = 0;
      a.forEach((function(t) {
        null != t.latitude && t.latitude > 0 && (e[n] = {
          id: i,
          width: 20,
          height: 30,
          latitude: t.latitude,
          longitude: t.longitude,
          name: t.unitname
        }, n++), i++
      }))
    }
    this.setData({
      dataList: a,
      markers: e
    }), console.log("setData", this.data)
  },
  markertap: function(t) {
    console.log("bindmarkertap", t.markerId);
    var a = this.data.dataList[t.markerId],
      e = this.distance(this.data.myaddress.latitude, this.data.myaddress.longitude, a.latitude, a.longitude);
    a.distance = Number(e).toFixed(0), this.setData({
      currentunit: a,
      latitude: a.latitude,
      longitude: a.longitude,
      distance: e
    }), console.log("setData", this.data)
  },
  access: function() {
    var a = this;
    t.default.getLocation().then((function(t) {
      console.log("当前所在位置的经纬度为：", t), a.setData({
        latitude: t.latitude,
        longitude: t.longitude
      })
    }))
  },
  distance: function(t, a, e, i) {
    var n = t * Math.PI / 180,
      d = e * Math.PI / 180,
      u = n - d,
      s = a * Math.PI / 180 - i * Math.PI / 180,
      o = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(u / 2), 2) + Math.cos(n) * Math.cos(d) * Math.pow(Math.sin(s / 2), 2)));
    return o *= 6378.137, o = Math.round(1e4 * o) / 1e4, console.log("计算结果", o), o
  },
  tomyaddress: function() {
    this.setData({
      latitude: this.data.myaddress.latitude,
      longitude: this.data.myaddress.longitude
    })
  },
  openMap: function() {
    var t = this.data.currentunit;
    wx.openLocation({
      latitude: Number(t.latitude),
      longitude: Number(t.longitude),
      scale: 19,
      name: t.unitshort,
      address: t.address
    })
  }
});