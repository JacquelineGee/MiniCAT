Component({
  properties: {
    pickList: Array,
    show_picker: {
      type: Boolean,
      value: !1,
      observer: function(t, e) {
        1 == t && this.setData({
          temparray: this.properties.pickList
        })
      }
    }
  },
  data: {
    temparray: [],
    inputValue: ""
  },
  methods: {
    hidePicker: function() {
      this.setData({
        show_picker: !1,
        inputValue: ""
      })
    },
    getSelect: function(t) {
      var e = t.currentTarget.dataset.item;
      this.triggerEvent("myevent", {
        data: e
      }), this.hidePicker()
    },
    getInput: function(t) {
      this.setData({
        inputValue: t.detail.value
      });
      var e = t.detail.value,
        a = this.searchList(e, this.data.pickList);
      this.setData({
        temparray: a
      })
    },
    searchList: function(t, e) {
      var a = [],
        r = t.charAt(0),
        i = t.length;
      if (0 == i) return e;
      for (var s = 0; s < e.length; s++) {
        var n = e[s],
          u = !1;
        for (var h in n)
          if ("function" == typeof n[h]) n[h]();
          else {
            var c = "";
            null != n[h] && (c = n[h]);
            for (var o = 0; o < c.length; o++)
              if (c.charAt(o) == r && c.substring(o).substring(0, i) == t) {
                u = !0;
                break
              }
          } u && a.push(n)
      }
      return a
    }
  }
});