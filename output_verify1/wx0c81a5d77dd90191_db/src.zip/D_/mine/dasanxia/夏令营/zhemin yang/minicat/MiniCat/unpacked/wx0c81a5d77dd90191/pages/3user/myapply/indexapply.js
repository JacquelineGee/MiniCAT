var t = (0, require("../../../@babel/runtime/helpers/interopRequireDefault").default)(require("../../../apiconfig")),
  e = require("../../../utils/myfunc.js");
Page({
  data: {
    applyinfo: ""
  },
  tocertify: function() {
    wx.navigateTo({
      url: "/pages/3user/myapply/certify"
    })
  },
  toaccount: function() {
    var t = "/pages/3user/myapply/account?unitid=" + this.data.applyinfo.unitid2;
    wx.navigateTo({
      url: t
    })
  },
  tosave: function(a) {
    if (console.log("value", a.detail.target), a.detail.value.unitname.length < 2) return wx.showToast({
      title: "请输入美容院名称!",
      icon: "none",
      duration: 1600
    }), !1;
    if (a.detail.value.address.length < 2) return wx.showToast({
      title: "请输入美容院地址!",
      icon: "none",
      duration: 1600
    }), !1;
    if (a.detail.value.contact.length < 2) return wx.showToast({
      title: "请输入联系人!",
      icon: "none",
      duration: 1600
    }), !1;
    if (a.detail.value.mobile.length < 8) return wx.showToast({
      title: "请输入联系电话!",
      icon: "none",
      duration: 1600
    }), !1;
    var i = {
      unitid2: this.data.applyinfo.unitid2,
      token: e.userInfo().token,
      unitname: a.detail.value.unitname,
      contact: a.detail.value.contact,
      mobile: a.detail.value.mobile,
      address: a.detail.value.address
    };
    e.Post(t.default.dataApi + "user/savemyapply", i, (function(t) {
      0 == t.code ? wx.showModal({
        title: "系统提示",
        content: "保存成功！",
        success: function(t) {
          wx.navigateBack({
            delta: 1
          })
        }
      }) : wx.showModal({
        title: "系统提示",
        content: t.msg
      })
    }))
  },
  onLoad: function(t) {
    var e = JSON.parse(t.jsdata);
    this.setData({
      applyinfo: e
    }), console.log("this-data", this.data)
  }
});