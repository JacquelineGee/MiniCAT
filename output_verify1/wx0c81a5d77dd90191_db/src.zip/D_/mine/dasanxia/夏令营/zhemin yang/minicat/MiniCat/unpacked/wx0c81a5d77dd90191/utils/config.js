Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.default = void 0;
exports.default = {
  tokenStoreName: "access_token",
  unitlbList: [{
    value: "合作"
  }, {
    value: "跟进"
  }, {
    value: "无效"
  }],
  groupid: 1002
};