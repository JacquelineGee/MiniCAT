Page({
  data: {},
  onLoad: function(e) {
    var t = wx.getStorageSync("userInfo");
    this.setData({
      url: "https://meiyiy.cn/wxlogin/bjl_guanlian.php",
      groupid: t.groupid,
      wxuser_id: t.wxuser_id
    }), console.log(this.data)
  },
  handleGetMessage: function(e) {
    console.log("handleGetMessage", e);
    var t = getCurrentPages();
    t[t.length - 2].freshInfo()
  }
});