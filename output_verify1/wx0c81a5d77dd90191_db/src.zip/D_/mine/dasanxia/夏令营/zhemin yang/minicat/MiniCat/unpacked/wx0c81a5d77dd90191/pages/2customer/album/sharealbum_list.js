var t = require("../../../@babel/runtime/helpers/interopRequireDefault").default,
  a = require("../../../@babel/runtime/helpers/defineProperty"),
  e = t(require("../../../utils/myfunc.js")),
  i = require("../../../apiconfig");
Page({
  data: {
    indexList: [],
    where: {
      limit: 20,
      albumlb: "-照片类别-",
      name: ""
    },
    albumlbList: []
  },
  onLoad: function(t) {
    console.log("page:", "1work/album/album_list");
    var a = this;
    e.default.getList("sharealbumlb").then((function(t) {
      var e = t.data;
      e = [{
        value: "-照片类别-"
      }].concat(e), a.setData({
        albumlbList: e
      }), wx.setStorageSync("albumlbList", t.data)
    }))
  },
  getdataList: function() {
    var t = this,
      a = {
        limit: this.data.where.limit
      };
    if (!(this.data.where.albumlb.length > 0 && "-照片类别-" != this.data.where.albumlb)) return e.default.showTip("请选择照片类别！"), !1;
    a.albumlb = this.data.where.albumlb, this.data.where.name.length > 0 && (a.name = this.data.where.name), e.default.Post(i.dataApi + "album/albumwx_list", a, (function(a) {
      200 == a.code && t.setData({
        dataList: a.data.list,
        picList: a.data.piclist,
        coverList: a.data.coverlist,
        msg: a.msg
      })
    }))
  },
  previewImage: function(t) {
    var a = t.target.dataset.src;
    console.log("current", a), wx.previewImage({
      current: a,
      urls: this.data.picList
    })
  },
  toEdit: function(t) {
    var a = t.currentTarget.dataset.item;
    wx.navigateTo({
      url: "./album_edit?info=" + JSON.stringify(a)
    })
  },
  showPicker: function(t) {
    var a = this.data[t.currentTarget.dataset.item];
    null == a || ("albumlbList" == t.currentTarget.dataset.item && a.forEach((function(t) {
      t.option = t.value
    })), this.setData({
      pickList: a,
      show_picker: !0,
      picker: t.currentTarget.dataset.item
    }))
  },
  getSelect: function(t) {
    "albumlbList" == this.data.picker && this.setData(a({}, "where.albumlb", t.detail.data.value))
  },
  inputChange: function(t) {
    var e = t.currentTarget.dataset.item;
    this.setData(a({}, e, t.detail.value))
  }
});