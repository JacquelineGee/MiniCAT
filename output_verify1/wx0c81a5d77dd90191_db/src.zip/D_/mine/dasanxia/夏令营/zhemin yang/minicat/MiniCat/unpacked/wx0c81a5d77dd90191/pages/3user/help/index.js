var e = require("../../../apiconfig"),
  i = require("../../../utils/myfunc.js");
Page({
  data: {
    list: [{
      title: "电脑端教学",
      index: "1"
    }, {
      title: "手机端教学",
      index: "2"
    }, {
      title: "技能提升",
      index: "3"
    }],
    currentIndex: 1,
    videolist: [],
    videoall: [],
    videoinfo: {}
  },
  onLoad: function(e) {
    this.getVideolist(), e && e.id > 0 && wx.navigateTo({
      url: "/pages/3user/help/videoplay?id=" + e.id
    })
  },
  clickTab: function(e) {
    var i = e.currentTarget.dataset.index;
    if (this.setData({
        currentIndex: i
      }), "1" == i) {
      var t = this.data.videoall.filter((function(e) {
        return "电脑端教学" == e.videolb
      }));
      this.setData({
        videolist: t
      })
    }
    if ("2" == i) {
      t = this.data.videoall.filter((function(e) {
        return "手机端教学" == e.videolb
      }));
      this.setData({
        videolist: t
      })
    }
    if ("3" == i) {
      t = this.data.videoall.filter((function(e) {
        return "技能提升" == e.videolb
      }));
      this.setData({
        videolist: t
      })
    }
  },
  getVideolist: function() {
    var t = this,
      a = {
        token: i.userInfo().token
      };
    i.Post(e.dataApi + "help/videolist", a, (function(e) {
      if (200 == e.code) {
        var i = e.data,
          a = i.filter((function(e) {
            return "电脑端教学" == e.videolb
          }));
        t.setData({
          videoall: i,
          currentIndex: 1,
          videolist: a
        })
      }
    }))
  },
  tosysinfo: function() {
    wx.navigateTo({
      url: "sysindex"
    })
  },
  videoClick: function(e) {
    var i = e.currentTarget.dataset.item;
    wx.navigateTo({
      url: "videoplay?id=" + i.id
    })
  },
  shareAction: function(e) {
    console.log("分享", e), this.setData({
      videoinfo: e.currentTarget.dataset.item
    })
  },
  saveshare: function(t) {
    var a = {
      token: i.userInfo().token,
      videoid: t
    };
    i.Post(e.dataApi + "help/saveshare", a, (function(e) {
      200 == e.code && console.log("res.msg", e.msg)
    }))
  },
  onShareAppMessage: function(e) {
    var t = i.userInfo().unitid,
      a = i.userInfo().wx_id,
      o = this.data.videoinfo;
    return this.saveshare(o.id), {
      title: o.video,
      desc: o.videolb,
      path: "/pages/3user/user?unitid=" + t + "&wx_id=" + a + "&page=helpvideo&id=" + o.id,
      imageUrl: o.coverurl
    }
  }
});