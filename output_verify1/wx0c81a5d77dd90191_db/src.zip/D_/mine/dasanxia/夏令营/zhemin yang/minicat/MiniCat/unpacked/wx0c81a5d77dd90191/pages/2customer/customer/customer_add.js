var t = require("../../../@babel/runtime/helpers/interopRequireDefault").default,
  a = require("../../../@babel/runtime/helpers/defineProperty"),
  e = t(require("../../../utils/myfunc.js")),
  i = require("../../../apiconfig");
Page({
  data: {
    addInfo: {},
    unitList: ""
  },
  onLoad: function(t) {
    console.log("page:", "1work/customer/customer_add");
    var a = wx.getStorageSync("unitList");
    this.setData({
      unitList: a
    })
  },
  saveAdd: function(t) {
    if (0 == e.default.inputCheck(this.data.addInfo.unitid, "number")) return e.default.showTip("请选择美容院！"), !1;
    if (0 == e.default.inputCheck(this.data.addInfo.name, "char")) return e.default.showTip("请输入顾客姓名！"), !1;
    var a = {
      unitid: this.data.addInfo.unitid,
      name: this.data.addInfo.name
    };
    this.data.addInfo.bdate && (a.bdate = this.data.addInfo.bdate), wx.showLoading({
      title: "保存中",
      mask: "true"
    }), e.default.Post(i.dataApi + "customer/customer_add", a, (function(t) {
      if (wx.hideLoading(), 200 == t.code) {
        var a = getCurrentPages();
        a[a.length - 2].getDatalist(), wx.showModal({
          title: "系统提示",
          content: "保存成功！",
          showCancel: !1,
          success: function(t) {
            wx.navigateBack({
              delta: 1
            })
          }
        })
      } else wx.showToast({
        title: t.msg,
        icon: "error"
      })
    }))
  },
  showPicker: function(t) {
    var a = this.data[t.currentTarget.dataset.item];
    null == a || ("unitList" == t.currentTarget.dataset.item && a.forEach((function(t) {
      t.option = t.unitname
    })), this.setData({
      pickList: a,
      show_picker: !0,
      picker: t.currentTarget.dataset.item
    }))
  },
  getSelect: function(t) {
    "unitList" == this.data.picker && this.setData(a(a({}, "addInfo.unitname", t.detail.data.unitname), "addInfo.unitid", t.detail.data.id))
  },
  inputChange: function(t) {
    var e = t.currentTarget.dataset.item;
    this.setData(a({}, e, t.detail.value))
  }
});