var e = (0, require("../../../@babel/runtime/helpers/interopRequireDefault").default)(require("../../../apiconfig")),
  t = require("../../../utils/myfunc.js");
Page({
  data: {
    list: [],
    userInfo: {},
    currentIndex: 0
  },
  onLoad: function(e) {
    var a = t.userInfo();
    this.setData({
      userInfo: a
    }), this.getMyShopList()
  },
  clickShop: function(a) {
    var n = {
      unitid: a.currentTarget.dataset.item.unitid,
      wx_id: t.userInfo().wx_id
    };
    t.Post(e.default.dataApi + "login/selectunit", n, (function(e) {
      200 == e.code && (getApp().globalData.userInfo = e.data, wx.setStorageSync("userInfo", e.data), wx.reLaunch({
        url: "/pages/3user/user"
      }))
    }))
  },
  getMyShopList: function() {
    var a = this,
      n = {
        token: t.userInfo().token
      };
    t.Post(e.default.dataApi + "user/myshoplist", n, (function(e) {
      200 == e.code ? a.setData({
        list: e.data
      }) : 401 == e.code && wx.navigateTo({
        url: "/pages/9public/login/login"
      })
    }))
  },
  openMap: function(e) {
    var t = e.currentTarget.dataset.item;
    wx.openLocation({
      latitude: Number(t.latitude),
      longitude: Number(t.longitude),
      scale: 19,
      name: t.unitname,
      address: t.address
    })
  },
  makeCall: function(e) {
    var t = e.currentTarget.dataset.item;
    wx.makePhoneCall({
      phoneNumber: t.tel
    })
  }
});