var t = require("../../../@babel/runtime/helpers/interopRequireDefault").default,
  a = require("../../../@babel/runtime/helpers/defineProperty"),
  e = t(require("../../../utils/myfunc.js")),
  i = require("../../../apiconfig");
Page({
  data: {
    addInfo: {
      amount: 1
    },
    radiolist: [{
      name: "是",
      value: "Y"
    }, {
      name: "否",
      value: "N"
    }],
    staffList: "",
    productList: "",
    cidList: ""
  },
  onLoad: function(t) {
    console.log("page:", "1work/sale/salecp_add"), this.setData(a({}, "addInfo.unitid", t.unitid)), this.pageStart()
  },
  pageStart: function(t) {
    var d = this,
      n = {
        token: e.default.userInfo().token,
        unitid: this.data.addInfo.unitid
      };
    e.default.Post(i.dataApi + "sale/add_start", n, (function(t) {
      if (200 == t.code) {
        var i = t.data;
        d.setData(a(a(a({
          staffList: i.staffList,
          cidList: i.cidList,
          productList: i.productList
        }, "addInfo.date", i.date), "mindate", e.default.GetDateStr(-1826)), "maxdate", e.default.GetDateStr(2)))
      }
    }))
  },
  saveAdd: function(t) {
    if (t.detail.value.name.length < 2) return e.default.showTip("请选择顾客！"), !1;
    if (t.detail.value.project.length < 2) return e.default.showTip("请选择产品！"), !1;
    if (t.detail.value.amount < 1) return e.default.showTip("请输入数量！"), !1;
    if (t.detail.value.price < 0) return e.default.showTip("请输入金额！"), !1;
    if (t.detail.value.staff.length < 2) return e.default.showTip("请选择美导老师！"), !1;
    var a = this.data.addInfo;
    a.token = e.default.userInfo().token, wx.showLoading({
      title: "保存中",
      mask: "true"
    }), e.default.Post(i.dataApi + "sale/salecp_add", a, (function(t) {
      if (wx.hideLoading(), 200 == t.code) {
        var a = getCurrentPages();
        a[a.length - 2].getDatalist(), wx.showModal({
          title: "系统提示",
          content: "保存成功！",
          showCancel: !1,
          success: function(t) {
            wx.navigateBack({
              delta: 1
            })
          }
        })
      } else wx.showToast({
        title: t.msg,
        icon: "error"
      })
    }))
  },
  showPicker: function(t) {
    var a = this.data[t.currentTarget.dataset.item];
    null == a || ("cidList" == t.currentTarget.dataset.item && a.forEach((function(t) {
      t.option = t.name
    })), "productList" == t.currentTarget.dataset.item && a.forEach((function(t) {
      t.option = t.product
    })), "staffList" == t.currentTarget.dataset.item && a.forEach((function(t) {
      t.option = t.staff
    })), this.setData({
      pickList: a,
      show_picker: !0,
      picker: t.currentTarget.dataset.item
    }))
  },
  getSelect: function(t) {
    "cidList" == this.data.picker && this.setData(a(a({}, "addInfo.cid", t.detail.data.id), "addInfo.name", t.detail.data.name)), "productList" == this.data.picker && this.setData(a({}, "addInfo.project", t.detail.data.product)), "staffList" == this.data.picker && this.setData(a({}, "addInfo.staff", t.detail.data.staff))
  },
  inputChange: function(t) {
    var e = t.currentTarget.dataset.item;
    this.setData(a({}, e, t.detail.value))
  },
  noteChange: function(t) {
    var e = t.detail.value.length;
    this.setData(a(a({}, "addInfo.note", t.detail.value), "length", e))
  },
  radioChange: function(t) {
    var e = t.currentTarget.dataset.item2;
    this.setData(a({}, e, t.currentTarget.dataset.item.value)), console.log(this.data)
  }
});