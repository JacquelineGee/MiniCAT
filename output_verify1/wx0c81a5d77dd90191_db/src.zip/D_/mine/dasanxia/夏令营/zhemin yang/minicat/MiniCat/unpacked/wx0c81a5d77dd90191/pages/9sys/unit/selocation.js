var t = (0, require("../../../@babel/runtime/helpers/interopRequireDefault").default)(require("../../../apiconfig")),
  e = require("../../../utils/myfunc.js");
Page({
  data: {
    name: "",
    address: "",
    latitude: "",
    longitude: "",
    unitInfo: {}
  },
  onLoad: function(t) {
    var e = JSON.parse(t.info);
    this.setData({
      unitInfo: e,
      name: e.unitname,
      address: e.address,
      latitude: e.latitude,
      longitude: e.longitude
    })
  },
  getLocation: function() {
    var t = this;
    wx.chooseLocation({
      success: function(e) {
        var o = e.latitude,
          s = e.longitude;
        t.setData({
          latitude: o,
          longitude: s,
          btnstate: 1
        })
      },
      fail: function() {
        wx.getSetting({
          success: function(t) {
            t.authSetting["scope.userLocation"] || wx.showModal({
              title: "是否授权当前位置",
              content: "需要获取您的地理位置，请确认授权，否则地图功能将无法使用",
              success: function(t) {
                t.confirm && wx.openSetting({
                  success: function(t) {
                    !0 === t.authSetting["scope.userLocation"] ? (wx.showToast({
                      title: "授权成功",
                      icon: "success",
                      duration: 1e3
                    }), wx.chooseLocation({
                      success: function(t) {
                        obj.setData({
                          addr: t.address
                        })
                      }
                    })) : wx.showToast({
                      title: "授权失败",
                      icon: "success",
                      duration: 1e3
                    })
                  }
                })
              }
            })
          },
          fail: function(t) {
            wx.showToast({
              title: "调用授权窗口失败",
              icon: "success",
              duration: 1e3
            })
          }
        })
      }
    })
  },
  getPermission: function(t) {
    wx.chooseLocation({
      success: function(e) {
        t.setData({
          addr: e.address
        })
      },
      fail: function() {
        wx.getSetting({
          success: function(e) {
            e.authSetting["scope.userLocation"] || wx.showModal({
              title: "是否授权当前位置",
              content: "需要获取您的地理位置，请确认授权，否则地图功能将无法使用",
              success: function(e) {
                e.confirm && wx.openSetting({
                  success: function(e) {
                    !0 === e.authSetting["scope.userLocation"] ? (wx.showToast({
                      title: "授权成功",
                      icon: "success",
                      duration: 1e3
                    }), wx.chooseLocation({
                      success: function(e) {
                        t.setData({
                          addr: e.address
                        })
                      }
                    })) : wx.showToast({
                      title: "授权失败",
                      icon: "success",
                      duration: 1e3
                    })
                  }
                })
              }
            })
          },
          fail: function(t) {
            wx.showToast({
              title: "调用授权窗口失败",
              icon: "success",
              duration: 1e3
            })
          }
        })
      }
    })
  },
  saveLocation: function() {
    var o = {
      token: e.userInfo().token,
      id: this.data.unitInfo.id,
      latitude: this.data.latitude,
      longitude: this.data.longitude
    };
    e.Post(t.default.dataApi + "unit/locationset", o, (function(t) {
      200 == t.code ? wx.showModal({
        title: "系统提示",
        content: "保存成功！",
        success: function(t) {
          wx.navigateBack({
            delta: 1
          })
        }
      }) : wx.showModal({
        title: "系统提示",
        content: t.msg
      })
    }))
  }
});