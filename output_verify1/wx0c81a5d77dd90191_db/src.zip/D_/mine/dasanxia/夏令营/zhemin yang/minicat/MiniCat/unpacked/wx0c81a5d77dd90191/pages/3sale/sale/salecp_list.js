var t = require("../../../@babel/runtime/helpers/interopRequireDefault").default,
  e = require("../../../@babel/runtime/helpers/defineProperty"),
  a = t(require("../../../utils/myfunc.js")),
  i = require("../../../apiconfig");
Page({
  data: {
    indexList: [],
    where: {
      unitid: 0
    },
    unitname: "-美容院-",
    unitList: "",
    thList: [{
      width: 120,
      orderid: 1,
      orderlb: "byChar",
      thname: "客户",
      field: "name"
    }, {
      width: 200,
      orderid: 2,
      orderlb: "byChar",
      thname: "产品名称",
      field: "product"
    }, {
      width: 250,
      orderid: 3,
      orderlb: "byNum",
      thname: "金额/数量",
      field: "tprice"
    }, {
      width: 180,
      orderid: 5,
      orderlb: "byDate",
      thname: "日期",
      field: "date"
    }]
  },
  onLoad: function(t) {
    console.log("page:", "1work/salecp/salecp_list");
    var e = this;
    a.default.getList("myunitList").then((function(t) {
      e.setData({
        unitList: t.data
      })
    })), this.setData({
      cIndex: 4
    })
  },
  clickBtn: function(t) {
    var e = t.currentTarget.dataset.index;
    this.setData({
      cIndex: e
    }), this.getDatalist(e)
  },
  getDatalist: function(t) {
    var e, r = this,
      n = "",
      d = "";
    1 == t && (n = (e = a.default.getMonthdate(0))[0], d = e[1]);
    2 == t && (n = (e = a.default.getMonthdate(1))[0], d = e[1]);
    3 == t && (d = n = a.default.GetDateStr(-1)), 4 == t && (d = n = a.default.GetDateStr(-0));
    var s = {
      staff: a.default.userInfo().staff,
      st: n,
      et: d
    };
    this.data.where.unitid > 0 && (s.unitid = this.data.where.unitid), a.default.Post(i.dataApi + "eproduct/eproduct_list", s, (function(t) {
      var e = 0,
        a = 0;
      t.data.length > 0 && (e = t.data.reduce((function(t, e) {
        return t + 1 * e.amount
      }), 0), a = t.data.reduce((function(t, e) {
        return t + 1 * e.tprice
      }), 0));
      var i = "数量:" + e + "， 金额:" + a;
      r.setData({
        indexList: t.data,
        msg: i
      })
    }))
  },
  clickLine: function(t) {
    var i, r = t.currentTarget.dataset.item.id,
      n = t.currentTarget.dataset.arr;
    i = a.default.selectChange(this.data[n], r), this.setData(e({}, n, i))
  },
  toAdd: function(t) {
    if (0 == this.data.where.unitid) return a.default.showTip("请选择美容院！"), !1;
    wx.navigateTo({
      url: "./salecp_add?unitid=" + this.data.where.unitid
    })
  },
  toDel: function(t) {
    var e = t.currentTarget.dataset.item,
      r = a.default.userInfo(),
      n = this;
    wx.showModal({
      title: "温馨提示",
      content: "您确定要删除吗？",
      success: function(t) {
        if (t.confirm) {
          var d = {
            token: r.token,
            id: e.id
          };
          wx.showLoading({
            title: "删除中",
            mask: "true"
          }), a.default.Post(i.dataApi + "sale/sale_del", d, (function(t) {
            wx.hideLoading(), 200 == t.code ? (wx.showToast({
              title: "删除成功!"
            }), n.getDatalist()) : wx.showToast({
              title: "删除失败!",
              icon: "error"
            })
          }))
        }
      }
    })
  },
  showPicker: function(t) {
    var e = this.data[t.currentTarget.dataset.item];
    null == e || ("unitList" == t.currentTarget.dataset.item && e.forEach((function(t) {
      t.option = t.unitname
    })), this.setData({
      pickList: e,
      show_picker: !0,
      picker: t.currentTarget.dataset.item
    }))
  },
  getSelect: function(t) {
    "unitList" == this.data.picker && this.setData(e(e({}, "where.unitid", t.detail.data.id), "unitname", t.detail.data.unitname))
  },
  inputChange: function(t) {
    var a = t.currentTarget.dataset.item;
    this.setData(e({}, a, t.detail.value))
  },
  getOrder: function(t) {
    var e = t.detail.data;
    this.setData({
      indexList: e
    })
  }
});