var e = getApp(),
  o = require("../../../apiconfig"),
  t = require("../../../utils/myfunc.js");
Page({
  data: {
    qrcode: ""
  },
  getqrcode: function() {
    var r = this,
      a = {
        request: "getqrcode",
        Token: e.globalData.userInfo.Token
      };
    t.Post(o.referApi, a, (function(e) {
      var o = e.data;
      console.log(o), r.setData({
        qrcode: o
      })
    }))
  },
  onLoad: function(e) {
    this.getqrcode()
  }
});