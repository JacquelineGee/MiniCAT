var t = require("../../../@babel/runtime/helpers/interopRequireDefault").default,
  e = require("../../../@babel/runtime/helpers/defineProperty"),
  a = t(require("../../../utils/myfunc.js")),
  i = require("../../../apiconfig");
Page({
  data: {
    editInfo: {},
    files: [],
    albumlbList: []
  },
  onLoad: function(t) {
    var e = a.default.userInfo(),
      i = JSON.parse(t.info),
      n = [];
    i.picurl.length > 5 && (n = i.picurl), this.setData({
      userInfo: e,
      editInfo: i,
      albumlbList: wx.getStorageSync("albumlbList"),
      files: n
    })
  },
  previewImage: function(t) {
    wx.previewImage({
      current: t.currentTarget.dataset.coverurl,
      urls: this.data.files
    })
  },
  showPicker: function(t) {
    var e = this.data[t.currentTarget.dataset.item];
    null == e || ("albumlbList" == t.currentTarget.dataset.item && e.forEach((function(t) {
      t.option = t.value
    })), this.setData({
      pickList: e,
      show_picker: !0,
      picker: t.currentTarget.dataset.item
    }))
  },
  getSelect: function(t) {
    console.log("getSelect", t.detail), "albumlbList" == this.data.picker && this.setData(e({}, "editInfo.albumlb", t.detail.data.value))
  },
  bindDateChange: function(t) {
    this.setData(e({}, "editInfo.date", t.detail.value))
  },
  changeNote: function(t) {
    var a = t.detail.value.length;
    this.setData(e({
      length: a
    }, "editInfo.note", t.detail.value))
  },
  tosave: function(t) {
    var e = Object.assign(this.data.editInfo, {
      token: a.default.userInfo().token
    });
    a.default.Post(i.dataApi + "album/albumnote_edit", e, (function(t) {
      if (wx.showLoading({
          title: "保存中",
          mask: "true"
        }), 200 == t.code) {
        wx.hideLoading();
        var e = getCurrentPages();
        e[e.length - 2].getdataList(), wx.showModal({
          title: "系统提示",
          content: "保存成功！",
          showCancel: !1,
          success: function(t) {
            t.confirm && wx.navigateBack({
              delta: 1
            })
          }
        })
      } else wx.showToast({
        title: t.msg,
        icon: "none"
      })
    }))
  },
  todel: function(t) {
    var e = this;
    wx.showModal({
      title: "温馨提示",
      content: "您确定要删除吗？",
      success: function(t) {
        if (t.confirm) {
          var n = {
            id: e.data.editInfo.id
          };
          a.default.Post(i.dataApi + "album/album_del", n, (function(t) {
            if (200 == t.code) {
              var e = getCurrentPages();
              e[e.length - 2].getdataList(), wx.showModal({
                title: "系统提示",
                content: "删除成功！",
                showCancel: !1,
                success: function(t) {
                  t.confirm && wx.navigateBack({
                    delta: 1
                  })
                }
              })
            } else wx.showToast({
              title: "删除失败!",
              icon: "none"
            })
          }))
        }
      }
    })
  }
});