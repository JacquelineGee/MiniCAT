var e = getApp(),
  t = require("../../../apiconfig"),
  a = require("../../../utils/myfunc.js");
Page({
  data: {
    currentIndex: 0,
    deskIndex: 0,
    resultList: [],
    resultlength: 0
  },
  onLoad: function(t) {
    this.setData({
      userInfo: e.globalData.userInfo
    }), this.getreferList()
  },
  changeTab: function(e) {
    var t = e.currentTarget.dataset.index;
    console.log("event dataset", e.currentTarget.dataset), this.setData({
      deskIndex: t,
      currentIndex: t
    }), console.log(this.data.currentIndex), this.getreferList(this.data.currentIndex)
  },
  getreferList: function(r) {
    var n = {
        request: "getreferlist",
        Token: e.globalData.userInfo.Token,
        cond: r
      },
      s = this;
    a.Post(t.referApi, n, (function(e) {
      if (0 == e.code) {
        var t = e.data,
          a = 0;
        a += e.data.length, t && null != t && s.setData({
          resultList: t,
          resultlength: a
        })
      }
    }))
  },
  callShop: function(e) {
    var t = e.currentTarget.dataset.item;
    console.log("shopinfo", t), wx.makePhoneCall({
      phoneNumber: t
    })
  }
});