var t = require("../../../@babel/runtime/helpers/interopRequireDefault").default,
  e = require("../../../@babel/runtime/helpers/defineProperty"),
  i = t(require("../../../utils/myfunc.js")),
  a = require("../../../apiconfig");
Page({
  data: {
    indexList: [],
    where: {
      limit: 20,
      unitid: 0,
      unitname: "-美容院-"
    },
    unitList: "",
    thList: [{
      width: 120,
      orderid: 1,
      orderlb: "byChar",
      thname: "客户",
      field: "name"
    }, {
      width: 180,
      orderid: 2,
      orderlb: "byChar",
      thname: "美容院",
      field: "unitname"
    }, {
      width: 150,
      orderid: 3,
      orderlb: "byNum",
      thname: "成交",
      field: "price1"
    }, {
      width: 120,
      orderid: 4,
      orderlb: "byChar",
      thname: "美导",
      field: "staff"
    }, {
      width: 180,
      orderid: 5,
      orderlb: "byDate",
      thname: "日期",
      field: "date"
    }]
  },
  onLoad: function(t) {
    console.log("page:", "2customer/journal/journal_list");
    var e = this;
    i.default.getList("myunitList").then((function(t) {
      e.setData({
        unitList: t.data
      }), wx.setStorageSync("unitList", t.data)
    }))
  },
  getDatalist: function(t) {
    var e = this;
    if (0 == i.default.inputCheck(this.data.where.unitid, "number")) return i.default.showTip("请选择美容院！"), !1;
    var n = {
      limit: this.data.where.limit,
      unitid: this.data.where.unitid
    };
    this.data.where.name && (n.name = this.data.where.name);
    var r = this;
    i.default.Post(a.dataApi + "journal/journal_list", n, (function(t) {
      var i = t.data,
        a = i ? i.length : 0,
        n = 0;
      a > 0 && i.forEach((function(t) {
        var e = r.data.unitList.filter((function(e) {
          return e.id == t.unitid
        }));
        t.unitname = e[0].unitname;
        var i = "复诊",
          a = "平诊";
        1 == t.zhena && (i = "初诊"), 1 == t.zhenb && (a = "专家"), t.state_zhen = i + "/" + a, n += 1 * t.price1
      }));
      var d = "计数:" + a + ", 成交:" + n;
      e.setData({
        indexList: t.data,
        msg: d
      })
    }))
  },
  clickLine: function(t) {
    var a, n = t.currentTarget.dataset.item.id,
      r = t.currentTarget.dataset.arr;
    a = i.default.selectChange(this.data[r], n), this.setData(e({}, r, a))
  },
  toAdd: function(t) {
    if (0 == this.data.where.unitid) return i.default.showTip("请选择美容院！"), !1;
    wx.navigateTo({
      url: "./journal_add?unitid=" + this.data.where.unitid
    })
  },
  toEdit: function(t) {
    var e = t.currentTarget.dataset.item;
    wx.navigateTo({
      url: "./journal_edit?info=" + JSON.stringify(e)
    })
  },
  toChanpin: function(t) {
    var e = t.currentTarget.dataset.item;
    wx.navigateTo({
      url: "./chanpin_add?info=" + JSON.stringify(e)
    })
  },
  toDel: function(t) {
    var e = t.currentTarget.dataset.item,
      n = i.default.userInfo(),
      r = this;
    wx.showModal({
      title: "温馨提示",
      content: "您确定要删除吗？",
      success: function(t) {
        if (t.confirm) {
          var d = {
            token: n.token,
            id: e.id
          };
          wx.showLoading({
            title: "删除中",
            mask: "true"
          }), i.default.Post(a.dataApi + "journal/journal_del", d, (function(t) {
            wx.hideLoading(), 200 == t.code ? (wx.showToast({
              title: "删除成功!"
            }), r.getDatalist()) : wx.showToast({
              title: "删除失败!",
              icon: "error"
            })
          }))
        }
      }
    })
  },
  showPicker: function(t) {
    var e = this.data[t.currentTarget.dataset.item];
    null == e || ("unitList" == t.currentTarget.dataset.item && e.forEach((function(t) {
      t.option = t.unitname
    })), this.setData({
      pickList: e,
      show_picker: !0,
      picker: t.currentTarget.dataset.item
    }))
  },
  getSelect: function(t) {
    "unitList" == this.data.picker && this.setData(e(e({}, "where.unitid", t.detail.data.id), "where.unitname", t.detail.data.unitname))
  },
  inputChange: function(t) {
    var i = t.currentTarget.dataset.item;
    this.setData(e({}, i, t.detail.value))
  },
  getOrder: function(t) {
    var e = t.detail.data;
    this.setData({
      indexList: e
    })
  }
});