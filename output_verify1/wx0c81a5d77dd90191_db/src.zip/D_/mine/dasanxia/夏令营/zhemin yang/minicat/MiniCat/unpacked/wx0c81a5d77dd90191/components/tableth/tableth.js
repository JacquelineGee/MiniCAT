Component({
  properties: {
    thList: Array,
    indexList: Array
  },
  data: {},
  methods: {
    byOrder: function(r) {
      var t = r.currentTarget.dataset.field,
        e = r.currentTarget.dataset.orderlb,
        a = this.data.order,
        n = this.orderBy(this.data.indexList, t, e, a);
      this.setData({
        orderid: r.currentTarget.dataset.orderid,
        order: !a
      }), this.triggerEvent("myevent", {
        data: n
      })
    },
    orderBy: function(r, t, e, a) {
      if (r && r.length > 0) {
        if ("byNum" == e) r.sort((function(r, e) {
          return 1 == a ? e[t] - r[t] : r[t] - e[t]
        }));
        else if ("byChar" == e) {
          var n = r.filter((function(r) {
              return null != r[t]
            })),
            i = r.filter((function(r) {
              return null == r[t]
            }));
          n.sort((function(r, e) {
            return 1 == a ? e[t].localeCompare(r[t], "zh") : r[t].localeCompare(e[t], "zh")
          })), r = n.concat(i)
        } else "byTime" == e ? r.sort((function(r, e) {
          return 1 == a ? e[t] > r[t] ? 1 : -1 : r[t] > e[t] ? 1 : -1
        })) : "byDate" == e && r.sort((function(r, e) {
          return null == r[t] || "" == r[t] ? 1 : null == e[t] || "" == e[t] ? -1 : 1 == a ? Date.parse(e[t]) - Date.parse(r[t]) : Date.parse(r[t]) - Date.parse(e[t])
        }));
        return r
      }
    }
  }
});