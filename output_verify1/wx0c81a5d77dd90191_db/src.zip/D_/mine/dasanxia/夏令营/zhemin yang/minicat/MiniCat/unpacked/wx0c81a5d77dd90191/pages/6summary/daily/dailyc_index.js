var t = require("../../../@babel/runtime/helpers/defineProperty"),
  e = require("../../../apiconfig"),
  a = require("../../../utils/myfunc.js");
Page({
  data: {
    navList: [{
      title: "总结概况",
      index: "1"
    }, {
      title: "见诊记录",
      index: "2"
    }, {
      title: "销售记录",
      index: "3"
    }, {
      title: "收款记录",
      index: "4"
    }],
    cIndex: 1,
    thList: [{
      width: 120,
      orderid: 1,
      orderlb: "byChar",
      thname: "员工",
      field: "staff"
    }, {
      width: 100,
      orderid: 2,
      orderlb: "byNum",
      thname: "客数",
      field: "custnum"
    }, {
      width: 150,
      orderid: 3,
      orderlb: "byNum",
      thname: "成交",
      field: "tprice"
    }, {
      width: 140,
      orderid: 4,
      orderlb: "byNum",
      thname: "收款",
      field: "receive"
    }, {
      width: 120,
      orderid: 5,
      orderlb: "byNum",
      thname: "初/复",
      field: "zhen1"
    }, {
      width: 120,
      orderid: 7,
      orderlb: "byNum",
      thname: "专/平",
      field: "zhen3"
    }],
    thList2: [{
      width: 120,
      orderid: 1,
      orderlb: "byChar",
      thname: "员工",
      field: "staff"
    }, {
      width: 200,
      orderid: 2,
      orderlb: "byChar",
      thname: "美容院",
      field: "unitname"
    }, {
      width: 150,
      orderid: 3,
      orderlb: "byChar",
      thname: "客户",
      field: "name"
    }, {
      width: 120,
      orderid: 4,
      orderlb: "byNum",
      thname: "成交",
      field: "price1"
    }, {
      width: 160,
      orderid: 5,
      orderlb: "byDate",
      thname: "日期",
      field: "date"
    }],
    thList3: [{
      width: 120,
      orderid: 1,
      orderlb: "byChar",
      thname: "员工",
      field: "staff"
    }, {
      width: 200,
      orderid: 2,
      orderlb: "byChar",
      thname: "美容院",
      field: "unitname"
    }, {
      width: 150,
      orderid: 3,
      orderlb: "byChar",
      thname: "产品",
      field: "product"
    }, {
      width: 120,
      orderid: 4,
      orderlb: "byNum",
      thname: "金额",
      field: "tprice"
    }, {
      width: 160,
      orderid: 5,
      orderlb: "byDate",
      thname: "日期",
      field: "date"
    }],
    thList4: [{
      width: 120,
      orderid: 1,
      orderlb: "byChar",
      thname: "员工",
      field: "staff"
    }, {
      width: 200,
      orderid: 2,
      orderlb: "byChar",
      thname: "美容院",
      field: "unitname"
    }, {
      width: 150,
      orderid: 3,
      orderlb: "byChar",
      thname: "客户",
      field: "name"
    }, {
      width: 120,
      orderid: 4,
      orderlb: "byNum",
      thname: "收款",
      field: "receive"
    }, {
      width: 160,
      orderid: 5,
      orderlb: "byDate",
      thname: "日期",
      field: "date"
    }],
    btnList: [],
    cIndex2: "0",
    userInfo: "",
    where: {
      date: "",
      depart: "-部门-",
      departid: ""
    },
    pickList: [],
    saleList: [],
    journalList: [],
    dailyList: [],
    dailyInfo: {},
    scrollv: 800
  },
  onLoad: function(e) {
    console.log("page:", "6summary/daily/dailyb_index");
    for (var i = [], r = 0, d = -30; d <= 0; d++) {
      var n = new Date(a.GetDateStr(d)).getDate();
      0 == d && (n = "今"), i[r] = {
        index: d,
        btnname: n
      }, r++
    }
    var l = a.GetDateStr(0);
    this.setData(t(t(t({
      btnList: i
    }, "where.date", l), "userInfo", a.userInfo()), "scrollv", 800)), this.clickBtn2(), this.getDatalist()
  },
  DateChange: function(e) {
    var i = e.detail.value,
      r = 1 - a.getdaysbyDate(i);
    this.setData(t(t({}, "where.date", i), "cIndex2", r)), this.getDatalist()
  },
  clickBtn: function(e) {
    var i = e.currentTarget.dataset.index,
      r = a.GetDateStr(i);
    this.setData(t({
      cIndex2: i
    }, "where.date", r)), this.getDatalist()
  },
  clickBtn1: function(t) {
    this.setData({
      scrollv: 0
    })
  },
  clickBtn2: function(t) {
    this.setData({
      scrollv: 950
    })
  },
  clickTab: function(t) {
    var e = t.detail.data.index;
    this.setData({
      cIndex: e
    })
  },
  getDatalist: function() {
    var t = this,
      i = {
        date: this.data.where.date
      };
    a.Post(e.dataApi + "summary/groupdaily_start", i, (function(e) {
      if (200 == e.code) {
        var a = 0,
          i = 0,
          r = 0,
          d = 0,
          n = 0,
          l = e.data.dailyList;
        l.length > 0 && l.forEach((function(t) {
          a += 1 * t.custnum, i += 1 * t.zhena, r += 1 * t.zhenb, d += 1 * t.tprice, n += 1 * t.receive
        })), t.setData({
          saleList: e.data.saleList,
          receiveList: e.data.receiveList,
          journalList: e.data.journalList,
          dailyList: e.data.dailyList,
          total: {
            custnum: a,
            zhena: i,
            zhenb: r,
            tprice: d,
            receive: n
          }
        })
      }
    }))
  },
  editinfo: function(t) {
    if (null == this.data.dailyInfo.id) return a.showTip("请选择部门！"), !1;
    var e = t.currentTarget.dataset.field,
      i = this.data.dailyInfo.id,
      r = this.data.dailyInfo[e],
      d = "";
    "dsummary" == e && (d = this.data.where.depart + "-每日总结"), "dgoal" == e && (d = this.data.where.depart + "-每日计划");
    var n = {
      id: i,
      table: "c_departdaily",
      field: e,
      note: r,
      title: d
    };
    wx.navigateTo({
      url: "/pages/9public/note/note_edit?info=" + JSON.stringify(n)
    })
  },
  showPicker: function(t) {
    var e = this.data[t.currentTarget.dataset.arr];
    e && e.length > 0 && ("mydepartList" == t.currentTarget.dataset.arr && e.forEach((function(t) {
      t.option = t.depart
    })), this.setData({
      pickList: e,
      show_picker: !0,
      picker: t.currentTarget.dataset.arr
    }))
  },
  getSelect: function(e) {
    "mydepartList" == this.data.picker && this.setData(t(t({}, "where.departid", e.detail.data.departid), "where.depart", e.detail.data.depart))
  },
  clickLine: function(e) {
    var i, r = e.currentTarget.dataset.item.id,
      d = e.currentTarget.dataset.arr;
    i = a.selectChange(this.data[d], r), this.setData(t({}, d, i))
  },
  inputChange: function(e) {
    var a = e.currentTarget.dataset.item;
    this.setData(t({}, a, e.detail.value))
  },
  getOrder: function(e) {
    var a = e.detail.data,
      i = e.currentTarget.dataset.arr;
    this.setData(t({}, i, a))
  }
});