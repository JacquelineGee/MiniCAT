var e = (0, require("../../../@babel/runtime/helpers/interopRequireDefault").default)(require("../../../utils/myfunc.js")),
  t = require("../../../apiconfig"),
  a = getApp();
Page({
  data: {
    id: "",
    item: {},
    length: 0,
    start: "",
    end: "",
    date: "",
    delpic: "",
    staff: a.globalData.userInfo.staff,
    files: []
  },
  Changedate: function(e) {
    var t = e.detail.value;
    t && this.setData({
      date: t
    })
  },
  length: function(e) {
    var t = e.detail.value.length;
    this.setData({
      length: t,
      note: e.detail.value
    })
  },
  onLoad: function(t) {
    this.setData({
      id: t.id,
      start: e.default.GetDateStr(-180),
      end: e.default.GetDateStr(10)
    }), this.requestDetail(t.id)
  },
  requestDetail: function(a) {
    var i = this,
      n = e.default.userInfo(),
      s = {
        token: n.token,
        id: a,
        staff: n.staff
      };
    e.default.Post(t.dataApi + "reimburse/reimburseinfo", s, (function(e) {
      if (200 == e.code) {
        var t = e.data;
        i.setData({
          item: t,
          length: t.note.length,
          date: t.date
        })
      }
    }))
  },
  chooseImage: function(e) {
    var t = this;
    wx.chooseImage({
      sizeType: ["original", "compressed"],
      sourceType: ["album", "camera"],
      success: function(e) {
        t.setData({
          files: t.data.files.concat(e.tempFilePaths)
        })
      }
    })
  },
  previewImage: function(e) {
    wx.previewImage({
      current: e.currentTarget.id,
      urls: this.data.files
    })
  },
  previewImage1: function(e) {
    wx.previewImage({
      current: this.data.item.pic,
      urls: [this.data.item.pic]
    })
  },
  deleteImage: function(e) {
    var t = this,
      a = t.data.files,
      i = e.currentTarget.dataset.index;
    console.log(t.data.files), console.log(t.data.files.length), wx.showModal({
      title: "系统提醒",
      content: "确定要删除此图片吗？",
      success: function(e) {
        if (e.confirm) a.splice(i, 1);
        else if (e.cancel) return !1;
        t.setData({
          files: a
        })
      }
    })
  },
  deleteImage1: function(e) {
    var t = this;
    t.data.files, e.currentTarget.dataset.index;
    console.log(t.data.files), console.log(t.data.files.length), wx.showModal({
      title: "系统提醒",
      content: "确定要删除此图片吗？",
      success: function(e) {
        if (e.confirm) {
          var a = t.data.item;
          a.pic = "", t.setData({
            item: a,
            delpic: "Y"
          })
        } else if (e.cancel) return !1
      }
    })
  },
  todel: function(a) {
    var i = this;
    wx.showModal({
      title: "温馨提示",
      content: "您确定要删除吗？",
      success: function(a) {
        if (a.confirm) {
          var n = {
            token: e.default.userInfo().token,
            id: i.data.id
          };
          e.default.Post(t.dataApi + "reimburse/reimburse_del", n, (function(e) {
            if (200 == e.code) {
              var t = getCurrentPages();
              t[t.length - 2].onLoad(), wx.showModal({
                title: "系统提示",
                content: "删除成功！",
                showCancel: !1,
                success: function(e) {
                  e.confirm && wx.navigateBack({
                    delta: 1
                  })
                }
              })
            } else wx.showToast({
              title: "删除失败!",
              icon: "none"
            })
          }))
        }
      }
    })
  },
  tosave: function(a) {
    var i = this,
      n = this;
    if (!(a.detail.value.number > 0)) return wx.showModal({
      title: "提示！！",
      content: "请输入报销金额。"
    }), !1;
    var s = {
      token: e.default.userInfo().token,
      number: a.detail.value.number,
      date: a.detail.value.date,
      note: a.detail.value.note,
      id: this.data.id
    };
    e.default.Post(t.dataApi + "reimburse/reimburse_edit", s, (function(t) {
      if (200 == t.code)
        if (1 == i.data.files.length) n.uploadImage();
        else {
          var a = getCurrentPages();
          a[a.length - 2].onLoad(), wx.showModal({
            title: "系统提示",
            content: "保存成功！",
            showCancel: !1,
            success: function(e) {
              e.confirm && wx.navigateBack({
                delta: 1
              })
            }
          })
        }
      else e.default.showTip("保存失败！")
    }))
  },
  uploadImage: function() {
    var a = e.default.userInfo();
    wx.showLoading({
      title: "图片上传中..."
    });
    var i = {
      token: a.token,
      pathlb: "reimburse",
      field: "pic",
      unitid: a.unitid,
      id: this.data.id
    };
    wx.uploadFile({
      url: t.resupApi + "Mr_img/pic_save",
      filePath: this.data.files[0],
      name: "file",
      formData: i,
      success: function(e) {
        var t = JSON.parse(e.data);
        if (console.log(t), console.log(e.data), wx.hideLoading(), 200 == t.code) {
          var a = getCurrentPages();
          a[a.length - 2].onLoad(), wx.showModal({
            title: "系统提示",
            content: "保存成功！",
            showCancel: !1,
            success: function(e) {
              e.confirm && wx.navigateBack({
                delta: 1
              })
            }
          })
        } else wx.showToast({
          title: "保存失败!",
          icon: "none"
        })
      }
    })
  }
});