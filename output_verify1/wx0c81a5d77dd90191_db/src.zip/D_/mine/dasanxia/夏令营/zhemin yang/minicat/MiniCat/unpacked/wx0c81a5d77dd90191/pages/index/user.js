var e = (0, require("../../@babel/runtime/helpers/interopRequireDefault").default)(require("../../apiconfig")),
  o = require("../../utils/myfunc.js");
Page({
  data: {
    userInfo: {},
    list_item: []
  },
  onLoad: function(e) {
    var a = this,
      t = o.userInfo();
    null != t.wx_id && t.wx_id > 0 && t.token ? (console.log("已登陆", t), "helpvideo" == e.page && wx.navigateTo({
      url: "/pages/3user/help/index?id=" + e.id
    })) : o.promisestart().then((function(o) {
      a.setData({
        userInfo: o
      }), "helpvideo" == e.page && wx.navigateTo({
        url: "/pages/3user/help/index?id=" + e.id
      })
    }))
  },
  gotologin: function() {
    var e = o.userInfo();
    e.wxuser_id && e.wxuser_id > 0 && e.groupid && e.groupid > 0 ? wx.navigateTo({
      url: "/pages/9public/login/getwx_info"
    }) : this.startbyCode()
  },
  startbyCode: function() {
    var o = this;
    wx.login({
      success: function(a) {
        console.log("startcode", a.code), wx.request({
          url: e.default.loginApi + "startbyCode",
          method: "POST",
          data: {
            code: a.code,
            groupid: o.data.userInfo.groupid
          },
          success: function(e) {
            getApp().globalData.userInfo = e.data.data, wx.setStorageSync("userInfo", e.data.data), console.log("promise resole", e.data.data), o.setData({
              userInfo: e.data.data
            })
          }
        })
      }
    })
  },
  onShow: function() {
    var e = o.userInfo();
    console.log("globalData", e), this.setData({
      list_item: [{
        icon: "/images/bacg/user.svg",
        title: "个人信息",
        url: "/pages/3user/editUser/editUser",
        code: 1,
        power: "Y"
      }, {
        icon: "/images/bacg/help.svg",
        title: "帮助中心",
        code: 3,
        url: "/pages/3user/help/index",
        power: "Y"
      }, {
        icon: "/images/bacg/refer.svg",
        title: "我的推荐",
        code: 7,
        url: "/pages/9public/login/guanlian_info",
        power: "Y"
      }],
      userInfo: e
    }), console.log("show data", this.data)
  },
  clickIterm: function(e) {
    var a = e.currentTarget.dataset.url;
    if ("myapply" == a) o.userInfo().token;
    else if ("guanlian" == a) {
      var t = o.userInfo();
      t.wxuser_id && t.wxuser_id > 0 && t.groupid && t.groupid > 0 ? wx.navigateTo({
        url: "/pages/9public/login/guanlian_info"
      }) : o.showTip("请先登陆！")
    } else a.length > 5 && wx.navigateTo({
      url: a
    })
  },
  gotoMyShop: function() {
    wx.navigateTo({
      url: "/pages/3user/myshop/myshop"
    })
  },
  gotoInfo: function() {
    var e = this.data.userInfo;
    wx.navigateTo({
      url: "/pages/3user/myinfo/myinfo?info=" + JSON.stringify(e)
    })
  },
  openMap: function() {
    wx.openLocation({
      latitude: Number(this.data.unitInfo.latitude),
      longitude: Number(this.data.unitInfo.longitude),
      scale: 19,
      name: o.userInfo().unitname,
      address: o.userInfo().address
    })
  },
  getunitinfo: function() {
    var a = this,
      t = {
        token: o.userInfo().token
      };
    o.Post(e.default.dataApi + "unit/unitinfo", t, (function(e) {
      200 == e.code && (a.setData({
        unitInfo: e.data
      }), a.openMap())
    }))
  },
  callShop: function() {
    o.callShop()
  }
});