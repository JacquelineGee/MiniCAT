var t = (0, require("../../../@babel/runtime/helpers/interopRequireDefault").default)(require("../../../apiconfig")),
  e = require("../../../utils/myfunc.js");
Page({
  data: {
    id: "",
    addressname: "",
    address: "",
    latitude: "",
    longitude: ""
  },
  onLoad: function(t) {
    console.log("page:", "1unit/map/unit_location");
    var e = JSON.parse(t.info);
    this.setData({
      id: e.id,
      addressname: e.unitname,
      address: e.address,
      latitude: e.latitude,
      longitude: e.longitude
    })
  },
  getLocation: function() {
    var t = this;
    wx.chooseLocation({
      success: function(e) {
        var i = e.latitude,
          a = e.longitude;
        t.setData({
          latitude: i,
          longitude: a,
          btnstate: 1
        })
      },
      fail: function() {
        wx.getSetting({
          success: function(t) {
            t.authSetting["scope.userLocation"] || wx.showModal({
              title: "是否授权当前位置",
              content: "需要获取您的地理位置，请确认授权，否则地图功能将无法使用",
              success: function(t) {
                t.confirm && wx.openSetting({
                  success: function(t) {
                    !0 === t.authSetting["scope.userLocation"] ? (wx.showToast({
                      title: "授权成功",
                      icon: "success",
                      duration: 1e3
                    }), wx.chooseLocation({
                      success: function(t) {
                        obj.setData({
                          addr: t.address
                        })
                      }
                    })) : wx.showToast({
                      title: "授权失败",
                      icon: "success",
                      duration: 1e3
                    })
                  }
                })
              }
            })
          },
          fail: function(t) {
            wx.showToast({
              title: "调用授权窗口失败",
              icon: "success",
              duration: 1e3
            })
          }
        })
      }
    })
  },
  saveLocation: function() {
    var i = {
      token: e.userInfo().token,
      id: this.data.id,
      latitude: this.data.latitude,
      longitude: this.data.longitude
    };
    wx.showLoading({
      title: "保存中",
      mask: "true"
    }), e.Post(t.default.dataApi + "unit/unit_edit2", i, (function(t) {
      if (200 == t.code) {
        wx.hideLoading();
        var e = getCurrentPages();
        e[e.length - 2].getDatalist(), wx.showModal({
          title: "系统提示",
          content: "保存成功！",
          success: function(t) {
            wx.navigateBack({
              delta: 1
            })
          }
        })
      } else wx.showModal({
        title: "系统提示",
        content: t.msg
      })
    }))
  }
});