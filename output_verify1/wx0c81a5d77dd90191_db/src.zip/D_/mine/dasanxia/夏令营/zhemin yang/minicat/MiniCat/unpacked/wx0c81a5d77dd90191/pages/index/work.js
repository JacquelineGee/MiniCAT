var e = (0, require("../../@babel/runtime/helpers/interopRequireDefault").default)(require("../../utils/myfunc.js"));
Page({
  data: {
    userInfo: {},
    multiple: 0,
    workList: [{
      icon: "/images/icon/journal.png",
      title: "见诊日志",
      url: "/pages/2customer/journal/journal_list",
      code: 1
    }, {
      icon: "/images/icon/nurse.svg",
      title: "订单管理",
      url: "/pages/3sale/sale/sale_list",
      code: 2
    }, {
      icon: "/images/icon/nurse.svg",
      title: "终端秒杀",
      url: "/pages/3sale/sale/miaosha_list",
      code: 9
    }, {
      icon: "/images/icon/sale.svg",
      title: "销售查询",
      url: "/pages/3sale/sale/salecp_list",
      code: 3
    }, {
      icon: "/images/icon/receive.svg",
      title: "收款查询",
      url: "/pages/3sale/receive/receive_list",
      code: 4
    }, {
      icon: "/images/icon/album1.svg",
      title: "顾客相册",
      url: "/pages/2customer/album/album_list",
      code: 5
    }, {
      icon: "/images/icon/daily.svg",
      title: "每日汇总",
      url: "/pages/6summary/daily/dailya_index",
      code: 6
    }, {
      icon: "/images/icon/month.svg",
      title: "月度汇总",
      url: "/pages/6summary/month/montha_index",
      code: 8
    }],
    resourceList: [{
      icon: "/images/icon/house.svg",
      title: "我的店家",
      code: 11,
      url: "/pages/1unit/unita/myunit_list"
    }, {
      icon: "/images/icon/mycust.svg",
      title: "客户管理",
      url: "/pages/2customer/customer/customer_list",
      code: 12
    }, {
      icon: "/images/icon/album2.svg",
      title: "共享相册",
      url: "/pages/2customer/album/sharealbum_list",
      code: 13
    }],
    proworkList: [{
      icon: "/images/icon/daily.svg",
      title: "每日汇总",
      url: "/pages/6summary/daily/dailypa_index",
      code: 21
    }, {
      icon: "/images/icon/month.svg",
      title: "月度汇总",
      url: "/pages/6summary/month/monthpa_index",
      code: 22
    }]
  },
  itermCLick: function(e) {
    var i = e.currentTarget.dataset.url;
    wx.navigateTo({
      url: i
    })
  },
  onShow: function() {
    console.log("onShow");
    var i = e.default.userInfo(),
      s = "";
    i.power && (s = i.power.weixin3);
    var a = Math.trunc((this.data.workList.length - 1) / 4);
    this.setData({
      userInfo: i,
      multiple: a,
      weixin3: s
    })
  }
});