var t = getApp(),
  e = require("../../../apiconfig"),
  a = require("../../../utils/myfunc.js");
Page({
  data: {
    cIndex: "2",
    msg: "",
    tempayList: [],
    state: "",
    date: ""
  },
  onLoad: function(t) {
    var e = this.getFirstDay(this.data.cIndex);
    this.setData({
      date: e
    }), this.getTempayList(e)
  },
  clickBtn: function(t) {
    var e = t.currentTarget.dataset.index,
      a = this.getFirstDay(e);
    this.setData({
      cIndex: e,
      date: a
    }), this.getTempayList(this.data.date)
  },
  pickDate: function(t) {
    var e = t.detail.value;
    this.setData({
      date: e
    }), this.getTempayList(e)
  },
  getFirstDay: function(t) {
    var e = new Date,
      a = e.getFullYear(),
      i = e.getMonth() + Number(t) - 1;
    return i < 10 && (i = "0" + i), a + "-" + i + "-01"
  },
  getTempayList: function(i) {
    var n = this,
      s = {
        request: "getTempayList",
        Token: t.globalData.userInfo.Token,
        date: i
      };
    a.Post(e.financeApi, s, (function(t) {
      console.log(t), 0 == t.code && (n.setData({
        tempayList: t.data,
        msg: t.msg
      }), console.log("loaddata", n.data))
    }))
  },
  clickLine: function(t) {
    var e = t.currentTarget.dataset.item,
      a = this.data.tempayList;
    a.length && (a.forEach((function(t) {
      t.id == e.id && ("0" == t.select || null == t.select) ? t.select = "1" : t.select = "0"
    })), this.setData({
      tempayList: a
    }))
  },
  toAdd: function(t) {
    wx.navigateTo({
      url: "tempay_add"
    })
  },
  clickItem1: function(t) {
    var e = t.currentTarget.dataset.item.id;
    wx.navigateTo({
      url: "./qrcode?id=" + e
    })
  },
  toEdit: function(t) {
    var e = t.currentTarget.dataset.item.id;
    wx.navigateTo({
      url: "./tempay_edit?id=" + e
    })
  },
  toDel: function(i) {
    var n = this,
      s = {
        request: "deltempay",
        id: i.currentTarget.dataset.item.id,
        Token: t.globalData.userInfo.Token
      };
    wx.showModal({
      title: "温馨提示",
      content: "您确定要删除吗？",
      success: function(t) {
        t.confirm && a.Post(e.financeApi, s, (function(t) {
          console.log(t), 0 == t.code && (wx.showToast({
            title: "删除成功!"
          }), n.getTempayList(n.data.date))
        }))
      }
    })
  }
});