var t = require("../../../@babel/runtime/helpers/interopRequireDefault").default,
  a = require("../../../@babel/runtime/helpers/defineProperty"),
  e = t(require("../../../utils/myfunc.js")),
  i = require("../../../apiconfig");
Page({
  data: {
    indexList: [],
    unitlbList: e.default.sysData("unitlb"),
    where: {
      limit: 20,
      unitname: "",
      staff: "-维护人-",
      unitlb: "合作",
      depart: "-部门-",
      departid: ""
    },
    departstaffList: "",
    mydepartList: "",
    pickList: []
  },
  onLoad: function(t) {
    console.log("page:", "1work/unit/unit_list");
    var a = this;
    e.default.getList("mydepartList").then((function(t) {
      a.setData({
        mydepartList: t.data
      })
    }))
  },
  getDatalist: function() {
    var t = this;
    if (0 == e.default.inputCheck(this.data.where.departid, "number")) return e.default.showTip("请选择部门！"), !1;
    var a = {
      limit: this.data.where.limit,
      departid: this.data.where.departid
    };
    this.data.where.unitname.length > 0 && (a.unitname = this.data.where.unitname), this.data.where.staff.length > 0 && "-维护人-" != this.data.where.staff && (a.staff = this.data.where.staff), this.data.where.unitlb.length > 0 && (a.unitlb = this.data.where.unitlb), e.default.Post(i.dataApi + "unit/departunit_list", a, (function(a) {
      if (200 == a.code) {
        var e = "计数:" + a.data.length;
        t.setData({
          indexList: a.data,
          msg: e
        })
      }
    }))
  },
  clickLine: function(t) {
    var i, r = t.currentTarget.dataset.item.id,
      n = t.currentTarget.dataset.arr;
    i = e.default.selectChange(this.data[n], r), this.setData(a({}, n, i))
  },
  toAdd: function(t) {
    wx.navigateTo({
      url: "./unit_add"
    })
  },
  toEdit: function(t) {
    var a = t.currentTarget.dataset.item;
    wx.navigateTo({
      url: "./unit_edit?info=" + JSON.stringify(a)
    })
  },
  toMap: function(t) {
    var a = this.data.indexList;
    wx.navigateTo({
      url: "../map/map_list?list=" + JSON.stringify(a)
    })
  },
  toEvent: function(t) {
    var a = t.currentTarget.dataset.item;
    wx.navigateTo({
      url: "../event/unitevent_add?info=" + JSON.stringify(a)
    })
  },
  toInfo: function(t) {
    var a = t.currentTarget.dataset.item;
    wx.navigateTo({
      url: "./unit_info?id=" + a.id
    })
  },
  selocation: function(t) {
    var a = t.currentTarget.dataset.item;
    wx.navigateTo({
      url: "../map/unit_location?info=" + JSON.stringify(a)
    })
  },
  openMap: function(t) {
    var a = t.currentTarget.dataset.item;
    wx.openLocation({
      latitude: Number(a.latitude),
      longitude: Number(a.longitude),
      scale: 19,
      name: a.unitname,
      address: a.address
    })
  },
  showPicker: function(t) {
    var a = this.data[t.currentTarget.dataset.arr];
    a && a.length > 0 && ("mydepartList" == t.currentTarget.dataset.arr && a.forEach((function(t) {
      t.option = t.depart
    })), "departstaffList" == t.currentTarget.dataset.arr && a.forEach((function(t) {
      t.option = t.staff
    })), "unitlbList" == t.currentTarget.dataset.arr && a.forEach((function(t) {
      t.option = t.value
    })), this.setData({
      pickList: a,
      show_picker: !0,
      picker: t.currentTarget.dataset.arr
    }))
  },
  getDepartstaff: function(t) {
    var a = this;
    e.default.Post(i.dataApi + "datas/departstaff_list", {
      departid: t
    }, (function(t) {
      200 == t.code && a.setData({
        departstaffList: t.data
      })
    }))
  },
  getSelect: function(t) {
    "mydepartList" == this.data.picker && (this.setData(a(a(a({}, "where.departid", t.detail.data.departid), "where.depart", t.detail.data.depart), "where.staff", "-维护人-")), this.getDepartstaff(t.detail.data.departid)), "departstaffList" == this.data.picker && this.setData(a({}, "where.staff", t.detail.data.staff)), "unitlbList" == this.data.picker && this.setData(a({}, "where.unitlb", t.detail.data.value))
  },
  inputChange: function(t) {
    var e = t.currentTarget.dataset.key;
    this.setData(a({}, e, t.detail.value))
  }
});