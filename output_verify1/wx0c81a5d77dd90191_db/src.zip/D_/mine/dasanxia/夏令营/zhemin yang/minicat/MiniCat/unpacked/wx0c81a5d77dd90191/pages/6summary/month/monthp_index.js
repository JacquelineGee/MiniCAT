var e = require("../../../@babel/runtime/helpers/defineProperty"),
  t = require("../../../apiconfig"),
  r = require("../../../utils/myfunc.js");
Page({
  data: {
    navList: [{
      title: "总结概况",
      index: "1"
    }, {
      title: "见诊记录",
      index: "2"
    }, {
      title: "产品搭配",
      index: "3"
    }, {
      title: "收款记录",
      index: "4"
    }],
    cIndex: 1,
    thList: [{
      width: 200,
      orderid: 1,
      orderlb: "byChar",
      thname: "专家",
      field: "professor"
    }, {
      width: 150,
      orderid: 2,
      orderlb: "byNum",
      thname: "客数",
      field: "custnum"
    }, {
      width: 200,
      orderid: 3,
      orderlb: "byNum",
      thname: "成交",
      field: "tprice"
    }, {
      width: 200,
      orderid: 4,
      orderlb: "byNum",
      thname: "收款",
      field: "receive1"
    }],
    thList2: [{
      width: 120,
      orderid: 1,
      orderlb: "byChar",
      thname: "专家",
      field: "professor"
    }, {
      width: 200,
      orderid: 2,
      orderlb: "byChar",
      thname: "美容院",
      field: "unitname"
    }, {
      width: 150,
      orderid: 3,
      orderlb: "byChar",
      thname: "客户",
      field: "name"
    }, {
      width: 120,
      orderid: 4,
      orderlb: "byNum",
      thname: "成交",
      field: "price1"
    }, {
      width: 160,
      orderid: 5,
      orderlb: "byDate",
      thname: "日期",
      field: "date"
    }],
    thList3: [{
      width: 120,
      orderid: 1,
      orderlb: "byChar",
      thname: "专家",
      field: "professor"
    }, {
      width: 200,
      orderid: 2,
      orderlb: "byChar",
      thname: "美容院",
      field: "unitname"
    }, {
      width: 150,
      orderid: 3,
      orderlb: "byChar",
      thname: "产品",
      field: "product"
    }, {
      width: 120,
      orderid: 4,
      orderlb: "byNum",
      thname: "金额",
      field: "tprice"
    }, {
      width: 160,
      orderid: 5,
      orderlb: "byDate",
      thname: "日期",
      field: "date"
    }],
    thList5: [{
      width: 120,
      orderid: 1,
      orderlb: "byChar",
      thname: "专家",
      field: "professor"
    }, {
      width: 200,
      orderid: 2,
      orderlb: "byChar",
      thname: "美容院",
      field: "unitname"
    }, {
      width: 150,
      orderid: 3,
      orderlb: "byNum",
      thname: "成交",
      field: "price1"
    }, {
      width: 120,
      orderid: 4,
      orderlb: "byNum",
      thname: "欠款",
      field: "price2"
    }, {
      width: 160,
      orderid: 5,
      orderlb: "byDate",
      thname: "日期",
      field: "date"
    }],
    thList4: [{
      width: 120,
      orderid: 1,
      orderlb: "byChar",
      thname: "专家",
      field: "professor"
    }, {
      width: 200,
      orderid: 2,
      orderlb: "byChar",
      thname: "美容院",
      field: "unitname"
    }, {
      width: 150,
      orderid: 3,
      orderlb: "byChar",
      thname: "客户",
      field: "name"
    }, {
      width: 120,
      orderid: 4,
      orderlb: "byNum",
      thname: "收款",
      field: "receive"
    }, {
      width: 160,
      orderid: 5,
      orderlb: "byDate",
      thname: "日期",
      field: "date"
    }],
    btnList: "",
    where: {
      date: ""
    },
    pickList: [],
    saleList: [],
    journalList: [],
    receiveList: [],
    professorData: [],
    mydepartList: []
  },
  onLoad: function(t) {
    console.log("page:", "6summary/month/monthb_index");
    for (var a = [], i = 0, d = -3; d <= 0; d++) {
      var n = r.getMonthdate(d + 1),
        o = new Date(n[0]).getMonth() + 1 + "月";
      0 == d && (o = "本月"), a[i] = {
        index: n[0],
        btnname: o
      }, i++
    }
    var h = r.getMonthdate(1)[0],
      s = this;
    r.getList("professorList").then((function(e) {
      s.setData({
        professorList: e.data
      })
    })), this.setData(e({
      btnList: a
    }, "where.date", h))
  },
  DateChange: function(t) {
    var r = t.detail.value;
    this.setData(e({}, "where.date", r)), this.getDatalist()
  },
  clickBtn: function(t) {
    var r = t.currentTarget.dataset.index;
    this.setData(e({}, "where.date", r)), this.getDatalist()
  },
  clickTab: function(e) {
    var t = e.detail.data.index;
    this.setData({
      cIndex: t
    })
  },
  getDatalist: function() {
    var e = this,
      a = {
        date: this.data.where.date
      };
    r.Post(t.dataApi + "summary/professormonth_start", a, (function(t) {
      if (200 == t.code) {
        var r, a = t.data.journalList,
          i = t.data.receiveList,
          d = [],
          n = 0,
          o = [],
          h = e.data.professorList;
        if (h.length > 0 && (h.forEach((function(e) {
            d.push({
              id: n,
              professor: e.professor,
              custnum: 0,
              zhen1: 0,
              zhena1: 0,
              zhen2: 0,
              zhena2: 0,
              zhen3: 0,
              zhena3: 0,
              zhen4: 0,
              zhena4: 0,
              tprice1: 0,
              tprice2: 0,
              tprice3: 0,
              tprice4: 0,
              tprice: 0,
              receive1: 0,
              receive2: 0,
              receive: 0,
              miaosha: 0
            }), n += 1
          })), o = h.map((function(e) {
            return e.professor
          }))), a.length > 0) {
          var s = {};
          a.forEach((function(e) {
            s[e.professor] = s[e.professor] || [], s[e.professor].push(e)
          })), o.forEach((function(e) {
            null == s[e] && (s[e] = [])
          })), o.forEach((function(e) {
            var t = 0,
              r = 0,
              a = 0,
              i = 0,
              n = 0,
              o = 0,
              h = 0,
              c = 0,
              l = 0,
              f = 0,
              u = 0,
              p = 0,
              m = 0;
            s[e].forEach((function(e) {
              t += 1, 1 * e.price1, 1 == e.zhena && 1 == e.zhenb && (r += 1, f += 1 * e.price1, e.price1 > 0 && (o += 1)), 1 == e.zhena && 0 == e.zhenb && (a += 1, u += 1 * e.price1, e.price1 > 0 && (h += 1)), 0 == e.zhena && 1 == e.zhenb && (i += 1, p += 1 * e.price1, e.price1 > 0 && (c += 1)), 0 == e.zhena && 0 == e.zhenb && (n += 1, m += 1 * e.price1, e.price1 > 0 && (l += 1))
            }));
            var b = d.indexOf(d.filter((function(t) {
                return t.professor == e
              }))[0]),
              v = d[b];
            v.custnum = t, v.zhen1 = r, v.zhena1 = o, v.zhen2 = a, v.zhena2 = h, v.zhen3 = i, v.zhena3 = c, v.zhen4 = n, v.zhena4 = l, v.tprice1 = f, v.tprice2 = u, v.tprice3 = p, v.tprice4 = m, v.tprice = f + u + p + m, d[b] = v
          }))
        }
        if (i.length > 0) {
          s = {};
          i.forEach((function(e) {
            s[e.professor] = s[e.professor] || [], s[e.professor].push(e)
          })), o.forEach((function(e) {
            null == s[e] && (s[e] = [])
          })), o.forEach((function(e) {
            var t = 0,
              r = 0;
            s[e].forEach((function(e) {
              0 == e.salelb && (t += 1 * e.receive), 1 == e.salelb && (r += 1 * e.receive)
            }));
            var a = d.indexOf(d.filter((function(t) {
                return t.professor == e
              }))[0]),
              i = d[a];
            i.receive1 = t, i.receive2 = r, d[a] = i
          }))
        }
        var c = 0,
          l = 0,
          f = 0,
          u = 0,
          p = 0,
          m = 0,
          b = 0,
          v = 0,
          z = 0,
          w = 0,
          y = 0,
          g = 0,
          L = 0,
          D = 0,
          C = 0,
          x = 0;
        d.forEach((function(e) {
          c += e.custnum, l += e.zhen1, f += e.zhen2, u += e.zhen3, p += e.zhen4, m += e.zhena1, b += e.zhena2, v += e.zhena3, z += e.zhena4, w += e.tprice1, y += e.tprice2, g += e.tprice3, L += e.tprice4, D += e.receive1, C += e.receive2, x += e.miaosha
        })), r = {
          tcustnum: c,
          tzhen1: l,
          tzhen2: f,
          tzhen3: u,
          tzhen4: p,
          tzhena1: m,
          tzhena2: b,
          tzhena3: v,
          tzhena4: z,
          ttprice1: w,
          ttprice2: y,
          ttprice3: g,
          ttprice4: L,
          ttprice: w + y + g + L,
          treceive1: D,
          treceive2: C,
          treceive: D + C,
          tmiaosha: x
        }, e.setData({
          saleList: t.data.saleList,
          receiveList: t.data.receiveList,
          journalList: a,
          professorData: d,
          total: r
        })
      }
    }))
  },
  scrollgo: function(e) {
    this.setData({
      scrollX: e.detail.scrollLeft
    })
  },
  showPicker: function(e) {
    var t = this.data[e.currentTarget.dataset.arr];
    t && t.length > 0 && ("mydepartList" == e.currentTarget.dataset.arr && t.forEach((function(e) {
      e.option = e.depart
    })), this.setData({
      pickList: t,
      show_picker: !0,
      picker: e.currentTarget.dataset.arr
    }))
  },
  getSelect: function(t) {
    "mydepartList" == this.data.picker && this.setData(e(e({}, "where.departid", t.detail.data.departid), "where.depart", t.detail.data.depart))
  },
  inputChange: function(t) {
    var r = t.currentTarget.dataset.item;
    this.setData(e({}, r, t.detail.value))
  },
  clickLine: function(t) {
    var a, i = t.currentTarget.dataset.item.id,
      d = t.currentTarget.dataset.arr;
    a = r.selectChange(this.data[d], i), this.setData(e({}, d, a))
  },
  getOrder: function(t) {
    var r = t.detail.data,
      a = t.currentTarget.dataset.arr;
    this.setData(e({}, a, r))
  },
  getOrder2: function(e) {
    var t = e.currentTarget.dataset.field,
      a = r.orderBy(this.data.professorData, t, "byNum", 0);
    this.setData({
      professorData: a,
      field: t
    })
  }
});