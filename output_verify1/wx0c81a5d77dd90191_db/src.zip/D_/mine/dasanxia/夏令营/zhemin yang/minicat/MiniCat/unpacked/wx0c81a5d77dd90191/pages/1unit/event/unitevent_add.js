var t = require("../../../@babel/runtime/helpers/interopRequireDefault").default,
  e = require("../../../@babel/runtime/helpers/defineProperty"),
  n = t(require("../../../utils/myfunc.js")),
  i = require("../../../apiconfig");
Page({
  data: {
    navList: [{
      title: "事件添加",
      index: "1"
    }, {
      title: "事件记录",
      index: "2"
    }],
    cIndex: 1,
    addInfo: "",
    unitInfo: "",
    indexList: []
  },
  onLoad: function(t) {
    console.log("page:", "1unit/event/unitevent_add");
    var n = JSON.parse(t.info);
    this.setData(e(e({
      unitInfo: n
    }, "addInfo.unitid", n.id), "addInfo.unitname", n.unitname))
  },
  clickTab: function(t) {
    var e = t.detail.data.index;
    this.setData({
      cIndex: e
    }), "2" == e && this.getEventList()
  },
  saveEvent: function() {
    if (0 == n.default.inputCheck(this.data.addInfo.note, "char")) return n.default.showTip("请填写事件内容！"), !1;
    var t = n.default.userInfo(),
      e = this.data.addInfo;
    e.token = t.token, e.staff = t.staff, wx.showLoading({
      title: "保存中",
      mask: "true"
    });
    var a = this;
    n.default.Post(i.dataApi + "event/event_add", e, (function(t) {
      wx.hideLoading(), 200 == t.code ? wx.showModal({
        title: "系统提示",
        content: "保存成功！",
        showCancel: !1,
        success: function(t) {
          a.setData({
            cIndex: 2
          }), a.getEventList()
        }
      }) : wx.showToast({
        title: t.msg,
        icon: "error"
      })
    }))
  },
  getEventList: function() {
    var t = this,
      e = {
        token: n.default.userInfo().token,
        unitid: this.data.unitInfo.id
      };
    n.default.Post(i.dataApi + "event/event_list", e, (function(e) {
      200 == e.code && t.setData({
        indexList: e.data
      })
    }))
  },
  toEdit: function(t) {
    var e = t.currentTarget.dataset.item;
    wx.navigateTo({
      url: "./unitevent_edit?id=" + e.id
    })
  },
  toDel: function(t) {
    var e = t.currentTarget.dataset.item,
      a = n.default.userInfo(),
      o = this;
    wx.showModal({
      title: "温馨提示",
      content: "您确定要删除吗？",
      success: function(t) {
        if (t.confirm) {
          var d = {
            token: a.token,
            id: e.id
          };
          n.default.Post(i.dataApi + "event/event_del", d, (function(t) {
            200 == t.code ? (wx.showToast({
              title: "删除成功!"
            }), o.getEventList()) : wx.showToast({
              title: "删除失败!",
              icon: "error"
            })
          }))
        }
      }
    })
  },
  inputChange: function(t) {
    var n = t.currentTarget.dataset.item;
    this.setData(e({}, n, t.detail.value)), "addInfo.note" == n && this.setData({
      length: t.detail.value.length
    })
  }
});