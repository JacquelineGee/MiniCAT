var t = require("../../../@babel/runtime/helpers/interopRequireDefault").default,
  e = require("../../../@babel/runtime/helpers/defineProperty"),
  a = t(require("../../../utils/myfunc.js")),
  i = require("../../../apiconfig");
Page({
  data: {
    indexList: [],
    where: {
      limit: 20,
      name: "",
      unitid: 0,
      unitname: "-美容院-"
    },
    unitList: ""
  },
  onLoad: function(t) {
    console.log("page:", "1work/customer/customer_list");
    var e = this;
    a.default.getList("myunitList").then((function(t) {
      e.setData({
        unitList: t.data
      }), wx.setStorageSync("unitList", t.data)
    }))
  },
  getDatalist: function() {
    var t = this,
      e = {
        limit: this.data.where.limit
      };
    if (!(this.data.where.unitid > 0)) return a.default.showTip("请选择美容院！"), !1;
    e.unitid = this.data.where.unitid, this.data.where.name.length > 0 && (e.name = this.data.where.name), a.default.Post(i.dataApi + "customer/mycustomer_list", e, (function(e) {
      var a = "计数:" + e.data.length;
      t.setData({
        indexList: e.data,
        msg: a
      })
    }))
  },
  clickLine: function(t) {
    var i, n = t.currentTarget.dataset.item.id,
      r = t.currentTarget.dataset.arr;
    i = a.default.selectChange(this.data[r], n), this.setData(e({}, r, i))
  },
  toAdd: function(t) {
    wx.navigateTo({
      url: "./customer_add"
    })
  },
  toEdit: function(t) {
    var e = t.currentTarget.dataset.item;
    wx.navigateTo({
      url: "./customer_edit?id=" + e.id
    })
  },
  toInfo: function(t) {
    var e = t.currentTarget.dataset.item;
    wx.navigateTo({
      url: "./customer_info?id=" + e.id
    })
  },
  showPicker: function(t) {
    var e = this.data[t.currentTarget.dataset.item];
    null == e || ("unitList" == t.currentTarget.dataset.item && e.forEach((function(t) {
      t.option = t.unitname
    })), this.setData({
      pickList: e,
      show_picker: !0,
      picker: t.currentTarget.dataset.item
    }))
  },
  getSelect: function(t) {
    "unitList" == this.data.picker && this.setData(e(e({}, "where.unitid", t.detail.data.id), "where.unitname", t.detail.data.unitname))
  },
  inputChange: function(t) {
    var a = t.currentTarget.dataset.item;
    this.setData(e({}, a, t.detail.value))
  }
});