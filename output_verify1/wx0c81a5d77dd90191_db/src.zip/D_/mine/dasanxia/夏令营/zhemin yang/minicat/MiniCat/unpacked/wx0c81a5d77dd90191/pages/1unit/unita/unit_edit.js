var t = require("../../../@babel/runtime/helpers/interopRequireDefault").default,
  e = require("../../../@babel/runtime/helpers/defineProperty"),
  i = t(require("../../../utils/myfunc.js")),
  a = require("../../../apiconfig");
Page({
  data: {
    id: "",
    editInfo: {}
  },
  onLoad: function(t) {
    console.log("page:", "1unit/unita/unit_edit");
    var e = JSON.parse(t.info);
    this.setData({
      id: t.id,
      editInfo: e,
      length: e.address.length
    })
  },
  saveEdit: function(t) {
    if (0 == i.default.inputCheck(this.data.editInfo.unitname, "char")) return i.default.showTip("请输入美容院名称"), !1;
    var e = this.data.editInfo;
    wx.showLoading({
      title: "保存中",
      mask: "true"
    }), i.default.Post(a.dataApi + "unit/unit_edit", e, (function(t) {
      if (200 == t.code) {
        wx.hideLoading();
        var e = getCurrentPages(),
          i = e[e.length - 2];
        i.getInfo && "function" == typeof i.getInfo && i.getInfo(), i.getDatalist && "function" == typeof i.getDatalist && i.getDatalist(), wx.showModal({
          title: "系统提示",
          content: "保存成功！",
          showCancel: !1,
          success: function(t) {
            t.confirm && wx.navigateBack({
              delta: 1
            })
          }
        })
      } else wx.showToast({
        title: t.msg,
        icon: "error"
      })
    }))
  },
  inputChange: function(t) {
    var i = t.currentTarget.dataset.key;
    this.setData(e({}, i, t.detail.value)), "editInfo.address" == i && this.setData({
      length: t.detail.value.length
    })
  }
});