var t = (0, require("../../../@babel/runtime/helpers/interopRequireDefault").default)(require("../../../utils/myfunc.js")),
  a = require("../../../apiconfig");
Page({
  data: {
    unitList: [],
    msg: "",
    unitname: "",
    maxid: ""
  },
  nameinput: function(t) {
    this.setData({
      unitname: t.detail.value
    })
  },
  maxidinput: function(t) {
    this.setData({
      maxid: t.detail.value
    })
  },
  onLoad: function(t) {},
  toAdd: function(t) {
    wx.navigateTo({
      url: "./unit_add"
    })
  },
  toEdit: function(t) {
    var a = t.currentTarget.dataset.item;
    wx.navigateTo({
      url: "./unit_edit?id=" + a.id
    })
  },
  toUnitInfo: function(t) {
    var a = t.currentTarget.dataset.item;
    wx.navigateTo({
      url: "./unitinfo/unitinfo?id=" + a.id
    })
  },
  selocation: function(t) {
    var a = t.currentTarget.dataset.item;
    wx.navigateTo({
      url: "./unit_location?info=" + JSON.stringify(a)
    })
  },
  getDatalist: function() {
    var e = this;
    console.log("get-data", this.data);
    var i = {
      token: t.default.userInfo().token,
      unitname: this.data.unitname,
      maxid: this.data.maxid
    };
    t.default.Post(a.dataApi + "sysrefer/unitlist", i, (function(t) {
      e.setData({
        unitList: t.data,
        msg: t.msg
      })
    }))
  },
  clickLine: function(t) {
    var a = t.currentTarget.dataset.item;
    if (null != t) {
      var e = this.data.unitList;
      e.length && (e.forEach((function(t) {
        t.id == a.id && ("0" == t.select || null == t.select) ? t.select = "1" : t.select = "0"
      })), this.setData({
        unitList: e
      }))
    }
  },
  clickShop: function(e) {
    var i = {
      unitid: e.currentTarget.dataset.item.id,
      wx_id: t.default.userInfo().wx_id
    };
    t.default.Post(a.dataApi + "login/selectunit", i, (function(t) {
      200 == t.code && (getApp().globalData.userInfo = t.data, wx.setStorageSync("userInfo", t.data), wx.reLaunch({
        url: "/pages/3user/user"
      }))
    }))
  },
  openMap: function(t) {
    var a = t.currentTarget.dataset.item;
    wx.openLocation({
      latitude: Number(a.latitude),
      longitude: Number(a.longitude),
      scale: 19,
      name: a.unitname,
      address: a.address
    })
  }
});