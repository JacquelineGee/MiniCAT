var e = require("../../../@babel/runtime/helpers/defineProperty"),
  t = require("../../../apiconfig"),
  r = require("../../../utils/myfunc.js");
Page({
  data: {
    navList: [{
      title: "总结概况",
      index: "1"
    }, {
      title: "见诊记录",
      index: "2"
    }, {
      title: "销售记录",
      index: "3"
    }, {
      title: "收款记录",
      index: "4"
    }],
    cIndex: 1,
    thList: [{
      width: 200,
      orderid: 1,
      orderlb: "byChar",
      thname: "专家",
      field: "professor"
    }, {
      width: 150,
      orderid: 2,
      orderlb: "byNum",
      thname: "客数",
      field: "custnum"
    }, {
      width: 200,
      orderid: 3,
      orderlb: "byNum",
      thname: "成交",
      field: "tprice"
    }, {
      width: 200,
      orderid: 4,
      orderlb: "byNum",
      thname: "收款",
      field: "receive1"
    }],
    thList2: [{
      width: 120,
      orderid: 1,
      orderlb: "byChar",
      thname: "专家",
      field: "professor"
    }, {
      width: 200,
      orderid: 2,
      orderlb: "byChar",
      thname: "美容院",
      field: "unitname"
    }, {
      width: 150,
      orderid: 3,
      orderlb: "byChar",
      thname: "客户",
      field: "name"
    }, {
      width: 120,
      orderid: 4,
      orderlb: "byNum",
      thname: "成交",
      field: "price1"
    }, {
      width: 160,
      orderid: 5,
      orderlb: "byDate",
      thname: "日期",
      field: "date"
    }],
    thList3: [{
      width: 120,
      orderid: 1,
      orderlb: "byChar",
      thname: "专家",
      field: "professor"
    }, {
      width: 200,
      orderid: 2,
      orderlb: "byChar",
      thname: "美容院",
      field: "unitname"
    }, {
      width: 150,
      orderid: 3,
      orderlb: "byChar",
      thname: "产品",
      field: "product"
    }, {
      width: 120,
      orderid: 4,
      orderlb: "byNum",
      thname: "金额",
      field: "tprice"
    }, {
      width: 160,
      orderid: 5,
      orderlb: "byDate",
      thname: "日期",
      field: "date"
    }],
    thList4: [{
      width: 120,
      orderid: 1,
      orderlb: "byChar",
      thname: "专家",
      field: "professor"
    }, {
      width: 200,
      orderid: 2,
      orderlb: "byChar",
      thname: "美容院",
      field: "unitname"
    }, {
      width: 150,
      orderid: 3,
      orderlb: "byChar",
      thname: "客户",
      field: "name"
    }, {
      width: 120,
      orderid: 4,
      orderlb: "byNum",
      thname: "收款",
      field: "receive"
    }, {
      width: 160,
      orderid: 5,
      orderlb: "byDate",
      thname: "日期",
      field: "date"
    }],
    btnList: [],
    cIndex2: "0",
    userInfo: "",
    where: {
      date: ""
    },
    pickList: [],
    saleList: [],
    journalList: [],
    staffdailyList: [],
    dailyInfo: {},
    scrollv: 800
  },
  onLoad: function(t) {
    console.log("page:", "6summary/daily/dailyp_index");
    for (var a = [], i = 0, n = -30; n <= 0; n++) {
      var d = new Date(r.GetDateStr(n)).getDate();
      0 == n && (d = "今"), a[i] = {
        index: n,
        btnname: d
      }, i++
    }
    var o = r.GetDateStr(0);
    this.setData(e(e(e(e({
      btnList: a
    }, "where.date", o), "where.professor", r.userInfo().staff), "userInfo", r.userInfo()), "scrollv", 200)), this.clickBtn2()
  },
  DateChange: function(t) {
    var a = t.detail.value,
      i = 1 - r.getdaysbyDate(a);
    this.setData(e(e({}, "where.date", a), "cIndex2", i)), this.getDatalist()
  },
  clickBtn: function(t) {
    var a = t.currentTarget.dataset.index,
      i = r.GetDateStr(a);
    this.setData(e({
      cIndex2: a
    }, "where.date", i)), this.getDatalist()
  },
  clickBtn1: function(e) {
    this.setData({
      scrollv: 0
    })
  },
  clickBtn2: function(e) {
    this.setData({
      scrollv: 950
    })
  },
  clickTab: function(e) {
    var t = e.detail.data.index;
    this.setData({
      cIndex: t
    })
  },
  getDatalist: function() {
    var e = this,
      a = {
        date: this.data.where.date,
        professor: r.userInfo().staff
      };
    r.Post(t.dataApi + "summary/proadaily_start", a, (function(t) {
      if (200 == t.code) {
        var a, i = t.data.journalList,
          n = t.data.receiveList,
          d = [],
          o = [r.userInfo().staff];
        if (d.push({
            id: 1,
            professor: o[0],
            custnum: 0,
            zhen1: 0,
            zhena1: 0,
            zhen2: 0,
            zhena2: 0,
            zhen3: 0,
            zhena3: 0,
            zhen4: 0,
            zhena4: 0,
            tprice1: 0,
            tprice2: 0,
            tprice3: 0,
            tprice4: 0,
            tprice: 0,
            receive1: 0,
            receive2: 0,
            receive: 0,
            miaosha: 0
          }), 1, i.length > 0) {
          var s = {};
          i.forEach((function(e) {
            s[e.professor] = s[e.professor] || [], s[e.professor].push(e)
          })), o.forEach((function(e) {
            null == s[e] && (s[e] = [])
          })), o.forEach((function(e) {
            var t = 0,
              r = 0,
              a = 0,
              i = 0,
              n = 0,
              o = 0,
              h = 0,
              c = 0,
              l = 0,
              f = 0,
              u = 0,
              p = 0,
              b = 0;
            s[e].forEach((function(e) {
              t += 1, 1 * e.price1, 1 == e.zhena && 1 == e.zhenb && (r += 1, f += 1 * e.price1, e.price1 > 0 && (o += 1)), 1 == e.zhena && 0 == e.zhenb && (a += 1, u += 1 * e.price1, e.price1 > 0 && (h += 1)), 0 == e.zhena && 1 == e.zhenb && (i += 1, p += 1 * e.price1, e.price1 > 0 && (c += 1)), 0 == e.zhena && 0 == e.zhenb && (n += 1, b += 1 * e.price1, e.price1 > 0 && (l += 1))
            }));
            var m = d.indexOf(d.filter((function(t) {
                return t.professor == e
              }))[0]),
              v = d[m];
            v.custnum = t, v.zhen1 = r, v.zhena1 = o, v.zhen2 = a, v.zhena2 = h, v.zhen3 = i, v.zhena3 = c, v.zhen4 = n, v.zhena4 = l, v.tprice1 = f, v.tprice2 = u, v.tprice3 = p, v.tprice4 = b, v.tprice = f + u + p + b, d[m] = v
          })), console.log("professorData", d)
        }
        if (n.length > 0) {
          s = {};
          n.forEach((function(e) {
            s[e.professor] = s[e.professor] || [], s[e.professor].push(e)
          })), o.forEach((function(e) {
            null == s[e] && (s[e] = [])
          })), o.forEach((function(e) {
            var t = 0,
              r = 0;
            s[e].forEach((function(e) {
              0 == e.salelb && (t += 1 * e.receive), 1 == e.salelb && (r += 1 * e.receive)
            }));
            var a = d.indexOf(d.filter((function(t) {
                return t.professor == e
              }))[0]),
              i = d[a];
            i.receive1 = t, i.receive2 = r, d[a] = i
          })), console.log("professorData", d)
        }
        var h = 0,
          c = 0,
          l = 0,
          f = 0,
          u = 0,
          p = 0,
          b = 0,
          m = 0,
          v = 0,
          y = 0,
          z = 0,
          g = 0,
          w = 0,
          D = 0,
          L = 0,
          I = 0;
        d.forEach((function(e) {
          h += e.custnum, c += e.zhen1, l += e.zhen2, f += e.zhen3, u += e.zhen4, p += e.zhena1, b += e.zhena2, m += e.zhena3, v += e.zhena4, y += e.tprice1, z += e.tprice2, g += e.tprice3, w += e.tprice4, D += e.receive1, L += e.receive2, I += e.miaosha
        })), a = {
          tcustnum: h,
          tzhen1: c,
          tzhen2: l,
          tzhen3: f,
          tzhen4: u,
          tzhena1: p,
          tzhena2: b,
          tzhena3: m,
          tzhena4: v,
          ttprice1: y,
          ttprice2: z,
          ttprice3: g,
          ttprice4: w,
          ttprice: y + z + g + w,
          treceive1: D,
          treceive2: L,
          treceive: D + L,
          tmiaosha: I
        }, e.setData({
          dailyInfo: t.data.dailyInfo,
          saleList: t.data.saleList,
          receiveList: t.data.receiveList,
          journalList: t.data.journalList,
          staffdailyList: t.data.dailyList,
          professorData: d,
          total: a
        })
      }
    }))
  },
  editinfo: function(e) {
    if (null == this.data.dailyInfo.id) return r.showTip("请选择部门！"), !1;
    var t = e.currentTarget.dataset.field,
      a = this.data.dailyInfo.id,
      i = this.data.dailyInfo[t],
      n = "";
    "dsummary" == t && (n = this.data.where.professor + "-每日总结"), "dgoal" == t && (n = this.data.where.professor + "-每日计划");
    var d = {
      id: a,
      table: "c_prodaily",
      field: t,
      note: i,
      title: n
    };
    wx.navigateTo({
      url: "/pages/9public/note/note_edit?info=" + JSON.stringify(d)
    })
  },
  scrollgo: function(e) {
    this.setData({
      scrollX: e.detail.scrollLeft
    })
  },
  showPicker: function(e) {
    var t = this.data[e.currentTarget.dataset.arr];
    t && t.length > 0 && ("professorList" == e.currentTarget.dataset.arr && t.forEach((function(e) {
      e.option = e.professor
    })), this.setData({
      pickList: t,
      show_picker: !0,
      picker: e.currentTarget.dataset.arr
    }))
  },
  getSelect: function(t) {
    "professorList" == this.data.picker && this.setData(e({}, "where.professor", t.detail.data.professor))
  },
  clickLine: function(t) {
    var a, i = t.currentTarget.dataset.item.id,
      n = t.currentTarget.dataset.arr;
    a = r.selectChange(this.data[n], i), this.setData(e({}, n, a))
  },
  inputChange: function(t) {
    var r = t.currentTarget.dataset.item;
    this.setData(e({}, r, t.detail.value))
  },
  getOrder: function(t) {
    var r = t.detail.data,
      a = t.currentTarget.dataset.arr;
    this.setData(e({}, a, r))
  },
  getOrder2: function(e) {
    var t = e.currentTarget.dataset.field,
      a = r.orderBy(this.data.professorData, t, "byNum", 0);
    this.setData({
      professorData: a,
      field: t
    })
  }
});