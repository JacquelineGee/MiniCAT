var t = require("../../../@babel/runtime/helpers/interopRequireDefault").default,
  a = require("../../../@babel/runtime/helpers/defineProperty"),
  e = t(require("../../../utils/myfunc.js")),
  i = require("../../../apiconfig");
Page({
  data: {
    dataList: [],
    unitlbList: e.default.sysData("unitlb"),
    where: {
      limit: 20,
      unitname: "",
      staff: e.default.userInfo().staff,
      unitlb: "合作"
    },
    pickList: []
  },
  onLoad: function(t) {
    console.log("page:", "1unit/unita/myunit_list")
  },
  getDatalist: function() {
    var t = this,
      a = {
        staff: e.default.userInfo().staff,
        limit: this.data.where.limit
      };
    this.data.where.unitname.length > 0 && (a.unitname = this.data.where.unitname), this.data.where.unitlb.length > 0 && (a.unitlb = this.data.where.unitlb), e.default.Post(i.dataApi + "unit/myunit_list", a, (function(a) {
      if (200 == a.code) {
        var e = "计数:" + a.data.length;
        t.setData({
          dataList: a.data,
          msg: e
        })
      }
    }))
  },
  clickLine: function(t) {
    var i, n = t.currentTarget.dataset.item.id,
      r = t.currentTarget.dataset.arr;
    i = e.default.selectChange(this.data[r], n), this.setData(a({}, r, i))
  },
  toAdd: function(t) {
    wx.navigateTo({
      url: "./unit_add"
    })
  },
  toEdit: function(t) {
    var a = t.currentTarget.dataset.item;
    wx.navigateTo({
      url: "./unit_edit?info=" + JSON.stringify(a)
    })
  },
  toMap: function(t) {
    var a = this.data.dataList;
    wx.navigateTo({
      url: "../map/map_list?list=" + JSON.stringify(a)
    })
  },
  toEvent: function(t) {
    var a = t.currentTarget.dataset.item;
    wx.navigateTo({
      url: "../event/unitevent_add?info=" + JSON.stringify(a)
    })
  },
  toInfo: function(t) {
    var a = t.currentTarget.dataset.item;
    wx.navigateTo({
      url: "./unit_info?id=" + a.id
    })
  },
  selocation: function(t) {
    var a = t.currentTarget.dataset.item;
    wx.navigateTo({
      url: "../map/unit_location?info=" + JSON.stringify(a)
    })
  },
  openMap: function(t) {
    var a = t.currentTarget.dataset.item;
    wx.openLocation({
      latitude: Number(a.latitude),
      longitude: Number(a.longitude),
      scale: 19,
      name: a.unitname,
      address: a.address
    })
  },
  showPicker: function(t) {
    var a = this.data[t.currentTarget.dataset.arr];
    null == a || ("unitlbList" == t.currentTarget.dataset.arr && a.forEach((function(t) {
      t.option = t.value
    })), this.setData({
      pickList: a,
      show_picker: !0,
      picker: t.currentTarget.dataset.arr
    }))
  },
  getSelect: function(t) {
    "unitlbList" == this.data.picker && this.setData(a({}, "where.unitlb", t.detail.data.value))
  },
  inputChange: function(t) {
    var e = t.currentTarget.dataset.key;
    this.setData(a({}, e, t.detail.value))
  }
});