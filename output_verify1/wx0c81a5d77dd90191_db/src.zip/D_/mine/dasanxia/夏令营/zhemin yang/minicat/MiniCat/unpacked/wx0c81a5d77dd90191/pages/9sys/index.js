var e = getApp();
Page({
  data: {
    power: {},
    referList: [{
      icon: "/images/sys/house.svg",
      title: "我的店家",
      code: 1,
      url: "/pages/9sys/myrefer/unit_list",
      power: "Y"
    }, {
      icon: "/images/sys/map.svg",
      title: "店家地图",
      code: 4,
      url: "/pages/9sys/myrefer/map_list",
      power: "Y"
    }, {
      icon: "/images/3icon/3-1.png",
      title: "我的推荐",
      code: 2,
      url: "/pages/9sys/myrefer/recommend",
      power: "Y"
    }, {
      icon: "/images/3icon/3-2.png",
      title: "我的二维码",
      code: 3,
      url: "/pages/9sys/myrefer/qrcode",
      power: "Y"
    }],
    sysList: [{
      icon: "/images/3icon/home.png",
      title: "美容院",
      code: 7,
      url: "/pages/9sys/unit/unit_index",
      power: "Y"
    }, {
      icon: "/images/3icon/home.png",
      title: "集团连锁",
      code: 8,
      url: "/pages/9sys/group/groupunit_index",
      power: "Y"
    }, {
      icon: "/images/3icon/3-5.png",
      title: "登陆查询",
      code: 9,
      url: "/pages/3user/sysdata/wxuser",
      power: "Y"
    }]
  },
  itermCLick: function(s) {
    if ("Y" == e.globalData.userInfo.power.weixin2 && null != e.globalData.userInfo.power.weixin2) {
      var o = s.currentTarget.dataset.url;
      wx.navigateTo({
        url: o
      })
    } else wx.showToast({
      title: "您没有得到授权！",
      icon: "none",
      duration: 1500
    })
  },
  onLoad: function() {
    this.setData({
      syspower: e.globalData.userInfo.wx_id
    })
  }
});