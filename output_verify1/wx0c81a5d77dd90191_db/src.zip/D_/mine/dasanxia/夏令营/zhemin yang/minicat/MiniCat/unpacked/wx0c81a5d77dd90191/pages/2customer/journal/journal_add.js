var t = require("../../../@babel/runtime/helpers/interopRequireDefault").default,
  a = require("../../../@babel/runtime/helpers/defineProperty"),
  e = t(require("../../../utils/myfunc.js")),
  i = require("../../../apiconfig");
Page({
  data: {
    addInfo: {
      amount: 1,
      zhena: 0,
      zhenb: 0
    },
    radiolist: [{
      name: "是",
      value: 1
    }, {
      name: "否",
      value: 0
    }],
    staffList: "",
    professorList: "",
    cidList: ""
  },
  onLoad: function(t) {
    console.log("page:", "2customer/journal/journal_add");
    var i = this;
    e.default.getcidList(t.unitid).then((function(t) {
      i.setData({
        cidList: t.data
      })
    })), e.default.getList("staffList").then((function(t) {
      i.setData({
        staffList: t.data
      })
    })), e.default.getList("professorList").then((function(t) {
      i.setData({
        professorList: t.data
      })
    })), this.setData(a(a(a(a(a({}, "addInfo.unitid", t.unitid), "addInfo.staff", e.default.userInfo().staff), "addInfo.date", e.default.GetDateStr(0)), "mindate", e.default.GetDateStr(-60)), "maxdate", e.default.GetDateStr(2)))
  },
  saveAdd: function(t) {
    if (0 == e.default.inputCheck(this.data.addInfo.cid, "number")) return e.default.showTip("请选择顾客！"), !1;
    if (0 == e.default.inputCheck(this.data.addInfo.staff, "char")) return e.default.showTip("请选择美导老师！"), !1;
    if (0 == e.default.inputCheck(this.data.addInfo.professor, "char") && 1 == this.data.addInfo.zhenb) return e.default.showTip("请选择专家！"), !1;
    var a = this.data.addInfo;
    wx.showLoading({
      title: "保存中",
      mask: "true"
    }), e.default.Post(i.dataApi + "journal/journal_add", a, (function(t) {
      if (200 == t.code) {
        wx.hideLoading();
        var a = getCurrentPages();
        a[a.length - 2].getDatalist(), wx.showModal({
          title: "系统提示",
          content: "保存成功！",
          showCancel: !1,
          success: function(t) {
            wx.navigateBack({
              delta: 1
            })
          }
        })
      } else wx.hideLoading(), wx.showToast({
        title: t.msg,
        icon: "error"
      })
    }))
  },
  showPicker: function(t) {
    var a = this.data[t.currentTarget.dataset.item];
    null == a || ("cidList" == t.currentTarget.dataset.item && a.forEach((function(t) {
      t.option = t.name
    })), "staffList" == t.currentTarget.dataset.item && a.forEach((function(t) {
      t.option = t.staff
    })), "professorList" == t.currentTarget.dataset.item && a.forEach((function(t) {
      t.option = t.professor
    })), this.setData({
      pickList: a,
      show_picker: !0,
      picker: t.currentTarget.dataset.item
    }))
  },
  getSelect: function(t) {
    "cidList" == this.data.picker && this.setData(a(a({}, "addInfo.cid", t.detail.data.id), "addInfo.name", t.detail.data.name)), "staffList" == this.data.picker && this.setData(a({}, "addInfo.staff", t.detail.data.staff)), "professorList" == this.data.picker && this.setData(a({}, "addInfo.professor", t.detail.data.professor))
  },
  inputChange: function(t) {
    var e = t.currentTarget.dataset.item;
    this.setData(a({}, e, t.detail.value)), "addInfo.note" == e && this.setData({
      length: t.detail.value.length
    })
  },
  radioChange: function(t) {
    var e = t.currentTarget.dataset.item2;
    this.setData(a({}, e, t.currentTarget.dataset.item.value))
  }
});