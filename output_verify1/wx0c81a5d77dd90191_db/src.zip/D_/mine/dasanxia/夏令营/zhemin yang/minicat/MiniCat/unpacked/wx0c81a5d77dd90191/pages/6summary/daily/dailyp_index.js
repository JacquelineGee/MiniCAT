var e = require("../../../@babel/runtime/helpers/defineProperty"),
  t = require("../../../apiconfig"),
  r = require("../../../utils/myfunc.js");
Page({
  data: {
    navList: [{
      title: "总结概况",
      index: "1"
    }, {
      title: "见诊记录",
      index: "2"
    }, {
      title: "销售记录",
      index: "3"
    }, {
      title: "收款记录",
      index: "4"
    }],
    cIndex: 1,
    thList2: [{
      width: 120,
      orderid: 1,
      orderlb: "byChar",
      thname: "专家",
      field: "professor"
    }, {
      width: 200,
      orderid: 2,
      orderlb: "byChar",
      thname: "美容院",
      field: "unitname"
    }, {
      width: 150,
      orderid: 3,
      orderlb: "byChar",
      thname: "客户",
      field: "name"
    }, {
      width: 120,
      orderid: 4,
      orderlb: "byNum",
      thname: "成交",
      field: "price1"
    }, {
      width: 160,
      orderid: 5,
      orderlb: "byDate",
      thname: "日期",
      field: "date"
    }],
    thList3: [{
      width: 120,
      orderid: 1,
      orderlb: "byChar",
      thname: "专家",
      field: "professor"
    }, {
      width: 200,
      orderid: 2,
      orderlb: "byChar",
      thname: "美容院",
      field: "unitname"
    }, {
      width: 150,
      orderid: 3,
      orderlb: "byChar",
      thname: "产品",
      field: "product"
    }, {
      width: 120,
      orderid: 4,
      orderlb: "byNum",
      thname: "金额",
      field: "tprice"
    }, {
      width: 160,
      orderid: 5,
      orderlb: "byDate",
      thname: "日期",
      field: "date"
    }],
    thList4: [{
      width: 120,
      orderid: 1,
      orderlb: "byChar",
      thname: "专家",
      field: "professor"
    }, {
      width: 200,
      orderid: 2,
      orderlb: "byChar",
      thname: "美容院",
      field: "unitname"
    }, {
      width: 150,
      orderid: 3,
      orderlb: "byChar",
      thname: "客户",
      field: "name"
    }, {
      width: 120,
      orderid: 4,
      orderlb: "byNum",
      thname: "收款",
      field: "receive"
    }, {
      width: 160,
      orderid: 5,
      orderlb: "byDate",
      thname: "日期",
      field: "date"
    }],
    btnList: [],
    cIndex2: "0",
    userInfo: "",
    where: {
      date: "",
      professor: "-专家-"
    },
    pickList: [],
    saleList: [],
    journalList: [],
    staffdailyList: [],
    dailyInfo: {},
    scrollv: 800
  },
  onLoad: function(t) {
    console.log("page:", "6summary/daily/dailyp_index");
    for (var a = [], i = 0, s = -30; s <= 0; s++) {
      var n = new Date(r.GetDateStr(s)).getDate();
      0 == s && (n = "今"), a[i] = {
        index: s,
        btnname: n
      }, i++
    }
    var o = r.GetDateStr(0);
    this.setData(e(e(e({
      btnList: a
    }, "where.date", o), "userInfo", r.userInfo()), "scrollv", 200));
    var d = this;
    r.getList("professorList").then((function(e) {
      d.setData({
        professorList: e.data
      })
    })), this.clickBtn2()
  },
  DateChange: function(t) {
    var a = t.detail.value,
      i = 1 - r.getdaysbyDate(a);
    this.setData(e(e({}, "where.date", a), "cIndex2", i)), this.getDatalist()
  },
  clickBtn: function(t) {
    var a = t.currentTarget.dataset.index,
      i = r.GetDateStr(a);
    this.setData(e({
      cIndex2: a
    }, "where.date", i)), this.getDatalist()
  },
  clickBtn1: function(e) {
    this.setData({
      scrollv: 0
    })
  },
  clickBtn2: function(e) {
    this.setData({
      scrollv: 950
    })
  },
  clickTab: function(e) {
    var t = e.detail.data.index;
    this.setData({
      cIndex: t
    })
  },
  getDatalist: function() {
    var e = this,
      a = {
        date: this.data.where.date
      };
    this.data.where.professor.length > 0 && "-专家-" != this.data.where.professor && (a.professor = this.data.where.professor), r.Post(t.dataApi + "summary/prodaily_start", a, (function(t) {
      if (200 == t.code) {
        var r, a = t.data.journalList,
          i = t.data.receiveList,
          s = e.data.professorList,
          n = [],
          o = 0,
          d = [];
        if (s.length > 0 && (s.forEach((function(e) {
            n.push({
              id: o,
              professor: e.professor,
              custnum: 0,
              zhen1: 0,
              zhena1: 0,
              zhen2: 0,
              zhena2: 0,
              zhen3: 0,
              zhena3: 0,
              zhen4: 0,
              zhena4: 0,
              tprice1: 0,
              tprice2: 0,
              tprice3: 0,
              tprice4: 0,
              tprice: 0,
              receive1: 0,
              receive2: 0,
              receive: 0,
              miaosha: 0
            }), o += 1
          })), d = s.map((function(e) {
            return e.professor
          }))), a.length > 0) {
          var h = {};
          a.forEach((function(e) {
            h[e.professor] = h[e.professor] || [], h[e.professor].push(e)
          })), d.forEach((function(e) {
            null == h[e] && (h[e] = [])
          })), d.forEach((function(e) {
            var t = 0,
              r = 0,
              a = 0,
              i = 0,
              s = 0,
              o = 0,
              d = 0,
              c = 0,
              f = 0,
              l = 0,
              u = 0,
              p = 0,
              v = 0;
            h[e].forEach((function(e) {
              t += 1, 1 * e.price1, 1 == e.zhena && 1 == e.zhenb && (r += 1, l += 1 * e.price1, e.price1 > 0 && (o += 1)), 1 == e.zhena && 0 == e.zhenb && (a += 1, u += 1 * e.price1, e.price1 > 0 && (d += 1)), 0 == e.zhena && 1 == e.zhenb && (i += 1, p += 1 * e.price1, e.price1 > 0 && (c += 1)), 0 == e.zhena && 0 == e.zhenb && (s += 1, v += 1 * e.price1, e.price1 > 0 && (f += 1))
            }));
            var m = n.indexOf(n.filter((function(t) {
                return t.professor == e
              }))[0]),
              b = n[m];
            b.custnum = t, b.zhen1 = r, b.zhena1 = o, b.zhen2 = a, b.zhena2 = d, b.zhen3 = i, b.zhena3 = c, b.zhen4 = s, b.zhena4 = f, b.tprice1 = l, b.tprice2 = u, b.tprice3 = p, b.tprice4 = v, b.tprice = l + u + p + v, n[m] = b
          })), console.log("professorData", n)
        }
        if (i.length > 0) {
          h = {};
          i.forEach((function(e) {
            h[e.professor] = h[e.professor] || [], h[e.professor].push(e)
          })), d.forEach((function(e) {
            null == h[e] && (h[e] = [])
          })), d.forEach((function(e) {
            var t = 0,
              r = 0;
            h[e].forEach((function(e) {
              0 == e.salelb && (t += 1 * e.receive), 1 == e.salelb && (r += 1 * e.receive)
            }));
            var a = n.indexOf(n.filter((function(t) {
                return t.professor == e
              }))[0]),
              i = n[a];
            i.receive1 = t, i.receive2 = r, n[a] = i
          })), console.log("professorData", n)
        }
        var c = 0,
          f = 0,
          l = 0,
          u = 0,
          p = 0,
          v = 0,
          m = 0,
          b = 0,
          g = 0,
          y = 0,
          z = 0,
          D = 0,
          w = 0,
          L = 0,
          x = 0,
          I = 0;
        n.forEach((function(e) {
          c += e.custnum, f += e.zhen1, l += e.zhen2, u += e.zhen3, p += e.zhen4, v += e.zhena1, m += e.zhena2, b += e.zhena3, g += e.zhena4, y += e.tprice1, z += e.tprice2, D += e.tprice3, w += e.tprice4, L += e.receive1, x += e.receive2, I += e.miaosha
        })), r = {
          tcustnum: c,
          tzhen1: f,
          tzhen2: l,
          tzhen3: u,
          tzhen4: p,
          tzhena1: v,
          tzhena2: m,
          tzhena3: b,
          tzhena4: g,
          ttprice1: y,
          ttprice2: z,
          ttprice3: D,
          ttprice4: w,
          ttprice: y + z + D + w,
          treceive1: L,
          treceive2: x,
          treceive: L + x,
          tmiaosha: I
        }, e.setData({
          dailyInfo: t.data.dailyInfo,
          saleList: t.data.saleList,
          receiveList: t.data.receiveList,
          journalList: t.data.journalList,
          staffdailyList: t.data.dailyList,
          professorData: n,
          total: r
        })
      }
    }))
  },
  editinfo: function(e) {
    if (null == this.data.dailyInfo.id) return r.showTip("请选择部门！"), !1;
    var t = e.currentTarget.dataset.field,
      a = this.data.dailyInfo.id,
      i = this.data.dailyInfo[t],
      s = "";
    "dsummary" == t && (s = this.data.where.professor + "-每日总结"), "dgoal" == t && (s = this.data.where.professor + "-每日计划");
    var n = {
      id: a,
      table: "c_professordaily",
      field: t,
      note: i,
      title: s
    };
    wx.navigateTo({
      url: "/pages/9public/note/note_edit?info=" + JSON.stringify(n)
    })
  },
  scrollgo: function(e) {
    this.setData({
      scrollX: e.detail.scrollLeft
    })
  },
  showPicker: function(e) {
    var t = this.data[e.currentTarget.dataset.arr];
    t && t.length > 0 && ("professorList" == e.currentTarget.dataset.arr && t.forEach((function(e) {
      e.option = e.professor
    })), this.setData({
      pickList: t,
      show_picker: !0,
      picker: e.currentTarget.dataset.arr
    }))
  },
  getSelect: function(t) {
    "professorList" == this.data.picker && this.setData(e({}, "where.professor", t.detail.data.professor))
  },
  clickLine: function(t) {
    var a, i = t.currentTarget.dataset.item.id,
      s = t.currentTarget.dataset.arr;
    if (a = r.selectChange(this.data[s], i), this.setData(e({}, s, a)), "professorData" == s) {
      var n = this.data.professorData.filter((function(e) {
        return e.id == i
      }))[0];
      console.log("temp", n);
      var o = n.professor,
        d = [],
        h = this.data.staffdailyList.filter((function(e) {
          return e.professor == o
        }));
      console.log("staffsummary", h), h.length > 0 && (d = h[0]), this.setData({
        staffsummary: d
      })
    }
  },
  inputChange: function(t) {
    var r = t.currentTarget.dataset.item;
    this.setData(e({}, r, t.detail.value))
  },
  getOrder: function(t) {
    var r = t.detail.data,
      a = t.currentTarget.dataset.arr;
    this.setData(e({}, a, r))
  },
  getOrder2: function(e) {
    var t = e.currentTarget.dataset.field,
      a = r.orderBy(this.data.professorData, t, "byNum", 0);
    this.setData({
      professorData: a,
      field: t
    })
  }
});