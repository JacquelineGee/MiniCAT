Component({
  properties: {
    navList: Array,
    cIndex: Number
  },
  data: {},
  methods: {
    clickTab: function(t) {
      var e = t.currentTarget.dataset.item;
      this.setData({
        cIndex: e.index
      }), this.triggerEvent("myevent", {
        data: e
      })
    }
  }
});