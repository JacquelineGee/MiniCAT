var t = (0, require("../../../@babel/runtime/helpers/interopRequireDefault").default)(require("../../../utils/myfunc.js")),
  n = require("../../../apiconfig");
Page({
  data: {
    id: "",
    infolb: "",
    infolb2: "",
    name: "",
    infocontent: "",
    length: ""
  },
  onLoad: function(n) {
    console.log("options", n);
    var e = n.infolb,
      i = n.id,
      a = "";
    "marital" == e && (a = "1.婚姻家庭"), "procreation" == e && (a = "2.生育情况"), "health" == e && (a = "3.健康情况"), "economic" == e && (a = "4.工作经济"), "charact" == e && (a = "5.个人特点"), this.setData({
      id: i,
      infolb: e,
      infolb2: a
    });
    var o = this;
    t.default.getInfo("d_cid", i).then((function(t) {
      o.setData({
        infocontent: t.data[e],
        name: t.data.name
      })
    }))
  },
  noteChange: function(t) {
    var n = t.detail.value.length;
    this.setData({
      length: n,
      infocontent: t.detail.value
    })
  },
  saveInfoN: function() {
    var e = {
      id: this.data.id,
      infolb: this.data.infolb,
      infocontent: this.data.infocontent
    };
    t.default.Post(n.dataApi + "customer/infoN_edit", e, (function(t) {
      if (200 == t.code) {
        var n = getCurrentPages(),
          e = n[n.length - 2];
        e.getCidinfo && "function" == typeof e.getCidinfo && e.getCidinfo(), wx.showModal({
          title: "系统提示",
          content: t.msg,
          success: function() {
            wx.navigateBack({
              detal: 1
            })
          }
        })
      } else wx.showToast({
        title: t.msg,
        icon: "none"
      })
    }))
  }
});