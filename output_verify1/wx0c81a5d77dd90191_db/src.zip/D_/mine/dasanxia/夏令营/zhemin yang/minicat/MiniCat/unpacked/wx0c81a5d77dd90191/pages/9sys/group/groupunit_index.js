var t = (0, require("../../../@babel/runtime/helpers/interopRequireDefault").default)(require("../../../utils/myfunc.js")),
  e = require("../../../apiconfig");
getApp();
Page({
  data: {
    groupList: [],
    groupid: "",
    groupname: "",
    unitList: [],
    msg: "",
    unitname: "",
    show_picker: !1,
    pickList: [],
    picker: ""
  },
  nameinput: function(t) {
    this.setData({
      unitname: t.detail.value
    })
  },
  onLoad: function(t) {
    this.getGroupList()
  },
  selocation: function(t) {
    var e = t.currentTarget.dataset.item;
    console.log("item", e), wx.navigateTo({
      url: "./selocation?info=" + JSON.stringify(e)
    })
  },
  showPicker: function(t) {
    var e = this.data[t.currentTarget.dataset.item];
    null == e || ("groupList" == t.currentTarget.dataset.item && e.forEach((function(t) {
      t.option = t.unitname
    })), this.setData({
      pickList: e,
      show_picker: !0,
      picker: t.currentTarget.dataset.item
    })), console.log("this.data.pickList", this.data.pickList)
  },
  getSelect: function(t) {
    console.log("getSelect", t.detail), "groupList" == this.data.picker && this.setData({
      groupid: t.detail.data.id,
      groupname: t.detail.data.unitname
    })
  },
  getUnitList: function() {
    var a = this,
      i = {
        token: t.default.userInfo().token,
        unitname: this.data.unitname,
        groupid: this.data.groupid
      };
    t.default.Post(e.dataApi + "unit/unitlist2", i, (function(t) {
      a.setData({
        unitList: t.data,
        msg: t.msg
      })
    }))
  },
  getGroupList: function() {
    var a = this,
      i = {
        token: t.default.userInfo().token
      };
    t.default.Post(e.dataApi + "group/unitlist", i, (function(t) {
      a.setData({
        groupList: t.data,
        msg: t.msg
      })
    }))
  },
  clickLine: function(t) {
    var e = t.currentTarget.dataset.item;
    if (null != t) {
      var a = this.data.unitList;
      a.length && (a.forEach((function(t) {
        t.id == e.id && ("0" == t.select || null == t.select) ? t.select = "1" : t.select = "0"
      })), this.setData({
        unitList: a
      }))
    }
  },
  clickShop: function(a) {
    var i = {
      unitid: a.currentTarget.dataset.item.id,
      wx_id: t.default.userInfo().wx_id
    };
    t.default.Post(e.dataApi + "login/selectunit", i, (function(t) {
      200 == t.code && (getApp().globalData.userInfo = t.data, wx.setStorageSync("userInfo", t.data), wx.reLaunch({
        url: "/pages/3user/user"
      }))
    }))
  },
  openMap: function(t) {
    var e = t.currentTarget.dataset.item;
    wx.openLocation({
      latitude: Number(e.latitude),
      longitude: Number(e.longitude),
      scale: 19,
      name: e.unitname,
      address: e.address
    })
  },
  makeCall: function(t) {
    var e = t.currentTarget.dataset.tel;
    wx.makePhoneCall({
      phoneNumber: e
    })
  }
});