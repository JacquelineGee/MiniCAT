Page({
  data: {},
  onLoad: function(t) {
    var a = wx.getStorageSync("userInfo");
    this.setData({
      url: "https://meiyiy.cn/wxlogin/avatar_myj_index.php",
      groupid: a.groupid,
      wxuser_id: a.wxuser_id
    }), console.log(this.data)
  },
  handleGetMessage: function(t) {
    var a = getCurrentPages(),
      e = a[a.length - 2];
    t.detail.data[0];
    e.startbyCode()
  }
});