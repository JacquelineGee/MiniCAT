var e = (0, require("../../../@babel/runtime/helpers/interopRequireDefault").default)(require("../../../utils/myfunc.js")),
  t = require("../../../apiconfig"),
  a = getApp();
Page({
  data: {
    length: 0,
    note: "",
    canClick: 1
  },
  onLoad: function(e) {},
  changeNote: function(e) {
    var t = e.detail.value.length;
    this.setData({
      length: t,
      note: e.detail.value
    })
  },
  formSubmit: function(n) {
    if (n.detail.value.goods_title.length < 2) return wx.showToast({
      title: "请输入订单名称！",
      icon: "none"
    }), !1;
    if (!(n.detail.value.pay_amt > 0)) return wx.showToast({
      title: "请输入订单金额！",
      icon: "none"
    }), !1;
    var o = {
        request: "addTempay",
        Token: a.globalData.userInfo.Token,
        goods_title: n.detail.value.goods_title,
        pay_amt: n.detail.value.pay_amt,
        name: n.detail.value.name,
        note: n.detail.value.note
      },
      i = this;
    e.default.Post(t.financeApi, o, (function(e) {
      if (i.setData({
          canClick: 0
        }), 0 == e.code) {
        var t = getCurrentPages();
        t[t.length - 2].onLoad(), wx.showModal({
          title: "系统提示",
          content: "保存成功！",
          showCancel: !1,
          success: function(e) {
            e.confirm && wx.navigateBack({
              delta: 1
            })
          }
        })
      } else wx.showToast({
        title: "保存失败！",
        icon: "none"
      })
    }))
  }
});