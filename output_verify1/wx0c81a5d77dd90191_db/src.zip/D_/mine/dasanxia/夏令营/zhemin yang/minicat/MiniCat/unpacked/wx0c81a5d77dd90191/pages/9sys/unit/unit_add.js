var t = (0, require("../../../@babel/runtime/helpers/interopRequireDefault").default)(require("../../../utils/myfunc.js")),
  e = require("../../../apiconfig");
getApp();
Page({
  data: {
    id: "",
    unitname: "",
    note: "",
    canClick: 1
  },
  onLoad: function(t) {
    this.getUnitaddstart()
  },
  getUnitaddstart: function() {
    var a = this,
      n = {
        token: t.default.userInfo().token
      };
    t.default.Post(e.dataApi + "sysdata/newunitid", n, (function(t) {
      200 == t.code && a.setData({
        id: t.data
      })
    }))
  },
  changeNote: function(t) {
    var e = t.detail.value.length;
    this.setData({
      length: e,
      note: t.detail.value
    })
  },
  formSubmit: function(a) {
    var n = this;
    if (a.detail.value.unitname.length < 2) return wx.showToast({
      title: "请填写美容院名称！",
      icon: "none",
      duration: 1600
    }), !1;
    var i = {
      token: t.default.userInfo().token,
      id: a.detail.value.id,
      unitname: a.detail.value.unitname,
      tel: a.detail.value.tel,
      address: this.data.note
    };
    t.default.Post(e.dataApi + "sysdata/saveunit", i, (function(t) {
      n.setData({
        canClick: 0
      }), 200 == t.code && wx.showModal({
        title: "系统提示",
        content: "保存成功！",
        success: function(t) {
          wx.navigateBack({
            delta: 1
          })
        }
      }), 0 == t.code && (wx.showToast({
        title: t.msg,
        icon: "none",
        duration: 1600
      }), n.setData({
        canClick: 1
      }))
    }))
  }
});