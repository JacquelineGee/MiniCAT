var e = require("../../../@babel/runtime/helpers/defineProperty"),
  t = require("../../../apiconfig"),
  a = require("../../../utils/myfunc.js");
Page({
  data: {
    navList: [{
      title: "总结概况",
      index: "1"
    }, {
      title: "见诊记录",
      index: "2"
    }, {
      title: "产品搭配",
      index: "3"
    }, {
      title: "收款记录",
      index: "4"
    }, {
      title: "门店秒杀",
      index: "5"
    }],
    cIndex: 1,
    thList: [{
      width: 200,
      orderid: 1,
      orderlb: "byChar",
      thname: "员工",
      field: "staff"
    }, {
      width: 150,
      orderid: 2,
      orderlb: "byNum",
      thname: "客数",
      field: "custnum"
    }, {
      width: 200,
      orderid: 3,
      orderlb: "byNum",
      thname: "成交",
      field: "tprice"
    }, {
      width: 200,
      orderid: 4,
      orderlb: "byNum",
      thname: "收款",
      field: "receive1"
    }],
    thList5: [{
      width: 120,
      orderid: 1,
      orderlb: "byChar",
      thname: "员工",
      field: "staff"
    }, {
      width: 200,
      orderid: 2,
      orderlb: "byChar",
      thname: "美容院",
      field: "unitname"
    }, {
      width: 150,
      orderid: 3,
      orderlb: "byNum",
      thname: "成交",
      field: "price1"
    }, {
      width: 120,
      orderid: 4,
      orderlb: "byNum",
      thname: "欠款",
      field: "price2"
    }, {
      width: 160,
      orderid: 5,
      orderlb: "byDate",
      thname: "日期",
      field: "date"
    }],
    btnList: "",
    cIndex2: "0",
    userInfo: "",
    where: {
      date: ""
    },
    dailyInfo: "",
    saleList: "",
    journalList: ""
  },
  onLoad: function(t) {
    console.log("page:", "6summary/daily/summarya_index");
    for (var i = [], r = 0, n = -4; n <= 0; n++) {
      var f = new Date(a.GetDateStr(n)).getDate();
      0 == n && (f = "今天"), i[r] = {
        index: n,
        btnname: f
      }, r++
    }
    var d = a.GetDateStr(0);
    this.setData(e(e(e({
      btnList: i
    }, "where.date", d), "where.staff", a.userInfo().staff), "userInfo", a.userInfo())), this.getDatalist()
  },
  DateChange: function(t) {
    var a = t.detail.value;
    this.setData(e({}, "where.date", a)), this.getDatalist()
  },
  clickBtn: function(t) {
    var i = t.currentTarget.dataset.index,
      r = a.GetDateStr(i);
    this.setData(e({
      cIndex2: i
    }, "where.date", r)), this.getDatalist()
  },
  clickTab: function(e) {
    var t = e.detail.data.index;
    this.setData({
      cIndex: t
    })
  },
  getDatalist: function() {
    var e = this,
      i = this.data.where;
    a.Post(t.dataApi + "summary/staffdaily2_start", i, (function(t) {
      if (200 == t.code) {
        var i = t.data.journalList,
          r = t.data.miaoshaList,
          n = t.data.receiveList,
          f = [],
          d = 0,
          s = [a.userInfo().staff];
        if (s.length > 0 && s.forEach((function(e) {
            f.push({
              id: d,
              staff: e,
              custnum: 0,
              zhen1: 0,
              zhena1: 0,
              zhen2: 0,
              zhena2: 0,
              zhen3: 0,
              zhena3: 0,
              zhen4: 0,
              zhena4: 0,
              tprice1: 0,
              tprice2: 0,
              tprice3: 0,
              tprice4: 0,
              tprice: 0,
              receive1: 0,
              receive2: 0,
              receive: 0,
              miaosha: 0
            }), d += 1
          })), i.length > 0) {
          var h = {};
          i.forEach((function(e) {
            h[e.staff] = h[e.staff] || [], h[e.staff].push(e)
          })), s.forEach((function(e) {
            null == h[e] && (h[e] = [])
          })), s.forEach((function(e) {
            var t = 0,
              a = 0,
              i = 0,
              r = 0,
              n = 0,
              d = 0,
              s = 0,
              c = 0,
              o = 0,
              l = 0,
              u = 0,
              p = 0,
              m = 0;
            h[e].forEach((function(e) {
              t += 1, 1 * e.price1, 1 == e.zhena && 1 == e.zhenb && (a += 1, l += 1 * e.price1, e.price1 > 0 && (d += 1)), 1 == e.zhena && 0 == e.zhenb && (i += 1, u += 1 * e.price1, e.price1 > 0 && (s += 1)), 0 == e.zhena && 1 == e.zhenb && (r += 1, p += 1 * e.price1, e.price1 > 0 && (c += 1)), 0 == e.zhena && 0 == e.zhenb && (n += 1, m += 1 * e.price1, e.price1 > 0 && (o += 1))
            }));
            var v = f.indexOf(f.filter((function(t) {
                return t.staff == e
              }))[0]),
              b = f[v];
            b.custnum = t, b.zhen1 = a, b.zhena1 = d, b.zhen2 = i, b.zhena2 = s, b.zhen3 = r, b.zhena3 = c, b.zhen4 = n, b.zhena4 = o, b.tprice1 = l, b.tprice2 = u, b.tprice3 = p, b.tprice4 = m, b.tprice = l + u + p + m, f[v] = b
          }))
        }
        if (r.length > 0 && (h = {}, r.forEach((function(e) {
            h[e.staff] = h[e.staff] || [], h[e.staff].push(e)
          })), s.forEach((function(e) {
            null == h[e] && (h[e] = [])
          })), s.forEach((function(e) {
            var t = 0;
            h[e].forEach((function(e) {
              t += 1 * e.price1
            }));
            var a = f.indexOf(f.filter((function(t) {
                return t.staff == e
              }))[0]),
              i = f[a];
            i.miaosha = t, f[a] = i
          }))), n.length > 0) {
          h = {};
          n.forEach((function(e) {
            h[e.staff] = h[e.staff] || [], h[e.staff].push(e)
          })), s.forEach((function(e) {
            null == h[e] && (h[e] = [])
          })), s.forEach((function(e) {
            var t = 0,
              a = 0;
            h[e].forEach((function(e) {
              0 == e.salelb && (t += 1 * e.receive), 1 == e.salelb && (a += 1 * e.receive)
            }));
            var i = f.indexOf(f.filter((function(t) {
                return t.staff == e
              }))[0]),
              r = f[i];
            r.receive1 = t, r.receive2 = a, f[i] = r
          }))
        }
        console.log("staffData", f), e.setData({
          dailyInfo: t.data.dailyInfo,
          saleList: t.data.saleList,
          receiveList: t.data.receiveList,
          journalList: t.data.journalList,
          dailyList: t.data.dailyList,
          staffData: f
        })
      }
    }))
  },
  clickLine: function(t) {
    var i, r = t.currentTarget.dataset.item.id,
      n = t.currentTarget.dataset.arr;
    i = a.selectChange(this.data[n], r), this.setData(e({}, n, i))
  },
  editinfo: function(e) {
    if (null == this.data.dailyInfo.id) return a.showTip("请选择日期！"), !1;
    var t = e.currentTarget.dataset.field,
      i = this.data.dailyInfo.id,
      r = this.data.dailyInfo[t],
      n = "";
    "dsummary" == t && (n = this.data.where.staff + "-每日总结"), "dgoal" == t && (n = this.data.where.staff + "-每日计划");
    var f = {
      id: i,
      table: "c_staffdaily",
      field: t,
      note: r,
      title: n
    };
    wx.navigateTo({
      url: "/pages/9public/note/note_edit?info=" + JSON.stringify(f)
    })
  },
  getOrder: function(e) {}
});