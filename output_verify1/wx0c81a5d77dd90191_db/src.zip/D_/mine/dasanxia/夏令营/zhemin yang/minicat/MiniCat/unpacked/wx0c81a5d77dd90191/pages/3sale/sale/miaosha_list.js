var t = require("../../../@babel/runtime/helpers/interopRequireDefault").default,
  e = require("../../../@babel/runtime/helpers/defineProperty"),
  a = t(require("../../../utils/myfunc.js")),
  i = require("../../../apiconfig");
Page({
  data: {
    indexList: [],
    where: {
      unitid: 0,
      unitname: "-美容院-"
    },
    unitList: "",
    thList: [{
      width: 200,
      orderid: 2,
      orderlb: "byChar",
      thname: "美容院",
      field: "unitname"
    }, {
      width: 200,
      orderid: 3,
      orderlb: "byNum",
      thname: "欠款",
      field: "price2"
    }, {
      width: 150,
      orderid: 4,
      orderlb: "byChar",
      thname: "美导",
      field: "staff"
    }, {
      width: 200,
      orderid: 5,
      orderlb: "byDate",
      thname: "日期",
      field: "date"
    }]
  },
  onLoad: function(t) {
    console.log("page:", "2customer/journal/journal_list");
    var e = this;
    a.default.getList("myunitList").then((function(t) {
      e.setData({
        unitList: t.data
      }), wx.setStorageSync("unitList", t.data)
    }))
  },
  getDatalist: function(t) {
    var e = this;
    if (0 == a.default.inputCheck(this.data.where.unitid, "number")) return a.default.showTip("请选择美容院！"), !1;
    var n = {
      token: a.default.userInfo().token,
      unitid: this.data.where.unitid
    };
    this.data.where.name && (n.name = this.data.where.name);
    var r = this;
    a.default.Post(i.dataApi + "sale/miaosha_list", n, (function(t) {
      var a = t.data,
        i = a ? a.length : 0,
        n = 0;
      i > 0 && a.forEach((function(t) {
        var e = r.data.unitList.filter((function(e) {
          return e.id == t.unitid
        }));
        t.unitname = e[0].unitname, n += 1 * t.price2
      }));
      var d = "计数:" + i + ", 欠款:" + n;
      e.setData({
        indexList: t.data,
        msg: d
      })
    }))
  },
  clickLine: function(t) {
    var i, n = t.currentTarget.dataset.item.id,
      r = t.currentTarget.dataset.arr;
    i = a.default.selectChange(this.data[r], n), this.setData(e({}, r, i))
  },
  toAdd: function(t) {
    if (0 == this.data.where.unitid) return a.default.showTip("请选择美容院！"), !1;
    wx.navigateTo({
      url: "./miaosha_add?unitid=" + this.data.where.unitid
    })
  },
  toReceive: function(t) {
    var e = t.currentTarget.dataset.item;
    wx.navigateTo({
      url: "/pages/3sale/receive/receive_add?info=" + JSON.stringify(e)
    })
  },
  toDel: function(t) {
    var e = t.currentTarget.dataset.item,
      n = a.default.userInfo(),
      r = this;
    wx.showModal({
      title: "温馨提示",
      content: "您确定要删除吗？",
      success: function(t) {
        if (t.confirm) {
          var d = {
            token: n.token,
            id: e.id
          };
          wx.showLoading({
            title: "删除中",
            mask: "true"
          }), a.default.Post(i.dataApi + "sale/miaosha_del", d, (function(t) {
            wx.hideLoading(), 200 == t.code ? (wx.showToast({
              title: "删除成功!"
            }), r.getDatalist()) : wx.showToast({
              title: "删除失败!",
              icon: "error"
            })
          }))
        }
      }
    })
  },
  showPicker: function(t) {
    var e = this.data[t.currentTarget.dataset.item];
    null == e || ("unitList" == t.currentTarget.dataset.item && e.forEach((function(t) {
      t.option = t.unitname
    })), this.setData({
      pickList: e,
      show_picker: !0,
      picker: t.currentTarget.dataset.item
    }))
  },
  getSelect: function(t) {
    "unitList" == this.data.picker && this.setData(e(e({}, "where.unitid", t.detail.data.id), "where.unitname", t.detail.data.unitname))
  },
  inputChange: function(t) {
    var a = t.currentTarget.dataset.item;
    this.setData(e({}, a, t.detail.value))
  },
  getOrder: function(t) {
    var e = t.detail.data;
    this.setData({
      indexList: e
    })
  }
});