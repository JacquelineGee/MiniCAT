var e = require("../../../@babel/runtime/helpers/interopRequireDefault").default,
  t = e(require("../../../utils/myfunc.js")),
  a = e(require("../../../utils/config.js")),
  o = require("../../../apiconfig");
Page({
  data: {
    userInfo: {},
    userstate: "0",
    code: ""
  },
  onLoad: function(e) {
    var t = wx.getStorageSync("userInfo"),
      a = 0;
    t.avatar && t.avatar.length > 10 && (a = 1), this.setData({
      userInfo: t,
      userstate: a
    })
  },
  getcode: function() {
    var e = this;
    wx.login({
      success: function(t) {
        e.setData({
          code: t.code
        })
      }
    })
  },
  getUserProfile: function() {
    this.getcode();
    var e = this;
    wx.getUserProfile({
      desc: "头像展示",
      success: function(t) {
        console.log("profile", t.userInfo), e.updateavatar(t.userInfo.nickName, t.userInfo.avatarUrl, e.data.code)
      }
    })
  },
  updateavatar: function(e, n, r) {
    var s = {
      avatar: n,
      nickname: e,
      code: r,
      groupid: a.default.groupid
    };
    t.default.Post(o.loginApi + "updateavatar", s, (function(e) {
      200 == e.code ? (getApp().globalData.userInfo = e.data, wx.setStorageSync("userInfo", e.data), wx.showModal({
        title: "系统提示",
        content: "登陆成功!",
        success: function() {
          wx.navigateBack()
        }
      })) : wx.showModal({
        title: "系统提示",
        content: "微信登录失败!!!!!!"
      })
    }))
  },
  backAction: function() {
    wx.navigateBack()
  }
});