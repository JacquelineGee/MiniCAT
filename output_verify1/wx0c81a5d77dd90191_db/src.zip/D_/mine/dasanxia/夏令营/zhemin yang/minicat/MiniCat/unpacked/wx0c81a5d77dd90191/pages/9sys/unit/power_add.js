var t = (0, require("../../../@babel/runtime/helpers/interopRequireDefault").default)(require("../../../utils/myfunc.js")),
  a = require("../../../apiconfig"),
  e = getApp();
Page({
  data: {
    powerList: "",
    power: "",
    nickname: "",
    unitid: "",
    inputValue: "",
    state_show: !1,
    canClick: 1
  },
  hidePicker: function() {
    this.setData({
      state_show: !1,
      inputValue: ""
    })
  },
  showPicker: function(t) {
    this.setData({
      temparray: this.data[t.currentTarget.dataset.item],
      currentName: t.currentTarget.dataset.item,
      state_show: !0
    }), console.log("data", this.data)
  },
  getSelect: function(t) {
    var a = t.currentTarget.dataset.item;
    "powerList" == this.data.currentName && this.setData({
      power: a.value
    }), this.hidePicker()
  },
  getInput: function(a) {
    this.setData({
      inputValue: a.detail.value
    });
    var e = a.detail.value,
      i = this.data[this.data.currentName],
      n = t.default.searchList(e, i);
    this.setData({
      temparray: n
    })
  },
  onLoad: function(t) {
    this.setData({
      unitid: t.unitid
    }), this.getPoweraddstart(t.unitid)
  },
  getPoweraddstart: function(e) {
    var i = this,
      n = {
        token: t.default.userInfo().token,
        unitid: e
      };
    t.default.Post(a.dataApi + "sysdata/powerlblist", n, (function(t) {
      200 == t.code && i.setData({
        powerList: t.data
      })
    }))
  },
  getInputwxid: function(t) {
    this.setData({
      wx_id: t.detail.value
    })
  },
  getNickname: function(e) {
    var i = this,
      n = {
        token: t.default.userInfo().token,
        wx_id: this.data.wx_id
      };
    t.default.Post(a.dataApi + "sysdata/nickname", n, (function(t) {
      200 == t.code && i.setData({
        nickname: t.data
      })
    }))
  },
  formSubmit: function(i) {
    var n = this;
    if (this.data.power.length < 2) return wx.showToast({
      title: "请选择权限！",
      icon: "none",
      duration: 1600
    }), !1;
    var s = {
      request: "savePower",
      Token: e.globalData.userInfo.Token,
      unitid: this.data.unitid,
      power: this.data.power,
      wx_id: i.detail.value.wx_id
    };
    t.default.Post(a.sysApi, s, (function(t) {
      n.setData({
        canClick: 0
      }), 0 == t.code && wx.showModal({
        title: "系统提示",
        content: "保存成功！",
        success: function(t) {
          wx.navigateBack({
            delta: 1
          })
        }
      }), 1 == t.code && (wx.showToast({
        title: t.msg,
        icon: "none",
        duration: 1600
      }), n.setData({
        canClick: 1
      }))
    }))
  }
});