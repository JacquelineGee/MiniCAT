var t, e = require("../../../@babel/runtime/helpers/interopRequireDefault").default,
  a = require("../../../@babel/runtime/helpers/regeneratorRuntime"),
  n = require("../../../@babel/runtime/helpers/asyncToGenerator"),
  i = e(require("../../../utils/myfunc.js")),
  o = (e(require("../../../regenerator-runtime/runtime.js")), require("../../../apiconfig"));
Page({
  data: {
    systemList: "",
    selectid: "",
    money: 0,
    unitid: "",
    code: ""
  },
  onLoad: function(t) {
    var e = t.unitid;
    this.setData({
      unitid: e
    }), this.getsystemList()
  },
  getsystemList: function() {
    var t = this,
      e = {
        token: i.default.userInfo().token
      };
    i.default.Post(o.dataApi + "unit/system_list", e, (function(e) {
      200 == e.code && t.setData({
        systemList: e.data.systemlist,
        couponList: e.data.couponlist
      })
    }))
  },
  selectitem: function(t) {
    var e = t.currentTarget.dataset.item,
      a = e.price,
      n = this.data.couponList,
      i = a,
      o = 0,
      s = "";
    if (n.length > 0) {
      for (var r = 0; r < n.length; r++) a - n[r].money1 >= 0 && n[r].money > o && (o = n[r].money, s = n[r].coupon);
      i -= o
    }
    this.setData({
      selectid: e.id,
      money: i,
      coupon: s,
      money2: o
    })
  },
  getcode: function() {
    var t = this;
    wx.login({
      success: function(e) {
        t.setData({
          code: e.code
        }), console.log("code", e.code)
      }
    })
  },
  sureOrder: function() {
    if (this.data.selectid < 2) return wx.showToast({
      title: "请选择要开通的账号！",
      icon: "none",
      duration: 1600
    }), !1;
    var t = this;
    wx.showLoading({
      title: "下单中..."
    });
    var e = {
      unitid: t.data.unitid,
      money: t.data.money,
      systemid: t.data.selectid
    };
    i.default.Post(o.dataApi + "unit/applyorder_add", e, (function(e) {
      if (wx.hideLoading(), 200 == e.code) {
        var a = e.data;
        t.topay(a.sid)
      } else wx.showToast({
        title: e.msg,
        icon: "none",
        duration: 1600
      })
    }))
  },
  topay: (t = n(a().mark((function t(e) {
    var n, s;
    return a().wrap((function(t) {
      for (;;) switch (t.prev = t.next) {
        case 0:
          return t.next = 2, i.default.getCode();
        case 2:
          n = t.sent, s = {
            token: i.default.userInfo().token,
            code: n,
            saleid: e
          }, wx.showLoading({
            title: "支付中..."
          }), i.default.Post(o.dataApi + "unit/order_pay", s, (function(t) {
            wx.hideLoading();
            var e = t.data;
            console.log(e), 200 == t.code ? wx.requestPayment({
              timeStamp: e.timeStamp,
              nonceStr: e.nonceStr,
              package: e.package,
              signType: e.signType,
              paySign: e.paySign,
              success: function(t) {
                console.log(t), wx.navigateTo({
                  url: "/pages/9public/paystatus/paystatus?status=1"
                })
              },
              fail: function(t) {
                console.log(t), "requestPayment:fail cancel" == t.errMsg ? wx.showToast({
                  title: "支付取消！",
                  icon: "none",
                  duration: 2e3
                }) : wx.navigateTo({
                  url: "/pages/9public/paystatus/paystatus?status=0"
                })
              }
            }) : wx.showToast({
              title: "获取支付参数失败！",
              icon: "none",
              duration: 1600
            })
          }));
        case 6:
        case "end":
          return t.stop()
      }
    }), t)
  }))), function(e) {
    return t.apply(this, arguments)
  })
});