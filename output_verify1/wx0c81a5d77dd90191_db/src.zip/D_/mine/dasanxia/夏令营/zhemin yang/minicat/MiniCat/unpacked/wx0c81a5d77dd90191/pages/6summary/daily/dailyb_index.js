var t = require("../../../@babel/runtime/helpers/defineProperty"),
  e = require("../../../apiconfig"),
  a = require("../../../utils/myfunc.js");
Page({
  data: {
    navList: [{
      title: "总结概况",
      index: "1"
    }, {
      title: "见诊记录",
      index: "2"
    }, {
      title: "销售记录",
      index: "3"
    }, {
      title: "收款记录",
      index: "4"
    }, {
      title: "门店秒杀",
      index: "5"
    }],
    cIndex: 1,
    thList: [{
      width: 120,
      orderid: 1,
      orderlb: "byChar",
      thname: "员工",
      field: "staff"
    }, {
      width: 100,
      orderid: 2,
      orderlb: "byNum",
      thname: "客数",
      field: "custnum"
    }, {
      width: 150,
      orderid: 3,
      orderlb: "byNum",
      thname: "成交",
      field: "tprice"
    }, {
      width: 140,
      orderid: 4,
      orderlb: "byNum",
      thname: "收款",
      field: "receive"
    }, {
      width: 120,
      orderid: 5,
      orderlb: "byNum",
      thname: "初/复",
      field: "zhen1"
    }, {
      width: 120,
      orderid: 7,
      orderlb: "byNum",
      thname: "专/平",
      field: "zhen3"
    }],
    thList2: [{
      width: 120,
      orderid: 1,
      orderlb: "byChar",
      thname: "员工",
      field: "staff"
    }, {
      width: 200,
      orderid: 2,
      orderlb: "byChar",
      thname: "美容院",
      field: "unitname"
    }, {
      width: 150,
      orderid: 3,
      orderlb: "byChar",
      thname: "客户",
      field: "name"
    }, {
      width: 120,
      orderid: 4,
      orderlb: "byNum",
      thname: "成交",
      field: "price1"
    }, {
      width: 160,
      orderid: 5,
      orderlb: "byDate",
      thname: "日期",
      field: "date"
    }],
    thList3: [{
      width: 120,
      orderid: 1,
      orderlb: "byChar",
      thname: "员工",
      field: "staff"
    }, {
      width: 200,
      orderid: 2,
      orderlb: "byChar",
      thname: "美容院",
      field: "unitname"
    }, {
      width: 150,
      orderid: 3,
      orderlb: "byChar",
      thname: "产品",
      field: "product"
    }, {
      width: 120,
      orderid: 4,
      orderlb: "byNum",
      thname: "金额",
      field: "tprice"
    }, {
      width: 160,
      orderid: 5,
      orderlb: "byDate",
      thname: "日期",
      field: "date"
    }],
    thList5: [{
      width: 120,
      orderid: 1,
      orderlb: "byChar",
      thname: "员工",
      field: "staff"
    }, {
      width: 200,
      orderid: 2,
      orderlb: "byChar",
      thname: "美容院",
      field: "unitname"
    }, {
      width: 150,
      orderid: 3,
      orderlb: "byNum",
      thname: "成交",
      field: "price1"
    }, {
      width: 120,
      orderid: 4,
      orderlb: "byNum",
      thname: "欠款",
      field: "price2"
    }, {
      width: 160,
      orderid: 5,
      orderlb: "byDate",
      thname: "日期",
      field: "date"
    }],
    thList4: [{
      width: 120,
      orderid: 1,
      orderlb: "byChar",
      thname: "员工",
      field: "staff"
    }, {
      width: 200,
      orderid: 2,
      orderlb: "byChar",
      thname: "美容院",
      field: "unitname"
    }, {
      width: 150,
      orderid: 3,
      orderlb: "byChar",
      thname: "客户",
      field: "name"
    }, {
      width: 120,
      orderid: 4,
      orderlb: "byNum",
      thname: "收款",
      field: "receive"
    }, {
      width: 160,
      orderid: 5,
      orderlb: "byDate",
      thname: "日期",
      field: "date"
    }],
    btnList: [],
    cIndex2: "0",
    userInfo: "",
    where: {
      date: "",
      depart: "-部门-",
      departid: ""
    },
    pickList: [],
    saleList: [],
    journalList: [],
    staffdailyList: [],
    dailyInfo: {},
    scrollv: 800
  },
  onLoad: function(e) {
    console.log("page:", "6summary/daily/dailyb_index");
    for (var i = [], r = 0, d = -30; d <= 0; d++) {
      var n = new Date(a.GetDateStr(d)).getDate();
      0 == d && (n = "今"), i[r] = {
        index: d,
        btnname: n
      }, r++
    }
    var h = a.GetDateStr(0);
    this.setData(t(t(t({
      btnList: i
    }, "where.date", h), "userInfo", a.userInfo()), "scrollv", 800));
    var s = this;
    a.getList("mydepartList").then((function(t) {
      s.setData({
        mydepartList: t.data
      })
    })), this.clickBtn2()
  },
  DateChange: function(e) {
    var i = e.detail.value,
      r = 1 - a.getdaysbyDate(i);
    this.setData(t(t({}, "where.date", i), "cIndex2", r)), this.getDatalist()
  },
  clickBtn: function(e) {
    var i = e.currentTarget.dataset.index,
      r = a.GetDateStr(i);
    this.setData(t({
      cIndex2: i
    }, "where.date", r)), this.getDatalist()
  },
  clickBtn1: function(t) {
    this.setData({
      scrollv: 0
    })
  },
  clickBtn2: function(t) {
    this.setData({
      scrollv: 950
    })
  },
  clickTab: function(t) {
    var e = t.detail.data.index;
    this.setData({
      cIndex: e
    })
  },
  getDatalist: function() {
    var t = this,
      i = {
        date: this.data.where.date
      };
    if (!(this.data.where.depart.length > 0 && "-部门-" != this.data.where.depart)) return a.showTip("请选择部门！"), !1;
    i.departid = this.data.where.departid, a.Post(e.dataApi + "summary/departdaily_start", i, (function(e) {
      if (200 == e.code) {
        var a, i = e.data.journalList,
          r = e.data.miaoshaList,
          d = e.data.receiveList,
          n = e.data.staffList,
          h = [],
          s = 0,
          f = [];
        if (n.length > 0 && (n.forEach((function(t) {
            h.push({
              id: s,
              staff: t.staff,
              departid: t.departid,
              custnum: 0,
              zhen1: 0,
              zhena1: 0,
              zhen2: 0,
              zhena2: 0,
              zhen3: 0,
              zhena3: 0,
              zhen4: 0,
              zhena4: 0,
              tprice1: 0,
              tprice2: 0,
              tprice3: 0,
              tprice4: 0,
              tprice: 0,
              receive1: 0,
              receive2: 0,
              receive: 0,
              miaosha: 0
            }), s += 1
          })), f = n.map((function(t) {
            return t.staff
          }))), i.length > 0) {
          var o = {};
          i.forEach((function(t) {
            o[t.staff] = o[t.staff] || [], o[t.staff].push(t)
          })), f.forEach((function(t) {
            null == o[t] && (o[t] = [])
          })), f.forEach((function(t) {
            var e = 0,
              a = 0,
              i = 0,
              r = 0,
              d = 0,
              n = 0,
              s = 0,
              f = 0,
              c = 0,
              l = 0,
              u = 0,
              p = 0,
              m = 0;
            o[t].forEach((function(t) {
              e += 1, 1 * t.price1, 1 == t.zhena && 1 == t.zhenb && (a += 1, l += 1 * t.price1, t.price1 > 0 && (n += 1)), 1 == t.zhena && 0 == t.zhenb && (i += 1, u += 1 * t.price1, t.price1 > 0 && (s += 1)), 0 == t.zhena && 1 == t.zhenb && (r += 1, p += 1 * t.price1, t.price1 > 0 && (f += 1)), 0 == t.zhena && 0 == t.zhenb && (d += 1, m += 1 * t.price1, t.price1 > 0 && (c += 1))
            }));
            var b = h.indexOf(h.filter((function(e) {
                return e.staff == t
              }))[0]),
              y = h[b];
            y.custnum = e, y.zhen1 = a, y.zhena1 = n, y.zhen2 = i, y.zhena2 = s, y.zhen3 = r, y.zhena3 = f, y.zhen4 = d, y.zhena4 = c, y.tprice1 = l, y.tprice2 = u, y.tprice3 = p, y.tprice4 = m, y.tprice = l + u + p + m, h[b] = y
          }))
        }
        if (r.length > 0 && (o = {}, r.forEach((function(t) {
            o[t.staff] = o[t.staff] || [], o[t.staff].push(t)
          })), f.forEach((function(t) {
            null == o[t] && (o[t] = [])
          })), f.forEach((function(t) {
            var e = 0;
            o[t].forEach((function(t) {
              e += 1 * t.price1
            }));
            var a = h.indexOf(h.filter((function(e) {
                return e.staff == t
              }))[0]),
              i = h[a];
            i.miaosha = e, h[a] = i
          }))), d.length > 0) {
          o = {};
          d.forEach((function(t) {
            o[t.staff] = o[t.staff] || [], o[t.staff].push(t)
          })), f.forEach((function(t) {
            null == o[t] && (o[t] = [])
          })), f.forEach((function(t) {
            var e = 0,
              a = 0;
            o[t].forEach((function(t) {
              0 == t.salelb && (e += 1 * t.receive), 1 == t.salelb && (a += 1 * t.receive)
            }));
            var i = h.indexOf(h.filter((function(e) {
                return e.staff == t
              }))[0]),
              r = h[i];
            r.receive1 = e, r.receive2 = a, h[i] = r
          })), console.log("staffData", h)
        }
        var c = 0,
          l = 0,
          u = 0,
          p = 0,
          m = 0,
          b = 0,
          y = 0,
          v = 0,
          w = 0,
          z = 0,
          g = 0,
          D = 0,
          L = 0,
          x = 0,
          C = 0,
          E = 0;
        h.forEach((function(t) {
          c += t.custnum, l += t.zhen1, u += t.zhen2, p += t.zhen3, m += t.zhen4, b += t.zhena1, y += t.zhena2, v += t.zhena3, w += t.zhena4, z += t.tprice1, g += t.tprice2, D += t.tprice3, L += t.tprice4, x += t.receive1, C += t.receive2, E += t.miaosha
        })), a = {
          tcustnum: c,
          tzhen1: l,
          tzhen2: u,
          tzhen3: p,
          tzhen4: m,
          tzhena1: b,
          tzhena2: y,
          tzhena3: v,
          tzhena4: w,
          ttprice1: z,
          ttprice2: g,
          ttprice3: D,
          ttprice4: L,
          ttprice: z + g + D + L,
          treceive1: x,
          treceive2: C,
          treceive: x + C,
          tmiaosha: E
        }, t.setData({
          dailyInfo: e.data.dailyInfo,
          saleList: e.data.saleList,
          receiveList: e.data.receiveList,
          journalList: e.data.journalList,
          miaoshaList: e.data.miaoshaList,
          staffdailyList: e.data.dailyList,
          staffData: h,
          total: a
        })
      }
    }))
  },
  editinfo: function(t) {
    if (null == this.data.dailyInfo.id) return a.showTip("请选择部门！"), !1;
    var e = t.currentTarget.dataset.field,
      i = this.data.dailyInfo.id,
      r = this.data.dailyInfo[e],
      d = "";
    "dsummary" == e && (d = this.data.where.depart + "-每日总结"), "dgoal" == e && (d = this.data.where.depart + "-每日计划");
    var n = {
      id: i,
      table: "c_departdaily",
      field: e,
      note: r,
      title: d
    };
    wx.navigateTo({
      url: "/pages/9public/note/note_edit?info=" + JSON.stringify(n)
    })
  },
  scrollgo: function(t) {
    this.setData({
      scrollX: t.detail.scrollLeft
    })
  },
  showPicker: function(t) {
    var e = this.data[t.currentTarget.dataset.arr];
    e && e.length > 0 && ("mydepartList" == t.currentTarget.dataset.arr && e.forEach((function(t) {
      t.option = t.depart
    })), this.setData({
      pickList: e,
      show_picker: !0,
      picker: t.currentTarget.dataset.arr
    }))
  },
  getSelect: function(e) {
    "mydepartList" == this.data.picker && this.setData(t(t({}, "where.departid", e.detail.data.departid), "where.depart", e.detail.data.depart))
  },
  clickLine: function(e) {
    var i, r = e.currentTarget.dataset.item.id,
      d = e.currentTarget.dataset.arr;
    if (i = a.selectChange(this.data[d], r), this.setData(t({}, d, i)), "staffData" == d) {
      var n = this.data.staffData.filter((function(t) {
        return t.id == r
      }))[0];
      console.log("temp", n);
      var h = n.staff,
        s = [],
        f = this.data.staffdailyList.filter((function(t) {
          return t.staff == h
        }));
      console.log("staffsummary", f), f.length > 0 && (s = f[0]), this.setData({
        staffsummary: s
      })
    }
  },
  inputChange: function(e) {
    var a = e.currentTarget.dataset.item;
    this.setData(t({}, a, e.detail.value))
  },
  getOrder: function(e) {
    var a = e.detail.data,
      i = e.currentTarget.dataset.arr;
    this.setData(t({}, i, a))
  },
  getOrder2: function(t) {
    var e = t.currentTarget.dataset.field,
      i = a.orderBy(this.data.staffData, e, "byNum", 0);
    this.setData({
      staffData: i,
      field: e
    })
  }
});