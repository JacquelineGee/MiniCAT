var n = wx.getUpdateManager();
App({
  globalData: {
    userInfo: ""
  },
  onLaunch: function() {
    n.onUpdateReady((function() {
      wx.showModal({
        title: "更新提示",
        content: "新版本已经准备好，是否重启应用？",
        success: function(o) {
          o.confirm && (wx.clearStorageSync(), n.applyUpdate())
        }
      })
    })), n.onUpdateFailed((function() {
      wx.showModal({
        title: "更新提示",
        content: "新版本下载失败",
        showCancel: !1
      })
    }));
    var o = wx.getStorageSync("userInfo");
    console.log("apponlaunchuserinfo?", o), null == o || (this.globalData.userInfo = o)
  }
});