var t = require("../../../@babel/runtime/helpers/interopRequireDefault").default,
  a = require("../../../@babel/runtime/helpers/defineProperty"),
  i = t(require("../../../utils/myfunc.js")),
  e = require("../../../apiconfig");
Page({
  data: {
    indexList: [],
    where: {
      limit: 20,
      albumlb: "-照片类别-",
      unitname: "-美容院-",
      unitid: 0,
      cid: "",
      name: "-顾客姓名-"
    },
    unitList: [],
    albumlbList: [],
    cidList: []
  },
  onLoad: function(t) {
    console.log("page:", "1work/album/album_list");
    var a = this;
    i.default.getList("myunitList").then((function(t) {
      a.setData({
        unitList: t.data
      })
    })), i.default.getList("albumlb").then((function(t) {
      var i = t.data;
      i = [{
        value: "-照片类别-"
      }].concat(i), a.setData({
        albumlbList: i
      }), wx.setStorageSync("albumlbList", t.data)
    }))
  },
  getdataList: function() {
    var t = this,
      a = {
        limit: this.data.where.limit
      };
    if (this.data.where.albumlb.length > 0 && "-照片类别-" != this.data.where.albumlb && (a.albumlb = this.data.where.albumlb), !(this.data.where.unitid > 0)) return i.default.showTip("请选择美容院！"), !1;
    a.unitid = this.data.where.unitid, this.data.where.cid > 0 && (a.cid = this.data.where.cid), i.default.Post(e.dataApi + "album/albumwx_list", a, (function(a) {
      200 == a.code && t.setData({
        dataList: a.data.list,
        picList: a.data.piclist,
        coverList: a.data.coverlist,
        msg: a.msg
      })
    }))
  },
  previewImage: function(t) {
    var a = t.target.dataset.src;
    console.log("current", a), wx.previewImage({
      current: a,
      urls: this.data.picList
    })
  },
  toAdd: function(t) {
    if (0 == this.data.where.unitid) return i.default.showTip("请选择美容院！"), !1;
    wx.navigateTo({
      url: "./album_add?unitid=" + this.data.where.unitid
    })
  },
  toEdit: function(t) {
    var a = t.currentTarget.dataset.item;
    wx.navigateTo({
      url: "./album_edit?info=" + JSON.stringify(a)
    })
  },
  showPicker: function(t) {
    var a = this.data[t.currentTarget.dataset.item];
    null == a || ("unitList" == t.currentTarget.dataset.item && a.forEach((function(t) {
      t.option = t.unitname
    })), "albumlbList" == t.currentTarget.dataset.item && a.forEach((function(t) {
      t.option = t.value
    })), "cidList" == t.currentTarget.dataset.item && a.forEach((function(t) {
      t.option = t.name
    })), this.setData({
      pickList: a,
      show_picker: !0,
      picker: t.currentTarget.dataset.item
    }))
  },
  getSelect: function(t) {
    if ("unitList" == this.data.picker) {
      this.setData(a(a({}, "where.unitid", t.detail.data.id), "where.unitname", t.detail.data.unitname));
      var e = this;
      i.default.getcidList(t.detail.data.id).then((function(t) {
        var i = [{
          value: "-顾客姓名-"
        }].concat(t.data);
        e.setData(a(a({
          cidList: i
        }, "where.cid", ""), "where.name", "-顾客姓名-")), wx.setStorageSync("cidList", t.data)
      }))
    }
    "albumlbList" == this.data.picker && this.setData(a({}, "where.albumlb", t.detail.data.value)), "cidList" == this.data.picker && (this.setData(a(a({}, "where.cid", t.detail.data.id), "where.name", t.detail.data.name)), this.getdataList())
  },
  inputChange: function(t) {
    var i = t.currentTarget.dataset.item;
    this.setData(a({}, i, t.detail.value))
  }
});