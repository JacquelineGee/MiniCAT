var i = getApp(),
  o = require("../../../apiconfig");
Page({
  data: {},
  onLoad: function(a) {
    console.log("hello", a), this.setData({
      id: a.id,
      qrcodeurl: o.qrcodeApi,
      unitid: i.globalData.userInfo.unitid,
      unionid: i.globalData.userInfo.unionid
    })
  }
});