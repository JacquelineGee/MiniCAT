var t = (0, require("../../../@babel/runtime/helpers/interopRequireDefault").default)(require("../../../utils/myfunc.js")),
  e = require("../../../apiconfig");
Page({
  data: {
    navList: [{
      title: "门店信息",
      index: "1"
    }, {
      title: "事件记录",
      index: "6"
    }],
    cIndex: 1,
    id: "",
    unitInfo: "",
    eventList: [],
    state_show: !1
  },
  clickTab: function(t) {
    var e = t.detail.data.index;
    this.setData({
      cIndex: e
    }), "6" == e && this.getEventList(this.data.id)
  },
  onLoad: function(t) {
    console.log("page:", "1work/unit/unit_info"), this.setData({
      id: t.id
    }), this.getInfo()
  },
  getInfo: function() {
    var e = this;
    t.default.getInfo("d_unit", this.data.id).then((function(t) {
      e.setData({
        unitInfo: t.data
      })
    }))
  },
  toEdit: function(t) {
    var e = t.currentTarget.dataset.item;
    wx.navigateTo({
      url: "./unit_edit?info=" + JSON.stringify(e)
    })
  },
  editinfo: function(t) {
    var e = t.currentTarget.dataset.key;
    wx.navigateTo({
      url: "./unitnote_edit?id=" + this.data.id + "&infolb=" + e
    })
  },
  getEventList: function(i) {
    var n = this,
      a = {
        token: t.default.userInfo().token,
        unitid: i
      };
    t.default.Post(e.dataApi + "event/event_list", a, (function(t) {
      if (200 == t.code) {
        var e = 1;
        t.data.length > 0 && (e = 0), n.setData({
          eventList: t.data,
          show_state: e
        })
      }
    }))
  }
});