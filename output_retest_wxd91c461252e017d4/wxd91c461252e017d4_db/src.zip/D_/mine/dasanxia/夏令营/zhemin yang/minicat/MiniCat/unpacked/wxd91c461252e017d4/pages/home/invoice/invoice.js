var t = i(require("../../../miniprogram_npm/@vant/weapp/notify/notify")),
  e = i(require("../../../miniprogram_npm/@vant/weapp/toast/toast"));

function i(t) {
  return t && t.__esModule ? t : {
    default: t
  }
}
var a = getApp(),
  n = require("../../../utils/webapi");
Page({
  data: {
    invoice_id: 0,
    invoice_title: "",
    tfn: "",
    unit_address: "",
    deposit_bank: "",
    bank_account: "",
    invoice_amount: "",
    participants: "",
    inbox: "",
    recipients: "",
    phone: "",
    mailing_address: "",
    openid: "",
    type_checked: "electronic",
    work_telephone: "",
    remark: "",
    issued: 0,
    phoneShow: !1,
    popShow: !1,
    popDuration: 200,
    records: [],
    isOverlay: !1
  },
  onLoad: function(t) {
    this.setData({
      invoice_id: t.invoice_id,
      invoice_title: t.invoice_title,
      tfn: t.tfn,
      invoice_amount: t.invoice_amount,
      participants: t.participants,
      inbox: t.inbox,
      phone: t.phone,
      remark: t.remark,
      issued: t.issued
    })
  },
  checkClick: function(t) {
    this.setData({
      type_checked: t.target.dataset.name
    })
  },
  closePhoneDialog: function() {
    this.setData({
      phoneShow: !1
    })
  },
  onClose: function() {
    this.setData({
      popShow: !1
    })
  },
  focusInvoiceTitle: function(t) {
    var e = this,
      i = a.globalData.openid;
    n.getInvoices({
      openid: i,
      invoice_title: ""
    }).then((function(t) {
      t.data.length > 0 && e.setData({
        records: t.data,
        popShow: !0
      })
    }))
  },
  changeInvoiceTitle: function(t) {
    var e = this;
    n.getInvoiceLists({
      issued: "",
      invoice_title: t.detail,
      startDate: "",
      endDate: "",
      pageSize: 7,
      pageNum: 1
    }).then((function(t) {
      if (t.data.list.length > 0) {
        e.data.popShow || e.setData({
          popShow: !0
        });
        var i = t.data.list.filter((function(e, i) {
          return t.data.list.findIndex((function(t) {
            return t.invoice_title === e.invoice_title
          })) === i
        }));
        e.setData({
          records: i
        })
      } else e.data.popShow && e.setData({
        popShow: !1
      })
    }))
  },
  rowClick: function(t) {
    this.setData({
      invoice_title: t.target.dataset.item.invoice_title,
      tfn: t.target.dataset.item.tfn,
      popShow: !1
    });
    var e = a.globalData.openid;
    t.target.dataset.item.openid === e ? this.setData({
      inbox: t.target.dataset.item.inbox,
      phone: t.target.dataset.item.phone
    }) : this.setData({
      inbox: "",
      phone: ""
    })
  },
  getPhoneNumber: function(t) {
    "getPhoneNumber:ok" == t.detail.errMsg && n.getPhoneNumber({
      encryptedData: t.detail.encryptedData,
      iv: t.detail.iv,
      session_key: a.globalData.session_key
    }).then((function(t) {
      a.globalData.localPhone = t.data, a.globalData.phone = t.data, n.postUpdatePartner({
        openid: a.globalData.openid,
        partner_phone: a.globalData.localPhone
      }).then((function(t) {}))
    })).catch((function(t) {}))
  },
  onSubmit: function() {
    var i = this;
    if (a.globalData.openid)
      if (this.data.invoice_title)
        if (this.data.tfn)
          if (this.data.invoice_amount)
            if (this.data.participants)
              if (this.data.inbox || "electronic" != this.data.type_checked)
                if (this.data.phone || "electronic" != this.data.type_checked)
                  if (0 == this.data.invoice_id) {
                    var o = {
                      invoice_title: this.data.invoice_title,
                      tfn: this.data.tfn,
                      unit_address: this.data.unit_address,
                      deposit_bank: this.data.deposit_bank,
                      bank_account: this.data.bank_account,
                      invoice_amount: this.data.invoice_amount,
                      participants: this.data.participants,
                      inbox: this.data.inbox,
                      recipients: this.data.recipients,
                      phone: this.data.phone,
                      mailing_address: this.data.mailing_address,
                      openid: a.globalData.openid,
                      type_checked: this.data.type_checked,
                      work_telephone: this.data.work_telephone,
                      remark: this.data.remark
                    };
                    n.postInvoice(o).then((function(t) {
                      200 == t.code ? (e.default.success("提交成功！"), i.setData({
                        invoice_title: "",
                        tfn: "",
                        unit_address: "",
                        deposit_bank: "",
                        bank_account: "",
                        invoice_amount: "",
                        participants: "",
                        inbox: "",
                        recipients: "",
                        phone: "",
                        mailing_address: "",
                        work_telephone: "",
                        remark: ""
                      })) : e.default.fail("提交失败")
                    }))
                  } else {
                    var s = {
                      invoice_id: this.data.invoice_id,
                      invoice_title: this.data.invoice_title,
                      tfn: this.data.tfn,
                      invoice_amount: this.data.invoice_amount,
                      participants: this.data.participants,
                      inbox: this.data.inbox,
                      phone: this.data.phone,
                      remark: this.data.remark,
                      issued: this.data.issued
                    };
                    n.editInvoice(s).then((function(t) {
                      200 == t.code ? (e.default.success("提交成功！"), setTimeout((function() {
                        wx.navigateBack({
                          delta: 1
                        })
                      }), 2500)) : e.default.fail(t.message)
                    }))
                  }
    else(0, t.default)({
      type: "warning",
      message: "请输入联系电话"
    });
    else(0, t.default)({
      type: "warning",
      message: "请输入收件人邮箱"
    });
    else(0, t.default)({
      type: "warning",
      message: "请输入报名人员信息"
    });
    else(0, t.default)({
      type: "warning",
      message: "请输入开票金额"
    });
    else(0, t.default)({
      type: "warning",
      message: "请输入纳税人识别号"
    });
    else(0, t.default)({
      type: "warning",
      message: "请输入发票抬头"
    });
    else this.setData({
      phoneShow: !0
    })
  },
  clickInvoiceRecord: function() {
    wx.navigateTo({
      url: "/pages/mine/invoice-records/invoice-records"
    })
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {}
});