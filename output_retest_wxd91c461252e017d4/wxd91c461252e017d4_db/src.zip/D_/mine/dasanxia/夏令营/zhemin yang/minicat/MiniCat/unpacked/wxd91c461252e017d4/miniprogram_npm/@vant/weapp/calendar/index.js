var t = function(t, e) {
    for (var a = 0, n = e.length, i = t.length; a < n; a++, i++) t[i] = e[a];
    return t
  },
  e = function(t) {
    return t && t.__esModule ? t : {
      default: t
    }
  };
Object.defineProperty(exports, "__esModule", {
  value: !0
});
var a, n = require("../common/component"),
  i = require("./utils"),
  o = e(require("../toast/toast")),
  r = require("../common/utils"),
  s = i.getToday().getTime(),
  l = (a = i.getToday(), new Date(a.getFullYear(), a.getMonth() + 6, a.getDate()).getTime());
n.VantComponent({
  props: {
    title: {
      type: String,
      value: "日期选择"
    },
    color: String,
    show: {
      type: Boolean,
      observer: function(t) {
        t && (this.initRect(), this.scrollIntoView())
      }
    },
    formatter: null,
    confirmText: {
      type: String,
      value: "确定"
    },
    rangePrompt: String,
    showRangePrompt: {
      type: Boolean,
      value: !0
    },
    defaultDate: {
      type: null,
      observer: function(t) {
        this.setData({
          currentDate: t
        }), this.scrollIntoView()
      }
    },
    allowSameDay: Boolean,
    confirmDisabledText: String,
    type: {
      type: String,
      value: "single",
      observer: "reset"
    },
    minDate: {
      type: null,
      value: s
    },
    maxDate: {
      type: null,
      value: l
    },
    position: {
      type: String,
      value: "bottom"
    },
    rowHeight: {
      type: null,
      value: i.ROW_HEIGHT
    },
    round: {
      type: Boolean,
      value: !0
    },
    poppable: {
      type: Boolean,
      value: !0
    },
    showMark: {
      type: Boolean,
      value: !0
    },
    showTitle: {
      type: Boolean,
      value: !0
    },
    showConfirm: {
      type: Boolean,
      value: !0
    },
    showSubtitle: {
      type: Boolean,
      value: !0
    },
    safeAreaInsetBottom: {
      type: Boolean,
      value: !0
    },
    closeOnClickOverlay: {
      type: Boolean,
      value: !0
    },
    maxRange: {
      type: null,
      value: null
    },
    firstDayOfWeek: {
      type: Number,
      value: 0
    }
  },
  data: {
    subtitle: "",
    currentDate: null,
    scrollIntoView: ""
  },
  created: function() {
    this.setData({
      currentDate: this.getInitialDate()
    })
  },
  mounted: function() {
    !this.data.show && this.data.poppable || (this.initRect(), this.scrollIntoView())
  },
  methods: {
    reset: function() {
      this.setData({
        currentDate: this.getInitialDate()
      }), this.scrollIntoView()
    },
    initRect: function() {
      var t = this;
      null != this.contentObserver && this.contentObserver.disconnect();
      var e = this.createIntersectionObserver({
        thresholds: [0, .1, .9, 1],
        observeAll: !0
      });
      this.contentObserver = e, e.relativeTo(".van-calendar__body"), e.observe(".month", (function(e) {
        e.boundingClientRect.top <= e.relativeRect.top && t.setData({
          subtitle: i.formatMonthTitle(e.dataset.date)
        })
      }))
    },
    limitDateRange: function(t, e, a) {
      return void 0 === e && (e = null), void 0 === a && (a = null), e = e || this.data.minDate, a = a || this.data.maxDate, -1 === i.compareDay(t, e) ? e : 1 === i.compareDay(t, a) ? a : t
    },
    getInitialDate: function(t) {
      var e = this;
      void 0 === t && (t = null);
      var a = this.data,
        n = a.type,
        o = a.minDate,
        r = a.maxDate,
        s = i.getToday().getTime();
      if ("range" === n) {
        Array.isArray(t) || (t = []);
        var l = t || [],
          u = l[0],
          c = l[1];
        return [this.limitDateRange(u || s, o, i.getPrevDay(r).getTime()), this.limitDateRange(c || s, i.getNextDay(o).getTime())]
      }
      return "multiple" === n ? Array.isArray(t) ? t.map((function(t) {
        return e.limitDateRange(t)
      })) : [this.limitDateRange(s)] : (t && !Array.isArray(t) || (t = s), this.limitDateRange(t))
    },
    scrollIntoView: function() {
      var t = this;
      r.requestAnimationFrame((function() {
        var e = t.data,
          a = e.currentDate,
          n = e.type,
          o = e.show,
          r = e.poppable,
          s = e.minDate,
          l = e.maxDate,
          u = "single" === n ? a : a[0];
        !u || !o && r || i.getMonths(s, l).some((function(e, a) {
          return 0 === i.compareMonth(e, u) && (t.setData({
            scrollIntoView: "month" + a
          }), !0)
        }))
      }))
    },
    onOpen: function() {
      this.$emit("open")
    },
    onOpened: function() {
      this.$emit("opened")
    },
    onClose: function() {
      this.$emit("close")
    },
    onClosed: function() {
      this.$emit("closed")
    },
    onClickDay: function(e) {
      var a = e.detail.date,
        n = this.data,
        o = n.type,
        r = n.currentDate,
        s = n.allowSameDay;
      if ("range" === o) {
        var l = r[0],
          u = r[1];
        if (l && !u) {
          var c = i.compareDay(a, l);
          1 === c ? this.select([l, a], !0) : -1 === c ? this.select([a, null]) : s && this.select([a, a])
        } else this.select([a, null])
      } else if ("multiple" === o) {
        var h;
        if (r.some((function(t, e) {
            var n = 0 === i.compareDay(t, a);
            return n && (h = e), n
          }))) {
          var m = r.splice(h, 1);
          this.setData({
            currentDate: r
          }), this.unselect(m)
        } else this.select(t(t([], r), [a]))
      } else this.select(a, !0)
    },
    unselect: function(t) {
      var e = t[0];
      e && this.$emit("unselect", i.copyDates(e))
    },
    select: function(t, e) {
      if (e && "range" === this.data.type && !this.checkRange(t)) return void(this.data.showConfirm ? this.emit([t[0], i.getDayByOffset(t[0], this.data.maxRange - 1)]) : this.emit(t));
      this.emit(t), e && !this.data.showConfirm && this.onConfirm()
    },
    emit: function(t) {
      var e = function(t) {
        return t instanceof Date ? t.getTime() : t
      };
      this.setData({
        currentDate: Array.isArray(t) ? t.map(e) : e(t)
      }), this.$emit("select", i.copyDates(t))
    },
    checkRange: function(t) {
      var e = this.data,
        a = e.maxRange,
        n = e.rangePrompt,
        r = e.showRangePrompt;
      return !(a && i.calcDateNum(t) > a) || (r && o.default({
        duration: 0,
        context: this,
        message: n || "选择天数不能超过 " + a + " 天"
      }), this.$emit("over-range"), !1)
    },
    onConfirm: function() {
      var t = this;
      ("range" !== this.data.type || this.checkRange(this.data.currentDate)) && wx.nextTick((function() {
        t.$emit("confirm", i.copyDates(t.data.currentDate))
      }))
    }
  }
});