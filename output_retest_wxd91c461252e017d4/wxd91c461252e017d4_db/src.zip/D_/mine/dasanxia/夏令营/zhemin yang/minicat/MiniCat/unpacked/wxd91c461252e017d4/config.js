Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.wssURL = exports.env = exports.baseURL = void 0;
var e = wx.getAccountInfoSync(),
  s = exports.env = e.miniProgram.envVersion;
s || console.error("获取运行环境失败!");
var i = exports.baseURL = {
    develop: "https://o.huixinshidai.cn/register-certificate-test/api",
    trial: "https://o.huixinshidai.cn/register-certificate-test/api",
    release: "https://o.huixinshidai.cn/register-certificate/api"
  } [s],
  t = exports.wssURL = {
    develop: "ws://192.168.50.85/KitchenService",
    trial: "wss://api.anyuns.com:5000/KitchenService",
    release: "wss://wb.anyuns.com:5000/KitchenService"
  } [s];
module.exports = {
  tokenKey: "UserSessionCacheConst",
  webApi: i,
  wssURL: t,
  pollInterval: 200
};