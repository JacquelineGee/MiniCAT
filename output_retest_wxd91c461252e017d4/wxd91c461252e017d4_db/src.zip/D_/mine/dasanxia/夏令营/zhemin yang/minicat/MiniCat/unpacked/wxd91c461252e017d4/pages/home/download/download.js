Page({
  data: {
    headerTips: "在操作中如有疑问，请拨打0871-65511162或进入在线客服咨询",
    menus: [{
      id: 1,
      title: "在考试结束5个工作日后，成绩合格的学员可按以下流程操作即可下载证书：",
      image: "",
      imageShow: !1,
      desc: ""
    }, {
      id: 2,
      title: "企业证",
      image: "",
      imageShow: !1,
      desc: [{
        id: 1,
        cont: "第一步：企业扫码登陆一体化平台点击人员管理→非注册人员业务→新培发证→选中人员信息→右上角点“上传工伤保险”上传材料后上报；",
        image: "",
        imageShow: !1
      }, {
        id: 2,
        cont: "第二步：本人在“云南建管”小程序“待办事项”中确认业务;",
        image: "http://m.qpic.cn/psc?/3f6edf2e-3b78-49c9-9740-8460a06ee3c9/ruAMsa53pVQWN7FLK88i5lc20X1jnGMO0XgHfBDgYFx99jkrVjmUVIS506YrqP6evEZm32GvWYdbJoNcGrf8*iDj15Ld1lq6o03Efb1gqdc!/b&bo=tAC0ALQAtAADByI!&rf=viewer_4",
        imageShow: !0
      }, {
        id: 3,
        cont: "第三步：等待主管部门进行审核;",
        image: "",
        imageShow: !1
      }, {
        id: 4,
        cont: "第四步：企业进入一体化管理系统，点人员管理→证书下载→选中人员信息右上角点击“下载”→添加下载申请→下载证书。",
        image: "",
        imageShow: !1
      }]
    }, {
      id: 3,
      title: "个人证",
      image: "",
      imageShow: !1,
      desc: [{
        id: 1,
        cont: "本人在“云南建管”小程序“待办事项”中确认业务→审核→我的→我的电子证书下载即可。",
        image: "",
        imageShow: !1
      }]
    }, {
      id: 4,
      title: "在操作中如有疑问请拨打0871-65631360，0871-65651496或进入在线客服咨询",
      image: "",
      imageShow: !1
    }]
  },
  onLoad: function(i) {},
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {}
});