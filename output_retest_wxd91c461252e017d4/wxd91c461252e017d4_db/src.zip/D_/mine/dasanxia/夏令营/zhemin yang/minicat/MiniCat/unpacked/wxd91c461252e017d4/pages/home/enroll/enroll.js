var e, t = (e = require("../../../miniprogram_npm/@vant/weapp/toast/toast")) && e.__esModule ? e : {
  default: e
};
getApp(), require("../../../utils/webapi");
Page({
  data: {
    menus: [{
      id: 1,
      icon: "http://m.qpic.cn/psc?/3f6edf2e-3b78-49c9-9740-8460a06ee3c9/ruAMsa53pVQWN7FLK88i5qGGWatmQNJDUajIIZDGJi.zp.O3KEUpsjjWrRCOIm1gSoGtEo3b6JS16*eRztJDkkndafz2iiTIBCBwLcp6Kq8!/b&bo=RAA.AEQAPgADByI!&rf=viewer_4",
      title: "住建考培",
      size: "image-view1",
      subtitle: "云南省住房和城乡建设领域",
      desc: "A证、B证、建筑电工、建筑架子工（普通脚手架）、焊工、八大员、试验员，测量员、普通工种16类",
      target: "/pages/training-lists/online-enroll/enroll-list/enroll-list"
    }, {
      id: 2,
      icon: "http://m.qpic.cn/psc?/3f6edf2e-3b78-49c9-9740-8460a06ee3c9/ruAMsa53pVQWN7FLK88i5qGGWatmQNJDUajIIZDGJi.6*g4hOMEhvT4EiPnVf2ubQdBULK9OrdDmop4JJxOwXupmrmq22rTxhJdUD9lM14o!/b&bo=RABHAEQARwADFzI!&rf=viewer_4",
      title: "应急考培",
      size: "image-view2",
      subtitle: "云南省应急管理领域",
      desc: "低压电工，高压电工，高处安装、维护、拆除作业，登高架设作业，熔化焊接与热切割作业",
      target: "/pages/home/emergency/enroll/enroll?enroll_type=firstTraining"
    }, {
      id: 3,
      icon: "http://m.qpic.cn/psc?/3f6edf2e-3b78-49c9-9740-8460a06ee3c9/ruAMsa53pVQWN7FLK88i5nMSR6a9zYtaC6jd8nFWGuZ1FvH7OCdSQrJhpttHQv65TDsGQeer3YIAZwYFBzJHcAlk9i.rCTItj2AlZ0BPwwM!/b&bo=PABLADwASwADFzI!&rf=viewer_4",
      title: "市监考培",
      size: "image-view3",
      subtitle: "云南省市场监督管理领域",
      desc: "特种设备安全管理(A)、叉车(N1)、永久气体气瓶充装(P)、电梯安装维修(T)、工业锅炉司炉(G1)......",
      target: "/pages/training-lists/market/market-list/market-list?enroll_type=firstTraining"
    }, {
      id: 4,
      icon: "http://m.qpic.cn/psc?/3f6edf2e-3b78-49c9-9740-8460a06ee3c9/ruAMsa53pVQWN7FLK88i5nMSR6a9zYtaC6jd8nFWGubQB32vL0oXCOL2DQv.HaQJcOvjKrY4jDqV9Vqh4x*iuplS6h7f7qK9oW4sMj3I4MI!/b&bo=OQBKADkASgADFzI!&rf=viewer_4",
      title: "人社考培",
      size: "image-view4",
      subtitle: "云南人力资源和社会保障领域",
      desc: "电工、架子工、混凝土工、钢筋工、手工木工、起重装卸机械操作工",
      target: ""
    }],
    naviTitle: ""
  },
  onLoad: function(e) {
    wx.setNavigationBarTitle({
      title: e.title
    }), this.setData({
      naviTitle: e.title
    })
  },
  clickInfo: function(e) {
    e.currentTarget.dataset.target ? wx.navigateTo({
      url: e.currentTarget.dataset.target
    }) : (0, t.default)("敬请期待")
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {}
});