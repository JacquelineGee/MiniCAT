var e = require("../../@babel/runtime/helpers/typeof");
module.exports = function(t) {
  var a = {};

  function n(e) {
    if (a[e]) return a[e].exports;
    var r = a[e] = {
      i: e,
      l: !1,
      exports: {}
    };
    return t[e].call(r.exports, r, r.exports, n), r.l = !0, r.exports
  }
  return n.m = t, n.c = a, n.d = function(e, t, a) {
    n.o(e, t) || Object.defineProperty(e, t, {
      enumerable: !0,
      get: a
    })
  }, n.r = function(e) {
    "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
      value: "Module"
    }), Object.defineProperty(e, "__esModule", {
      value: !0
    })
  }, n.t = function(t, a) {
    if (1 & a && (t = n(t)), 8 & a) return t;
    if (4 & a && "object" === e(t) && t && t.__esModule) return t;
    var r = Object.create(null);
    if (n.r(r), Object.defineProperty(r, "default", {
        enumerable: !0,
        value: t
      }), 2 & a && "string" != typeof t)
      for (var u in t) n.d(r, u, function(e) {
        return t[e]
      }.bind(null, u));
    return r
  }, n.n = function(e) {
    var t = e && e.__esModule ? function() {
      return e.default
    } : function() {
      return e
    };
    return n.d(t, "a", t), t
  }, n.o = function(e, t) {
    return Object.prototype.hasOwnProperty.call(e, t)
  }, n.p = "", n(n.s = 0)
}([function(e, t, a) {
  var n, r = a(1),
    u = (n = r) && n.__esModule ? n : {
      default: n
    };
  Component({
    options: {
      pureDataPattern: /^value|showWeek|isRendered|isLunarCalendar/
    },
    properties: {
      value: {
        type: Object,
        value: u.default.getDefaultValue()
      },
      showWeek: {
        type: Boolean,
        value: !0
      }
    },
    data: {
      isRendered: !1,
      isLunarCalendar: !1,
      objectMultiArray: u.default.getDefaultObjectMultiArray(),
      multiIndex: [0, 0, 0]
    },
    observers: {
      "value, showWeek": function(e, t) {
        this._render && this._render(e, t)
      }
    },
    lifetimes: {
      attached: function() {
        !1 === this.data.isRendered && this._triggerRender()
      }
    },
    methods: {
      _render: function(e, t) {
        var a = this,
          n = u.default.validateValue(e),
          r = n.year,
          l = n.month,
          i = n.day,
          o = n.isLeapMonth,
          d = n.isLunarCalendar,
          s = u.default.getYearColumn(),
          f = u.default.getMonthColumn(r, d),
          c = u.default.getDayColumn(r, l, o, d, t);
        this.setData({
          isRendered: !0,
          isLunarCalendar: d,
          objectMultiArray: [s, f, c]
        }), setTimeout((function() {
          a.setData({
            multiIndex: [u.default.getYearIndex(r), u.default.getMonthIndex(f, l, o), u.default.getDayIndex(i)]
          })
        }), 100)
      },
      _triggerRender: function() {
        this.setData({
          showWeek: this.data.showWeek
        })
      },
      bindColumnChange: function(e) {
        var t, a = e.detail,
          n = a.column,
          r = a.value,
          l = this.data,
          i = l.showWeek,
          o = l.isLunarCalendar;
        this.setData(((t = {})["multiIndex[" + n + "]"] = r, t));
        var d = this.data.multiIndex,
          s = d[0],
          f = d[1],
          c = d[2],
          m = u.default.getYearColumn(),
          h = u.default.getColumnItem(m, s).value,
          g = u.default.getMonthColumn(h, o),
          p = u.default.getColumnItem(g, f),
          v = p.value,
          y = p.isLeap,
          b = u.default.getDayColumn(h, v, y, o, i),
          C = u.default.getColumnItem(b, c).value;
        this._render({
          year: h,
          month: v,
          day: C,
          isLeapMonth: y,
          isLunarCalendar: o
        }, i)
      },
      bindCancel: function() {
        this._triggerRender()
      },
      bindChange: function() {
        var e = this.data,
          t = e.objectMultiArray,
          a = e.multiIndex,
          n = e.isLunarCalendar,
          r = t[0],
          l = t[1],
          i = t[2],
          o = a[0],
          d = a[1],
          s = a[2],
          f = u.default.getColumnItem(r, o).value,
          c = u.default.getColumnItem(l, d),
          m = c.value,
          h = c.isLeap,
          g = {
            year: f,
            month: m,
            day: u.default.getColumnItem(i, s).value,
            isLeapMonth: h,
            isLunarCalendar: n
          };
        this.triggerEvent("change", {
          value: g
        })
      }
    }
  })
}, function(e, t) {
  e.exports = require("./lib")
}]);