Object.defineProperty(exports, "__esModule", {
  value: !0
});
var e = require("../common/color"),
  t = require("../common/component"),
  r = require("../common/utils"),
  n = require("../common/validator"),
  a = require("../common/version"),
  i = require("./canvas");
var o = 2 * Math.PI,
  l = -Math.PI / 2;
t.VantComponent({
  props: {
    text: String,
    lineCap: {
      type: String,
      value: "round"
    },
    value: {
      type: Number,
      value: 0,
      observer: "reRender"
    },
    speed: {
      type: Number,
      value: 50
    },
    size: {
      type: Number,
      value: 100,
      observer: function() {
        this.drawCircle(this.currentValue)
      }
    },
    fill: String,
    layerColor: {
      type: String,
      value: e.WHITE
    },
    color: {
      type: null,
      value: e.BLUE,
      observer: function() {
        var e = this;
        this.setHoverColor().then((function() {
          e.drawCircle(e.currentValue)
        }))
      }
    },
    type: {
      type: String,
      value: ""
    },
    strokeWidth: {
      type: Number,
      value: 4
    },
    clockwise: {
      type: Boolean,
      value: !0
    }
  },
  data: {
    hoverColor: e.BLUE
  },
  methods: {
    getContext: function() {
      var e = this,
        t = this.data,
        n = t.type,
        o = t.size;
      if ("" === n || !a.canIUseCanvas2d()) {
        var l = wx.createCanvasContext("van-circle", this);
        return Promise.resolve(l)
      }
      var s = r.getSystemInfoSync().pixelRatio;
      return new Promise((function(t) {
        wx.createSelectorQuery().in(e).select("#van-circle").node().exec((function(r) {
          var a = r[0].node,
            l = a.getContext(n);
          e.inited || (e.inited = !0, a.width = o * s, a.height = o * s, l.scale(s, s)), t(i.adaptor(l))
        }))
      }))
    },
    setHoverColor: function() {
      var e = this,
        t = this.data,
        r = t.color,
        a = t.size;
      return n.isObj(r) ? this.getContext().then((function(t) {
        var n = t.createLinearGradient(a, 0, 0, 0);
        Object.keys(r).sort((function(e, t) {
          return parseFloat(e) - parseFloat(t)
        })).map((function(e) {
          return n.addColorStop(parseFloat(e) / 100, r[e])
        })), e.hoverColor = n
      })) : (this.hoverColor = r, Promise.resolve())
    },
    presetCanvas: function(e, t, r, n, a) {
      var i = this.data,
        o = i.strokeWidth,
        l = i.lineCap,
        s = i.clockwise,
        u = i.size / 2,
        c = u - o / 2;
      e.setStrokeStyle(t), e.setLineWidth(o), e.setLineCap(l), e.beginPath(), e.arc(u, u, c, r, n, !s), e.stroke(), a && (e.setFillStyle(a), e.fill())
    },
    renderLayerCircle: function(e) {
      var t = this.data,
        r = t.layerColor,
        n = t.fill;
      this.presetCanvas(e, r, 0, o, n)
    },
    renderHoverCircle: function(e, t) {
      var r = this.data.clockwise,
        n = o * (t / 100),
        a = r ? l + n : 3 * Math.PI - (l + n);
      this.presetCanvas(e, this.hoverColor, l, a)
    },
    drawCircle: function(e) {
      var t = this,
        r = this.data.size;
      this.getContext().then((function(n) {
        n.clearRect(0, 0, r, r), t.renderLayerCircle(n);
        var a, i = (a = e, Math.min(Math.max(a, 0), 100));
        0 !== i && t.renderHoverCircle(n, i), n.draw()
      }))
    },
    reRender: function() {
      var e = this,
        t = this.data,
        r = t.value,
        n = t.speed;
      n <= 0 || n > 1e3 ? this.drawCircle(r) : (this.clearInterval(), this.currentValue = this.currentValue || 0, this.interval = setInterval((function() {
        e.currentValue !== r ? (Math.abs(e.currentValue - r) < 1 ? e.currentValue = r : e.currentValue < r ? e.currentValue += 1 : e.currentValue -= 1, e.drawCircle(e.currentValue)) : e.clearInterval()
      }), 1e3 / n))
    },
    clearInterval: function(e) {
      function t() {
        return e.apply(this, arguments)
      }
      return t.toString = function() {
        return e.toString()
      }, t
    }((function() {
      this.interval && (clearInterval(this.interval), this.interval = null)
    }))
  },
  mounted: function() {
    var e = this;
    this.currentValue = this.data.value, this.setHoverColor().then((function() {
      e.drawCircle(e.currentValue)
    }))
  },
  destroyed: function() {
    this.clearInterval()
  }
});