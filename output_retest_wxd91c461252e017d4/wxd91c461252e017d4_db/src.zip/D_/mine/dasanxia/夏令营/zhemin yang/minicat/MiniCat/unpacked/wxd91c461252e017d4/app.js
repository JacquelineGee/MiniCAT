var n = require("./sdk/wxapi"),
  t = require("./utils/webapi");
App({
  onLaunch: function() {
    var n = wx.getStorageSync("logs") || [];
    n.unshift(Date.now()), wx.setStorageSync("logs", n), this.login()
  },
  globalData: {
    userInfo: null,
    localPhone: "",
    phone: "",
    openid: "",
    partner_type: "",
    session_key: "",
    baseUrl: "https://o.huixinshidai.cn"
  },
  login: function() {
    var t = this;
    n.login().then((function(n) {
      t.getOpenid(n.code)
    }))
  },
  getOpenid: function(n) {
    var e = this;
    n ? t.getOpenid({
      code: n
    }).then((function(n) {
      200 == n.code ? (e.globalData.openid = n.data.openid, e.globalData.session_key = n.data.session_key, e.globalData.partner_type = n.data.partner_type, e.globalData.partner_id = n.data.partner_id, e.globalData.phone = n.data.phone) : wx.showToast({
        title: n.message,
        icon: "none",
        duration: 2e3
      })
    })).catch((function(n) {
      wx.showToast({
        title: "服务器出现异常，请重新登录",
        icon: "none",
        duration: 2e3
      })
    })) : wx.showToast({
      title: "登录失败",
      icon: "none",
      duration: 2e3
    })
  }
});