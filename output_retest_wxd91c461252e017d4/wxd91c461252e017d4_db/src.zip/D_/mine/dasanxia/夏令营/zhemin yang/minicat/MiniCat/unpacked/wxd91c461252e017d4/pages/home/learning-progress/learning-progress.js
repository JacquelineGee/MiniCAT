e(require("../../../miniprogram_npm/@vant/weapp/notify/notify"));
var t = e(require("../../../miniprogram_npm/@vant/weapp/toast/toast"));

function e(t) {
  return t && t.__esModule ? t : {
    default: t
  }
}
var a = getApp(),
  n = require("../../../utils/webapi");
Page({
  data: {
    headerTips1: "1.学时要求:AB证、八大员48学时，特工32学时，普工24学时",
    headerTips2: "2.学时修满，显示不合格:AB证、特工、试验员测量员需网课系统点“去认证”认证学时，普工需要做测试并合格",
    headerTips3: "3.网课自开通日起算一年内有效，网课到期未学完的需要重新报名、重新缴费、重新学习",
    headerTips4: "4.网课进度工作日每天17:00更新，如有问题请致电:0871-65511162",
    keywork: "",
    addShow: !1,
    isFocus: !1,
    focusType: !0,
    valueData: "",
    dataLength: "",
    boxList: [1, 2, 3, 4, 5, 6],
    input_value: "",
    tempArr: [],
    menus: [{
      status_id: 0,
      company_name: "云南某某有限公司",
      id_number: "530281200212090525",
      name: "张三",
      work_type: "企业主要负责人",
      is_conformity: "合格",
      progress: "48"
    }],
    exampleMenus: {},
    srcPath: "http://m.qpic.cn/psc?/3f6edf2e-3b78-49c9-9740-8460a06ee3c9/ruAMsa53pVQWN7FLK88i5mrof8CvKPxnfSYzqlZ2J3OifhaLiBdQskZh.EA45qxWcHf1mF5ExYSR*hRGkm5u8GDlBfi5hewLuCdYTGRxtdE!/b&bo=OQA3ADkANwADByI!&rf=viewer_4",
    textColor: "follow-text-color"
  },
  onLoad: function(t) {},
  clickFollow: function(e) {
    0 == e.currentTarget.dataset.item.status_id ? (0, t.default)("示例学员，无法关注") : this.setData({
      addShow: !0,
      exampleMenus: e.currentTarget.dataset.item
    })
  },
  onClose: function() {
    this.setData({
      addShow: !1
    })
  },
  handleUseFocus: function() {
    this.setData({
      focusType: !0
    })
  },
  handleUseBlur: function() {
    this.setData({
      focusType: !1
    })
  },
  handleFocus: function() {
    this.setData({
      isFocus: !0
    })
  },
  handleSetData: function(t) {
    var e = Array.from(t.detail.value);
    this.setData({
      dataLength: t.detail.value.length,
      valueData: t.detail.value,
      tempArr: e
    })
  },
  onSubmit: function(e) {
    if (6 === this.data.dataLength) {
      var i = this.data.valueData,
        o = this.data.exampleMenus.id_number.slice(12);
      if (this.setData({
          addShow: !1,
          valueData: "",
          dataLength: "",
          tempArr: [],
          isFocus: !1,
          input_value: ""
        }), i === o) {
        var s = {
          partner_id: a.globalData.partner_id,
          openid: a.globalData.openid,
          status_id: this.data.exampleMenus.status_id
        };
        n.updateStatus(s).then((function(e) {
          200 == e.code ? t.default.success({
            duration: 4e3,
            message: '关注成功！请前往"我的","我关注的学员"查看'
          }) : 201 == e.code ? (0, t.default)({
            duration: 4e3,
            message: '您已关注该学员，请前往"我的","我关注的学员"查看'
          }) : (0, t.default)("添加失败，请稍后重试")
        }))
      } else(0, t.default)("验证失败")
    } else(0, t.default)("请输入学员身份证后六位")
  },
  onChange: function(t) {
    this.setData({
      keywork: t.detail
    })
  },
  onSearch: function() {
    this.getStatusList()
  },
  getStatusList: function() {
    var e = this,
      a = this.data.keywork;
    n.getStatusList({
      keywork: a
    }).then((function(a) {
      e.setData({
        menus: a.data
      }), 0 == e.data.menus.length && (0, t.default)("没有查到任何信息")
    }))
  },
  getLangfolioList: function() {
    var t = this,
      e = this.data.keywork;
    n.getLangfolioList({
      keywork: e
    }).then((function(e) {
      t.setData({
        menus: e.data.map((function(t) {
          return t.order = t.langfolio_id, t.companyName = t.company_name, t.name = t.name, t.idNumber = t.id_number, t.trainingClasses = t.work_type, t.learningProgressResult = t.progress, t.is_conformity = t.is_conformity, t
        }))
      })
    }))
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {}
});