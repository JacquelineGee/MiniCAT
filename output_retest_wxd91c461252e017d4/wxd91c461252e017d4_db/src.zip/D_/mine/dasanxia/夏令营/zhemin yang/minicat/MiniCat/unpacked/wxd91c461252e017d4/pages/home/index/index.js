var e, t = (e = require("../../../miniprogram_npm/@vant/weapp/toast/toast")) && e.__esModule ? e : {
  default: e
};
var i = getApp(),
  a = require("../../../utils/webapi");
require("../../../utils/util.js");
Page({
  data: {
    background: [],
    indicatorDots: !1,
    vertical: !1,
    autoplay: 3e3,
    interval: 5e3,
    intervalYJ: 5e3,
    intervalZJ: 7e3,
    indicatorColor: "rgba(200,200,200,1)",
    indicatorActiveColor: "rgba(0,0,200,1)",
    duration: 500,
    phoneShow: !1,
    menus: [{
      id: 1,
      icon: "/images/zjkp.png",
      title: "住建考培",
      desc: "",
      target: "/pages/home/scene/zj-index/zj-index",
      isShow: !0
    }, {
      id: 2,
      icon: "/images/yjkp.png",
      title: "应急考培",
      desc: "",
      target: "/pages/home/emergency/yj-index/yj-index",
      isShow: !0
    }, {
      id: 3,
      icon: "/images/sjkp.png",
      title: "市监考培",
      desc: "",
      target: "/pages/home/market/sj_index/sj_index",
      isShow: !0
    }, {
      id: 4,
      icon: "/images/rskp.png",
      title: "人社考培",
      desc: "",
      target: "",
      isShow: !0
    }],
    query_menus: [{
      id: 1,
      icon: "/images/zxbm_s@3x.png",
      title: "在线报名",
      desc: "",
      badge: "热",
      target: "/pages/home/enroll/enroll?title=在线报名",
      isShow: !0
    }, {
      id: 2,
      icon: "/images/bmjf_s@3x.png",
      title: "报名缴费",
      desc: "",
      badge: "",
      target: "/pages/home/enroll-apply/enroll-apply?title=在线缴费",
      isShow: !0
    }, {
      id: 3,
      icon: "/images/xetk_s@3x.png",
      title: "学而题库",
      desc: "",
      badge: "",
      target: "/pages/home/exam/exam-list/exam-list",
      isShow: !0
    }, {
      id: 4,
      icon: "/images/xycx_s@3x.png",
      title: "学员查询",
      desc: "",
      badge: "",
      target: "/pages/home/status-enquiry/status-enquiry",
      isShow: !0
    }],
    notices: []
  },
  onLoad: function(e) {
    this.getSwiperList(), this.noticeList()
  },
  noticeList: function() {
    var e = this;
    a.noticeList({
      type: "effective"
    }).then((function(t) {
      t.data.forEach((function(e) {
        e.create_time = e.create_time.split("T")[0]
      })), e.setData({
        notices: t.data
      })
    }))
  },
  clickNotice: function(e) {
    wx.navigateTo({
      url: "/pages/home/webView/webView?url=" + e.currentTarget.dataset.path
    })
  },
  getSwiperList: function() {
    var e = this;
    a.getSwiperList({
      type: "effective"
    }).then((function(t) {
      e.setData({
        background: t.data.map((function(e) {
          return e.img_path = i.globalData.baseUrl + e.img_path, e
        }))
      })
    }))
  },
  onClick: function(e) {
    4 == e.target.dataset.id && (0, t.default)("敬请期待")
  },
  search: function(e) {
    (0, t.default)("敬请期待")
  },
  closePhoneDialog: function() {
    this.setData({
      phoneShow: !1
    })
  },
  getPhoneNumber: function(e) {
    var t = this;
    "getPhoneNumber:ok" == e.detail.errMsg && a.getPhoneNumber({
      encryptedData: e.detail.encryptedData,
      iv: e.detail.iv,
      session_key: i.globalData.session_key
    }).then((function(e) {
      i.globalData.localPhone = e.data, i.globalData.phone = e.data, t.setData({
        popupShow: !0
      }), a.postUpdatePartner({
        openid: i.globalData.openid,
        partner_phone: i.globalData.localPhone
      }).then((function(e) {}))
    })).catch((function(e) {}))
  },
  onChange: function(e) {},
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {},
  onShareTimeline: function() {
    return {
      title: "学而在线：真诚服务 相伴成长"
    }
  }
});