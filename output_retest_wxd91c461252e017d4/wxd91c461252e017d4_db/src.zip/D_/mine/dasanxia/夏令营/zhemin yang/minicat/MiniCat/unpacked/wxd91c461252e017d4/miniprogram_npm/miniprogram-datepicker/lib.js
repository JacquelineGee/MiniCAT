var t = require("../../@babel/runtime/helpers/typeof");
module.exports = function(e) {
  var n = {};

  function u(t) {
    if (n[t]) return n[t].exports;
    var r = n[t] = {
      i: t,
      l: !1,
      exports: {}
    };
    return e[t].call(r.exports, r, r.exports, u), r.l = !0, r.exports
  }
  return u.m = e, u.c = n, u.d = function(t, e, n) {
    u.o(t, e) || Object.defineProperty(t, e, {
      enumerable: !0,
      get: n
    })
  }, u.r = function(t) {
    "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
      value: "Module"
    }), Object.defineProperty(t, "__esModule", {
      value: !0
    })
  }, u.t = function(e, n) {
    if (1 & n && (e = u(e)), 8 & n) return e;
    if (4 & n && "object" === t(e) && e && e.__esModule) return e;
    var r = Object.create(null);
    if (u.r(r), Object.defineProperty(r, "default", {
        enumerable: !0,
        value: e
      }), 2 & n && "string" != typeof e)
      for (var o in e) u.d(r, o, function(t) {
        return e[t]
      }.bind(null, o));
    return r
  }, u.n = function(t) {
    var e = t && t.__esModule ? function() {
      return t.default
    } : function() {
      return t
    };
    return u.d(e, "a", e), e
  }, u.o = function(t, e) {
    return Object.prototype.hasOwnProperty.call(t, e)
  }, u.p = "", u(u.s = 2)
}([, , function(t, e, n) {
  e.__esModule = !0;
  var u = o(n(3)),
    r = o(n(4));

  function o(t) {
    return t && t.__esModule ? t : {
      default: t
    }
  }
  e.default = {
    getToday: function() {
      return u.default.solar2lunar()
    },
    validateValue: function(t) {
      var e = parseInt(null == t ? void 0 : t.year, 10),
        n = parseInt(null == t ? void 0 : t.month, 10),
        r = parseInt(null == t ? void 0 : t.day, 10),
        o = !!(null == t ? void 0 : t.isLeapMonth),
        a = !!(null == t ? void 0 : t.isLunarCalendar),
        l = a ? u.default.lunar2solar(e, n, r, o) : u.default.solar2lunar(e, n, r),
        i = -1 === l ? this.getToday() : l;
      return {
        year: a ? i.lYear : i.cYear,
        month: a ? i.lMonth : i.cMonth,
        day: a ? i.lDay : i.cDay,
        isLeapMonth: !!a && i.isLeap,
        isLunarCalendar: a
      }
    },
    getDefaultValue: function() {
      var t = new Date;
      return {
        year: t.getFullYear(),
        month: t.getMonth() + 1,
        day: t.getDate(),
        isLeapMonth: !1,
        isLunarCalendar: !1
      }
    },
    getDefaultObjectMultiArray: function() {
      return [
        [{
          label: "某年",
          value: 0
        }],
        [{
          label: "某月",
          value: 0,
          isLeap: !1
        }],
        [{
          label: "某日",
          value: 0
        }]
      ]
    },
    getColumn: function(t, e, n) {
      for (var u = [], r = t; r <= e; r++) u.push(n.call(this, r));
      return u
    },
    getColumnItem: function(t, e) {
      return void 0 === t[e] && (e = t.length - 1), t[e]
    },
    getYearColumnItem: function(t) {
      return {
        label: t + "年",
        value: t
      }
    },
    getYearColumn: function() {
      return this.getColumn(1900, 2100, this.getYearColumnItem)
    },
    getYearIndex: function(t) {
      return t - 1900
    },
    getMonthColumnItemLabel: function(t, e, n) {
      if (n) {
        var r = u.default.toChinaMonth(t);
        return e && (r = "闰" + r), r
      }
      return t + "月"
    },
    getMonthColumnItem: function(t, e, n) {
      return {
        label: this.getMonthColumnItemLabel(t, e, n),
        value: t,
        isLeap: e
      }
    },
    getSolarMonthColumnItem: function(t) {
      return this.getMonthColumnItem(t, !1, !1)
    },
    getLunarNotLeapMonthColumnItem: function(t) {
      return this.getMonthColumnItem(t, !1, !0)
    },
    getLunarLeapMonthColumnItem: function(t) {
      return this.getMonthColumnItem(t, !0, !0)
    },
    getSolarMonthColumn: function() {
      return this.getColumn(1, 12, this.getSolarMonthColumnItem)
    },
    getLunarMonthColumn: function(t) {
      var e = this.getColumn(1, 12, this.getLunarNotLeapMonthColumnItem),
        n = u.default.leapMonth(t);
      return 0 !== n && e.splice(n, 0, this.getLunarLeapMonthColumnItem(n)), e
    },
    getMonthColumn: function(t, e) {
      return e ? this.getLunarMonthColumn(t) : this.getSolarMonthColumn()
    },
    getMonthIndex: function(t, e, n) {
      return (0, r.default)(t, {
        value: e,
        isLeap: n
      })
    },
    getDayColumnItemLabel: function(t, e, n, r, o, a) {
      var l = o ? u.default.toChinaDay(n) : n + "日";
      a && (l = l + " " + (o ? u.default.lunar2solar(t, e, n, r) : u.default.solar2lunar(t, e, n)).ncWeek);
      return l
    },
    getDayColumnItem: function(t, e, n, u, r, o) {
      return {
        label: this.getDayColumnItemLabel(t, e, n, u, r, o),
        value: n
      }
    },
    getSolarDayColumnItem: function(t, e, n, u) {
      return this.getDayColumnItem(t, e, n, !1, !1, u)
    },
    getLunarDayColumnItem: function(t, e, n, u, r) {
      return this.getDayColumnItem(t, e, n, u, !0, r)
    },
    getSolarDays: function(t, e) {
      return u.default.solarDays(t, e)
    },
    getLunarDays: function(t, e, n) {
      return n ? u.default.leapDays(t) : u.default.monthDays(t, e)
    },
    getSolarDayColumn: function(t, e, n) {
      var u = this;
      return this.getColumn(1, this.getSolarDays(t, e), (function(r) {
        return u.getSolarDayColumnItem(t, e, r, n)
      }))
    },
    getLunarDayColumn: function(t, e, n, u) {
      var r = this;
      return this.getColumn(1, this.getLunarDays(t, e, n), (function(o) {
        return r.getLunarDayColumnItem(t, e, o, n, u)
      }))
    },
    getDayColumn: function(t, e, n, u, r) {
      return u ? this.getLunarDayColumn(t, e, n, r) : this.getSolarDayColumn(t, e, r)
    },
    getDayIndex: function(t) {
      return t - 1
    }
  }
}, function(t, e) {
  t.exports = require("calendar")
}, function(t, e) {
  t.exports = require("lodash.findindex")
}]);