var n = require("../../../utils/webapi");
Page({
  data: {
    isNumberShow: !1
  },
  onLoad: function(n) {
    this.getMenuShow()
  },
  getMenuShow: function() {
    var o = this;
    n.getDicts({
      dictType: "isMenuShow"
    }).then((function(n) {
      "1" == n.data[0].dict_value && o.setData({
        isNumberShow: !0
      })
    }))
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {},
  copyClick: function(n) {
    wx.setClipboardData({
      data: "单位名称：云南学而建筑职业技能培训学校有限公司\n银行账户：134064217102\n开户银行：中国银行股份有限公司昆明市民族村支行",
      success: function(n) {
        wx.getClipboardData({
          success: function(n) {
            console.log(n.data)
          }
        })
      }
    })
  }
});